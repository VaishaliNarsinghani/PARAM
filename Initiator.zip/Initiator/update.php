<?php include('auth.php'); ?>

<?php 
ini_set('memory_limit', '16G'); // or '1G'

$host = 'localhost';
$db = 'project_db';
$user = 'root';
$pass = '';
$message = "";

try {
    $pdo = new PDO("mysql:host=$host;dbname=$db;charset=utf8", $user, $pass);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

    // Message if any
    $message = isset($_GET['message']) ? $_GET['message'] : '';

    // 1. Fetch single record when 'view_id' is present
    $viewData = null;
    if (isset($_GET['view_id'])) {
        $view_id = $_GET['view_id'];
        $stmt = $pdo->prepare("SELECT * FROM mis WHERE reference_id = ?");
        $stmt->execute([$view_id]);
        $viewData = $stmt->fetch(PDO::FETCH_ASSOC);
    }

    // 2. Handle Update Submission
    if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['reference_id']) && isset($_POST['customerName'])) {
        $reference_id = $_POST['reference_id'];

        $fields = [
            'customerName', 'address', 'customerMob', 'visitType',
            'caseType', 'applicationNo',
            'initiatorMailId', 'initiationDate', 'time'
        ];

        $stmt = $pdo->prepare("SELECT * FROM mis WHERE reference_id = ?  ORDER BY initiationDate DESC");
        $stmt->execute([$reference_id]);
        $currentData = $stmt->fetch(PDO::FETCH_ASSOC);

        $updateParts = [];
        $params = [];

        foreach ($fields as $field) {
            if (isset($_POST[$field]) && $_POST[$field] !== $currentData[$field]) {
                $updateParts[] = "$field = ?";
                $params[] = $_POST[$field];
            }
        }

        for ($i = 1; $i <= 6; $i++) {
            if (isset($_FILES['new_pdfs']['tmp_name'][$i - 1]) && $_FILES['new_pdfs']['error'][$i - 1] === 0) {
                $pdfContent = file_get_contents($_FILES['new_pdfs']['tmp_name'][$i - 1]);
                $updateParts[] = "pdf$i = ?";
                $params[] = $pdfContent;
            }
        }

        if (!empty($updateParts)) {
            $params[] = $reference_id;
            $sql = "UPDATE mis SET " . implode(", ", $updateParts) . " WHERE reference_id = ?";
            $stmt = $pdo->prepare($sql);
            $stmt->execute($params);
            header("Location: update.php?success=1&message=Data%20updated%20successfully!");
            exit;
        }
    }

    // 3. Handle Search Filters
    $filters = [];
    $params = [];

    if ($_SERVER['REQUEST_METHOD'] === 'GET') {
        if (!empty($_GET['reference_id'])) {
            $filters[] = "reference_id LIKE ?";
            $params[] = "%" . $_GET['reference_id'] . "%";
        }
        if (!empty($_GET['customerName'])) {
            $filters[] = "customerName LIKE ?";
            $params[] = "%" . $_GET['customerName'] . "%";
        }
        if (!empty($_GET['applicationNo'])) {
            $filters[] = "address LIKE ?";
            $params[] = "%" . $_GET['applicationNo'] . "%";
        }
        if (!empty($_GET['applicationNo'])) {
            $filters[] = "applicationNo LIKE ?";
            $params[] = "%" . $_GET['applicationNo'] . "%";
        }
       
        if (!empty($_GET['caseType'])) {
            $filters[] = "caseType LIKE ?";
            $params[] = "%" . $_GET['caseType'] . "%";
        }
   
    }
    
    $sql = "SELECT * FROM mis WHERE flag_not_built = 0";

if (!empty($filters)) {
    $sql .= " AND " . implode(" AND ", $filters);
}

$stmt = $pdo->prepare($sql);
$stmt->execute($params);
$results = $stmt->fetchAll(PDO::FETCH_ASSOC);

} catch (PDOException $e) {
    $message = "Database Error: " . $e->getMessage();
}
?>

<?php if (!empty($message)): ?>
    <?= htmlspecialchars($message) ?>
<?php endif; ?>

<script>
<?php if (!empty($message)): ?>
  alert("<?= htmlspecialchars($message) ?>");
<?php endif; ?>
</script>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
  <title>Magpie Engineering</title>
  <link rel="shortcut icon" href="favicon.ico" type="image/x-icon">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
  <link rel="stylesheet" href="Revisereport10.css">
</head>
<body>
  <button class="toggle-btn" id="toggle-btn">☰</button>
  <div class="container">
    <div class="sidebar" id="sidebar">
      <div style="display: flex;">
        <img class="logo" src="logo.png" alt="">
        <h1>Magpie Engineering</h1>
      </div>
      <div class="rotating-text">INITIATOR</div>
      <a href="initiator.php"><i class="fas fa-search icon"></i>Search</a>
      <a href="homeinitiator.php"><i class="fas fa-home icon"></i>Home</a>
      <a href="update.php" class="active"><i class="fas fa-home icon"></i>Update Assignment</a>
      <a href="createsassign.php"><i class="fas fa-file-alt icon"></i> Create New Assignment</a>
      <a href="Createsubs.php"><i class="fas fa-plus-square icon"></i> Create Subsequent</a>
      <a href="Revisereport.php"><i class="fas fa-edit icon"></i> Revise Report</a>
        <a href="not_built.php"><i class="fas fa-edit icon"></i> Cases Not to be Built</a>

      <a href="index.php"><i class="fas fa-sign-out-alt icon"></i>Logout</a>
    </div>

    <div class="content" id="content">
      <div class="search-filters">
        <h2>Search Filters</h2>
        <form id="searchForm" method="GET" action="update.php">
          <div class="form-row">
            <input type="text" name="reference_id" placeholder="Reference ID" />
            <input type="text" name="customerName" placeholder="Customer Name" />
          </div>
          <div class="form-row">
                <input type="text" name="caseType" placeholder="Case Type" />
            <input type="text" name="applicationNo" placeholder="Application No." />
          </div>
         
          <button type="submit" style="background: #4A90E2;">Search to Update</button>
        </form>
      </div>

      <?php if (!isset($_GET['view_id']) && !empty($results)): ?>
<table id="sortableTable">
          <thead>    
               <?php echo "<h2>Customer Information Table</h2>";?>
        <tr >
          <th style="background-color:rgb(102, 146, 190);">Reference Number</th>
          <th style="background-color:rgb(102, 146, 190);">Customer Name</th>
          <th style="background-color:rgb(102, 146, 190);">Address</th>
          <th style="background-color:rgb(102, 146, 190);">Customer Mobile Number</th>
          <th style="background-color:rgb(102, 146, 190);">Visit Type</th>
          <th style="background-color:rgb(102, 146, 190);">Case Type</th>
          <th style="background-color:rgb(102, 146, 190);">Application Number</th>
          <th style="background-color:rgb(102, 146, 190);">Date</th>
          <th style="background-color:rgb(102, 146, 190);">View</th>
        </tr>
      </thead>    
        <?php foreach ($results as $row): ?>
        <tr>
          <td><?= htmlspecialchars($row['reference_id']) ?></td>
          <td><?= htmlspecialchars($row['customerName']) ?></td>
          <td><?= htmlspecialchars($row['address']) ?></td>
          <td><?= htmlspecialchars($row['customerMob']) ?></td>
          <td><?= htmlspecialchars($row['visitType']) ?></td>
          <td><?= htmlspecialchars($row['caseType']) ?></td>
          <td><?= htmlspecialchars($row['applicationNo']) ?></td>
          <td><?= htmlspecialchars($row['initiationDate']) ?></td>
          <td>
            <a href="update.php?view_id=<?= urlencode($row['reference_id']) ?>" style="text-decoration:none; color:white;">
              <button>View</button>
            </a>
          </td>
        </tr>
        <?php endforeach; ?>
      </table>
      <?php endif; ?>

      <?php if ($viewData): ?>
      <h3>update assignment</h3>
      <form method="POST" enctype="multipart/form-data">
        <table>
          <tr><th>Field</th><th>Old Value</th><th>New Value</th></tr>
          <tr><td>Reference ID</td><td><?= htmlspecialchars($viewData['reference_id']) ?></td><input type="hidden" name="reference_id" value="<?= htmlspecialchars($viewData['reference_id']) ?>"></tr>
          <?php
          $fields = ['customerName', 'address', 'customerMob', 'visitType', 'caseType', 'applicationNo', 'initiatorMailId', 'initiationDate', 'time'];
          foreach ($fields as $field):
          ?>
            <tr>
              <td><?= ucfirst($field) ?></td>
              <td><?= htmlspecialchars($viewData[$field]) ?></td>
              <td><input type="<?= $field === 'initiationDate' ? 'date' : ($field === 'time' ? 'time' : 'text') ?>" name="<?= $field ?>" value="<?= htmlspecialchars($viewData[$field]) ?>"></td>
            </tr>
          <?php endforeach; ?>

          <?php for ($i = 1; $i <= 6; $i++): ?>
          <tr>
            <td>PDF <?= $i ?></td>
            <td>
              <?php if (!empty($viewData["pdf$i"])): ?>
              <a href="view_pdf.php?ref_id=<?= urlencode($viewData['reference_id']) ?>&pdf=<?= $i ?>" target="_blank">View PDF</a>
              <?php else: ?>Not uploaded<?php endif; ?>
            </td>
            <td>
              <?php if (!empty($viewData["pdf$i"])): ?>
              <embed src="view_pdf.php?ref_id=<?= urlencode($viewData['reference_id']) ?>&pdf=<?= $i ?>" type="application/pdf" width="100%" height="400px">
              <?php else: ?>Not uploaded<?php endif; ?>
            </td>
            <td><input type="file" name="new_pdfs[]" accept="application/pdf"></td>
          </tr>
          <?php endfor; ?>
        </table>
        <button type="submit" style="margin-left:10%;padding:15px;">update assignment</button>
      </form>
      <?php endif; ?>
    </div>
  </div>
  <script>
    const toggleBtn = document.getElementById("toggle-btn");
    const sidebar = document.getElementById("sidebar");
    toggleBtn.addEventListener("click", () => {
      sidebar.classList.toggle("visible");
    });
  </script>
  
<script>
document.addEventListener("DOMContentLoaded", function () {
    const table = document.getElementById("sortableTable");
    const headers = table.querySelectorAll("th");
    let sortDirection = 1;
    let activeColumn = -1;

    headers.forEach((header, index) => {
        header.addEventListener("click", () => {
            const tbody = table.tBodies[0];
            const rows = Array.from(tbody.querySelectorAll("tr"));
            
            if (activeColumn === index) {
                sortDirection *= -1; // toggle
            } else {
                sortDirection = 1;
            }
            activeColumn = index;

            // Remove sort classes
            headers.forEach(h => h.classList.remove("asc", "desc"));
            header.classList.add(sortDirection === 1 ? "asc" : "desc");

            rows.sort((a, b) => {
                let aText = a.cells[index].textContent.trim();
                let bText = b.cells[index].textContent.trim();

                // Check if date
                if (/\d{4}-\d{2}-\d{2}/.test(aText) && /\d{4}-\d{2}-\d{2}/.test(bText)) {
                    return (new Date(aText) - new Date(bText)) * sortDirection;
                }

                // Check if number
                let aNum = parseFloat(aText.replace(/[^0-9.\-]/g, ""));
                let bNum = parseFloat(bText.replace(/[^0-9.\-]/g, ""));
                if (!isNaN(aNum) && !isNaN(bNum) && aText !== "" && bText !== "") {
                    return (aNum - bNum) * sortDirection;
                }

                // Default string compare
                return aText.localeCompare(bText, undefined, {numeric: true}) * sortDirection;
            });

            rows.forEach(row => tbody.appendChild(row));
        });
    });
});
</script>
</body>
</html>
