<?php
include('auth.php');

// Database connection
$host = 'localhost';
$db   = 'project_db';
$user = 'root';
$pass = '';
$message = '';

try {
    $pdo = new PDO("mysql:host=$host;dbname=$db;charset=utf8", $user, $pass);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (PDOException $e) {
    die("Database connection failed: " . $e->getMessage());
}

// Get reference details from GET
$reference_id  = isset($_GET['reference_id']) ? htmlspecialchars($_GET['reference_id']) : '';
$customer_name = isset($_GET['customerName']) ? htmlspecialchars($_GET['customerName']) : '';
$bank_name     = isset($_GET['bankName']) ? htmlspecialchars($_GET['bankName']) : '';

// Handle form submission
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $not_built_remarks = trim($_POST['not_built_remarks'] ?? '');
    $otp_input = trim($_POST['otp'] ?? '');

    if (empty($not_built_remarks) || empty($otp_input)) {
        $message = "Remarks and OTP are required.";
    } else {
        $today = date('Y-m-d');
        $stmt = $pdo->prepare("SELECT otp FROM otp_login WHERE date = ?");
        $stmt->execute([$today]);
        $row = $stmt->fetch(PDO::FETCH_ASSOC);

        if (!$row) {
            $message = "No OTP found for today.";
        } elseif ($otp_input !== $row['otp']) {
            $message = "Invalid OTP. Please try again.";
        } else {
            // ✅ Update query now includes not_built_remarks
            $update = $pdo->prepare("UPDATE mis 
                                     SET flag_not_built = 1, 
                                         flag_report_submit = 1, 
                                         flag_report_to_technical = 1, 
                                         flag_technical_to_cso = 1, 
                                         flag_cso_submit = 1, 
                                         flag_fe_submit = 1,
                                         flag_field_engineer = 1,
                                         flag_preview_submit = 1,
                                         flag_report_preview = 1,
                                         not_built_date = CURRENT_DATE,
                                         not_built_remarks = ?
                                     WHERE reference_id = ?");
            if ($update->execute([$not_built_remarks, $reference_id])) {
                echo "<script>
                    alert('Case marked as Not to be built successfully');
                    window.location.href = 'initiator.php';
                </script>";
                exit;
            } else {
                $message = "Failed to update case.";
            }
        }
    }
}
?>


<!-- JavaScript for Alert -->
<script>
    <?php if (!empty($message)): ?>
    alert("<?= htmlspecialchars_decode(addslashes($message)) ?>");
    <?php endif; ?>
</script>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Magpie Engineering</title>
    <link rel="shortcut icon" href="favicon.ico" type="image/x-icon">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
    <link rel="stylesheet" href="initiator12.css">
    <style>


        /* Main content styling */
.main-content {
    margin-left: 260px; /* keeps space for sidebar */
    padding: 30px;
    min-height: 100vh;
    display: flex;
    flex-direction: column;
    align-items: center; /* center horizontally */
    justify-content: center; /* center vertically */
    background: linear-gradient(135deg, #f9f9f9, #e0eafc);
}

/* Form container */
.main-content form {
    background: #ffffff;
    padding: 25px 40px;
    border-radius: 12px;
    box-shadow: 0px 4px 12px rgba(0,0,0,0.1);
    width: 100%;
    max-width: 500px;
}

/* Headings */
.main-content h2 {
    text-align: center;
    font-size: 1.8rem;
    color: #2c3e50;
    margin-bottom: 20px;
}

/* Labels */
.main-content label {
    display: block;
    font-weight: 600;
    margin-top: 12px;
    color: #34495e;
}

/* Inputs & textarea */
.main-content input[type="text"],
.main-content textarea {
    width: 100%;
    padding: 10px;
    border: 1px solid #bdc3c7;
    border-radius: 6px;
    margin-top: 5px;
    font-size: 1rem;
    transition: 0.3s;
}

.main-content textarea {
    resize: none;
    height: 80px;
}

.main-content input[type="text"]:focus,
.main-content textarea:focus {
    border-color: #3498db;
    outline: none;
    box-shadow: 0 0 6px rgba(52,152,219,0.4);
}

/* Submit button */
.btn-danger {
    background: linear-gradient(90deg, #e74c3c, #c0392b);
    color: #fff;
    padding: 12px 18px;
    border: none;
    border-radius: 6px;
    cursor: pointer;
    margin-top: 20px;
    width: 100%;
    font-size: 1.1rem;
    transition: all 0.3s ease-in-out;
}

.btn-danger:hover {
    background: linear-gradient(90deg, #c0392b, #a93226);
    transform: scale(1.02);
}

/* Message styling */
.message {
    font-weight: bold;
    text-align: center;
    margin-bottom: 15px;
    padding: 10px;
    border-radius: 6px;
}

.message.error {
    background: #ffdddd;
    color: #e74c3c;
    border: 1px solid #e74c3c;
}

.message.success {
    background: #ddffdd;
    color: #27ae60;
    border: 1px solid #27ae60;
}

    </style>
</head>
<body>
    <button class="toggle-btn" id="toggle-btn">☰</button>
    <div class="container">
        <!-- Sidebar -->
        <div class="sidebar" id="sidebar">
            <div style="display: flex">
                <img class="logo" src="logo.png" alt="" />
                <h1>Magpie Engineering</h1>
            </div>
            <div class="rotating-text">INITIATOR</div>
            <a href="initiator.php" class="active"><i class="fas fa-search icon"></i>Search</a>
            <a href="homeinitiator.php"><i class="fas fa-home icon"></i>Home</a>
            <a href="update.php"><i class="fas fa-home icon"></i>Update Assignment</a>
            <a href="createsassign.php"><i class="fas fa-file-alt icon"></i>Create New Assignment</a>
            <a href="Createsubs.php"><i class="fas fa-plus-square icon"></i>Create Subsequent</a>
            <a href="Revisereport.php"><i class="fas fa-edit icon"></i>Revise Report</a>
            <a href="index.php"><i class="fas fa-sign-out-alt icon"></i>Logout</a>
        </div>

        <!-- Main Content -->
        <div class="main-content">
            <h2>CASE Not to be built</h2>

           

            <form method="POST" action="">
                <label>Reference ID:</label>
                <input type="text" value="<?= $reference_id ?>" readonly><br><br>

                <label>Customer Name:</label>
                <input type="text" value="<?= $customer_name ?>" readonly><br><br>

                <label>Bank Name:</label>
                <input type="text" value="<?= $bank_name ?>" readonly><br><br>

               <label>Remarks (Required):</label>
    <textarea name="not_built_remarks" required><?= htmlspecialchars($_POST['not_built_remarks'] ?? '') ?></textarea><br><br>

                <label>OTP (Required):</label>
                <input type="text" name="otp" required><br><br>

                <button type="submit" class="btn-danger">Not to be built</button>
            </form>
        </div>
    </div>

    <script>
    // Sidebar toggle
    document.getElementById('toggle-btn').addEventListener('click', function () {
        document.getElementById('sidebar').classList.toggle('active');
    });
    </script>
</body>
</html> 
