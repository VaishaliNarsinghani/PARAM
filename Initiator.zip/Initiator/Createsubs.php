<?php include('auth.php'); ?>
<?php
ini_set('memory_limit', '16G'); // or '1G'
// Database connection details
$host = 'localhost';
$db = 'project_db';
$user = 'root';
$pass = '';
$message = "";


try {
    // Create a new PDO instance
    $pdo = new PDO("mysql:host=$host;dbname=$db;charset=utf8", $user, $pass);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
 // Function to generate new reference ID

function generateReferenceId(PDO $pdo, string $bankName, string $branchName): string
{
    // Ensure month boundary matches your business timezone (optional)
    // date_default_timezone_set('Asia/Kolkata');

    $yearMonth = date('y/m'); // e.g. "25/09"
    $bankAbbr   = strtoupper(substr(preg_replace('/\s+/', '', $bankName), 0, 3));
    $branchAbbr = strtoupper(substr(preg_replace('/\s+/', '', $branchName), 0, 3));

    // Get the highest sequence used THIS MONTH only
    $stmt = $pdo->prepare("
        SELECT COALESCE(
            MAX(CAST(SUBSTRING_INDEX(TRIM(reference_id), '/', -1) AS UNSIGNED)), 
            0
        ) AS max_seq
        FROM mis
        WHERE SUBSTRING_INDEX(TRIM(reference_id), '/', 2) = :ym
    ");
    $stmt->execute([':ym' => $yearMonth]);
    $lastSeq = (int)$stmt->fetchColumn();

    // Start at 0001 if none this month, else increment
    $nextSeq = $lastSeq + 1;
    $seq4 = str_pad((string)$nextSeq, 4, '0', STR_PAD_LEFT);

    return "{$yearMonth}/{$bankAbbr}/{$branchAbbr}/{$seq4}";
}
}
catch (PDOException $e) {
    $message = "Error: " . $e->getMessage();
}
 // Start the session to access logged-in user data

try {
    // Create a new PDO instance
    $pdo = new PDO("mysql:host=$host;dbname=$db;charset=utf8", $user, $pass);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

    // Ensure the user is logged in
    if (!isset($_SESSION['username'])) {
        die("Access denied. Please log in.");
    }

    $username = $_SESSION['username'];

    // Fetch all five branch columns for the logged-in user
    $stmt = $pdo->prepare("SELECT branch1, branch2, branch3, branch4, branch5 FROM login WHERE username = ?");
    $stmt->execute([$username]);
    $userData = $stmt->fetch(PDO::FETCH_ASSOC);

    if (!$userData) {
        die("User not found.");
    }

    // Store branch values into an array and filter out empty/null values
    $branches = array_filter([$userData['branch1'], $userData['branch2'], $userData['branch3'], $userData['branch4'], $userData['branch5']]);

    if (empty($branches)) {
        die("No branches assigned.");
    }

    $results = [];
  
    if ($_SERVER['REQUEST_METHOD'] === 'POST') {
        // Initialize the SQL query for the search functionality
        $query = "SELECT * FROM mis WHERE 1=1";
        $params = [];

        // Add filters only if fields are filled
      
        if (!empty($_POST['reference_id'])) {
            $query .= " AND reference_id LIKE ?";
            $params[] = "%" . $_POST['reference_id'] . "%";
        }
        
        if (!empty($_POST['customerName'])) {
            $query .= " AND customerName LIKE ?";
            $params[] = "%" . $_POST['customerName'] . "%";
        }
        if (!empty($_POST['city'])) {
            $query .= " AND address LIKE ?";
            $params[] = "%" . $_POST['city'] . "%";
        }
        if (!empty($_POST['applicationNo'])) {
            $query .= " AND applicationNo LIKE ?";
            $params[] = "%" . $_POST['applicationNo'] . "%";
        }
        if (!empty($_POST['bankName'])) {
            $query .= " AND bankName LIKE ?";
            $params[] = "%" . $_POST['bankName'] . "%";
        }
        
        if (!empty($_POST['branchname'])) {
          $query .= " AND branchname LIKE ?";
          $params[] = "%" . $_POST['branchname'] . "%";
    }
        if (!empty($_POST['caseType'])) {
            $query .= " AND caseType LIKE ?";
            $params[] = "%" . $_POST['caseType'] . "%";
        }
   // ✅ ADD THIS LINE HERE
    $query .= " ORDER BY initiationDate DESC";
    
        // Execute the search query
        $stmt = $pdo->prepare($query);
        $stmt->execute($params);
        $results = $stmt->fetchAll(PDO::FETCH_ASSOC);
    }
   
// Fetch technical managers for assignment
$managersQuery = "SELECT coordinator_id, name FROM coordinator_login";
$managersStmt = $pdo->prepare($managersQuery);
$managersStmt->execute();
$managersResult = $managersStmt->fetchAll(PDO::FETCH_ASSOC);

// Fetch data for the "View" functionality when the user clicks on "View"
$viewData = null;
if (isset($_GET['view_id'])) {
    $viewId = $_GET['view_id'];
    $stmt = $pdo->prepare("SELECT * FROM mis WHERE reference_id = ? AND flag_not_built = 0");
    $stmt->execute([$viewId]);
    $viewData = $stmt->fetch(PDO::FETCH_ASSOC);
}


if (isset($_POST['assign_task'])) {
    // Fetch the reference ID
    $referenceId = $viewData['reference_id'];

    // Directory to save PDFs
    $uploadDir = "uploads/";

    // Loop through each of the 6 file inputs
    for ($i = 0; $i < 6; $i++) {
        if (isset($_FILES['pdfs']['name'][$i]) && $_FILES['pdfs']['error'][$i] === UPLOAD_ERR_OK) {
            $tmpName = $_FILES['pdfs']['tmp_name'][$i];
            $originalName = basename($_FILES['pdfs']['name'][$i]);
            $targetPath = $uploadDir . time() . "_" . $originalName;

            // Move uploaded file to target path
            if (move_uploaded_file($tmpName, $targetPath)) {
                // Save the path/filename in the correct pdf field (pdf1 to pdf6)
                $pdfField = "pdf" . ($i + 1);

                // Update the PDF in the database
                $stmt = $pdo->prepare("UPDATE mis SET $pdfField = :pdf WHERE reference_id = :ref");
                $stmt->execute([
                    ':pdf' => $targetPath,
                    ':ref' => $referenceId
                ]);
            }
        }
    }

    // Continue processing other updated fields (name, address, etc.) as needed
    // Example:
    $updateStmt = $pdo->prepare("UPDATE mis SET 
        customerName = :customerName,
        address = :address,
        customerMob = :customerMob,
        visitType = :visitType,
        bankName = :bankName,
        branchname = :branchname,
        caseType = :caseType,
        applicationNo = :applicationNo,
        initiatorMailId = :initiatorMailId,
        initiationDate = :initiationDate,
        time = :time,
        coordinator_id = :coordinator_id
        WHERE reference_id = :ref");

    $updateStmt->execute([
        ':customerName' => $_POST['customerName'],
        ':address' => $_POST['address'],
        ':customerMob' => $_POST['customerMob'],
        ':visitType' => $_POST['visitType'],
        ':bankName' => $_POST['bankName'],
        ':branchname' => $_POST['branchname'],
        ':caseType' => $_POST['caseType'],
        ':applicationNo' => $_POST['applicationNo'],
        ':initiatorMailId' => $_POST['initiatorMailId'],
        ':initiationDate' => $_POST['initiationDate'],
        ':time' => $_POST['initiationTime'],
        ':coordinator_id' => $_POST['coordinator_id'],
        ':ref' => $referenceId
    ]);

    echo "<script>alert('Task Updated and Assigned Successfully');window.location='Createsubs.php';</script>";
}
// Directory to save PDFs (if you want to save files physically)
$uploadDir = "uploads/";
$pdfContents = ['', '', '', '', '', ''];

for ($i = 0; $i < 6; $i++) {
    if (isset($_FILES['new_pdfs']['name'][$i]) && $_FILES['new_pdfs']['error'][$i] === UPLOAD_ERR_OK) {
        // ✅ New file uploaded by user
        $tmpName = $_FILES['new_pdfs']['tmp_name'][$i];
        $pdfContents[$i] = file_get_contents($tmpName);
    } else {
        // ✅ No new file, use existing PDF binary from $viewData (e.g., from database)
        $pdfField = 'pdf' . ($i + 1);
        if (!empty($viewData[$pdfField])) {
            $pdfContents[$i] = $viewData[$pdfField]; // Already binary
        }
    }
}
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['assign_task'])) {
    $selectedEngineerId = $_POST['coordinator_id'] ?? '';

    try {
        // ✅ Step 1: Fetch old reference ID from MIS
        $stmtOld = $pdo->prepare("SELECT reference_id FROM mis WHERE applicationNo = ? ORDER BY id DESC LIMIT 1");
        $stmtOld->execute([$_POST['applicationNo']]);
        $oldReferenceData = $stmtOld->fetch(PDO::FETCH_ASSOC);

        $oldReferenceId = $oldReferenceData ? $oldReferenceData['reference_id'] : null;

        // ✅ Step 2: Generate a new reference ID
        $newReferenceId = generateReferenceId($pdo, $_POST['bankName'], $_POST['branchname']);

        // ✅ Step 3: Find party_name from mepl_details
        $partyName = ''; // default blank
        if (!empty($_POST['bankName'])) {
            $sqlParty = "SELECT bankName 
                         FROM mepl_details 
                         WHERE valu = ? 
                         LIMIT 1";
            $stmtParty = $pdo->prepare($sqlParty);
            $stmtParty->execute([$_POST['bankName']]);
            $partyName = $stmtParty->fetchColumn() ?: ''; 
            
            // Debugging output
            echo "<pre>DEBUG PARTY QUERY: $sqlParty with value = {$_POST['bankName']}</pre>";
            echo "<pre>DEBUG PARTY RESULT (party_name): $partyName</pre>";
        }

        // ✅ Step 4: Insert into `mis` table
        $sqlInsert = "INSERT INTO mis 
            (customerName, address, customerMob, visitType, bankName, branchname, caseType, applicationNo, initiatorMailId, initiationDate, reference_id, coordinator_id, party_name, pdf1, pdf2, pdf3, pdf4, pdf5, pdf6) 
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
        
        echo "<pre>DEBUG INSERT QUERY: $sqlInsert</pre>";

        $stmt = $pdo->prepare($sqlInsert);

        $stmt->bindParam(1, $_POST['customerName']);
        $stmt->bindParam(2, $_POST['address']);
        $stmt->bindParam(3, $_POST['customerMob']);
        $stmt->bindParam(4, $_POST['visitType']);
        $stmt->bindParam(5, $_POST['bankName']);
        $stmt->bindParam(6, $_POST['branchname']);
        $stmt->bindParam(7, $_POST['caseType']);
        $stmt->bindParam(8, $_POST['applicationNo']);
        $stmt->bindParam(9, $_POST['initiatorMailId']);
        $stmt->bindParam(10, $_POST['initiationDate']);
        $stmt->bindParam(11, $newReferenceId);
        $stmt->bindParam(12, $_POST['coordinator_id']);
        $stmt->bindParam(13, $partyName);   // ✅ Correct value coming from mepl_details.bankName
        $stmt->bindParam(14, $pdfContents[0], PDO::PARAM_LOB);
        $stmt->bindParam(15, $pdfContents[1], PDO::PARAM_LOB);
        $stmt->bindParam(16, $pdfContents[2], PDO::PARAM_LOB);
        $stmt->bindParam(17, $pdfContents[3], PDO::PARAM_LOB);
        $stmt->bindParam(18, $pdfContents[4], PDO::PARAM_LOB);
        $stmt->bindParam(19, $pdfContents[5], PDO::PARAM_LOB);

        if ($stmt->execute()) {
            echo "✅ Data with PDFs inserted successfully!<br>";

            // ✅ Step 5: Update new row with old_reference_id
            if ($oldReferenceId) {
                $stmtUpdateOld = $pdo->prepare("UPDATE mis SET old_reference_id = ? WHERE reference_id = ?");
                $stmtUpdateOld->execute([$oldReferenceId, $newReferenceId]);
            }

            // ✅ Step 6: Set assignment time
            $stmtUpdate = $pdo->prepare("UPDATE mis SET assigned_at_coordinator = CURRENT_TIMESTAMP WHERE reference_id = ?");
            $stmtUpdate->execute([$newReferenceId]);

        } else {
            echo "❌ Insert into MIS failed.<br>";
            print_r($stmt->errorInfo());
        }

    } catch (PDOException $e) {
        echo 'Error assigning the task: ' . $e->getMessage();
    }
}
}
 catch (PDOException $e) {
$message = "Error: " . $e->getMessage();
}


?>

<!-- JavaScript for Alert -->
<script>
<?php if (!empty($message)): ?>
alert("<?= htmlspecialchars_decode(addslashes($message)) ?>");
<?php endif; ?>
</script>
<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Magpie Engineering</title>
  <link rel="shortcut icon" href="favicon.ico" type="image/x-icon"> 
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
  <link rel="stylesheet" href="Createsubs77.css">
</head>
  <button class="toggle-btn" id="toggle-btn">☰</button>
  <div class="container">
    <!-- Sidebar -->

    <div class="sidebar" id="sidebar">
      <div style="display: flex;">
        <img class="logo" src="logo.png" alt="">
        <h1>Magpie Engineering</h1>
      </div>
      <div class="rotating-text">INITIATOR</div>
        <a href="initiator.php"><i class="fas fa-search icon"></i>Search</a>
             <a href="homeinitiator.php"><i class="fas fa-home icon"></i>Home</a>
        <a href="update.php"><i class="fas fa-home icon"></i>update assignment</a>
        <a href="createsassign.php"><i class="fas fa-file-alt icon"></i> Create New Assignment</a>
        <a href="Createsubs.php"class="active"><i class="fas fa-plus-square icon"></i> Create Subsequent</a>
        <a href="Revisereport.php"><i class="fas fa-edit icon"></i> Revise Report</a>
        <a href="not_built.php"><i class="fas fa-edit icon"></i> Cases Not to be Built</a>

        <a href="index.php"><i class="fas fa-sign-out-alt icon"></i>Logout</a>
    </div>

    <!-- Main Content -->
    <div class="content" id="content">
            <div class="search-filters">
                <h2>Search Filters</h2>
                <form id="searchForm" method="POST" action="Createsubs.php">
                <div class="form-row">
            <input type="text" name="reference_id" placeholder="Reference ID" />
            <input type="text" name="customerName" placeholder="Customer Name" />
          </div>
          <div class="form-row">
            <input type="text" name="city" placeholder="City" />
            <input type="text" name="applicationNo" placeholder="Application No." />
          </div>
          <div class="form-row">
            <input type="text" name="bankName" placeholder="Party Name " />
            <input type="text" name="branchname" placeholder="Branch Name" />
            <input type="text" name="caseType" placeholder="Case Type" />
           
          </div>
                    <button type="submit"style="background: #4A90E2;">Search for Subsequent</button>
                </form>
                </div>
        <?php echo "<style>
          /* Main Content */
 .content {
  margin: 0; /* Remove conflicting margins */
  padding: 20px;
  animation: fadeIn 1.5s ease-in-out;
  transition: transform 0.3s ease-in-out;
}

table {
  width: 100%;
  margin: 0 1% 0 1%; /* Use the same margin in both pages */
  border-collapse: collapse;
  background:rgb(207, 222, 240);
  color: #2C3E50;
  border-radius: 10px;
  overflow: hidden;
  table-layout: fixed; /* Enforce fixed column widths */
  
}

th, td {
  padding: 12px;
  text-align: left;
  border: 1px solid rgba(255, 255, 255, 0.2);
  font-size: 15px;
  word-wrap: break-word; /* Allow wrapping of text */
  white-space: normal; /* Ensure wrapping is allowed */
  min-width: 100px; /* Set a minimum width for columns */
}

th {
  font-size: 13px;
  background-color:rgb(102, 146, 190);
   color:white;
  font-weight: bold;
}

table {
    table-layout: fixed; /* Enforces fixed column widths */
}

th, td {
     /* Adjust as needed for your preferred column width */
    word-wrap: break-word; /* Allows text to wrap onto the next line */
    white-space: normal; /* Ensures wrapping is allowed */
}


 tr:nth-child(even) {
   background-color:rgb(234, 236, 250);
 }

 tr:hover {
   background-color:rgb(138, 177, 215);
   color:white;
   font-weight:bolder;
   font-style:italic;
 }
h2{
  margin-left:32% ; 
   font-style: oblique;
 color: #2C3E50;
 }
 button{
    padding:10px 10px;
    background-color: #005f8a;
    color: white;
    text-decoration: none;
    border: none;
    border-radius: 5px;
    cursor: pointer;
    font-size: 16px;
    margin-top:10px;
}

@media (max-width: 768px) {
  

.content {
  margin-left: 0;
}

.search-filters input,
.search-filters button {
  width: 90%;
}
}
.content {
margin-left: 270px; /* Adjust based on sidebar width */
}


@media (min-width: 1200px) {

@media (max-width: 768px) {
.toggle-btn {
 display: block;
}

.sidebar {
 transform: translateX(-100%);
}

.sidebar.visible {
 transform: translateX(0);
}

.content {
 margin-left: 0;
 margin:0;

}

.search-filters input,
.search-filters button {
 width: 90%;
}
}

@keyframes slideIn {
from {
 transform: translateX(-100%);
 opacity: 0;
}

to {
 transform: translateX(0);
 opacity: 1;
}
}

@keyframes fadeIn {
from {
 opacity: 0;
}

to {
 opacity: 1;
}
}

.logo {
  width: 50px;
  height:50px;
  padding: 15px;
}
@media (max-width: 768px) {
  .toggle-btn {
    display: block;
  }

  .sidebar {
    transform: translateX(-100%);
  }

  .sidebar.visible {
    transform: translateX(0);
  }

  .content {
    margin-left: 0;

  }

  .search-filters input,
  .search-filters button {
    width: 90%;
  }
}
  
   </style>";

   if (!empty($results)): ?>
  <table id="sortableTable">
      <thead>
   <?php echo "<h2>Customer Information Table</h2>";?>
      <tr>
          <th >Reference Number</th>
          <th>Customer Name</th>
          <th>Address</th>
          <th>Customer Mobile Number</th>
          <th>Visit Type</th>
          <th>Party Name </th>
          <th>Branch Name</th>
          <th>Case Type</th>
          <th>Application Number</th>
          <th>Date</th>
          <th>View</th>
      </tr>
   </thead>
 
      <?php foreach ($results as $row): ?>
      <tr>
          <td><?= htmlspecialchars($row['reference_id']) ?></td>
          <td><?= htmlspecialchars($row['customerName']) ?></td>
          <td><?= htmlspecialchars($row['address']) ?></td>
          <td><?= htmlspecialchars($row['customerMob']) ?></td>
          <td><?= htmlspecialchars($row['visitType']) ?></td>
          <td><?= htmlspecialchars($row['bankName']) ?></td>
          <td><?= htmlspecialchars($row['branchname']) ?></td>
          <td><?= htmlspecialchars($row['caseType']) ?></td>
          <td><?= htmlspecialchars($row['applicationNo']) ?></td>
          <td><?= htmlspecialchars($row['initiationDate']) ?></td>
          <td ><button style="text-decoration:none; color:white;"><a href="Createsubs.php?view_id=<?= $row['reference_id'] ?>">View</a></button></td>
      </tr>
      
      <?php endforeach; ?>
       
  </table>

<?php endif; ?>

<?php if ($viewData): ?>
  <h3>Subsequent Report</h3>
  <form action="Createsubs.php" method="POST" enctype="multipart/form-data"> 
      <table>
          <tr>
              <th>Field</th>
              <th>Old Value</th>
              <th>New Value</th>
          </tr>
           
    <tr>
        <td>Reference ID</td>
        <td><?= htmlspecialchars($viewData['reference_id']) ?></td>
       <input type="hidden" name="old_reference_id" value="<?= $oldReferenceId ?>">

    </tr>
    <tr>
        <td >Customer Name</td>
        <td><?= htmlspecialchars($viewData['customerName']) ?></td>
        <td><input type="text" name="customerName" value="<?= htmlspecialchars($viewData['customerName']) ?>"></td>
    </tr>
    <tr>
        <td>Address</td>
        <td><?= htmlspecialchars($viewData['address']) ?></td>
        <td><input type="text" name="address" value="<?= htmlspecialchars($viewData['address']) ?>"></td>
    </tr>
    <tr>
        <td >Customer Mobile</td>
        <td><?= htmlspecialchars($viewData['customerMob']) ?></td>
        <td><input  type="text" name="customerMob" value="<?= htmlspecialchars($viewData['customerMob']) ?>"></td>
    </tr>
   <tr>
    <td>Visit Type</td>
    <td><?= htmlspecialchars($viewData['visitType']) ?></td>
    <td>
        <select name="visitType">
                        <option value="SUBSEQUENT" <?= $viewData['visitType'] === 'SUBSEQUENT' ? 'selected' : '' ?>>SUBSEQUENT</option>
            <option value="RE-VISIT" <?= $viewData['visitType'] === 'RE-VISIT' ? 'selected' : '' ?>>RE-VISIT</option>
            <option value="APF-SUBSEQUENT" <?= $viewData['visitType'] === 'APF-SUBSEQUENT' ? 'selected' : '' ?>>APF-SUBSEQUENT</option>
        </select>
    </td>
</tr>

    <tr>
        <td>Party Name </td>
        <td><?= htmlspecialchars($viewData['bankName']) ?></td>
        <td><input type="text" name="bankName" value="<?= htmlspecialchars($viewData['bankName']) ?>"></td>
    </tr>
    <tr>
        <td>Branch Name</td>
        <td><?= htmlspecialchars($viewData['branchname']) ?></td>
        <td><input type="text" name="branchname" value="<?= htmlspecialchars($viewData['branchname']) ?>"></td>
    </tr>
    <tr>
        <td>Case Type</td>
        <td><?= htmlspecialchars($viewData['caseType']) ?></td>
        <td><input type="text" name="caseType" value="<?= htmlspecialchars($viewData['caseType']) ?>"></td>
    </tr>
    <tr>
        <td>Application Number</td>
        <td><?= htmlspecialchars($viewData['applicationNo']) ?></td>
        <td><input type="text" name="applicationNo" value="<?= htmlspecialchars($viewData['applicationNo']) ?>"></td>
    </tr>
    <tr>
        <td>Initiator Mail ID</td>
        <td><?= htmlspecialchars($viewData['initiatorMailId']) ?></td>
        <td><input type="text" name="initiatorMailId" value="<?= htmlspecialchars($viewData['initiatorMailId']) ?>"></td>
    </tr>
    <tr>
        <td>Initiation Date</td>
        <td><?= htmlspecialchars($viewData['initiationDate']) ?></td>
        <td><input type="date" name="initiationDate" value="<?= htmlspecialchars($viewData['initiationDate']) ?>"></td>
    </tr>
    <tr>
    <td>Time</td>
        <td><?= htmlspecialchars($viewData['time']) ?></td>
        <td><input type="time" name="initiationTime" value="<?= htmlspecialchars($viewData['time']) ?>"></td>
    </tr>


    <?php for ($i = 1; $i <= 6; $i++): ?>
    <tr>
        <td>PDF <?= $i ?></td>

        <!-- First display column: Link to view PDF -->
        <td>
            <?php if (!empty($viewData["pdf$i"])): ?>
                <a href="view_pdf.php?ref_id=<?= urlencode($viewData['reference_id']) ?>&pdf=<?= $i ?>" target="_blank">
                    View PDF
                </a>
            <?php else: ?>
                Not uploaded
            <?php endif; ?>
        </td>

        <!-- Second display column: Display PDF directly -->
        <td>
            <?php if (!empty($viewData["pdf$i"])): ?>
                <embed src="view_pdf.php?ref_id=<?= urlencode($viewData['reference_id']) ?>&pdf=<?= $i ?>" type="application/pdf" width="100%" height="400px">
            <?php else: ?>
                Not uploaded
            <?php endif; ?>
        </td>

        <!-- File input for uploading new PDF -->
        <td>
            <input type="file" name="new_pdfs[]" accept="application/pdf">
        </td>
    </tr>
<?php endfor; ?>



  

      </table>
      <!-- Dropdown for Assigning to Technical Manager -->
<label for="coordinator_id"style="margin-left:20px;">Select Coordinator :</label>
<select name="coordinator_id" id="coordinator_id" required>
    <option value="" disabled selected>Select a Coordinator</option>
    <?php foreach ($managersResult as $manager): ?>
        <option value="<?= htmlspecialchars($manager['coordinator_id']) ?>">            
            <?= htmlspecialchars($manager['name']) ?>
        </option>
    <?php endforeach; ?>
</select>
<!-- Submit Button -->
<button type="submit" name="assign_task" style="margin-left:10%;padding:15px;">Assign To coordinator</button>
</form>
  
<?php endif; ?>

</div>
</div>
<script>
  const toggleBtn = document.getElementById("toggle-btn");
  const sidebar = document.getElementById("sidebar");
  toggleBtn.addEventListener("click", () => {
    sidebar.classList.toggle("visible");
  });
</script>

<script>
document.addEventListener("DOMContentLoaded", function () {
    const table = document.getElementById("sortableTable");
    const headers = table.querySelectorAll("th");
    let sortDirection = 1;
    let activeColumn = -1;

    headers.forEach((header, index) => {
        header.addEventListener("click", () => {
            const tbody = table.tBodies[0];
            const rows = Array.from(tbody.querySelectorAll("tr"));
            
            if (activeColumn === index) {
                sortDirection *= -1; // toggle
            } else {
                sortDirection = 1;
            }
            activeColumn = index;

            // Remove sort classes
            headers.forEach(h => h.classList.remove("asc", "desc"));
            header.classList.add(sortDirection === 1 ? "asc" : "desc");

            rows.sort((a, b) => {
                let aText = a.cells[index].textContent.trim();
                let bText = b.cells[index].textContent.trim();

                // Check if date
                if (/\d{4}-\d{2}-\d{2}/.test(aText) && /\d{4}-\d{2}-\d{2}/.test(bText)) {
                    return (new Date(aText) - new Date(bText)) * sortDirection;
                }

                // Check if number
                let aNum = parseFloat(aText.replace(/[^0-9.\-]/g, ""));
                let bNum = parseFloat(bText.replace(/[^0-9.\-]/g, ""));
                if (!isNaN(aNum) && !isNaN(bNum) && aText !== "" && bText !== "") {
                    return (aNum - bNum) * sortDirection;
                }

                // Default string compare
                return aText.localeCompare(bText, undefined, {numeric: true}) * sortDirection;
            });

            rows.forEach(row => tbody.appendChild(row));
        });
    });
});
</script>
</body>

</html>
