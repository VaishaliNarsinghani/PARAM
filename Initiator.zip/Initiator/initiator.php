<?php include('auth.php'); ?>
<?php
ini_set('memory_limit', '16G'); // or '1G'

// Database connection details
$host = 'localhost';
$db = 'project_db';
$user = 'root';
$pass = '';
$message = "";

try {
    // Create a new PDO instance
    $pdo = new PDO("mysql:host=$host;dbname=$db;charset=utf8", $user, $pass);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

    $results = [];
  
    if ($_SERVER['REQUEST_METHOD'] === 'POST') {
        // Initialize the SQL query for the search functionality
        $query = "SELECT * FROM mis WHERE flag_not_built = 0";
        $params = [];

        // Add filters only if fields are filled
      
        if (!empty($_POST['reference_id'])) {
            $query .= " AND reference_id LIKE ?";
            $params[] = "%" . $_POST['reference_id'] . "%";
        }
        
        if (!empty($_POST['customerName'])) {
            $query .= " AND customerName LIKE ?";
            $params[] = "%" . $_POST['customerName'] . "%";
        }
        if (!empty($_POST['city'])) {
            $query .= " AND address LIKE ?";
            $params[] = "%" . $_POST['city'] . "%";
        }
        if (!empty($_POST['applicationNo'])) {
            $query .= " AND applicationNo LIKE ?";
            $params[] = "%" . $_POST['applicationNo'] . "%";
        }
        if (!empty($_POST['party_name'])) {
            $query .= " AND party_name LIKE ?";
            $params[] = "%" . $_POST['party_name'] . "%";
        }
        
        if (!empty($_POST['branchname'])) {
          $query .= " AND branchname LIKE ?";
          $params[] = "%" . $_POST['branchname'] . "%";
    }
        if (!empty($_POST['caseType'])) {
            $query .= " AND caseType LIKE ?";
            $params[] = "%" . $_POST['caseType'] . "%";
        }

        // Execute the search query
        $stmt = $pdo->prepare($query);
        $stmt->execute($params);
        $results = $stmt->fetchAll(PDO::FETCH_ASSOC);
    }
   
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['not_built'])) {
    $reference_id = $_POST['reference_id'];
    $remark = $_POST['not_built']; // Name of the button pressed

    $updateQuery = "UPDATE mis 
                    SET flag_not_built = 1, 
                        flag_report_submit = 1, 
                        flag_report_to_technical = 1, 
                        flag_technical_to_cso = 1, 
                        flag_cso_submit = 1, 
                        flag_fe_submit = 1,
                        flag_field_engineer = 1,
                        flag_preview_submit = 1,
                        flag_report_preview = 1,
                        not_built_date = CURRENT_DATE,
                        not_built_remarks = ?
                    WHERE reference_id = ?";

    $stmt = $pdo->prepare($updateQuery);
    $stmt->execute([$remark, $reference_id]);

    // Set message for alert
    $message = "Updated '$remark' for Reference ID: $reference_id";

    // Redirect back to the same page to prevent form resubmission
    header("Location: " . $_SERVER['PHP_SELF']);
    exit();
}

} catch (PDOException $e) {
  $message = "Error: " . $e->getMessage();
}
?>
<?php if (!empty($message)): ?>
<script>
    alert("<?= htmlspecialchars_decode(addslashes($message)) ?>");
    window.location.href = window.location.href; // reloads the page
</script>
<?php endif; ?>


<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Magpie Engineering</title>
    <link rel="shortcut icon" href="favicon.ico" type="image/x-icon">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
    <link rel="stylesheet" href="initiator12.css">
  </head>

  <th>
    <button class="toggle-btn" id="toggle-btn">☰</button>
    <div class="container">
      <!-- Sidebar -->

      <div class="sidebar" id="sidebar">
        <div style="display: flex">
          <img class="logo" src="logo.png" alt="" />
          <h1>Magpie Engineering</h1>
        </div>
        <div class="rotating-text">INITIATOR</div>
        <a href="initiator.php" class="active"><i class="fas fa-search icon"></i>Search</a>
             <a href="homeinitiator.php"><i class="fas fa-home icon"></i>Home</a>
        <a href="update.php"><i class="fas fa-home icon"></i>update assignment</a>
        <a href="createsassign.php"><i class="fas fa-file-alt icon"></i> Create New Assignment</a>
        <a href="Createsubs.php"><i class="fas fa-plus-square icon"></i> Create Subsequent</a>
        <a href="Revisereport.php"><i class="fas fa-edit icon"></i> Revise Report</a>
        <a href="not_built.php"><i class="fas fa-edit icon"></i> Cases Not to be Built</a>
        <a href="index.php"><i class="fas fa-sign-out-alt icon"></i>Logout</a>
      </div>

    <!-- Main Content -->
    <div class="content" id="content">
 <div class="search-filters" style="height:300px; padding:10px;">
                  <h2>Search Filters</h2>
                <form id="searchForm" method="POST" action="initiator.php">
                <div class="form-row">
            <input type="text" name="reference_id" placeholder="Reference ID" />
            <input type="text" name="customerName" placeholder="Customer Name" />
          </div>
          <div class="form-row">
            <input type="text" name="city" placeholder="City" />
            <input type="text" name="applicationNo" placeholder="Application No." />
          </div>
          <div class="form-row">
            <input type="text" name="party_name" placeholder="Party Name " />
            <input type="text" name="branchname" placeholder="Branch Name" />
            <input type="text" name="caseType" placeholder="Case Type" />
          </div>
                    <button type="submit"style="background: #4A90E2;">Search</button>
                </form>
        </div>
    </div>
   <?php
    if (!empty($results)): ?>
       <table>       <?php         
         echo "
         <style>
/* Main Content */         
 .content {
  margin: 0; /* Remove conflicting margins */
  padding: 20px;
  animation: fadeIn 1.5s ease-in-out;
  transition: transform 0.3s ease-in-out;
}

table {
  width:75%;
  margin: 0 1% 0 24%; /* Use the same margin in both pages */
  border-collapse: collapse;
  background:rgb(207, 222, 240);
  color: #2C3E50;
  margin-top:3.5%;
  border-radius: 10px;
  overflow: hidden;
  table-layout: fixed; /* Enforce fixed column widths */
  
}

th, td {
  padding:10px;
  border: 1px solid rgba(255, 255, 255, 0.2);
  font-size: 15px;
  word-wrap: break-word; /* Allow wrapping of text */
  white-space: normal; /* Ensure wrapping is allowed */
  min-width:100px; /* Set a minimum width for columns */
}

th {
  font-size: 13px;
  background-color:rgb(102, 146, 190);
   color:white;
  font-weight: bold;
}

table {
    table-layout: fixed; /* Enforces fixed column widths */
}

th, td {
     /* Adjust as needed for your preferred column width */
    word-wrap: break-word; /* Allows text to wrap onto the next line */
    white-space: normal; /* Ensures wrapping is allowed */
}


 tr:nth-child(even) {
   background-color:rgb(234, 236, 250);
 }

 tr:hover {
   background-color:rgb(138, 177, 215);
   color:white;
   font-weight:bolder;
   font-style:italic;
 }
h2{
  margin-left:38% ; 
   font-style: oblique;
 color: #2C3E50;
 }
 button{
    padding:10px 10px;
    background-color:rgb(102, 146, 190);
    color: white;
    text-decoration: none;
    border: none;
    border-radius: 5px;
    cursor: pointer;
    font-size: 16px;
    margin-top:10px;
}

.content {
margin-left: 270px; /* Adjust based on sidebar width */
}


@media (min-width: 1200px) {

@media (max-width: 768px) {
.content {
margin-left: 0px; /* Adjust based on sidebar width */
}
.toggle-btn {
 display: block;
}

.sidebar {
 transform: translateX(-100%);
}

.sidebar.visible {
 transform: translateX(0);
}
 
}

@keyframes slideIn {
from {
 transform: translateX(-100%);
 opacity: 0;
}

to {
 transform: translateX(0);
 opacity: 1;
}
}

@keyframes fadeIn {
from {
 opacity: 0;
}

to {
 opacity: 1;
}
}

.logo {
  width: 50px;
  height:50px;
  padding: 15px;
}
  /* Assign Button Styling */
.upload-button {
background-color:rgb(102, 146, 190);
color: white; /* White text color */
border: 1px solid black; /* Black border */
border-radius: 5px; /* Rounded corners */
padding: 5px 10px; /* Padding for the button */
font-size: 14px; /* Font size */
font-weight: bold; /* Bold text */
text-align: center; /* Center the text */
cursor: pointer; /* Pointer cursor on hover */
display: inline-block; /* Inline-block for proper alignment */
}

.upload-button a {
text-decoration:none; /* Remove underline */
color: white; /* Ensure the link text color is white */
display: inline-block; /* Ensure proper alignment inside the button */
width: 100%; /* Make it span the button */
height: 100%; /* Make it span the button */
}

/* Hover effect for the button */
.upload-button:hover {
background-color: #B0C4DE; /* Gray background on hover */
color: white; /* Maintain white text on hover */
}

.upload-button a:hover {
color: white; /* Ensure link remains white on hover */
}
@media (max-width: 768px) {
  .content {
    margin-left: 0 !important; /* Remove unwanted left margin */
    padding: 10px;
    display: flex;
    justify-content: center;
    align-items: center;
    flex-direction: column;
  }

  table {
    width: 90% !important; /* Ensure the table takes up most of the screen */
    margin: 0 auto !important; /* Center the table horizontally */
    display: block;
    overflow-x: auto; /* Enable horizontal scrolling if needed */
    text-align: center;
  }

  th, td {
    font-size: 14px; /* Adjust font size for better readability */
    padding: 8px;
    word-wrap: break-word;
    white-space: normal;
  }
}
   </style>";?>
   
      <table>
        <tr>
          <th>Reference Number</th>
          <th>Customer Name</th>
          <th>Address</th>
          <th>Customer Mobile Number</th>
          <th>Visit Type</th>
          <th>Party Name</th>
          <th>Branch Name</th>
          <th>Case Type</th>
          <th>Application Number</th>
          <th>Mail ID</th>
          <th>Date</th>
          <th>Not to be Built</th>
        </tr>
        
        <?php foreach ($results as $task): ?>
        <tr>
            <td data-label="Reference Number"><?= htmlspecialchars($task['reference_id']) ?></td>
            <td data-label="Customer Name"><?= htmlspecialchars($task['customerName']) ?></td>
            <td data-label="Address"><?= htmlspecialchars($task['address']) ?></td>
            <td data-label="Customer Mobile Number"><?= htmlspecialchars($task['customerMob']) ?></td>
            <td data-label="Visit Type"><?= htmlspecialchars($task['visitType']) ?></td>
            <td data-label="Bank Name"><?= htmlspecialchars($task['party_name']) ?></td>
            <td data-label="Branch Name"><?= htmlspecialchars($task['branchname']) ?></td>
            <td data-label="Case Type"><?= htmlspecialchars($task['caseType']) ?></td>
            <td data-label="Application Number"><?= htmlspecialchars($task['applicationNo']) ?></td>
            <td data-label="Mail ID"><?= htmlspecialchars($task['initiatorMailId']) ?></td>
            <td data-label="Date"><?= htmlspecialchars($task['initiationDate']) ?></td>
<td data-label="Assign">
    <form method="POST" style="display: flex; flex-direction: column; gap: 5px;">
        <input type="hidden" name="reference_id" value="<?= htmlspecialchars($task['reference_id']) ?>">
        <button type="submit" name="not_built" value="Hold by bank">Hold by bank</button>
        <button type="submit" name="not_built" value="Hold by customer">Hold by customer</button>
        <button type="submit" name="not_built" value="Duplicate Entry">Duplicate Entry</button>
    </form>
</td>

        </tr>
        <?php endforeach; ?>
        </table>
      <?php else: ?>
      <?php endif; ?>
    </div>
  </div>
<script>
  const toggleBtn = document.getElementById("toggle-btn");
  const sidebar = document.getElementById("sidebar");
toggleBtn.addEventListener("click", () => {
  sidebar.classList.toggle("visible");
});
</script>
</body>
</html>
