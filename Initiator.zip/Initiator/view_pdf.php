<?php include('auth.php'); ?>
<?php
// Connect to the database
$host = 'localhost';
$db = 'project_db';
$user = 'root';
$pass = '';
$charset = 'utf8mb4';

$dsn = "mysql:host=$host;dbname=$db;charset=$charset";
$options = [
    PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
    PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
];

try {
    $pdo = new PDO($dsn, $user, $pass, $options);
} catch (PDOException $e) {
    die("DB Connection failed: " . $e->getMessage());
}

// Validate inputs
$ref_id = $_GET['ref_id'] ?? '';
$pdf_number = $_GET['pdf'] ?? '';

if (!preg_match('/^[1-6]$/', $pdf_number)) {
    die("Invalid PDF number.");
}

if (empty($ref_id)) {
    die("Reference ID is missing.");
}

try {
    $stmt = $pdo->prepare("SELECT pdf$pdf_number FROM mis WHERE reference_id = ?");
    $stmt->execute([$ref_id]);
    $row = $stmt->fetch();

    if ($row && !empty($row["pdf$pdf_number"])) {
        header("Content-Type: application/pdf");
        header("Content-Disposition: inline; filename=\"ref_{$ref_id}_pdf{$pdf_number}.pdf\"");
        echo $row["pdf$pdf_number"];
    } else {
        echo "PDF not found.";
    }
} catch (PDOException $e) {
    echo "Error: " . $e->getMessage();
}
   