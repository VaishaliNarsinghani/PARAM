<?php include('auth.php'); ?>
<?php

// Enable error reporting for debugging
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

// Database connection details
$host = 'localhost';
$db = 'project_db';
$user = 'root';
$pass = '';
$message = "";

try {
    $pdo = new PDO("mysql:host=$host;dbname=$db;charset=utf8", $user, $pass);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    

$message = "";
if (isset($_SESSION['form_success'])) {
    $message = $_SESSION['form_success'];
    unset($_SESSION['form_success']);
}

function generateReferenceId(PDO $pdo, string $bankName, string $branchName): string
{
    // Ensure month boundary matches your business timezone (optional)
    // date_default_timezone_set('Asia/Kolkata');

    $yearMonth = date('y/m'); // e.g. "25/09"
    $bankAbbr   = strtoupper(substr(preg_replace('/\s+/', '', $bankName), 0, 3));
    $branchAbbr = strtoupper(substr(preg_replace('/\s+/', '', $branchName), 0, 3));

    // Get the highest sequence used THIS MONTH only
    $stmt = $pdo->prepare("
        SELECT COALESCE(
            MAX(CAST(SUBSTRING_INDEX(TRIM(reference_id), '/', -1) AS UNSIGNED)), 
            0
        ) AS max_seq
        FROM mis
        WHERE SUBSTRING_INDEX(TRIM(reference_id), '/', 2) = :ym
    ");
    $stmt->execute([':ym' => $yearMonth]);
    $lastSeq = (int)$stmt->fetchColumn();

    // Start at 0001 if none this month, else increment
    $nextSeq = $lastSeq + 1;
    $seq4 = str_pad((string)$nextSeq, 4, '0', STR_PAD_LEFT);

    return "{$yearMonth}/{$bankAbbr}/{$branchAbbr}/{$seq4}";
}
    

    // Fetch technical managers for assignment
    $managersQuery = "SELECT coordinator_id, name FROM coordinator_login";
    $managersStmt = $pdo->prepare($managersQuery);
    $managersStmt->execute();
    $managersResult = $managersStmt->fetchAll(PDO::FETCH_ASSOC);

    // Auto-fill branchname and state from login for logged-in user
    $loggedInUser = $_SESSION['username'] ?? '';
    $branchname = '';
    $state = '';
    if ($loggedInUser) {
        $stmt = $pdo->prepare("SELECT location, state FROM login WHERE username = ?");
        $stmt->execute([$loggedInUser]);
        $userRow = $stmt->fetch(PDO::FETCH_ASSOC);
        if ($userRow) {
            $branchname = $userRow['location'];
            $state = $userRow['state'];
        }
    }

    if ($_SERVER['REQUEST_METHOD'] === 'POST') {
        // ✅ Safely handle checkbox and textarea
        $flag_special_submit = isset($_POST['flag_special_submit']) ? 1 : 0;
        $special_text = isset($_POST['special_text']) ? $_POST['special_text'] : null;

        if (isset($_POST['assign_task'])) {
            // Assign task to coordinator
            $selectedEngineerId = $_POST['coordinator_id'] ?? '';

            try {
                $referenceId = generateReferenceId($pdo, 'DefaultBank', 'DefaultBranch');

                $stmt = $pdo->prepare("INSERT INTO mis (coordinator_id, reference_id, assigned_at_coordinator) VALUES (?, ?, CURRENT_TIMESTAMP)");
                $stmt->execute([$selectedEngineerId, $referenceId]);

                $message = 'The assignment has been successfully assigned to the Coordinator Manager with Reference ID: ' . htmlspecialchars($referenceId);
            } catch (PDOException $e) {
                $message = 'Error assigning the task: ' . htmlspecialchars($e->getMessage());
            }
        } else {
           try {
$requiredFields = ['co_applicant_name', 'document_provided_for_valuation', 'state','customerName', 'address', 'customerMob', 'bankName','product','bank_branchname', 'branchname', 'caseType', 'applicationNo', 'initiatorMailId', 'initiationDate', 'initiationTime'];
    foreach ($requiredFields as $field) {
        if (empty($_POST[$field])) {
            throw new Exception("Field '$field' is required.");
        }
    }
$referenceId = generateReferenceId($pdo, $_POST['bankName'], $_POST['branchname']);
$selectedEngineerId = $_POST['coordinator_id'] ?? '';

// Get the "valu" corresponding to the selected bankName

$partyName = $_POST['bankName'] ?? '';  // dropdown selection
$bankN = '';  // this will hold the 'valu' for MIS table

if ($partyName !== '') {
    $stmtValu = $pdo->prepare("SELECT valu FROM mepl_details WHERE bankName = ? LIMIT 1");
    $stmtValu->execute([$partyName]);
    $bankN = $stmtValu->fetchColumn() ?: ''; // fallback empty if not found
}

    // Check files
    $uploadedFiles = [];
    for ($i = 0; $i < 6; $i++) {
        if (isset($_FILES['files']['tmp_name'][$i]) && $_FILES['files']['tmp_name'][$i]) {
            $uploadedFiles[$i] = file_get_contents($_FILES['files']['tmp_name'][$i]);
        } else {
            $uploadedFiles[$i] = null;
        }
    }
error_log("Selected bankName from form: " . $partyName);


    // Debug: Output visitType
    $visitType = 'Fresh';
    error_log("DEBUG: VisitType used = $visitType");
    
    // FIXED: Corrected the INSERT statement to match the number of parameters
    $stmt = $pdo->prepare("INSERT INTO mis 
        (co_applicant_name, document_provided_for_valuation, party_name, state, flag_special_submit, special_text, 
        customerName, address, customerMob, visitType, bankName, product, bank_branchname, branchname, caseType, 
        applicationNo, initiatorMailId, initiationDate, time, coordinator_id, reference_id, assigned_at_coordinator, 
        created_at, updated_at, pdf1, pdf2, pdf3, pdf4, pdf5, pdf6) 
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, CURRENT_TIMESTAMP, NOW(), NOW(), ?, ?, ?, ?, ?, ?)");

    $stmt->execute([
    $_POST['co_applicant_name'],
    $_POST['document_provided_for_valuation'],
    $partyName,   // 👈 dropdown selection stored in party_name
    $state,
    $flag_special_submit,
    $special_text,
    $_POST['customerName'],
    $_POST['address'],
    $_POST['customerMob'],
    $visitType,
    $bankN,       // 👈 valu from mepl_details goes into bankName
    $_POST['product'],
    $_POST['bank_branchname'],
    $_POST['branchname'],
    $_POST['caseType'],
    $_POST['applicationNo'],
    $_POST['initiatorMailId'],
    $_POST['initiationDate'],
    $_POST['initiationTime'],
    $selectedEngineerId,
    $referenceId,
    $uploadedFiles[0],
    $uploadedFiles[1],
    $uploadedFiles[2],
    $uploadedFiles[3],
    $uploadedFiles[4],
    $uploadedFiles[5]
]);

    $_SESSION['form_success'] = "Data inserted successfully with Reference ID: " . htmlspecialchars($referenceId);
    header("Location: createsassign.php");
    exit;

} catch (Exception $e) {
    $message = "Error: " . htmlspecialchars($e->getMessage());
    error_log("ERROR: " . $e->getMessage());
}
        }
    }
} catch (PDOException $e) {
    $message = "Database Error: " . htmlspecialchars($e->getMessage());
} catch (Exception $e) {
    $message = "Error: " . htmlspecialchars($e->getMessage());
}
?>

<!-- JavaScript for Alert -->
<script>
    <?php if (!empty($message)): ?>
    alert("<?= htmlspecialchars_decode(addslashes($message)) ?>");
    <?php endif; ?>
</script>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Magpie Engineering</title>
    <link rel="shortcut icon" href="favicon.ico" type="image/x-icon">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
    <link rel="stylesheet" href="Createassign11.css">
</head>
<body>
    <button class="toggle-btn" id="toggle-btn">☰</button>
    <div class="container">
        <!-- Sidebar -->
        <div class="sidebar" id="sidebar">
            <div style="display: flex">
                <img class="logo" src="logo.png" alt="" />
                <h1>Magpie Engineering</h1>
            </div>
            <div class="rotating-text">INITIATOR</div>
            <a href="initiator.php"><i class="fas fa-search icon"></i>Search</a>
                 <a href="homeinitiator.php"><i class="fas fa-home icon"></i>Home</a>
        <a href="update.php"><i class="fas fa-home icon"></i>update assignment</a>
            <a href="createsassign.php"class="active"><i class="fas fa-file-alt icon"></i> Create New Assignment</a>
            <a href="Createsubs.php"><i class="fas fa-plus-square icon"></i> Create Subsequent</a>
            <a href="Revisereport.php"><i class="fas fa-edit icon"></i> Revise Report</a>
        <a href="not_built.php"><i class="fas fa-edit icon"></i> Cases Not to be Built</a>

            <a href="index.php"><i class="fas fa-sign-out-alt icon"></i>Logout</a>
        </div>
        <!-- Main Content -->
        <div class="content" id="content">
            <div class="search-filters">
                <h2 id="assignment">ASSIGNMENT DETAILS</h2>
                <form id="assignmentForm" method="POST" action="createsassign.php" enctype="multipart/form-data">
                    <div class="form-group">
                        <label for="customerName">Customer Name :</label>
                        <input type="text" name="customerName" placeholder="Customer Name" required />
                    </div>
                    <div class="form-group">
                        <label for="Co-Applicant Name">Co-Applicant Name:</label>
                        <input type="text" name="co_applicant_name" placeholder="Customer Co-Applicant Name" required />
                      </div>
                    <div class="form-group">
                        <label for="address">Address :</label>
                        <input type="text" name="address" placeholder="Address" required />
                    </div>
                    <div class="form-group">
                        <label for="customerMob">Mobile Number:</label>
                        <input type="tel" name="customerMob" placeholder="Customer Mobile Number" required />
                    </div>
                    <!-- Bank Name Dropdown -->
<div class="form-group">
    <label for="bankName">Bank Name</label>
    <select name="bankName" id="bankName" required>
        <option value="">Select Bank</option>
        <?php
        $stmt = $pdo->query("SELECT DISTINCT bankName FROM mepl_details");
        while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
            echo "<option value='" . htmlspecialchars($row['bankName']) . "'>" . htmlspecialchars($row['bankName']) . "</option>";
        }
        ?>
    </select>
</div>

<!-- Bank Branch Name Dropdown -->
<div class="form-group">
    <label for="bank_branchname">Bank Branch Name</label>
    <select name="bank_branchname" id="bank_branchname" required>
        <option value="">Select Branch</option>
        <?php
        $stmt = $pdo->query("SELECT DISTINCT bank_branchname FROM mepl_details");
        while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
            $branch = htmlspecialchars($row['bank_branchname']);
            $selected = ($branch === 'INDORE') ? 'selected' : '';
            echo "<option value='{$branch}' {$selected}>{$branch}</option>";
        }
        ?>
    </select>
</div>

<!-- Product Dropdown -->
<div class="form-group">
    <label for="product">Product</label>
    <select name="product" id="product" required>
        <option value="">Select Product</option>
        <?php
        $stmt = $pdo->query("SELECT DISTINCT product FROM mepl_details");
        while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
            $product = htmlspecialchars($row['product']);
            $selected = ($product === 'NA') ? 'selected' : '';
            echo "<option value='{$product}' {$selected}>{$product}</option>";
        }
        ?>
    </select>
</div>




                    <div class="form-group">
                        <label for="caseType">Case Type:</label>
                        <select id="caseType" name="caseType" required>
                            <option value="">Select</option>
                          <option value="Home Loan">Home Loan</option>
                            <option value="Property Loan">Property Loan</option>
                            <option value="Land Loan">Land Loan</option>
                            <option value="APF NEW">APF NEW</option>
<option value="APF SUBSQ.">APF SUBSQ.</option>
<option value="AUDIT">AUDIT</option>
<option value="BT">BT</option>
<option value="BT + TOPUP (LAP)">BT + TOPUP (LAP)</option>
<option value="BT EXTENSION">BT EXTENSION</option>
<option value="BT TOP UP">BT TOP UP</option>
<option value="BUILDER PURCHASE">BUILDER PURCHASE</option>
<option value="COMMERCIAL PURCHASE">COMMERCIAL PURCHASE</option>
<option value="CONSTRUCTION">CONSTRUCTION</option>
<option value="DOD">DOD</option>
<option value="EBL">EBL</option>
<option value="FCRB">FCRB</option>
<option value="FLAT PURCHASE">FLAT PURCHASE</option>
<option value="FRESH">FRESH</option>
<option value="FRESH LAP">FRESH LAP</option>
<option value="FRESH P+C">FRESH P+C</option>
<option value="HE">HE</option>
<option value="HE LAP">HE LAP</option>
<option value="HFCHL">HFCHL</option>
<option value="HL">HL</option>
<option value="HL BT">HL BT</option>
<option value="HL BT TOPUP">HL BT TOPUP</option>
<option value="HL CONSTRN.">HL CONSTRN.</option>
<option value="HL HFC">HL HFC</option>
<option value="HL HOME IMPROVEMENT">HL HOME IMPROVEMENT</option>
<option value="HL P+C">HL P+C</option>
<option value="HL PURCHASE">HL PURCHASE</option>
<option value="HL SELF CONSTRUCTION">HL SELF CONSTRUCTION</option>
<option value="HL SWARAJ">HL SWARAJ</option>
<option value="HOME COMPOSITE">HOME COMPOSITE</option>
<option value="HOME CONSTRUCTION">HOME CONSTRUCTION</option>
<option value="HOME EQUITY LOAN">HOME EQUITY LOAN</option>
<option value="HOME PURCHASE">HOME PURCHASE</option>
<option value="HOUSE PURCHASE">HOUSE PURCHASE</option>
<option value="INTERNAL BHFL TOP UP">INTERNAL BHFL TOP UP</option>
<option value="LAP">LAP</option>
<option value="LAP COMMERCIAL">LAP COMMERCIAL</option>
<option value="LAP TOP UP">LAP TOP UP</option>
<option value="LAP TOPUP">LAP TOPUP</option>
<option value="MICRO LAP">MICRO LAP</option>
<option value="MSME">MSME</option>
<option value="NHL">NHL</option>
<option value="NPA">NPA</option>
<option value="NRP">NRP</option>
<option value="P+C">P+C</option>
<option value="PLI">PLI</option>
<option value="PLOT + CONST">PLOT + CONST</option>
<option value="PLOT LOAN">PLOT LOAN</option>
<option value="Plot Purchase">Plot Purchase</option>
<option value="PURCHASE">PURCHASE</option>
<option value="RE VISIT">RE VISIT</option>
<option value="RESALE">RESALE</option>
<option value="RESALE PURCHASE">RESALE PURCHASE</option>
<option value="RESI LAP">RESI LAP</option>
<option value="RESIDENTIAL PLOT + CONSTRUCTION LOAN">RESIDENTIAL PLOT + CONSTRUCTION LOAN</option>
<option value="RHPL">RHPL</option>
<option value="RPL">RPL</option>
<option value="RSCL">RSCL</option>
<option value="SAMMAAN">SAMMAAN</option>
<option value="SBL">SBL</option>
<option value="SELF CONSTRUCTION">SELF CONSTRUCTION</option>
<option value="SOCP">SOCP</option>
<option value="SORP">SORP</option>
<option value="ST LAP">ST LAP</option>
<option value="SUBSEQUENT">SUBSEQUENT</option>
<option value="TL">TL</option>
<option value="TOP UP">TOP UP</option>
<option value="HFCHL">HFCHL</option>            
                        </select>
                    </div>
                    <br>
<div class="form-group">
  <label class="checkbox-container">
    <input type="checkbox" id="flag_special_submit" name="flag_special_submit" onchange="toggleSpecialText()">
    <span class="checkmark"></span>
    <span class="label-text">Special Fees Applicable</span>
  </label>
</div>

<div class="form-group" id="specialTextGroup" style="display: none;">
  <label for="special_text">Enter Remarks on Special Fess Applicable :</label>
  <textarea name="special_text" id="special_text" rows="3" placeholder="Enter Remarks on Special Fess Applicable...."></textarea>
</div>
<br>


                    <div class="form-group">
                        <label for="applicationNo">Application Number:</label>
                        <input type="text" name="applicationNo" placeholder="Application Number" required />
                    </div>
                    <div class="form-group">
                        <label for="initiatorMailId">Initiator Mail ID:</label>
                        <input type="email" name="initiatorMailId" placeholder="Initiator Mail ID" required />
                    </div>
                    <div class="form-group">
                        <label for="document provided for valuation">Document Provided For Valuation:</label>
                        <input type="text" name="document provided for valuation" placeholder="Enter Document Provided For Valuation" required />
                      </div>
                    <div style="margin-left:2px; width:28%;" class="form-group">
                        <label for="initiationDate">Initiation Date:</label>
                        <input type="date" name="initiationDate" required />
                    </div>
                    <div style=" width:28%;margin-left:2px;" class="form-group">
                        <label for="initiationTime">Initiation Time:</label>
                        <input type="time" name="initiationTime" required />
                    </div>
                    <input type="hidden" name="state" value="<?= htmlspecialchars($state) ?>">
<input type="hidden" name="branchname" value="<?= htmlspecialchars($branchname) ?>">
<input type="hidden" id="party_name" name="party_name">


<div class="form-group">
  <label for="uploadDocuments">Upload Documents:</label>
  <input type="file" id="fileInput" name="files[]" multiple required>
  <small style="color: gray;">(Maximum 6 files allowed — any format)</small>
  <div id="fileList" style="margin-top: 10px;"></div>
</div>



                      <!-- Dropdown for Assigning to Technical Manager -->
<label for="coordinator_id"style="margin-left:20px;">Select Coordinator :</label>
<select name="coordinator_id" id="coordinator_id" required>
    <option value="" disabled selected>Select a Coordinator</option>
    <?php foreach ($managersResult as $manager): ?>
        <option value="<?= htmlspecialchars($manager['coordinator_id']) ?>">            
            <?= htmlspecialchars($manager['name']) ?>
        </option>
    <?php endforeach; ?>
</select>
<!-- Submit Button -->
                    <button type="submit" >Create Assignment</button>

                </form>
            </div>
        </div>
    </div>
    
<script>
    <?php if (!empty($message)): ?>
    alert("<?= htmlspecialchars_decode(addslashes($message)) ?>");
    <?php endif; ?>
</script>

<script>
function updatePartyName() {
    const bankDropdown = document.getElementById('bankName');
    const selectedText = bankDropdown.options[bankDropdown.selectedIndex].text;
    document.getElementById('party_name').value = selectedText;
}
 
</script>

   <script>
  document.getElementById('fileInput').addEventListener('change', function () {
    const fileList = document.getElementById('fileList');
    const files = this.files;

    fileList.innerHTML = ''; // Clear previous list

    if (files.length > 6) {
      alert("You can upload a maximum of 6 files.");
      this.value = ''; // Reset input
      return;
    }

    // Display file names
    for (let i = 0; i < files.length; i++) {
      const fileItem = document.createElement('div');
      fileItem.textContent = (i + 1) + '. ' + files[i].name;
      fileList.appendChild(fileItem);
    }
  });
 

function toggleSpecialText() {
  const checkbox = document.getElementById('flag_special_submit');
  const textGroup = document.getElementById('specialTextGroup');
  textGroup.style.display = checkbox.checked ? 'block' : 'none';
}

function updatePartyName() {
    const bankDropdown = document.getElementById('bankName');
    const selectedOption = bankDropdown.options[bankDropdown.selectedIndex];
    const partyName = selectedOption.text;
    document.getElementById('party_name').value = partyName;
}

</script>
    <script>
        const toggleBtn = document.getElementById("toggle-btn");
        const sidebar = document.getElementById("sidebar");

        // Toggle Sidebar
        toggleBtn.addEventListener("click", () => {
            sidebar.classList.toggle("visible");
        });
    </script>
</body>
</html>
