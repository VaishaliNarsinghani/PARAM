<?php include('auth.php'); ?>
<?php
// Database connection details
$host = 'localhost';
$db = 'project_db';
$user = 'root';
$pass = '';
try {
    // Create a new PDO instance
    $pdo = new PDO("mysql:host=$host;dbname=$db;charset=utf8", $user, $pass);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

} catch (PDOException $e) {
    echo "Error: " . $e->getMessage();
}
?>
<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Magpie Engineering</title>
    <link rel="shortcut icon" href="favicon.ico" type="image/x-icon">
    <link rel="stylesheet" href="homeinitiator1.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
  </head>

  <div>
    <button class="toggle-btn" id="toggle-btn">☰</button>
    <classds="container">
      <!-- Sidebar -->

      <div class="sidebar" id="sidebar">
        <div style="display: flex">
          <img class="logo" src="logo.png" alt="" />
          <h1>Magpie Engineering</h1>
        </div>
        <div class="rotating-text">INITIATOR</div>
        <a href="initiator.php"><i class="fas fa-search icon"></i>Search</a>
        <a href="homeinitiator.php"class="active"><i class="fas fa-home icon"></i>Home</a>
        <a href="update.php"><i class="fas fa-home icon"></i>update assignment</a>
        <a href="createsassign.php"><i class="fas fa-file-alt icon"></i> Create New Assignment</a>
        <a href="Createsubs.php"><i class="fas fa-plus-square icon"></i> Create Subsequent</a>
        <a href="Revisereport.php"><i class="fas fa-edit icon"></i> Revise Report</a>
        <a href="not_built.php"><i class="fas fa-edit icon"></i> Cases Not to be Built</a>

        <a href="index.php"><i class="fas fa-sign-out-alt icon"></i>Logout</a>
      </div>
      <p class="time" id="time">
            <span>Current Time:</span> Loading...
        </p>
        <p class="date">
            <span>Current Date:</span> <?php echo date("l, F j, Y"); ?>
        </p>
        <p class="day">
            <span>Current Day:</span> <?php echo date("l"); ?>
        </p>

        <!-- Creative Status Box for Total and Pending Assignments -->
        <div class="status-box">
            <h2>Assignments Status</h2>
            <div class="status-details">
                <div>
                    <span>Total:</span>
                    <span class="value total">20</span>
                </div>
                <div>
                    <span>Pending:</span>
                    <span class="value pending">5</span>
                </div>
            </div>
        </div>
    </div>
    <script>
      const toggleBtn = document.getElementById("toggle-btn");
      const sidebar = document.getElementById("sidebar");

      // Toggle Sidebar
      toggleBtn.addEventListener("click", () => {
        sidebar.classList.toggle("visible");
      });

      function search() {
        window.location.href = "initiator.php";
      }
       // Function to update the current time
      function updateTime() {
        const timeElement = document.getElementById("time");
        const currentTime = new Date();

        let hours = currentTime.getHours();
        let minutes = currentTime.getMinutes();
        let seconds = currentTime.getSeconds();
        const ampm = hours >= 12 ? "PM" : "AM";

        // Convert to 12-hour format
        hours = hours % 12 || 12;
        minutes = minutes < 10 ? "0" + minutes : minutes;
        seconds = seconds < 10 ? "0" + seconds : seconds;

        const timeString = `${hours}:${minutes}:${seconds} ${ampm}`;
        timeElement.innerHTML = `<span>Current Time:</span> ${timeString}`;
      }

      // Update time every second
      setInterval(updateTime, 1000);

      // Initial time update
      updateTime();
    </script>
  </body>
</html>