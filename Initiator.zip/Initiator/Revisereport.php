<?php 
include('auth.php');
ini_set('memory_limit', '8G'); // or '1G'
$successMessage = '';
if (isset($_SESSION['success_message'])) {
    $successMessage = $_SESSION['success_message'];
    unset($_SESSION['success_message']); // remove it after displaying
}

// Database connection details
$host = 'localhost';
$db = 'project_db';
$user = 'root';
$pass = '';
$message = "";

try {
    // Create a new PDO instance
    $pdo = new PDO("mysql:host=$host;dbname=$db;charset=utf8", $user, $pass);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

    // Ensure the user is logged in
    if (!isset($_SESSION['username'])) {
        die("Access denied. Please log in.");
    }

    $username = $_SESSION['username'];

    // Fetch branches assigned to the user
    $stmt = $pdo->prepare("SELECT branch1, branch2, branch3, branch4, branch5 FROM login WHERE username = ?");
    $stmt->execute([$username]);
    $userData = $stmt->fetch(PDO::FETCH_ASSOC);

    if (!$userData) {
        die("User not found.");
    }

    $branches = array_filter([
        $userData['branch1'], 
        $userData['branch2'], 
        $userData['branch3'], 
        $userData['branch4'], 
        $userData['branch5']
    ]);

    if (empty($branches)) {
        die("No branches assigned.");
    }

    $results = [];

    // Handle search
    if ($_SERVER['REQUEST_METHOD'] === 'POST' && !isset($_POST['assign_task'])) {
        $query = "SELECT * FROM mis WHERE 1=1";
        $params = [];

        $searchFields = [
            'reference_id' => 'reference_id',
            'customerName' => 'customerName',
            'city' => 'address',
            'applicationNo' => 'applicationNo',
            'bankName' => 'bankName',
            'branchname' => 'branchname',
            'caseType' => 'caseType'
        ];

        foreach ($searchFields as $postField => $dbField) {
            if (!empty($_POST[$postField])) {
                $query .= " AND $dbField LIKE ?";
                $params[] = "%" . $_POST[$postField] . "%";
            }
        }

        $stmt = $pdo->prepare($query);
        $stmt->execute($params);
        $results = $stmt->fetchAll(PDO::FETCH_ASSOC);
    }

    // Fetch technical managers
    $managersStmt = $pdo->prepare("SELECT technical_manager_id, name FROM technical_login");
    $managersStmt->execute();
    $managersResult = $managersStmt->fetchAll(PDO::FETCH_ASSOC);

    // View case by reference ID
    $viewData = null;
    if (isset($_GET['view_id'])) {
        $stmt = $pdo->prepare("SELECT * FROM mis WHERE reference_id = ? AND flag_not_built = 0 ORDER BY initiationDate DESC");
        $stmt->execute([$_GET['view_id']]);
        $viewData = $stmt->fetch(PDO::FETCH_ASSOC);
    }

    // Handle task assignment (update)
    if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['assign_task'])) {
        $requiredFields = [
            'customerName', 'address', 'customerMob', 'visitType', 
            'bankName', 'branchname', 'caseType', 'applicationNo',
            'initiatorMailId', 'initiationDate', 'technical_manager_id'
        ];

        foreach ($requiredFields as $field) {
            if (empty($_POST[$field])) {
                die("Required field '$field' is missing.");
            }
        }

        $uploadDir = "uploads/";
        if (!is_dir($uploadDir)) {
            mkdir($uploadDir, 0755, true);
        }

        $pdfPaths = ['', '', '', '', '', ''];
        for ($i = 0; $i < 6; $i++) {
            $fieldName = 'pdfs_' . ($i + 1);
            if (isset($_FILES[$fieldName]) && $_FILES[$fieldName]['error'] === UPLOAD_ERR_OK) {
                $fileExt = pathinfo($_FILES[$fieldName]['name'], PATHINFO_EXTENSION);
                $fileName = uniqid() . '.' . $fileExt;
                $targetPath = $uploadDir . $fileName;

                if (move_uploaded_file($_FILES[$fieldName]['tmp_name'], $targetPath)) {
                    $pdfPaths[$i] = $targetPath;
                }
            } elseif (isset($_POST['existing_pdf_' . ($i + 1)])) {
                $pdfPaths[$i] = $_POST['existing_pdf_' . ($i + 1)];
            }
        }

        if (empty($_POST['reference_id'])) {
            die("Reference ID is missing.");
        }
$stmt = $pdo->prepare("UPDATE mis SET 
    customerName = ?, 
    address = ?, 
    customerMob = ?, 
    visitType = ?, 
    bankName = ?, 
    branchname = ?, 
    caseType = ?, 
    applicationNo = ?, 
    initiatorMailId = ?, 
    initiationDate = ?, 
    time = ?, 
    technical_manager_id = ?, 
    pdf1 = ?, 
    pdf2 = ?, 
    pdf3 = ?, 
    pdf4 = ?, 
    pdf5 = ?, 
    pdf6 = ?,
    flag_technical_to_cso = '0',
    flag_cso_submit = '0',
    flag_revise_times = flag_revise_times + 1,
    revised_at = NOW()
WHERE reference_id = ?");



$stmt->execute([
    $_POST['customerName'],
    $_POST['address'],
    $_POST['customerMob'],
    $_POST['visitType'],
    $_POST['bankName'],
    $_POST['branchname'],
    $_POST['caseType'],
    $_POST['applicationNo'],
    $_POST['initiatorMailId'],
    $_POST['initiationDate'],
    $_POST['initiationTime'] ?? date('H:i:s'),
    $_POST['technical_manager_id'],
    $pdfPaths[0],
    $pdfPaths[1],
    $pdfPaths[2],
    $pdfPaths[3],
    $pdfPaths[4],
    $pdfPaths[5],
    $_POST['reference_id']
]);

$_SESSION['success_message'] = "Task assigned successfully to Technical Manager!";
header("Location: Revisereport.php");
exit();

    }

} catch (PDOException $e) {
    $message = "Database Error: " . $e->getMessage();
} catch (Exception $e) {
    $message = "Error: " . $e->getMessage();
}
?>
 
<!-- JavaScript for Alert -->
<script>
<?php if (!empty($successMessage)): ?>
alert("<?= htmlspecialchars_decode(addslashes($successMessage)) ?>");
<?php endif; ?>
</script>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Magpie Engineering</title>
<link rel="shortcut icon" href="favicon.ico" type="image/x-icon">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
<link rel="stylesheet" href="Revisereport10.css">
</head>
<body>
<button class="toggle-btn" id="toggle-btn">☰</button>
<div class="container">
<!-- Sidebar -->
<div class="sidebar" id="sidebar">
<div style="display: flex;">
  <img class="logo" src="logo.png" alt="">
  <h1>Magpie Engineering</h1>
</div>
<div class="rotating-text">INITIATOR</div>
<a href="initiator.php"><i class="fas fa-search icon"></i>Search</a>
           
        <a href="homeinitiator.php"><i class="fas fa-home icon"></i>Home</a>
        <a href="update.php"><i class="fas fa-home icon"></i>update assignment</a>
        <a href="createsassign.php"><i class="fas fa-file-alt icon"></i> Create New Assignment</a>
        <a href="Createsubs.php"><i class="fas fa-plus-square icon"></i> Create Subsequent</a>
        <a href="Revisereport.php" class="active"><i class="fas fa-edit icon"></i> Revise Report</a>
        <a href="not_built.php"><i class="fas fa-edit icon"></i> Cases Not to be Built</a>
        <a href="index.php"><i class="fas fa-sign-out-alt icon"></i>Logout</a>
</div>

<!-- Main Content -->
<div class="content" id="content">
<!-- Search Filters -->
<div class="search-filters">
  <h2>Search Filters</h2>
  <form id="searchForm" method="POST" action="Revisereport.php">
    <div class="form-row">
      <input type="text" name="reference_id" placeholder="Reference ID" />
      <input type="text" name="customerName" placeholder="Customer Name" />
    </div>
    <div class="form-row">
      <input type="text" name="city" placeholder="City" />
      <input type="text" name="applicationNo" placeholder="Application No." />
    </div>
    <div class="form-row">
      <input type="text" name="bankName" placeholder="Party Name " />
      <input type="text" name="branchname" placeholder="Branch Name" />
      <input type="text" name="caseType" placeholder="Case Type" />
    </div>
    <button type="submit"style="background: #4A90E2;">Search For Revise Report</button>
  </form>
</div>

<?php echo "<style>
          /* Main Content */
 .content {
  margin: 0; /* Remove conflicting margins */
  padding: 20px;
  animation: fadeIn 1.5s ease-in-out;
  transition: transform 0.3s ease-in-out;
}

table {
  width: 100%;
  margin: 0 1% 0 1%; /* Use the same margin in both pages */
  border-collapse: collapse;
  background:rgb(207, 222, 240);
  color: #2C3E50;
  border-radius: 10px;
  overflow: hidden;
  table-layout: fixed; /* Enforce fixed column widths */
  
}

th, td {
  padding: 12px;
  text-align: left;
  border: 1px solid rgba(255, 255, 255, 0.2);
  font-size: 15px;
  word-wrap: break-word; /* Allow wrapping of text */
  white-space: normal; /* Ensure wrapping is allowed */
  min-width: 100px; /* Set a minimum width for columns */
}

th {
  font-size: 13px;
  background-color:rgb(102, 146, 190);
   color:white;
  font-weight: bold;
}

table {
    table-layout: fixed; /* Enforces fixed column widths */
}

th, td {
     /* Adjust as needed for your preferred column width */
    word-wrap: break-word; /* Allows text to wrap onto the next line */
    white-space: normal; /* Ensures wrapping is allowed */
}


 tr:nth-child(even) {
   background-color:rgb(234, 236, 250);
 }

 tr:hover {
   background-color:rgb(138, 177, 215);
   color:white;
   font-weight:bolder;
   font-style:italic;
 }
h2{
  margin-left:32% ; 
   font-style: oblique;
 color: #2C3E50;
 }
 button{
    padding:10px 10px;
    background-color: #005f8a;
    color: white;
    text-decoration: none;
    border: none;
    border-radius: 5px;
    cursor: pointer;
    font-size: 16px;
    margin-top:10px;
}

@media (max-width: 768px) {
  

.content {
  margin-left: 0;
}

.search-filters input,
.search-filters button {
  width: 90%;
}
}
.content {
margin-left: 270px; /* Adjust based on sidebar width */
}


@media (min-width: 1200px) {

@media (max-width: 768px) {
.toggle-btn {
 display: block;
}

.sidebar {
 transform: translateX(-100%);
}

.sidebar.visible {
 transform: translateX(0);
}

.content {
 margin-left: 0;
 margin:0;

}

.search-filters input,
.search-filters button {
 width: 90%;
}
}

@keyframes slideIn {
from {
 transform: translateX(-100%);
 opacity: 0;
}

to {
 transform: translateX(0);
 opacity: 1;
}
}

@keyframes fadeIn {
from {
 opacity: 0;
}

to {
 opacity: 1;
}
}

.logo {
  width: 50px;
  height:50px;
  padding: 15px;
}
@media (max-width: 768px) {
  .toggle-btn {
    display: block;
  }

  .sidebar {
    transform: translateX(-100%);
  }

  .sidebar.visible {
    transform: translateX(0);
  }

  .content {
    margin-left: 0;

  }

  .search-filters input,
  .search-filters button {
    width: 90%;
  }
}
   </style>";

   if (!empty($results)): ?>
  <table id="sortableTable">
      <thead>
   <?php echo "<h2>Customer Information Table</h2>";?>
      <tr >
          <th >Reference Number</th>
          <th>Customer Name</th>
          <th>Address</th>
          <th>Customer Mobile Number</th>
          <th>Visit Type</th>
          <th>Party Name </th>
          <th>Branch Name</th>
          <th>Case Type</th>
          <th>Application Number</th>
          <th>Date</th>
          <th>View</th>
      </tr>
   </thead>
      <?php foreach ($results as $row): ?>
      <tr>
          <td><?= htmlspecialchars($row['reference_id']) ?></td>
          <td><?= htmlspecialchars($row['customerName']) ?></td>
          <td><?= htmlspecialchars($row['address']) ?></td>
          <td><?= htmlspecialchars($row['customerMob']) ?></td>
          <td><?= htmlspecialchars($row['visitType']) ?></td>
          <td><?= htmlspecialchars($row['bankName']) ?></td>
          <td><?= htmlspecialchars($row['branchname']) ?></td>
          <td><?= htmlspecialchars($row['caseType']) ?></td>
          <td><?= htmlspecialchars($row['applicationNo']) ?></td>
          <td><?= htmlspecialchars($row['initiationDate']) ?></td>
          <td ><button style="text-decoration:none; color:white;"><a href="Revisereport.php?view_id=<?= $row['reference_id'] ?>">View</a></button></td>
      </tr>
      
      <?php endforeach; ?>
       
  </table>
 
<?php endif; ?>
<?php if ($viewData): ?>
    <h3>Revise Report</h3>
    <form action="Revisereport.php" method="POST" enctype="multipart/form-data">
        <table>
            <tr>
                <th>Field</th>
                <th>Old Value</th>
                <th>New Value</th>
            </tr>
            <tr>
        <td>Reference ID</td>
        <td><?= htmlspecialchars($viewData['reference_id']) ?></td>
<input type="hidden" name="reference_id" value="<?= htmlspecialchars($viewData['reference_id']) ?>">

    </tr>
    <tr>
        <td >Customer Name</td>
        <td><?= htmlspecialchars($viewData['customerName']) ?></td>
        <td><input type="text" name="customerName" value="<?= htmlspecialchars($viewData['customerName']) ?>"></td>
    </tr>
    <tr>
        <td>Address</td>
        <td><?= htmlspecialchars($viewData['address']) ?></td>
        <td><input type="text" name="address" value="<?= htmlspecialchars($viewData['address']) ?>"></td>
    </tr>
    <tr>
        <td >Customer Mobile</td>
        <td><?= htmlspecialchars($viewData['customerMob']) ?></td>
        <td><input  type="text" name="customerMob" value="<?= htmlspecialchars($viewData['customerMob']) ?>"></td>
    </tr>
    <tr>
        <td>Visit Type</td>
        <td><?= htmlspecialchars($viewData['visitType']) ?></td>
        <td><input type="text" name="visitType" value="<?= htmlspecialchars($viewData['visitType']) ?>"></td>
    </tr>
    <tr>
        <td>Party Name </td>
        <td><?= htmlspecialchars($viewData['bankName']) ?></td>
        <td><input type="text" name="bankName" value="<?= htmlspecialchars($viewData['bankName']) ?>"></td>
    </tr>
    <tr>
        <td>Branch Name</td>
        <td><?= htmlspecialchars($viewData['branchname']) ?></td>
        <td><input type="text" name="branchname" value="<?= htmlspecialchars($viewData['branchname']) ?>"></td>
    </tr>
    <tr>
        <td>Case Type</td>
        <td><?= htmlspecialchars($viewData['caseType']) ?></td>
        <td><input type="text" name="caseType" value="<?= htmlspecialchars($viewData['caseType']) ?>"></td>
    </tr>
    <tr>
        <td>Application Number</td>
        <td><?= htmlspecialchars($viewData['applicationNo']) ?></td>
        <td><input type="text" name="applicationNo" value="<?= htmlspecialchars($viewData['applicationNo']) ?>"></td>
    </tr>
    <tr>
        <td>Initiator Mail ID</td>
        <td><?= htmlspecialchars($viewData['initiatorMailId']) ?></td>
        <td><input type="text" name="initiatorMailId" value="<?= htmlspecialchars($viewData['initiatorMailId']) ?>"></td>
    </tr>
    <tr>
        <td>Initiation Date</td>
        <td><?= htmlspecialchars($viewData['initiationDate']) ?></td>
        <td><input type="date" name="initiationDate" value="<?= htmlspecialchars($viewData['initiationDate']) ?>"></td>
    </tr>
    <tr>
    <td>Time</td>
        <td><?= htmlspecialchars($viewData['time']) ?></td>
        <td><input type="time" name="initiationTime" value="<?= htmlspecialchars($viewData['time']) ?>"></td>
    </tr>


    <?php for ($i = 1; $i <= 6; $i++): ?>
    <tr>
        <td>PDF <?= $i ?></td>

        <!-- First display column: Link to view PDF -->
        <td>
            <?php if (!empty($viewData["pdf$i"])): ?>
                <a href="view_pdf.php?ref_id=<?= urlencode($viewData['reference_id']) ?>&pdf=<?= $i ?>" target="_blank">
                    View PDF
                </a>
            <?php else: ?>
                Not uploaded
            <?php endif; ?>
        </td>

        <!-- Second display column: Display PDF directly -->
        <td>
            <?php if (!empty($viewData["pdf$i"])): ?>
                <embed src="view_pdf.php?ref_id=<?= urlencode($viewData['reference_id']) ?>&pdf=<?= $i ?>" type="application/pdf" width="100%" height="400px">
            <?php else: ?>
                Not uploaded
            <?php endif; ?>
        </td>

        <!-- File input for uploading new PDF -->
        <td>
            <input type="file" name="new_pdfs[]" accept="application/pdf">
        </td>
    </tr>
<?php endfor; ?>


</table>
<!-- Dropdown for Assigning to Technical Manager -->
<label for="technical_manager_id"style="margin-left:20px;">Select Technical Manager:</label>
<select name="technical_manager_id" id="technical_manager_id" required>
    <option value="" disabled selected>Select a manager</option>
    <?php foreach ($managersResult as $manager): ?>
        <option value="<?= htmlspecialchars($manager['technical_manager_id']) ?>">            
            <?= htmlspecialchars($manager['name']) ?>
        </option>
    <?php endforeach; ?>
</select>
<!-- Submit Button -->
<button type="submit" name="assign_task"style="margin-left:10%;padding:15px;">Assign To Technical Manager</button>
</form>
      <?php endif; ?>
    </div>
  </div>
  <script>
    const toggleBtn = document.getElementById("toggle-btn");
    const sidebar = document.getElementById("sidebar");
    toggleBtn.addEventListener("click", () => {
      sidebar.classList.toggle("visible");
    });
  </script>
  <script>
document.addEventListener("DOMContentLoaded", function () {
    const table = document.getElementById("sortableTable");
    const headers = table.querySelectorAll("th");
    let sortDirection = 1;
    let activeColumn = -1;

    headers.forEach((header, index) => {
        header.addEventListener("click", () => {
            const tbody = table.tBodies[0];
            const rows = Array.from(tbody.querySelectorAll("tr"));
            
            if (activeColumn === index) {
                sortDirection *= -1; // toggle
            } else {
                sortDirection = 1;
            }
            activeColumn = index;

            // Remove sort classes
            headers.forEach(h => h.classList.remove("asc", "desc"));
            header.classList.add(sortDirection === 1 ? "asc" : "desc");

            rows.sort((a, b) => {
                let aText = a.cells[index].textContent.trim();
                let bText = b.cells[index].textContent.trim();

                // Check if date
                if (/\d{4}-\d{2}-\d{2}/.test(aText) && /\d{4}-\d{2}-\d{2}/.test(bText)) {
                    return (new Date(aText) - new Date(bText)) * sortDirection;
                }

                // Check if number
                let aNum = parseFloat(aText.replace(/[^0-9.\-]/g, ""));
                let bNum = parseFloat(bText.replace(/[^0-9.\-]/g, ""));
                if (!isNaN(aNum) && !isNaN(bNum) && aText !== "" && bText !== "") {
                    return (aNum - bNum) * sortDirection;
                }

                // Default string compare
                return aText.localeCompare(bText, undefined, {numeric: true}) * sortDirection;
            });

            rows.forEach(row => tbody.appendChild(row));
        });
    });
});
</script>
</body>
</html>
