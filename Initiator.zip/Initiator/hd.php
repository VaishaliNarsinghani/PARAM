<?php include('auth.php'); ?>
<?php
ini_set('memory_limit', '16G'); // or '1G'

// Database connection details
$host = 'localhost';
$db = 'project_db';
$user = 'root';
$pass = '';
$message = "";

try {
    // Create a new PDO instance
    $pdo = new PDO("mysql:host=$host;dbname=$db;charset=utf8", $user, $pass);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

    $results = [];
  
    if ($_SERVER['REQUEST_METHOD'] === 'POST') {
        // Initialize the SQL query for the search functionality
        $query = "SELECT * FROM mis WHERE flag_not_built = 0";
        $params = [];

        // Add filters only if fields are filled
      
        if (!empty($_POST['reference_id'])) {
            $query .= " AND reference_id LIKE ?";
            $params[] = "%" . $_POST['reference_id'] . "%";
        }
        
        if (!empty($_POST['customerName'])) {
            $query .= " AND customerName LIKE ?";
            $params[] = "%" . $_POST['customerName'] . "%";
        }
        if (!empty($_POST['city'])) {
            $query .= " AND address LIKE ?";
            $params[] = "%" . $_POST['city'] . "%";
        }
        if (!empty($_POST['applicationNo'])) {
            $query .= " AND applicationNo LIKE ?";
            $params[] = "%" . $_POST['applicationNo'] . "%";
        }
        if (!empty($_POST['party_name'])) {
            $query .= " AND party_name LIKE ?";
            $params[] = "%" . $_POST['party_name'] . "%";
        }
        
        if (!empty($_POST['branchname'])) {
          $query .= " AND branchname LIKE ?";
          $params[] = "%" . $_POST['branchname'] . "%";
    }
        if (!empty($_POST['caseType'])) {
            $query .= " AND caseType LIKE ?";
            $params[] = "%" . $_POST['caseType'] . "%";
        }

        // Execute the search query
        $stmt = $pdo->prepare($query);
        $stmt->execute($params);
        $results = $stmt->fetchAll(PDO::FETCH_ASSOC);
    }
   

    // Handle form submission for updating data (if required)
    if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['update']))
    
    {
        $stmt = $pdo->prepare("UPDATE mis SET customerName = ?, address = ?, customerMob = ?, visitType = ?, party_name = ?, branchname= ?,caseType = ?, applicationNo = ?, initiatorMailId = ?, initiationDate = ? WHERE reference_id = ?");
        $stmt->execute([
            $_POST['customerName'],
            $_POST['address'],
            $_POST['customerMob'],
            $_POST['visitType'],
            $_POST['party_name'],
            $_POST['branchname'],
            $_POST['caseType'],
            $_POST['applicationNo'],
            $_POST['initiatorMailId'],
            $_POST['initiationDate'],
            $_POST['reference_id']
        ]);
        $message = "Details updated successfully!";
    }
} catch (PDOException $e) {
  $message = "Error: " . $e->getMessage();
}
?>

<!-- JavaScript for Alert -->
<script>
    <?php if (!empty($message)): ?>
    alert("<?= htmlspecialchars_decode(addslashes($message)) ?>");
    <?php endif; ?>
</script>

<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Magpie Engineering</title>
    <link rel="shortcut icon" href="favicon.ico" type="image/x-icon">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
    <link rel="stylesheet" href="initiator12.css">
  </head>

  <th>
    <button class="toggle-btn" id="toggle-btn">☰</button>
    <div class="container">
      <!-- Sidebar -->

      <div class="sidebar" id="sidebar">
        <div style="display: flex">
          <img class="logo" src="logo.png" alt="" />
          <h1>Magpie Engineering</h1>
        </div>
        <div class="rotating-text">INITIATOR</div>
        <a href="initiator.php" class="active"><i class="fas fa-search icon"></i>Search</a>
             <a href="homeinitiator.php"><i class="fas fa-home icon"></i>Home</a>
        <a href="update.php"><i class="fas fa-home icon"></i>update assignment</a>
        <a href="createsassign.php"><i class="fas fa-file-alt icon"></i> Create New Assignment</a>
        <a href="Createsubs.php"><i class="fas fa-plus-square icon"></i> Create Subsequent</a>
        <a href="Revisereport.php"><i class="fas fa-edit icon"></i> Revise Report</a>
        <a href="not_built.php"><i class="fas fa-edit icon"></i> Cases Not to be Built</a>

        <a href="index.php"><i class="fas fa-sign-out-alt icon"></i>Logout</a>
      </div>

      <table>
        <tr>
          <th>Reference Number</th>
          <th>Customer Name</th>
          <th>Address</th>
          <th>Customer Mobile Number</th>
          <th>Visit Type</th>
          <th>Party Name</th>
          <th>Branch Name</th>
          <th>Case Type</th>
          <th>Application Number</th>
          <th>Mail ID</th>
          <th>Date</th>
          <th>Not to be Built</th>
        </tr>
        
        <?php foreach ($results as $task): ?>
        <tr>
            <td data-label="Reference Number"><?= htmlspecialchars($task['reference_id']) ?></td>
            <td data-label="Customer Name"><?= htmlspecialchars($task['customerName']) ?></td>
            <td data-label="Address"><?= htmlspecialchars($task['address']) ?></td>
            <td data-label="Customer Mobile Number"><?= htmlspecialchars($task['customerMob']) ?></td>
            <td data-label="Visit Type"><?= htmlspecialchars($task['visitType']) ?></td>
            <td data-label="Bank Name"><?= htmlspecialchars($task['party_name']) ?></td>
            <td data-label="Branch Name"><?= htmlspecialchars($task['branchname']) ?></td>
            <td data-label="Case Type"><?= htmlspecialchars($task['caseType']) ?></td>
            <td data-label="Application Number"><?= htmlspecialchars($task['applicationNo']) ?></td>
            <td data-label="Mail ID"><?= htmlspecialchars($task['initiatorMailId']) ?></td>
            <td data-label="Date"><?= htmlspecialchars($task['initiationDate']) ?></td>
            <td data-label="Assign"><a href="uploadFE.php?reference_id=<?= urlencode($task['reference_id']) ?>&customerName=<?= urlencode($task['customerName']) ?>&party_name=<?= urlencode($task['party_name']) ?>" class="upload-button" style="text-decoration:none;">Not to be built</a></td>
        </tr>
        <?php endforeach; ?>
        </table>
    </div>
  </div>
<script>
  const toggleBtn = document.getElementById("toggle-btn");
  const sidebar = document.getElementById("sidebar");
toggleBtn.addEventListener("click", () => {
  sidebar.classList.toggle("visible");
});
</script>
</body>
</html>