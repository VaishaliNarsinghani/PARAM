<?php 
 include('auth.php');
// Start the session to access session variables
 

// Database credentials
$host = 'localhost';
$db = 'project_db';
$user = 'root';
$pass = '';


try {
    // Create database connection using PDO
    $conn = new PDO("mysql:host=$host;dbname=$db", $user, $pass);
    $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (PDOException $e) {
    die("Database connection failed: " . $e->getMessage());
}

// Check if engineer_id is set in session (i.e., user is logged in)
if (!isset($_SESSION['coordinator_id'])) {
    // Redirect to login page if not logged in
    header("Location:index.php");
    exit();
}

$engineer_id = $_SESSION['coordinator_id'];

// Fetch records from the `mis` table where engineer_id matches the logged-in user
$sql = "SELECT * FROM mis WHERE coordinator_id = :coordinator_id AND flag_field_engineer = FALSE";

$stmt = $conn->prepare($sql);
$stmt->bindParam(':coordinator_id', $engineer_id, PDO::PARAM_STR);
$stmt->execute();
$assignments = $stmt->fetchAll(PDO::FETCH_ASSOC);


// Ensure values are passed through GET
$reference_id = $_GET['reference_id'] ?? '';
$customerName = $_GET['customerName'] ?? '';
$address = $_GET['address'] ?? '';
$customerMob = $_GET['customerMob'] ?? '';
$visitType = $_GET['visitType'] ?? '';
$caseType = $_GET['caseType'] ?? '';
$bankName = $_GET['bankName'] ?? '';
$branchname = $_GET['branchname'] ?? '';
$applicationNo = $_GET['applicationNo'] ?? '';
$initiatorMailId = $_GET['initiatorMailId'] ?? '';
$initiationDate = $_GET['initiationDate'] ?? '';
$message = '';


?>

<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Magpie Engineering</title>
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
  <link rel="stylesheet" href="subASS2.css">
</head>

<body>
  <button class="toggle-btn" id="toggle-btn">☰</button>
  <div class="container">
    <!-- Sidebar -->

    <div class="sidebar" id="sidebar">
      <div style="display: flex;">
        <img class="logo" src="logo.png" alt="">
        <h1>Magpie Engineering</h1>
      </div>
      <div class="rotating-text">COORDINATOR</div>
        <a href="home.php"><i class="fas fa-home icon"></i> Home</a>
        <a href="coordinator.php"><i class="fas fa-user-friends icon"></i> Coordinator</a>
        <a href="assignRD.php"><i class="fas fa-tasks icon"></i> Assign Report Drafter</a>
         <a href="subASS.php" class="active"><i class="fas fa-file-alt icon"></i>Pending To Assign</a>
            <a href="assStatus.php"><i class="fas fa-chart-line icon"></i> Assignment Status</a>
        <a href="assField.php"><i class="fas fa-file-alt icon"></i>Assigned Field Engineers</a>
        <a href="assReport.php"><i class="fas fa-file-alt icon"></i>Assigned Report Drafters</a>
        <a href="issues.php"><i class="fas fa-exclamation-triangle icon"></i> Issues</a>
        <a href="index.php"><i class="fas fa-sign-out-alt icon"></i> Logout</a>
    </div>

    <!-- Main Content -->
    <div class="content" id="content">
      <table>
        <p>ASSIGNMENT LIST</p>
        <tr>
          <th>Reference Number</th>
          <th>Customer Name</th>
          <th>Address</th>
          <th>Customer Mobile Number</th>
          <th>Visit Type</th>
          <th>Bank Name</th>
          <th>Branch Name</th>
          <th>Case Type</th>
          <th>Application Number</th>
          <th>Mail ID</th>
          <th>Date</th>
          <th>Assign</th>
          <th>Freelancer</th>
        </tr>
     
      <?php foreach ($assignments as $row): ?>
  <tr>
    <td><?= htmlspecialchars($row['reference_id']) ?></td>
    <td><?= htmlspecialchars($row['customerName']) ?></td>
    <td><?= htmlspecialchars($row['address']) ?></td>
    <td><?= htmlspecialchars($row['customerMob']) ?></td>
    <td><?= htmlspecialchars($row['visitType']) ?></td>
    <td><?= htmlspecialchars($row['bankName']) ?></td>
    <td><?= htmlspecialchars($row['branchname']) ?></td>
    <td><?= htmlspecialchars($row['caseType']) ?></td>
    <td><?= htmlspecialchars($row['applicationNo']) ?></td>
    <td><?= htmlspecialchars($row['initiatorMailId']) ?></td>
    <td><?= htmlspecialchars($row['initiationDate']) ?></td>
    <td>
      <a class="assign-button" 
         href="chooseFE1.php?assignmentId=<?= $row['id'] ?>
         &reference_id=<?= urlencode($row['reference_id']) ?>
         &customerName=<?= urlencode($row['customerName']) ?>
         &address=<?= urlencode($row['address']) ?>">
         Assign
      </a>
    </td>
  </tr>
<?php endforeach; ?>
