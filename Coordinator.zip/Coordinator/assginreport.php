

<?php
include('auth.php');
// Database connection setup
$host = 'localhost';
$db = 'project_db';
$user = 'root';
$pass = '';
$message = '';

try {
    $pdo = new PDO("mysql:host=$host;dbname=$db;charset=utf8", $user, $pass);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (PDOException $e) {
    die('Database connection failed: ' . $e->getMessage());
}

// Fetch engineers for assignment
try {
    $managersQuery = "SELECT report_id, name FROM report_login";
    $managersStmt = $pdo->query($managersQuery);
    $managersResult = $managersStmt->fetchAll(PDO::FETCH_ASSOC);
} catch (PDOException $e) {
    die('Error fetching Engineers: ' . $e->getMessage());
}

// Ensure values are passed through GET or SESSION
$engineer_id = isset($_GET['reference_id']) ? $_GET['reference_id'] : '';
$customerName = isset($_GET['customerName']) ? $_GET['customerName'] : '';
$address = isset($_GET['address']) ? $_GET['address'] : '';
$customerMob = isset($_GET['customerMob']) ? $_GET['customerMob'] : '';
$visitType = isset($_GET['visitType']) ? $_GET['visitType'] : '';
$caseType = isset($_GET['caseType']) ? $_GET['caseType'] : '';
$bankName = isset($_GET['bankName']) ? $_GET['bankName'] : '';
$branchname = isset($_GET['branchname']) ? $_GET['branchname'] : '';
$applicationNo = isset($_GET['applicationNo']) ? $_GET['applicationNo'] : '';
$initiatorMailId = isset($_GET['initiatorMailId']) ? $_GET['initiatorMailId'] : '';
$initiationDate = isset($_GET['initiationDate']) ? $_GET['initiationDate'] : '';
$message = '';

// Fetch assignments excluding those that already have a technical manager assigned
try {
    $stmt = $pdo->query("SELECT * FROM mis WHERE technical_manager_id IS NULL AND flag_report_drafter IS NULL");
    $assignments = $stmt->fetchAll(PDO::FETCH_ASSOC);
} catch (PDOException $e) {
    $message = 'Error fetching assignments: ' . $e->getMessage();
}

// Assign task to field engineer
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['assign_task'])) {
    $selectedEngineerId = isset($_POST['report_id']) ? $_POST['report_id'] : '';

    try {
        // Check if the selected report_id exists in report_login table
        $stmt = $pdo->prepare("SELECT COUNT(*) FROM report_login WHERE report_id = ?");
        $stmt->execute([$selectedEngineerId]);
        $reportExists = $stmt->fetchColumn();

        if ($reportExists) {
            // Proceed with the update if report_id exists
            $stmt = $pdo->prepare("UPDATE mis SET report_id = ?, report_assigned_at = CURRENT_TIMESTAMP, flag_report_drafter = 1 WHERE reference_id = ?");
            $stmt->execute([$selectedEngineerId, $engineer_id]);

            if ($stmt->rowCount() > 0) {
                // Redirect to assignRD.php after successful assignment
                header("Location: assReport.php");
                exit;
            } else {
                $message = 'No record was updated. Please check the Reference ID.';
            }
        } else {
            $message = 'The selected report ID does not exist. Please choose a valid report.';
            error_log("Report ID not found: " . $selectedEngineerId);
        }
    } catch (PDOException $e) {
        $message = 'Error assigning the task: ' . $e->getMessage();
    }
}
?>




<!-- JavaScript for Alert -->
<script>
    <?php if (!empty($message)): ?>
    alert("<?= htmlspecialchars_decode(addslashes($message)) ?>");
    <?php endif; ?>
</script>


<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Assign Task to Technical Manager</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
    <link rel="stylesheet" href="chooseRD12.css">
</head>

<body>
    <button class="toggle-btn" id="toggle-btn">☰</button>
    <div class="container">
        <!-- Sidebar -->
        <div class="sidebar" id="sidebar">
            <div style="display: flex;">
                <img class="logo" src="logo.png" alt="Magpie Engineering Logo">
                <h1>Magpie Engineering</h1>
            </div>
            <div class="rotating-text">COORDINATOR</div>
        <a href="home.php"><i class="fas fa-home icon"></i> Home</a>
        <a href="coordinator.php"><i class="fas fa-user-friends icon"></i> Coordinator</a>
        <a href="assignRD.php"><i class="fas fa-tasks icon"></i> Assign Report Drafter</a>
   <a href="subASS.php"><i class="fas fa-file-alt icon"></i>Pending To Assign</a>
    <a href="assStatus.php"><i class="fas fa-chart-line icon"></i> Assignment Status</a>
        <a href="assField.php"><i class="fas fa-file-alt icon"></i>Assigned Field Engineers</a>
        <a href="assReport.php" class="active"><i class="fas fa-file-alt icon"></i>Assigned Report Drafters</a>        <a href="issues.php"><i class="fas fa-exclamation-triangle icon"></i> Issues</a>
        <a href="index.php"><i class="fas fa-sign-out-alt icon"></i> Logout</a>
        </div>

        <!-- Content -->
        <div class="content" id="content">
            <div class="search-filters">
                <h2>Assign Task to Field Engineer</h2>
                <?php if (!empty($message)): ?>
                    <p style="color: green;"><?= htmlspecialchars($message) ?></p>
                <?php endif; ?>
                <form action="" method="POST">
                    <input type="text" name="reference_id" placeholder="Reference ID" value="<?= htmlspecialchars($engineer_id) ?>"  >
                    <input type="text" name="customerName" placeholder="Customer Name" value="<?= htmlspecialchars($customerName) ?>"  >
                    <input type="text" name="address" placeholder="Address" value="<?= htmlspecialchars($address) ?>" >
                    <input type="text" name="customerMob" placeholder="Customer Mobile" value="<?= htmlspecialchars($customerMob) ?>"  >
                    <input type="text" name="visitType" placeholder="Visit Type" value="<?= htmlspecialchars($visitType) ?>"  >
                    <input type="text" name="bankName" placeholder="Bank Name" value="<?= htmlspecialchars($bankName) ?>"  >
                    <input type="text" name="branchname" placeholder="Branch Name" value="<?= htmlspecialchars($branchname) ?>"  >
                    <input type="text" name="caseType" placeholder="Case Type" value="<?= htmlspecialchars($caseType) ?>"  >
                    <input type="text" name="applicationNo" placeholder="Application Number" value="<?= htmlspecialchars($applicationNo) ?>"  >
                    <input type="email" name="initiatorMailId" placeholder="Email ID" value="<?= htmlspecialchars($initiatorMailId) ?>"  >
                    <input type="date" name="initiationDate" placeholder="Initiation Date" value="<?= htmlspecialchars($initiationDate) ?>"  >
                    
                    <div class="form-row">
                        <!-- Left Side: Label and Select Box -->
                        <div class="form-left">
                            <label for="field_report_id">Select Report Drafter:</label>
                            <select name="report_id" id="field_report_id" required>
                                <option value="" disabled selected>Select Drafter</option>
                                <?php foreach ($managersResult as $manager): ?>
                                    <option value="<?= htmlspecialchars($manager['report_id']) ?>">
                                        <?= htmlspecialchars($manager['name']) ?>
                                    </option>
                                <?php endforeach; ?>
                            </select>
      </div>

      <button type="submit" name="assign_task"style="  background-color: #005f8a;">Assign Task</button>
    </div>
  </form>
            </div>
        </div>
    </div>

    <script>
        const toggleBtn = document.getElementById("toggle-btn");
        const sidebar = document.getElementById("sidebar");

        // Toggle Sidebar
        toggleBtn.addEventListener("click", () => {
            sidebar.classList.toggle("visible");
        });
    </script>
</body>

</html>
