<?php include('auth.php'); ?>
<?php
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

// DB Connection
$host = 'localhost';
$db = 'project_db';
$user = 'root';
$pass = '';

try {
    $pdo = new PDO("mysql:host=$host;dbname=$db", $user, $pass);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (PDOException $e) {
    echo "Database error: " . $e->getMessage();
    exit;
}

// Fetch engineer names
$engineerStmt = $pdo->query("SELECT engineer_id, name FROM engineer_login");
$engineerMap = [];
while ($row = $engineerStmt->fetch(PDO::FETCH_ASSOC)) {
    $engineerMap[$row['engineer_id']] = $row['name'];
}

// Search Filter
$conditions = ["engineer_id IS NOT NULL", "flag_fe_submit = FALSE"];
$params = [];
if (!empty(trim($_GET['reference_id'] ?? ''))) {
    $referenceId = trim($_GET['reference_id']);
    $conditions[] = "reference_id LIKE :reference_id";
    $params['reference_id'] = '%' . $referenceId . '%';
}
if (!empty(trim($_GET['customerName'] ?? ''))) {
    $customerName = trim($_GET['customerName']);
    $conditions[] = "customerName LIKE :customerName";
    $params['customerName'] = '%' . $customerName . '%';
}
if (!empty(trim($_GET['address'] ?? ''))) {
    $address = trim($_GET['address']);
    $conditions[] = "address LIKE :address";
    $params['address'] = '%' . $address . '%';
}
if (!empty(trim($_GET['customerMob'] ?? ''))) {
    $customerMob = trim($_GET['customerMob']);
    $conditions[] = "customerMob LIKE :customerMob";
    $params['customerMob'] = '%' . $customerMob . '%';
}
if (!empty(trim($_GET['visitType'] ?? ''))) {
    $visitType = trim($_GET['visitType']);
    $conditions[] = "visitType LIKE :visitType";
    $params['visitType'] = '%' . $visitType . '%';
}
if (!empty(trim($_GET['bankName'] ?? ''))) {
    $bankName = trim($_GET['bankName']);
    $conditions[] = "bankName LIKE :bankName";
    $params['bankName'] = '%' . $bankName . '%';
}
if (!empty(trim($_GET['branchname'] ?? ''))) {
    $branchName = trim($_GET['branchname']);
    $conditions[] = "branchname LIKE :branchname";
    $params['branchname'] = '%' . $branchName . '%';
}
if (!empty(trim($_GET['engineerName'] ?? ''))) {
    $searchEngineer = trim($_GET['engineerName']);
    $matchedIds = [];
    $engineerParams = [];

    foreach ($engineerMap as $id => $name) {
        if (stripos($name, $searchEngineer) !== false) {
            $paramKey = ':eng_' . $id;
            $matchedIds[] = $paramKey;
            $engineerParams[$paramKey] = $id;
        }
    }

    if (!empty($matchedIds)) {
        $conditions[] = 'engineer_id IN (' . implode(',', $matchedIds) . ')';
        $params = array_merge($params, $engineerParams);
    } else {
        $conditions[] = "1=0";
    }
}


$whereClause = $conditions ? 'WHERE ' . implode(' AND ', $conditions) : '';
$sql = "SELECT * FROM mis $whereClause ORDER BY assigned_at DESC";
$stmt = $pdo->prepare($sql);
$stmt->execute($params);
$misRows = $stmt->fetchAll(PDO::FETCH_ASSOC);
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Magpie Engineering</title>
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
<style>body {
  font-family: Arial, sans-serif;
  margin: 0;
  padding: 0;
  /* background: url('https://yadurajrealty.com/wp-content/uploads/2024/10/All-You-Need-To-Know-About.webp') no-repeat center center fixed; */
  background-size: cover;
  color: #333;
}

body::before {
  content: "";
  position: absolute;
  top: 0;
  left: 0;
  width: 100%;
  height: 100%;
  z-index: -1;
}

.container {
  display: flex;
  flex-direction: column;
  display: flex;
  min-height: 100vh;
  transition: all 0.3s ease;
  /* Stacks content vertically for small screens */
}
    .rotating-text {
    perspective: 1000px; /* Adds a 3D perspective effect */
    font-size: 2rem;
    font-weight:bold;
    animation: rotate360 3s linear infinite;
    display: inline-block;
    margin-bottom:10px;
    transform-origin: center center; /* Rotates around its center */
    text-align:center;
    font-style: italic;
    text-shadow: 
    1px 1px 2px rgba(235, 244, 243, 0.97),
    2px 2px 4px rgba(246, 242, 242, 0.4),
    3px 3px 6px rgba(249, 252, 252, 0.89),
    4px 4px 8px rgba(248, 242, 247, 0.93),
    5px 5px 10px rgba(232, 236, 237, 0.4);
  }
  
  /* Keyframes for rotating the text */
  @keyframes rotate360 {
    0% {
      transform: rotateY(0deg); /* Starts with no rotation */
    }
    50% {
      transform: rotateY(360deg); /* Half rotation */
    }
    100% {
      transform: rotateY(360deg); /* Full rotation */
    }
  }
    /* Sidebar */
    .sidebar {
      width: 250px;
      background: #B0C4DE; /* Light Steel Blue */
      color: #2C3E50; /* Dark Grayish Blue */
      padding:20px;
      height: 100vh;
      position: fixed;
      left: 0;
      top: 0;
      z-index: 1000;
      transition: transform 0.3s ease-in-out;
    }
    .sidebar.hidden {
      transform: translateX(-100%);
    }
    .sidebar h1 {
      font-size: 20px;
      margin-bottom: 20px;
    }
  
    .sidebar a {
      padding: 15px 20px;
        margin:19px 0;
        text-decoration: none;
        color: #2C3E50; /* Dark Grayish Blue */
        font-size:16px;
        font-style: italic;
        font-weight: 500;
        border-radius: 5px;
        transition: all 0.3s ease;
        display: flex;
        align-items: center;
    }

  .sidebar a:hover,
  .sidebar a.active {
    background: #4A90E2; /* Light Blue */
    color: white;
    transform: translateX(10px);
  }
  .sidebar a .icon {
    margin-right: 15px;
    font-size: 18px;
  }
/* Toggle Button */
.toggle-btn {
  width: 10%;
  display: none;
  /* Hidden by default */
  position: fixed;
  top: 10px;
  left: 10px;
  background: none;
  color:black;
  padding: 10px 15px;
  border: none;
  border-radius: 5px;
  cursor: pointer;
  z-index: 1001;

}
.toggle-btn:hover {
  width: 10%;
  background: rgba(255, 255, 255, 0.288);
}

  /* Main Content */
  .content {
    margin-left: 270px;
    padding: 20px;
    animation: fadeIn 1.5s ease-in-out;
    transition: transform 0.3s ease-in-out;
  }

  .content.full-width {
    margin-left: 0;
  }

  /* Search Filters */
  .search-filters {
    background: hwb(210 92% 7%); /* Light Steel Blue */
    padding: 20px;
    border-radius: 5px;
    box-shadow: 0 5px 15px rgba(247, 247, 247, 0.1);
    animation: slideIn 1s ease-in-out;
  }

  .search-filters h2 {
    margin-bottom: 20px;
      color: #2C3E50; /* Dark Grayish Blue */
    text-align: center;
    margin-left:auto;
  }

  .search-filters input,
  .search-filters button {
    background-color: rgba(255, 255, 255, 0.986);
    padding: 10px;
    margin: 5px;
    border: 1px solid #ccc;
    border-radius: 5px;
    width: 45%;
  }
/* Media Queries for Responsiveness */
@media (max-width: 768px) {
  .toggle-btn {
    display: block;
  }

  .sidebar {
    transform: translateX(-100%);
  }

  .sidebar.visible {
    transform: translateX(0);
  }

  .content {
    margin-left: 0;

  }

  .search-filters input,
  .search-filters button {
    width: 90%;
  }
}
.logo {
  width: 50px;
  height:50px;
  padding: 15px;
}
.content {
  margin: 0; /* Remove conflicting margins */
  padding: 20px;
  animation: fadeIn 1.5s ease-in-out;
  transition: transform 0.3s ease-in-out;
}

table {
  width: 100%;
  margin: 0 1% 0 1%; /* Use the same margin in both pages */
  border-collapse: collapse;
  background:rgb(207, 222, 240);
  color: #2C3E50;
  border-radius: 10px;
  overflow: hidden;
  table-layout: fixed; /* Enforce fixed column widths */
  
}

th, td {
  padding: 12px;
  text-align: left;
  border: 1px solid rgba(255, 255, 255, 0.2);
  font-size: 15px;
  word-wrap: break-word; /* Allow wrapping of text */
  white-space: normal; /* Ensure wrapping is allowed */
  min-width: 100px; /* Set a minimum width for columns */
}

th {
  font-size: 13px;
  background-color:rgb(102, 146, 190);
   color:white;
  font-weight: bold;
}

table {
    table-layout: fixed; /* Enforces fixed column widths */
}

th, td {
     /* Adjust as needed for your preferred column width */
    word-wrap: break-word; /* Allows text to wrap onto the next line */
    white-space: normal; /* Ensures wrapping is allowed */
}


 tr:nth-child(even) {
   background-color:rgb(234, 236, 250);
 }

 tr:hover {
   background-color:rgb(138, 177, 215);
   color:white;
   font-weight:bolder;
   font-style:italic;
 }
 h2{
  margin-left:32% ; 
   font-style: oblique;
 color: #2C3E50;
 }
 button{
    padding:10px 10px;
    background-color: #005f8a;
    color: white;
    text-decoration: none;
    border: none;
    border-radius: 5px;
    cursor: pointer;
    font-size: 16px;
    margin-top:10px;
}

@media (max-width: 768px) {
  

.content {
  margin-left: 0;
}

.search-filters input,
.search-filters button {
  width: 90%;
}
}
.content {
margin-left: 270px; /* Adjust based on sidebar width */
}

button {
  padding: 5px 10px;
  background-color: #005f8a;
  color: white;
  border: none;
  border-radius: 5px;
  cursor: pointer;
  font-size: 14px;
}

button a {
  text-decoration: none;
  color: white;
}

button:hover {
  background-color: #007aa3;
}

/* Responsive Table */
@media screen and (max-width: 768px) {

  table,
  thead,
  tbody,
  th,
  td,
  tr {
    display: block;
  }

  th {
    display: none;
  }

  td {
    position: relative;
    padding-left: 50%;
    text-align: right;
  }

  td::before {
    content: attr(data-label);
    position: absolute;
    left: 10px;
    font-weight: bold;
    text-transform: uppercase;
  }

  tr {
    margin-bottom: 15px;
  }

  button {
    width: 100%;
    padding: 10px;
  }
}
select{
  padding:10px;
text-align: left;
}
label{
  text-align: left;
}

p{
  color: #2C3E50;
 text-align:center;
 font-size:30px;
 font-style:oblique;
 font-weight: 100;
}

/* Assign Button Styling */
.upload-button {
background-color:rgb(102, 146, 190);
color: white; /* White text color */
border: 1px solid black; /* Black border */
border-radius: 5px; /* Rounded corners */
padding: 5px 10px; /* Padding for the button */
font-size: 14px; /* Font size */
font-weight: bold; /* Bold text */
text-align: center; /* Center the text */
cursor: pointer; /* Pointer cursor on hover */
display: inline-block; /* Inline-block for proper alignment */
}

.upload-buttona {
text-decoration:none; /* Remove underline */
color: white; /* Ensure the link text color is white */
display: inline-block; /* Ensure proper alignment inside the button */
width: 100%; /* Make it span the button */
height: 100%; /* Make it span the button */
}

/* Hover effect for the button */
.upload-button:hover {
background-color: #B0C4DE; /* Gray background on hover */
color: white; /* Maintain white text on hover */
}

.upload-button a:hover {
color: white; /* Ensure link remains white on hover */
}
/* Main Content */
  .content {
    margin-left: 270px;
    padding: 20px;
    animation: fadeIn 1.5s ease-in-out;
    transition: transform 0.3s ease-in-out;
  }

  .content.full-width {
    margin-left: 0;
  }
   table {
        border-collapse: collapse;
        width: 100%;
    }
    th, td {
        border: 1px solid #ccc;
        padding: 8px;
        text-align: left;
    }
    th {
        cursor: pointer;
        background: #f2f2f2;
        position: relative;
        user-select: none;
    }
    th:hover {
        background: #e0e0e0;
    }
    th.asc::after {
        content: " ▲";
        position: absolute;
        right: 8px;
    }
    th.desc::after {
        content: " ▼";
        position: absolute;
        right: 8px;
    }
  </style>
  </head>

<body>
  <button class="toggle-btn" id="toggle-btn">☰</button>
  <div class="container">
    <!-- Sidebar -->

    <div class="sidebar" id="sidebar">
      <div style="display: flex;">
        <img class="logo" src="logo.png" alt="">
        <h1>Magpie Engineering</h1>
      </div>
      <div class="rotating-text">COORDINATOR</div>
        <a href="home.php"><i class="fas fa-home icon"></i> Home</a>
        <a href="coordinator.php"><i class="fas fa-user-friends icon"></i> Coordinator</a>
        <a href="assignRD.php"><i class="fas fa-tasks icon"></i> Assign Report Drafter</a>
         <a href="subASS.php"><i class="fas fa-file-alt icon"></i>Pending To Assign</a>
         <a href="assStatus.php"><i class="fas fa-chart-line icon"></i> Assignment Status</a>
        <a href="assField.php"  class="active"><i class="fas fa-file-alt icon"></i>Assigned Field Engineers</a>
        <a href="assReport.php"><i class="fas fa-file-alt icon"></i>Assigned Report Drafters</a>
        <a href="issues.php"><i class="fas fa-exclamation-triangle icon"></i> Issues</a>
        <a href="index.php"><i class="fas fa-sign-out-alt icon"></i> Logout</a>
    </div>

  
       <table>       <?php         
         echo "
         <style>
/* Main Content */         
 .content {
  margin: 0; /* Remove conflicting margins */
  padding: 20px;
  animation: fadeIn 1.5s ease-in-out;
  transition: transform 0.3s ease-in-out;
}

table {
  width:75%;
  margin: 0 1% 0 24%; /* Use the same margin in both pages */
  border-collapse: collapse;
  background:rgb(207, 222, 240);
  color: #2C3E50;
  border-radius: 10px;
  overflow: hidden;
  table-layout: fixed; /* Enforce fixed column widths */
  
}

th, td {
  padding:10px;
  border: 1px solid rgba(255, 255, 255, 0.2);
  font-size: 15px;
  word-wrap: break-word; /* Allow wrapping of text */
  white-space: normal; /* Ensure wrapping is allowed */
  min-width:100px; /* Set a minimum width for columns */
}

th {
  font-size: 13px;
  background-color:rgb(102, 146, 190);
   color:white;
  font-weight: bold;
}

table {
    table-layout: fixed; /* Enforces fixed column widths */
}

th, td {
     /* Adjust as needed for your preferred column width */
    word-wrap: break-word; /* Allows text to wrap onto the next line */
    white-space: normal; /* Ensures wrapping is allowed */
}


 tr:nth-child(even) {
   background-color:rgb(234, 236, 250);
 }

 tr:hover {
   background-color:rgb(138, 177, 215);
   color:white;
   font-weight:bolder;
   font-style:italic;
 }
h2{
  margin-left:38% ; 
   font-style: oblique;
 color: #2C3E50;
 }
 button{
    padding:10px 10px;
    background-color:rgb(102, 146, 190);
    color: white;
    text-decoration: none;
    border: none;
    border-radius: 5px;
    cursor: pointer;
    font-size: 16px;
    margin-top:10px;
}

.content {
margin-left: 270px; /* Adjust based on sidebar width */
}


@media (min-width: 1200px) {

@media (max-width: 768px) {
.content {
margin-left: 0px; /* Adjust based on sidebar width */
}
.toggle-btn {
 display: block;
}

.sidebar {
 transform: translateX(-100%);
}

.sidebar.visible {
 transform: translateX(0);
}
 
}

@keyframes slideIn {
from {
 transform: translateX(-100%);
 opacity: 0;
}

to {
 transform: translateX(0);
 opacity: 1;
}
}

@keyframes fadeIn {
from {
 opacity: 0;
}

to {
 opacity: 1;
}
}

.logo {
  width: 50px;
  height:50px;
  padding: 15px;
}
  /* Assign Button Styling */
.upload-button {
background-color:rgb(102, 146, 190);
color: white; /* White text color */
border: 1px solid black; /* Black border */
border-radius: 5px; /* Rounded corners */
padding: 5px 6px; /* Padding for the button */
font-size: 14px; /* Font size */
font-weight: bold; /* Bold text */
text-align: center; /* Center the text */
cursor: pointer; /* Pointer cursor on hover */
display: inline-block; /* Inline-block for proper alignment */
}

.upload-button a {
text-decoration:none; /* Remove underline */
color: white; /* Ensure the link text color is white */
display: inline-block; /* Ensure proper alignment inside the button */
width: 100%; /* Make it span the button */
height: 100%; /* Make it span the button */
}

/* Hover effect for the button */
.upload-button:hover {
background-color: #B0C4DE; /* Gray background on hover */
color: white; /* Maintain white text on hover */
}

.upload-button a:hover {
color: white; /* Ensure link remains white on hover */
}
@media (max-width: 768px) {
  .content {
    margin-left: 0 !important; /* Remove unwanted left margin */
    padding: 10px;
    display: flex;
    justify-content: center;
    align-items: center;
    flex-direction: column;
  }

  table {
    width: 90% !important; /* Ensure the table takes up most of the screen */
    margin: 0 auto !important; /* Center the table horizontally */
    display: block;
    overflow-x: auto; /* Enable horizontal scrolling if needed */
    text-align: center;
  }

  th, td {
    font-size: 14px; /* Adjust font size for better readability */
    padding: 8px;
    word-wrap: break-word;
    white-space: normal;
  }
}


   </style>";?></table>
 <div class="content" id="content">
  <div class="search-filters">
    <h2>Search Filters</h2>
    <form id="searchForm" method="GET" action="assField.php">
      <div class="form-row">
        <input type="text" name="reference_id" placeholder="Reference Number" value="<?php echo htmlspecialchars($_GET['reference_id'] ?? '') ?>" />
        <input type="text" name="customerName" placeholder="Customer Name" value="<?php echo htmlspecialchars($_GET['customerName'] ?? '') ?>" />
      </div>
      <div class="form-row">
        <input type="text" name="address" placeholder="Address" value="<?php echo htmlspecialchars($_GET['address'] ?? '') ?>" />
        <input type="text" name="customerMob" placeholder="Customer Mobile Number" value="<?php echo htmlspecialchars($_GET['customerMob'] ?? '') ?>" />
      </div>
      <div class="form-row">
        <input type="text" name="visitType" placeholder="Visit Type" value="<?php echo htmlspecialchars($_GET['visitType'] ?? '') ?>" />
        <input type="text" name="bankName" placeholder="Bank Name" value="<?php echo htmlspecialchars($_GET['bankName'] ?? '') ?>" />
      </div>
      <div class="form-row">
        <input type="text" name="branchname" placeholder="Branch Name" value="<?php echo htmlspecialchars($_GET['branchname'] ?? '') ?>" />
        <input type="text" name="engineerName" placeholder="Engineer Name" value="<?php echo htmlspecialchars($_GET['engineerName'] ?? '') ?>" />
      </div>
      <div class="form-row">
        <button type="submit" style="background: #4A90E2; color: white; padding: 8px 16px;">Search</button>
      </div>
    </form>
  </div>
</div>
<?php if (!empty($misRows)): ?>
<form method="POST" action="reassignFE.php">
  <p style="margin-left:18%;">Customer Information Table</p>
  <table id="sortableTable">
    <thead>
    <tr>
      <th>Select</th>
      <th>Reference Number</th>
      <th>Customer Name</th>
      <th>Address</th>
      <th>Customer Mobile Number</th>
      <th>Visit Type</th>
      <th>Bank Name</th>
      <th>Branch Name</th>
      <th>Field Engineer Name</th>
      <th>Field Engineer Assigned At</th>
      <th>Re-Assign</th>
    </tr>
    </thead>
    <?php foreach ($misRows as $task): ?>
    <tr>
      <td><input type="checkbox" name="selected[]" value="<?= $task['id'] ?>"></td>
      <td><?= htmlspecialchars($task['reference_id']) ?></td>
      <td><?= htmlspecialchars($task['customerName']) ?></td>
      <td><?= htmlspecialchars($task['address']) ?></td>
      <td><?= htmlspecialchars($task['customerMob']) ?></td>
      <td><?= htmlspecialchars($task['visitType']) ?></td>
      <td><?= htmlspecialchars($task['bankName']) ?></td>
      <td><?= htmlspecialchars($task['branchname']) ?></td>
      <td><?= isset($engineerMap[$task['engineer_id']]) ? htmlspecialchars($engineerMap[$task['engineer_id']]) : 'Not Found' ?></td>
      <td><?= htmlspecialchars($task['assigned_at']) ?></td>
   <td data-label="Assign">
    <a href="reassignFE.php?id=<?= urlencode($task['id']) ?>" 
       class="upload-button" 
       style="text-decoration:none;">
        Re-Assign
    </a>
</td>

    </tr>
    <?php endforeach; ?>
  </table>

  <br>
  <button type="submit" class="upload-button" style="margin-left:55%;padding:10px;">Re-Assign Selected</button>
</form>
<?php else: ?>
  <p style="text-align: center;">No data available</p>
<?php endif; ?>


</div>
<script>
  const toggleBtn = document.getElementById("toggle-btn");
  const sidebar = document.getElementById("sidebar");
  toggleBtn.addEventListener("click", () => {
    sidebar.classList.toggle("visible");
  });
</script>

<script>
document.addEventListener("DOMContentLoaded", function () {
    const table = document.getElementById("sortableTable");
    const headers = table.querySelectorAll("th");
    let sortDirection = 1;
    let activeColumn = -1;

    headers.forEach((header, index) => {
        header.addEventListener("click", () => {
            const tbody = table.tBodies[0];
            const rows = Array.from(tbody.querySelectorAll("tr"));
            
            if (activeColumn === index) {
                sortDirection *= -1; // toggle
            } else {
                sortDirection = 1;
            }
            activeColumn = index;

            // Remove sort classes
            headers.forEach(h => h.classList.remove("asc", "desc"));
            header.classList.add(sortDirection === 1 ? "asc" : "desc");

            rows.sort((a, b) => {
                let aText = a.cells[index].textContent.trim();
                let bText = b.cells[index].textContent.trim();

                // Check if date
                if (/\d{4}-\d{2}-\d{2}/.test(aText) && /\d{4}-\d{2}-\d{2}/.test(bText)) {
                    return (new Date(aText) - new Date(bText)) * sortDirection;
                }

                // Check if number
                let aNum = parseFloat(aText.replace(/[^0-9.\-]/g, ""));
                let bNum = parseFloat(bText.replace(/[^0-9.\-]/g, ""));
                if (!isNaN(aNum) && !isNaN(bNum) && aText !== "" && bText !== "") {
                    return (aNum - bNum) * sortDirection;
                }

                // Default string compare
                return aText.localeCompare(bText, undefined, {numeric: true}) * sortDirection;
            });

            rows.forEach(row => tbody.appendChild(row));
        });
    });
});
</script>
</body>
</html>