<?php include('auth.php'); ?>
<?php
 
$host = 'localhost';
$db = 'project_db';
$user = 'root';
$pass = '';

try {
    $pdo = new PDO("mysql:host=$host;dbname=$db", $user, $pass);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (PDOException $e) {
    echo "Database error: " . $e->getMessage();
    exit;
}

// ✅ Fetch unsubmitted tasks with assigned engineers
$sql = "SELECT * FROM mis WHERE report_id IS NOT NULL AND flag_report_drafter = 1 AND flag_report_submit = 0;";
$stmt = $pdo->prepare($sql);
$stmt->execute();
$results = $stmt->fetchAll(PDO::FETCH_ASSOC);
?>

 <?php
 

// PDO Connection
$host = 'localhost';
$db = 'project_db';
$user = 'root';
$pass = '';

try {
    $pdo = new PDO("mysql:host=$host;dbname=$db", $user, $pass);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (PDOException $e) {
    die("Database error: " . $e->getMessage());
}

// Step 1: Fetch all mis entries with an assigned engineer
$sql = "SELECT * FROM mis WHERE report_id IS NOT NULL  AND flag_report_drafter = 1 AND flag_report_submit = 0 ORDER BY report_assigned_at DESC;";
$stmt = $pdo->prepare($sql);
$stmt->execute();
$misRows = $stmt->fetchAll(PDO::FETCH_ASSOC);

// Step 2: Fetch all engineer IDs and names in one go (avoid querying inside a loop)
$engineerStmt = $pdo->query("SELECT report_id, name FROM report_login");
$engineerMap = [];
while ($row = $engineerStmt->fetch(PDO::FETCH_ASSOC)) {
    $engineerMap[$row['report_id']] = $row['name'];
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Magpie Engineering</title>
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
 <style>

body {
  font-family: Arial, sans-serif;
  margin: 0;
  padding: 0;
  /* background: url('https://yadurajrealty.com/wp-content/uploads/2024/10/All-You-Need-To-Know-About.webp') no-repeat center center fixed; */
  background-size: cover;
  color: #333;
}

body::before {
  content: "";
  position: absolute;
  top: 0;
  left: 0;
  width: 100%;
  height: 100%;
  z-index: -1;
}

.container {
  display: flex;
  flex-direction: column;
  display: flex;
  min-height: 100vh;
  transition: all 0.3s ease;
  /* Stacks content vertically for small screens */
}

.rotating-text {
    perspective: 1000px; /* Adds a 3D perspective effect */
    font-size:20px;
    font-weight:bolder;
    animation: rotate360 3s linear infinite;
    display: inline-block;
    margin-top:20px;
    transform-origin: center center; /* Rotates around its center */
    text-align:center;
    margin-left:45px;
    margin-bottom:-10px;
    font-style: italic;
    text-shadow: 
    1px 1px 2px rgba(235, 244, 243, 0.97),
    2px 2px 4px rgba(246, 242, 242, 0.4),
    3px 3px 6px rgba(249, 252, 252, 0.89),
    4px 4px 8px rgba(248, 242, 247, 0.93),
    5px 5px 10px rgba(232, 236, 237, 0.4);
  }

/* Keyframes for rotating the text */
@keyframes rotate360 {
  0% {
    transform: rotateY(0deg); /* Starts with no rotation */
  }
  50% {
    transform: rotateY(360deg); /* Half rotation */
  }
  100% {
    transform: rotateY(360deg); /* Full rotation */
  }
}
  /* Sidebar */
  .sidebar {
    width: 250px;
    background: #B0C4DE; /* Light Steel Blue */
    color: #2C3E50; /* Dark Grayish Blue */
    padding:20px;
    height: 100vh;
    position: fixed;
    left: 0;
    top: 0;
    z-index: 1000;
    transition: transform 0.3s ease-in-out;
  }
  .sidebar.hidden {
    transform: translateX(-100%);
  }
 .sidebar h1 {
    font-size: 20px;
    margin-bottom: 20px;
  }
  .sidebar a {
    padding: 15px 20px;
    margin:19px 0;
      text-decoration: none;
      color: #2C3E50; /* Dark Grayish Blue */
      font-size:16px;
      font-style: italic;
      font-weight: 500;
      margin-bottom:0px;
      border-radius: 5px;
      transition: all 0.3s ease;
      display: flex;
      align-items: center;
  }

  .sidebar a:hover,
  .sidebar a.active {
    background: #4A90E2; /* Light Blue */
    color: white;
    transform: translateX(10px);
  }
  .sidebar a .icon {
    margin-right: 15px;
    font-size: 18px;
  }
/* Toggle Button */
.toggle-btn {
  width: 10%;
  display: none;
  /* Hidden by default */
  position: fixed;
  top: 10px;
  left: 10px;
  background: none;
  color:black;
  padding: 10px 15px;
  border: none;
  border-radius: 5px;
  cursor: pointer;
  z-index: 1001;

}

.toggle-btn:hover {
  width: 10%;
  background: rgba(255, 255, 255, 0.288);
}

  /* Main Content */
  .content {
    margin-left: 270px;
    padding: 20px;
    animation: fadeIn 1.5s ease-in-out;
    transition: transform 0.3s ease-in-out;
  }

  .content.full-width {
    margin-left: 0;
  }
  /* Media Queries for Responsiveness */
  @media (max-width: 768px) {
    .toggle-btn {
      display: block;
    }

    .sidebar {
      transform: translateX(-100%);
    }

    .sidebar.visible {
      transform: translateX(0);
    }

    .content {
      margin-left: 0;

    }
    
  }

  @keyframes slideIn {
    from {
      transform: translateX(-100%);
      opacity: 0;
    }

    to {
      transform: translateX(0);
      opacity: 1;
    }
  }

  @keyframes fadeIn {
    from {
      opacity: 0;
    }

    to {
      opacity: 1;
    }
  }

  .logo {
    width: 50px;
    height: 50px;
    padding: 15px;
  }
/* Main Content */
.content {
  margin: 0; /* Remove conflicting margins */
  padding: 0px;
  animation: fadeIn 1.5s ease-in-out;
  transition: transform 0.3s ease-in-out;
}

table {
  width: 100%;
  margin: 0 1% 0 1%; /* Use the same margin in both pages */
  border-collapse: collapse;
  background:rgb(207, 222, 240);
  color: #2C3E50;
  border-radius: 10px;
  overflow: hidden;
  table-layout: fixed; /* Enforce fixed column widths */
  
}

th, td {
  padding: 2px;
  text-align: left;
  border: 1px solid rgba(255, 255, 255, 0.2);
  font-size: 15px;
  word-wrap: break-word; /* Allow wrapping of text */
  white-space: normal; /* Ensure wrapping is allowed */
  min-width: 100px; /* Set a minimum width for columns */
}

th {
  font-size: 13px;
  background-color:rgb(102, 146, 190);
   color:white;
  font-weight: bold;
}

table {
    table-layout: fixed; /* Enforces fixed column widths */
}

th, td {
     /* Adjust as needed for your preferred column width */
    word-wrap: break-word; /* Allows text to wrap onto the next line */
    white-space: normal; /* Ensures wrapping is allowed */
}


 tr:nth-child(even) {
   background-color:rgb(234, 236, 250);
 }

 tr:hover {
   background-color:rgb(138, 177, 215);
   color:white;
   font-weight:bolder;
   font-style:italic;
 }
h2{
  margin-left:32% ; 
   font-style: oblique;
 color: #2C3E50;
 }

 button{
    padding:10px 10px;
    background-color:rgb(102, 146, 190);
    color: white;
    border: none;
    border-radius: 5px;
    cursor: pointer;
    font-size: 16px;
    margin-top:10px;
}

@media (max-width: 768px) {
  

.content {
  margin-left: 0;
}

.search-filters input,
.search-filters button {
  width: 90%;
}
}
.content {
margin-left: 270px; /* Adjust based on sidebar width */
}


@media (min-width: 1200px) {

@media (max-width: 768px) {
.toggle-btn {
 display: block;
}

.sidebar {
 transform: translateX(-100%);
}

.sidebar.visible {
 transform: translateX(0);
}

.content {
 margin-left: 0;
 margin:0;

}

.search-filters input,
.search-filters button {
 width: 90%;
}
}

@keyframes slideIn {
from {
 transform: translateX(-100%);
 opacity: 0;
}

to {
 transform: translateX(0);
 opacity: 1;
}
}

@keyframes fadeIn {
from {
 opacity: 0;
}

to {
 opacity: 1;
}
}

.logo {
  width: 50px;
  height:50px;
  padding: 15px;
}
@media (max-width: 768px) {
  .toggle-btn {
    display: block;
  }

  .sidebar {
    transform: translateX(-100%);
  }

  .sidebar.visible {
    transform: translateX(0);
  }

  .content {
    margin-left: 0;

  }

  .search-filters input,
  .search-filters button {
    width: 90%;
  }
}
}
p{
  color: #2C3E50;
 text-align:center;
 font-size:30px;
 font-style:oblique;
 font-weight: 100;
}
/* Assign Button Styling */
.assign-button {
  background-color:rgb(102, 146, 190);
  color: white; /* White text color */
  border: 1px solid black; /* Black border */
  border-radius: 5px; /* Rounded corners */
  padding: 5px 10px; /* Padding for the button */
  font-size: 14px; /* Font size */
  font-weight: bold; /* Bold text */
  text-align: center; /* Center the text */
  cursor: pointer; /* Pointer cursor on hover */
  display: inline-block; /* Inline-block for proper alignment */
}

.assign-button a {
  text-decoration: none; /* Remove underline */
  color: white; /* Ensure the link text color is white */
  display: inline-block; /* Ensure proper alignment inside the button */
  width: 100%; /* Make it span the button */
  height: 100%; /* Make it span the button */
}

/* Hover effect for the button */
.assign-button:hover {
  background-color: #B0C4DE; /* Gray background on hover */
  color: white; /* Maintain white text on hover */
}

.assign-button a:hover {
  color: white; /* Ensure link remains white on hover */
}

/* Responsive Table */
@media screen and (max-width: 768px) {

  table,
  thead,
  tbody,
  th,
  td,
  tr {
    display: block;
  }

  th {
    display: none;
  }

  td {
    position: relative;
    padding-left: 50%;
    text-align: right;
  }

  td::before {
    content: attr(data-label);
    position: absolute;
    left: 0px;
    font-weight: bold;
    text-transform: uppercase;
  }

  tr {
    margin-bottom: 15px;
  }

  button {
    width: 100%;
    padding: 10px;
  }
}

 </style>
</head>

<body>
  <button class="toggle-btn" id="toggle-btn">☰</button>
  <div class="container">
    <!-- Sidebar -->

    <div class="sidebar" id="sidebar">
      <div style="display: flex;">
        <img class="logo" src="logo.png" alt="">
        <h1>Magpie Engineering</h1>
      </div>
      <div class="rotating-text">COORDINATOR</div>
        <a href="home.php"><i class="fas fa-home icon"></i> Home</a>
        <a href="coordinator.php"><i class="fas fa-user-friends icon"></i> Coordinator</a>
        <a href="assignRD.php"><i class="fas fa-tasks icon"></i> Assign Report Drafter</a>
           <a href="subASS.php"><i class="fas fa-file-alt icon"></i>Pending To Assign</a>
    <a href="assStatus.php"><i class="fas fa-chart-line icon"></i> Assignment Status</a>
        <a href="assField.php" ><i class="fas fa-file-alt icon"></i>Assigned Field Engineers</a>
        <a href="assReport.php"  class="active"><i class="fas fa-file-alt icon"></i>Assigned Report Drafters</a>
        <a href="issues.php"><i class="fas fa-exclamation-triangle icon"></i> Issues</a>
        <a href="index.php"><i class="fas fa-sign-out-alt icon"></i> Logout</a>
    </div>
    
    
    
    
     <?php
    if (!empty($results)): ?>
       <table>       <?php         
         echo "
         <style>
/* Main Content */         
 .content {
  margin: 0; /* Remove conflicting margins */
  padding: 20px;
  animation: fadeIn 1.5s ease-in-out;
  transition: transform 0.3s ease-in-out;
}

table {
  width:76%;
  margin: 0 1% 0 23%; /* Use the same margin in both pages */
  border-collapse: collapse;
  background:rgb(207, 222, 240);
  color: #2C3E50;
  border-radius: 10px;
  overflow: hidden;
  table-layout: fixed; /* Enforce fixed column widths */
  
}

th, td {
  padding:8px;
  border: 1px solid rgba(255, 255, 255, 0.2);
  font-size: 15px;
  word-wrap: break-word; /* Allow wrapping of text */
  white-space: normal; /* Ensure wrapping is allowed */
  min-width:100px; /* Set a minimum width for columns */
}

th {
  font-size: 13px;
  background-color:rgb(102, 146, 190);
   color:white;
  font-weight: bold;
}

table {
    table-layout: fixed; /* Enforces fixed column widths */
}

th, td {
     /* Adjust as needed for your preferred column width */
    word-wrap: break-word; /* Allows text to wrap onto the next line */
    white-space: normal; /* Ensures wrapping is allowed */
}


 tr:nth-child(even) {
   background-color:rgb(234, 236, 250);
 }

 tr:hover {
   background-color:rgb(138, 177, 215);
   color:white;
   font-weight:bolder;
   font-style:italic;
 }
h2{
  margin-left:38% ; 
   font-style: oblique;
 color: #2C3E50;
 }
 button{
    padding:10px 10px;
    background-color:rgb(102, 146, 190);
    color: white;
    text-decoration: none;
    border: none;
    border-radius: 4px;
    cursor: pointer;
    font-size: 16px;
    margin-top:10px;
}

.content {
margin-left: 270px; /* Adjust based on sidebar width */
}


@media (min-width: 1200px) {

@media (max-width: 768px) {
.content {
margin-left: 0px; /* Adjust based on sidebar width */
}
.toggle-btn {
 display: block;
}

.sidebar {
 transform: translateX(-100%);
}

.sidebar.visible {
 transform: translateX(0);
}
 
}

@keyframes slideIn {
from {
 transform: translateX(-100%);
 opacity: 0;
}

to {
 transform: translateX(0);
 opacity: 1;
}
}

@keyframes fadeIn {
from {
 opacity: 0;
}

to {
 opacity: 1;
}
}

.logo {
  width: 50px;
  height:50px;
  padding: 15px;
}
  /* Assign Button Styling */
.upload-button {
background-color:rgb(102, 146, 190);
color: white; /* White text color */
border: 1px solid black; /* Black border */
border-radius: 5px; /* Rounded corners */
padding: 8px 5px; /* Padding for the button */
font-size: 12px; /* Font size */
font-weight: bold; /* Bold text */
text-align: center; /* Center the text */
cursor: pointer; /* Pointer cursor on hover */
display: inline-block; /* Inline-block for proper alignment */
}

.upload-button a {
text-decoration:none; /* Remove underline */
color: white; /* Ensure the link text color is white */
display: inline-block; /* Ensure proper alignment inside the button */
width: 100%; /* Make it span the button */
height: 100%; /* Make it span the button */
}

/* Hover effect for the button */
.upload-button:hover {
background-color: #B0C4DE; /* Gray background on hover */
color: white; /* Maintain white text on hover */
}

.upload-button a:hover {
color: white; /* Ensure link remains white on hover */
}
@media (max-width: 768px) {
  .content {
    margin-left: 0 !important; /* Remove unwanted left margin */
    padding: 10px;
    display: flex;
    justify-content: center;
    align-items: center;
    flex-direction: column;
  }

  table {
    width: 90% !important; /* Ensure the table takes up most of the screen */
    margin: 0 auto !important; /* Center the table horizontally */
    display: block;
    overflow-x: auto; /* Enable horizontal scrolling if needed */
    text-align: center;
  }

  th, td {
    font-size: 14px; /* Adjust font size for better readability */
    padding: 8px;
    word-wrap: break-word;
    white-space: normal;
  }
}


   </style>";?>
   
        
      <table>
        <p>Customer Information Table</p>
        <tr>
          <th>Reference Number</th>
          <th>Customer Name</th>
          <th>Address</th>
          <th>Customer Mobile Number</th>
          <th>Visit Type</th>
          <th>Bank Name</th>
          <th>Branch Name</th>
          <th>Case Type</th>
          
         <th>Engineer Name</th>
          <th>Re-Assign</th>
        </tr>


     
        <?php foreach ($results as $task): ?>
        <tr>
            <td data-label="Reference Number"><?= htmlspecialchars($task['reference_id']) ?></td>
            <td data-label="Customer Name"><?= htmlspecialchars($task['customerName']) ?></td>
            <td data-label="Address"><?= htmlspecialchars($task['address']) ?></td>
            <td data-label="Customer Mobile Number"><?= htmlspecialchars($task['customerMob']) ?></td>
            <td data-label="Visit Type"><?= htmlspecialchars($task['visitType']) ?></td>
            <td data-label="Bank Name"><?= htmlspecialchars($task['bankName']) ?></td>
            <td data-label="Branch Name"><?= htmlspecialchars($task['branchname']) ?></td>
            <td data-label="Case Type"><?= htmlspecialchars($task['caseType']) ?></td>
      
             <td>
                    <?= isset($engineerMap[$task['report_id']]) 
                        ? htmlspecialchars($engineerMap[$task['report_id']]) 
                        : 'Not Found' ?>
                </td>
            <td data-label="Assign">
    <a href="assginreport.php?reference_id=<?= urlencode($task['reference_id']) ?>
        &customerName=<?= urlencode($task['customerName']) ?>
        &bankName=<?= urlencode($task['bankName']) ?>
        &branchname=<?= urlencode($task['branchname']) ?>
        &applicationNo=<?= urlencode($task['applicationNo']) ?>
        &customerMob=<?= urlencode($task['customerMob']) ?>
        &caseType=<?= urlencode($task['caseType']) ?>
        &visitType=<?= urlencode($task['visitType']) ?>
        &address=<?= urlencode($task['address']) ?>" 
        class="upload-button" style="text-decoration:none;">
        Re-Assign 
    </a>
</td>

        </tr>
        <?php endforeach; ?>
        </table>
      <?php else: ?>
        <p style="text-align: center;">No data available</p>
      <?php endif; ?>
    </div>
  </div>
  </div>
<script>
  document.addEventListener("DOMContentLoaded", function () {
    let tabs = document.querySelectorAll(".tab-links .tab");
    let slider = document.querySelector(".tab-links .slider");

    function moveSlider(activeTab) {
        slider.style.width = activeTab.offsetWidth + "px";
        slider.style.left = activeTab.offsetLeft + "px";
    }

    tabs.forEach(tab => {
        tab.addEventListener("click", function () {
            tabs.forEach(t => t.classList.remove("active"));
            this.classList.add("active");
            moveSlider(this);
        });

        // Initialize position on load for the active tab
        if (tab.classList.contains("active")) {
            moveSlider(tab);
        }
    });
});

   document.getElementById("toggleSidebar").addEventListener("click", function() {
    var sidebar = document.getElementById("sidebar");
    var toggleButton = document.getElementById("toggleSidebar");
    
    sidebar.classList.toggle("active");
    
    // Toggle button state
    toggleButton.classList.toggle("active");
});

</script>
</body>
</html>
