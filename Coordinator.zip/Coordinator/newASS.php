<?php 
 include('auth.php');
// Database connection details
$host = 'localhost';
$db = 'project_db';
$user = 'root';
$pass = '';

try {
    // Create a new PDO instance
    $pdo = new PDO("mysql:host=$host;dbname=$db;charset=utf8", $user, $pass);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

    // Fetch only assignments where caseType is "FRESH"
    $query = "SELECT * FROM mis  ";
    $stmt = $pdo->prepare($query);
    $stmt->execute();

    // Fetch results
    $assignments = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    // Check if the form is submitted and redirect
    if ($_SERVER['REQUEST_METHOD'] === 'POST') {
        $reference_id = $_POST['reference_id'];
        $customerName = $_POST['customerName'];
        $address = $_POST['address'];
        $customerMob = $_POST['customerMob'];

        // Redirect to chooseFE1.php with the data as query parameters
        header("Location: chooseFE1.php?reference_id=" . urlencode($reference_id) . 
               "&customerName=" . urlencode($customerName) . 
               "&address=" . urlencode($address) . 
               "&customerMob=" . urlencode($customerMob));
        exit;
    }
} catch (PDOException $e) {
    echo "Error: " . $e->getMessage();
}
?>
<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Magpie Engineering</title>
  <link rel="stylesheet" href="newASS.css">
</head>

<body>
  <button class="toggle-btn" id="toggle-btn">☰</button>
  <div class="container">
    <!-- Sidebar -->

    <div class="sidebar" id="sidebar">
      <div style="display: flex;">
        <img class="logo" src="logo.png" alt="">
        <h1>Magpie Engineering</h1>
      </div>
      <a href="coordinator.php">Coordinator</a>
       
      <a href="assignRD.php">Assign Report Drafter</a>
     
      <a href="subASS.php">Subsequent Assignment List</a>
       
      <a href="issues.php">Issues</a>
      <a href="index.php">Logout</a>
    </div>

    <!-- Main Content -->
    <div class="content" id="content">
      <table>
        <p style="color: white; text-align:center;">NEW ASSIGNMENT LIST</p>
        <tr>
          <th>Reference Number</th>
          <th>Customer Name</th>
          <th>Address</th>
          <th>Customer Mobile Number</th>
          <th>Visit Type</th>
          <th>Bank Name</th>
          <th>branchname</th>
          <th>Case Type</th>
          <th>Application Number</th>
          <th>Mail ID</th>
          <th>Date</th>
          <th>Assign</th>
        </tr>
        <?php if (!empty($assignments)): ?>
            <?php foreach ($assignments as $assignment): ?>
                <tr>
                    <form action="newASS.php" method="POST">
                        <td><?= htmlspecialchars($assignment['reference_id']) ?></td>
                        <td><?= htmlspecialchars($assignment['customerName']) ?></td>
                        <td><?= htmlspecialchars($assignment['address']) ?></td>
                        <td><?= htmlspecialchars($assignment['customerMob']) ?></td>
                        <td><?= htmlspecialchars($assignment['visitType']) ?></td>
                        <td><?= htmlspecialchars($assignment['bankName']) ?></td>
                        <td><?= htmlspecialchars($assignment['branchname']) ?></td>
                        <td><?= htmlspecialchars($assignment['caseType']) ?></td>
                        <td><?= htmlspecialchars($assignment['applicationNo']) ?></td>
                        <td><?= htmlspecialchars($assignment['initiatorMailId']) ?></td>
                        <td><?= htmlspecialchars($assignment['initiationDate']) ?></td>
                        <td>
                            <!-- Hidden inputs to pass data to chooseFE1.php -->
                            <input type="hidden" name="reference_id" value="<?= htmlspecialchars($assignment['reference_id']) ?>">
                            <input type="hidden" name="customerName" value="<?= htmlspecialchars($assignment['customerName']) ?>">
                            <input type="hidden" name="address" value="<?= htmlspecialchars($assignment['address']) ?>">
                            <input type="hidden" name="customerMob" value="<?= htmlspecialchars($assignment['customerMob']) ?>">
                            <input type="hidden" name="visitType" value="<?= htmlspecialchars($assignment['visitType']) ?>">
                            <input type="hidden" name="bankName" value="<?= htmlspecialchars($assignment['bankName']) ?>">
                            <input type="hidden" name="branchname" value="<?= htmlspecialchars($assignment['branchname']) ?>">
                            <input type="hidden" name="caseType" value="<?= htmlspecialchars($assignment['caseType']) ?>">
                            <input type="hidden" name="applicationNo" value="<?= htmlspecialchars($assignment['applicationNo']) ?>">
                            <input type="hidden" name="initiatorMailId" value="<?= htmlspecialchars($assignment['initiatorMailId']) ?>">
                            <input type="hidden" name="initiationDate" value="<?= htmlspecialchars($assignment['initiationDate']) ?>">
                            <button type="submit">ASSIGN FIELD ENGINEER</button>
                        </td>
                    </form>
                </tr>
            <?php endforeach; ?>
        <?php else: ?>
            <tr><td colspan="11">No assignments found with case type "FRESH".</td></tr>
        <?php endif; ?>
      </table>
    </div>
  </div>
</body>
</html>
