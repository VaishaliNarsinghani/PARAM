<?php 
 include('auth.php');
// Database connection
$host = 'localhost';
$dbname = 'project_db';
$username = 'root';
$password = '';

try {
    $pdo = new PDO("mysql:host=$host;dbname=$dbname", $username, $password);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

    // Query to fetch assignment data
    $query = "SELECT reference_id, customerName, address, customerMob, visitType, 
                     bankName, caseType, applicationNo, initiatorMailId, initiationDate 
              FROM mis  WHERE caseType = 'Revise'";
    $stmt = $pdo->prepare($query);
    $stmt->execute();

    $assignments = $stmt->fetchAll(PDO::FETCH_ASSOC);
} catch (PDOException $e) {
    die("Database connection failed: " . $e->getMessage());
}
?>
<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Magpie Engineering</title>
  <link rel="stylesheet" href="revASS.css">
</head>

<body>
  <button class="toggle-btn" id="toggle-btn">☰</button>
  <div class="container">
    <!-- Sidebar -->

    <div class="sidebar" id="sidebar">
      <div style="display: flex;">
        <img class="logo" src="logo.png" alt="">
        <h1>Magpie Engineering</h1>
      </div>
      <a href="coordinator.php">Coordinator</a>
       
      <a href="assignRD.php">Assign Report Drafter</a>
       
      <a href="subASS.php" >Subsequent Assignment List</a>
      <a href="revASS.php" class="active">Revised Assignment List</a>
      <a href="issues.php">Issues</a>
      <a href="index.php">Logout</a>
    </div>

    <!-- Main Content -->
    <div class="content" id="content">
      <table>
        <p style="color: white; text-align:center;">LIST OF ASSIGNMENT TO BE REVISED</p>
        <tr>
          <th>Reference Number</th>
          <th>Customer Name</th>
          <th>Address</th>
          <th>Customer Mobile Number</th>
          <th>Visit Type</th>
          <th>Bank Name</th>
          <th>Case Type</th>
          <th>Application Number</th>
          <th>Mail ID</th>
          <th>Date</th>
          <th>Assign</th>
        </tr>
        <?php foreach ($assignments as $assignment): ?>
                    <tr>
                        <td data-label="Reference Number"><?= htmlspecialchars($assignment['reference_id']) ?></td>
                        <td data-label="Customer Name"><?= htmlspecialchars($assignment['customerName']) ?></td>
                        <td data-label="Address"><?= htmlspecialchars($assignment['address']) ?></td>
                        <td data-label="Customer Mobile Number"><?= htmlspecialchars($assignment['customerMob']) ?></td>
                        <td data-label="Visit Type"><?= htmlspecialchars($assignment['visitType']) ?></td>
                        <td data-label="Bank Name"><?= htmlspecialchars($assignment['bankName']) ?></td>
                        <td data-label="Case Type"><?= htmlspecialchars($assignment['caseType']) ?></td>
                        <td data-label="Application Number"><?= htmlspecialchars($assignment['applicationNo']) ?></td>
                        <td data-label="Mail ID"><?= htmlspecialchars($assignment['initiatorMailId']) ?></td>
                        <td data-label="Date"><?= htmlspecialchars($assignment['initiationDate']) ?></td>
                        <td><button class="assign-btn">Assign To Technical Manager</button></td>
                    </tr>
                <?php endforeach; ?>
            </table>
    </div>
  </div>

</body>

</html>