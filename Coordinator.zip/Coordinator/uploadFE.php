<?php include('auth.php'); ?>
 <?php
  // Start session before accessing session variables

// Database connection setup
$host = 'localhost';
$db = 'project_db';
$user = 'root';
$pass = '';
$message = '';

try {
    $pdo = new PDO("mysql:host=$host;dbname=$db;charset=utf8", $user, $pass);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (PDOException $e) {
    die('Database connection failed: ' . $e->getMessage());
}

// Check if coordinator is logged in
if (!isset($_SESSION['coordinator_id'])) {
    // Redirect to login page if not logged in
    header("Location: index.php");
    exit();
}

$engineer_id = $_SESSION['coordinator_id']; // Set engineer_id from session

// Fetch engineers for assignment
try {
    $managersQuery = "SELECT engineer_id, name FROM engineer_login";
    $managersStmt = $pdo->query($managersQuery);
    $managersResult = $managersStmt->fetchAll(PDO::FETCH_ASSOC);
} catch (PDOException $e) {
    die('Error fetching Engineers: ' . $e->getMessage());
}

// Ensure values are passed through GET
$reference_id = $_GET['reference_id'] ?? '';
$customerName = $_GET['customerName'] ?? '';
$address = $_GET['address'] ?? '';
$customerMob = $_GET['customerMob'] ?? '';
$visitType = $_GET['visitType'] ?? '';
$caseType = $_GET['caseType'] ?? '';
$bankName = $_GET['bankName'] ?? '';
$branchname = $_GET['branchname'] ?? '';
$applicationNo = $_GET['applicationNo'] ?? '';
$initiatorMailId = $_GET['initiatorMailId'] ?? '';
$initiationDate = $_GET['initiationDate'] ?? '';
$message = '';

// Fetch assignments excluding those that already have a technical manager assigned
try {
    $stmt = $pdo->query("SELECT * FROM mis WHERE technical_manager_id IS NULL AND flag_field_engineer IS NULL");
    $assignments = $stmt->fetchAll(PDO::FETCH_ASSOC);
} catch (PDOException $e) {
    $message = 'Error fetching assignments: ' . $e->getMessage();
}

// Assign task to field engineer
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['assign_task'])) {
    $selectedEngineerId = $_POST['engineer_id'] ?? '';
    $reference_id = $_POST['reference_id'] ?? '';

    if (!empty($selectedEngineerId) && !empty($reference_id)) {
        try {
            // Prepare the update query
            $stmt = $pdo->prepare("UPDATE mis 
                SET engineer_id = ?, 
                    field_engineer_to_coordinator = ?, 
                    assigned_at = CURRENT_TIMESTAMP, 
                    flag_field_engineer = 1 
                WHERE reference_id = ?");
        
            // Execute the query with bound parameters
            $stmt->execute([$selectedEngineerId, $engineer_id, $reference_id]);
        
            if ($stmt->rowCount() > 0) {
                $message = 'The assignment has been successfully assigned to the Field Officer with Reference ID: ' . htmlspecialchars($reference_id);
                // Redirect to clear form data
                header("Location: subASS.php" );
                exit();
            } else {
                $message = 'No record was updated. Please check the Reference ID.';
            }
        } catch (PDOException $e) {
            $message = 'Error assigning the task: ' . $e->getMessage();
        }
    } else {
        $message = 'Please select an Engineer and provide a valid Reference ID.';
    }
}

// Assign task to technical manager
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['assign_task_to_manager'])) {
    $selectedEngineerId = $_POST['engineer_id'] ?? '';
    $reference_id = $_POST['reference_id'] ?? '';

    if (!empty($selectedEngineerId) && !empty($reference_id)) {
        try {
            // Update the 'mis' table to assign the task to the selected technical manager
            $stmt = $pdo->prepare("UPDATE mis 
                SET flag_field_engineer = 1, 
                    field_engineer_to_coordinator = ?, 
                    assigned_at = CURRENT_TIMESTAMP 
                WHERE reference_id = ?");
            
            // Execute with bound parameters
            $stmt->execute([$selectedEngineerId, $reference_id]);

            if ($stmt->rowCount() > 0) {
                $message = 'Task has been successfully assigned to the Field Engineer.';
            } else {
                $message = 'No record updated. Please check the Reference ID.';
            }
        } catch (PDOException $e) {
            $message = 'Error: ' . $e->getMessage();
        }
    } else {
        $message = 'Please select an Engineer and provide a valid Reference ID.';
    }
}
?>

<!-- JavaScript for Alert -->
<script>
    <?php if (!empty($message)): ?>
    alert("<?= htmlspecialchars_decode(addslashes($message)) ?>");
    <?php endif; ?>
</script>


<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Assign Task to Technical Manager</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
    <link rel="stylesheet" href="chooseFE1.css">
</head>

<body>
    <button class="toggle-btn" id="toggle-btn">☰</button>
    <div class="container">
        <!-- Sidebar -->
        <div class="sidebar" id="sidebar">
            <div style="display: flex;">
                <img class="logo" src="logo.png" alt="Magpie Engineering Logo">
                <h1>Magpie Engineering</h1>
            </div>
            <div class="rotating-text">COORDINATOR</div>
        <a href="home.php"><i class="fas fa-home icon"></i> Home</a>
        <a href="coordinator.php"><i class="fas fa-user-friends icon"></i> Coordinator</a>
        <a href="assignRD.php"><i class="fas fa-tasks icon"></i> Assign Report Drafter</a>
           <a href="subASS.php"><i class="fas fa-file-alt icon"></i>Pending To Assign</a>
    <a href="assStatus.php"><i class="fas fa-chart-line icon"></i> Assignment Status</a>
        <a href="assField.php" class="active"><i class="fas fa-file-alt icon"></i>Assigned Field Engineers</a>
        <a href="assReport.php"><i class="fas fa-file-alt icon"></i>Assigned Report Drafters</a>
        <a href="issues.php"><i class="fas fa-exclamation-triangle icon"></i> Issues</a>
        <a href="index.php"><i class="fas fa-sign-out-alt icon"></i> Logout</a>
        </div>

        <!-- Content -->
        <div class="content" id="content">
            <div class="search-filters">
                <h2>Assign Task to Field Engineer</h2>
                <?php if (!empty($message)): ?>
                    <p style="color: green;"><?= htmlspecialchars($message) ?></p>
                <?php endif; ?>
                <form action="" method="POST">
                    <input type="text" name="reference_id" placeholder="Reference ID" value="<?= htmlspecialchars($reference_id) ?>" readonly>
                    <input type="text" name="customerName" placeholder="Customer Name" value="<?= htmlspecialchars($customerName) ?>" readonly>
                    <input type="text" name="address" placeholder="Address" value="<?= htmlspecialchars($address) ?>" required>
                    <input type="text" name="customerMob" placeholder="Customer Mobile" value="<?= htmlspecialchars($customerMob) ?>" readonly>
                    <input type="text" name="visitType" placeholder="Visit Type" value="<?= htmlspecialchars($visitType) ?>" readonly>
                    <input type="text" name="bankName" placeholder="Bank Name" value="<?= htmlspecialchars($bankName) ?>" readonly>
                    <input type="text" name="branchname" placeholder="Branch Name" value="<?= htmlspecialchars($branchname) ?>"readonly>
                    <input type="text" name="caseType" placeholder="Case Type" value="<?= htmlspecialchars($caseType) ?>" readonly>
                    <input type="text" name="applicationNo" placeholder="Application Number" value="<?= htmlspecialchars($applicationNo) ?>" readonly>
                    <input type="email" name="initiatorMailId" placeholder="Email ID" value="<?= htmlspecialchars($initiatorMailId) ?>" readonly>
                    <input type="date" name="initiationDate" placeholder="Initiation Date" value="<?= htmlspecialchars($initiationDate) ?>" readonly>
                    <form>
    <div class="form-row">
      <!-- Left Side: Label and Select Box -->
      <div class="form-left">
        <label for="field_engineer_id">Select Field Engineer:</label>
        <select name="engineer_id" id="field_engineer_id" required>
          <option value="" disabled selected>Select Engineer</option>
          <?php foreach ($managersResult as $manager): ?>
            <option value="<?= htmlspecialchars($manager['engineer_id']) ?>">
              <?= htmlspecialchars($manager['name']) ?>
            </option>
          <?php endforeach; ?>
        </select>
      </div>

      <button type="submit" name="assign_task"style="  background-color: #005f8a;">Assign Task</button>
    </div>
  </form>
            </div>
        </div>
    </div>

    <script>
        const toggleBtn = document.getElementById("toggle-btn");
        const sidebar = document.getElementById("sidebar");

        // Toggle Sidebar
        toggleBtn.addEventListener("click", () => {
            sidebar.classList.toggle("visible");
        });
    </script>
</body>

</html>
