<?php
$host = "localhost";
$user = "root";
$password = "";
$db = "project_db";

session_start();

$data = mysqli_connect($host, $user, $password, $db);
if ($data === false) {
    die("Connection error");
}

$error_message = "";

if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST["login"])) {
    $coordinator_id = trim($_POST["coordinator_id"]);
    $password = trim($_POST["password"]);
    $user_otp = trim($_POST["otp"]);

    // Validate coordinator ID and password
    $stmt = $data->prepare("SELECT * FROM coordinator_login WHERE coordinator_id = ?");
    $stmt->bind_param("s", $coordinator_id);
    $stmt->execute();
    $result = $stmt->get_result();
    $user = $result->fetch_assoc();
    $stmt->close();

    if ($user) {
        if ($password === $user["password"]) {
            // Check today's OTP
            $today = date("Y-m-d");
            $otp_stmt = $data->prepare("SELECT otp FROM otp_login WHERE date = ?");
            $otp_stmt->bind_param("s", $today);
            $otp_stmt->execute();
            $otp_result = $otp_stmt->get_result();
            $otp_row = $otp_result->fetch_assoc();
            $otp_stmt->close();

            if ($otp_row && $user_otp === $otp_row["otp"]) {
                // Successful login
                $_SESSION["coordinator_id"] = $coordinator_id;
                session_regenerate_id(true);

                header("Location:home.php");
                exit();
            } else {
                $error_message = "Invalid OTP.";
            }
        } else {
            $error_message = "Invalid login credentials.";
        }
    } else {
        $error_message = "No user found with the given Engineer ID.";
    }
}
?>



<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Magpie Engineering Login</title>
    <style>
        /* General body styling */
        body {
            margin: 0;
            padding: 0;
            font-family: 'Poppins', sans-serif;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
            background: linear-gradient(to bottom, rgba(68, 170, 214, 0.8), rgba(200, 230, 255, 0.9)), 
                        url('https://via.placeholder.com/1920x1080') no-repeat center center/cover; /* Replace placeholder */
            overflow: hidden;
        }

        /* Login container styling */
        .login-container {
            position: relative;
            z-index: 2;
            width: 100%;
            max-width: 400px;
            padding: 40px;
            background: rgba(255, 255, 255, 0.9); /* Light transparent white */
            border-radius: 20px;
            box-shadow: 0 10px 20px rgba(0, 0, 0, 0.2);
            color: #444; /* Dark text for readability */
            animation: fadeIn 1.5s ease-out;
        }

        .login-header {
            text-align: center;
            font-size: 28px;
            color:rgb(11, 11, 11); /* Complementary dark blue */
            font-weight: 700;
            margin-bottom: 20px;
            text-transform: uppercase;
            letter-spacing: 1.5px;
        }

        /* Input fields */
        .input-group {
            margin-bottom: 20px;
        }

        .input-field {
            width: 100%;
            padding: 15px;
            border: 1px solid #bbb;
            border-radius: 8px;
            font-size: 16px;
            color: #333;
            background: rgba(255, 255, 255, 0.8); /* Soft background */
            transition: 0.3s ease;
            outline: none;
        }

        .input-field:focus {
            border-color: #44aad6;
            box-shadow: 0 0 10px rgba(68, 170, 214, 0.4);
        }

        .input-field::placeholder {
            color: #aaa;
        }

        /* Login button */
        .login-btn {
            width: 100%;
            padding: 15px;
            background: #44aad6; /* Primary blue */
            border: none;
            border-radius: 8px;
            color: #fff;
            font-size: 18px;
            font-weight: bold;
            text-transform: uppercase;
            cursor: pointer;
            transition: 0.3s ease;
            box-shadow: 0 8px 15px rgba(68, 170, 214, 0.3);
        }

        .login-btn:hover {
            background: #3691b5;
            box-shadow: 0 10px 20px rgba(68, 170, 214, 0.4);
            transform: translateY(-2px);
        }
.error-message{
  color:red;
  font-size:17px;
  margin-top:5px;
  font-family:sans-serif;
  font-style:italic;
  font-weight:bold;
}

        /* Animations */
        @keyframes fadeIn {
            0% {
                opacity: 0;
                transform: scale(0.9);
            }
            100% {
                opacity: 1;
                transform: scale(1);
            }
        }

        /* Responsive Design */
        @media (max-width: 768px) {
            .login-container {
                padding: 30px;
            }

            .login-header {
                font-size: 24px;
            }
        }
    </style>
</head>
<body>
    <div class="login-container">
        <div class="login-header">
            Magpie Engineering Pvt. Ltd.
           <form id="loginForm" method="POST" action="index.php">
            <div class="input-group">
            <input type="text" name="coordinator_id" placeholder="User ID" class="input-field" required>
            </div>
            <div class="input-group">
            <input type="password" name="password" placeholder="Password" class="input-field" required>
            </div>
            <div class="input-group">
    <input type="text" name="otp" placeholder="Enter OTP" class="input-field" required>
</div>

            <button type="submit" name="login" class="login-btn">Log In</button>
            
        </form>
        <?php if (!empty($error_message)) : ?>
      <div class="error-message"><?php echo $error_message; ?></div>
    <?php endif; ?>
      </div>

</body>
</html>
