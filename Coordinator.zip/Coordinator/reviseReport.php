<?php include('auth.php'); ?>

<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Magpie Engineering</title>
  <link rel="stylesheet" href="reviseReport.css">
</head>

<body>
  <button class="toggle-btn" id="toggle-btn">☰</button>
  <div class="container">
    <!-- Sidebar -->

    <div class="sidebar" id="sidebar">
      <div style="display: flex;">
        <img class="logo" src="logo.png" alt="">
        <h1>Magpie Engineering</h1>
      </div>
      <a href="initiator.php">Initiator</a>
      <a href="createAss.php">Create New Assignment</a>
      <a href="createSubs.php">Create Subsequent</a>
      <a href="reviseReport.php" class="active">Revise Report</a>
      <a href="assignRD.php">Assign to Report Drafter</a>
      <a href="index.php">Logout</a>
    </div>

    <!-- Main Content -->
    <div class="content" id="content">
      <!-- Search Filters -->
      <div class="search-filters">
        <h2>Search Filters</h2>
        <form>
          <input type="text" placeholder="Reference ID" />
          <input type="text" placeholder="Customer Name" />
          <input type="text" placeholder="City" />
          <input type="text" placeholder="Application No." />
          <input type="text" placeholder="Bank Name" />
          <input type="text" placeholder="Loan Type" />
        </form>
        <button class="btn" type="submit"><a style="text-decoration: none; color: white;" href="searchREV.php">Search For Revise Report</a></button>
      </div>
    </div>
  </div>

  <script>
    const toggleBtn = document.getElementById("toggle-btn");
    const sidebar = document.getElementById("sidebar");

    // Toggle Sidebar
    toggleBtn.addEventListener("click", () => {
      sidebar.classList.toggle("visible");
    });
  </script>
</body>

</html>