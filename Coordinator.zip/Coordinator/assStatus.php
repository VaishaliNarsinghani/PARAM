<?php include('auth.php'); ?>
<?php
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

// DB Connection
$host = 'localhost';
$db = 'project_db';
$user = 'root';
$pass = '';

try {
    $pdo = new PDO("mysql:host=$host;dbname=$db;charset=utf8", $user, $pass);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (PDOException $e) {
    echo "Database error: " . $e->getMessage();
    exit;
}

$technical_id = $_SESSION['technical_manager_id'] ?? null;

// Fetch maps from related tables (you can keep using these for display if you prefer)
function fetchMap($pdo, $table, $keyColumn, $valueColumn) {
    $stmt = $pdo->query("SELECT $keyColumn, $valueColumn FROM $table");
    $map =[];
    while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
        $map[$row[$keyColumn]] = $row[$valueColumn];
    }
    return $map;
}
$engineerMap    = fetchMap($pdo, 'engineer_login', 'engineer_id', 'name');
$coordinatorMap = fetchMap($pdo, 'coordinator_login', 'coordinator_id', 'name');
$reportMap      = fetchMap($pdo, 'report_login', 'report_id', 'name');
$technicalMap   = fetchMap($pdo, 'technical_login', 'technical_manager_id', 'name');

// ----------------- Filters -----------------
$conditions = ['mis.flag_cso_submit = 0'];
$params = [];

$filters = [
    'reference_id' => 'mis.reference_id',
    'customerName' => 'mis.customerName',
    'address'      => 'mis.address',
    'customerMob'  => 'mis.customerMob',
    'visitType'    => 'mis.visitType',
    'bankName'     => 'mis.bankName',
    'branchname'   => 'mis.branchname'
];

foreach ($filters as $getKey => $dbColumn) {
    if (!empty(trim($_GET[$getKey] ?? ''))) {
        $conditions[] = "$dbColumn LIKE :$getKey";
        $params[$getKey] = '%' . trim($_GET[$getKey]) . '%';
    }
}

// Filters for staff names (search by name, uses joined tables)
if (!empty(trim($_GET['engineerName'] ?? ''))) {
    $conditions[] = "eng.name LIKE :engineerName";
    $params['engineerName'] = '%' . trim($_GET['engineerName']) . '%';
}
if (!empty(trim($_GET['coordinatorName'] ?? ''))) {
    $conditions[] = "coord.name LIKE :coordinatorName";
    $params['coordinatorName'] = '%' . trim($_GET['coordinatorName']) . '%';
}
if (!empty(trim($_GET['reportDrafterName'] ?? ''))) {
    $conditions[] = "rep.name LIKE :reportDrafterName";
    $params['reportDrafterName'] = '%' . trim($_GET['reportDrafterName']) . '%';
}
if (!empty(trim($_GET['technicalManagerName'] ?? ''))) {
    $conditions[] = "tech.name LIKE :technicalManagerName";
    $params['technicalManagerName'] = '%' . trim($_GET['technicalManagerName']) . '%';
}

// ----------------- Sorting (fixed using a map) -----------------
// friendly key from GET (what your header links should pass)
$sortKey = $_GET['sort'] ?? 'reference_id';

// order key (friendly, lower-case); we'll build SQL order value from it
$orderKey = strtolower($_GET['order'] ?? 'asc');
$orderSql = ($orderKey === 'desc') ? 'DESC' : 'ASC';

// map friendly sort keys to a safe SQL expression (column or alias)
$sortMap = [
    'reference_id'           => 'mis.reference_id',
    'customerName'           => 'mis.customerName',
    'address'                => 'mis.address',
    'customerMob'            => 'mis.customerMob',
    'visitType'              => 'mis.visitType',
    'bankName'               => 'mis.bankName',
    'branchname'             => 'mis.branchname',
    // these aliases are defined in the SELECT below
    'engineerName'           => 'engineerName',
    'coordinatorName'        => 'coordinatorName',
    'reportDrafterName'      => 'reportDrafterName',
    'technicalManagerName'   => 'technicalManagerName'
];

// validate sortKey, fallback to reference_id if invalid
if (!array_key_exists($sortKey, $sortMap)) {
    $sortKey = 'reference_id';
}
$sortSql = $sortMap[$sortKey]; // safe, pre-defined expression

// Build WHERE clause
$whereClause = $conditions ? 'WHERE ' . implode(' AND ', $conditions) : '';

// Main query with joins to expose staff names (so sorting by name works)
$sql = "
    SELECT 
        mis.*,
        eng.name AS engineerName,
        coord.name AS coordinatorName,
        rep.name AS reportDrafterName,
        tech.name AS technicalManagerName
    FROM mis
    LEFT JOIN engineer_login eng 
        ON mis.engineer_id = eng.engineer_id
    LEFT JOIN coordinator_login coord 
        ON mis.coordinator_id = coord.coordinator_id
    LEFT JOIN report_login rep 
        ON mis.report_id = rep.report_id
    LEFT JOIN technical_login tech 
        ON mis.report_drafter_to_technical = tech.technical_manager_id
    $whereClause
    ORDER BY $sortSql $orderSql
";

$stmt = $pdo->prepare($sql);
$stmt->execute($params);
$misRows = $stmt->fetchAll(PDO::FETCH_ASSOC);

// helper for next order in links
$nextOrder = ($orderKey === 'asc') ? 'desc' : 'asc';
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Magpie Engineering</title>
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
<style>body {
  font-family: Arial, sans-serif;
  margin: 0;
  padding: 0;
  /* background: url('https://yadurajrealty.com/wp-content/uploads/2024/10/All-You-Need-To-Know-About.webp') no-repeat center center fixed; */
  background-size: cover;
  color: #333;
}

body::before {
  content: "";
  position: absolute;
  top: -10px;
  left: 0;
  width: 100%;
  height: 100%;
  z-index: -1;
}

.container {
  display: flex;
  flex-direction: column;
  display: flex;
  min-height: 100vh;
  transition: all 0.3s ease;
  /* Stacks content vertically for small screens */
}
  .rotating-text {
    perspective: 1000px; /* Adds a 3D perspective effect */
    font-size: 2rem;
    font-weight:bold;
    animation: rotate360 3s linear infinite;
    display: inline-block;
    margin-bottom:10px;
    transform-origin: center center; /* Rotates around its center */
    text-align:center;
    font-style: italic;
    text-shadow: 
    1px 1px 2px rgba(235, 244, 243, 0.97),
    2px 2px 4px rgba(246, 242, 242, 0.4),
    3px 3px 6px rgba(249, 252, 252, 0.89),
    4px 4px 8px rgba(248, 242, 247, 0.93),
    5px 5px 10px rgba(232, 236, 237, 0.4);
  }
  
  /* Keyframes for rotating the text */
  @keyframes rotate360 {
    0% {
      transform: rotateY(0deg); /* Starts with no rotation */
    }
    50% {
      transform: rotateY(360deg); /* Half rotation */
    }
    100% {
      transform: rotateY(360deg); /* Full rotation */
    }
  }
    /* Sidebar */
    .sidebar {
      width: 250px;
      background: #B0C4DE; /* Light Steel Blue */
      color: #2C3E50; /* Dark Grayish Blue */
      padding:10px;
      
      height: 100vh;
      position: fixed;
      left: 0;
      top: 0;
      z-index: 1000;
      transition: transform 0.3s ease-in-out;
    }
    .sidebar.hidden {
      transform: translateX(-100%);
    }
    .sidebar h1 {
      font-size: 20px;
      margin-bottom: 20px;
    }
  
    .sidebar a {
      padding: 15px 20px;
        margin:19px 0;
        text-decoration: none;
        color: #2C3E50; /* Dark Grayish Blue */
        font-size:16px;
        font-style: italic;
        font-weight: 500;
        border-radius: 5px;
        transition: all 0.3s ease;
        display: flex;
        align-items: center;
    }

  .sidebar a:hover,
  .sidebar a.active {
    background: #4A90E2; /* Light Blue */
    color: white;
    transform: translateX(10px);
  }
  .sidebar a .icon {
      z-index: 1000;
      transition: transform 0.3s ease-in-out;
    }
    .sidebar.hidden {
      transform: translateX(-100%);
    }
    .sidebar h1 {
    margin-right: 15px;
    font-size: 18px;
  }
/* Toggle Button */
.toggle-btn {
  width: 10%;
  display: none;
  /* Hidden by default */
  position: fixed;
  top: 10px;
  left: 10px;
  background: none;
  color:black;
  padding: 10px 15px;
  border: none;
  border-radius: 5px;
  cursor: pointer;
  z-index: 1001;

}
.toggle-btn:hover {
  width: 10%;
  background: rgba(255, 255, 255, 0.288);
}

  /* Main Content */
  .content {
    margin-left: 270px;
    padding: 20px;
    animation: fadeIn 1.5s ease-in-out;
    transition: transform 0.3s ease-in-out;
  }

  .content.full-width {
    margin-left: 0;
  }

  /* Search Filters */
  .search-filters {
    background: hwb(210 92% 7%); /* Light Steel Blue */
          margin: 0 1% 0 2%; /* Use the same margin in both pages */

    padding: -5px;
    border-radius: 5px;
    box-shadow: 0 5px 15px rgba(247, 247, 247, 0.1);
    animation: slideIn 1s ease-in-out;
  }

  .search-filters h2 {
    margin-bottom: 20px;
      color: #2C3E50; /* Dark Grayish Blue */
    text-align: center;
    margin-left:auto;
  }

  .search-filters input,
  .search-filters button {
    background-color: rgba(255, 255, 255, 0.986);
    padding: 3px;
    margin: 5px;
    border: 1px solid #ccc;
    border-radius: 5px;
    width: 45%;
  }
/* Media Queries for Responsiveness */
@media (max-width: 768px) {
  .toggle-btn {
    display: block;
  }

  .sidebar {
    transform: translateX(-100%);
  }

  .sidebar.visible {
    transform: translateX(0);
  }

  .content {
    margin-left: 0;

  }

  .search-filters input,
  .search-filters button {
    width: 90%;
  }
}
.logo {
  width: 50px;
  height:50px;
  padding: 15px;
}
.content {
  margin: 0; /* Remove conflicting margins */
    margin-left: -100px;

  padding: 20px;
  animation: fadeIn 1.5s ease-in-out;
  transition: transform 0.3s ease-in-out;
}
a {
  text-decoration: none;
}
table {
  width: 100%;
  margin: 0 1% 0 1%; /* Use the same margin in both pages */
  border-collapse: collapse;
  margin-left:-20%;
  background:rgb(207, 222, 240);
  color: #2C3E50;
  border-radius: 10px;
  overflow: hidden;
  table-layout: fixed; /* Enforce fixed column widths */
  
}

th, td {
  padding: 12px;
  text-align: left;
  border: 1px solid rgba(255, 255, 255, 0.2);
  font-size: 15px;
  word-wrap: break-word; /* Allow wrapping of text */
  white-space: normal; /* Ensure wrapping is allowed */
  min-width: 100px; /* Set a minimum width for columns */
}

th {
  font-size: 13px;
  background-color:rgb(102, 146, 190);
   color:white;
  font-weight: bold;
}

table {
    table-layout: fixed; /* Enforces fixed column widths */
}

th, td {
     /* Adjust as needed for your preferred column width */
    word-wrap: break-word; /* Allows text to wrap onto the next line */
    white-space: normal; /* Ensures wrapping is allowed */
}


 tr:nth-child(even) {
   background-color:rgb(234, 236, 250);
 }

 tr:hover {
   background-color:rgb(138, 177, 215);
   color:white;
   font-weight:bolder;
   font-style:italic;
 }
 h2{
  margin-left:32% ; 
   font-style: oblique;
 color: #2C3E50;
 }
 button{
    padding:10px 10px;
    background-color: #005f8a;
    color: white;
    text-decoration: none;
    border: none;
    border-radius: 5px;
    cursor: pointer;
    font-size: 16px;
    margin-top:10px;
}

@media (max-width: 768px) {
  

.content {
  margin-left: -25px;
}

.search-filters input,
.search-filters button {
  width: 90%;
}
}
.content {
margin-left: 200px; /* Adjust based on sidebar width */
}

button {
  padding: 5px 10px;
  background-color: #005f8a;
  color: white;
  border: none;
  border-radius: 5px;
  cursor: pointer;
  font-size: 14px;
}

button a {
  text-decoration: none;
  color: white;
}

button:hover {
  background-color: #007aa3;
}

/* Responsive Table */
@media screen and (max-width: 768px) {

  table,
  thead,
  tbody,
  th,
  td,
  tr {
    display: block;
  }

  th {
    display: none;
  }

  td {
    position: relative;
    padding-left: 50%;
    text-align: right;
  }

  td::before {
    content: attr(data-label);
    position: absolute;
    left: 10px;
    font-weight: bold;
    text-transform: uppercase;
  }

  tr {
    margin-bottom: 15px;
  }

  button {
    width: 100%;
    padding: 10px;
  }
}
select{
  padding:10px;
text-align: left;
}
label{
  text-align: left;
}

p{
  color: #2C3E50;
 text-align:center;
 font-size:30px;
 font-style:oblique;
 font-weight: 100;
}

/* Assign Button Styling */
.upload-button {
background-color:rgb(102, 146, 190);
color: white; /* White text color */
border: 1px solid black; /* Black border */
border-radius: 5px; /* Rounded corners */
padding: 5px 10px; /* Padding for the button */
font-size: 14px; /* Font size */
font-weight: bold; /* Bold text */
text-align: center; /* Center the text */
cursor: pointer; /* Pointer cursor on hover */
display: inline-block; /* Inline-block for proper alignment */
}

.upload-buttona {
text-decoration:none; /* Remove underline */
color: white; /* Ensure the link text color is white */
display: inline-block; /* Ensure proper alignment inside the button */
width: 100%; /* Make it span the button */
height: 100%; /* Make it span the button */
}

/* Hover effect for the button */
.upload-button:hover {
background-color: #B0C4DE; /* Gray background on hover */
color: white; /* Maintain white text on hover */
}

    th a {
        text-decoration: none;
        color: inherit;
    }

.upload-button a:hover {
color: white; /* Ensure link remains white on hover */
}
/* Main Content */
  .content {
    margin-left: 270px;
    padding: 20px;
    animation: fadeIn 1.5s ease-in-out;
    transition: transform 0.3s ease-in-out;
  }
  .content.full-width {
    margin-left: 0;
  }
  .table-container {
  max-height: 495px; 
   max-width:1300px; /* Adjust height as needed */
  overflow-y: auto;
  overflow-x: auto;
  margin: 0 1% 0 0%;
  margin-left:-10%;
  border: 1px solid #ccc;
  border-radius: 10px;
  background-color: rgb(207, 222, 240);
}
  </style>
</head>
<body>

<button class="toggle-btn" id="toggle-btn">☰</button>
<div class="container">
  <div class="sidebar" id="sidebar">
    <div style="display: flex;">
      <img class="logo" src="logo.png" alt="">
      <h1>Magpie Engineering</h1>
    </div>
    <div class="rotating-text">COORDINATOR</div>
        <a href="home.php"><i class="fas fa-home icon"></i> Home</a>
        <a href="coordinator.php"><i class="fas fa-user-friends icon"></i> Coordinator</a>
        <a href="assignRD.php"><i class="fas fa-tasks icon"></i> Assign Report Drafter</a>
         <a href="subASS.php"><i class="fas fa-file-alt icon"></i>Pending To Assign</a>
         <a href="assStatus.php" class="active"><i class="fas fa-chart-line icon"></i> Assignment Status</a>
        <a href="assField.php"><i class="fas fa-file-alt icon"></i>Assigned Field Engineers</a>
        <a href="assReport.php"><i class="fas fa-file-alt icon"></i>Assigned Report Drafters</a>
        <a href="issues.php"><i class="fas fa-exclamation-triangle icon"></i> Issues</a>
        <a href="index.php"><i class="fas fa-sign-out-alt icon"></i> Logout</a>
    </div>
<div class="table-container">
       <table>       <?php         
         echo "
         <style>
/* Main Content */         
 .content {
  margin: 0; /* Remove conflicting margins */
  padding: 5px;
  animation: fadeIn 1.5s ease-in-out;
  transition: transform 0.3s ease-in-out;
}

table {
  width:150%;
  margin: 0 1% 0 11%; /* Use the same margin in both pages */
  border-collapse: collapse;
  background:rgb(207, 222, 240);
  color: #2C3E50;
  border-radius: 10px;
  overflow: hidden;
  table-layout: fixed; /* Enforce fixed column widths */
  
}

th, td {
  padding:10px;
  border: 1px solid rgba(255, 255, 255, 0.2);
  font-size: 15px;
  word-wrap: break-word; /* Allow wrapping of text */
  white-space: normal; /* Ensure wrapping is allowed */
  min-width:100px; /* Set a minimum width for columns */
}

th {
  font-size: 13px;
  background-color:rgb(102, 146, 190);
   color:white;
  font-weight: bold;
}

table {
    table-layout: fixed; /* Enforces fixed column widths */
}

th, td {
     /* Adjust as needed for your preferred column width */
    word-wrap: break-word; /* Allows text to wrap onto the next line */
    white-space: normal; /* Ensures wrapping is allowed */
}


 tr:nth-child(even) {
   background-color:rgb(234, 236, 250);
 }

 tr:hover {
   background-color:rgb(138, 177, 215);
   color:white;
   font-weight:bolder;
   font-style:italic;
 }
h2{
  margin-left:38% ; 
   font-style: oblique;
 color: #2C3E50;
 }
 button{
    padding:10px 10px;
    background-color:rgb(102, 146, 190);
    color: white;
    text-decoration: none;
    border: none;
    border-radius: 5px;
    cursor: pointer;
    font-size: 16px;
    margin-top:10px;
}

.content {
margin-left: 270px; /* Adjust based on sidebar width */
}


@media (min-width: 1200px) {

@media (max-width: 768px) {
.content {
margin-left: 0px; /* Adjust based on sidebar width */
}
.toggle-btn {
 display: block;
}

.sidebar {
 transform: translateX(-100%);
}

.sidebar.visible {
 transform: translateX(0);
}
 
}

@keyframes slideIn {
from {
 transform: translateX(-100%);
 opacity: 0;
}

to {
 transform: translateX(0);
 opacity: 1;
}
}

@keyframes fadeIn {
from {
 opacity: 0;
}

to {
 opacity: 1;
}
}

.logo {
  width: 50px;
  height:50px;
  padding: 15px;
}
  /* Assign Button Styling */
.upload-button {
background-color:rgb(102, 146, 190);
color: white; /* White text color */
border: 1px solid black; /* Black border */
border-radius: 5px; /* Rounded corners */
padding: 5px 6px; /* Padding for the button */
font-size: 14px; /* Font size */
font-weight: bold; /* Bold text */
text-align: center; /* Center the text */
cursor: pointer; /* Pointer cursor on hover */
display: inline-block; /* Inline-block for proper alignment */
}

.upload-button a {
text-decoration:none; /* Remove underline */
color: white; /* Ensure the link text color is white */
display: inline-block; /* Ensure proper alignment inside the button */
width: 100%; /* Make it span the button */
height: 100%; /* Make it span the button */
}

/* Hover effect for the button */
.upload-button:hover {
background-color: #B0C4DE; /* Gray background on hover */
color: white; /* Maintain white text on hover */
}

.upload-button a:hover {
color: white; /* Ensure link remains white on hover */
}
@media (max-width: 768px) {
  .content {
    margin-left: 0 !important; /* Remove unwanted left margin */
    padding: 10px;
    display: flex;
    justify-content: center;
    align-items: center;
    flex-direction: column;
  }

  table {
    width: 90% !important; /* Ensure the table takes up most of the screen */
    margin: 0 auto !important; /* Center the table horizontally */
    display: block;
    overflow-x: auto; /* Enable horizontal scrolling if needed */
    text-align: center;
  }

  th, td {
    font-size: 14px; /* Adjust font size for better readability */
    padding: 8px;
    word-wrap: break-word;
    white-space: normal;
  }
}

/* Scrollable Table Container */


/* Formal Font Style */
table, th, td {
  font-family: 'Times New Roman', Times, serif; /* Formal font */
}

/* Make the table header fixed */
.table-container thead th {
  position:fixed;
  top: 0;
  background-color: rgb(102, 146, 190); /* Same as your header color */
  z-index: 1;
}
   </style>";?></table></div>
 <div class="content" id="content">
    <div class="search-filters">
      <h2>Search Filters</h2>
      <form id="searchForm" method="GET" action="assStatus.php">
        <div class="form-row">
          <input type="text" name="reference_id" placeholder="Reference Number" value="<?= htmlspecialchars($_GET['reference_id'] ?? '') ?>" />
          <input type="text" name="customerName" placeholder="Customer Name" value="<?= htmlspecialchars($_GET['customerName'] ?? '') ?>" />
        </div>
        <div class="form-row">
          <input type="text" name="address" placeholder="Address" value="<?= htmlspecialchars($_GET['address'] ?? '') ?>" />
          <input type="text" name="customerMob" placeholder="Customer Mobile Number" value="<?= htmlspecialchars($_GET['customerMob'] ?? '') ?>" />
        </div>
        <div class="form-row">
          <input type="text" name="visitType" placeholder="Visit Type" value="<?= htmlspecialchars($_GET['visitType'] ?? '') ?>" />
          <input type="text" name="bankName" placeholder="Bank Name" value="<?= htmlspecialchars($_GET['bankName'] ?? '') ?>" />
        </div>
        <div class="form-row">
          <input type="text" name="branchname" placeholder="Branch Name" value="<?= htmlspecialchars($_GET['branchname'] ?? '') ?>" />
          <input type="text" name="engineerName" placeholder="Engineer Name" value="<?= htmlspecialchars($_GET['engineerName'] ?? '') ?>" />
        </div>
        <div class="form-row">
          <button type="submit" style="background: #4A90E2; color: white; padding: 3px 8px;">Search</button>
        </div>
      </form>
    </div>
<div class="table-container">

    <?php if (!empty($misRows)): ?>
<table border="1" cellpadding="5" cellspacing="0" >
  <tr style=" position:sticky;">
    <th>Reference Number</th>
<th>
    <a href="?<?= http_build_query(array_merge($_GET, ['sort' => 'customerName', 'order' => $nextOrder])) ?>">
        Customer Name
        <?php if ($sortKey === 'customerName'): ?>
            <?= ($orderKey === 'asc') ? '↑' : '↓' ?>
        <?php endif; ?>
    </a>
</th>
    <th>Address</th>
    <th>Customer Mobile Number</th>
    <th>Visit Type</th>
<th>
    <a href="?<?= http_build_query(array_merge($_GET, ['sort' => 'bankName', 'order' => $nextOrder])) ?>">
        Bank Name
        <?php if ($sortKey === 'bankName'): ?>
            <?= ($orderKey === 'asc') ? '↑' : '↓' ?>
        <?php endif; ?>
    </a>
</th>
<th>
    <a href="?<?= http_build_query(array_merge($_GET, ['sort' => 'branchname', 'order' => $nextOrder])) ?>">
        Branch Name
        <?php if ($sortKey === 'branchname'): ?>
            <?= ($orderKey === 'asc') ? '↑' : '↓' ?>
        <?php endif; ?>
    </a>
</th>

    <th>Application No</th>
<th>
    <a href="?<?= http_build_query(array_merge($_GET, ['sort' => 'engineerName', 'order' => $nextOrder])) ?>">
        Engineer Name
        <?php if ($sortKey === 'engineerName'): ?>
            <?= ($orderKey === 'asc') ? '↑' : '↓' ?>
        <?php endif; ?>
    </a>
</th>

    <th>Engineer Assigned At</th>

<th>
    <a href="?<?= http_build_query(array_merge($_GET, ['sort' => 'coordinatorName', 'order' => $nextOrder])) ?>">
        Coordinator Name
        <?php if ($sortKey === 'coordinatorName'): ?>
            <?= ($orderKey === 'asc') ? '↑' : '↓' ?>
        <?php endif; ?>
    </a>
</th>
    <th>Coordinator Assigned At</th>  

<th>
    <a href="?<?= http_build_query(array_merge($_GET, ['sort' => 'reportDrafterName', 'order' => $nextOrder])) ?>">
        Report Drafter Name
        <?php if ($sortKey === 'reportDrafterName'): ?>
            <?= ($orderKey === 'asc') ? '↑' : '↓' ?>
        <?php endif; ?>
    </a>
</th>

    <th>Report Drafter Assigned At</th>
  
<th>
    <a href="?<?= http_build_query(array_merge($_GET, ['sort' => 'technicalManagerName', 'order' => $nextOrder])) ?>">
        Technical Manager Name
        <?php if ($sortKey === 'technicalManagerName'): ?>
            <?= ($orderKey === 'asc') ? '↑' : '↓' ?>
        <?php endif; ?>
    </a>
</th>
    <th>Technical Manager Assigned At</th>
    <th>CSO Assigned At</th>
  </tr>
  <?php foreach ($misRows as $task): ?>
  <tr>
    <td><?= htmlspecialchars($task['reference_id'] ?? '') ?></td>
    <td><?= htmlspecialchars($task['customerName'] ?? '') ?></td>
    <td><?= htmlspecialchars($task['address'] ?? '') ?></td>
    <td><?= htmlspecialchars($task['customerMob'] ?? '') ?></td>
    <td><?= htmlspecialchars($task['visitType'] ?? '') ?></td>
    <td><?= htmlspecialchars($task['bankName'] ?? '') ?></td>
    <td><?= htmlspecialchars($task['branchname'] ?? '') ?></td>
    <td><?= htmlspecialchars($task['applicationNo'] ?? '') ?></td>
     <td><?= htmlspecialchars($engineerMap[$task['engineer_id']] ?? '') ?></td>
    <td><?= htmlspecialchars($task['assigned_at'] ?? '') ?></td>
    <td><?= htmlspecialchars($coordinatorMap[$task['coordinator_id']] ?? '') ?></td>
    <td><?= htmlspecialchars($task['assigned_at_coordinator'] ?? '') ?></td>
    <td><?= htmlspecialchars($reportMap[$task['report_id']] ?? '') ?></td>
    <td><?= htmlspecialchars($task['report_assigned_at'] ?? '') ?></td>
    <td><?= htmlspecialchars($technicalMap[$task['report_drafter_to_technical']] ?? '') ?></td>
    <td><?= htmlspecialchars($task['report_to_technical_assigned_at'] ?? '') ?></td>
    <td><?= htmlspecialchars($task['technical_to_cso_assigned_at'] ?? '') ?></td>
  </tr>
  <?php endforeach; ?>
</table>
<?php else: ?>
  <p style="text-align: center;">No data available</p>
<?php endif; ?>
</div>
  </div>
</div>

<script>
  const toggleBtn = document.getElementById("toggle-btn");
  const sidebar = document.getElementById("sidebar");
  toggleBtn.addEventListener("click", () => {
    sidebar.classList.toggle("visible");
  });
</script>

</body>
</html>
