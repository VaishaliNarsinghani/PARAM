<?php 
 include('auth.php');
// Database connection setup
$host = 'localhost';
$db = 'project_db';
$user = 'root';
$pass = '';
$message = '';
try {
    $pdo = new PDO("mysql:host=$host;dbname=$db;charset=utf8", $user, $pass);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (PDOException $e) {
    die('Database connection failed: ' . $e->getMessage());
}

// Check if coordinator_id is set in session (i.e., user is logged in)
if (!isset($_SESSION['coordinator_id'])) {
    // Redirect to login page if not logged in
    header("Location:index.php");
    exit();
}

$coordinator_id = $_SESSION['coordinator_id'];

$data = [];
try {
    // Fetch data where field_engineer_to_coordinator matches logged-in coordinator_id
    $query = "
        SELECT 
            m.reference_id,
            m.customerName,
            m.address,
            m.customerMob,
            m.visitType,
            m.bankName,
            m.branchname,
            m.caseType,
            m.applicationNo,
            m.initiatorMailId,
            m.initiationDate
        FROM mis m
        INNER JOIN uploaded_images u ON m.reference_id = u.reference_id
        WHERE m.flag_report_drafter != 1
        AND m.field_engineer_to_coordinator = :coordinator_id
        AND m.flag_not_built = 0
    ";
    $stmt = $pdo->prepare($query);
    $stmt->bindParam(':coordinator_id', $coordinator_id, PDO::PARAM_STR);
    $stmt->execute();
    $data = $stmt->fetchAll(PDO::FETCH_ASSOC);
} catch (PDOException $e) {
    die("Error fetching data: " . $e->getMessage());
}
?>


<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Magpie Engineering</title>
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
  <link rel="stylesheet" href="assignRD2.css">
</head>

<body>
  <button class="toggle-btn" id="toggle-btn">☰</button>
  <div class="container">
    <!-- Sidebar -->
    <div class="sidebar" id="sidebar">
      <div style="display: flex;">
        <img class="logo" src="logo.png" alt="">
        <h1>Magpie Engineering</h1>
      </div>
      <div class="rotating-text">COORDINATOR</div>
      <a href="home.php"><i class="fas fa-home icon"></i> Home</a>
      <a href="coordinator.php"><i class="fas fa-user-friends icon"></i> Coordinator</a>
      <a href="assignRD.php" class="active"><i class="fas fa-tasks icon"></i> Assign Report Drafter</a>
         <a href="subASS.php"><i class="fas fa-file-alt icon"></i>Pending To Assign</a>
    <a href="assStatus.php"><i class="fas fa-chart-line icon"></i> Assignment Status</a>
        <a href="assField.php"><i class="fas fa-file-alt icon"></i>Assigned Field Engineers</a>
        <a href="assReport.php"><i class="fas fa-file-alt icon"></i>Assigned Report Drafters</a>
      <a href="issues.php"><i class="fas fa-exclamation-triangle icon"></i> Issues</a>
      <a href="index.php"><i class="fas fa-sign-out-alt icon"></i> Logout</a>
    </div>

    <!-- Main Content -->
    <div class="content" id="content">
      <p>Customer Information Table</p> <!-- Moved outside the <table> -->
      <table>
        <tr>
          <th>Reference Number</th>
          <th>Customer Name</th>
          <th>Address</th>
          <th>Customer Mobile Number</th>
          <th>Visit Type</th>
          <th>Bank Name</th>
          <th>Branch Name</th>
          <th>Case Type</th>
          <th>Application Number</th>
          <th>Mail ID</th>
          <th>Date</th>
          <th>Assign</th>
        </tr>
        <?php if (!empty($data)): ?>
          <?php foreach ($data as $row): ?>
            <tr>
              <td><?= htmlspecialchars($row['reference_id']) ?></td>
              <td><?= htmlspecialchars($row['customerName']) ?></td>
              <td><?= htmlspecialchars($row['address']) ?></td>
              <td><?= htmlspecialchars($row['customerMob']) ?></td>
              <td><?= htmlspecialchars($row['visitType']) ?></td>
              <td><?= htmlspecialchars($row['bankName']) ?></td>
              <td><?= htmlspecialchars($row['branchname']) ?></td>
              <td><?= htmlspecialchars($row['caseType']) ?></td>
              <td><?= htmlspecialchars($row['applicationNo']) ?></td>
              <td><?= htmlspecialchars($row['initiatorMailId']) ?></td>
              <td><?= htmlspecialchars($row['initiationDate']) ?></td>
              <td>
              <button class="assign-button">
  <a href="chooseRD.php?assignmentId=<?= urlencode($row['id'] ?? '') ?>&reference_id=<?= urlencode($row['reference_id']) ?>&customerName=<?= urlencode($row['customerName']) ?>&address=<?= urlencode($row['address']) ?>&customerMob=<?= urlencode($row['customerMob']) ?>&visitType=<?= urlencode($row['visitType']) ?>&bankName=<?= urlencode($row['bankName']) ?>&branchname=<?= urlencode($row['branchname']) ?>&caseType=<?= urlencode($row['caseType']) ?>&applicationNo=<?= urlencode($row['applicationNo']) ?>&initiatorMailId=<?= urlencode($row['initiatorMailId']) ?>&initiationDate=<?= urlencode($row['initiationDate']) ?>">SelectRD</a>
</button>

              </td>
            </tr>
          <?php endforeach; ?>
        <?php else: ?>
          <tr>
            <td colspan="12" style="text-align: center;">No data available</td>
          </tr>
        <?php endif; ?>
      </table>
    </div>
  </div>

  <script>
    const toggleBtn = document.getElementById("toggle-btn");
    const sidebar = document.getElementById("sidebar");

    // Toggle Sidebar
    toggleBtn.addEventListener("click", () => {
      sidebar.classList.toggle("visible");
    });
  </script>
</body>

</html>
