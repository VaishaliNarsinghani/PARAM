<?php include('auth.php'); ?>


<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Magpie Engineering</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
    <link rel="stylesheet" href="coordinator2.css">
  </head>
  <body>
    <button class="toggle-btn" id="toggle-btn">☰</button>
    <div class="container">
      <!-- Sidebar -->
      <div class="sidebar" id="sidebar">
        <div style="display: flex">
          <img class="logo" src="logo.png" alt="" />
          <h1>Magpie Engineering</h1>
        </div>
        <div class="rotating-text">COORDINATOR</div>
        <a href="home.php"><i class="fas fa-home icon"></i> Home</a>
        <a href="coordinator.php" class="active"><i class="fas fa-user-friends icon"></i> Coordinator</a>
        <a href="assignRD.php"><i class="fas fa-tasks icon"></i> Assign Report Drafter</a>
   <a href="subASS.php"><i class="fas fa-file-alt icon"></i>Pending To Assign</a>
    <a href="assStatus.php"><i class="fas fa-chart-line icon"></i> Assignment Status</a>
        <a href="assField.php"><i class="fas fa-file-alt icon"></i>Assigned Field Engineers</a>
        <a href="assReport.php"><i class="fas fa-file-alt icon"></i>Assigned Report Drafters</a>        <a href="issues.php"><i class="fas fa-exclamation-triangle icon"></i> Issues</a>
        <a href="index.php"><i class="fas fa-sign-out-alt icon"></i> Logout</a>
      </div>

      <!-- Main Content -->
      <div class="content" id="content">
        <div class="status-container">
          <!-- Field Engineer Status -->
          <div class="status-box">
            <h3>Field Engineer Status</h3>
            <div class="assignment">Today's Assignments: 2</div>
            <div class="assignment">Active Assignments: 14</div>
            <div class="assignment">Pending Assignments: 6</div>
          </div>

          <!-- Report Drafter Status -->
          <div class="status-box">
            <h3>Report Drafter Status</h3>
            <div class="assignment">Today's Assignments: 2</div>
            <div class="assignment">Active Assignments: 14</div>
            <div class="assignment">Pending Assignments: 6</div>
          </div>

          <!-- Technical Manager Status -->
          <div class="status-box">
            <h3>Technical Manager Status</h3>
            <div class="assignment">Today's Assignments: 2</div>
            <div class="assignment">Active Assignments: 14</div>
            <div class="assignment">Pending Assignments: 6</div>
          </div>

          <!-- Customer Service Officer Status -->
          <div class="status-box">
            <h3>Customer Service Officer Status</h3>
            <div class="assignment">Today's Assignments: 2</div>
            <div class="assignment">Active Assignments: 14</div>
            <div class="assignment">Pending Assignments: 6</div>
          </div>
        </div>
      </div>
    </div>

    <script>
      const toggleBtn = document.getElementById("toggle-btn");
      const sidebar = document.getElementById("sidebar");

      // Toggle Sidebar
      toggleBtn.addEventListener("click", () => {
        sidebar.classList.toggle("visible");
      });
    </script>
  </body>
</html>
