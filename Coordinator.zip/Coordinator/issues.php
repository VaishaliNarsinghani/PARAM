<?php include('auth.php'); ?>
<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Magpie Engineering</title>
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
  <link rel="stylesheet" href="issues2.css">
</head>

<body>
  <button class="toggle-btn" id="toggle-btn">☰</button>
  <div class="container">

    <div class="sidebar" id="sidebar">
      <div style="display: flex;">
        <img class="logo" src="logo.png" alt="">
        <h1>Magpie Engineering</h1>
      </div>
      <div class="rotating-text">COORDINATOR</div>
      <a href="home.php"><i class="fas fa-home icon"></i> Home</a>
      <a href="coordinator.php"><i class="fas fa-user-friends icon"></i> Coordinator</a>
      <a href="assignRD.php"><i class="fas fa-tasks icon"></i> Assign Report Drafter</a>
         <a href="subASS.php"><i class="fas fa-file-alt icon"></i>Pending To Assign</a>
    <a href="assStatus.php"><i class="fas fa-chart-line icon"></i> Assignment Status</a>
        <a href="assField.php"><i class="fas fa-file-alt icon"></i>Assigned Field Engineers</a>
        <a href="assReport.php"><i class="fas fa-file-alt icon"></i>Assigned Report Drafters</a>
      <a href="issues.php" class="active"><i class="fas fa-exclamation-triangle icon"></i> Issues</a>
      <a href="index.php"><i class="fas fa-sign-out-alt icon"></i> Logout</a>
    </div>

    <div class="content" id="content">
      <p>ISSUE RAISAL WINDOW</p>
      <table>
        <tr>
          <th>Reference Number</th>
          <th>Customer Name</th>
          <th>Address</th>
          <th>Customer Mobile Number</th>
          <th>Visit Type</th>
          <th>Bank Name</th>
          <th>Case Type</th>
          <th>Application Number</th>
          <th style= "width: 30%; font-size:17px; text-                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                        :center">Issue</th>
          <th style= "width:10%;">Reassign</th>
        </tr>

        <?php
        // DB connection
        $host = 'localhost';
        $db = 'project_db';
        $user = 'root';
        $pass = '';

        try {
            $pdo = new PDO("mysql:host=$host;dbname=$db", $user, $pass);
            $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

            // Fetch only flagged issues
            $stmt = $pdo->query("SELECT reference_id, customerName, address, customerMob, visitType, bankName, caseType, applicationNo, raise_issue 
            FROM mis 
            WHERE engineer_to_coordinator_issue_flag = 1");

            while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
              echo "<tr>";
              echo "<td data-label='Reference Number'>" . htmlspecialchars($row['reference_id']) . "</td>";
              echo "<td data-label='Customer Name'>" . htmlspecialchars($row['customerName']) . "</td>";
              echo "<td data-label='Address'>" . htmlspecialchars($row['address']) . "</td>";
              echo "<td data-label='Customer Mobile Number'>" . htmlspecialchars($row['customerMob']) . "</td>";
              echo "<td data-label='Visit Type'>" . htmlspecialchars($row['visitType']) . "</td>";
              echo "<td data-label='Bank Name'>" . htmlspecialchars($row['bankName']) . "</td>";
              echo "<td data-label='Case Type'>" . htmlspecialchars($row['caseType']) . "</td>";
              echo "<td data-label='Application Number'>" . htmlspecialchars($row['applicationNo']) . "</td>";
              echo "<td data-label='Issue'><div class='issue-text'>" . (htmlspecialchars($row['raise_issue'])) . "</div></td>";
               echo "<td><button>Reasaign</button></td>";
              echo "</tr>";
            }

        } catch (PDOException $e) {
            echo "<tr><td colspan='11'>Database error: " . $e->getMessage() . "</td></tr>";
        }
        ?>
      </table>
    </div>
  </div>

  <script>
    const toggleBtn = document.getElementById("toggle-btn");
    const sidebar = document.getElementById("sidebar");
    toggleBtn.addEventListener("click", () => {
      sidebar.classList.toggle("visible");
    });
  </script>
</body>

</html>
