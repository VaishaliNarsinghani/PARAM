<?php include('auth.php'); ?>
<?php
 

$host = 'localhost';
$db = 'project_db';
$user = 'root';
$pass = '';

try {
    $pdo = new PDO("mysql:host=$host;dbname=$db", $user, $pass);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (PDOException $e) {
    echo "Database error: " . $e->getMessage();
    exit;
}

// ✅ Fetch unsubmitted tasks with assigned engineers
$sql = "SELECT * FROM mis WHERE engineer_id IS NOT NULL AND flag_fe_submit = FALSE";
$stmt = $pdo->prepare($sql);
$stmt->execute();
$results = $stmt->fetchAll(PDO::FETCH_ASSOC);
?>
<?php
 

// PDO Connection
$host = 'localhost';
$db = 'project_db';
$user = 'root';
$pass = '';

try {
    $pdo = new PDO("mysql:host=$host;dbname=$db", $user, $pass);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (PDOException $e) {
    die("Database error: " . $e->getMessage());
}

// Step 1: Fetch all mis entries with an assigned engineer
$sql = "SELECT * FROM mis WHERE engineer_id IS NOT NULL AND flag_fe_submit = FALSE";
$stmt = $pdo->prepare($sql);
$stmt->execute();
$misRows = $stmt->fetchAll(PDO::FETCH_ASSOC);

// Step 2: Fetch all engineer IDs and names in one go (avoid querying inside a loop)
$engineerStmt = $pdo->query("SELECT engineer_id, name FROM engineer_login");
$engineerMap = [];
while ($row = $engineerStmt->fetch(PDO::FETCH_ASSOC)) {
    $engineerMap[$row['engineer_id']] = $row['name'];
}
?>


<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Magpie Engineering</title>
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
  <link rel="stylesheet" href="assfield.css">
</head>

<body>
  <button class="toggle-btn" id="toggle-btn">☰</button>
  <div class="container">
    <!-- Sidebar -->

    <div class="sidebar" id="sidebar">
      <div style="display: flex;">
        <img class="logo" src="logo.png" alt="">
        <h1>Magpie Engineering</h1>
      </div>
      <div class="rotating-text">COORDINATOR</div>
        <a href="home.php"><i class="fas fa-home icon"></i> Home</a>
        <a href="coordinator.php"><i class="fas fa-user-friends icon"></i> Coordinator</a>
        <a href="assignRD.php"><i class="fas fa-tasks icon"></i> Assign Report Drafter</a>
           <a href="subASS.php"><i class="fas fa-file-alt icon"></i>Pending To Assign</a>
    <a href="assStatus.php"><i class="fas fa-chart-line icon"></i> Assignment Status</a>
        <a href="assField.php"  class="active"><i class="fas fa-file-alt icon"></i>Assigned Field Engineers</a>
        <a href="assReport.php"><i class="fas fa-file-alt icon"></i>Assigned Report Drafters</a>
        <a href="issues.php"><i class="fas fa-exclamation-triangle icon"></i> Issues</a>
        <a href="index.php"><i class="fas fa-sign-out-alt icon"></i> Logout</a>
    </div>

    <?php
    if (!empty($results)): ?>
       <table>       <?php         
         echo "
         <style>
/* Main Content */         
 .content {
  margin: 0; /* Remove conflicting margins */
  padding: 20px;
  animation: fadeIn 1.5s ease-in-out;
  transition: transform 0.3s ease-in-out;
}

table {
  width:75%;
  margin: 0 1% 0 24%; /* Use the same margin in both pages */
  border-collapse: collapse;
  background:rgb(207, 222, 240);
  color: #2C3E50;
  border-radius: 10px;
  overflow: hidden;
  table-layout: fixed; /* Enforce fixed column widths */
  
}

th, td {
  padding:10px;
  border: 1px solid rgba(255, 255, 255, 0.2);
  font-size: 15px;
  word-wrap: break-word; /* Allow wrapping of text */
  white-space: normal; /* Ensure wrapping is allowed */
  min-width:100px; /* Set a minimum width for columns */
}

th {
  font-size: 13px;
  background-color:rgb(102, 146, 190);
   color:white;
  font-weight: bold;
}

table {
    table-layout: fixed; /* Enforces fixed column widths */
}

th, td {
     /* Adjust as needed for your preferred column width */
    word-wrap: break-word; /* Allows text to wrap onto the next line */
    white-space: normal; /* Ensures wrapping is allowed */
}


 tr:nth-child(even) {
   background-color:rgb(234, 236, 250);
 }

 tr:hover {
   background-color:rgb(138, 177, 215);
   color:white;
   font-weight:bolder;
   font-style:italic;
 }
h2{
  margin-left:38% ; 
   font-style: oblique;
 color: #2C3E50;
 }
 button{
    padding:10px 10px;
    background-color:rgb(102, 146, 190);
    color: white;
    text-decoration: none;
    border: none;
    border-radius: 5px;
    cursor: pointer;
    font-size: 16px;
    margin-top:10px;
}

.content {
margin-left: 270px; /* Adjust based on sidebar width */
}


@media (min-width: 1200px) {

@media (max-width: 768px) {
.content {
margin-left: 0px; /* Adjust based on sidebar width */
}
.toggle-btn {
 display: block;
}

.sidebar {
 transform: translateX(-100%);
}

.sidebar.visible {
 transform: translateX(0);
}
 
}

@keyframes slideIn {
from {
 transform: translateX(-100%);
 opacity: 0;
}

to {
 transform: translateX(0);
 opacity: 1;
}
}

@keyframes fadeIn {
from {
 opacity: 0;
}

to {
 opacity: 1;
}
}

.logo {
  width: 50px;
  height:50px;
  padding: 15px;
}
  /* Assign Button Styling */
.upload-button {
background-color:rgb(102, 146, 190);
color: white; /* White text color */
border: 1px solid black; /* Black border */
border-radius: 5px; /* Rounded corners */
padding: 5px 6px; /* Padding for the button */
font-size: 14px; /* Font size */
font-weight: bold; /* Bold text */
text-align: center; /* Center the text */
cursor: pointer; /* Pointer cursor on hover */
display: inline-block; /* Inline-block for proper alignment */
}

.upload-button a {
text-decoration:none; /* Remove underline */
color: white; /* Ensure the link text color is white */
display: inline-block; /* Ensure proper alignment inside the button */
width: 100%; /* Make it span the button */
height: 100%; /* Make it span the button */
}

/* Hover effect for the button */
.upload-button:hover {
background-color: #B0C4DE; /* Gray background on hover */
color: white; /* Maintain white text on hover */
}

.upload-button a:hover {
color: white; /* Ensure link remains white on hover */
}
@media (max-width: 768px) {
  .content {
    margin-left: 0 !important; /* Remove unwanted left margin */
    padding: 10px;
    display: flex;
    justify-content: center;
    align-items: center;
    flex-direction: column;
  }

  table {
    width: 90% !important; /* Ensure the table takes up most of the screen */
    margin: 0 auto !important; /* Center the table horizontally */
    display: block;
    overflow-x: auto; /* Enable horizontal scrolling if needed */
    text-align: center;
  }

  th, td {
    font-size: 14px; /* Adjust font size for better readability */
    padding: 8px;
    word-wrap: break-word;
    white-space: normal;
  }
}


   </style>";?>
   
      <table >
        <p style="margin-left:0px;">Customer Information Table</p>
        <tr>
          <th>Reference Number</th>
          <th>Customer Name</th>
          <th>Address</th>
          <th>Customer Mobile Number</th>
          <th>Visit Type</th>
          <th>Bank Name</th>
          <th>Branch Name</th>
          <th>Engineer Name</th>
          <th>Re-Assign</th>
        </tr>
        
        <?php foreach ($results as $task): ?>
        <tr>
            <td data-label="Reference Number"><?= htmlspecialchars($task['reference_id']) ?></td>
            <td data-label="Customer Name"><?= htmlspecialchars($task['customerName']) ?></td>
            <td data-label="Address"><?= htmlspecialchars($task['address']) ?></td>
            <td data-label="Customer Mobile Number"><?= htmlspecialchars($task['customerMob']) ?></td>
            <td data-label="Visit Type"><?= htmlspecialchars($task['visitType']) ?></td>
            <td data-label="Bank Name"><?= htmlspecialchars($task['bankName']) ?></td>
            <td data-label="Branch Name"><?= htmlspecialchars($task['branchname']) ?></td>
  <!-- ✅ Fetch name from preloaded map -->
                <td>
                    <?= isset($engineerMap[$task['engineer_id']]) 
                        ? htmlspecialchars($engineerMap[$task['engineer_id']]) 
                        : 'Not Found' ?>
                </td>
                
                
                <td data-label="Assign">
                <a href="reassignFE.php?reference_id=<?= $task['id'] ?>&reference_id=<?= urlencode($task['reference_id']) ?>&customerName=<?= urlencode($task['customerName']) ?>&address=<?= urlencode($task['address']) ?>&customerMob=<?= urlencode($task['customerMob']) ?>&visitType=<?= urlencode($task['visitType']) ?>&bankName=<?= urlencode($task['bankName']) ?>&branchname=<?= urlencode($task['branchname']) ?>&caseType=<?= urlencode($task['caseType']) ?>&applicationNo=<?= urlencode($task['applicationNo']) ?>&initiatorMailId=<?= urlencode($task['initiatorMailId']) ?>&initiationDate=<?= urlencode($task['initiationDate']) ?>" class="upload-button" style="text-decoration:none;">
                    Re-Assign
                </a>
            </td>
 
        </tr>
        <?php endforeach; ?>
        </table>
      <?php else: ?>
        <p style="text-align: center;">No data available</p>
      <?php endif; ?>
    </div>
  </div>
  <script>
    const toggleBtn = document.getElementById("toggle-btn");
const sidebar = document.getElementById("sidebar");

toggleBtn.addEventListener("click", () => {
  sidebar.classList.toggle("visible");
});

  </script>
</body>

</html>
