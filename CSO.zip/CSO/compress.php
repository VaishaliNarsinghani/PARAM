<?php 
// ==== START SESSION ====
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// ==== CONFIGURATION ====
$pdfDir = __DIR__ . '/pdf_exports';
$compressedDir = __DIR__ . '/compressed_pdfs';

if (!is_dir($pdfDir)) mkdir($pdfDir, 0777, true);
if (!is_dir($compressedDir)) mkdir($compressedDir, 0777, true);

// ==== GET PARAMETERS ====

$reference_id = preg_replace('/[^a-zA-Z0-9_\-\/]/', '', $_GET['reference_id'] ?? '');
$bankName     = preg_replace('/[^a-zA-Z0-9_\-]/', '', $_GET['bankName'] ?? '');
// Store reference_id in session
$_SESSION['reference_id'] = $reference_id;

$_SESSION['bankName'] = $bankName;

if ($reference_id === '') $reference_id = 'Unknown';
if ($bankName === '') $bankName = 'Unknown';

// ==== SANITIZE FILENAMES ====
$safeReferenceId = str_replace(['/', '\\'], '_', $reference_id);
$safeBankName    = str_replace(['/', '\\'], '_', $bankName);

// ==== LOAD BANK TEMPLATE ====
$bankFile = strtolower(preg_replace('/[^a-zA-Z0-9_]/', '', $bankName)) . '.php';

ob_start();
if (file_exists($bankFile)) {
    include($bankFile);
} else {
    echo "<h2>Bank template not found: {$bankName}</h2>";
}
$htmlContent = ob_get_clean();

// ==== FIX IMAGE PATHS ====
$htmlContent = str_replace('src="images/', 'src="file://' . __DIR__ . '/images/', $htmlContent);



$extraCSS = '
<style>
    body { font-family: Arial, sans-serif; font-size: 12px; }

    /* PDF-safe 4-column grid */
    .image-gallery { width: 100%; display: block !important; }
    .image-grid { 
        width: 100%; 
        border-collapse: collapse; 
        table-layout: fixed; 
        border: 1px solid white; /* outer border white */
    }
    .image-grid tr { page-break-inside: avoid; }
    .image-grid td { 
        width: 25%; 
        padding: 6px; 
        vertical-align: top; 
        border: 1px solid white; /* cell borders white */
    }

    .image-grid .img-wrap { display: block; }
    .image-grid img { 
        display: block; 
        width: 100%; 
        height: auto; 
        page-break-inside: avoid; 
        border: none; /* ensure no image border */
    }
    .image-grid .caption { 
        font-size: 12px; 
        text-align: center; 
        margin-top: 4px; 
    }

    /* General */
    img, .no-break { page-break-inside: avoid; }
    .page-break { page-break-before: always; }
</style>
';

$htmlContent = $extraCSS . $htmlContent;

// ==== GENERATE PDF USING wkhtmltopdf ====
$pdfFile = $pdfDir . '/report_' . $safeBankName . '_' . $safeReferenceId . '.pdf';

$commandExists = shell_exec('which wkhtmltopdf');
if (!$commandExists) {
    die("Error: wkhtmltopdf is not installed on your server.");
}

$tempHtml = $pdfDir . '/temp_' . uniqid() . '.html';
file_put_contents($tempHtml, $htmlContent);

// Important: add --enable-local-file-access for images & CSS
$cmd = sprintf(
    'wkhtmltopdf --enable-local-file-access --print-media-type --page-size A4 --margin-top 10mm --margin-bottom 10mm --margin-left 10mm --margin-right 10mm --image-quality 90 %s %s',
    escapeshellarg($tempHtml),
    escapeshellarg($pdfFile)
);
exec($cmd, $out, $status);
@unlink($tempHtml);

if (!file_exists($pdfFile) || filesize($pdfFile) === 0) {
    die("Error: PDF generation failed.");
}

// ==== COMPRESS PDF ====
$compressedFile = $compressedDir . '/report_' . $safeBankName . '_' . $safeReferenceId . '.pdf.gz';
$pdfContent = file_get_contents($pdfFile);
$compressedContent = gzencode($pdfContent, 9);
file_put_contents($compressedFile, $compressedContent);

// ==== DOWNLOAD ====
header('Content-Type: application/gzip');
header('Content-Disposition: attachment; filename="' . basename($compressedFile) . '"');
header('Content-Length: ' . filesize($compressedFile));
readfile($compressedFile);

// ==== CLEANUP ====
@unlink($pdfFile);
@unlink($compressedFile);
exit;
?>
