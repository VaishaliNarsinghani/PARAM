<?php include('auth.php'); ?>
<?php include 'watermark.html'; ?>

<?php
ini_set('display_errors', 1);
error_reporting(E_ALL);

// Increase PHP execution time and memory limit
ini_set('max_execution_time', 600); // Increase execution time to 600 seconds (10 minutes)
ini_set('memory_limit', '4096M'); // Increase memory limit to 4096MB
// Start session


$servername = "localhost";
$username = "root";
$password = "";
$dbname = "project_db";

// Create DB connection
$conn = new mysqli($servername, $username, $password, $dbname);
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

if (!isset($_SESSION['reference_id'])) {
    die("Reference ID not found in session.");
}
$reference_id = $_SESSION['reference_id'];

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['download_images'])) {

    // Get customer name
    $stmt_name = $conn->prepare("SELECT customerName FROM mis WHERE reference_id = ?");
    $stmt_name->bind_param("s", $reference_id);
    $stmt_name->execute();
    $result_name = $stmt_name->get_result();
    $customerName = "customer";
    if ($row = $result_name->fetch_assoc()) {
        $customerName = preg_replace('/[^a-zA-Z0-9]/', '', $row['customerName']);
    }
    $stmt_name->close();

    // Fetch image BLOBs
    $stmt = $conn->prepare("SELECT image1, image2, image3, image4, image5, image6, image7, image8, image9, image10, image11, image12,image13, image14, image15, image16, image17, image18, image19, image20 FROM final_uploaded_images WHERE reference_id = ?");    $stmt->bind_param("s", $reference_id);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows > 0 && ($row = $result->fetch_assoc())) {
        $tempDir = sys_get_temp_dir() . DIRECTORY_SEPARATOR . uniqid('images_', true);
        mkdir($tempDir);

        $imageFiles = [];
        for ($i = 1; $i <= 12; $i++) {
            if (!empty($row["image$i"])) {
                $filename = $tempDir . DIRECTORY_SEPARATOR . "image{$i}.jpg";
                file_put_contents($filename, $row["image$i"]);
                $imageFiles[] = $filename;
            }
        }

        if (empty($imageFiles)) {
            die("No images to download.");
        }

        // Create ZIP
        $zipFileName = "images_" . preg_replace('/[^a-zA-Z0-9]/', '_', $reference_id) . "_{$customerName}.zip";
        $zipPath = $tempDir . DIRECTORY_SEPARATOR . $zipFileName;

        $zip = new ZipArchive();
        if ($zip->open($zipPath, ZipArchive::CREATE) !== TRUE) {
            die("Failed to create ZIP file.");
        }

        foreach ($imageFiles as $file) {
            $zip->addFile($file, basename($file));
        }
        $zip->close();

        // Send ZIP to browser
        header('Content-Type: application/zip');
        header('Content-Disposition: attachment; filename="' . basename($zipFileName) . '"');
        header('Content-Length: ' . filesize($zipPath));
        flush();
        readfile($zipPath);

        // Cleanup
        foreach ($imageFiles as $file) {
            unlink($file);
        }
        unlink($zipPath);
        rmdir($tempDir);
        exit;
    } else {
        echo "<p style='color:red;'>No image data found for this reference ID.</p>";
    }
}

$page = isset($_GET['page']) ? $_GET['page'] : 1;
$limit = 50;
$offset = ($page - 1) * $limit;
$sql_property = "SELECT * FROM mis WHERE reference_id = ? LIMIT $limit OFFSET $offset";
$stmt_property = $conn->prepare($sql_property);
$stmt_property->bind_param("s", $reference_id);
$stmt_property->execute();
$result_property = $stmt_property->get_result();
$data1 = $result_property->fetch_assoc();




// Fetch data from property_details table
$sql_property = "SELECT * FROM property_details WHERE reference_id = ?";
$stmt_property = $conn->prepare($sql_property);
$stmt_property->bind_param("s", $reference_id);
$stmt_property->execute();
$result_property = $stmt_property->get_result();
$data2= $result_property->fetch_assoc();




// Fetch data from area_valuation table
$sql_area = "SELECT * FROM address_details WHERE reference_id = ?";
$stmt_area = $conn->prepare($sql_area); 
$stmt_area->bind_param("s", $reference_id);
$stmt_area->execute();
$result_area = $stmt_area->get_result();
$data3 = $result_area->fetch_assoc();





// Fetch data from area_valuation table
$sql_area = "SELECT * FROM critical_parameters WHERE reference_id = ?";
$stmt_area = $conn->prepare($sql_area); 
$stmt_area->bind_param("s", $reference_id);
$stmt_area->execute();
$result_area = $stmt_area->get_result();
$data4 = $result_area->fetch_assoc();

 
// Fetch data from area_valuation table
$sql_area = "SELECT * FROM surroundings_details WHERE reference_id = ?";
$stmt_area = $conn->prepare($sql_area); 
$stmt_area->bind_param("s", $reference_id);
$stmt_area->execute();
$result_area = $stmt_area->get_result();
$data5 = $result_area->fetch_assoc();
$stmt_area->close();
 
// Fetch data from area_valuation table
$sql_area = "SELECT * FROM area_valuation WHERE reference_id = ?";
$stmt_area = $conn->prepare($sql_area); 
$stmt_area->bind_param("s", $reference_id);
$stmt_area->execute();
$result_area = $stmt_area->get_result();
$data6 = $result_area->fetch_assoc();
$stmt_area->close();
 



// Fetch data from area_valuation table
$sql_area = "SELECT * FROM floor_details WHERE reference_id = ?";
$stmt_area = $conn->prepare($sql_area); 
$stmt_area->bind_param("s", $reference_id);
$stmt_area->execute();
$result_area = $stmt_area->get_result();
$data8= $result_area->fetch_assoc();
$stmt_area->close();
 


// Fetch data from area_valuation table
$sql_area = "SELECT * FROM technical_details WHERE reference_id = ?";
$stmt_area = $conn->prepare($sql_area); 
$stmt_area->bind_param("s", $reference_id);
$stmt_area->execute();
$result_area = $stmt_area->get_result();
$data9 = $result_area->fetch_assoc();
$stmt_area->close();
 
// Fetch data from area_valuation table
$sql_area = "SELECT * FROM remarks_table WHERE reference_id = ?";
$stmt_area = $conn->prepare($sql_area); 
$stmt_area->bind_param("s", $reference_id);
$stmt_area->execute();
$result_area = $stmt_area->get_result();
$data10 = $result_area->fetch_assoc();
$stmt_area->close();


// Step 1: Fetch the engineer_id from the mis table
$sql_mis = "SELECT engineer_id FROM mis WHERE reference_id = ?";
$stmt_mis = $conn->prepare($sql_mis);
$stmt_mis->bind_param("s", $reference_id);
$stmt_mis->execute();
$result_mis = $stmt_mis->get_result();
$row_mis = $result_mis->fetch_assoc();
$stmt_mis->close(); 

if ($row_mis) {
    $engineer_id = $row_mis['engineer_id'];

    // Step 2: Fetch the engineer's name from engineer_login table
    $sql_engineer = "SELECT name FROM engineer_login WHERE engineer_id = ?";
    $stmt_engineer = $conn->prepare($sql_engineer);
    $stmt_engineer->bind_param("s", $engineer_id);
    $stmt_engineer->execute();
    $result_engineer = $stmt_engineer->get_result();
    $row_engineer = $result_engineer->fetch_assoc();
    $stmt_engineer->close();

    if ($row_engineer) {
        $engineer_name = $row_engineer['name'];
         //echo "Engineer Name: " . $engineer_name;
    } else {
        echo "Engineer not found.";
    }
} else {
    echo "No engineer assigned for this reference_id.";
}



// Step 1: Fetch the engineer_id from the mis table
$sql_mis = "SELECT report_id FROM mis WHERE reference_id = ?";
$stmt_mis = $conn->prepare($sql_mis);
$stmt_mis->bind_param("s", $reference_id);
$stmt_mis->execute();
$result_mis = $stmt_mis->get_result();
$row_mis = $result_mis->fetch_assoc();
$stmt_mis->close(); 

if ($row_mis) {
    $report_id = $row_mis['report_id'];

    // Step 2: Fetch the engineer's name from engineer_login table
    $sql_engineer = "SELECT name FROM report_login WHERE report_id = ?";
    $stmt_engineer = $conn->prepare($sql_engineer);
    $stmt_engineer->bind_param("s", $report_id);
    $stmt_engineer->execute();
    $result_engineer = $stmt_engineer->get_result();
    $row_engineer = $result_engineer->fetch_assoc();
    $stmt_engineer->close();

    if ($row_engineer) {
        $report_name = $row_engineer['name'];
         //echo "Engineer Name: " . $report_name;
    } else {
        echo "Engineer not found.";
    }
} else {
    echo "No engineer assigned for this reference_id.";
}


// Step 1: Fetch the engineer_id from the mis table
$sql_mis = "SELECT report_drafter_to_technical FROM mis WHERE reference_id = ?";
$stmt_mis = $conn->prepare($sql_mis);
$stmt_mis->bind_param("s", $reference_id);
$stmt_mis->execute();
$result_mis = $stmt_mis->get_result();
$row_mis = $result_mis->fetch_assoc();
$stmt_mis->close(); 

if ($row_mis) {
    $report_drafter_to_technical = $row_mis['report_drafter_to_technical'];

    // Step 2: Fetch the engineer's name from engineer_login table
    $sql_engineer = "SELECT name FROM technical_login WHERE technical_manager_id = ?";
    $stmt_engineer = $conn->prepare($sql_engineer);
    $stmt_engineer->bind_param("s", $report_drafter_to_technical);
    $stmt_engineer->execute();
    $result_engineer = $stmt_engineer->get_result();
    $row_engineer = $result_engineer->fetch_assoc();
    $stmt_engineer->close();

    if ($row_engineer) {
        $technical_name = $row_engineer['name'];
        //echo "Engineer Name: " . $technical_name;
    } else {
        echo "Engineer not found.";
    }
} else {
    echo "No engineer assigned for this reference_id.";
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>AGRIM REPORT</title>
      <link rel="shortcut icon" href="favicon.png" type="image/x-icon"> 
  <style>
    .center {
      display:flex;
      text-align: center;
    }
    .main-title {
      font-size: 22px;
      font-weight: bold;
      color: #b30000;
    }
    table {
      width: 100%;
      border-collapse: collapse;
      font-family: Arial, sans-serif;
    }
    th, td {
      border: 2px solid black;
      padding: 8px;
      text-align: left;
      vertical-align: top;
    }
    th {
      font-weight: bold;
      text-align: center;
    }
    .header, .sub-header {
      background-color:#ACB9CA;
      font-weight: bolder;
      font-size:16px;
      text-align: center;
    }
    .no-border {
      border: none !important;
    }
    body {
      font-family: Arial;
      background: #f4f4f4;
      padding: 20px;
    }

    table {
      width: 100%;
      border-collapse: collapse;
      background: white;
      box-shadow: 0 0 10px #ccc;
    }

    th, td {
      border: 1px solid black;
      padding: 4px 18px;
      text-align: center;
      font-size: 10px;
    }
   
    th {
      background-color: #ACB9CA;
      font-weight: bold;
    }

    .section-title {
      text-align: center;
      font-size: 14px;
      font-weight:bolder;
    }

    .header-blue {
      background-color:#ACB9CA;
      color: white;
      font-weight: bold;
      text-align: center;
    }

    .highlight {
      background-color: #f2f2f2;
    }
    button{
  padding:8px;
  margin-left:45%;
  background-color:#5d5e5f8f ;
  font-weight:500;
  font-style:italic;
}
button:hover{
  background-color:#bdbabaf4 ;
}
@media print{
  body{
    margin:0;
  }
  button{
    display:none;
    margin-left:30%;
  }

  }
  pre{
      font-size:15px;
      font-family: Arial, sans-serif;
      font-style: oblique;
  }
  .clean-textarea {
    width: 100%;
    min-height: 30px;
    padding: 5px;
    font-size: 14px;
    font-family: inherit;
    background: transparent;
    border: none;
    outline: none;
    resize: none;
    overflow: hidden;
    color: inherit;
  }
textarea{    
  margin-top:5px;
border:0.2px solid grey;
background-color: transparent;
height:auto;
width:100%;
 font-family: Arial, Helvetica, sans-serif;
}
  .number-column {
    width: 40px;
    text-align: center;
    font-weight: bold;
}
  .magpie-header {
      display: flex;
      align-items: center;
      gap: 20px;
      padding: 10px 20px;
      border-bottom: 2px solid #ccc;
    }

    .magpie-header img {
      height: 100px ;
      weight:100px;
    }

    .magpie-header-content {
      text-align: center;
      flex: 1;
      color: #7b0000;
      font-family: Arial, sans-serif;
    }

    .magpie-header-content h1 {
      margin: 0;
      font-size: 28px;
      font-weight: 700;
    }

    .magpie-header-content h3 {
      margin: 5px 0 0;
      font-size: 16px;
      font-weight: 600;
    }
input{
     width:100%;
     height:100%;
     margin-left:-10px;
     border:none;
}
    .magpie-header-content p {
      margin: 4px 0 0;
      font-size: 14px;
      color: #7b0000;
      font-weight: normal;
    }
span{
  font-weight:500;
}
  </style>
  <style>
.container {
    max-width: 1200px;
    margin: 20px auto;
    padding: 20px;
    background-color: white;
    box-shadow: 0px 0px 10px rgba(0, 0, 0, 0.1);
    border-radius: 8px;
}

.title {
    text-align: center;
    font-size: 24px;
    font-weight: bold;
    margin-bottom: 20px;
}
.grid-container {
    display: grid;
    grid-template-columns: repeat(4, 1fr);
    gap: 15px;
}

.grid-item {
    position: relative;
    border-radius: 8px;
    overflow: hidden;
    box-shadow: 0px 4px 6px rgba(0, 0, 0, 0.1);
}

.grid-item img {
    width: 100%;
    height: 200px;
    object-fit: cover;
    transition: transform 0.3s ease;
}
.grid-item:hover img {
    transform: scale(1.05);
}

.overlay {
    position: absolute;
    bottom: 0;
    left: 0;
    background: rgba(0, 0, 0, 0.6);
    color: white;
    width: 100%;
    padding: 8px;
    font-size: 14px;
    text-align: center;
}
 
   
/* Force a stable 4-column grid that wkhtmltopdf respects */
.image-gallery { width: 100%; }
.image-grid { width: 100%; border-collapse: collapse; table-layout: fixed; }
.image-grid tr { page-break-inside: avoid; }
.image-grid td { width: 25%; padding: 6px; vertical-align: top; }

.image-grid .img-wrap { display: block; }
.image-grid img { display: block; width: 100%; height: auto; }
.image-grid .caption { font-size: 12px; text-align: center; margin-top: 4px; }

/* If you had a flex layout before, neutralize it */
.image-gallery { display: block !important; }



    /* Print-specific rules */
    @media print {
      .no-print {
        display: none !important;
      }

      body {
        margin: 0;
      }
 
    }
  button{
    padding:8px;
    margin-left:45%;
    background-color:#808485;
    color:white;
    font-weight:700;
    font-style:italic;
  }
  button:hover{
    background-color:rgba(216,216,216,255);
    color:white;
  }

/* Optional: Google map styling */
    .google-map-container {
      max-width: 90%;
      margin: 20px auto;
      border: 2px solid #ccc;
      padding: 10px;
      box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
      background-color: #f9f9f9;
      border-radius: 8px;
      text-align: center;
    }

    .google-map-container img {
      max-width: 100%;
      height: auto;
      display: inline-block;
      border: 1px solid #999;
      border-radius: 4px;
    }
    
.logo img {
  width: 120px;
  margin-left:30px;
  height: auto;
}

 </style>

</head>
<body>

<div class="magpie-header">
  <img src="images/logo.png" alt="Magpie Logo">
  <div class="magpie-header-content">
    <h1>MAGPIE ENGINEERING PVT. LTD.</h1>
    <h3>Valuer Designer Architects</h3>
    <p>Office No. 201, 2nd Floor, Gravity Mall, Warehouse Road, Mechanic Nagar,<br>
    near Vijay Nagar, Madhya Pradesh - 452011.</p>
  </div>
</div>

  <table>
    <tr><th colspan="4" class="header">TECHNICAL SCRUTINY REPORT</th></tr>
    <table>
  <tr>
    <td colspan="6" class="section-title">LOAN APPLICATION DETAIL</td>
  </tr>
  <tr>
    <th>COMPANY</th>
<td colspan="2"><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars('AGRIM HOUSING FINANCE PVT. LTD') ?></span></td>
    <th>DATE OF REPORT RELEASE</th>
     <td colspan="2"><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
 <?= htmlspecialchars(date('d M Y h:i A', strtotime($data1['report_assigned_at'] ?? ''))) ?></span>
</td>
  </tr>
  <tr>
    <th>BRANCH NAME</th>
     <td><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data1['bank_branchname'] ?? '') ?></span>
</td>
    <th>APPLICANT / CO-APPLICANT NAME</th>
    <td><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data1['customerName'] ?? '') ?>
    </span></td>    <th>FILE NO./REF.NO./LOS NO.</th>
     <td><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data1['applicationNo'] ?? '') ?></span>
</td>
  </tr>
  <tr>
    <th>PRODUCT</th>
     <td><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data1['caseType'] ?? '') ?></span>
</td>
    <th>TRANSACTION TYPE</th>
     <td colspan="3"><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data1['caseType'] ?? '') ?></span>
</td>
  </tr>
  <tr>
    <td colspan="6"  class="section-title">ADDRESS DETAIL</td>
  </tr>
  <tr>
    <th colspan="2">ADDRESS DETAILS (AS PER SITE INSPECTION)</th>
  <td colspan="4"><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data3['address_per_site'] ?? '') ?>
    </span></td>  </tr>
  <tr>
    <th colspan="2">ADDRESS DETAILS (AS PER DOCUMENTS)</th>
<td colspan="4"><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
  <?= htmlspecialchars($data3['address_per_document'] ?? '') ?> </span></td>
  </tr>
  <tr>
    <th>SURVEY NO./KHASRA NO.</th>
     <td><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars('Refer Address') ?></span>
</td>
    <th>LANDMARK</th>
     <td><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data3['landmark_1'] ?? '') ?> <?= htmlspecialchars($data3['landmark_2'] ?? '') ?></span>
</td>
    <th>DISTRICT</th>
     <td><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data3['address_line_3_as_per_doc'] ?? '') ?></span></td>
  </tr>
  <tr>
    <th>STATE</th>
     <td><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data3['address_line_4_as_per_doc'] ?? '') ?></span>
</td>
    <th>PIN CODE</th>
     <td><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data3['pin_code'] ?? '') ?></span>
</td>
    <th>NEAREST AHF BRANCH NAME</th>
     <td><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data1['bank_branchname'] ?? '') ?></span>
</td>
  </tr>
  <tr>
    <th>DISTANCE FROM NEAREST BRANCH</th>
     <td><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data3['distance_from_branch_kms'] ?? '') ?></span>
</td>
    <th>PROPERTY TYPE</th>
     <td><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data2['property_unit_type'] ?? '') ?></span>
</td>
    <th>PERSON MET AT SITE</th>
     <td><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data2['person_meet_at_site_contact'] ?? '') ?></span>
</td>
  </tr>
  <tr>
    <th>RELATIONSHIP WITH APPLICANT/CUSTOMER</th>
     <td><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data2['relation_of_occupant'] ?? '') ?></span>
</td>
    <th>CONTACT NUMBER</th>
     <td colspan="3"><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data1['customerMob'] ?? '') ?></span>
</td>
  </tr>

  <!-- Boundaries -->
  <tr><td colspan="6" class="section-title">BOUNDARIES</td></tr>
  <tr >
    <th >DIRECTION</th>
    <th >NORTH</th>
    <th >SOUTH</th>
    <th >EAST</th>
    <th colspan="2" >WEST</th>
   
  </tr>
  <tr>
    <th>AS PER SALE DEED/DRAFT AGREEMENT</th>
    
    <td><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data3['direction_as_per_document_north'] ?? '') ?>
    </span></td>
    <td><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data3['direction_as_per_document_south'] ?? '') ?>
    </span></td>
      <td><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data3['direction_as_per_document_east'] ?? '') ?>
    </span></td>
    <td colspan="2"><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data3['direction_as_per_document_west'] ?? '') ?>
    </span></td>

  </tr>
  <tr>
    <th>AS PER SITE INVESTIGATION</th>
     <td><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data3['direction_as_per_site_north'] ?? '') ?></span>
</td>
     <td><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data3['direction_as_per_site_south'] ?? '') ?></span>
</td>
     <td><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data3['direction_as_per_site_east'] ?? '') ?></span>
</td>
     <td colspan="2"><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data3['direction_as_per_site_west'] ?? '') ?></span>
</td>

  </tr>
  <tr>
    <th>AS PER PLAN/BOUNDARIES CERTIFICATE</th>
     <td><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data3['direction_approved_north'] ?? '') ?></span>
</td>
     <td><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data3['direction_approved_south'] ?? '') ?></span>
</td>
     <td><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data3['direction_approved_east'] ?? '') ?></span>
</td>
     <td colspan="2"><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data3['direction_approved_west'] ?? '') ?></span>
</td>

  </tr>
  <tr>
    <th>BOUNDARIES MATCHES (YES/NO)</th>
     <td colspan="2"><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data3['boundaries_matching'] ?? '') ?></span>
</td>
     <th>IF NO, THEN MENTION REASON.</th>    
      <td colspan="2"><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data10['NA'] ?? '') ?></span>
</td>
  </tr>
</table>
<table>
    <tr>
      <td colspan="6" class="section-title">GENERAL PROPERTY DETAIL</td>
    </tr>
    <tr>
      <th>APPROVAL AUTHORITY (NAME IF APPROVED)</th>
       <td><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data9['floor_document'] ?? '') ?></span>
</td>
      <th>APPROVAL AUTHORITY LIMIT</th>
      <td style="width:100px;"><span style="font-size:14px; display: block; text-align: left; padding: 0; margin: 0;">
        <?= htmlspecialchars($data3['property_location_in'] ?? '') ?>
    </span></td>
      <th>AGE OF PROPERTY</th>
       <td><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data2['age_of_property'] ?? '') ?></span>
</td>
    </tr>
    <tr>
      <th>RESIDUAL AGE OF PROPERTY</th>
       <td><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data2['residual_age_of_property'] ?? '') ?></span>
</td>
      <th>PROPERTY/DWELLING UNIT TYPE</th>
       <td><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data2['property_unit_type'] ?? '') ?></span>
</td>
      <th>APPROACH ROAD TO PROPERTY</th>
       <td><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data2['type_of_approach_road'] ?? '') ?></span>
</td>
    </tr>
    <tr>
      <th>SELLER / OWNER NAME</th>
       <td style="width:100px;"><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data9['seller_name'] ?? '') ?>  <?= htmlspecialchars($data9['owner_name'] ?? '') ?></span>
</td>
      <th>OCCUPANCY STATUS</th>
       <td><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data2['occupancy_status'] ?? '') ?></span>
</td>
      <th>OCCUPANT NAME</th>
       <td style="width:100px;"><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data2['occupant_name'] ?? '') ?></span>
</td>
    </tr>
    <tr>
      <th>NUMBER OF FLAT IN BUILDING/PROJECT</th>
       <td><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data10['NA'] ?? '') ?></span>
</td>
      <th>OCCUPANCY IN A BUILDING IN %</th>
       <td><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data10['NA'] ?? '') ?></span>
</td>
      <th>PROPERTY FINISHED/UNFINISHED</th>
       <td><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data2['property_furnished_unfurnished'] ?? '') ?></span>
</td>
    </tr>
    <tr>
      <th>VIOLATIONS OBSERVED IF ANY (YES/NO)</th>
       <td><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data10['NA'] ?? '') ?></span>
</td>
      <th>RISK OF DEMOLITION IN CASE OF VIOLATION (YES/NO)</th>
       <td><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data9['demolition_risk_1'] ?? '') ?></span>
</td>
      <th>ACCOMMODATION OF FLAT (ROOM, KITCHEN, TOILET, HALL DETAIL)</th>
       <td><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data10['NA'] ?? '') ?></span>
</td>
    </tr>
    <tr>
      <th>PROPERTY FALLING IN CAUTION AREA (YES/NO)</th>
       <td><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data10['NA'] ?? '') ?></span>
</td>
      <th>REASON FOR CAUTION IF YES</th>
       <td><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data10['NA'] ?? '') ?></span>
</td>
      <th>PROPERTY EXTERIORS (AVERAGE/GOOD/POOR)</th>
<td><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars('Average') ?></span></td>
    </tr>
    <tr>
      <th>CLASS OF LOCALITY (HIGH CLASS/MIDDLE CLASS/LOWER CLASS)</th>
       <td><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data2['class_of_locality'] ?? '') ?></span>
</td>
      <th>PROPERTY INTERIORS (AVERAGE/GOOD/POOR)</th>
<td><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars('Average') ?></span></td></td>
      <th>BASIC AMENITIES (ROAD,ELECTRICITY,DRAINAGE) (YES/NO)</th>
       <td><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars('Available') ?></span></td>
    </tr>
    <tr>
      <th>DEVELOPMENT IN PARTICULAR COLONY/AREA</th>
       <td><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data2['surrounding_infrastructure'] ?? '') ?></span>
</td>
      <th>HABITATION IN SURROUNDING AREA (IN %)</th>
       <td><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data2['develop_percent'] ?? '') ?></span>
</td>
</td>
      <th>RURAL, URBAN, SEMI URBAN </th>
       <td><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data3['property_location_in'] ?? '') ?></span>
</td>
    </tr>
  </table>
  <table>
  <tr>
    <td colspan="4" class="section-title">SURROUNDING EXTERNAL AMENITIES</td>
  </tr>
  <tr>
    <th>SR. NO.</th>
    <th>PRIMISES LIST</th>
    <th>APPROX DISTANCE FROM PROPERTY</th>
    <th>NAME OF PRIMISES/DESCRIPTION</th>
  </tr>
  <tr><th>1</th>
     <th>
NEAREST RAILWAY STATION</th>
     <td><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data3['nearest_railway_station_distance'] ?? '') ?></span>
</td>
     <td><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data3['nearest_railway_station_name'] ?? '') ?></span>
</td>
  </tr>
  <tr>
     <th>
2</th>
     <th>
   NEAREST HIGHWAY/CONNECTING ROAD</th>
     <td><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data3['nearest_bus_stop_distance'] ?? '') ?></span>
</td>
     <td><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data3['nearest_bus_stop_name'] ?? '') ?></span>
</td>
  </tr>
  <tr>
    <th colspan="2">PROPERTY LATITUDE AND LONGITUDE:</th>
     <td colspan="2"><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data3['latitude_value'] ?? '') ?>,<?= htmlspecialchars($data3['longitude_value'] ?? '') ?></span>
 </td>
  </tr>
</table>

<br>

<table>
  <tr>
    <td colspan="6" class="section-title">AREA DETAIL</td>
  </tr>
  <tr>
    <th>AREA TYPE</th>
    <th>SQUARE FEET</th>
    <th>SQUARE METER</th>
    <TH></TH>
    <th colspan="2">REMARKS ON AREA OF PROPERTY</th>

  </tr>
  <tr>
    <th>PROPERTY LENGTH</th>
     <td><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data10['NA'] ?? '') ?></span>
         <th>PROPERTY WIDTH</th>
     <td><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data10['NA'] ?? '') ?></span>
</td>
   <td colspan="2"><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars('') ?></span>
</td>
  </tr>
  <tr>
    <th>PLOT AREA AS PER DOCUMENT / AS PER MEASUREMENT</th>
         <td><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data6['plot_square_feet'] ?? '') ?></span>
</td>
     <td>  <input type="text" readonly  name="engineer_id"  
        value="<?= isset($data6['plot_square_feet']) ? round(floatval($data6['plot_square_feet']) * 0.092903, 2) : '' ?>">
</td>
    <th>LAND AREA / UDS AREA</th>
    <th style="background-color:white;margin-top:10%;" rowspan="5" colspan="2";>AS PER PLAN -<span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data8['ground_approved_area'] ?? '') ?></span><br><br><br>
    AS PER SITE / MEASUREMENT<span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data6['actual_plot_square_feet'] ?? '') ?></span><br><br>
    <br>AS PER AGREEMENT -<span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data6['plot_square_feet'] ?? '') ?></span></th>
  </tr>
  <tr>
    <th>CARPET AREA</th>
     <td><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data6['actual_carpet_square_feet'] ?? '') ?></span>
</td>
     <td> <input type="text" readonly  name="engineer_id"  
        value="<?= isset($data6['carpet_square_feet']) ? round(floatval($data6['carpet_square_feet']) * 0.092903, 2) : '' ?>">

</td>
    <th>AS PER ACTUAL ON SITE</th>
   </td>
  </tr>
  <tr>
    <th>EXISTING BUILT-UP</th>
     <td><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data6['actual_construction_square_feet'] ?? '') ?></span>
</td>
     <td> <input type="text" readonly  name="engineer_id"  
        value="<?= isset($data6['actual_construction_square_feet']) ? round(floatval($data6['actual_construction_square_feet']) * 0.092903, 2) : '' ?>">
</td>
    <th>NOT MORE THAN 20% OF CA.</th>
    </td>
  </tr>
  <tr>
    <th>PROPOSED / ESTIMATE BUILT-UP AREA</th>
     <td><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data6['construction_area_sqft_3'] ?? '') ?></span>
</td>
     <td> <input type="text" readonly  name="engineer_id"  
        value="<?= isset($data6['construction_area_sqft_3']) ? round(floatval($data6['construction_area_sqft_3']) * 0.092903, 2) : '' ?>">
</td>
    <th style="background-color:white;" rowspan="2">AS PER APPROVAL / BYELAWS / POLICY</th>
</td>  </tr>
  <tr>
    <th>SALEABLE AREA</th>
     <td><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data6['actual_saleable_square_feet'] ?? '') ?></span>
</td>
    <td> <input type="text" readonly  name="engineer_id"  
        value="<?= isset($data6['actual_saleable_square_feet']) ? round(floatval($data6['actual_saleable_square_feet']) * 0.092903, 2) : '' ?>">
</td>
  </tr>
  <tr>
    <th>PRESENT CONSTRUCTED AREA</th>
     <td><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data10['NA'] ?? '') ?></span>
</td>
     <td><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data10['NA'] ?? '') ?></span>
</td>
     <td><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data10['NA'] ?? '') ?></span>
</td>
    <th>ZONE AS PER CITY DEVELOPMENT PLAN</th>
     <td><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data4['zoning_development_plan'] ?? '') ?></span>
</td>
  </tr>
</table>
<table>
  <tr>
    <td colspan="6" class="section-title">VALUATION DETAIL</td>
  </tr>
  <tr>
    <th rowspan="">CATEGORY</th>
    <th>AREA TYPE</th>
    <th>AREA SQ.FT.</th>
    <th>RATE PER SQ.FT.</th>
    <th>VALUATION</th>
    <th rowspan=""></th>
  </tr>
  <tr>
    <td rowspan="2">AREA VALUATION</td>
     <td>SALABLE AREA</td>
     <td><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data6['final_area_square_feet'] ?? '') ?></span>
</td>
     <td><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data6['final_area_rate'] ?? '') ?></span>
</td>
     <td><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data6['final_area_valuation'] ?? '') ?></span>
</td>
         <td>RS.</td>
  </tr>
  <tr>
     <td>LAND AREA</td>
     <td><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data6['final_plot_square_feet'] ?? '') ?></span>
</td>
     <td><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data6['final_plot_rate'] ?? '') ?></span>
</td>
     <td><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data6['finally_plot_valuation'] ?? '') ?></span>
</td>
         <td>RS.</td>
  </tr>
  <tr>
    <td rowspan="3">CONSTRUCTION/EXTENSION/IMPROVEMENT COST</td>
     <td>EXISTING BUILT-UP AREA</td>
     <td><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data6['construction_area_sqft_1'] ?? '') ?></span>
</td>
     <td><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data6['construction_rate_1'] ?? '') ?></span>
</td>
     <td><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data6['construction_valuation_1'] ?? '') ?></span>
</td>
          <td>RS.</td>
  </tr>
  <tr>
     <td>PROPOSED /ESTIMATE BUILT-UP AREA</td>
     <td><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data6['construction_area_sqft_3'] ?? '') ?></span>
</td>
     <td><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data6['construction_rate_3'] ?? '') ?></span>
</td>
     <td><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data6['construction_valuation_3'] ?? '') ?></span>
</td>
          <td>RS.</td>
  </tr>
  <tr>
     <td>PRESENT CONST. AREA</td>
     <td><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data10['NA'] ?? '') ?></span>
</td>
     <td><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data10['NA'] ?? '') ?></span>
</td>
     <td><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data10['NA'] ?? '') ?></span>
</td>
          <td>RS.</td>
  </tr>
  <tr>
     <td>DLC RATE / GOVT. VALUE</td>
     <td>LAND/PROPERTY</td>
     <td><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data6['final_plot_square_feet'] ?? '') ?></span>
</td>
     <td><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data6['guideline_rate'] ?? '') ?></span>
</td>
     <td><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data6['guideline_values'] ?? '') ?></span>
</td>
     <td>RS.</td>
  </tr>
</table>
<!-- AMENITIES / F & F DETAIL TABLE -->
<table>
  <tr>
    <td colspan="6" class="section-title">AMENITIES / F & F DETAIL</td>
  </tr>
  <tr>
    <th>AMENITIES</th>
    <th>DESCRIPTION</th>
    <th>AREA / QUANTITY</th>
    <th>UNIT</th>
    <th>AMOUNT</th>
     <th></th>
  </tr>
  <tr>
     <td>1</td>
     <td><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data6['addition_amenities_description_2'] ?? '') ?></span>
</td>
     <td><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data10['NA'] ?? '') ?></span>
</td>
     <td><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data10['NA'] ?? '') ?></span>
</td>
     <td><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data6['addition_amenities_amount_2'] ?? '') ?></span>
</td>
     <td><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data10['NA'] ?? '') ?></span>
</td>
  </tr>
  <tr>
     <td>2</td>
     <td><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data6['addition_amenities_description_3'] ?? '') ?></span>
</td>
     <td><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data10['NA'] ?? '') ?></span>
</td>
     <td><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data10['NA'] ?? '') ?></span>
</td>
     <td><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data6['addition_amenities_amount_3'] ?? '') ?></span>
</td>
     <td><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data10['NA'] ?? '') ?></span>
</td>
  </tr>
  <tr>
     <td colspan="4">TOTAL AMENITIES COST</td>
     <td><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data6['amenities_total'] ?? '') ?></span>
</td>
     <td>RS.</td>
  </tr>
  <tr>
     <td colspan="4">MARKET VALUE</td>
     <td><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data6['total_finally_area_valuation'] ?? '') ?></span>
</td>
     <td>RS.</td>
  </tr>
  <tr>
     <td colspan="4">REALIZABLE VALUE</td>
     <td><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data6['total_finally_area_valuation'] ?? '') ?></span>
</td>
     <td>RS.</td>
  </tr>
  <tr>
     <td colspan="4">DISTRESS VALUE</td>
     <td><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data6['total_distress_value'] ?? '') ?></span>
</td>
     <td>RS.</td>
  </tr>
  <tr>
    <td colspan="6">0</td>
  </tr>
</table>
<table>
  <tr>
    <th colspan="2">FLOOR</th>
    <th>APPROVED</th>
    <th>PROPOSED / ACTUAL</th>
    <th>REMARKS ON NO. OF FLOORS</th>
  </tr>
  <tr>
     <td>A.</td>
     <td>NO. OF BASEMENT</td>
     <td><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data10['NA'] ?? '') ?></span>
</td>
     <td><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data10['NA'] ?? '') ?></span>
</td>
    <td rowspan="4"></td>
  </tr>
  <tr>
     <td>B.</td>
     <td>NO. OF GROUND/PARKING/STILT FLOOR</td>
     <td><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data10['NA'] ?? '') ?></span>
</td>
     <td><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data8['ground_actual'] ?? '') ?></span>
</td>
  </tr>
  <tr>
     <td>C.</td>
     <td>NO. OF UPPER FLOOR</td>
     <td><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data10['NA'] ?? '') ?></span>
</td>
     <td><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data8['first_actual'] ?? '') ?></span>
</td>
  </tr>
  <tr>
     <td>A + B + C </td>
     <td>TOTAL NO. OF FLOOR</td>
     <td><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data6['approved_configuration_building'] ?? '') ?></span>
</td>
     <td><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data6['actual_configuration_building'] ?? '') ?></span>
</td>
  </tr>
</table>
<table>
  <tr>
    <td colspan="5" class="section-title">TECHNICAL / LEGAL DOCUMENT DETAIL</td>
  </tr>
  <tr>
    <th>DOCUMENT NAME</th>
    <th>REF / APPROVAL NO.</th>
    <th>REF / APPROVAL DATE</th>
    <th>APPROVAL AUTHORITY NAME</th>
    <th>NUMBER OF FLOOR APPROVED</th>
  </tr>
  <tr>
    <th>LAYOUT PLAN</th>
     <td><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data9['layout_approval_details'] ?? '') ?></span>
</td>
     <td><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data9['layout_approval_date'] ?? '') ?></span>
</td>
     <td><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data9['layout_approving_authority'] ?? '') ?></span>
</td>
     <td><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data10['NA'] ?? '') ?></span>
</td>
  </tr>
  <tr>
    <th>APPROVED FLOOR PLAN</th>
     <td><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data9['sanction_approval_no'] ?? '') ?></span>
</td>
     <td><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data9['sanction_approval_date'] ?? '') ?></span>
</td>
     <td><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data9['sanction_approving_authority'] ?? '') ?></span>
</td>
     <td><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data10['NA'] ?? '') ?></span>
</td>
  </tr>
  <tr>
    <th>CONSTRUCTION PERMISSION / BUILDING PERMISSION</th>
 <td colspan="1"><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data10['NA'] ?? '') ?></span>
</td> <td colspan="1"><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data10['NA'] ?? '') ?></span>
</td> <td colspan="1"><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data10['NA'] ?? '') ?></span>
</td> <td colspan="1"><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data10['NA'] ?? '') ?></span>
</td>  </tr>
  <tr>
    <th>DA AUTHORITY ALLOTMENT LETTER</th>
 <td colspan="1"><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data10['NA'] ?? '') ?></span>
</td> <td colspan="1"><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data10['NA'] ?? '') ?></span>
</td> <td colspan="1"><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data10['NA'] ?? '') ?></span>
</td> <td colspan="1"><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data10['NA'] ?? '') ?></span>
</td>  </tr>
  <tr>
    <th>BUILDING COMPLETION / OCCUPATION CERTIFICATE</th>
 <td colspan="1"><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data10['NA'] ?? '') ?></span>
</td> <td colspan="1"><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data10['NA'] ?? '') ?></span>
</td> <td colspan="1"><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data9['possesion_details'] ?? '') ?></span>
</td> <td colspan="1"><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data10['NA'] ?? '') ?></span>
</td>  </tr>
  <tr>
    <th>NON-AGRICULTURE LAND CONVERSION ORDER</th>
 <td colspan="1"><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data10['NA'] ?? '') ?></span>
</td> <td colspan="1"><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data10['NA'] ?? '') ?></span>
</td> <td colspan="1"><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data9['nonagricultural_details'] ?? '') ?></span>
</td> <td colspan="1"><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data10['NA'] ?? '') ?></span>
</td>  </tr>
  <tr>
    <th>CONSTRUCTION / EXTENSION / IMPROVEMENT ESTIMATE FROM REGISTERED ENGINEER / ARCHITECT</th>
 <td colspan="1"><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data10['NA'] ?? '') ?></span>
</td> <td colspan="1"><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data10['NA'] ?? '') ?></span>
</td> <td colspan="1"><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data10['NA'] ?? '') ?></span>
</td> <td colspan="1"><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data10['NA'] ?? '') ?></span>
</td>  </tr>
  <tr>
    <th>SALES DEED / AGREEMENT DETAIL (CIDCO ALLOTMENT LETTER)</th>
 <td colspan="1"><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data10['NA'] ?? '') ?></span>
</td> <td colspan="1"><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data10['NA'] ?? '') ?></span>
</td> <td colspan="1"><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data10['NA'] ?? '') ?></span>
</td> <td colspan="1"><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data10['NA'] ?? '') ?></span>
</td>  </tr>
  <tr>
    <th>REMARKS ON DOCUMENT VERIFIED:</th>
    <td colspan="5"><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data9['list_documents'] ?? '') ?></span></td>
  </tr>
</table>
<table border="1">
 <tr>
    <td colspan="5" class="section-title">TECHNICAL PARAMETERS (AS PER NATIONAL DISASTER MANAGEMENT NORMS)</td>
  </tr>
  <tr>
    <th>SEISMIC ZONE</th>
     <td><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data4['seismic_zone'] ?? '') ?></span>
</td>
    <th>STRUCTURE TYPE</th>
     <td><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data4['structure_type'] ?? '') ?></span>
</td>
    <th>FOOTING / FOUNDATION TYPE</th>
<td><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars('Open Footing') ?></span></td>
  </tr>
  <tr>
    <th>ROOF TYPE</th>
     <td><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data4['roof_type'] ?? '') ?></span>
</td>
    <th>TYPE OF MASONARY</th>
        <td><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars('Brick Masonary') ?></span></td> 
    <th>SOIL TYPE</th>
        <td><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars('Black Cotton Soil') ?></span></td> 
  </tr>
  <tr>
    <th>CYCLONE ZONE (DESIGN WIND SPEED M/S)</th>
 <td><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars('Good') ?></span></td>
    <th>ENVIRONMENTAL EXPOSURE CONDITION</th>
    <td><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars('Good') ?></span></td>
    <th>FLOOD PRONE AREA (YES / NO)</th>
   <td><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars('No') ?></span></td>
  </tr>
</table>
<table border="1">
  <tr>
    <td colspan="7" class="section-title">PROPERTY STAGE OF CONSTRUCTION</td>
  </tr>
  <tr>
    <th>S. NO.</th>
    <th>ACTIVITY</th>
    <th>ALLOTED CONSTRUCTION STAGE IN %</th>
    <th>PRESENT COMPLETION IN %</th>
    <th>NO OF FLOOR COMPLETED</th>
    <th colspan="2">REMARKS</th>
  </tr>
  <tr>
     <td>1</td>
     <td>FOUNDATION</td>
    <td><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars('10.00%') ?></span></td>
     <td><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data10['NA'] ?? '') ?></span>
</td>
     <td><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data10['NA'] ?? '') ?></span>
</td>
     <td rowspan="8" colspan="2">
      <span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data9['positive_report'] ?? '') ?></span>
</td>
  </tr>
  <tr>
     <td>2</td>
     <td>PLINTH</td>
      <td><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars('10.00%') ?></span></td>
     <td><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data8['plinth_present_completion'] ?? '') ?></span>
</td>
     <td><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data10['NA'] ?? '') ?></span>
</td>
     
  </tr>
  <tr>
     <td>3</td>
     <td>BRICKWORK UP TO SLAB</td>
     <td><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars('15.00%') ?></span></td>
     <td><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data8['brickwork_present_completion'] ?? '') ?></span>
</td>
     <td><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data10['NA'] ?? '') ?></span>
</td>
     
  </tr>
  <tr>
     <td>4</td>
     <td>SLAB / RCC CASTING</td>
    <td><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars('30.00%') ?></span></td>
     <td><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data8['rcc_present_completion'] ?? '') ?></span>
</td>
     <td><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data10['NA'] ?? '') ?></span>
</td>
  </tr>
  <tr>
     <td>5</td>
     <td>INSIDE / OUTSIDE PLASTER</td>
<td><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars('10.00%') ?></span></td>
     <td><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data8['internal_plaster_present_completion'] ?? '') ?><?= htmlspecialchars($data8['external_plaster_present_completion'] ?? '') ?></span>
</td>
     <td><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data10['NA'] ?? '') ?></span>
</td>
  </tr>
  <tr>
     <td>6</td>
     <td>FLOORING WORK</td>
    <td><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars('10.00%') ?></span></td>
     <td><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data8['flooring_present_completion'] ?? '') ?></span>
</td>
     <td><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data10['NA'] ?? '') ?></span>
</td>
  </tr>
  <tr>
     <td>7</td>
     <td>ELECTRIFICATION</td>
    <td><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars('5.00%') ?></span></td>
     <td><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data10['NA'] ?? '') ?></span>
</td>
     <td><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data10['NA'] ?? '') ?></span>
</td>
  </tr>
  <tr>
     <td>8</td>
     <td>WOODWORK & PAINTING</td>
    <td><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars('10.00%') ?></span></td>
     <td><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data10['NA'] ?? '') ?></span>
</td>
     <td><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data10['NA'] ?? '') ?></span>
</td>
  </tr>
  <tr>
     <td colspan="2">TOTAL COMPLETION (%)</td>
<td><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars('100%') ?></span></td>
     <td><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data8['stage_construction_actual_present_completion'] ?? '') ?></span>
</td>
     <td colspan="2"><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data10['NA'] ?? '') ?></span>
</td>
  </tr>

    <tr>
     <td colspan="4"></td>
<td>RECOMMENDATION</td>
     <td><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data8['stage_construction_recommend_present_completion'] ?? '') ?></span>
</td>
  </tr>
</table>

<table border="1">
  <tr>
    <th>IS THE PROPERTY TECHNICALLY ACCEPTABLE</th>
     <td><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data9['positive_report'] ?? '') ?></span>
</td>
    <th>MARKETABILITY OF PROPERTY</th>
     <td><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data9['markebility'] ?? '') ?></span>
</td>
  </tr>
</table>
<table>
    <tr>
    <td colspan="6" class="section-title">REMARKS ON THE PROPERTY</td>
    </tr>
    <tbody>
      <tr>
      <td colspan="2"><span style="white-space: pre-line; font-size:14px; display: block; text-align: left; padding: 0; margin: 0;">
        <?= htmlspecialchars($data10['remarks'] ?? '') ?>
    </span></td>
    </tbody>
  </table>
 
  <table>
  
    <thead>
    <tr>
    <td colspan="6" class="section-title">TECHNICAL DEVIATION</td>
    </tr>
        </thead>
        <tr>
          <th>SR.NO.</th>
          <th>TYPE OF DEVIATION</th>
          <th>DESCRIPTION</th>
        </tr>
    <tbody>
      <tr><th>1</th> <td><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data10['NA'] ?? '') ?></span>
</td> <td><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data10['NA'] ?? '') ?></span>
</td></tr>
      <tr><th>2</th> <td><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data10['NA'] ?? '') ?></span>
</td> <td><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data10['NA'] ?? '') ?></span>
</td></tr>
      <tr><th>3</th> <td><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data10['NA'] ?? '') ?></span>
</td> <td><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data10['NA'] ?? '') ?></span>
</td></tr>
      <tr><th>4</th> <td><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data10['NA'] ?? '') ?></span>
</td> <td><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data10['NA'] ?? '') ?></span>
</td></tr>
    </tbody>
  </table>
  <table>
    <thead>
    <tr>
    <td colspan="6" class="section-title">TSR CONDITION</td>
    </tr>
        </thead>
        <tr>
          <th>SR. NO.</th>
          <th>TSR CONDITION FOR COMPLIANCE</th>
        </tr>
    <tbody>
      <tr><th>1</th> <td><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data10['NA'] ?? '') ?></span>
</td></tr>
      <tr><th>2</th> <td><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data10['NA'] ?? '') ?></span>
</td></tr>
      <tr><th>3</th> <td><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data10['NA'] ?? '') ?></span>
</td></tr>
    </tbody>
    <tr>
         <td style="font-weight:bolder;font-size:15px;">LOCATION MAP AND LATITUDE, LONGITUDE – </td>
        <td><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data3['latitude_value'] ?? '') ?> <?= htmlspecialchars($data3['longitude_value'] ?? '') ?></span></td>
</td>
    </tr>
  </table>
  <table>
<tr><th style="margin-bottom:-18px;">PHOTOGRAPH OF THE PROPERTY</tr></th></table>
<br>

    
<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

$servername = "localhost";
$username   = "root";
$password   = "";
$dbname     = "project_db";

$conn = new mysqli($servername, $username, $password, $dbname);
if ($conn->connect_error) {
    die("Connection failed: " . htmlspecialchars($conn->connect_error));
}

$reference_id = $_SESSION['reference_id'] ?? null;
$reference_id = $_GET['reference_id'] ?? $reference_id;

if ($reference_id) {

    // Map captions
    $captions = [
        'image1'  => 'EXTERNAL PHOTOS',
        'image2'  => 'Kitchen',
        'image3'  => 'Selfie',
        'image4'  => 'Electric Meter',
        'image6'  => 'Other 1',
        'image7'  => 'Other 2',
        'image8'  => 'Other 3',
        'image9'  => 'Other 4',
        'image10' => 'Other 5',
        'image11' => 'Other 6',
        'image12' => 'Other 7',
        'image13' => 'Other 8',
        'image14' => 'Other 9',
        'image15' => 'Other 10',
        'image16' => 'Other 11',
        'image17' => 'Other 12',
        'image18' => 'Other 13',
        'image19' => 'Other 14',
        'image20' => 'Other 15',
    ];

    // === Helper: EXIF-aware orientation detection ===
    function classify_orientation_after_exif(string $imageData): ?string {
        $size = @getimagesizefromstring($imageData);
        if (!$size || !isset($size[0], $size[1])) {
            return null;
        }
        $width  = (int)$size[0];
        $height = (int)$size[1];

        $mime = $size['mime'] ?? '';
        if ($mime === 'image/jpeg' && function_exists('exif_read_data')) {
            $tmp = @tempnam(sys_get_temp_dir(), 'exif_');
            if ($tmp !== false) {
                @file_put_contents($tmp, $imageData);
                $exif = @exif_read_data($tmp);
                @unlink($tmp);

                if (!empty($exif['Orientation'])) {
                    $orientation = (int)$exif['Orientation'];
                    if ($orientation === 6 || $orientation === 8) {
                        $t = $width; $width = $height; $height = $t;
                    }
                }
            }
        }
        return ($width >= $height) ? 'horizontal' : 'vertical';
    }

    // === Helper: Fix orientation physically with Imagick ===
    function fixImageOrientation($binaryData) {
        $img = new Imagick();
        $img->readImageBlob($binaryData);

        switch ($img->getImageOrientation()) {
            case Imagick::ORIENTATION_BOTTOMRIGHT:
                $img->rotateImage("#000", 180);
                break;
            case Imagick::ORIENTATION_RIGHTTOP:
                $img->rotateImage("#000", 90);
                break;
            case Imagick::ORIENTATION_LEFTBOTTOM:
                $img->rotateImage("#000", -90);
                break;
        }

        $img->setImageOrientation(Imagick::ORIENTATION_TOPLEFT);
        $fixed = $img->getImageBlob();
        $img->destroy();

        return $fixed;
    }

    $sql = "SELECT 
                image1, image2, image3, image4, 
                image6, image7, image8, image9, 
                image10, image11, image12, image13, image14, image15, image16, image17, image18, image19, image20
            FROM final_uploaded_images 
            WHERE reference_id = ?";

    $stmt = $conn->prepare($sql);
    if ($stmt === false) {
        die("Error preparing the SQL statement: " . htmlspecialchars($conn->error));
    }

    $stmt->bind_param("s", $reference_id);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result && $result->num_rows > 0) {
        $horizontal_images = [];
        $vertical_images   = [];

        while ($row = $result->fetch_assoc()) {
            foreach ($row as $key => $imageData) {
                if (!empty($imageData)) {

                    // Actually fix image before displaying
                    $fixedData = fixImageOrientation($imageData);

                    $orientation = classify_orientation_after_exif($fixedData) ?? 'horizontal';
                    $imgString   = base64_encode($fixedData);
                    $caption     = $captions[$key] ?? 'Image';

                    $item = [
                        'data'    => $imgString,
                        'caption' => $caption,
                        'alt'     => $key,
                    ];

                    if ($orientation === 'horizontal') {
                        $horizontal_images[] = $item;
                    } else {
                        $vertical_images[]   = $item;
                    }
                }
            }
        }

 
// Output as a stable 4-column table (works in wkhtmltopdf)
$all_images = array_merge($vertical_images, $horizontal_images);

echo '<table class="image-grid">';
$rows = array_chunk($all_images, 4);
foreach ($rows as $row) {
    echo '<tr>';
    foreach ($row as $img) {
        echo '<td>';
        echo '<div class="img-wrap">';
        echo '<img src="data:image/jpeg;base64,' . $img['data'] . '" alt="' . htmlspecialchars($img['alt']) . '">';
        echo '<div class="caption">' . htmlspecialchars($img['caption']) . '</div>';
        echo '</div>';
        echo '</td>';
    }
    // pad remaining cells to keep 4 columns
    $remaining = 4 - count($row);
    if ($remaining > 0) {
        echo str_repeat('<td></td>', $remaining);
    }
    echo '</tr>';
}
echo '</table>';

    } else {
        echo "<p style='text-align:center;'>No images found.</p>";
    }

    $stmt->close();
} else {
    echo "<p style='text-align:center;'>Reference ID is missing.</p>";
}
?>
 <table>
 
  <tr>

<div class="google-map-container">
<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "project_db";
$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$reference_id = $_SESSION['reference_id'] ?? null;
$reference_id = $_GET['reference_id'] ?? $reference_id;

if ($reference_id) {
    $sql = "SELECT image5 FROM final_uploaded_images WHERE reference_id = ?";
    $stmt = $conn->prepare($sql);
    if ($stmt === false) {
        die("Error preparing the SQL statement: " . $conn->error);
    }

    $stmt->bind_param("s", $reference_id);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows > 0) {
        $row = $result->fetch_assoc();
        if (!empty($row['image5'])) {
 
            echo '<div><img src="data:image/jpeg;base64,' . base64_encode($row['image5']) . '" alt="Google Map"><p>Google Map</p></div>';
        } else {
            echo "<p style='text-align:center;'>Google Map image not available.</p>";
        }
    } else {
        echo "<p style='text-align:center;'>No record found for Google Map image.</p>";
    }

    $stmt->close();
} else {
    echo "<p style='text-align:center;'>Reference ID is missing.</p>";
}
?>
</tr>
</div>
    </table>



      <table style="margin-top:15px;">
    <tr>
      <th>APPLICANT / CO-AAPLICANT NAME </th>
    <td><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data1['customerName'] ?? '') ?>
    </span></td>      <th>FILE NO/REF.NO/LOS NO.</th>
       <td><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data1['reference_id'] ?? '') ?></span>
</td>
    </tr>
    <tr>
      <th>ADDRESS DETAIL</th>
  <td colspan="4"><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data3['address_per_site'] ?? '') ?>
    </span></td></td>
    </tr>
        <tr>
      <th>TSR PREPARED BY</th>
       <td><input type="text" readonly  value="<?=  $report_name ?>">
</td>
      <th>VISIT DONE BY (NAME)</th>
       <td><input type="text" readonly  name="engineer_id"  value="<?= $engineer_name ?>">
</td>
    </tr>
    <tr>
      <th>TSR PRAPARED DATE</th>
       <td><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
 <?= htmlspecialchars(date('d M Y h:i A', strtotime($data1['report_assigned_at'] ?? ''))) ?></span>
</td>
      <th>VISIT DATE</th>
       <td><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data1['fe_to_coordinator_assign_at'] ?? '') ?></span>
</td>
    </tr>
    <tr>
      <th>SIGNATURE, STAMP AND DATE</th>
       <td colspan="4"><input type="text" readonly  value="">
</td>
    </tr>
  </table>
</div>

     <!-- <button onclick="window.print()">Download PDF</button> -->
    <form method="post">
  <input type="hidden" name="download_images" value="1">
  <button type="submit">Download All Images</button>
</form>
     <!-- <button onclick="window.print()">Download PDF</button> -->
  <button id="downloadPdf" onclick="setPrintMargins()">DOWNLOAD PDF</button>
  <script>
    document.getElementById('downloadPdf').addEventListener('click', () => {
      // Select the content you want to convert to PDF
      const element = document.getElementById('content');
      const options = {
        margin:[0,0],
        filename:'report.pdf',
        image: { type: 'jpeg', quality: 0.98 },
        html2canvas: { scale: 2 },
        jsPDF: { unit: 'in', format: 'letter', orientation: 'portrait' }
      };

      // Generate and download the PDF
      html2pdf().set(options).from(element).save();
    });
    function setPrintMargins() {
      const style = document.createElement('style');
      style.innerHTML = `
      @media print {
          body {
            margin:0.5;
          }
        }
      `;
      document.head.appendChild(style);
      window.print();
    }
    // Disable all input fields in the form
    document.querySelectorAll('input').forEach(function(input) {
        input.disabled = true;  // Disables the field completely
    });
    </script>
     </div>
</body>
</html>