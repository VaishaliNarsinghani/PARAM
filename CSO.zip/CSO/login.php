<?php
$host = "localhost";
$user = "root";
$password = "";
$db = "project_db";

session_start();

$data = mysqli_connect($host, $user, $password, $db);
if ($data === false) {
    die("Connection error");
}

$error_message = "";

if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST["login"])) {
    $cso_id = $_POST["cso_id"];
    $password = $_POST["password"];
    $user_otp = $_POST["otp"];

    // Validate CSO ID and password
    $stmt = $data->prepare("SELECT * FROM cso_login WHERE cso_id = ?");
    $stmt->bind_param("s", $cso_id);
    $stmt->execute();
    $result = $stmt->get_result();
    $row = $result->fetch_assoc();
    $stmt->close();

    if ($row && $password === $row["password"]) {
        // Check today's OTP
        $today = date("Y-m-d");
        $otp_stmt = $data->prepare("SELECT otp FROM otp_login WHERE date = ?");
        $otp_stmt->bind_param("s", $today);
        $otp_stmt->execute();
        $otp_result = $otp_stmt->get_result();
        $otp_row = $otp_result->fetch_assoc();
        $otp_stmt->close();

        if ($otp_row && $user_otp === $otp_row["otp"]) {
            // Successful login
            $_SESSION["cso_id"] = $cso_id;
            session_regenerate_id(true);

            header("Location: pending.php");
            exit();
        } else {
            $error_message = "Invalid OTP.";
        }
    } else {
        $error_message = "Invalid login credentials.";
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="shortcut icon" href="favicon.ico" type="image/x-icon">
    <title>Magpie Engineering Login</title>
    <link rel="shortcut icon" href="favicon.png" type="image/x-icon"> 
    <link rel="stylesheet" href="login.css">
</head>
<body>
    <div class="login-container">
        <div class="login-header">
            Magpie Engineering Pvt. Ltd.
            <form id="loginForm" method="POST" action="">
                <div class="input-group">
                    <input type="text" name="cso_id" placeholder="User ID" class="input-field" required>
                </div>
                <div class="input-group">
                    <input type="password" name="password" placeholder="Password" class="input-field" required>
                </div>
                <div class="input-group">
                    <input type="text" name="otp" placeholder="Enter OTP" class="input-field" required>
                </div>
                <button type="submit" name="login" class="login-btn">Log In</button>
            </form>
            <?php if (!empty($error_message)) : ?>
                <div class="error-message"><?php echo $error_message; ?></div>
            <?php endif; ?>
        </div>
    </div>
</body>
</html>
