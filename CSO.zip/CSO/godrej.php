<?php include('auth.php'); ?>
<?php
ini_set('display_errors', 1);
error_reporting(E_ALL);

// Increase PHP execution time and memory limit
ini_set('max_execution_time', 600); // Increase execution time to 600 seconds (10 minutes)
ini_set('memory_limit', '4096M'); // Increase memory limit to 4096MB
// Start session


$servername = "localhost";
$username = "root";
$password = "";
$dbname = "project_db";

// Create DB connection
$conn = new mysqli($servername, $username, $password, $dbname);
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

if (!isset($_SESSION['reference_id'])) {
    die("Reference ID not found in session.");
}
$reference_id = $_SESSION['reference_id'];

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['download_images'])) {

    // Get customer name
    $stmt_name = $conn->prepare("SELECT customerName FROM mis WHERE reference_id = ?");
    $stmt_name->bind_param("s", $reference_id);
    $stmt_name->execute();
    $result_name = $stmt_name->get_result();
    $customerName = "customer";
    if ($row = $result_name->fetch_assoc()) {
        $customerName = preg_replace('/[^a-zA-Z0-9]/', '', $row['customerName']);
    }
    $stmt_name->close();

    // Fetch image BLOBs
    $stmt = $conn->prepare("SELECT image1, image2, image3, image4, image5, image6, image7, image8, image9, image10, image11, image12,image13, image14, image15, image16, image17, image18, image19, image20 FROM final_uploaded_images WHERE reference_id = ?");    $stmt->bind_param("s", $reference_id);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows > 0 && ($row = $result->fetch_assoc())) {
        $tempDir = sys_get_temp_dir() . DIRECTORY_SEPARATOR . uniqid('images_', true);
        mkdir($tempDir);

        $imageFiles = [];
        for ($i = 1; $i <= 12; $i++) {
            if (!empty($row["image$i"])) {
                $filename = $tempDir . DIRECTORY_SEPARATOR . "image{$i}.jpg";
                file_put_contents($filename, $row["image$i"]);
                $imageFiles[] = $filename;
            }
        }

        if (empty($imageFiles)) {
            die("No images to download.");
        }

        // Create ZIP
        $zipFileName = "images_" . preg_replace('/[^a-zA-Z0-9]/', '_', $reference_id) . "_{$customerName}.zip";
        $zipPath = $tempDir . DIRECTORY_SEPARATOR . $zipFileName;

        $zip = new ZipArchive();
        if ($zip->open($zipPath, ZipArchive::CREATE) !== TRUE) {
            die("Failed to create ZIP file.");
        }

        foreach ($imageFiles as $file) {
            $zip->addFile($file, basename($file));
        }
        $zip->close();

        // Send ZIP to browser
        header('Content-Type: application/zip');
        header('Content-Disposition: attachment; filename="' . basename($zipFileName) . '"');
        header('Content-Length: ' . filesize($zipPath));
        flush();
        readfile($zipPath);

        // Cleanup
        foreach ($imageFiles as $file) {
            unlink($file);
        }
        unlink($zipPath);
        rmdir($tempDir);
        exit;
    } else {
        echo "<p style='color:red;'>No image data found for this reference ID.</p>";
    }
}

$page = isset($_GET['page']) ? $_GET['page'] : 1;
$limit = 50;
$offset = ($page - 1) * $limit;
$sql_property = "SELECT * FROM mis WHERE reference_id = ? LIMIT $limit OFFSET $offset";
$stmt_property = $conn->prepare($sql_property);
$stmt_property->bind_param("s", $reference_id);
$stmt_property->execute();
$result_property = $stmt_property->get_result();
$data1 = $result_property->fetch_assoc();




// Fetch data from property_details table
$sql_property = "SELECT * FROM property_details WHERE reference_id = ?";
$stmt_property = $conn->prepare($sql_property);
$stmt_property->bind_param("s", $reference_id);
$stmt_property->execute();
$result_property = $stmt_property->get_result();
$data2= $result_property->fetch_assoc();




// Fetch data from area_valuation table
$sql_area = "SELECT * FROM address_details WHERE reference_id = ?";
$stmt_area = $conn->prepare($sql_area); 
$stmt_area->bind_param("s", $reference_id);
$stmt_area->execute();
$result_area = $stmt_area->get_result();
$data3 = $result_area->fetch_assoc();





// Fetch data from area_valuation table
$sql_area = "SELECT * FROM critical_parameters WHERE reference_id = ?";
$stmt_area = $conn->prepare($sql_area); 
$stmt_area->bind_param("s", $reference_id);
$stmt_area->execute();
$result_area = $stmt_area->get_result();
$data4 = $result_area->fetch_assoc();

 
// Fetch data from area_valuation table
$sql_area = "SELECT * FROM surroundings_details WHERE reference_id = ?";
$stmt_area = $conn->prepare($sql_area); 
$stmt_area->bind_param("s", $reference_id);
$stmt_area->execute();
$result_area = $stmt_area->get_result();
$data5 = $result_area->fetch_assoc();
$stmt_area->close();
 
// Fetch data from area_valuation table
$sql_area = "SELECT * FROM area_valuation WHERE reference_id = ?";
$stmt_area = $conn->prepare($sql_area); 
$stmt_area->bind_param("s", $reference_id);
$stmt_area->execute();
$result_area = $stmt_area->get_result();
$data6 = $result_area->fetch_assoc();
$stmt_area->close();
 



// Fetch data from area_valuation table
$sql_area = "SELECT * FROM floor_details WHERE reference_id = ?";
$stmt_area = $conn->prepare($sql_area); 
$stmt_area->bind_param("s", $reference_id);
$stmt_area->execute();
$result_area = $stmt_area->get_result();
$data8= $result_area->fetch_assoc();
$stmt_area->close();
 


// Fetch data from area_valuation table
$sql_area = "SELECT * FROM technical_details WHERE reference_id = ?";
$stmt_area = $conn->prepare($sql_area); 
$stmt_area->bind_param("s", $reference_id);
$stmt_area->execute();
$result_area = $stmt_area->get_result();
$data9 = $result_area->fetch_assoc();
$stmt_area->close();
 
// Fetch data from area_valuation table
$sql_area = "SELECT * FROM remarks_table WHERE reference_id = ?";
$stmt_area = $conn->prepare($sql_area); 
$stmt_area->bind_param("s", $reference_id);
$stmt_area->execute();
$result_area = $stmt_area->get_result();
$data10 = $result_area->fetch_assoc();
$stmt_area->close();


// Step 1: Fetch the engineer_id from the mis table
$sql_mis = "SELECT engineer_id FROM mis WHERE reference_id = ?";
$stmt_mis = $conn->prepare($sql_mis);
$stmt_mis->bind_param("s", $reference_id);
$stmt_mis->execute();
$result_mis = $stmt_mis->get_result();
$row_mis = $result_mis->fetch_assoc();
$stmt_mis->close(); 

if ($row_mis) {
    $engineer_id = $row_mis['engineer_id'];

    // Step 2: Fetch the engineer's name from engineer_login table
    $sql_engineer = "SELECT name FROM engineer_login WHERE engineer_id = ?";
    $stmt_engineer = $conn->prepare($sql_engineer);
    $stmt_engineer->bind_param("s", $engineer_id);
    $stmt_engineer->execute();
    $result_engineer = $stmt_engineer->get_result();
    $row_engineer = $result_engineer->fetch_assoc();
    $stmt_engineer->close();

    if ($row_engineer) {
        $engineer_name = $row_engineer['name'];
         //echo "Engineer Name: " . $engineer_name;
    } else {
        echo "Engineer not found.";
    }
} else {
    echo "No engineer assigned for this reference_id.";
}



// Step 1: Fetch the engineer_id from the mis table
$sql_mis = "SELECT report_id FROM mis WHERE reference_id = ?";
$stmt_mis = $conn->prepare($sql_mis);
$stmt_mis->bind_param("s", $reference_id);
$stmt_mis->execute();
$result_mis = $stmt_mis->get_result();
$row_mis = $result_mis->fetch_assoc();
$stmt_mis->close(); 

if ($row_mis) {
    $report_id = $row_mis['report_id'];

    // Step 2: Fetch the engineer's name from engineer_login table
    $sql_engineer = "SELECT name FROM report_login WHERE report_id = ?";
    $stmt_engineer = $conn->prepare($sql_engineer);
    $stmt_engineer->bind_param("s", $report_id);
    $stmt_engineer->execute();
    $result_engineer = $stmt_engineer->get_result();
    $row_engineer = $result_engineer->fetch_assoc();
    $stmt_engineer->close();

    if ($row_engineer) {
        $report_name = $row_engineer['name'];
         //echo "Engineer Name: " . $report_name;
    } else {
        echo "Engineer not found.";
    }
} else {
    echo "No engineer assigned for this reference_id.";
}


// Step 1: Fetch the engineer_id from the mis table
$sql_mis = "SELECT report_drafter_to_technical FROM mis WHERE reference_id = ?";
$stmt_mis = $conn->prepare($sql_mis);
$stmt_mis->bind_param("s", $reference_id);
$stmt_mis->execute();
$result_mis = $stmt_mis->get_result();
$row_mis = $result_mis->fetch_assoc();
$stmt_mis->close(); 

if ($row_mis) {
    $report_drafter_to_technical = $row_mis['report_drafter_to_technical'];

    // Step 2: Fetch the engineer's name from engineer_login table
    $sql_engineer = "SELECT name FROM technical_login WHERE technical_manager_id = ?";
    $stmt_engineer = $conn->prepare($sql_engineer);
    $stmt_engineer->bind_param("s", $report_drafter_to_technical);
    $stmt_engineer->execute();
    $result_engineer = $stmt_engineer->get_result();
    $row_engineer = $result_engineer->fetch_assoc();
    $stmt_engineer->close();

    if ($row_engineer) {
        $technical_name = $row_engineer['name'];
        //echo "Engineer Name: " . $technical_name;
    } else {
        echo "Engineer not found.";
    }
} else {
    echo "No engineer assigned for this reference_id.";
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Valuation Form</title>
    <link rel="shortcut icon" href="favicon.png" type="image/x-icon"> 
  <style>
    body {
      font-family: Arial, sans-serif;
      font-size: 13px;
      padding: 20px;
    }

    table {
      width: 100%;
      border-collapse: collapse;
      table-layout: fixed;
    }

    td, th {
      border: 1px solid #000;
      padding:2px;
      vertical-align: top;
    }

    .section-header {
      font-weight: bold;
      text-align: center;
    }

    input, textarea {
      width: 100%;
      border: none;
      padding: 4px;
      font-size: 13px;
      box-sizing: border-box;
    }

header {
  display: flex;
  align-items: center;
}

.logo img {
  width: 120px;
  margin-left:30px;
  height: auto;
}

.header-content {
  text-align: center;
  flex: 1;
  margin-left:-190x
}

header h1 {
  margin: 0;
  font-weight:700;
  font-size:27px;
  color: #a60000;
  
}

header p {
  margin: 2px 0;
  font-size: 14px;
  font-weight: bolder;
  color: #9e2424;
  
}
    textarea {
      resize: vertical;
      min-height: 40px;
    }
       
/* Force a stable 4-column grid that wkhtmltopdf respects */
.image-gallery { width: 100%; }
.image-grid { width: 100%; border-collapse: collapse; table-layout: fixed; }
.image-grid tr { page-break-inside: avoid; }
.image-grid td { width: 25%; padding: 6px; vertical-align: top; }

.image-grid .img-wrap { display: block; }
.image-grid img { display: block; width: 100%; height: auto; }
.image-grid .caption { font-size: 12px; text-align: center; margin-top: 4px; }

/* If you had a flex layout before, neutralize it */
.image-gallery { display: block !important; }



    /* Print-specific rules */
    @media print {
      .no-print {
        display: none !important;
      }

      body {
        margin: 0;
      }
 
    }
  button{
    padding:8px;
    margin-left:45%;
    background-color:#808485;
    color:white;
    font-weight:700;
    font-style:italic;
  }
  button:hover{
    background-color:rgba(216,216,216,255);
    color:white;
  }
    .google-map-container {
    max-width: 90%;           /* Keep container within page width */
    margin: 20px auto;        /* Center it with spacing */
    border: 2px solid #ccc;   /* Light gray border */
    padding: 10px;
    box-shadow: 0 0 10px rgba(0, 0, 0, 0.1); /* Optional: subtle shadow */
    background-color: #f9f9f9; /* Optional: light background */
    border-radius: 8px;       /* Rounded corners */
    text-align: center;       /* Center image and caption */
}

.google-map-container img {
    max-width: 100%;          /* Scale image to container */
    height: auto;             /* Keep image aspect ratio */
    display: inline-block;
    border: 1px solid #999;   /* Border around the image itself */
    border-radius: 4px;
} 
  </style>
</head>
<body>
  
<div class="content">
    <header>
      <div class="logo">
        <img src="images/logo.png" alt="Magpie Logo">
      </div>
      <div class="header-content">
        <h1>MAGPIE ENGINEERING PVT. LTD.</h1>
        <p>Valuer Designer Architects</p>
        <p>Reg.Add:5th Floor E-509,Casa Green ,A.B.Road,Talawall Chanda,Indore(M.P)-453771</p>
        <p>Office No. 201, 2nd Floor, Gravity Mall, Warehouse Road, Mechanic Nagar,near Vijay Nagar, Madhya Pradesh - 452011.</p>
      </div>
    </header>
<table>
  <tr>
    <td>Case Ref. No.</td>
    <td colspan="3"><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data1['applicationNo'] ?? '') ?></span></td>
</tr>
<tr>
    <td>Name of Valuation Agency</td>
    <td>  <span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars('Magpie Engineering Pvt. Ltd.') ?></span></td>
    <td>Date of Technical Initiation</td>
    <td><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data1['report_assigned_at'] ?? '') ?></span></td>
  </tr>
  <tr>
    <td>Name of Customer/Applicant</td>
    <td><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data1['customerName'] ?? '') ?>
    </span></td>    <td>Date & Time of Site Visit</td>
    <td><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data1['fe_to_coordinator_assign_at'] ?? '') ?></span></td>
</tr>
  <tr>
    <td>Request From</td>
    <td><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data10['NA'] ?? '') ?></span></td>
      <td>Date of Report Release</td>
    <td><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
 <?= htmlspecialchars(date('d M Y h:i A', strtotime($data1['report_assigned_at'] ?? ''))) ?></span></td>
  </tr>
</table>
<table>
  <tr>
    <td colspan="4" class="section-header">Data From Valuation Request Form (VRF)</td>
  </tr>
  <tr>
    <td>Proposal ID/Application ID</td>
    <td><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data1['applicationNo'] ?? '') ?></span></td>
    <td>Case Type</td>
    <td><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data1['caseType'] ?? '') ?></span></td>
</tr>
<tr>
    <td>Branch Name/ID</td>
    <td><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data1['bank_branchname'] ?? '') ?></span></td>
    <td>Request From GFL Employe</td>
    <td><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data10['NA'] ?? '') ?></span></td>
  </tr>
  <tr>
    <td>Name of Current Owner/Seller</td>
    <td colspan="3"><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data9['owner_name'] ?? '') ?></span></td>
</tr>
<tr>
    <td>Name of the Person met at Site & Contact No.</td>
    <td colspan="3"><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data2['person_meet_at_site_contact'] ?? '') ?></span></td>
  </tr>
  </table>
  <table>
  <tr>
    <td colspan="7" class="section-header">Address</td>
  </tr>
  <tr>
    <td rowspan="4">Address of the Property being Appraised</td>
  </tr>
  <tr>
    <td>As per VRF</td>
    <td colspan="5"><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data1['address'] ?? '') ?></span></td>
  </tr>
  <tr>
    <td>As per Legal Documents</td>
    <td colspan="5"><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data3['address_per_document'] ?? '') ?>
</span></td>
  </tr>
  <tr>
    <td>As per Actual at Site</td>
    <td colspan="5"><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data3['address_per_site'] ?? '') ?>
    </span></td>
  </tr>
  <tr>
    <td>Documents Provided by GHF</td>
    <td colspan="6"><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data1['document_provided_for_valuation'] ?? '') ?></span></td>
  </tr>

  <tr>
    <td colspan="7" class="section-header">Location & Property Specific Details (Based on Site Visit)</td>
  </tr>
  <tr>
    <td colspan="2">Status of Holding</td>
    <td colspan="2"><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data2['property_leasehold_freehold'] ?? '') ?></span></td>
    <td>Delivery Agency</td>
    <td colspan="2"><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data10['NA'] ?? '') ?></span></td>
  </tr>
  <tr>
    <td colspan="2">Type of Property</td>
    <td colspan="2"><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data2['property_unit_type'] ?? '') ?></span></td>
    <td>Name of the State</td>
    <td colspan="2"><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data3['address_line_4_as_per_doc'] ?? '') ?></span></td>
  </tr>
  <tr>
    <td colspan="2">Sub Locality</td>
    <td colspan="2"><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data2['class_of_locality'] ?? '') ?></span></td>
     <td>Main Locality</td>
    <td colspan="2"><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data2['class_of_locality'] ?? '') ?></span></td>
    </tr>
    <tr>
    <td colspan="2">Street on which Property is located</td>
    <td colspan="2"><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data2['approach_road_to_property'] ?? '') ?></span></td>
    <td>Nearest Landmark</td>
    <td colspan="2"><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data3['landmark_1'] ?? '') ?> <?= htmlspecialchars($data3['landmark_2'] ?? '') ?></span></td>
  </tr>
  <tr>
    <td colspan="2">Pin Code</td>
    <td colspan="2"><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data3['pin_code'] ?? '') ?></span></td>
    <td>Occupation Status</td>
    <td colspan="2"><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data2['occupancy_status'] ?? '') ?></span></td>
  </tr>
  <tr>
    <td colspan="2">Locality/Zoning type as per Latest Development Master Plan</td>
    <td colspan="2"><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data4['zoning_development_plan'] ?? '') ?></span></td>
    <td>Property Usage</td>
    <td colspan="2"><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data4['current_property_usage'] ?? '') ?></span></td>
    </tr>
    <tr>
    <td colspan="2">Property Identifiable</td>
    <td colspan="2"><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data10['NA'] ?? '') ?></span></td>
    <td>Property Demarcated separately</td>
    <td colspan="2"><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data2['demarcated_at_site'] ?? '') ?></span></td>
  </tr>
  <tr>
    <td colspan="2">Identified Through</td>
    <td colspan="2"><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data2['NA'] ?? '') ?></span></td>
    <td>Name of City/Town/Village</td>
    <td colspan="2"><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data3['address_line_3_as_per_doc'] ?? '') ?></span></td>
  </tr>
  <tr>
    <td colspan="2">Roof Construction</td>
    <td colspan="2"><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data4['roof_type'] ?? '') ?></span></td>
    <td>Type of Structure </td>
    <td colspan="2"><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data4['structure_type'] ?? '') ?></span></td>
    </tr>
       <tr>
    <td colspan="2">No. of Floors in the building</td>
    <td colspan="2"><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data10['NA'] ?? '') ?></span></td>
    <td>Located on Floor No.</td>
    <td colspan="2"><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars('Refer Address') ?></span></td>
</tr>
    <td colspan="2">Total No. of Flats / Units in building</td>
    <td colspan="2"><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data10['NA'] ?? '') ?></span></td>
     <td>Internal Quality of construction</td>
    <td colspan="2"><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data8['Present_quality_of_structure'] ?? '') ?></span></td>
  </tr>
  <tr>
    <td colspan="2">External Finishing</td>
    <td colspan="2"><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data10['NA'] ?? '') ?></span></td>
    <td>Type of Flooring</td>
    <td colspan="2"><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data10['NA'] ?? '') ?></span></td>
  </tr>
  <tr>
    <td colspan="2">Present Age of the Property in Yrs</td>
    <td colspan="2"><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data2['age_of_property'] ?? '') ?></span></td>
    <td>Future Physical Life of Property in Yrs</td>
    <td colspan="2"><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data2['residual_age_of_property'] ?? '') ?></span></td>
  </tr>
  <tr>
    <td colspan="2">Latitude</td>
    <td colspan="2"><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data3['latitude_value'] ?? '') ?></span></td>
    <td>Longitude</td>
    <td colspan="2"><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data3['longitude_value'] ?? '') ?></span></td>
</tr>
<tr>
    <td colspan="3">Extra Amenities available</td>
        <td colspan="4"><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data10['NA'] ?? '') ?></span></td>
  </tr>
</table>
<table>
  <tr>
    <td colspan="4" class="section-header">Zone/Locality/Surrounding/Civic Amenities</td>
  </tr>
  <tr>
    <td>Infrastructure in the area</td>
    <td><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data2['infra_building'] ?? '') ?></span></td>
    <td>Class of Locality</td>
    <td><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data2['class_of_locality'] ?? '') ?></span></td>
  </tr>
</table>
<table>
  <tr>
    <td>Type of Road</td>
    <td><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data2['type_of_approach_road'] ?? '') ?></span></td>
    <td>Width of the Road in ft</td>
    <td><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data2['width_of_approach_road'] ?? '') ?></span></td>
  </tr>
  <tr>
    <td>Electrification/Electric poles observed</td>
    <td><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data10['NA'] ?? '') ?></span></td>
    <td>Distance from nearest Bus Stand (Km)</td>
    <td><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data3['nearest_bus_stop_distance'] ?? '') ?></span></td>
  </tr>
  <tr>
    <td>Distance from nearest School/College (Km)</td>
    <td><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data3['nearest_school_college_distance'] ?? '') ?></span></td>
    <td>Distance from nearest Hospital (Km)</td>
    <td><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data3['nearest_hospital_distance'] ?? '') ?></span></td>
  </tr>
  <tr>
    <td>Distance from nearest Market (Km)</td>
    <td><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data10['NA'] ?? '') ?></span></td>
    <td>Distance from Metro Railway/Metro Stn./Airport (Km)</td>
    <td><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data3['nearest_railway_station_distance'] ?? '') ?></span></td>
  </tr>
</table>
<table>
  <tr>
    <td colspan="4" class="section-header">NDMA Guidelines</td>
  </tr>
  <tr>
    <td>Property falls under Seismic Zone</td>
    <td><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data4['seismic_zone'] ?? '') ?></span></td>
    <td>Property Falls under Flood Zone</td>
    <td><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data10['NA'] ?? '') ?></span></td>
  </tr>
  <tr>
    <td>Property Falls in Cyclone Zone</td>
    <td><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data10['NA'] ?? '') ?></span></td>
    <td>Property Falls in CR Zone</td>
    <td><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data10['NA'] ?? '') ?></span></td>
  </tr>
  <tr>
    <td>Degree of Risk Associated</td>
    <td><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data10['NA'] ?? '') ?></span></td>
    <td>Any risk of Demolition / Falls in Road Widening, Forest Land, Govt Notification etc.</td>
    <td><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data9['demolition_risk_1'] ?? '') ?></span></td>
  </tr>
</table>
<br>
<table style="margin-top:-17px;">
  <tr>
    <td colspan="5" class="section-header">Boundaries</td>
  </tr>
  <tr>
    <td></td>
    <td>North</td>
    <td>South</td>
    <td>East</td>
    <td>West</td>
  </tr>
  <tr>
    <td>As per Documents</td>
     <td><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data3['direction_as_per_document_north'] ?? '') ?></span></td>
                <td><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data3['direction_as_per_document_south'] ?? '') ?></span></td>
                <td><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data3['direction_as_per_document_east'] ?? '') ?></span></td>
                <td><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data3['direction_as_per_document_west'] ?? '') ?></span></td>
      <tr>
    <td>As per Site / Actual</td>
       <td><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data3['direction_as_per_site_north'] ?? '') ?></span></td>
                <td><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data3['direction_as_per_site_south'] ?? '') ?></span></td>
                <td><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data3['direction_as_per_site_east'] ?? '') ?></span></td>
                <td><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data3['direction_as_per_site_west'] ?? '') ?></span></td>
         </tr>
  <tr>
    <td>Boundaries Matching</td>
    <td colspan="4"><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data3['boundaries_matching'] ?? '') ?></span></td>
  </tr>
</table>

<br>

<table style="margin-top:-17px;">
  <tr>
    <td colspan="5" class="section-header">Setbacks / Margin (in Ft)</td>
  </tr>
  <tr>
    <td>Setbacks / Margin in the Building (in Ft)</td>
    <td>Front</td>
    <td>Rear</td>
    <td>Left Side</td>
    <td>Right Side</td>
  </tr>
  <tr>
    <td>As per sanctioned/permissible byelaws</td>
    <td><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data10['NA'] ?? '') ?></span></td>
    <td><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data10['NA'] ?? '') ?></span></td>
    <td><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data10['NA'] ?? '') ?></span></td>
    <td><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data10['NA'] ?? '') ?></span></td>
  </tr>
  <tr>
    <td>As per Site / Actual</td>
    <td><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data10['NA'] ?? '') ?></span></td>
    <td><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data10['NA'] ?? '') ?></span></td>
    <td><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data10['NA'] ?? '') ?></span></td>
    <td><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data10['NA'] ?? '') ?></span></td>
  </tr>
</table>

<br>

<table style="margin-top:-17px;">
  <tr>
    <td colspan="2" class="section-header">Height / Storeys</td>
  </tr>
  <tr>
    <td>As per Sanctioned Plan / Permissible Byelaws</td>
    <td><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data10['NA'] ?? '') ?></span></td>
  </tr>
  <tr>
    <td>As per Site / Actual</td>
    <td><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data10['NA'] ?? '') ?></span></td>
  </tr>
</table>

<br>

<table style="margin-top:-17px;">
  <tr>
    <td colspan="6" class="section-header">Area & Accommodation Details</td>
  </tr>
  <tr>
    <td>Floor (Pl mention floor wise)</td>
    <td>Accommodation</td>
    <td>Carpet Area (Sft)</td>
    <td>Actual BUA / Saleable Area (Sft)</td>
    <td>Permissible Area (Sft)</td>
    <td>Adopted Area (Sft)</td>
  </tr>
  <tr>
    <td>Basement / Stilt</td>
    <td><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data10['NA'] ?? '') ?></span></td>
    <td><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data10['NA'] ?? '') ?></span></td>
    <td><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data10['NA'] ?? '') ?></span></td>
    <td><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data10['NA'] ?? '') ?></span></td>
    <td><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data10['NA'] ?? '') ?></span></td>
  </tr>
  <tr>
    <td>Ground Floor Stone</td>
    <td><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data10['NA'] ?? '') ?></span></td>
    <td><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data10['NA'] ?? '') ?></span></td>
    <td><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data10['ground_actual'] ?? '') ?></span></td>
    <td><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data10['ground_permissible'] ?? '') ?></span></td>
    <td><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data10['ground_approved'] ?? '') ?></span></td>
  </tr>
  <tr>
    <td>First Floor Stone</td>
    <td><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data10['NA'] ?? '') ?></span></td>
    <td><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data10['NA'] ?? '') ?></span></td>
    <td><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data8['first_actual'] ?? '') ?></span></td>
    <td><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data8['first_permissible'] ?? '') ?></span></td>
    <td><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data8['first_approved'] ?? '') ?></span></td>
  </tr>
  <tr>
    <td>Second Floor RCC</td>
    <td><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data10['NA'] ?? '') ?></span></td>
    <td><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data10['NA'] ?? '') ?></span></td>
    <td><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data8['second_actual'] ?? '') ?></span></td>
    <td><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data8['second_permissible'] ?? '') ?></span></td>
    <td><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data8['second_approved'] ?? '') ?></span></td>
  </tr>
  <tr>
    <td>Third Floor RCC</td>
    <td><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data10['NA'] ?? '') ?></span></td>
    <td><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data10['NA'] ?? '') ?></span></td>
    <td><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data10['NA'] ?? '') ?></span></td>
    <td><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data10['NA'] ?? '') ?></span></td>
    <td><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data10['NA'] ?? '') ?></span></td>
  </tr>
  <tr>
    <td>4th Floor RCC</td>
    <td><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data10['NA'] ?? '') ?></span></td>
    <td><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data10['NA'] ?? '') ?></span></td>
    <td><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data8['other_actual_floors'] ?? '') ?></span></td>
    <td><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data8['other_permissible_floors'] ?? '') ?></span></td>
    <td><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data8['other_approved_floors'] ?? '') ?></span></td>
  </tr>
  <tr>
    <td>Total</td>
    <td></td>
    <td><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data10['NA'] ?? '') ?></span></td>
    <td><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data8['total_actual_floors'] ?? '') ?></span></td>
    <td><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data8['total_permissible_floors'] ?? '') ?></span></td>
    <td><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data8['total_approved_floors'] ?? '') ?></span></td>
  </tr>
</table>
<table>
  <tr>
    <td colspan="7" class="section-header">Building Approvals & Related Documents</td>
  </tr>
  <tr>
    <td colspan="2">Construction as per approved/ sanctioned plans</td>
    <td colspan="2"><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data10['NA'] ?? '') ?></span></td>
    <td>Details of Approved Plan with approval no and date</td>
    <td colspan="2"><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data9['floor_authority'] ?? '') ?> <?= htmlspecialchars($data9['floor_details'] ?? '') ?></span></td>
  </tr>
  <tr>
    <td colspan="2">CC/OC Number and Date</td>
    <td colspan="2"><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data10['NA'] ?? '') ?></span></td>
        <td>Work Progress observed at</td>
    <td colspan="2"><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data10['NA'] ?? '') ?></span></td>
</tr>
<tr>
    <td colspan="2">If plans not available whether the structure conforming to local byelaws</td>
    <td colspan="2"><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data10['NA'] ?? '') ?></span></td>
    <td>Violations Observed if Any</td>
    <td colspan="2"><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data10['NA'] ?? '') ?></span></td>
  </tr>
  <tr>
    <td colspan="2">Any other docs like Pt-Tax/E-Bill/Society NOC etc</td>
    <td colspan="2"><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data10['NA'] ?? '') ?></span></td>
    <td>RERA Number for Builder Project</td>
    <td colspan="2"><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data9['location_details'] ?? '') ?></span></td>
  </tr>
</table>
<table>
  <tr>
    <td colspan="7" class="section-header">Estimate Analysis (Applicable only in Self Construction Cases)</td>
  </tr>
  <tr>
    <td  colspan="2">Submitted Estimated Cost (in Rs per Sqft)</td>
    <td  colspan="2"><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data10['NA'] ?? '') ?></span></td>
    <td>Total Estimate submitted (in Rs)</td>
    <td  colspan="2"><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data10['NA'] ?? '') ?></span></td>
  </tr>
  <tr>
    <td  colspan="2">Justified Estimated Cost (in Rs per Sqft)</td>
    <td  colspan="2"><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data10['NA'] ?? '') ?></span></td>
    <td>Adoptable / Justified Estimated Cost (in Rs)</td>
    <td colspan="2"><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data10['NA'] ?? '') ?></span></td>
  </tr>
</table>

<br>

<table style="margin-top:-17px;">
  <tr>
    <td colspan="7" class="section-header">Property Valuation</td>
  </tr>
  <tr>
    <td  colspan="7" style="font-weight:bold;">Valuation of Independent House/Bungalow/Commercial/Industrial Building/land</td>
  </tr>
  <tr>
    <td colspan="2">Land Area (in Sqft)</td>
    <td colspan="2"><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data6['final_plot_square_feet'] ?? '') ?></span></td>
    <td>Adoptable Built-up Area (in Sqft)</td>
    <td colspan="2"><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data6['final_construction_square_feet'] ?? '') ?></span></td>
  </tr>
  <tr>
      <td colspan="2">Rate Range of land in the locality (Rs per Sqft)</td>
    <td colspan="2"><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data6['final_plot_rate'] ?? '') ?></span></td>
    <td>Construction Cost (Rs per sqft)</td>
    <td colspan="2"><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data6['final_construction_rate'] ?? '') ?></span></td>
</tr>
<tr>
    <td colspan="2">Recommended Rate of Land (Rs per sqft)</td>
    <td colspan="2"><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data6['plot_rate'] ?? '') ?></span></td>
    <td>Total Construction Value for 100% complete building (in Rs)</td>
    <td colspan="2"><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data6['finally_construction_valuation'] ?? '') ?></span></td>
  </tr>	
  <tr>
    <td colspan="2">Pls specify if any special amenities provided<br>(Lift/Swimming pool/compound wall etc)</td>
    <td colspan="2"><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data10['NA'] ?? '') ?></span></td>
    <td>Addl Cost incurred for amenities (in Rs)</td>
    <td colspan="2"><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data10['NA'] ?? '') ?></span></td>
  </tr>
  <tr>
    <td colspan="2">Total Land Value (in Rs)</td>	
    <td colspan="2"><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data6['finally_plot_valuation'] ?? '') ?></span></td>
    <td>Total Construction Value at present construction stage (in Rs)</td>
    <td colspan="2"><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data6['finally_construction_valuation'] ?? '') ?></span></td>
  </tr>
  <tr>
    <td colspan="2">Market Value of Land & Building for 100% complete property (in Rs)</td>
    <td colspan="2"><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data6['total_finally_area_valuation'] ?? '') ?></span></td>
    <td>Market Value of Land & Building at present stage of completion (in Rs)</td>
    <td colspan="2"><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data6['total_finally_area_valuation'] ?? '') ?></span></td>
  </tr>
</table>

<br>

<table style="margin-top:-17px;">
  <tr>
    <td colspan="7" class="section-header">Valuation of Flat / Shop / Office / Industrial / Other unit etc</td>
  </tr>
  <tr>
    <td  colspan="2">Flat / Apartment / Shop / Office on adopted Area (in Sqft) SBUA</td>
    <td  colspan="2"><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data10['NA'] ?? '') ?></span></td>
    <td>Rate Range in the locality (Rs per sqft)</td>
    <td  colspan="2"><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data10['NA'] ?? '') ?></span></td>
  </tr>
  <tr>
      <td  colspan="2">Amenities and other costs if any (in Rs)</td>
    <td  colspan="2"><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data10['NA'] ?? '') ?></span></td>
    <td>Rate considered (Rs per sqft)</td>
    <td  colspan="2"><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data10['NA'] ?? '') ?></span></td>
  </tr>
  <tr>
        <td  colspan="2">Total Market Value of Flat / Shop / Flat / Office on 100% complete (in Rs)</td>
    <td colspan="2"><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data10['NA'] ?? '') ?></span></td>
        <td>Total Market Value of Flat / Shop / Flat / Office on present completion stage (in Rs)</td>
    <td colspan="2"><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data10['NA'] ?? '') ?></span></td>
  </tr>
</table>

<br>

<table style="margin-top:-17px;">
  <tr>
    <td colspan="4" class="section-header">Stage of Construction</td>
  </tr>
  <tr>
    <td>% Completion</td>
    <td><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data8['stage_construction_actual_present_completion'] ?? '') ?></span></td>
    <td>% Recommendation</td>
    <td><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data8['stage_construction_recommend_present_completion'] ?? '') ?></span></td>
  </tr>
  <tr>
    <td>Government Guideline/Circle rate for Land (Rs per sqft)</td>
    <td><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data6['guideline_rate'] ?? '') ?></span></td>
    <td>Land Value as per Government Rate (Rs)</td>
    <td><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data6['guideline_values'] ?? '') ?></span></td>
  </tr>
  <tr>
    <td>Government Guideline/Circle rate for Flat/Unit/Built up (Rs per sqft)</td>
    <td><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data10['NA'] ?? '') ?></span></td>
    <td>Flat/Unit/Built up Value as per Government Rate (Rs)</td>
    <td><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data10['NA'] ?? '') ?></span></td>
  </tr>
</table>
<table>
  <tr>
    <td>Distress Value (in Rs)</td>
    <td><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data6['total_distress_value'] ?? '') ?></span></td>
    <td>Avg Rental per sqft (in Rs)</td>
    <td><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data10['NA'] ?? '') ?></span></td>
  </tr>
</table>
<br>
<table style="margin-top:-17px;">
  <tr>
    <td colspan="6" class="section-header">Property Specific Remarks & Observation</td>
  </tr>
  <tr>
    <td><br><br><br>Remarks / Observation</td>
 <td colspan="5"><span style="white-space: pre-line; font-size:14px; display: block; text-align: left; padding: 0; margin: 0;"readonly>
        <?= htmlspecialchars($data10['remarks'] ?? '') ?>
    </span></td>
  </tr>
</table>

<br>
<table style="margin-top:-17px;">
  <tr>
    <td colspan="6" class="section-header">References of Transactions Available</td>
  </tr>
  <tr>
    <td rowspan="2">References of Transactions Available</td>
    <td>Ref 1</td>
    <td>Ref 2</td>
    <td>Ref 3</td>
    <td>Ref 4</td>
    <td>Ref 5</td>

  </tr>
  <tr>
    <td><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data10['NA'] ?? '') ?></span></td>
    <td><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data10['NA'] ?? '') ?></span></td>
    <td><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data10['NA'] ?? '') ?></span></td>
    <td><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data10['NA'] ?? '') ?></span></td>
 <td><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data10['NA'] ?? '') ?></span></td>
  </tr>
</table>
<table>
 
  <tr>
    <td>Name of the Customer/ Applicant</td>
    <td><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data1['customerName'] ?? '') ?>
    </span></td>    <td>Date & Time of Property/Site Visit</td>
    <td><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data1['fe_to_coordinator_assign_at'] ?? '') ?></span></td>
  </tr>
  <tr>
    <td><br>Address of the Property being Appraised</td>
     <td colspan="3"><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data3['address_per_site'] ?? '') ?>
    </span></td>  </tr>
</table> 
 <table>
 
  <tr>

<div class="google-map-container">
<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "project_db";
$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$reference_id = $_SESSION['reference_id'] ?? null;
$reference_id = $_GET['reference_id'] ?? $reference_id;

if ($reference_id) {
    $sql = "SELECT image5 FROM final_uploaded_images WHERE reference_id = ?";
    $stmt = $conn->prepare($sql);
    if ($stmt === false) {
        die("Error preparing the SQL statement: " . $conn->error);
    }

    $stmt->bind_param("s", $reference_id);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows > 0) {
        $row = $result->fetch_assoc();
        if (!empty($row['image5'])) {
 
            echo '<div><img src="data:image/jpeg;base64,' . base64_encode($row['image5']) . '" alt="Google Map"><p>Google Map</p></div>';
        } else {
            echo "<p style='text-align:center;'>Google Map image not available.</p>";
        }
    } else {
        echo "<p style='text-align:center;'>No record found for Google Map image.</p>";
    }

    $stmt->close();
} else {
    echo "<p style='text-align:center;'>Reference ID is missing.</p>";
}
?>
</tr>
</div>
    </table>

 

<table>
    <tr>
    <td colspan="7" class="section-header">Valuer Certification/Disclaimer</td>
    </tr>
    <tr><td colspan="7"><span style="white-space: pre-line; font-size:14px; display: block; text-align: left; padding: 0; margin: 0;font-weight:400;" readonly>
    <?= nl2br(htmlspecialchars(formatDeclaration($data10['declaration'] ?? ''))) ?>
</span></td> </tr>
 <?php
function formatDeclaration($text) {
    // Insert a newline before every occurrence of a number followed by a dot and space (e.g., "1. ", "10. ")
    // Only if it's NOT already at the beginning of the string or a new line
    $text = preg_replace('/(?<!^)(?<!\n)(\d+\.\s)/', "\n$1", $text);
    return $text;
}
?></tr>
    <tr>
        <td colspan="2">Name of Engineer Visited the property</td>
        <td colspan="2"><input  type="text"value="<?= $engineer_name ?>" readonly></td>
        <td>Authorized Signatory Name & Signature</td>
        <td colspan="2">  <span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars('Mr. Sanjay Saini') ?></span></td>
    </tr>
</table>
 
   <!-- Buttons: Hidden during print -->
<div class="no-print">
  <form method="post">
    <input type="hidden" name="download_images" value="1">
    <button type="submit">Download All Images</button>
  </form>

  <button id="downloadPdf" onclick="setPrintMargins()">DOWNLOAD PDF</button>
</div>

  <script>
    document.getElementById('downloadPdf').addEventListener('click', () => {
      // Select the content you want to convert to PDF
      const element = document.getElementById('content');
      const options = {
        margin:[0,0],
        filename:'report.pdf',
        image: { type: 'jpeg', quality: 0.98 },
        html2canvas: { scale: 2 },
        jsPDF: { unit: 'in', format: 'letter', orientation: 'portrait' }
      };

      // Generate and download the PDF
      html2pdf().set(options).from(element).save();
    });
    function setPrintMargins() {
      const style = document.createElement('style');
      style.innerHTML = `
      @media print {
          body {
            margin:0.5;
          }
        }
      `;
      document.head.appendChild(style);
      window.print();
    }
    // Disable all input fields in the form
    document.querySelectorAll('input').forEach(function(input) {
        input.disabled = true;  // Disables the field completely
    });
     function resizeFakeInput(input) {
    const fake = document.getElementById('fakeWrap');
    fake.textContent = input.value || ' ';
    input.style.height = fake.scrollHeight + 'px';
  }

  // Initialize height
  resizeFakeInput(document.getElementById('longInput'));
   function autoResize(el) {
    el.style.height = 'auto'; // reset height
    el.style.height = el.scrollHeight + 'px'; // set to content height
  }
  // Auto-resize on load
  document.querySelectorAll('.clean-textarea').forEach(t => autoResize(t));
    </script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/jspdf/2.5.1/jspdf.umd.min.js"></script>

  <script>
    // Disable input fields before generating PDF
    function disableInputs() {
      document.querySelectorAll('input, textarea').forEach(input => input.disabled = true);
    }

    // Re-enable input fields after PDF generation (optional)
    function enableInputs() {
      document.querySelectorAll('input, textarea').forEach(input => input.disabled = false);
    }

    // Auto-resize textareas
    function autoResize(el) {
      el.style.height = 'auto';
      el.style.height = el.scrollHeight + 'px';
    }

    document.querySelectorAll('.clean-textarea').forEach(t => autoResize(t));

    // PDF generation logic using jsPDF with html()
    document.getElementById('downloadPdf').addEventListener('click', async () => {
      disableInputs();

      const { jsPDF } = window.jspdf;
      const doc = new jsPDF({
        orientation: 'portrait',
        unit: 'pt',
        format: 'a4'
      });

      await doc.html(document.getElementById('content'), {
        callback: function (doc) {
          doc.save('report.pdf');
          enableInputs();
        },
        margin: [40, 40, 40, 40],
        autoPaging: 'text',
        x: 10,
        y: 10,
        html2canvas: {
          scale: 1,
          useCORS: true
        }
      });
    });
  </script>
</div>
</body>
</html>