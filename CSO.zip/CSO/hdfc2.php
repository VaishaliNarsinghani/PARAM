<?php include('auth.php'); ?>
<?php
// Start session


$servername = "localhost";
$username = "root";
$password = "";
$dbname = "project_db";

// Create DB connection
$conn = new mysqli($servername, $username, $password, $dbname);
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

if (!isset($_SESSION['reference_id'])) {
    die("Reference ID not found in session.");
}
$reference_id = $_SESSION['reference_id'];

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['download_images'])) {

    // Get customer name
    $stmt_name = $conn->prepare("SELECT customerName FROM mis WHERE reference_id = ?");
    $stmt_name->bind_param("s", $reference_id);
    $stmt_name->execute();
    $result_name = $stmt_name->get_result();
    $customerName = "customer";
    if ($row = $result_name->fetch_assoc()) {
        $customerName = preg_replace('/[^a-zA-Z0-9]/', '', $row['customerName']);
    }
    $stmt_name->close();

    // Fetch image BLOBs
    $stmt = $conn->prepare("SELECT image1, image2, image3, image4, image5, image6, image7, image8, image9, image10, image11, image12,image13, image14, image15, image16, image17, image18, image19, image20 FROM final_uploaded_images WHERE reference_id = ?");    $stmt->bind_param("s", $reference_id);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows > 0 && ($row = $result->fetch_assoc())) {
        $tempDir = sys_get_temp_dir() . DIRECTORY_SEPARATOR . uniqid('images_', true);
        mkdir($tempDir);

        $imageFiles = [];
        for ($i = 1; $i <= 12; $i++) {
            if (!empty($row["image$i"])) {
                $filename = $tempDir . DIRECTORY_SEPARATOR . "image{$i}.jpg";
                file_put_contents($filename, $row["image$i"]);
                $imageFiles[] = $filename;
            }
        }

        if (empty($imageFiles)) {
            die("No images to download.");
        }

        // Create ZIP
        $zipFileName = "images_" . preg_replace('/[^a-zA-Z0-9]/', '_', $reference_id) . "_{$customerName}.zip";
        $zipPath = $tempDir . DIRECTORY_SEPARATOR . $zipFileName;

        $zip = new ZipArchive();
        if ($zip->open($zipPath, ZipArchive::CREATE) !== TRUE) {
            die("Failed to create ZIP file.");
        }

        foreach ($imageFiles as $file) {
            $zip->addFile($file, basename($file));
        }
        $zip->close();

        // Send ZIP to browser
        header('Content-Type: application/zip');
        header('Content-Disposition: attachment; filename="' . basename($zipFileName) . '"');
        header('Content-Length: ' . filesize($zipPath));
        flush();
        readfile($zipPath);

        // Cleanup
        foreach ($imageFiles as $file) {
            unlink($file);
        }
        unlink($zipPath);
        rmdir($tempDir);
        exit;
    } else {
        echo "<p style='color:red;'>No image data found for this reference ID.</p>";
    }
}
 

// Fetch data from bank_details table
$sql_property = "SELECT * FROM mis WHERE reference_id = ?";
$stmt_property = $conn->prepare($sql_property);
$stmt_property->bind_param("s", $reference_id);
$stmt_property->execute();
$result_property = $stmt_property->get_result();
$data1 = $result_property->fetch_assoc();




// Fetch data from property_details table
$sql_property = "SELECT * FROM property_details WHERE reference_id = ?";
$stmt_property = $conn->prepare($sql_property);
$stmt_property->bind_param("s", $reference_id);
$stmt_property->execute();
$result_property = $stmt_property->get_result();
$data2= $result_property->fetch_assoc();




// Fetch data from area_valuation table
$sql_area = "SELECT * FROM address_details WHERE reference_id = ?";
$stmt_area = $conn->prepare($sql_area); 
$stmt_area->bind_param("s", $reference_id);
$stmt_area->execute();
$result_area = $stmt_area->get_result();
$data3 = $result_area->fetch_assoc();





// Fetch data from area_valuation table
$sql_area = "SELECT * FROM critical_parameters WHERE reference_id = ?";
$stmt_area = $conn->prepare($sql_area); 
$stmt_area->bind_param("s", $reference_id);
$stmt_area->execute();
$result_area = $stmt_area->get_result();
$data4 = $result_area->fetch_assoc();

 
// Fetch data from area_valuation table
$sql_area = "SELECT * FROM surroundings_details WHERE reference_id = ?";
$stmt_area = $conn->prepare($sql_area); 
$stmt_area->bind_param("s", $reference_id);
$stmt_area->execute();
$result_area = $stmt_area->get_result();
$data5 = $result_area->fetch_assoc();
$stmt_area->close();
 
// Fetch data from area_valuation table
$sql_area = "SELECT * FROM area_valuation WHERE reference_id = ?";
$stmt_area = $conn->prepare($sql_area); 
$stmt_area->bind_param("s", $reference_id);
$stmt_area->execute();
$result_area = $stmt_area->get_result();
$data6 = $result_area->fetch_assoc();
$stmt_area->close();
 


// Fetch data from area_valuation table
$sql_area = "SELECT * FROM cost_details WHERE reference_id = ?";
$stmt_area = $conn->prepare($sql_area); 
$stmt_area->bind_param("s", $reference_id);
$stmt_area->execute();
$result_area = $stmt_area->get_result();
$data7 = $result_area->fetch_assoc();
$stmt_area->close();
 


// Fetch data from area_valuation table
$sql_area = "SELECT * FROM floor_details WHERE reference_id = ?";
$stmt_area = $conn->prepare($sql_area); 
$stmt_area->bind_param("s", $reference_id);
$stmt_area->execute();
$result_area = $stmt_area->get_result();
$data8= $result_area->fetch_assoc();
$stmt_area->close();
 


// Fetch data from area_valuation table
$sql_area = "SELECT * FROM technical_details WHERE reference_id = ?";
$stmt_area = $conn->prepare($sql_area); 
$stmt_area->bind_param("s", $reference_id);
$stmt_area->execute();
$result_area = $stmt_area->get_result();
$data9 = $result_area->fetch_assoc();
$stmt_area->close();
 
// Fetch data from area_valuation table
$sql_area = "SELECT * FROM remarks_table WHERE reference_id = ?";
$stmt_area = $conn->prepare($sql_area); 
$stmt_area->bind_param("s", $reference_id);
$stmt_area->execute();
$result_area = $stmt_area->get_result();
$data10 = $result_area->fetch_assoc();
$stmt_area->close();


// Step 1: Fetch the engineer_id from the mis table
$sql_mis = "SELECT engineer_id FROM mis WHERE reference_id = ?";
$stmt_mis = $conn->prepare($sql_mis);
$stmt_mis->bind_param("s", $reference_id);
$stmt_mis->execute();
$result_mis = $stmt_mis->get_result();
$row_mis = $result_mis->fetch_assoc();
$stmt_mis->close(); 

if ($row_mis) {
    $engineer_id = $row_mis['engineer_id'];

    // Step 2: Fetch the engineer's name from engineer_login table
    $sql_engineer = "SELECT name FROM engineer_login WHERE engineer_id = ?";
    $stmt_engineer = $conn->prepare($sql_engineer);
    $stmt_engineer->bind_param("s", $engineer_id);
    $stmt_engineer->execute();
    $result_engineer = $stmt_engineer->get_result();
    $row_engineer = $result_engineer->fetch_assoc();
    $stmt_engineer->close();

    if ($row_engineer) {
        $engineer_name = $row_engineer['name'];
         //echo "Engineer Name: " . $engineer_name;
    } else {
        echo "Engineer not found.";
    }
} else {
    echo "No engineer assigned for this reference_id.";
}



// Step 1: Fetch the engineer_id from the mis table
$sql_mis = "SELECT report_id FROM mis WHERE reference_id = ?";
$stmt_mis = $conn->prepare($sql_mis);
$stmt_mis->bind_param("s", $reference_id);
$stmt_mis->execute();
$result_mis = $stmt_mis->get_result();
$row_mis = $result_mis->fetch_assoc();
$stmt_mis->close(); 

if ($row_mis) {
    $report_id = $row_mis['report_id'];

    // Step 2: Fetch the engineer's name from engineer_login table
    $sql_engineer = "SELECT name FROM report_login WHERE report_id = ?";
    $stmt_engineer = $conn->prepare($sql_engineer);
    $stmt_engineer->bind_param("s", $report_id);
    $stmt_engineer->execute();
    $result_engineer = $stmt_engineer->get_result();
    $row_engineer = $result_engineer->fetch_assoc();
    $stmt_engineer->close();

    if ($row_engineer) {
        $report_name = $row_engineer['name'];
         //echo "Engineer Name: " . $report_name;
    } else {
        echo "Engineer not found.";
    }
} else {
    echo "No engineer assigned for this reference_id.";
}


// Step 1: Fetch the engineer_id from the mis table
$sql_mis = "SELECT report_drafter_to_technical FROM mis WHERE reference_id = ?";
$stmt_mis = $conn->prepare($sql_mis);
$stmt_mis->bind_param("s", $reference_id);
$stmt_mis->execute();
$result_mis = $stmt_mis->get_result();
$row_mis = $result_mis->fetch_assoc();
$stmt_mis->close(); 

if ($row_mis) {
    $report_drafter_to_technical = $row_mis['report_drafter_to_technical'];

    // Step 2: Fetch the engineer's name from engineer_login table
    $sql_engineer = "SELECT name FROM technical_login WHERE technical_manager_id = ?";
    $stmt_engineer = $conn->prepare($sql_engineer);
    $stmt_engineer->bind_param("s", $report_drafter_to_technical);
    $stmt_engineer->execute();
    $result_engineer = $stmt_engineer->get_result();
    $row_engineer = $result_engineer->fetch_assoc();
    $stmt_engineer->close();

    if ($row_engineer) {
        $technical_name = $row_engineer['name'];
        //echo "Engineer Name: " . $technical_name;
    } else {
        echo "Engineer not found.";
    }
} else {
    echo "No engineer assigned for this reference_id.";
}
?>
<!DOCTYPE html>
<html lang="en">
    
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="hdfc12.css">
    <link rel="shortcut icon" href="favicon.png" type="image/x-icon"> 
    <title>HDFC Bank Report</title>
    <style>
      
    </style>
</head>
<body>

<div class="report-container">
    <div class="header">
        <img src="Magpie_logo.jpg" alt="Saini and Associates Logo">
        <div class="header-text">
            <h1>SAINI AND ASSOCIATES</h1>
            <p>Valuer Designer Architects</p>
            <p>Regd. Address : Office no. 201, 2nd floor, Gravity Mall, Mechanic nagar, warehouse road, near vijay nagar, Indore, Madhya Pradesh- 452011 452001</p>
            <p>Helpline Number: Sanjay Saini: 09752598376, Nitin Saini: 09669968797</p>
        </div>
    </div>

    <div class="report-title">
        <h2>HDFC BANK REPORT</h2>
    </div>

    <!-- General Details -->
    <div class="section-title">GENERAL DETAILS</div>
    <table>
        <tr>
            <th>Date of Valuation Report</th>
            <td><input type="text" name="date_of_valuation" placeholder="Enter date" value="<?= $data1['initiationDate'] ?? '' ?>"></td>
            <th>Name of Customer</th>
            <td><input type="text" name="customer_name" placeholder="Enter customer name" value="<?= $data1['customerName'] ?? '' ?>"></td>
        </tr>
        <tr>
            <th>Loan Application Number</th>
            <td><input type="text" name="loan_application_number" placeholder="Enter loan application number" value="<?= $data1['applicationNo'] ?? '' ?>"></td>
            <th>Serial No.</th>
            <td><input type="text" name="serial_number" placeholder="Enter serial number" value="1"></td>
        </tr>
        <tr>
            <th>Name of the Owner</th>
            <td><input type="text" name="owner_name" placeholder="Enter owner's name" value="<?= $data1['applicationNo'] ?? '' ?>"></td>
            <th>Legal Address of Property</th>
<td>
    <textarea name="legal_address" ><?= htmlspecialchars('****') ?></textarea>
</td>
</tr>
        <tr>
            <th>Property Address with Pin Code</th>
            <td  colspan="3"><textarea input type="text"  name="property_address" value="***">****</textarea></td>
        </tr>
        <tr>
            <th>Landmark</th>
            <td colspan="3"> <textarea name="landmark" ><?= htmlspecialchars('****') ?></textarea></td>

        </tr>
        <tr>
            <th>Date of Inspection</th>
            <td><input type="text" name="date_of_inspection" placeholder="Enter inspection date" value="<?= $data1['assigned_at'] ?? '' ?>"></td>
        </tr>
    </table>

    <!-- Subject Property Details -->
    <div class="section-title">SUBJECT PROPERTY DETAILS</div>
    <table>
        <tr>
            <th>Type of Premises</th>
           
            <td><textarea input type="text"  name="premises_type" value="***">****</textarea></td>
            <th>Occupied By</th>
            <td><textarea input type="text"  name="occupied_by" value="***">****</textarea></td>
        </tr>
        <tr>
            <th>Is Property Rented?</th>
            <td>
                <select name="is_property_rented">
                    <option value="yes">Yes</option>
                    <option value="no">No</option>
                </select>
            </td>
            <th>If Rented, List of Occupants</th>
            <td><textarea input type="text"  name="occupants_list" value="***">****</textarea></td>
        </tr>
        <tr>
            <th>Market Rental per Sqft (Rs)</th>
            <td><textarea input type="text"  name="market_rental" value="***">****</textarea></td>
        </tr>
    </table>

    <!-- Structural Details -->
    <div class="section-title">STRUCTURAL DETAILS</div>
    <table>
        <tr>
            <th>Type of Structure</th>
           
            <td><textarea input type="text"  name="structure_type" value="***">****</textarea></td>
            <th>No. of Floors</th>
            <td><input type="text" name="number_of_floors" value="<?= $data8['total_actual_upper_floors'] ?? '' ?>"></td>
        </tr>
        <tr>
            <th>Age of Property</th>
            <td><input type="text" name="property_age" value="***"></td>
            <th>Estimated Future Life</th>
            <td><input type="text" name="future_life" value="***"></td>
        </tr>
        <tr>
            <th>Interiors</th>
            
            <td><textarea input type="text"  name="interiors" value="***">****</textarea></td>
        </tr>
    </table>

    <!-- Property Details -->
    <div class="section-title">PROPERTY DETAILS</div>
    <table class="property-details-table">
        <tr>
            <th>Type of Usage of Entire Property</th>
            <td><textarea input type="text"  name="usage_type" value="***">****</textarea></td>
        </tr>
        <tr>
            <th>Additional Amenities</th>
            <td><textarea  input type="text"  name="amenities" value="***" >*****</textarea></td>
        </tr>
        <tr>
            <th>Legal Status of Property</th>
            <td><textarea  input type="text"  name="legal_status" value="***" >*****</textarea></td>
        </tr>
    </table>

    <!-- Remarks Section -->
    <div class="remarks">
        <div class="section-title">REMARKS</div>
        <ol>
            <li>The property is an Industrial Unit situated at Land bearing Survey No. 108/1 (After bantanian survey no. 108/1/2), Patwari Halka No. 16, , Saral No. 83, Village Khatamba, Tehsil & Dist. Dewas 455001(M.P.)</li>
            <li>Provided copy of Sale Deed has been obtained in favour of M/s Coram Chromwell India Pvt. Ltd. Through Mr. Uday Kapoor S/o Indraraj Kapoor.</li>
            <li>The property has been identified on the basis of local inquiry and as indicated by customer after verify & tag property.</li>
            <li>The Plot rate has been considered as per local inquiry of recent transactions of similar properties in the area from market sources & applying necessary adjustment for property's location & potential.</li>
            <li>Site construction rate has been considered as per the built up specifications, raw material used, and workmanship, maintenance level observed during visit & making necessary adjustment for age. Amenities charges of Rs. 15.00 lacs has been considered in this valuation (RCC Road, paving block & compound wall).</li>
            <li>The property visit in presence of Mr. Sharmaji, who is customer's representative (Manager).</li>
            <li>As per Provided T&CP Layout Memo no 2018 Date 16/9/2013 & Revised T&CP Layout Memo no. 2278 Dated 26.09.2022 , as per T&CP total land area 0.800 hect / after deducting road widening area 0.780 hect , which is considered for valuation.</li>
            <li>As per site area found 5332 sqft and shed area 15500 sqft, site Built up area considered as per actual.</li>
            <li>For site boundary not mention document (deed) so we verify the property as per Khgy book.</li>
            <li>The copy of Sanction plan has not been provided. Bank is suggested to check necessity of the same as per their internal policy and take necessary deviation approval from competent authority before funding as per applicable approval matrix. In absence of necessary deviation approval as mentioned above the report shall stand null and void.</li>
        </ol>
    </div>

    <!-- Declaration Section -->
    <div class="section-title">DECLARATION</div>
    <p>
        I hereby declare that:
        <ol>
            <li>I have deputed my representative Mr. Vishal & Myself Mr. Sanjay Saini, to inspect the property. My representative has personally inspected the property on 18.11.2022.</li>
            <li>I have no direct or indirect interest in the property valued.</li>
            <li>The information furnished in the report is true and correct to the best of my knowledge and belief.</li>
        </ol>
    </p>

    <table>
        <tr>
            <th>Signature of Valuer</th>
            <th>Name of Valuer</th>
            <th>Date</th>
        </tr>
        <tr>
            <td></td>
            <td>Saini And Associates</td>
            <td>02.12.2022</td>
        </tr>
    </table>

    <!-- Photographs Section -->
    <div class="section-title">PHOTOGRAPHS</div>
  
  <?php
// Database connection
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "project_db"; // Replace with your database name
$message = "";
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Step 2: Retrieve reference_id from session (if set)
$reference_id = $_SESSION['reference_id'] ?? null;

// Fetch reference_id from GET or session
$id = isset($_GET['reference_id']) ? $_GET['reference_id'] : $reference_id;

// Ensure reference_id is available
if ($id) {
    // Fetch the images from the database using a prepared statement
    $sql = "SELECT 
                image1, image2, image3, image4, image5, 
                image6, image7, image8, image9, image10, 
                image11, image12 
            FROM final_uploaded_images 
            WHERE reference_id = ?";
    
    $stmt = $conn->prepare($sql);
    if ($stmt === false) {
        die("Error preparing the SQL statement: " . $conn->error);
    }

    // Bind the parameter
    $stmt->bind_param("s", $id); // "s" indicates the parameter is a string

    // Execute the statement
    $stmt->execute();


      echo "<style> 
  .image-gallery {
  display: grid;
  grid-template-columns: repeat(3, 1fr); /* 3 images per row */
  gap:10px;
  justify-content:space-between;
  margin-top:20px;
  align-items:center;
}
.image-gallery img {
  width: 100%;
  height:300px;
  border: 1px solid #ccc;
  object-fit: cover;
  border-radius:5px;
  box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
}
.image-gallery p {
  text-align: center;
  margin-top: 5px;
  font-size: 14px;
  color: #333;
}
</style>";
    // Get the result
    $result = $stmt->get_result();
   
    if ($result->num_rows > 0) {
        while ($row = $result->fetch_assoc()) {
            if (!empty($row['image1'])) {
                echo '<div>';
                echo '<img src="data:image/jpeg;base64,' . base64_encode($row['image1']) . '" alt="Image 1">';
                echo '<p>EXTERNAL PHOTOS</p>';
                echo '</div>';
            }
            if (!empty($row['image2'])) {
                echo '<div>';
                echo '<img src="data:image/jpeg;base64,' . base64_encode($row['image2']) . '" alt="Image 2">';
                echo '<p>Kitchen</p>';
                echo '</div>';
            }
            if (!empty($row['image3'])) {
                echo '<div>';
                echo '<img src="data:image/jpeg;base64,' . base64_encode($row['image3']) . '" alt="Image 3">';
                echo '<p>Selfie</p>';
                echo '</div>';
            }
            if (!empty($row['image4'])) {
                echo '<div>';
                echo '<img src="data:image/jpeg;base64,' . base64_encode($row['image4']) . '" alt="Image 4">';
                echo '<p>Electric Meter</p>';
                echo '</div>';
            }
            if (!empty($row['image5'])) {
                echo '<div>';
                echo '<img src="data:image/jpeg;base64,' . base64_encode($row['image5']) . '" alt="Image 5">';
                echo '<p>Google Map</p>';
                echo '</div>';
            }
            if (!empty($row['image6'])) {
                echo '<div>';
                echo '<img src="data:image/jpeg;base64,' . base64_encode($row['image6']) . '" alt="Image 6">';
                echo '<p>Other 1</p>';
                echo '</div>';
            }
            if (!empty($row['image7'])) {
                echo '<div>';
                echo '<img src="data:image/jpeg;base64,' . base64_encode($row['image7']) . '" alt="Image 7">';
                echo '<p>Other 2</p>';
                echo '</div>';
            }
            if (!empty($row['image8'])) {
                echo '<div>';
                echo '<img src="data:image/jpeg;base64,' . base64_encode($row['image8']) . '" alt="Image 8">';
                echo '<p>Other 3</p>';
                echo '</div>';
            }
            if (!empty($row['image9'])) {
                echo '<div>';
                echo '<img src="data:image/jpeg;base64,' . base64_encode($row['image9']) . '" alt="Image 9">';
                echo '<p>Other 4</p>';
                echo '</div>';
            }
            if (!empty($row['image10'])) {
                echo '<div>';
                echo '<img src="data:image/jpeg;base64,' . base64_encode($row['image10']) . '" alt="Image 10">';
                echo '<p>Other 5</p>';
                echo '</div>';
            }
            if (!empty($row['image11'])) {
                echo '<div>';
                echo '<img src="data:image/jpeg;base64,' . base64_encode($row['image11']) . '" alt="Image 11">';
                echo '<p>Other 6</p>';
                echo '</div>';
            }
            if (!empty($row['image12'])) {
                echo '<div>';
                echo '<img src="data:image/jpeg;base64,' . base64_encode($row['image12']) . '" alt="Image 12">';
                echo '<p>Other 7</p>';
                echo '</div>';
            }
        }
    } else {
        echo "<p style='text-align:center;'>No images found.</p>";
    }

 



}
?>
</div>
</div>

</body>
</html>
