<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Valuation Report</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 20px;
        }

        .header {
            text-align: center;
            font-size: 20px;
            font-weight: bold;
            margin-bottom: 20px;
        }

        .sub-header {
            text-align: center;
            margin-bottom: 30px;
        }

        table {
            width: 100%;
            border-collapse: collapse;
            margin-bottom: 20px;
        }

        table, th, td {
            border: 1px solid black;
        }

        th, td {
            padding: 8px;
            text-align: left;
        }

        th {
            background-color: #f2f2f2;
        }

        .section-title {
            font-weight: bold;
            text-decoration: underline;
            margin: 20px 0;
        }
        button{
            padding:20px;
            margin-left:45%;
        }
    </style>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/html2pdf.js/0.9.2/html2pdf.bundle.min.js"></script>
</head>
<body>
    <div id="content">
    <div class="header">
        MAGPIE ENGINEERING PVT. LTD.<br>
        Valuer Designer Architects
    </div>

    <div class="sub-header">
        Address : Office no. 201, 2nd floor, Gravity Mall, Mechanic nagar, warehouse road, near vijay nagar, Indore, Madhya Pradesh- 452011<br>
        <strong>VALUATION REPORT FOR CRISS FINANCE</strong>
    </div>

    <table>
        <tr>
            <th>Date of Technical Visit</th>
            <td>27.08.2024</td>
            <th>Type of Product</th>
            <td>SORP</td>
        </tr>
        <tr>
            <th>Application No.</th>
            <td>ISP00089345</td>
            <th>Serial No.</th>
            <td>134/0824/CRISS FINANCIAL SERVICES</td>
        </tr>
        <tr>
            <th>Name of Customer</th>
            <td>Mr. Ajab Singh Malviya</td>
            <th>Co-Applicant</th>
            <td>Mrs. Sunita</td>
        </tr>
        <tr>
            <th>Ownership as per document</th>
            <td>Mr. Ajab Singh S/o Mr. Dhuliram</td>
            <th>Contact No. of customer</th>
            <td>9795341344 & 8105399386</td>
        </tr>
        <tr>
            <th>Lease Hold or Free Hold</th>
            <td>Free Hold</td>
            <th>Occupation Status</th>
            <td>Self Occupied</td>
        </tr>
        <tr>
            <th>Property title</th>
            <td>Gram Panchayat Property</td>
            <th>Documents Provided for Valuation</th>
            <td>Copy of Gram Panchayat Patta</td>
        </tr>
        <tr>
            <th>Population of Village (G.P)</th>
            <td>500-600</td>
            <th>Dependency (%)</th>
            <td>45%</td>
        </tr>
        <tr>
            <th colspan="2">Address of Property as per Document</th>
            <td colspan="2">House at Village Nevari, Tehsil Hatpipliya, Dist. Dewas (M.P) 455223</td>
        </tr>
        <tr>
            <th colspan="2">Address of Property as per Actual</th>
            <td colspan="2">House at Indira Colony, Village Nevari, Tehsil Hatpipliya, Dist. Dewas (M.P) 455223</td>
        </tr>
    </table>

    <table>
        <tr>
            <th>Area of land (Sq.m)</th>
            <td>58.55</td>
            <th>Electricity Meter</th>
            <td>NA</td>
        </tr>
        <tr>
            <th>Area of land (Sq.yd)</th>
            <td>70.00</td>
            <th>Area of land (Sq.ft)</th>
            <td>630.00</td>
        </tr>
        <tr>
            <th>Plinth area of house (Sq.ft)</th>
            <td>630.00</td>
            <th>Built-up area of house (Sq.ft)</th>
            <td>360.00</td>
        </tr>
    </table>

    <table>
        <tr>
            <th>Floor</th>
            <th>Actual Area (Sq.ft)</th>
            <th>Permissible Area (Sq.ft)</th>
        </tr>
        <tr>
            <td>Ground Floor Rec</td>
            <td>360</td>
            <td>360</td>
        </tr>
        <tr>
            <td>First Floor</td>
            <td>0</td>
            <td>0</td>
        </tr>
        <tr>
            <td>Second Floor</td>
            <td>0</td>
            <td>0</td>
        </tr>
        <tr>
            <td>Total Built-up area</td>
            <td>360</td>
            <td>360</td>
        </tr>
    </table>

    <div class="section-title">Boundaries Detail</div>
    <table>
        <tr>
            <th>Description</th>
            <th>North</th>
            <th>South</th>
            <th>East</th>
            <th>West</th>
        </tr>
        <tr>
            <td>As Per Document</td>
            <td>Road</td>
            <td>Road</td>
            <td>House of Mrs. Prem Bai</td>
            <td>House of Mr. Vikram</td>
        </tr>
        <tr>
            <td>As Per Actual</td>
            <td>Road</td>
            <td>Road</td>
            <td>House of Mrs. Prem Bai</td>
            <td>House of Mr. Vikram</td>
        </tr>
        <tr>
            <td>Approach road</td>
            <td colspan="4">10 Ft wide cc road</td>
        </tr>
    </table>

    <div class="section-title">Section 4: Local Authority Compliance & Safety Aspects</div>
    <table>
        <tr>
            <th>Setbacks (As per Government by Laws)</th>
            <th>Actual Setbacks</th>
        </tr>
        <tr>
            <td>Front</td>
            <td>Front</td>
        </tr>
        <tr>
            <td>Back</td>
            <td>Back</td>
        </tr>
        <tr>
            <td>Side</td>
            <td>Side</td>
        </tr>
        <tr>
            <td>Type of Structure</td>
            <td>RCC</td>
        </tr>
        <tr>
            <td>No. of Floors (Actual)</td>
            <td>GF</td>
        </tr>
        <tr>
            <td>Internal composition of the property</td>
            <td>GF - 1 Hall, 1 Room, 1 LD Rec & 1 Kitchen Tin shed</td>
        </tr>
        <tr>
            <td>Availability of basic amenities viz. electricity, water</td>
            <td>Yes</td>
        </tr>
        <tr>
            <td>Violation observed</td>
            <td>Low</td>
        </tr>
        <tr>
            <td>Structure conforming to safety</td>
            <td>Yes</td>
        </tr>
        <tr>
            <td>Meeting NDMA Guidelines</td>
            <td>Yes</td>
        </tr>
    </table>

    <div class="section-title">Section 5: Value</div>
    <table>
        <tr>
            <th>Particulars</th>
            <th>Area</th>
            <th>Rate</th>
            <th>Value</th>
        </tr>
        <tr>
            <td>Cost of land</td>
            <td>630.00</td>
            <td>176</td>
            <td>110880.00</td>
        </tr>
        <tr>
            <td>Ground Floor Rec</td>
            <td>360.00</td>
            <td>557</td>
            <td>200520.00</td>
        </tr>
        <tr>
            <td>Total Cost of Existing Property</td>
            <td></td>
            <td></td>
            <td>311400</td>
        </tr>
    </table>

    <table>
        <tr>
            <th>Particulars</th>
            <th>Area</th>
            <th>Rate</th>
            <th>Value</th>
        </tr>
        <tr>
            <td>Market Value</td>
            <td>630.00</td>
            <td>550</td>
            <td>346500.00</td>
        </tr>
        <tr>
            <td>Total Cost</td>
            <td></td>
            <td></td>
            <td>652920</td>
        </tr>
    </table>

    <div class="section-title">Stage of Construction</div>
    <p>Remarks</p>
    <ol>
        <li>The residential property is a House situated at Indira Colony, Village Nevari, Tehsil Hatpipliya, Dist. Dewas (M.P) 455223</li>
        <li>The provided copy of gram panchayat patta has been obtained in favor of Mr. Ajab Singh S/o Mr. Dhuliram.</li>
        <li>...</li>
    </ol>
    </div>
  <!-- <button onclick="window.print()">Download PDF</button> -->
  <button onclick="setPrintMargins()">Print with Margins</button>
  <script>
    document.getElementById('downloadPdf').addEventListener('click', () => {
      // Select the content you want to convert to PDF
      const element = document.getElementById('content');
      const options = {
        margin:[0,0],
        filename:'report.pdf',
        image: { type: 'jpeg', quality: 0.98 },
        html2canvas: { scale: 2 },
        jsPDF: { unit: 'in', format: 'letter', orientation: 'portrait' }
      };

      // Generate and download the PDF
      html2pdf().set(options).from(element).save();
    });
    function setPrintMargins() {
      const style = document.createElement('style');
      style.innerHTML = `
      @media print {
          body {
            margin:0.5;
          }
        }
      `;
      document.head.appendChild(style);
      window.print();
    }
    // Disable all input fields in the form
    document.querySelectorAll('input').forEach(function(input) {
        input.disabled = true;  // Disables the field completely
    });
    </script>
</body>
</html>
