<?php
include('auth.php');

ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

// Database credentials
$host = 'localhost';
$db = 'project_db';
$user = 'root';
$pass = '';

try {
    $conn = new PDO("mysql:host=$host;dbname=$db", $user, $pass);
    $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (PDOException $e) {
    die("Database connection failed: " . $e->getMessage());
}

// Check if cso_id is set in session
if (!isset($_SESSION['cso_id'])) {
    header("Location: login.php");
    exit();
}

$cso_id = $_SESSION['cso_id'];

// Generate CSRF token if not set
if (empty($_SESSION['csrf_token'])) {
    $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
}
// Fetch session variables
$reference_id = $_SESSION['reference_id'] ?? null;
$bankName = $_SESSION['bankName'] ?? null;


// =======================
// Handle Dispatch Confirm
// =======================
if (isset($_POST['dispatch_confirm'])) {
    // 1. CSRF Token Validation
    if (!isset($_POST['csrf_token']) || $_POST['csrf_token'] !== $_SESSION['csrf_token']) {
        $_SESSION['flash_message'] = "Invalid request (CSRF token mismatch)";
        header("Location: pending.php");
        exit();
    }

    // 2. Required fields check
    $referenceId = trim($_POST['reference_id'] ?? '');
    $email = trim($_POST['email'] ?? '');
    $otpInput = trim($_POST['otp'] ?? '');

    if ($referenceId === '' || $email === '' || $otpInput === '') {
        $_SESSION['flash_message'] = "All fields are required.";
        header("Location: pending.php");
        exit();
    }

    // 3. Verify OTP for today's date
    $otpSql = "SELECT otp FROM otp_login WHERE `date` = CURDATE() LIMIT 1";
    $otpStmt = $conn->prepare($otpSql);
    $otpStmt->execute();
    $otpRow = $otpStmt->fetch(PDO::FETCH_ASSOC);

    if (!$otpRow || $otpRow['otp'] !== $otpInput) {
        $_SESSION['flash_message'] = "OTP not verified.";
        header("Location: pending.php");
        exit();
    }

    // 4. Update mis table
    $updateSql = "UPDATE mis 
                  SET flag_cso_submit = 1, final_submit_assigned = NOW() 
                  WHERE reference_id = :reference_id";
    $updateStmt = $conn->prepare($updateSql);
    $updateStmt->bindParam(':reference_id', $referenceId, PDO::PARAM_STR);
    $updateStmt->execute();

    $_SESSION['flash_message'] = "Dispatch confirmed successfully.";
    header("Location: pending.php");
    exit();
}

// =======================
// Fetch pending records
// =======================
$sql = "SELECT * FROM mis 
        WHERE technical_to_cso = :cso_id 
        AND (flag_technical_to_cso = TRUE AND flag_cso_submit = FALSE)";
$stmt = $conn->prepare($sql);
$stmt->bindParam(':cso_id', $cso_id, PDO::PARAM_STR);
$stmt->execute();
$results = $stmt->fetchAll(PDO::FETCH_ASSOC);

 $stmt = $conn->prepare("SELECT bankName FROM mis WHERE reference_id = ?");
$stmt->execute([$reference_id]);
$row = $stmt->fetch(PDO::FETCH_ASSOC);
$bankName = $row ? $row['bankName'] : '';


?>


<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <meta name="View Reportport" content="width=device-width, initial-scale=1.0">
  <title>Magpie Engineering</title>
  <link rel="shortcut icon" href="favicon.png" type="image/x-icon"> 
  <link rel="stylesheet" href="pending11.css">
   
      <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
  <script src="https://cdnjs.cloudflare.com/ajax/libs/html2pdf.js/0.9.2/html2pdf.bundle.min.js"></script>
</head>

<body>

<script>
<?php if (!empty($_SESSION['flash_message'])): ?>
    alert("<?= addslashes($_SESSION['flash_message']); ?>");
    <?php unset($_SESSION['flash_message']); ?>
<?php endif; ?>
</script>



  <button class="toggle-btn" id="toggle-btn">☰</button>
  <div class="container">
    <!-- Sidebar -->

    <div class="sidebar" id="sidebar">
      <div style="display: flex;">
        <img class="logo" src="logo.png" alt="">
        <h1>Magpie Engineering</h1>
      </div>
      <div class="rotating-text">Customer Service Officer</div>
        <a href="search.php"><i class="fas fa-search icon"></i>Search</a>
        <a href="homecso.php"><i class="fas fa-home icon"></i>Home</a>
        <a href="pending.php"class="active"><i class="fas fa-clock icon"></i> Pending For Dispatch</a>
        <a href="login.php"><i class="fas fa-sign-out-alt icon"></i>Logout</a>
    </div>     

    <?php
    if (!empty($results)): ?>
       <table>       <?php         
         echo "<style>
        /* Main Content */
 .content {
  margin: 0; /* Remove conflicting margins */
  padding: 20px;
  animation: fadeIn 1.5s ease-in-out;
  transition: transform 0.3s ease-in-out;
}

table {
  width:76%;
  margin: P-0 5% 0 19.5%; /* Use the same margin in both pages */
  border-collapse: collapse;
  background:rgb(207, 222, 240);
  color: #2C3E50;
  border-radius: 10px;
  overflow: hidden;
  table-layout: fixed; /* Enforce fixed column widths */
  margin-left :23%;
}

th, td {
  padding:10px;
  text-align: left;
  border: 1px solid rgba(255, 255, 255, 0.2);
  font-size: 15px;
  word-wrap: break-word; /* Allow wrapping of text */
  white-space: normal; /* Ensure wrapping is allowed */
  min-width:100px; /* Set a minimum width for columns */
}

th {
  font-size: 13px;
  background-color:rgb(102, 146, 190);
   color:white;
  font-weight: bold;
}

th, td {
     /* Adjust as needed for your preferred column width */
    word-wrap: break-word; /* Allows text to wrap onto the next line */
    white-space: normal; /* Ensures wrapping is allowed */
}


 tr:nth-child(even) {
   background-color:rgb(234, 236, 250);
 }

 tr:hover {
   background-color:rgb(138, 177, 215);
   color:white;
   font-weight:bolder;
   font-style:italic;
 }
h2{
  margin-left:32% ; 
   font-style: oblique;
 color: #2C3E50;
 }
 button{
    padding:10px 10px;
    background-color: #005f8a;
    color: white;
    text-decoration: none;
    border: none;
    border-radius: 5px;
    cursor: pointer;
    font-size: 20px;
    margin-top:10px;
}

@media (max-width: 768px) {
  

.content {
  margin-left: 0;
}

.search-filters input,
.search-filters button {
  width: 90%;
}
}
.content {
margin-left: 270px; /* Adjust based on sidebar width */
}


@media (min-width: 1200px) {

@media (max-width: 768px) {
.toggle-btn {
 display: block;
}

.sidebar {
 transform: translateX(-100%);
}

.sidebar.visible {
 transform: translateX(0);
}

.content {
 margin-left: 0;
 margin:0;

}

.search-filters input,
.search-filters button {
 width: 90%;
}
}

@keyframes slideIn {
from {
 transform: translateX(-100%);
 opacity: 0;
}

to {
 transform: translateX(0);
 opacity: 1;
}
}

@keyframes fadeIn {
from {
 opacity: 0;
}

to {
 opacity: 1;
}
}

.logo {
  width: 50px;
  height:50px;
  padding: 15px;
}
@media (max-width: 768px) {
  .toggle-btn {
    display: block;
  }

  .sidebar {
    transform: translateX(-100%);
  }

  .sidebar.visible {
    transform: translateX(0);
  }

  .content {
    margin-left: 0;

  }

  .search-filters input,
  .search-filters button {
    width: 90%;
  }
}
  /* Assign Button Styling */
.upload-button {
  background-color:rgb(102, 146, 190);
  color: white; /* White text color */
  border: 1px solid black; /* Black border */
  border-radius: 5px; /* Rounded corners */
  padding: 5px 10px; /* Padding for the button */
  font-size: 14px; /* Font size */
  font-weight: bold; /* Bold text */
  text-align: center; /* Center the text */
  cursor: pointer; /* Pointer cursor on hover */
  display: inline-block; /* Inline-block for proper alignment */
}

.upload-button a {
  text-decoration: none; /* Remove underline */
  color: white; /* Ensure the link text color is white */
  display: inline-block; /* Ensure proper alignment inside the button */
  width: 100%; /* Make it span the button */
  height: 100%; /* Make it span the button */
}

/* Hover effect for the button */
.upload-button:hover {
  background-color: #B0C4DE; /* Gray background on hover */
  color: white; /* Maintain white text on hover */
}

.upload-button a:hover {
  color: white; /* Ensure link remains white on hover */
}

   </style>";?>
      <table id="sortableTable">
        <p style="color: white; text-align:center;">Customer Information Table</p>
        <thead>
        <tr>
          <th>Reference Number</th>
          <th>Customer Name</th>
          <th>Address</th>
          <th>Customer Mobile Number</th>
          <th>Visit Type</th>
          <th>Bank Name</th>
          <th>Case Type</th>
          <th>Application Number</th>
          <th>Mail ID</th>
          <th>View</th>
          <th>Compress PDF</th>
           <th style="width:100px;">Dispatch</th>
        </tr>
</thead>
        <?php foreach ($results as $task): ?>
        <tr>
            <td data-label="Reference Number"><?= htmlspecialchars($task['reference_id']) ?></td>
            <td data-label="Customer Name"><?= htmlspecialchars($task['customerName']) ?></td>
            <td data-label="Address"><?= htmlspecialchars($task['address']) ?></td>
            <td data-label="Customer Mobile Number"><?= htmlspecialchars($task['customerMob']) ?></td>
            <td data-label="Visit Type"><?= htmlspecialchars($task['visitType']) ?></td>
            <td data-label="Bank Name"><?= htmlspecialchars($task['bankName']) ?></td>
          
            <td data-label="Case Type"><?= htmlspecialchars($task['caseType']) ?></td>
            <td data-label="Application Number"><?= htmlspecialchars($task['applicationNo']) ?></td>
            <td data-label="Mail ID"><?= htmlspecialchars($task['initiatorMailId']) ?></td>
      
            
            <td data-label="Assign">
            <a href="redirect.php?reference_id=<?= urlencode($task['reference_id']) ?>&bankName=<?= urlencode($task['bankName']) ?>" class="upload-button" style="text-decoration: none;padding:10px;">
    VIEW
</a></td>
 <td data-label="Assign">
            <a href="compress.php?reference_id=<?= urlencode($task['reference_id']) ?>&bankName=<?= urlencode($task['bankName']) ?>" class="upload-button" style="text-decoration: none;padding:1px;">
     Compress PDF
</a></td>

 


<!-- Dispatch Button (Inside Your Table Row) -->
<td>
    <button type="button"
            class="upload-button"
            style="text-decoration:none; padding:10px;  margin-top:0.5px;"
            onclick="openDispatchModal('<?= htmlspecialchars($task['reference_id']) ?>')">
        DISPATCH
    </button>
</td>

<!-- Grey Overlay -->
<div id="modal-overlay" style="
    display:none;
    position:fixed;
    top:0; left:0;
    width:100%; height:100%;
    background:rgba(128,128,128,0.5);
    z-index:9998;">
</div>

<!-- Modal Popup -->
<div id="dispatch-modal" style="
    display:none;
    position:fixed;
    top:50%; left:50%;
    transform:translate(-50%, -50%);
    background:#fff;
    padding:20px;
    width:400px;
    max-width:90%;
    box-shadow:0 5px 15px rgba(0,0,0,0.3);
    border-radius:8px;
    z-index:9999;">
    
    <h2 style="margin-top:0; color:#e23906;">!! ATTENTION !!</h2>
    <p>The selected assignment will be dispatched and the assignment will not be displayed anymore. 
      <br> Confirm by giving e-mail id and otp.</p>
    
    <!-- Modal Form -->
    <form id="dispatch-form" method="POST" action="pending.php">
        <!-- Hidden fields -->
        <input type="hidden" name="reference_id" id="modal-reference-id">
        <input type="hidden" name="csrf_token" value="<?= htmlspecialchars($_SESSION['csrf_token']) ?>">
        <input type="hidden" name="dispatch_confirm" value="1">

        <!-- Email Input -->
        <label for="email">Enter E-mail ID:</label>
        <input type="email" id="email" name="email" required
               style="width:100%; padding:8px; margin:5px 0 15px 0; box-sizing:border-box;">

        <!-- OTP Input -->
        <label for="otp">Enter OTP:</label>
        <input type="text" id="otp" name="otp" required
               style="width:100%; padding:8px; margin:5px 0 15px 0; box-sizing:border-box;">

        <!-- Buttons -->
        <div style="text-align:right; margin-top:15px;">
            <button type="button" onclick="closeDispatchModal()" 
                    style="background:#ccc; padding:8px 15px; border:none; border-radius:4px; margin-right:5px;">
                Cancel
            </button>
            <button type="submit" id="confirm-dispatch-btn" disabled
                    style="background:#27ae60; color:white; padding:8px 15px; border:none; border-radius:4px;">
                Confirm Dispatch
            </button>
        </div>
    </form>
</div>

<!-- JavaScript for Modal & Validation -->
<script>
    function openDispatchModal(referenceId) {
        document.getElementById('modal-reference-id').value = referenceId;
        document.getElementById('modal-overlay').style.display = 'block';
        document.getElementById('dispatch-modal').style.display = 'block';
        document.body.style.overflow = 'hidden'; // prevent scrolling
    }

    function closeDispatchModal() {
        document.getElementById('modal-overlay').style.display = 'none';
        document.getElementById('dispatch-modal').style.display = 'none';
        document.body.style.overflow = ''; // restore scrolling
    }

    // Enable confirm button when both fields are filled
    const emailInput = document.getElementById('email');
    const otpInput = document.getElementById('otp');
    const confirmBtn = document.getElementById('confirm-dispatch-btn');

    function validateFormFields() {
        if (emailInput.value.trim() !== "" && otpInput.value.trim() !== "" && emailInput.checkValidity()) {
            confirmBtn.disabled = false;
        } else {
            confirmBtn.disabled = true;
        }
    }

    emailInput.addEventListener('input', validateFormFields);
    otpInput.addEventListener('input', validateFormFields);
</script>

        </tr>
    <?php endforeach; ?>
      </table>
      <?php endif; ?>
    </div>
  </div>

  
  <script>
    document.getElementById('download').addEventListener('click', () => {
      const element = document.getElementById('report');
      const options = {
        margin: 1,
        filename: 'example.pdf',
        html2canvas: { scale: 2 },
        jsPDF: { unit: 'in', format: 'letter', orientation: 'portrait' }
      };
      html2pdf().set(options).from(element).save();
    });
    const toggleBtn = document.getElementById("toggle-btn");
    const sidebar = document.getElementById("sidebar");

    // Toggle Sidebar
    toggleBtn.addEventListener("click", () => {
      sidebar.classList.toggle("visible");
    });
    function search(){
      window.location.href="pending.php"
  }

  </script>
  <script>
document.addEventListener("DOMContentLoaded", function () {
    const table = document.getElementById("sortableTable");
    const headers = table.querySelectorAll("th");
    let sortDirection = 1;
    let activeColumn = -1;

    headers.forEach((header, index) => {
        header.addEventListener("click", () => {
            const tbody = table.tBodies[0];
            const rows = Array.from(tbody.querySelectorAll("tr"));
            
            if (activeColumn === index) {
                sortDirection *= -1; // toggle
            } else {
                sortDirection = 1;
            }
            activeColumn = index;

            // Remove sort classes
            headers.forEach(h => h.classList.remove("asc", "desc"));
            header.classList.add(sortDirection === 1 ? "asc" : "desc");

            rows.sort((a, b) => {
                let aText = a.cells[index].textContent.trim();
                let bText = b.cells[index].textContent.trim();

                // Check if date
                if (/\d{4}-\d{2}-\d{2}/.test(aText) && /\d{4}-\d{2}-\d{2}/.test(bText)) {
                    return (new Date(aText) - new Date(bText)) * sortDirection;
                }

                // Check if number
                let aNum = parseFloat(aText.replace(/[^0-9.\-]/g, ""));
                let bNum = parseFloat(bText.replace(/[^0-9.\-]/g, ""));
                if (!isNaN(aNum) && !isNaN(bNum) && aText !== "" && bText !== "") {
                    return (aNum - bNum) * sortDirection;
                }

                // Default string compare
                return aText.localeCompare(bText, undefined, {numeric: true}) * sortDirection;
            });

            rows.forEach(row => tbody.appendChild(row));
        });
    });
});
</script>
</body>

</html>
