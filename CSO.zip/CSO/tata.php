<?php include('auth.php'); ?>
<?php
ini_set('display_errors', 1);
error_reporting(E_ALL);

// Increase PHP execution time and memory limit
ini_set('max_execution_time', 600); // Increase execution time to 600 seconds (10 minutes)
ini_set('memory_limit', '4096M'); // Increase memory limit to 4096MB
// Start session


$servername = "localhost";
$username = "root";
$password = "";
$dbname = "project_db";

// Create DB connection
$conn = new mysqli($servername, $username, $password, $dbname);
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

if (!isset($_SESSION['reference_id'])) {
    die("Reference ID not found in session.");
}
$reference_id = $_SESSION['reference_id'];

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['download_images'])) {

    // Get customer name
    $stmt_name = $conn->prepare("SELECT customerName FROM mis WHERE reference_id = ?");
    $stmt_name->bind_param("s", $reference_id);
    $stmt_name->execute();
    $result_name = $stmt_name->get_result();
    $customerName = "customer";
    if ($row = $result_name->fetch_assoc()) {
        $customerName = preg_replace('/[^a-zA-Z0-9]/', '', $row['customerName']);
    }
    $stmt_name->close();

    // Fetch image BLOBs
    $stmt = $conn->prepare("SELECT image1, image2, image3, image4, image5, image6, image7, image8, image9, image10, image11, image12,image13, image14, image15, image16, image17, image18, image19, image20 FROM final_uploaded_images WHERE reference_id = ?");    $stmt->bind_param("s", $reference_id);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows > 0 && ($row = $result->fetch_assoc())) {
        $tempDir = sys_get_temp_dir() . DIRECTORY_SEPARATOR . uniqid('images_', true);
        mkdir($tempDir);

        $imageFiles = [];
        for ($i = 1; $i <= 12; $i++) {
            if (!empty($row["image$i"])) {
                $filename = $tempDir . DIRECTORY_SEPARATOR . "image{$i}.jpg";
                file_put_contents($filename, $row["image$i"]);
                $imageFiles[] = $filename;
            }
        }

        if (empty($imageFiles)) {
            die("No images to download.");
        }

        // Create ZIP
        $zipFileName = "images_" . preg_replace('/[^a-zA-Z0-9]/', '_', $reference_id) . "_{$customerName}.zip";
        $zipPath = $tempDir . DIRECTORY_SEPARATOR . $zipFileName;

        $zip = new ZipArchive();
        if ($zip->open($zipPath, ZipArchive::CREATE) !== TRUE) {
            die("Failed to create ZIP file.");
        }

        foreach ($imageFiles as $file) {
            $zip->addFile($file, basename($file));
        }
        $zip->close();

        // Send ZIP to browser
        header('Content-Type: application/zip');
        header('Content-Disposition: attachment; filename="' . basename($zipFileName) . '"');
        header('Content-Length: ' . filesize($zipPath));
        flush();
        readfile($zipPath);

        // Cleanup
        foreach ($imageFiles as $file) {
            unlink($file);
        }
        unlink($zipPath);
        rmdir($tempDir);
        exit;
    } else {
        echo "<p style='color:red;'>No image data found for this reference ID.</td>";
    }
}

$page = isset($_GET['page']) ? $_GET['page'] : 1;
$limit = 50;
$offset = ($page - 1) * $limit;
$sql_property = "SELECT * FROM mis WHERE reference_id = ? LIMIT $limit OFFSET $offset";
$stmt_property = $conn->prepare($sql_property);
$stmt_property->bind_param("s", $reference_id);
$stmt_property->execute();
$result_property = $stmt_property->get_result();
$data1 = $result_property->fetch_assoc();

// Fetch data from property_details table
$sql_property = "SELECT * FROM property_details WHERE reference_id = ?";
$stmt_property = $conn->prepare($sql_property);
$stmt_property->bind_param("s", $reference_id);
$stmt_property->execute();
$result_property = $stmt_property->get_result();
$data2= $result_property->fetch_assoc();

// Fetch data from area_valuation table
$sql_area = "SELECT * FROM address_details WHERE reference_id = ?";
$stmt_area = $conn->prepare($sql_area); 
$stmt_area->bind_param("s", $reference_id);
$stmt_area->execute();
$result_area = $stmt_area->get_result();
$data3 = $result_area->fetch_assoc();

// Fetch data from area_valuation table
$sql_area = "SELECT * FROM critical_parameters WHERE reference_id = ?";
$stmt_area = $conn->prepare($sql_area); 
$stmt_area->bind_param("s", $reference_id);
$stmt_area->execute();
$result_area = $stmt_area->get_result();
$data4 = $result_area->fetch_assoc();

// Fetch data from area_valuation table
$sql_area = "SELECT * FROM surroundings_details WHERE reference_id = ?";
$stmt_area = $conn->prepare($sql_area); 
$stmt_area->bind_param("s", $reference_id);
$stmt_area->execute();
$result_area = $stmt_area->get_result();
$data5 = $result_area->fetch_assoc();
$stmt_area->close();
 
// Fetch data from area_valuation table
$sql_area = "SELECT * FROM area_valuation WHERE reference_id = ?";
$stmt_area = $conn->prepare($sql_area); 
$stmt_area->bind_param("s", $reference_id);
$stmt_area->execute();
$result_area = $stmt_area->get_result();
$data6 = $result_area->fetch_assoc();
$stmt_area->close();
 
// Fetch data from area_valuation table
$sql_area = "SELECT * FROM floor_details WHERE reference_id = ?";
$stmt_area = $conn->prepare($sql_area); 
$stmt_area->bind_param("s", $reference_id);
$stmt_area->execute();
$result_area = $stmt_area->get_result();
$data8= $result_area->fetch_assoc();
$stmt_area->close();
 
// Fetch data from area_valuation table
$sql_area = "SELECT * FROM technical_details WHERE reference_id = ?";
$stmt_area = $conn->prepare($sql_area); 
$stmt_area->bind_param("s", $reference_id);
$stmt_area->execute();
$result_area = $stmt_area->get_result();
$data9 = $result_area->fetch_assoc();
$stmt_area->close();
 
// Fetch data from area_valuation table
$sql_area = "SELECT * FROM remarks_table WHERE reference_id = ?";
$stmt_area = $conn->prepare($sql_area); 
$stmt_area->bind_param("s", $reference_id);
$stmt_area->execute();
$result_area = $stmt_area->get_result();
$data10 = $result_area->fetch_assoc();
$stmt_area->close();

// Step 1: Fetch the engineer_id from the mis table
$sql_mis = "SELECT engineer_id FROM mis WHERE reference_id = ?";
$stmt_mis = $conn->prepare($sql_mis);
$stmt_mis->bind_param("s", $reference_id);
$stmt_mis->execute();
$result_mis = $stmt_mis->get_result();
$row_mis = $result_mis->fetch_assoc();
$stmt_mis->close(); 

if ($row_mis) {
    $engineer_id = $row_mis['engineer_id'];

    // Step 2: Fetch the engineer's name from engineer_login table
    $sql_engineer = "SELECT name FROM engineer_login WHERE engineer_id = ?";
    $stmt_engineer = $conn->prepare($sql_engineer);
    $stmt_engineer->bind_param("s", $engineer_id);
    $stmt_engineer->execute();
    $result_engineer = $stmt_engineer->get_result();
    $row_engineer = $result_engineer->fetch_assoc();
    $stmt_engineer->close();

    if ($row_engineer) {
        $engineer_name = $row_engineer['name'];
         //echo "Engineer Name: " . $engineer_name;
    } else {
        echo "Engineer not found.";
    }
} else {
    echo "No engineer assigned for this reference_id.";
}

// Step 1: Fetch the engineer_id from the mis table
$sql_mis = "SELECT report_id FROM mis WHERE reference_id = ?";
$stmt_mis = $conn->prepare($sql_mis);
$stmt_mis->bind_param("s", $reference_id);
$stmt_mis->execute();
$result_mis = $stmt_mis->get_result();
$row_mis = $result_mis->fetch_assoc();
$stmt_mis->close(); 

if ($row_mis) {
    $report_id = $row_mis['report_id'];

    // Step 2: Fetch the engineer's name from engineer_login table
    $sql_engineer = "SELECT name FROM report_login WHERE report_id = ?";
    $stmt_engineer = $conn->prepare($sql_engineer);
    $stmt_engineer->bind_param("s", $report_id);
    $stmt_engineer->execute();
    $result_engineer = $stmt_engineer->get_result();
    $row_engineer = $result_engineer->fetch_assoc();
    $stmt_engineer->close();

    if ($row_engineer) {
        $report_name = $row_engineer['name'];
         //echo "Engineer Name: " . $report_name;
    } else {
        echo "Engineer not found.";
    }
} else {
    echo "No engineer assigned for this reference_id.";
}

// Step 1: Fetch the engineer_id from the mis table
$sql_mis = "SELECT report_drafter_to_technical FROM mis WHERE reference_id = ?";
$stmt_mis = $conn->prepare($sql_mis);
$stmt_mis->bind_param("s", $reference_id);
$stmt_mis->execute();
$result_mis = $stmt_mis->get_result();
$row_mis = $result_mis->fetch_assoc();
$stmt_mis->close(); 

if ($row_mis) {
    $report_drafter_to_technical = $row_mis['report_drafter_to_technical'];

    // Step 2: Fetch the engineer's name from engineer_login table
    $sql_engineer = "SELECT name FROM technical_login WHERE technical_manager_id = ?";
    $stmt_engineer = $conn->prepare($sql_engineer);
    $stmt_engineer->bind_param("s", $report_drafter_to_technical);
    $stmt_engineer->execute();
    $result_engineer = $stmt_engineer->get_result();
    $row_engineer = $result_engineer->fetch_assoc();
    $stmt_engineer->close();

    if ($row_engineer) {
        $technical_name = $row_engineer['name'];
        //echo "Engineer Name: " . $technical_name;
    } else {
        echo "Engineer not found.";
    }
} else {
    echo "No engineer assigned for this reference_id.";
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <link rel="shortcut icon" href="favicon.png" type="image/x-icon"> 
  <meta charset="UTF-8">
  <title>Tata Report</title>
  <style>
    body {
      font-family: Arial, sans-serif;
      background: #f7f9fc;
      margin: 20px;
    }

.content{
  width:auto;
  margin: 0 auto;
  background: #ffffff;
  padding:8px;
  box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
  border: 1px solid #dcdcdc;
}

header {
  display: flex;
  align-items: center;
}

.logo img {
  width: 100px;
  margin-left:30px;
  height: auto;
}

.header-content {
  text-align: center;
  flex: 1;
  margin-left:-190x
}

header h1 {
  margin: 0;
  font-weight:700;
  font-size:27px;
  color: #a60000;
  
}

header p {
  margin: 2px 0;
  font-size: 14px;
  font-weight: bolder;
  color: #9e2424;
  
}
    table {
      border-collapse: collapse;
      width: 100%;
      background: #fff;
      box-shadow: 0 0 8px rgba(0,0,0,0.1);
      border-radius: 8px;
    }

    th, td {
      text-align: left;
      padding: 10px;
      vertical-align: top;
      /* border:2px solid black; */
    }

    th {
      width: 20%;
      font-weight:700;
    }

    input[type="text"], textarea, select {
      width: 95%;
      padding: 6px;
      border-radius: 4px;
      border: none;
      font-size: 14px;
    }

    textarea {
      resize: vertical;
    }

    .section-title {
      background: #e6f0ff;
      font-weight: bold;
      padding: 10px;
      text-transform: uppercase;
      color: #003366;
    }

    .radio-group {
      display: flex;
      gap: 10px;
    }

    .radio-group label {
      margin-right: 15px;
    }
    span{
      font-weight:500;
      font-size:14px;
    }
  </style>
  <style>
.container {
    max-width: 1200px;
    margin: 20px auto;
    padding: 20px;
    background-color: white;
    box-shadow: 0px 0px 10px rgba(0, 0, 0, 0.1);
    border-radius: 8px;
}

.title {
    text-align: center;
    font-size: 24px;
    font-weight: bold;
    margin-bottom: 20px;
}
.grid-container {
    display: grid;
    grid-template-columns: repeat(4, 1fr);
    gap: 15px;
}

.grid-item {
    position: relative;
    border-radius: 8px;
    overflow: hidden;
    box-shadow: 0px 4px 6px rgba(0, 0, 0, 0.1);
}

.grid-item img {
    width: 100%;
    height: 200px;
    object-fit: cover;
    transition: transform 0.3s ease;
}
.grid-item:hover img {
    transform: scale(1.05);
}

.overlay {
    position: absolute;
    bottom: 0;
    left: 0;
    background: rgba(0, 0, 0, 0.6);
    color: white;
    width: 100%;
    padding: 8px;
    font-size: 14px;
    text-align: center;
}
 
   
/* Force a stable 4-column grid that wkhtmltopdf respects */
.image-gallery { width: 100%; }
.image-grid { width: 100%; border-collapse: collapse; table-layout: fixed; }
.image-grid tr { page-break-inside: avoid; }
.image-grid td { width: 25%; padding: 6px; vertical-align: top; }

.image-grid .img-wrap { display: block; }
.image-grid img { display: block; width: 100%; height: auto; }
.image-grid .caption { font-size: 12px; text-align: center; margin-top: 4px; }

/* If you had a flex layout before, neutralize it */
.image-gallery { display: block !important; }



    /* Print-specific rules */
    @media print {
      .no-print {
        display: none !important;
      }

      body {
        margin: 0;
      }
 
    }
  button{
    padding:8px;
    margin-left:45%;
    background-color:#808485;
    color:white;
    font-weight:700;
    font-style:italic;
  }
  button:hover{
    background-color:rgba(216,216,216,255);
    color:white;
  }

/* Optional: Google map styling */
    .google-map-container {
      max-width: 90%;
      margin: 20px auto;
      border: 2px solid #ccc;
      padding: 10px;
      box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
      background-color: #f9f9f9;
      border-radius: 8px;
      text-align: center;
    }

    .google-map-container img {
      max-width: 100%;
      height: auto;
      display: inline-block;
      border: 1px solid #999;
      border-radius: 4px;
    }
    
.logo img {
  width: 120px;
  margin-left:30px;
  height: auto;
}
</style>

</head>
<body>
<div class="content">
    <header>
      <div class="logo">
        <img src="images/logo.png" alt="Magpie Logo">
      </div>
      <div class="header-content">
        <h1>MAGPIE ENGINEERING PVT. LTD.</h1>
        <p>Valuer Designer Architects</p>
                <p>Office no. 201, 2nd floor, Gravity Mall, Mechanic nagar, warehouse road, near vijay nagar, Indore, Madhya Pradesh- 452011</p>
      </div>
    </header>
  <table>
    <tr>
      <td colspan="4" class="section-title">Property Address</td>
    </tr>
    <tr>
      <th>Pincode</th>
      <th>State</th>
      <th>City</th>
      <th>District</th>
   </tr>
      <tr>
      <td><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data3['pin_code'] ?? '') ?>
    </span></td>
      <td><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data3['address_line_4_as_per_doc'] ?? '') ?>
    </span></td>
      <td><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data3['address_line_3_as_per_doc'] ?? '') ?>
    </span></td>
      <td><span style="display: inline-block; min-width: 50px; padding: 2px;">
         <?= htmlspecialchars($data3['address_line_3_as_per_doc'] ?? '') ?>
    </span></td>
    </tr>
    <tr>
      <th>Taluka</th>
      <th>Village</th>
      <th>Locality</th>
      <th>Street Name & No.</th>
      </tr>
    <tr>
      <td><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars('Refer Address') ?>
    </span></td>
      <td><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars('Refer Address') ?>
    </span></td>
      <td><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data2['class_of_locality'] ?? '') ?>
    </span></td>
      <td><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars('Refer Address') ?>
    </span></td>
    </tr>
    <tr>
      <th>Landmark</th>
      <th>Project/Society Name</th>
      <th>Plot No.</th>
  </tr>
   <tr>
  <td><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data3['landmark_1'] ?? '') ?> <?= htmlspecialchars($data3['landmark_2'] ?? '') ?>
    </span></td>
      <td><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data3['address_per_document'] ?? '') ?>
    </span></td>
      <td><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data3['address_line_1_as_per_doc'] ?? '') ?>
    </span></td>
    </tr>
    <tr>
      <th>Property Type</th>
      <th>Property Sub Type</th>
      <th>Unit Type</th>
      <th>Unit No.</th>
  </tr>
     <tr>
      <td><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data2['property_unit_type'] ?? '') ?>
    </span>
      </td>
      <td><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data2['property_unit_type'] ?? '') ?>
    </span>
      </td>
      <td><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data2['electric_meter_no'] ?? '') ?>
    </span></td>
      <td><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data10['NA'] ?? '') ?>
    </span></td>
    </tr>
  
    <tr>
            <th colspan="3">Revenue Record Type & Number</th>
            <th>Property falling in which Area</th>
  </tr>
     <tr>
      <td colspan="3"><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data3['address_per_site'] ?? '') ?>
    </span></td>
      <td><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data3['property_location_in'] ?? '') ?>
    </span></td>
    </tr>
    </table>
  <table>
    <tr>
      <td colspan="4" class="section-title">Property Details</td>
    </tr>
    <tr>
      <th>Within Geo Limit</th>
      <th>Class Of Locality</th>
      <th>Property Jurisdiction</th>
      <th>Sanction Authority Name</th>
    </tr>
      <tr>
      <td><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data3['property_location_in'] ?? '') ?>
    </span></td>
      <td><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data2['class_of_locality'] ?? '') ?>
    </span></td>
      <td><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data3['property_location_in'] ?? '') ?>
    </span></td>
      <td><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data8['floor_document'] ?? '') ?>
    </span></td>
    </tr>
    <tr>
      <th>Sanction Usage</th>
      <th>Actual Usage</th>
      <th>Type of Structure</th>
      <th>Plot Area (Sqft)</th>
  </tr>
    <tr>
      <td><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data4['approved_property_usage'] ?? '') ?>
    </span></td>
      <td><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data4['current_property_usage'] ?? '') ?>
    </span></td>
      <td><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data4['structure_type'] ?? '') ?>
    </span></td>
      <td><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data6['final_plot_square_feet'] ?? '') ?>
    </span></td>
   </tr>
   <tr>
    <th>Basement Levels</th>
    <th>Parking Levels</th>
    <th>Livable Floors</th>
    <th>Structure Configuration</th>
  </tr>
    <tr>
      <td><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data10['NA'] ?? '') ?></span></td>
      <td><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data10['NA'] ?? '') ?></span></td>
      <td><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data10['NA'] ?? '') ?></span></td>
      <td><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data8['basements_remarks'] ?? '') ?></span></td>  
   </tr>
    <tr>
           <th>Society Registered</th>
           <th>Unique Property ID</th>
           <th>Property Entrance Facing</th>
           <th>Construction Status</th>
  </tr>
    <tr>
      <td><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data8['floor_availability'] ?? '') ?></span></td>
      <td><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data1['reference_id'] ?? '') ?></span></td>
      <td><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data2['property_facing'] ?? '') ?></span></td>
      <td><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data8['description_stage_construction_allotted'] ?? '') ?></span></td>
    </tr>
        <tr>
          <th>APF Flag</th>
          <th>Floor Number</th>
          <th>Count Of Properties</th>
          <th>Property Transaction Type</th>
  </tr>
    <tr>
      <td><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data10['NA'] ?? '') ?></span></td>
      <td><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data8['actual_configuration_building'] ?? '') ?></span></td>
      <td><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data8['document_area_saledeed'] ?? '') ?></span></td>
      <td><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data1['caseType'] ?? '') ?>
    </span></td>
    </tr>
    <tr>
      <th>Commencement Certificate Date</th>
      <th>Commencement Certificate Approval No.</th>
      <th>Approval Plan Date</th>
      <th>Approval Plan Number</th>
  </tr>
    <tr>
      <td><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data9['possesion_details'] ?? '') ?>
    </span></td>
      <td><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data9['possesion_details'] ?? '') ?>
    </span></td>

      <td><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data9['floor_details'] ?? '') ?>
    </span></td>
      <td><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data9['floor_details'] ?? '') ?>
    </span></td>
    </tr>
    <tr>
      <th>Occupancy Certificate Date</th>
      <th>Occupancy Certificate Approval No.</th>
  </tr>
    <tr>
      <td><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data9['nonagricultural_details'] ?? '') ?>
    </span></td>
      <td><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data9['location_details'] ?? '') ?>
    </span></td>
    </tr>
    <th>Risk of Demolition</th>
    <th>Status of Collateral</th>
    <th>Approved Authority</th>
  </tr>
    <tr>
      <td><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data9['demolition_risk_1'] ?? '') ?>
    </span></td>
      <td><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data2['property_leasehold_freehold'] ?? '') ?>
    </span></td>
      <td><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data9['property_leasehold_freehold'] ?? '') ?>
    </span></td>
    </tr>
    <tr>
        <th>Door Photo with Name Plate</th>
      <td colspan="3">
      <span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data9['layout_details'] ?? '') ?>
    </span>
      </td>
    </tr>
    </table>
    <table>
        <tr>
      <td colspan="8" class="section-title">Floor Details</td>
    </tr>
<tr>
      <th>Occupied Type</th>
      <td colspan="4"><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data2['relation_of_occupant'] ?? '') ?>
    </span></td>
</tr>
<tr>
      <th>Occupied Name</th>
      <td colspan="4"><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data2['occupant_name'] ?? '') ?>
    </span></td>
</tr><tr>
      <th>Occupied Since</th>
      <td colspan="4"><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data2['occupied_since'] ?? '') ?>
    </span></td>
</tr><tr>
      <th>Floor Details</th>
      <td colspan="4"><span style="white-space: pre-line; font-size:14px; display: block; text-align: left; padding: 0; margin: 0;"readonly>
        <?= htmlspecialchars($data10['negative_remarks'] ?? '') ?></span></td>  
</tr>
   <td colspan="8" class="section-title">Area Calculator</td>
    </tr>
<tr>
      <th>Area Measured</th>
      <td><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data2['project_approval_status'] ?? '') ?>
    </span></td>
        <td><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars('Sqft') ?>
    </span></td>
</tr>
    <tr>
      <td colspan="4" class="section-title">Property Maintenance</td>
    </tr>

    <tr>
      <th>Property Age (yrs)</th>
      <th>Residual Age (yrs)</th>
      <th>Internal Maintenance</th>
      <th>External Maintenance</th>
     </tr>
      <tr>
      <td><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data2['age_of_property'] ?? '') ?>
    </span></td>
      <td><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data2['residual_age_of_property'] ?? '') ?>
    </span></td>
      <td>
        <span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data2['structurally_fit'] ?? '') ?>
    </span>
      </td>
      <td><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data2['structurally_fit'] ?? '') ?>
    </span>
      </td>
    </tr>

    <tr>
      <th>Quality of Construction</th>
      <th>Leakage & Cracks</th>
      <th>Deviation Remarks</th>
      <th>Plot Area per Site</th>
      </tr>
      <tr>
      <td><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data2['structurally_fit'] ?? '') ?>
    </span></td>
      <td><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data10['NA'] ?? '') ?>
    </span></td>
      <td><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data10['NA'] ?? '') ?>
    </span></td>
      <td><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data6['actual_plot_square_feet'] ?? '') ?>
    </span></td>
    </tr>
        </div>
</td>
    </tr>
   </table>
    <table>
        <tr>
    <td colspan="8" class="section-title" style="font-weight: boldh">Boundaries</td>
  </tr>

  <tr>
    <th><b></b></th>
    <th><b>East</b></th>
    <th><b>West</b></th>
    <th><b>North</b></th>
    <th><b>South</b></th>
  </tr>

  <tr>
    <th>As Per Document</th>
    <td><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data3['direction_as_per_document_east'] ?? '') ?>
    </span></td>
    <td><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data3['direction_as_per_document_west'] ?? '') ?>
    </span></td>
    <td><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data3['direction_as_per_document_north'] ?? '') ?>
    </span></td>
    <td><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data3['direction_as_per_document_south'] ?? '') ?>
    </span></td>
  </tr>

  <tr>
    <th>As Per Site Visit</th>
    <td><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data3['direction_as_per_site_east'] ?? '') ?>
    </span></td>
    <td><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data3['direction_as_per_site_west'] ?? '') ?>
    </span></td>
    <td><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data3['direction_as_per_site_north'] ?? '') ?>
    </span></td>
    <td><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data3['direction_as_per_site_south'] ?? '') ?>
    </span></td>
  </tr>
<tr>

</tr>
  <tr>
    <th>Linear Dimensions(ft)</th>
    <td><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data6['dimension_as_per_site_east'] ?? '') ?>
    </span></td>
    <td><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data6['dimension_as_per_site_west'] ?? '') ?>
    </span></td>
    <td><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data6['dimension_as_per_site_north'] ?? '') ?>
    </span></td>
    <td><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data6['dimension_as_per_site_south'] ?? '') ?>
    </span></td>
  </tr>

  <tr>
    <th colspan="2">Capture Plot Sketch For Irregular Shape Plots</th>
    <th colspan="2">Plot Demarcated</th>
    <th colspan="2">Boundaries Are Matching</th>
   </tr>
  <tr>
    <td colspan="2"><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data2['project_id'] ?? '') ?>
    </span></td>
    <td colspan="2"><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data2['demarcated_at_site'] ?? '') ?>
    </span></td>
    <td colspan="2"><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data3['boundaries_matching'] ?? '') ?>
    </span></td>
  </tr>
  <tr>
    <th colspan="2">Property Demarcated at Site</th></tr>
    <tr><td colspan="2"><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data2['project_id'] ?? '') ?>
    </span></td>
  </tr>
  <tr>
    <th>Remarks</th></tr>
<tr><td><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data10
        ['NA'] ?? '') ?>
    </span></td></tr>
  </table>
  <table>
    <tr>
    <td colspan="4" class="section-title">Unit Amenities</td>
  </tr>
    <tr>
    <td><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data6['car_parking'] ?? '') ?>
    </span></td>
  </tr>
 </table>
  <table>
   <tr>
    <td colspan="4" class="section-title">Project Amenities</td>
  </tr>
  <td><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data6['addition_amenities_description_2'] ?? '') ?>
    </span></td>
  </tr>
  </table>
  <table>
  <tr>
    <td colspan="3" class="section-title">Surrounding Amenities</td>
  </tr>
  <tr>
    <th>Public Transport in 1km</th>
    </tr>
    <tr>
    <td><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data6['addition_amenities_description_3'] ?? '') ?>
    </span></td>
  </tr>
  <tr>
    <th>Other Ameniies in 1km</th>
   <tr>
    <td><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data6['addition_amenities_description_4'] ?? '') ?>
    </span></td>
  </tr>
  <tr>
    <th colspan="2">Infra Surroundings</th></tr>
    <tr>
    <td colspan="2">
      <span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data2['surrounding_infrastructure'] ?? '') ?>
    </span>
    </td>
  </tr>

  <tr>
    <th>Width Of Access Road (ft) - 1</th>
    <th>Width Of Access Road (ft) - 2</th>
    <th>Any Other?</th> </tr>
<tr>
    <td><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data2['width_of_approach_road'] ?? '') ?>
    </span></td>
    <td><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data2['approach_road_to_property'] ?? '') ?>
    </span></td>
    <td><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data10['NA'] ?? '') ?>
    </span></td>
  </tr>
  </table>
  <table>
  <tr>
    <td colspan="3" class="section-title">Caution Area</td>
  </tr>
  <tr>
  <th>Any Chemical Hazard</th>
  <th>Community Dominated</th>
  <th>Flood Prone</th></tr>
  <tr>
    <td><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data10['NA'] ?? '') ?>
    </span></td>
    <td><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data2['community_dominated'] ?? '') ?>
    </span></td>
    <td><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data10['NA'] ?? '') ?>
    </span></td>
  </tr>
  <tr>
    <th>Land Reservation</th>
    <th>Near Crematorium</th>
    <th>Near Garbage Dump</th></tr>
    <tr>
    <td><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data10['NA'] ?? '') ?>
    </span></td>
    <td><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data10['NA'] ?? '') ?>
    </span></td>
    <td><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data10['NA'] ?? '') ?>
    </span></td>
  </tr>
  <tr>
      <th>Near Nalla</th>
      <th>Near To Rail Track</th>
      <th>Near Garbage Extension</th></tr>
<tr>
    <td><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data10['NA'] ?? '') ?>
    </span></td>
    <td><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data10['NA'] ?? '') ?>
    </span></td>
    <td><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data10['NA'] ?? '') ?>
    </span></td>
  </tr>
  <tr>
      <th>Proprty Access Issues</th>
      <th>Proprty Is Land Locked</th>
      <th>Slum Area</th></tr>
  <tr>
    <td><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data10['NA'] ?? '') ?>
    </span></td>
    <td><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data10['NA'] ?? '') ?>
    </span></td>
    <td><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data10['NA'] ?? '') ?>
    </span></td>
  </tr>
  <tr>
    <th>Statutory Notices On Property</th>
    <th>Under High Tension Line</th>
    <th>Other</th></tr>
<tr>
    <td><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data10['NA'] ?? '') ?>
    </span></td>
    <td><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data4['near_high_tension'] ?? '') ?>
    </span></td>
    <td><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data10['NA'] ?? '') ?>
    </span></td>
  </tr>
  <tr>
      <th>Caution Level</th>
    <td colspan="2"><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data10['NA'] ?? '') ?>
    </span></td>
  </tr>
    <tr>
        <th class="section-title" colspan="5">Fair Market Valuation</th>
    </tr>
    <tr>
       <th>Choose the measurement unit</th>
    <td colspan="2"><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data10['NA'] ?? '') ?>
    </span></td>   
    </tr>
  <table>
  <thead>
      <tr>
        <th class="section-title" colspan="5">Land/Existing Structure Value</th>
    </tr>
      <tr>
        <th>Description</th>
        <th>Area (sq.ft.)</th>
        <th>Realizable Land Rate (₹)</th>
        <th>Amount (₹)</th>
      </tr>
    </thead>
    <tbody>
      <tr>
        <td>Plot Area</td>
        <td><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data6['final_plot_square_feet'] ?? '') ?>
    </span></td>
        <td><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data6['final_plot_rate'] ?? '') ?>
    </span></td>
        <td><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data6['total_finally_area_valuation'] ?? '') ?>
    </span></td>
      </tr>
         <tr>
        <th class="section-title" colspan="5">Unit Value</th>
    </tr>
       <tr>
        <th>Description</th>
        <th>Measured Area (sq.ft.)</th>
        <th>Approved Area (sq.ft.)</th>
        <th>Realizable Rate Per sq.ft(₹)</th>
        <th>Amount(₹)</th>
    </tr>
    <tr>
        <td>Ground Floor</td>
        <td><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data8['ground_actual'] ?? '') ?>
    </span></td>
        <td><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data8['ground_approved'] ?? '') ?>
    </span></td>
        <td><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data6['axis_ground_considered'] ?? '') ?>
    </span></td>
     <td>
    <span style="display:inline-block;min-width:50px;padding:2px;">
        <?= htmlspecialchars(
            (float)($data8['ground_permissible'] ?? 0) * (float)($data6['axis_ground_considered'] ?? 0)
        ) ?>
    </span>
</td>

    </tr>
    <tr>
        <td>First Floor</td>
        <td><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data8['first_actual'] ?? '') ?>
    </span></td>
        <td><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data8['first_approved'] ?? '') ?>
    </span></td>
        <td><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data6['axis_first_considered'] ?? '') ?>
    </span></td>
      <td>
    <span style="display:inline-block;min-width:50px;padding:2px;">
        <?= htmlspecialchars(
            (float)($data8['first_permissible'] ?? 0) * (float)($data6['axis_first_considered'] ?? 0)
        ) ?>
    </span>
</td>

    </tr>
     <tr>
        <td>Second Floor</td>
        <td><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data8['second_actual'] ?? '') ?>
    </span></td>
        <td><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data8['second_approved'] ?? '') ?>
    </span></td>
        <td><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data6['axis_second_considered'] ?? '') ?>
    </span></td>
        <td>
    <span style="display:inline-block;min-width:50px;padding:2px;">
        <?= htmlspecialchars(
            (float)($data8['second_permissible'] ?? 0) * (float)($data6['axis_second_considered'] ?? 0)
        ) ?>
    </span>
</td>
    </tr>
     <tr>
        <td>Third Floor</td>
        <td><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data8['other_actual_floors'] ?? '') ?>
    </span></td>
        <td><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data8['other_approved_floors'] ?? '') ?>
    </span></td>
        <td><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data6['axis_third_considered'] ?? '') ?>
    </span></td>
             <td>
    <span style="display:inline-block;min-width:50px;padding:2px;">
        <?= htmlspecialchars(
            (float)($data8['other_permissible_floors'] ?? 0) * (float)($data6['axis_third_considered'] ?? 0)
        ) ?>
    </span>
</td>
    </tr>
     <tr>
        <td>Fourth Floor</td>
        <td><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data8['total_actual_floors'] ?? '') ?>
    </span></td>
        <td><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data8['total_approved_floors'] ?? '') ?>
    </span></td>
        <td><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data6['axis_forth_considered'] ?? '') ?>
    </span></td>
                 <td>
    <span style="display:inline-block;min-width:50px;padding:2px;">
        <?= htmlspecialchars(
            (float)($data8['total_permissible_floors'] ?? 0) * (float)($data6['axis_forth_considered'] ?? 0)
        ) ?>
    </span>
</td>
    </tr>
    <tr class="total-row">
        <td>Total</td>
        <td><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data10['NA'] ?? '') ?>
    </span></td>
        <td><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data10['NA'] ?? '') ?>
    </span></td>
        <td></td>
        <td><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data10['NA'] ?? '') ?>
    </span></td>
    </tr>
    <tr>
      <th colspan="2">Valuation On</th>
      <th colspan="2">Construction Value</th>
    </tr>
    <tr>
      <td colspan="2"><span style="display: inline-block; min-width: 50px; padding: 2px;">
          <?= htmlspecialchars($data8['approved_configuration_building'] ?? '') ?>
      </span></td>
       <td colspan="2"><span style="display: inline-block; min-width: 50px; padding: 2px;">
          <?= htmlspecialchars($data6['total_finally_area_valuation'] ?? '') ?>
      </span></td>
    </tr>
    </tbody>
  </table>
<table>
  <td><strong>Amenities Or Interiors</strong></td>
  <td><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data6['addition_amenities_amount_2'] ?? '') ?>
    </span></td></tr>
    <tr>
  <td><strong>Realizable Value of Unit</strong></td>
  <td><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data6['total_finally_area_valuation'] ?? '') ?>
    </span></td></tr>
    <tr>
  <td><strong>Distress Value of the property *</strong></td>
 <td> <span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data6['total_distress_value'] ?? '') ?>
    </span></td>
  <td><strong>Deviation(%) *</strong></td>
  <td><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data10['NA'] ?? '') ?></span><td></tr>
        <tr>
  <div class="section-title">Valuation As Per Government Rates</div>

  <td><strong>Santioned Usage</strong></td>
 <td> <span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data4['approved_property_usage'] ?? '') ?></span></td>
  <table>
    <thead>
      <tr>
        <th>Description</th>
        <th>Area (sq.ft.)</th>
        <th>Realizable Rate Per sq.ft (₹)</th>
      </tr>
    </thead>
    <tbody>
      <tr>
        <td>Land/BU/SBU</td>
        <td><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data6['final_plot_square_feet'] ?? '') ?>
    </span></td>
        <td><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data6['guideline_rate'] ?? '') ?>
    </span></td>
      </tr>
      <tr>
        <td>Construction</td>
        <td><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data6['actual_construction_square_feet'] ?? '') ?>
    </span></td>
        <td><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data6['actual_construction_rate'] ?? '') ?>
    </span></td>
      </tr>
      <tr>
        <th>Total Value (Gross Value): </th>
        <td><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data6['total_actual_area_valuation'] ?? '') ?>
    </span></td>
      </tr>
     </table>
      <table> 
        <tr>
    <td colspan="6" class="section-title">Construction Progress Details</td>
  </tr>
  <tr>
        <th colspan="2">Structure Configuration</th>
        <th colspan="2">Stage Of Completion Amenities (%)</th>
        <th colspan="2">Stage Of Recommendation Amenities(%)</th></tr>
  <tr>
        <td colspan="2"><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data8['basements_remarks'] ?? '') ?>
    </span></td>
        <td colspan="2"><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data2['infra_building'] ?? '') ?>
    </span></td>
        <td colspan="2"><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data2['infra_building'] ?? '') ?>
    </span></td>
  </tr></table>
  <table>
   <tr>
    <td colspan="8" class="section-title">Stage of Amenity</td>
  </tr>
  <tr>
    <th colspan="3">% Complete:%</th>
    <th colspan="3">% Recommendation:%</th></tr>
    <tr>
        <td colspan="3"><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data8['stage_construction_actual_present_completion'] ?? '') ?>
    </span></td>
        <td colspan="3"><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data8['stage_construction_actual_present_completion'] ?? '') ?>
    </span></td>
  </tr>
    <tr>
    <td colspan="8" class="section-title">Stage of Structure</td>
  </tr>
  <tr>
         <th colspan="2">% Complete:%</th>
         <th colspan="2">% Recommendation:%</th>
         <th colspan="2">% User Recommendation:</th></tr>
<tr>
         <td colspan="2"><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data8['stage_construction_actual_present_completion'] ?? '') ?>
    </span></td>
        <td colspan="2"><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data8['stage_construction_recommend_present_completion'] ?? '') ?>
    </span></td>
        <td colspan="2"><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data8['total_completion_present'] ?? '') ?>
    </span></td>
  </tr>
  <tr>
     <th>Recommendation Value:</th>
        <td><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data10['NA'] ?? '') ?>
    </span></td>
  </tr>
  <tr>
    <th>Comments on Construction</th>
  <td><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data10['NA'] ?? '') ?>
    </span></td>
  </tr>
        <tr>
    <td colspan="8" class="section-title">Distance Range of the property</td>
  </tr>
  <tr>
    <td colspan="2">Distance From Branch (kms)<br><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data3['distance_from_branch_kms'] ?? '') ?>
    </span></td>
    <td colspan="2">Distance From City Center (kms) <span class="required">*</span></span><br><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data3['nearest_bus_stop_distance'] ?? '') ?>
    </span></td>
    <td colspan="2">Distance From TCHFL Bank Sourcing Branch (kms)<br><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data3['distance_from_branch_kms'] ?? '') ?>
    </span></td>
    <td colspan="2">Latitude <span class="required">*</span><br><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data3['latitude_value'] ?? '') ?>
    </span></td>
  </tr>
  <tr>
    <td colspan="2">Longitude<br></td>
      <td colspan="2">One Way Distance From Operating Location (kms)<br></td>
      <td colspan="2">Surrounding Development<br></td>
      <td colspan="2">Marketability</td><br></tr>
      <tr>
      <td colspan="2"><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data3['longitude_value'] ?? '') ?>
    </span></td>
      <td colspan="2"><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data3['nearest_branch_location'] ?? '') ?>
    </span></td>
    <td colspan="2"><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data2['develop_percent'] ?? '') ?>
    </span></td>
    <td colspan="2"><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data9['markebility'] ?? '') ?></span></td>
  </tr>
</table>
 <table>
<tr><th style="margin-bottom:-18px;">PHOTOGRAPH OF THE PROPERTY</tr></th></table>
<br>

    
<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

$servername = "localhost";
$username   = "root";
$password   = "";
$dbname     = "project_db";

$conn = new mysqli($servername, $username, $password, $dbname);
if ($conn->connect_error) {
    die("Connection failed: " . htmlspecialchars($conn->connect_error));
}

$reference_id = $_SESSION['reference_id'] ?? null;
$reference_id = $_GET['reference_id'] ?? $reference_id;

if ($reference_id) {

    // Map captions
    $captions = [
        'image1'  => 'EXTERNAL PHOTOS',
        'image2'  => 'Kitchen',
        'image3'  => 'Selfie',
        'image4'  => 'Electric Meter',
        'image6'  => 'Other 1',
        'image7'  => 'Other 2',
        'image8'  => 'Other 3',
        'image9'  => 'Other 4',
        'image10' => 'Other 5',
        'image11' => 'Other 6',
        'image12' => 'Other 7',
        'image13' => 'Other 8',
        'image14' => 'Other 9',
        'image15' => 'Other 10',
        'image16' => 'Other 11',
        'image17' => 'Other 12',
        'image18' => 'Other 13',
        'image19' => 'Other 14',
        'image20' => 'Other 15',
    ];

    // === Helper: EXIF-aware orientation detection ===
    function classify_orientation_after_exif(string $imageData): ?string {
        $size = @getimagesizefromstring($imageData);
        if (!$size || !isset($size[0], $size[1])) {
            return null;
        }
        $width  = (int)$size[0];
        $height = (int)$size[1];

        $mime = $size['mime'] ?? '';
        if ($mime === 'image/jpeg' && function_exists('exif_read_data')) {
            $tmp = @tempnam(sys_get_temp_dir(), 'exif_');
            if ($tmp !== false) {
                @file_put_contents($tmp, $imageData);
                $exif = @exif_read_data($tmp);
                @unlink($tmp);

                if (!empty($exif['Orientation'])) {
                    $orientation = (int)$exif['Orientation'];
                    if ($orientation === 6 || $orientation === 8) {
                        $t = $width; $width = $height; $height = $t;
                    }
                }
            }
        }
        return ($width >= $height) ? 'horizontal' : 'vertical';
    }

    // === Helper: Fix orientation physically with Imagick ===
    function fixImageOrientation($binaryData) {
        $img = new Imagick();
        $img->readImageBlob($binaryData);

        switch ($img->getImageOrientation()) {
            case Imagick::ORIENTATION_BOTTOMRIGHT:
                $img->rotateImage("#000", 180);
                break;
            case Imagick::ORIENTATION_RIGHTTOP:
                $img->rotateImage("#000", 90);
                break;
            case Imagick::ORIENTATION_LEFTBOTTOM:
                $img->rotateImage("#000", -90);
                break;
        }

        $img->setImageOrientation(Imagick::ORIENTATION_TOPLEFT);
        $fixed = $img->getImageBlob();
        $img->destroy();

        return $fixed;
    }

    $sql = "SELECT 
                image1, image2, image3, image4, 
                image6, image7, image8, image9, 
                image10, image11, image12, image13, image14, image15, image16, image17, image18, image19, image20
            FROM final_uploaded_images 
            WHERE reference_id = ?";

    $stmt = $conn->prepare($sql);
    if ($stmt === false) {
        die("Error preparing the SQL statement: " . htmlspecialchars($conn->error));
    }

    $stmt->bind_param("s", $reference_id);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result && $result->num_rows > 0) {
        $horizontal_images = [];
        $vertical_images   = [];

        while ($row = $result->fetch_assoc()) {
            foreach ($row as $key => $imageData) {
                if (!empty($imageData)) {

                    // Actually fix image before displaying
                    $fixedData = fixImageOrientation($imageData);

                    $orientation = classify_orientation_after_exif($fixedData) ?? 'horizontal';
                    $imgString   = base64_encode($fixedData);
                    $caption     = $captions[$key] ?? 'Image';

                    $item = [
                        'data'    => $imgString,
                        'caption' => $caption,
                        'alt'     => $key,
                    ];

                    if ($orientation === 'horizontal') {
                        $horizontal_images[] = $item;
                    } else {
                        $vertical_images[]   = $item;
                    }
                }
            }
        }

 
// Output as a stable 4-column table (works in wkhtmltopdf)
$all_images = array_merge($vertical_images, $horizontal_images);

echo '<table class="image-grid">';
$rows = array_chunk($all_images, 4);
foreach ($rows as $row) {
    echo '<tr>';
    foreach ($row as $img) {
        echo '<td>';
        echo '<div class="img-wrap">';
        echo '<img src="data:image/jpeg;base64,' . $img['data'] . '" alt="' . htmlspecialchars($img['alt']) . '">';
        echo '<div class="caption">' . htmlspecialchars($img['caption']) . '</div>';
        echo '</div>';
        echo '</td>';
    }
    // pad remaining cells to keep 4 columns
    $remaining = 4 - count($row);
    if ($remaining > 0) {
        echo str_repeat('<td></td>', $remaining);
    }
    echo '</tr>';
}
echo '</table>';

    } else {
        echo "<p style='text-align:center;'>No images found.</p>";
    }

    $stmt->close();
} else {
    echo "<p style='text-align:center;'>Reference ID is missing.</p>";
}
?>

    
      <table>
  </tr>
  <tr>

<div class="google-map-container">
<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "project_db";
$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$reference_id = $_SESSION['reference_id'] ?? null;
$reference_id = $_GET['reference_id'] ?? $reference_id;

if ($reference_id) {
    $sql = "SELECT image5 FROM final_uploaded_images WHERE reference_id = ?";
    $stmt = $conn->prepare($sql);
    if ($stmt === false) {
        die("Error preparing the SQL statement: " . $conn->error);
    }

    $stmt->bind_param("s", $reference_id);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows > 0) {
        $row = $result->fetch_assoc();
        if (!empty($row['image5'])) {
 
            echo '<div><img src="data:image/jpeg;base64,' . base64_encode($row['image5']) . '" alt="Google Map"><p>Google Map</p></div>';
        } else {
            echo "<p style='text-align:center;'>Google Map image not available.</p>";
        }
    } else {
        echo "<p style='text-align:center;'>No record found for Google Map image.</p>";
    }

    $stmt->close();
} else {
    echo "<p style='text-align:center;'>Reference ID is missing.</p>";
}
?>
</tr>
</div>
    </table>
    </table>
 
  

    <table>
  <tr>
    <th class="section-title">Remarks</th>
    <td colspan="8"><span style="white-space: pre-line; font-size:14px; display: block; text-align: left; padding: 0; margin: 0;">
        <?= htmlspecialchars($data10['remarks'] ?? '') ?></span></td>
  </tr>
  <tr>
    <td>Is this property valued under market practice ?</td>
    <td><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars('Yes') ?>
    </span></td>
  </tr></table>
  <table>
  <tr>
    <td colspan="4" class="section-title">Document Vetted</td>
  </tr>

  <!-- Row 1 -->
  <tr>
    <th>Document Name</th>
    <th colspan="2">Document Reference</th>
    <th>Document Date</th></tr>
<tr>
    <td><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data9['ownership1_document'] ?? '') ?> <?= htmlspecialchars($data9['ownership2_document'] ?? '') ?>
    </span></td>
    <td colspan="2"><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data9['ownership1_details'] ?? '') ?> <?= htmlspecialchars($data9['ownership2_details'] ?? '') ?>
    </span></td>
    <td><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data9['ownership1_details'] ?? '') ?> <?= htmlspecialchars($data9['ownership2_details'] ?? '') ?>
    </span></td>
  </tr>
  <tr>
      <th colspan="2">Authority</th>
      <th colspan="2">Action</th>
    </tr>
  <tr>
      <td colspan="2"><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data10['NA'] ?? '') ?>
    </span></td>
    <td colspan="2"><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data10['NA'] ?? '') ?>
    </span></td>
  </tr>
  <!-- Row 3 -->
  <tr>
    <th>Name Of The Person Met At Site</th>
    <th>Relationship Of The Person</th>
    <th>Mobile No. of The Person Met At  Site</th>
    <th>No. Of Site Visits</th></tr>
<tr>
    <td><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data2['person_meet_at_site_contact'] ?? '') ?>
    </span></td>
    <td><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data2['relation_of_occupant'] ?? '') ?>
    </span></td>
    <td><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data2['person_meet_at_site_contact'] ?? '') ?>
    </span></td>
    <td><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data10['NA'] ?? '') ?>
    </span></td>
  </tr>
  <!-- Row 5 -->
  <tr>
    <th>Visited By</th>
    <th>Visited User Type</th>
    <th>Date Of Site Visit</th></tr>
<tr>
    <td><input type="text" readonly  value="<?= $engineer_name ?>"></td>
    </span></td>
    <td><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data10['NA'] ?? '') ?>
    </span></td>
    <td><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data1['fe_to_coordinator_assign_at'] ?? '') ?>
    </span></td>
  </tr>
  </table>
  <table>
  <!-- Section Title -->
  <tr>
    <td colspan="6" class="section-title">5. UNDERTAKING</td>
  </tr>

  <!-- Undertaking Rows -->
   <tr>
    <td colspan="2" style="font-weight: bold; color: #0056b3;">
      I have personally checked following in the Property:
    </td>
    <td>
      <span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars('I have personally visited the property & identified the same based on the documents provided. ') ?>
    </span>
    <span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars('I/We have no direct or Indirect Interest in the property being valued. ') ?>
    </span>
    <span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars('The information furnished above is true and correct to my/our knowledge.') ?>
    </span>
    </td>
  </tr>
  

  <!-- Actual builtup Area -->
  <tr>
    <td colspan="2">Copy of approved Plans by Appropriate authority</td>
    <td colspan="2">Property identification possible with available documents</td>
    <td colspan="2">Conversion of Land by District Collector for current use</td></tr>
   <tr>
    <td colspan="2"><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data6['axis_ground_actual'] ?? '') ?>
    </span></td>
    <td colspan="2"> <span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data6['axis_first_actual'] ?? '') ?>
    </span></td>
    <td colspan="2"> <span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data6['axis_second_actual'] ?? '') ?>
    </span></td>
  </tr>
  
  <tr>
    <td colspan="2">Does property falls in Negative Property List?</td>
    <td colspan="2">The property is constructed as per local Bye Laws </td>
    <td colspan="2">I have personally visited the property & identified the same based on the documents provided.</td></tr>
 <tr>
    <td colspan="2"><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data6['axis_3_actual'] ?? '') ?></span></td>
    <td colspan="2"><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data6['axis_4_actual'] ?? '') ?></span></td>
    <td colspan="2"><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data6['axis_other_actual'] ?? '') ?>
    </span></td>
  </tr>
  <tr>
    <td colspan="2">I/We have no direct or indirect interest in the property being valued</td>
    <td colspan="2">The information furnished above is true and correct to my/our knowledge</td>
    <td colspan="2">The valuation considered is as per local bye laws</td></tr> 
<tr>
    <td colspan="2"><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data6['axis_basement_floor1'] ?? '') ?>
    </span></td>
      <td colspan="2"><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data6['axis_basement_floor2'] ?? '') ?>
    </span></td>
      <td colspan="2"><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data6['axis_basement_floor3'] ?? '') ?>
    </span></td>
  </tr>
  
  <tr>
    <th colspan="2">Whether the property fulfills the criteria as per NDMA guidelines
    </th>  
  </tr>
  <tr>
        <td colspan="2"><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data6['axis_final_plot_square_feet'] ?? '') ?>
    </span></td>
  </tr>
    </tbody>
    
  </table>
</table>
</table>
   <!-- Buttons: Hidden during print -->
<div class="no-print">
  <form method="post">
    <input type="hidden" name="download_images" value="1">
    <button type="submit">Download All Images</button>
  </form>
  <button id="downloadPdf" onclick="setPrintMargins()">DOWNLOAD PDF</button>
</div>
  <script>
    document.getElementById('downloadPdf').addEventListener('click', () => {
      // Select the content you want to convert to PDF
      const element = document.getElementById('content');
      const options = {
        margin:[0,0],
        filename:'report.pdf',
        image: { type: 'jpeg', quality: 0.98 },
        html2canvas: { scale: 2 },
        jsPDF: { unit: 'in', format: 'letter', orientation: 'portrait' }
      };

      // Generate and download the PDF
      html2pdf().set(options).from(element).save();
    });
    function setPrintMargins() {
      const style = document.createElement('style');
      style.innerHTML = `
      @media print {
          body {
            margin:0.5;
          }
        }
      `;
      document.head.appendChild(style);
      window.print();
    }
    // Disable all input fields in the form
    document.querySelectorAll('input').forEach(function(input) {
        input.disabled = true;  // Disables the field completely
    });
     function resizeFakeInput(input) {
    const fake = document.getElementById('fakeWrap');
    fake.textContent = input.value || ' ';
    input.style.height = fake.scrollHeight + 'px';
  }

  // Initialize height
  resizeFakeInput(document.getElementById('longInput'));
   function autoResize(el) {
    el.style.height = 'auto'; // reset height
    el.style.height = el.scrollHeight + 'px'; // set to content height
  }
  // Auto-resize on load
  document.querySelectorAll('.clean-textarea').forEach(t => autoResize(t));
    </script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/jspdf/2.5.1/jspdf.umd.min.js"></script>

  <script>
    // Disable input fields before generating PDF
    function disableInputs() {
      document.querySelectorAll('input, textarea').forEach(input => input.disabled = true);
    }

    // Re-enable input fields after PDF generation (optional)
    function enableInputs() {
      document.querySelectorAll('input, textarea').forEach(input => input.disabled = false);
    }

    // Auto-resize textareas
    function autoResize(el) {
      el.style.height = 'auto';
      el.style.height = el.scrollHeight + 'px';
    }

    document.querySelectorAll('.clean-textarea').forEach(t => autoResize(t));

    // PDF generation logic using jsPDF with html()
    document.getElementById('downloadPdf').addEventListener('click', async () => {
      disableInputs();

      const { jsPDF } = window.jspdf;
      const doc = new jsPDF({
        orientation: 'portrait',
        unit: 'pt',
        format: 'a4'
      });

      await doc.html(document.getElementById('content'), {
        callback: function (doc) {
          doc.save('report.pdf');
          enableInputs();
        },
        margin: [40, 40, 40, 40],
        autoPaging: 'text',
        x: 10,
        y: 10,
        html2canvas: {
          scale: 1,
          useCORS: true
        }
      });
    });
  </script>
</div>
</body>
</html>