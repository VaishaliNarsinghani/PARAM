<?php include('auth.php'); ?>
<?php
$host = 'localhost';
$db = 'project_db';
$user = 'root';
$pass = '';
$message = "";

try {
    $pdo = new PDO("mysql:host=$host;dbname=$db;charset=utf8", $user, $pass);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

    $results = [];

    if ($_SERVER['REQUEST_METHOD'] === 'POST') {
        $query = "SELECT * FROM mis WHERE 1=1";
        $params = [];

        if (!empty($_POST['reference_id'])) {
            $query .= " AND reference_id LIKE ?";
            $params[] = "%" . $_POST['reference_id'] . "%";
        }

        if (!empty($_POST['customerName'])) {
            $query .= " AND customerName LIKE ?";
            $params[] = "%" . $_POST['customerName'] . "%";
        }
        if (!empty($_POST['city'])) {
            $query .= " AND address LIKE ?";
            $params[] = "%" . $_POST['city'] . "%";
        }
        if (!empty($_POST['applicationNo'])) {
            $query .= " AND applicationNo LIKE ?";
            $params[] = "%" . $_POST['applicationNo'] . "%";
        }
        if (!empty($_POST['party_name'])) {
            $query .= " AND party_name LIKE ?";
            $params[] = "%" . $_POST['party_name'] . "%";
        }
        if (!empty($_POST['branchname'])) {
            $query .= " AND branchname LIKE ?";
            $params[] = "%" . $_POST['branchname'] . "%";
        }
        if (!empty($_POST['caseType'])) {
            $query .= " AND caseType LIKE ?";
            $params[] = "%" . $_POST['caseType'] . "%";
        }

        $stmt = $pdo->prepare($query);
        $stmt->execute($params);
        $results = $stmt->fetchAll(PDO::FETCH_ASSOC);

        // Append additional data from other tables
        foreach ($results as &$row) {
            // Fetch from address_details
            $stmt1 = $pdo->prepare("SELECT address_per_site, nearest_branch_location, distance_from_branch_kms, latitude_value, longitude_value FROM address_details WHERE reference_id = ?");
            $stmt1->execute([$row['reference_id']]);
            $addressDetails = $stmt1->fetch(PDO::FETCH_ASSOC);

            $row['address_per_site'] = $addressDetails['address_per_site'] ?? '';
            $row['nearest_branch_location'] = $addressDetails['nearest_branch_location'] ?? '';
            $row['distance_from_branch_kms'] = $addressDetails['distance_from_branch_kms'] ?? '';
            $row['latitude_value'] = $addressDetails['latitude_value'] ?? '';
            $row['longitude_value'] = $addressDetails['longitude_value'] ?? '';

            // Fetch from area_valuation
            $stmt2 = $pdo->prepare("SELECT final_plot_square_feet, final_construction_square_feet, final_area_square_feet FROM area_valuation WHERE reference_id = ?");
            $stmt2->execute([$row['reference_id']]);
            $areaValuation = $stmt2->fetch(PDO::FETCH_ASSOC);

            $row['final_plot_square_feet'] = $areaValuation['final_plot_square_feet'] ?? '';
            $row['final_construction_square_feet'] = $areaValuation['final_construction_square_feet'] ?? '';
            $row['final_area_square_feet'] = $areaValuation['final_area_square_feet'] ?? '';
        }
    }

    if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['update'])) {
        $stmt = $pdo->prepare("UPDATE mis SET customerName = ?, address = ?, customerMob = ?, visitType = ?, party_name = ?, branchname= ?,caseType = ?, applicationNo = ?, initiatorMailId = ?, initiationDate = ? WHERE reference_id = ?");
        $stmt->execute([
            $_POST['customerName'],
            $_POST['address'],
            $_POST['customerMob'],
            $_POST['visitType'],
            $_POST['party_name'],
            $_POST['branchname'],
            $_POST['caseType'],
            $_POST['applicationNo'],
            $_POST['initiatorMailId'],
            $_POST['initiationDate'],
            $_POST['reference_id']
        ]);
        $message = "Details updated successfully!";
    }
} catch (PDOException $e) {
    $message = "Error: " . $e->getMessage();
}
?>

<!-- Alert Script -->
<script>
    <?php if (!empty($message)): ?>
    alert("<?= htmlspecialchars_decode(addslashes($message)) ?>");
    <?php endif; ?>
</script>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Magpie Engineering</title>
    <link rel="shortcut icon" href="favicon.ico" type="image/x-icon">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
    <link rel="stylesheet" href="initiator1.css">
</head>
<body>
    <button class="toggle-btn" id="toggle-btn">☰</button>
    <div class="container">
        <div class="sidebar" id="sidebar">
            <div style="display: flex">
                <img class="logo" src="logo.png" alt="" />
                <h1>Magpie Engineering</h1>
            </div>
            <div class="rotating-text">INITIATOR</div>
            <a href="initiator.php" class="active"><i class="fas fa-search icon"></i>Search</a>
            <a href="homeinitiator.php"><i class="fas fa-home icon"></i>Home</a>
            <a href="update.php"><i class="fas fa-home icon"></i>update assignment</a>
            <a href="createsassign.php"><i class="fas fa-file-alt icon"></i> Create New Assignment</a>
            <a href="Createsubs.php"><i class="fas fa-plus-square icon"></i> Create Subsequent</a>
            <a href="Revisereport.php"><i class="fas fa-edit icon"></i> Revise Report</a>
            <a href="index.php"><i class="fas fa-sign-out-alt icon"></i>Logout</a>
        </div>

        <div class="content" id="content">
            <div class="search-filters">
                <h2>Search Filters</h2>
                <form id="searchForm" method="POST" action="initiator.php">
                    <div class="form-row">
                        <input type="text" name="reference_id" placeholder="Reference ID" />
                        <input type="text" name="customerName" placeholder="Customer Name" />
                    </div>
                    <div class="form-row">
                        <input type="text" name="city" placeholder="City" />
                        <input type="text" name="applicationNo" placeholder="Application No." />
                    </div>
                    <div class="form-row">
                        <input type="text" name="party_name" placeholder="Party Name " />
                        <input type="text" name="branchname" placeholder="Branch Name" />
                        <input type="text" name="caseType" placeholder="Case Type" />
                    </div>
                    <button type="submit" style="background: #4A90E2;">Search</button>
                </form>
            </div>


       <table>       <?php         
         echo "<style>
       /* Main Content */
 .content {
  margin: 0; /* Remove conflicting margins */
  padding: 100px;
  animation: fadeIn 1.5s ease-in-out;
  transition: transform 0.3s ease-in-out;
}

table {
  width:500%;
  margin: 0 1% 0 25%; /* Use the same margin in both pages */
  border-collapse: collapse;
  background:rgb(207, 222, 240);
  color: #2C3E50;
  border-radius: 10px;
  overflow: hidden;
  table-layout: fixed; /* Enforce fixed column widths */
  
}

th, td {
  padding: 5px;
  text-align: left;
  border: 1px solid rgba(255, 255, 255, 0.2);
  font-size: 15px;
  word-wrap: break-word; /* Allow wrapping of text */
  white-space: normal; /* Ensure wrapping is allowed */
  min-width: 100px; /* Set a minimum width for columns */
}

th {
  font-size: 13px;
  background-color:rgb(102, 146, 190);
   color:white;
  font-weight: bold;
}

table {
    table-layout: fixed; /* Enforces fixed column widths */
}

th, td {
     /* Adjust as needed for your preferred column width */
    word-wrap: break-word; /* Allows text to wrap onto the next line */
    white-space: normal; /* Ensures wrapping is allowed */
}


 tr:nth-child(even) {
   background-color:rgb(234, 236, 250);
 }

 tr:hover {
   background-color:rgb(138, 177, 215);
   color:white;
   font-weight:bolder;
   font-style:italic;
 }
h2{
  margin-left:48% ; 
   font-style: oblique;
    color:#2C3E50;      
}
 button{
    padding: 5px 10px;
    background-color: #005f8a;
    color: white;
    text-decoration: none;
    border: none;
    border-radius: 5px;
    cursor: pointer;
    font-size: 14px;
}
    @media (max-width: 768px) {
  

  .content {
    margin-left: 0;
  }

  .search-filters input,
  .search-filters button {
    width: 90%;
  }
}
.content {
  margin-left: 270px; /* Adjust based on sidebar width */
}


@media (min-width: 1200px) {

 @media (max-width: 768px) {
 .toggle-btn {
   display: block;
 }
 .sidebar {
   transform: translateX(-100%);
 }
 .sidebar.visible {
   transform: translateX(0);
 }
 .content {
   margin-left: 0;
   margin:0;
 }
  /.search-filters input,
 .search-filters button {
   width: 90%;
 }
}
@keyframes slideIn {
 from {
   transform: translateX(-100%);
   opacity: 0;
 }
 to {
   transform: translateX(0);
   opacity: 1;
 }
}
@keyframes fadeIn {
 from {
   opacity: 0;
 }
 to {
   opacity: 1;
 }
}
.logo{
 width: 40px;
 height: 40px;
 padding: 15px;
}
  @media (max-width: 768px) {
    .toggle-btn {
      display: block;
    }
    .sidebar {
      transform: translateX(-100%);
    }
    .sidebar.visible {
      transform: translateX(0);
    }
    .content {
      margin-left:0px;

    }
    .search-filters input,
    .search-filters button {
      width: 90%;
    }
  }
   </style>";
   echo "<h2>Customer Information Table</h2>";?>
                <tr>
                    <th>Reference Number</th>
                    <th>Customer Name</th>
                    <th>Address</th>
                    <th>Customer Mobile Number</th>
                    <th>Visit Type</th>
                    <th>Party Name</th>
                    <th>Branch Name</th>
                    <th>Case Type</th>
                    <th>Application Number</th>
                    <th>Mail ID</th>
                    <th>Date</th>

                    <!-- New columns from address_details -->
                    <th>Address Per Site</th>
                    <th>Nearest Branch Location</th>
                    <th>Distance From Branch (km)</th>
                    <th>Latitude</th>
                    <th>Longitude</th>

                    <!-- New columns from area_valuation -->
                    <th>Final Plot Sqft</th>
                    <th>Final Construction Sqft</th>
                    <th>Final Area Sqft</th>
                </tr>

                <?php if (!empty($results)): ?>
                    <?php foreach ($results as $row): ?>
                        <tr>
                            <td><?= htmlspecialchars($row['reference_id']) ?></td>
                            <td><?= htmlspecialchars($row['customerName']) ?></td>
                            <td><?= htmlspecialchars($row['address']) ?></td>
                            <td><?= htmlspecialchars($row['customerMob']) ?></td>
                            <td><?= htmlspecialchars($row['visitType']) ?></td>
                            <td><?= htmlspecialchars($row['party_name']) ?></td>
                            <td><?= htmlspecialchars($row['branchname']) ?></td>
                            <td><?= htmlspecialchars($row['caseType']) ?></td>
                            <td><?= htmlspecialchars($row['applicationNo']) ?></td>
                            <td><?= htmlspecialchars($row['initiatorMailId']) ?></td>
                            <td><?= htmlspecialchars($row['initiationDate']) ?></td>

                            <!-- From address_details -->
                            <td><?= htmlspecialchars($row['address_per_site']) ?></td>
                            <td><?= htmlspecialchars($row['nearest_branch_location']) ?></td>
                            <td><?= htmlspecialchars($row['distance_from_branch_kms']) ?></td>
                            <td><?= htmlspecialchars($row['latitude_value']) ?></td>
                            <td><?= htmlspecialchars($row['longitude_value']) ?></td>

                            <!-- From area_valuation -->
                            <td><?= htmlspecialchars($row['final_plot_square_feet']) ?></td>
                            <td><?= htmlspecialchars($row['final_construction_square_feet']) ?></td>
                            <td><?= htmlspecialchars($row['final_area_square_feet']) ?></td>
                        </tr>
                    <?php endforeach; ?>
                <?php else: ?>
                    <tr>
                        <td colspan="19" style="text-align: center;">No data Found</td>
                    </tr>
                <?php endif; ?>
            </table>
        </div>
    </div>

    <script>
        const toggleBtn = document.getElementById("toggle-btn");
        const sidebar = document.getElementById("sidebar");

        toggleBtn.addEventListener("click", () => {
            sidebar.classList.toggle("visible");
        });

        function search() {
            window.location.href = "initiator.php";
        }
    </script>
</body>
</html>
