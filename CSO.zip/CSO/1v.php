<?php include('auth.php'); ?>
<?php
ini_set('display_errors', 1);
error_reporting(E_ALL);

// Increase PHP execution time and memory limit
ini_set('max_execution_time', 3000); // 300 seconds = 5 minutes
ini_set('memory_limit', '1024M'); // Increase memory limit to 512MB

// Start session

$servername = "localhost";
$username = "root";
$password = "";
$dbname = "project_db";

// Create DB connection
$conn = new mysqli($servername, $username, $password, $dbname);
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

if (!isset($_SESSION['reference_id'])) {
    die("Reference ID not found in session.");
}
$reference_id = $_SESSION['reference_id'];

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['download_images'])) {

    // Get customer name
    $stmt_name = $conn->prepare("SELECT customerName FROM mis WHERE reference_id = ?");
    $stmt_name->bind_param("s", $reference_id);
    $stmt_name->execute();
    $result_name = $stmt_name->get_result();
    $customerName = "customer";
    if ($row = $result_name->fetch_assoc()) {
        $customerName = preg_replace('/[^a-zA-Z0-9]/', '', $row['customerName']);
    }
    $stmt_name->close();

    // Fetch image BLOBs
    $stmt = $conn->prepare("SELECT image1, image2, image3, image4, image5, image6, image7, image8, image9, image10, image11, image12 FROM final_uploaded_images WHERE reference_id = ?");
    $stmt->bind_param("s", $reference_id);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows > 0 && ($row = $result->fetch_assoc())) {
        $tempDir = sys_get_temp_dir() . DIRECTORY_SEPARATOR . uniqid('images_', true);
        mkdir($tempDir);

        $imageFiles = [];
        for ($i = 1; $i <= 12; $i++) {
            if (!empty($row["image$i"])) {
                $filename = $tempDir . DIRECTORY_SEPARATOR . "image{$i}.jpg";
                file_put_contents($filename, $row["image$i"]);
                $imageFiles[] = $filename;
            }
        }

        if (empty($imageFiles)) {
            die("No images to download.");
        }

        // Create ZIP
        $zipFileName = "images_" . preg_replace('/[^a-zA-Z0-9]/', '_', $reference_id) . "_{$customerName}.zip";
        $zipPath = $tempDir . DIRECTORY_SEPARATOR . $zipFileName;

        $zip = new ZipArchive();
        if ($zip->open($zipPath, ZipArchive::CREATE) !== TRUE) {
            die("Failed to create ZIP file.");
        }

        foreach ($imageFiles as $file) {
            $zip->addFile($file, basename($file));
        }
        $zip->close();

        // Send ZIP to browser
        header('Content-Type: application/zip');
        header('Content-Disposition: attachment; filename="' . basename($zipFileName) . '"');
        header('Content-Length: ' . filesize($zipPath));
        flush();
        readfile($zipPath);

        // Cleanup
        foreach ($imageFiles as $file) {
            unlink($file);
        }
        unlink($zipPath);
        rmdir($tempDir);
        exit;
    } else {
        echo "<p style='color:red;'>No image data found for this reference ID.</p>";
    }
}



// Debugging: Output for verification 
echo "Session reference_id: " . htmlspecialchars($reference_id) . "<br>";


$page = isset($_GET['page']) ? $_GET['page'] : 1;
$limit = 50;
$offset = ($page - 1) * $limit;
$sql_property = "SELECT * FROM mis WHERE reference_id = ? LIMIT $limit OFFSET $offset";
$stmt_property = $conn->prepare($sql_property);
$stmt_property->bind_param("s", $reference_id);
$stmt_property->execute();
$result_property = $stmt_property->get_result();
$data1 = $result_property->fetch_assoc();




// Fetch data from property_details table
$sql_property = "SELECT * FROM property_details WHERE reference_id = ?";
$stmt_property = $conn->prepare($sql_property);
$stmt_property->bind_param("s", $reference_id);
$stmt_property->execute();
$result_property = $stmt_property->get_result();
$data2= $result_property->fetch_assoc();




// Fetch data from area_valuation table
$sql_area = "SELECT * FROM address_details WHERE reference_id = ?";
$stmt_area = $conn->prepare($sql_area); 
$stmt_area->bind_param("s", $reference_id);
$stmt_area->execute();
$result_area = $stmt_area->get_result();
$data3 = $result_area->fetch_assoc();





// Fetch data from area_valuation table
$sql_area = "SELECT * FROM critical_parameters WHERE reference_id = ?";
$stmt_area = $conn->prepare($sql_area); 
$stmt_area->bind_param("s", $reference_id);
$stmt_area->execute();
$result_area = $stmt_area->get_result();
$data4 = $result_area->fetch_assoc();

 
// Fetch data from area_valuation table
$sql_area = "SELECT * FROM surroundings_details WHERE reference_id = ?";
$stmt_area = $conn->prepare($sql_area); 
$stmt_area->bind_param("s", $reference_id);
$stmt_area->execute();
$result_area = $stmt_area->get_result();
$data5 = $result_area->fetch_assoc();
$stmt_area->close();
 
// Fetch data from area_valuation table
$sql_area = "SELECT * FROM area_valuation WHERE reference_id = ?";
$stmt_area = $conn->prepare($sql_area); 
$stmt_area->bind_param("s", $reference_id);
$stmt_area->execute();
$result_area = $stmt_area->get_result();
$data6 = $result_area->fetch_assoc();
$stmt_area->close();
 



// Fetch data from area_valuation table
$sql_area = "SELECT * FROM floor_details WHERE reference_id = ?";
$stmt_area = $conn->prepare($sql_area); 
$stmt_area->bind_param("s", $reference_id);
$stmt_area->execute();
$result_area = $stmt_area->get_result();
$data8= $result_area->fetch_assoc();
$stmt_area->close();
 


// Fetch data from area_valuation table
$sql_area = "SELECT * FROM technical_details WHERE reference_id = ?";
$stmt_area = $conn->prepare($sql_area); 
$stmt_area->bind_param("s", $reference_id);
$stmt_area->execute();
$result_area = $stmt_area->get_result();
$data9 = $result_area->fetch_assoc();
$stmt_area->close();
 
// Fetch data from area_valuation table
$sql_area = "SELECT * FROM remarks_table WHERE reference_id = ?";
$stmt_area = $conn->prepare($sql_area); 
$stmt_area->bind_param("s", $reference_id);
$stmt_area->execute();
$result_area = $stmt_area->get_result();
$data10 = $result_area->fetch_assoc();
$stmt_area->close();


// Step 1: Fetch the engineer_id from the mis table
$sql_mis = "SELECT engineer_id FROM mis WHERE reference_id = ?";
$stmt_mis = $conn->prepare($sql_mis);
$stmt_mis->bind_param("s", $reference_id);
$stmt_mis->execute();
$result_mis = $stmt_mis->get_result();
$row_mis = $result_mis->fetch_assoc();
$stmt_mis->close(); 

if ($row_mis) {
    $engineer_id = $row_mis['engineer_id'];

    // Step 2: Fetch the engineer's name from engineer_login table
    $sql_engineer = "SELECT name FROM engineer_login WHERE engineer_id = ?";
    $stmt_engineer = $conn->prepare($sql_engineer);
    $stmt_engineer->bind_param("s", $engineer_id);
    $stmt_engineer->execute();
    $result_engineer = $stmt_engineer->get_result();
    $row_engineer = $result_engineer->fetch_assoc();
    $stmt_engineer->close();

    if ($row_engineer) {
        $engineer_name = $row_engineer['name'];
         //echo "Engineer Name: " . $engineer_name;
    } else {
        echo "Engineer not found.";
    }
} else {
    echo "No engineer assigned for this reference_id.";
}



// Step 1: Fetch the engineer_id from the mis table
$sql_mis = "SELECT report_id FROM mis WHERE reference_id = ?";
$stmt_mis = $conn->prepare($sql_mis);
$stmt_mis->bind_param("s", $reference_id);
$stmt_mis->execute();
$result_mis = $stmt_mis->get_result();
$row_mis = $result_mis->fetch_assoc();
$stmt_mis->close(); 

if ($row_mis) {
    $report_id = $row_mis['report_id'];

    // Step 2: Fetch the engineer's name from engineer_login table
    $sql_engineer = "SELECT name FROM report_login WHERE report_id = ?";
    $stmt_engineer = $conn->prepare($sql_engineer);
    $stmt_engineer->bind_param("s", $report_id);
    $stmt_engineer->execute();
    $result_engineer = $stmt_engineer->get_result();
    $row_engineer = $result_engineer->fetch_assoc();
    $stmt_engineer->close();

    if ($row_engineer) {
        $report_name = $row_engineer['name'];
         //echo "Engineer Name: " . $report_name;
    } else {
        echo "Engineer not found.";
    }
} else {
    echo "No engineer assigned for this reference_id.";
}


// Step 1: Fetch the engineer_id from the mis table
$sql_mis = "SELECT report_drafter_to_technical FROM mis WHERE reference_id = ?";
$stmt_mis = $conn->prepare($sql_mis);
$stmt_mis->bind_param("s", $reference_id);
$stmt_mis->execute();
$result_mis = $stmt_mis->get_result();
$row_mis = $result_mis->fetch_assoc();
$stmt_mis->close(); 

if ($row_mis) {
    $report_drafter_to_technical = $row_mis['report_drafter_to_technical'];

    // Step 2: Fetch the engineer's name from engineer_login table
    $sql_engineer = "SELECT name FROM technical_login WHERE technical_manager_id = ?";
    $stmt_engineer = $conn->prepare($sql_engineer);
    $stmt_engineer->bind_param("s", $report_drafter_to_technical);
    $stmt_engineer->execute();
    $result_engineer = $stmt_engineer->get_result();
    $row_engineer = $result_engineer->fetch_assoc();
    $stmt_engineer->close();

    if ($row_engineer) {
        $technical_name = $row_engineer['name'];
        //echo "Engineer Name: " . $technical_name;
    } else {
        echo "Engineer not found.";
    }
} else {
    echo "No engineer assigned for this reference_id.";
}


?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>JMFHL Technical Appraisal Report</title>
    <link rel="shortcut icon" href="favicon.png" type="image/x-icon"> 
    <link rel="stylesheet" href="jmfhl1.css">
</head>
<body>
<div class="content">
    <header>
      <div class="logo">
        <img src="logo.png" alt="Magpie Logo">
      </div>
      <div class="header-content">
        <h1>MAGPIE ENGINEERING PVT. LTD.</h1>
        <p>Valuer Designer Architects</p>
        <p>Office: 208, Sunrise Tower, 579, M.G. Road, Indore (M.P.)</p>
      </div>
    </header>
    <div class="container">
        <div class="header">
            <div>Date: <input type="text" name="initiationDate"  value="<?= $data1['initiationDate'] ?? '' ?>"></div>
            <div>Report Reference No.<input type="text"value="<?= $data1['reference_id'] ?? '' ?>"></div>
        </div>

        <div class="title">JMFHL TECHNICAL APPRAISAL REPORT</div>
        <h3>LOAN APPLICATION DETAILS</h3>
        <table>
            <tr>
                <th>JMFHL BRANCH NAME</th>
                <td><input type="date" name="initiationDate" value="<?=  $data1['branchname'] ?? '' ?>"></td>
                <th>APPLICATION NO</th>
                <td><input type="text" name="engineer_id"  value="<?= $data1['applicationNo'] ?? '' ?>"></td>
                <th>CUSTOMER NO</th>
                <td><input type="text" name="customerName" value="<?= $data1['customerMob'] ?? '' ?>"></td>
            </tr>
            <tr>
                <th id="change">NAME OF APPLICANT(S)</th>
                <td colspan="3"><input type="text" name="customerName" value="<?= $data1['customerName'] ?? '' ?>"></td>
                <th>PRODUCT</th>
                <td><input type="text" value="<?= $data1['caseType'] ?? '' ?>"></td>
            </tr>
            <tr>
                <th>NAME & NUMBER OF CONTACT PERSON FOR PROPERTY VISIT</th>
                <td colspan="3"><input type="text" name="engineer_id"  value="<?= $data2['person_meet_at_site_contact'] ?? '' ?>"></td>
                <th id="change">TRANSACTION TYPE</th>
                <td><input type="text" name="caseType"  value="<?= $data1['caseType'] ?? '' ?>" ></td>
            </tr>
        </table>

        <h2>APF DETAILS (IF APPLICABLE)</h2>
        <table>
            <tr>
                <th>PROJECT APPROVAL STATUS</th>
                <td><input type="text" name="engineer_id"  value="<?= $data2['project_approval_status'] ?? '' ?>"></td>
                <th>PROJECT ID</th>
                <td><input type="text" name="engineer_id"  value="<?= $data2['project_id'] ?? '' ?>"></td>
                <th>PROJECT NAME</th>
                <td><input type="text" name="engineer_id"  value="<?= $data2['project_name'] ?? '' ?>"></td>
            </tr>
            <tr>
                <th id="change">BUILDING NAME & NO</th>
                <td><input type="text" name="engineer_id"  value="<?= $data3['address_line_1_as_per_doc'] ?? '' ?>"></td>
                <th id="change">WING NAME & NO</th>
                <td><input type="text" name="engineer_id"  value="<?= $data3['address_line_2_as_per_doc'] ?? '' ?>"></td>
                <th id="change">HOUSE/FLAT/UNIT NO</th>
                <td><input type="text" name="engineer_id"  value="<?= $data3['address_line_3_as_per_doc'] ?? '' ?>"></td>
               
            </tr>
            <tr>
                <th>BUILDER GROUP NAME</th>
                <td colspan="2"><input type="text" name="engineer_id"  value="<?=$data2['builder_group_name'] ?? '' ?>"></td>
                <th>COMPANY NAME FOR PROJECT</th>
                <td colspan="2"><input type="text" name="engineer_id"  value="<?= $data2['project_name'] ?? '' ?>"></td>
            </tr>
            <tr>
                <th id="change">REMARKS ON REPUTATION OF BUILDER AND PROJECT</th>
                <td colspan="5"><input type="text" name="engineer_id"  value="<?= $data2['builder_group_name'] ?? '' ?>  <?= $data2['project_name'] ?? '' ?>"></td>
            </tr>
        </table>

        <h2>RERA DETAILS (IF APPLICABLE)</h2>
        <table>
            <tr>
                <th>RERA APPLICABLE</th>
                <td><input type="text" name="engineer_id" value="<?= $data10['NA'] ?? '' ?>"></td>
                <th>IF APPLICABLE,RERA REGISTRATION STATUS</th>
                <td><input type="text" name="engineer_id" value="<?= $data10['NA'] ?? '' ?>"></td>
                <th>RERA REGISTRATION NO</th>
                <td><input type="text" name="engineer_id" value="<?= $data10['NA'] ?? '' ?>"></td>
            </tr>
            <tr>
                <th id="change">IF ANY LITIGATION RECORD ON PROJECT AS PER RERA</th>
                <td><input type="text" name="engineer_id" value="<?= $data10['NA'] ?? '' ?>"></td>
                <th id="change">REMARKS</th>
                <td colspan="3"><input type="text" name="engineer_id" value="<?= $data10['NA'] ?? '' ?>"></td>
            </tr>
        </table>

        <h2>ADDRESS DETAILS AS PER PROPERTY VISIT</h2>
        <table>
            <tr>
                <th>ENTER DETAILED ADDRESS IN BELOW FORM AS PER PROPERTY VISIT</th>
                <td  colspan="5" id="change"><input type="text"id="change"  value="<?= $data3['address_per_site'] ?? '' ?>"></td>
            </tr>
            </table>
            <h2>(PLEASE ENTER "NA" IN CASE FIELD DETAILS ARE NOT AVAILABLE/APPLICABLE IN ADDRESS FORM BELOW)</h2>
        <table>
            <tr>
                <th>HOUSE/FLAT NO</th>
                <td><input type="text" name="engineer_id"  value="<?= $data3['address_line_1_as_per_doc'] ?? '' ?>"></td>
                <th>FLOOR NO</th>
                <td><input type="text" name="engineer_id"  value="<?= $data3['address_line_2_as_per_doc'] ?? '' ?>"></td>
                <th>WING NAME & NO</th>
                <td><input type="text" name="engineer_id"  value="<?= $data10['NA'] ?? '' ?>"></td>
            </tr>
            <tr>
                <th id="change">BUILDING NAME & NO</th>
                <td><input type="text" name="engineer_id"  value="<?= $data2['infra_building'] ?? '' ?>"></td>
                <th id="change">PROJECT NAME/SOCIETY NAME</th>
                <td><input type="text" name="engineer_id"  value="<?= $data2['project_name'] ?? '' ?>"></td>
                <th id="change">PLOT NO</th>
                <td><input type="text" name="engineer_id"  value="<?= $data10['NA'] ?? '' ?>"></td>
            </tr>
            <tr>
                <th>SURVEY NO.</th>
                <td><input type="text" name="engineer_id"  value="<?= $data10['NA'] ?? '' ?>"></td>
                <th> STAGE/SECTOR/WARD NO.</th>
                <td><input type="text" name="engineer_id"  value="<?= $data10['NA'] ?? '' ?>"></td>
                <th>STREET NAME &/NO.</th>
                <td><input type="text" name="engineer_id"  value="<?= $data10['NA'] ?? '' ?>"></td>
            </tr>
            <tr>
                <th id="change">VILLAGE/LOCATION</th>
                <td><input type="text" name="engineer_id"  value="<?=$data10['NA'] ?? '' ?>"></td>
                <th id="change">LANDMARK 1</th>
                <td><input type="text" name="engineer_id"  value="<?= $data3['landmark_1'] ?? '' ?>"></td>
                <th id="change">LANDMARK 2</th>
                <td><input type="text" name="engineer_id"  value="<?= $data3['landmark_2'] ?? '' ?>"></td>
            </tr>
            <tr>
                <th>PIN CODE</th>
                <td><input type="text" name="engineer_id"  value="<?= $data3['pin_code'] ?? '' ?>"></td>
                <th>PIN CODE AREA </th>
                <td><input type="text" name="engineer_id"  value="<?= $data10['NA'] ?? '' ?>"></td>
                <th>CITY/TALUKA/TOWN</th>
                <td><input type="text" name="engineer_id"  value="<?=$data3['pin_code'] ?? '' ?>"></td>
            </tr>
            <tr>
                <th id="change">DISTRICT</th>
                <td><input type="text" name="engineer_id"  value="<?=$data10['NA'] ?? '' ?>"></td>
                <th id="change">LATITUDE VALUE</th>
                <td><input type="text" name="engineer_id"  value="<?= $data3['latitude_value'] ?? '' ?>"></td>
                <th id="change">LONGITUDE VALUE</th>
                <td><input type="text" name="engineer_id"  value="<?= $data3['longitude_value'] ?? '' ?>"></td>
            </tr> 
             <tr>
                <th>STATE</th>
                <td><input type="text" name="engineer_id"  value="<?=$data10['NA'] ?? '' ?>"></td>
                <th>NEAREST JMFHL LOCATION</th>
                <td><input type="text" name="engineer_id"  value="<?= $data3['nearest_branch_location'] ?? '' ?>"></td>
                <th>DISTANCE FROM JMFHL LOCATION(KMS)</th>
                <td><input type="text" name="engineer_id"  value="<?= $data3['distance_from_branch_kms'] ?? '' ?>"></td>
            </tr>
        </table>
        <h2>ADDRESS DETAILS AS PER LEGAL DOCUMENTS</h2>
        <table>
            <tr>
                <th id="change">ADDRESS AS PER DOC</th>
                <td colspan="5"><input type="text" name="engineer_id" value="<?= $data3['address_line_1_as_per_doc'] ?? '' ?>  <?= $data3['address_line_2_as_per_doc'] ?? '' ?>  <?= $data3['address_line_3_as_per_doc'] ?? '' ?>  <?= $data3['address_line_4_as_per_doc'] ?? '' ?>"></td>
            </tr>
            <tr>
                <th>ADDRESS AS ACTUAL ON SITE</th>
                
                <td colspan="5"><input type="text" name="engineer_id"  value="<?= $data3['address_per_site'] ?? '' ?>"></td>
            </tr>
            <tr>
                <th>LEGAL DOCUMENT(S) VERIFIED FOR ADDRESS</th>
                <td colspan="5"><input type="text" name="engineer_id" value="<?= $data1['document_provided_for_valuation'] ?? '' ?>"></td>
            </tr>
        </table>

        <h2>BOUNDARIES</h2>
        <table>
            <tr>
                <th> DIRECTIONS</th>
                <th>NORTH</th>
                <th>SOUTH</th>
                <th>EAST</th>
                <th>WEST</th>
            </tr>
            <tr>
                <th id="change">AS PER APPROVED PLAN</th>
                <td><input type="text" name="engineer_id" value="<?= $data3['direction_approved_north'] ?? '' ?>"></td>
                <td><input type="text" name="engineer_id" value="<?= $data3['direction_approved_south'] ?? '' ?>"></td>
                <td><input type="text" name="engineer_id" value="<?= $data3['direction_approved_east'] ?? '' ?>"></td>
                <td><input type="text" name="engineer_id" value="<?= $data3['direction_approved_west'] ?? '' ?>"></td>
            </tr>
            <tr>
                <th>AS PER SITE</th>
                <td><input type="text" name="engineer_id" value="<?= $data3['direction_as_per_site_north'] ?? '' ?>"></td>
                <td><input type="text" name="engineer_id" value="<?= $data3['direction_as_per_site_south'] ?? '' ?>"></td>
                <td><input type="text" name="engineer_id" value="<?= $data3['direction_as_per_site_east'] ?? '' ?>"></td>
                <td><input type="text" name="engineer_id" value="<?= $data3['direction_as_per_site_west'] ?? '' ?>"></td>
            </tr>
            <tr>
                <th id="change">AS PER LEGAL DOCUMENTS</th>
                <td><input type="text" name="engineer_id" value="<?= $data3['direction_as_per_document_north'] ?? '' ?>"></td>
                <td><input type="text" name="engineer_id" value="<?= $data3['direction_as_per_document_south'] ?? '' ?>"></td>
                <td><input type="text" name="engineer_id" value="<?= $data3['direction_as_per_document_east'] ?? '' ?>"></td>
                <td><input type="text" name="engineer_id" value="<?= $data3['direction_as_per_document_west'] ?? '' ?>"></td>
            </tr>
        </table>

        <h2>SET BACK/MARGIN DETAILS</h2>
        <table>
            <tr>
                <th></th>
                <th>FRONT SIDE</th>
                <th>REAR SIDE</th>
                <th>RIGHT SIDE</th>
                <th>LEFT SIDE</th>
            </tr>
            <tr>
                <th id="change">AS PER APPROVED PLAN</th>
                <td><input type="text" name="engineer_id" value="<?= $data10['NA'] ?? '' ?>"></td>
                <td><input type="text" name="engineer_id" value="<?= $data10['NA'] ?? '' ?>"></td>
                <td><input type="text" name="engineer_id" value="<?= $data10['NA'] ?? '' ?>"></td>
                <td><input type="text" name="engineer_id" value="<?= $data10['NA'] ?? '' ?>"></td>
            </tr>
            <tr>
                <th>AS PER SITE</th>
                <td><input type="text" name="engineer_id" value="<?= $data10['NA'] ?? '' ?>"></td>
                <td><input type="text" name="engineer_id" value="<?= $data10['NA'] ?? '' ?>"></td>
                <td><input type="text" name="engineer_id" value="<?= $data10['NA'] ?? '' ?>"></td>
                <td><input type="text" name="engineer_id" value="<?= $data10['NA'] ?? '' ?>"></td>
            </tr>
        </table>
        <h2>GENERAL DETAILS</h2>
        <table>
            <tr>
                <th>MUNICIPAL LIMIT</th>
                <td><input type="text" name="engineer_id"  value="<?= $data10['NA'] ?? '' ?>"></td>
                <th>MUNICIPAL LIMIT(NAME)</th>
                <td><input type="text" name="engineer_id"  value="<?=$data10['NA'] ?? '' ?>"></td>
                <th>YEAR OF CONSTRUCTION</th>
                <td><input type="text" name="engineer_id"  value="<?= $data2['year_of_construction'] ?? '' ?>"></td>
            </tr>
            <tr>
                <th id="change">AGE OF PROPERTY(YEARS)</th>
                <td><input type="text" name="engineer_id"  value="<?= $data2['age_of_property'] ?? '' ?>"></td>
                <th id="change">RESIDUAL AGE OF PROPERTY(YEARS)</th>
                <td><input type="text" name="engineer_id"  value="<?= $data2['residual_age_of_property'] ?? '' ?>"></td>
                <th id="change">STRUCTURALLY FIT</th>
                <td><input type="text" name="engineer_id"  value="<?= $data2['structurally_fit'] ?? '' ?>"></td>
            </tr>
            <tr>
                <th>APPROACH ROAD TO PROPERTY</th>
                <td><input type="text" name="engineer_id"  value="<?= $data2['approach_road_to_property'] ?? '' ?>"></td>
                <th>TYPE OF APPROACH ROAD</th>
                <td><input type="text" name="engineer_id"  value="<?= $data2['type_of_approach_road'] ?? '' ?>"></td>
                <th>WIDTH OF APPROACH ROAD(MTRS)</th>
                <td><input type="text" name="engineer_id"  value="<?= $data2['width_of_approach_road'] ?? '' ?>"></td>
            </tr>
            <tr>
                <th id="change">CLASS OF LOCALITY</th>
                <td><input type="text" name="engineer_id"  value="<?= $data2['class_of_locality'] ?? '' ?>"></td>
                <th id="change">SURROUNDING INFRASTRUCTURE</th>
                <td><input type="text" name="engineer_id"  value="<?= $data2['surrounding_infrastructure'] ?? '' ?>"></td>
                <th id="change">PROPERTY/DWELLING UNIT TYPE</th>
                <td><input type="text" name="engineer_id"  value="<?= $data2['property_unit_type'] ?? '' ?>"></td>
            </tr>
            <tr>
                <th>OCCUPANCY STATUS</th>
                <td><input type="text" name="engineer_id"  value="<?= $data2['occupancy_status'] ?? '' ?>"></td>
                <th>PROPERTY FURNISHED/UNFURNISHED </th>
                <td><input type="text" name="engineer_id"  value="<?= $data2['property_furnished_unfurnished'] ?? '' ?>"></td>
                <th>OCCUPANT NAME</th>
                <td><input type="text" name="engineer_id"  value="<?= $data2['occupant_name'] ?? '' ?>"></td>
            </tr>
            <tr>
                <th>PERSON MET AT SITE AND CONTACT NO.</th>
                <td colspan="1"><input type="text" name="engineer_id"  value="<?= $data2['person_meet_at_site_contact'] ?? '' ?>"></td>
                <th id="change">SELLER NAME</th>
                <td colspan="1"><input type="text" name="engineer_id"  value="<?= $data9['seller_name'] ?? '' ?>"></td>
            </tr> 
             <tr>
                <th>WHETHER PROPERTY LEASEHOLD OR FREEHOLD</th>
                <td><input type="text" name="engineer_id"  value="<?= $data2['property_leasehold_freehold'] ?? '' ?>"></td>
                <th>IF LEASEHOLD,NAME OF THE LEASOR</th>
                <td><input type="text" name="engineer_id" value="<?=  $data10['NA'] ?? '' ?>"></td>
                <th>IF LEASEHOLD,END DATE & BALANCE TENURE OF LEASE</th>
                <td><input type="text" name="engineer_id" value="<?= $data10['NA'] ?? '' ?>"></td>
            </tr>
            <tr>
                <th id="change">TOTAL NO. OF UNITS IN APARTMENT/COLONY</th>
                <td><input type="text" name="engineer_id" value="<?= $data10['NA'] ?? '' ?>"></td>
                <th id="change">TOTAL NO OF UNITS OCCUPIED</th>
                <td colspan="4"><input type="text" name="engineer_id" value="<?= $data10['NA'] ?? '' ?>"></td>
            </tr> 
        </table>
        <h2>CRITICAL PARAMETERS</h2>
        <table>
            <tr>
                <th id="change">ZONING AS PER DEVELOPMENT PLAN</th>
                <td><input type="text" name="engineer_id"  value="<?= $data4['zoning_development_plan'] ?? '' ?>"></td>
                <th id="change">FALLING IN RESERVATION AS PER DEVELOPMENT PLAN</th>
                <td><input type="text" name="engineer_id"  value="<?= $data4['failing_in_reservation'] ?? '' ?>"></td>
                <th id="change">FALLING IN PRESENT OR PROPOSED ROAD WIDENING</th>
                <td><input type="text" name="engineer_id"  value="<?= $data4['failing_in_road_widening'] ?? '' ?>"></td>
            </tr>
            <tr>
                <th>PROPERTY WITHIN 30 MTRS FROM RAILWAY BOUNDARY </th>
                <td><input type="text" name="engineer_id"  value="<?= $data4['within_50_mtrs_railway'] ?? '' ?>"></td>
                <th>IF YES,APPROX DISTANCE FROM RAILWAY BOUNDARY (MTRS)</th>
                <td><input type="text" name="engineer_id" value="<?= $data3['distance_from_branch_kms'] ?? '' ?>"></td>
                <th>IF YES,DETAILS OF NOC AVAOLABLE FROM RAILWAY</th>
                <td><input type="text" name="engineer_id" value="<?= $data3['distance_from_branch_kms'] ?? '' ?>"></td>
            </tr>
            <tr>
                <th id="change" style="width:15%;">PROPERTY NEAR HIGH/LOW TENSION(HT)/(LT)LINES?</th>
                <td><input type="text" name="engineer_id"  value="<?= $data4['near_high_tension'] ?? '' ?>"></td>
                <th id="change" style="width:15%;">IF YES,APPROX VERTICAL DISTANCE FROM(HT)/(LT)LINES</th>
                <td><input type="text" name="engineer_id"  value="<?= $data4['vertical_distance_from_line'] ?? '' ?>"></td>
                <th id="change" style="width:15%;">IF YES,APPROX HORIZONTAL DISTANCE FROM(HT)/(LT)LINES</th>
                <td><input type="text" name="engineer_id" value="<?= $data3['distance_from_branch_kms'] ?? '' ?>"></td>
            </tr>
            <tr>
                <th>PRESENCE OF NALLAH/LAKE/WATER BODY NEARBY</th>
                <td><input type="text" name="engineer_id"  value="<?= $data4['vertical_distance_from_line'] ?? '' ?>"></td>
                <th>CURRENT PROPERTY USAGE</th>
                <td><input type="text" name="engineer_id"  value="<?= $data4['current_property_usage'] ?? '' ?>"></td>
                <th>APPROVED PROPERTY USAGE</th>
                <td><input type="text" name="engineer_id"  value="<?= $data4['approved_property_usage'] ?? '' ?>"></td>
            </tr>
            <tr>
                <th id="change">FSI DEVIATION</th>
                <td><input type="text" name="engineer_id"  value="<?= $data9['fsi_deviation'] ?? '' ?>"></td>
                <th id="change">VERTICAL DEVIATION</th>
                <td><input type="text" name="engineer_id"  value="<?= $data9['vertical_deviation'] ?? '' ?>"></td>
                <th id="change">REMARKS IF PROPERTY AFFECTED BY ANY OF CRITICAL PARAMETER</th>
                <td><input type="text" name="engineer_id"  value="<?= $data10['NA'] ?? '' ?>"></td>
            </tr>
            <tr>
                <th>HABITATION % WITHIN 1 KM AROUND PROPERTY</th>
                <td><input type="text" name="engineer_id"  value="<?= $data4['comment_on_location_risk'] ?? '' ?>"></td>
                <th>COMMENT ON LOCATION RISK IF HABITATION IS LESS THAN 40% WITHIN 1 KM</th>
                <td><input type="text" name="engineer_id"  value="<?= $data4['comment_on_location_risk'] ?? '' ?>"></td>
                <th>PROPERTY CONFIGURATION i.e.1 RK/1 BHK,SHOP,GODOWN,OFFICE,ETC.</th>
                <td><input type="text" name="engineer_id"  value="<?= $data8['configuration_building'] ?? '' ?>"></td>
            </tr>
            <tr>
                <th id="change">PROPERTY ABUTTING AGRICULTURAL LAND?</th>
                <td><input type="text" name="engineer_id"  value="<?= $data4['abutting_agriculture_land'] ?? '' ?>"></td>
                <th id="change">IF YES,RATE(PSF)OF THE AGRICULTURAL LAND</th>
                <td><input type="text" name="engineer_id"  value="<?= $data10['NA'] ?? '' ?>"></td>
                <th id="change">PERCENTAGE OF SURROUNDING DEVELOPMENT CONSIDERING CONNECTIVITY,BASIC AMENITIES,CONSTRUCTION ACTIVITY & OCCUPANCY</th>
                <td><input type="text" name="engineer_id"  value="<?= $data2['develop_percent'] ?? '' ?>"></td>
            </tr>
         </table>
         <h2>NDMC PARAMETERS</h2>
        <table>
            <tr>
                <th id="change">SEISMIC ZONE</th>
                <td><input type="text" name="engineer_id"  value="<?= $data4['seismic_zone'] ?? '' ?>"></td>
                <th>FLOOD PRONE AREA</th>
                <td><input type="text" name="engineer_id"  value="<?=$data10['NA']?? '' ?>"></td>
                <th id="change">COSTAL REGULATORY ZONE </th>
                <td><input type="text" name="engineer_id"  value="<?= $data4['costal_regulatory_zone'] ?? '' ?>"></td>
            </tr>
            <tr>
                <th id="change">NATURE OF BUILDING /WING</th>
                <td><input type="text" name="engineer_id"  value="<?=$data10['NA'] ?? '' ?>"></td>
                <th>STRUCTURE TYPE</th>
                <td><input type="text" name="engineer_id"  value="<?= $data4['structure_type'] ?? '' ?>"></td>
                <th id="change">FOOTING TYPE</th>
                <td><input type="text" name="engineer_id"  value="<?= $data10['NA'] ?? '' ?>"></td>
            </tr>  <tr>
                <th id="change">SHAPE OF BUILDING</th>
                <td><input type="text" name="engineer_id"  value="<?= $data10['NA'] ?? '' ?>"></td>
                <th>MORTAR TYPE</th>
                <td><input type="text" name="engineer_id"  value="<?=$data10['NA']?? '' ?>"></td>
                <th id="change">ROOF TYPE</th>
                <td><input type="text" name="engineer_id"  value="<?= $data4['roof_type'] ?? '' ?>"></td>
            </tr>  <tr>
                <th id="change">FIRE EXIT AVAILABLE </th>
                <td><input type="text" name="engineer_id"  value="<?=$data10['NA'] ?? '' ?>"></td>
                <th>CONCRETE GRADE</th>
                <td><input type="text" name="engineer_id"  value="<?= $data10['NA'] ?? '' ?>"></td>
                <th id="change">FLOOD PRONE AREA</th>
                <td><input type="text" name="engineer_id"  value="<?= $data10['NA'] ?? '' ?>"></td>
            </tr>  <tr>
                <th id="change">STEEL GRADE</th>
                <td><input type="text" name="engineer_id"  value="<?=$data10['NA'] ?? '' ?>"></td>
                <th>EXPANSION JOINT AVAILABLE</th>
                <td><input type="text" name="engineer_id"  value="<?=$data10['NA']?? '' ?>"></td>
                <th id="change">PROJECTED PARTS AVAILABLE</th>
                <td><input type="text" name="engineer_id"  value="<?=$data10['NA'] ?? '' ?>"></td>
            </tr>  <tr>
                <th id="change">GROUND SLOP MORE THAN 20%</th>
                <td><input type="text" name="engineer_id"  value="<?=$data10['NA'] ?? '' ?>"></td>
                <th>STRUCTURAL SYSTEM</th>
                <td><input type="text" name="engineer_id"  value="<?= $data10['NA']?? '' ?>"></td>
                <th id="change">SOIL TYPE</th>
                <td><input type="text" name="engineer_id"  value="<?=$data10['NA'] ?? '' ?>"></td>
            </tr>  <tr>
                <th id="change">SOIL LIQUEFIABLE</th>
                <td><input type="text" name="engineer_id"  value="<?=$data10['NA']?? '' ?>"></td>
                <th>ENVIRONMENT EXPOSURE CONDITION</th>
                <td><input type="text" name="engineer_id"  value="<?= $data10['NA'] ?? '' ?>"></td>
                <th id="change">PLAN ASPECT RATIO</th>
                <td><input type="text" name="engineer_id"  value="<?=$data10['NA']?? '' ?>"></td>
            </tr>  <tr>
                <th id="change">SOIL SLOP VULNERABLE TO LIQUEFIABLE </th>
                <td><input type="text" name="engineer_id"  value="<?=$data10['NA']?? '' ?>"></td>
                <th>CYCLONE ZONE-WIND SPEED</th>
                <td><input type="text" name="engineer_id"  value="<?= $data10['NA'] ?? '' ?>"></td>
                <th id="change">SOIL STRATA</th>
                <td><input type="text" name="engineer_id"  value="<?= $data10['NA'] ?? '' ?>"></td>
            </tr>
            </table>
          <h2>SURROUNDING EXTERNAL AMENITIES</h2>
          <table>
            <tr>
                <th>PREMISES LIST</th>
                <th>APPROX. DISTANCE FROM PROPERTY (IN KMS)</th>
                <th>NAME OF THE PREMISES</th>
                <th>SPECIFICATION LIST</th>
                <th>DETAILS - CONDITION & AVAILABILITY</th>
            </tr>
            <tr>
                <th id="change">NEAREST BUS STOP</th>
                <td><input type="text" name="engineer_id"  value="<?= $data3['nearest_bus_stop_distance'] ?? '' ?>"></td>
                <td><input type="text" name="engineer_id"  value="<?= $data3['nearest_bus_stop_name'] ?? '' ?>"></td>
                <th id="change">STRUCTURAL ELEMENTS</th>
                <td><input type="text" name="engineer_id"  value="<?= $data10['NA'] ?? '' ?>"></td>
            </tr>
            <tr>
                <th>NEAREST RAILWAY STN</th>
                <td><input type="text" name="engineer_id"  value="<?= $data3['nearest_railway_station_distance'] ?? '' ?>"></td>
                <td><input type="text" name="engineer_id"  value="<?= $data3['nearest_railway_station_name'] ?? '' ?>"></td>
               <th>WALL THICKNESS</th>
                <td><input type="text" name="engineer_id"  value="<?= $data10['NA']?? '' ?>"></td>
            </tr>
            <tr>
                <th id="change">NEAREST AIRPORT</th>
                <td><input type="text" name="engineer_id"  value="<?=$data10['NA'] ?? '' ?>"></td>
                <td><input type="text" name="engineer_id"  value="<?= $data10['NA'] ?? '' ?>"></td>
                <th id="change">PLASTER & PAINTING</th>
                <td><input type="text" name="engineer_id"  value="<?= $data10['NA'] ?? '' ?>"></td>
            </tr>
            <tr>
                <th>NEAREST SCHOOL/COLLEGE</th>
                <td><input type="text" name="engineer_id"  value="<?= $data3['nearest_school_college_distance'] ?? '' ?>"></td>
                <td><input type="text" name="engineer_id"  value="<?=$data10['NA'] ?? '' ?>"></td>
                <th>ELECTRIFICATION</th>
                <td><input type="text" name="engineer_id"  value="<?= $data10['NA'] ?? '' ?>"></td>
            </tr>
            <tr>
                <th id="change">NEAREST BANK</th>
                <td><input type="text" name="engineer_id"  value="<?= $data10['NA'] ?? '' ?>"></td>
                <td><input type="text" name="engineer_id"  value="<?=$data10['NA'] ?? '' ?>"></td>
                 <th id="change">PLUMBING & BATH FITTINGS</th> 
                <td><input type="text" name="engineer_id"  value="<?= $data10['NA']?? '' ?>"></td>
            </tr>
            <tr>
                <th>NEAREST HIGHWAY/MAJOR ROAD</th>
                <td><input type="text" name="engineer_id"  value="<?= $data10['NA'] ?? '' ?>"></td>
                <td><input type="text" name="engineer_id"  value="<?=$data10['NA'] ?? '' ?>"></td>
                <th>DOOR,WINDOWS</th>
                <td><input type="text" name="engineer_id"  value="<?= $data8['door_window_paint_present_completion']?? '' ?>"></td>
            </tr>
            <tr>
                <th id="change">NEAREST HOSPITAL</th>
                <td><input type="text" name="engineer_id"  value="<?= $data3['nearest_hospital_distance'] ?? '' ?>"></td>
                <td><input type="text" name="engineer_id"  value="<?=$data10['NA'] ?? '' ?>"></td>
                <th id="change">POTABLE WATER CONNECTION</th>
                <td><input type="text" name="engineer_id"  value="<?= $data10['NA']?? '' ?>"></td>
            </tr>
            <tr>
                <th>NEAREST MULTIPLEX/MALL/MARKET</th>
                <td><input type="text" name="engineer_id"  value="<?= $data10['NA']?? '' ?>"></td>
                <td><input type="text" name="engineer_id"  value="<?= $data10['NA']?? '' ?>"></td>
                <th>SEWERAGE SYSTEM</th>
                <td><input type="text" name="engineer_id"  value="<?=$data10['NA'] ?? '' ?>"></td>
            </tr>
        </table>
    <table>
        <tr>
            <h2>AREA & VALUATION DETAILS</h2>
            <h3>APPROVED AREA & VALUATION</h3>
        </tr>
        <tr>
            <th>Area Type</th>
            <th>Square Meter</th>
            <th>Square Feet</th>
            <th>Rate/Sq.Ft</th>
            <th>Valuation (Rs.)</th>
        </tr>
        <tr>
            <th id="change">Plot Area (i)</th>
            <td id="change">
    <input type="text" name="engineer_id"  
        value="<?= isset($data6['plot_square_feet']) ? round(floatval($data6['plot_square_feet']) * 0.092903, 2) : '' ?>">
</td>

            <td><input type="text" name="engineer_id"  value="<?= $data6['plot_square_feet'] ?? '' ?>"></td>
            <td><input type="text" name="engineer_id"  value="<?= $data6['plot_rate'] ?? '' ?>"></td>
            <td id="change"><input type="text" name="engineer_id"  value="<?= $data6['plot_valuation_computed'] ?? '' ?>"></td>
        </tr>
        <tr>
            <th>Carpet Area (ii)</th>
            <td>
    <input type="text" name="engineer_id"  
        value="<?= isset($data6['carpet_square_feet']) ? round(floatval($data6['carpet_square_feet']) * 0.092903, 2) : '' ?>">
</td>
  <td><input type="text" name="engineer_id"  value="<?= $data6['carpet_square_feet'] ?? '' ?>"></td>
            <td><input type="text" name="engineer_id"  value="<?= $data6['carpet_rate'] ?? '' ?>"></td>
            <td><input type="text" name="engineer_id"  value="<?= $data6['carpet_valuation_computed'] ?? '' ?>"></td>
        </tr>
        <tr>
            <th id="change">Construction / Built Up Area (iii)</th>
            <td id="change">
    <input type="text" name="engineer_id"  
        value="<?= isset($data6['construction_square_feet']) ? round(floatval($data6['construction_square_feet']) * 0.092903, 2) : '' ?>">
</td>
  <td><input type="text" name="engineer_id"  value="<?= $data6['construction_square_feet'] ?? '' ?>"></td>
            <td><input type="text" name="engineer_id"  value="<?= $data6['construction_rate'] ?? '' ?>"></td>
            <td id="change"><input type="text" name="engineer_id"  value="<?= $data6['construction_valuation_computed'] ?? '' ?>"></td>
        </tr>
        <tr>
    <th>Saleable Area (iv)</th>
    <td>
    <input type="text" name="saleable_square_meter"  
        value="<?= isset($data6['saleable_square_feet']) ? round(floatval($data6['saleable_square_feet']) * 0.092903, 2) : '' ?>">
</td>
 <td><input type="text" name="saleable_square_feet"  
        value="<?= $data6['saleable_square_feet'] ?? '' ?>"></td>
    <td><input type="text" name="saleable_rate"  
        value="<?= $data6['saleable_rate'] ?? '' ?>"></td>
    <td><input type="text" name="saleable_valuation_computed"  
        value="<?= $data6['saleable_valuation_computed'] ?? '' ?>"></td>
</tr>
<tr>
    <th colspan="4" style="text-align:center;">APPROVED AREA VALUATION (A) (i + ii + iii + iv)</th>
    <td><input type="text" name="total_area_valuation"  
        value="<?= $data6['total_area_valuation'] ?? '' ?>"></td>
</tr> 
    <h3>ACTUAL AREA & VALUATION</h3>
    <tr>
        <th>Area Type</th>
        <th>Square Meter</th>
        <th>Square Feet</th>     
        <th>Rate/Sq.Ft</th>
        <th>Valuation (Rs.)</th>
    </tr>
    <tr>
        <th>Plot Area (i)</th>
        <td>
    <input type="text" name="actual_plot_square_meter"  
        value="<?= isset($data6['actual_plot_square_feet']) ? round(floatval($data6['actual_plot_square_feet']) * 0.092903, 2) : '' ?>">
</td>
<td><input type="text" name="actual_plot_square_feet"  
            value="<?= $data6['actual_plot_square_feet'] ?? '' ?>"></td>
        <td><input type="text" name="actual_plot_rate"  
            value="<?= $data6['actual_plot_rate'] ?? '' ?>"></td>
        <td><input type="text" name="actual_plot_valuation_computed"  
            value="<?= $data6['actual_plot_valuation_computed'] ?? '' ?>"></td>
    </tr>

        <tr>
            <th>Carpet Area (ii)</th>
            <td>
    <input type="text" name="engineer_id"  
        value="<?= isset($data6['actual_carpet_square_feet']) ? round(floatval($data6['actual_carpet_square_feet']) * 0.092903, 2) : '' ?>">
</td>
  <td><input type="text" name="engineer_id"  value="<?= $data6['actual_carpet_square_feet'] ?? '' ?>"></td>
            <td><input type="text" name="engineer_id"  value="<?= $data6['actual_carpet_rate'] ?? '' ?>"></td>
            <td><input type="text" name="engineer_id"  value="<?= $data6['actual_carpet_valuation_computed'] ?? '' ?>"></td>
        </tr>
        <tr>
            <th id="change">Construction / Built Up Area (iii)</th>
            <td id="change"><input type="text" name="engineer_id"  
            value="<?= isset($data6['actual_construction_square_feet']) ? round($data6['actual_construction_square_feet'] * 0.092903, 2) : '' ?>"></td>
            <td><input type="text" name="engineer_id"  value="<?= $data6['actual_construction_square_feet'] ?? '' ?>"></td>
            <td><input type="text" name="engineer_id"  value="<?= $data6['actual_construction_rate'] ?? '' ?>"></td>
            <td id="change"><input type="text" name="engineer_id"  value="<?= $data6['actual_construction_valuation_computed'] ?? '' ?>"></td>
        </tr>
        <tr>
            <th>Saleable Area (iv)</th>
            <td>
    <input type="text" name="engineer_id"  
        value="<?= isset($data6['actual_saleable_square_feet']) ? round(floatval($data6['actual_saleable_square_feet']) * 0.092903, 2) : '' ?>">
</td>
 <td><input type="text" name="engineer_id"  value="<?= $data6['actual_saleable_square_feet'] ?? '' ?>"></td>
            <td><input type="text" name="engineer_id"  value="<?= $data6['actual_saleable_rate'] ?? '' ?>"></td>
            <td><input type="text" name="engineer_id"  value="<?= $data6['actual_saleable_valuation_computed'] ?? '' ?>"></td>
        </tr>
        <tr>
        <th id="change" colspan="4" style="text-align:center;">ACTUAL AREA VALUATION(B)(i + ii + iii + iv)</th>
            <td id="change"><input type="text" name="engineer_id"  value="<?= $data6['total_actual_area_valuation'] ?? '' ?>"></td>
        </tr>
        </table>
        <table>
            <tr class="header-row">
                <th colspan="2" style="text-align:center;">DETAILS OF REFERENCE INSTANCE FOR VALUATIONS</th>
                <th colspan="2" style="text-align:center;">REMARKS ON APPROVED/ACTUAL AREA & VALUATION</th>
            </tr>
            <tr>
                <td colspan="2"><input type="text" name="engineer_id"  value="<?=$data10['NA'] ?? '' ?>"></td>
                <td colspan="2"><input type="text" name="engineer_id"  value="<?= $data6['enquiry_remarks'] ?? '' ?>"></td>
            </tr>
        </table>

        <table>
                <h2>EXTENSION / IMPROVEMENT COST</h2>
            </tr>
            <tr>
                <th>AREA TYPE</th>
                <th>SQUARE METER</th>
                <th>SQUARE FEET</th>
                <th>RATE/SQ.FT</th>
                <th>ESTIMATION (Rs.)</th>
            </tr>
            <tr>
                <td><input type="text" name="engineer_id" value="<?=$data10['NA'] ?? '' ?>"></td>
                <td><input type="text" name="engineer_id" value="<?=$data10['NA'] ?? '' ?>"></td>
                <td><input type="text" name="engineer_id" value="<?=$data10['NA'] ?? '' ?>"></td>
                <td><input type="text" name="engineer_id" value="<?= $data10['NA'] ?? '' ?>"></td>
                <td><input type="text" name="engineer_id" value="<?= $data10['NA']?? '' ?>"></td>
            </tr>
        </table>
         <table>
                    <h2>ADDITIONAL AMENITIES COST</h2>
                <tr>
                    <th>DJ.AMENITIES </th>
                    <th>DESCRIPTION</th>
                    <th>AREA/QUANTITY</th>
                    <th>UNIT</th>
                    <th>AMOUNT (Rs.)</th>
                </tr>
                   
                <tr>
                    <th id="change">1</th>
                    <td><input type="text" name="engineer_id"  value="<?= $data6['addition_amenities_description_1'] ?? '' ?>"></td>
                    <td><input type="text" name="engineer_id"  value="<?=$data10['NA'] ?? '' ?>"></td>
                    <td><input type="text" name="engineer_id"  value="<?= $data10['NA']?? '' ?>"></td>
                    <td><input type="text" name="engineer_id"  value="<?= $data6['addition_amenities_amount_1'] ?? '' ?>"></td>
                </tr>
                <tr>
                    <th>2</th>
                    <td><input type="text" name="engineer_id"  value="<?= $data6['addition_amenities_description_2'] ?? '' ?>"></td>
                    <td><input type="text" name="engineer_id"  value="<?= $data10['NA']?? '' ?>"></td>
                    <td><input type="text" name="engineer_id"  value="<?=$data10['NA'] ?? '' ?>"></td>
                    <td><input type="text" name="engineer_id"  value="<?= $data6['addition_amenities_amount_2'] ?? '' ?>"></td>
                </tr>
                <tr>
                    <th id="change">3</t>
                    <td><input type="text" name="engineer_id"  value="<?=$data6['addition_amenities_description_3']?? '' ?>"></td>
                    <td><input type="text" name="engineer_id"  value="<?=$data10['NA'] ?? '' ?>"></td>
                    <td><input type="text" name="engineer_id"  value="<?=$data10['NA'] ?? '' ?>"></td>
                    <td><input type="text" name="engineer_id"  value="<?=$data6[ 'addition_amenities_amount_3'] ?? '' ?>"></td>
                </tr>
                <tr>
                    <th>4</t>
                    <td><input type="text" name="engineer_id"  value="<?=$data6['addition_amenities_description_4'] ?? '' ?>"></td>
                    <td><input type="text" name="engineer_id"  value="<?=$data10['NA'] ?? '' ?>"></td>
                    <td><input type="text" name="engineer_id"  value="<?=$data10['NA'] ?? '' ?>"></td>
                    <td><input type="text" name="engineer_id"  value="<?=$data6['addition_amenities_amount_4'] ?? '' ?>"></td>
                </tr>
                <tr>
                    <th id="change">5</t>
                    <td><input type="text" name="engineer_id"  value="<?=$data10['NA'] ?? '' ?>"></td>
                    <td><input type="text" name="engineer_id"  value="<?=$data10['NA'] ?? '' ?>"></td>
                    <td><input type="text" name="engineer_id"  value="<?=$data10['NA'] ?? '' ?>"></td>
                    <td><input type="text" name="engineer_id"  value="<?=$data10['NA'] ?? '' ?>"></td>
                </tr>
                <tr>
                    <th>6</th>
                    <td><input type="text" name="engineer_id"  value="<?=$data10['NA'] ?? '' ?>"></td>
                    <td><input type="text" name="engineer_id"  value="<?=$data10['NA'] ?? '' ?>"></td>
                    <td><input type="text" name="engineer_id"  value="<?=$data10['NA'] ?? '' ?>"></td>
                    <td><input type="text" name="engineer_id"  value="<?=$data10['NA'] ?? '' ?>"></td>
                </tr>
                <tr>
                    <th colspan="4" style="text-align:center;"id="change">TOTAL AMENITIES COST (D)</th>
                    <td id="change"><input type="text" name="engineer_id" value="<?= $data6['amenities_total'] ?? '' ?>"></td>
                </tr>
        </table>
                    <h2>FINAL VALUATION RECOMMENDED</h2>
                    <table>
            <tr></tr>
                <th>A/B</th>
                <th>AREA VALUATION</th>
                <td colspan="2">ACTUAL AREA VALUATION (B)</td>
                <th colspan="2"><input type="text" name="engineer_id"  value="<?=$data6['total_finally_area_valuation']?? '' ?>"></th>
            </tr>
            <tr>
                <th id="change">C</th>
                <th id="change">EXTENSION/IMPROVEMENT ESTIMATE</th>
                <td colspan="4"><input type="text" name="engineer_id"  value="<?= $data10['NA']?? '' ?>"></td>
            </tr>
            <tr>
                <th>D</th>
                <th>AMENITIES COST</th>
                <th colspan="4"><input type="text" name="engineer_id"  value="<?=$data6['amenities_total']?? '' ?>"></th>
            </tr>
            <tr>
                <th colspan="2" id="change">TOTAL FAIR MARKET VALUATION OF THE PROPERTY (RS.)</th>
                <td colspan="2"><input type="text" name="engineer_id"  value="<?= $data6['total_finally_area_valuation'] ?? '' ?>"></td>
                <th id="change">DISTRESS VALUE (RS.)</th>
                <td><input type="text" name="engineer_id"  value="<?= $data6['total_distress_value'] ?? '' ?>"></td>
            </tr>
            <tr>
                <th colspan="6">TOTAL FAIR MARKET VALUATION OF THE PROPERTY (RS.) IN WORDS</th>
            </tr>
            <tr><

                <td colspan="6"><textarea name="engineer_id" ><?= $data6['total_valuation_words'] ?? '' ?></textarea></td>
            </tr>
            <tr>
                <th colspan="6" id="change">DISTRESS VALUE (RS.) IN WORDS</th>	
            </tr>
            <tr>
                <td colspan="6"><textarea name="engineer_id"> <?=  $data6['distress_value_words'] ?? '' ?></textarea></td>
            </tr>
    </table>
                    <h2>RENTAL & REPLACEMENT COST INFORMATION</h2>
            <table>
                <tr>
                    <th>GROSS MONTHLY RENTAL FOR SIMILAR PROPERTIES IN LOCALITY (RS.)</th>
                    <td><input type="text" name="engineer_id"  value="<?= $data6['gross_monthly_rental'] ?? '' ?>"></td>
                    <th>Government Guideline Rate Per Sq. Ft.</t>
                    <td><input type="text" name="engineer_id"  value="<?= $data6['guideline_rate'] ?? '' ?>"></td>
                    <th>Replacement Cost (Rs.)</th>
                    <td><input type="text" name="engineer_id"  value="<?= $data6['replacement_cost'] ?? '' ?>"></td>
                    </tr>
            </table>
                    <h2>FLOOR DETAILS</h2>
            <table>
                <tr>
                    <th></th>
                    <th>FLOORS</th>
                    <th>APPROVED</th>
                    <th>ACTUAL/PLANNED</th>
                    <th>REMARKS ON NO. OF FLOORS,NUMBER OF UNITS ON EACH FLOOR</th>
                </tr>
                <tr>
                    <th id="change">(A)</th>
                    <th id="change"> NO. OF BASEMENTS</th>
                    <td><input type="text" name="engineer_id"  value="<?= $data8['approved_basements'] ?? '' ?>"></td>
                    <td><input type="text" name="engineer_id"  value="<?= $data8['actual_basements'] ?? '' ?>"></td>
                    <td rowspan="5"><input type="text" name="engineer_id"  value="<?= $data8['basements_remarks'] ?? '' ?>  <?= $data8['ground_remarks'] ?? '' ?>   <?= $data8['podium_remarks'] ?? '' ?>   <?= $data8['upper_floors_remarks'] ?? '' ?>  <?= $data8['total_floor_remarks'] ?? '' ?>"></td>
                </tr>
                <tr>
                    <th>(B)</th>
                         <th>NO. OF UPPER FLOORS</th>
                         <td><input type="text" name="engineer_id"  value="<?= $data8['approved_ground'] ?? '' ?>"></td>
                         <td><input type="text" name="engineer_id"  value="<?= $data8['actual_ground'] ?? '' ?>"></td>
                </tr>
                <tr>
                    <th id="change">(C)</th>
                    <th id="change"> PODIUMS</th>
                    <td><input type="text" name="engineer_id"  value="<?= $data8['approved_podium'] ?? '' ?>"></td>
                    <td><input type="text" name="engineer_id"  value="<?= $data8['actual_podium'] ?? '' ?>"></td>
                </tr>
                <tr>
                    <th>(D)</th>
                    <th>NO. OF UPPER FLOOR(S)</th>
                    <td><input type="text" name="engineer_id"  value="<?= $data8['approved_upper_floors'] ?? '' ?>"></td>
                    <td><input type="text" name="engineer_id"  value="<?= $data8['actual_upper_floors'] ?? '' ?>"></td>
                </tr>
                <tr>
                    <th id="change">(E) =(A + B + C + D)</th>
                    <th id="change">TOTAL NO. OF FLOORS</th>
                    <td id="change"><input type="text" name="engineer_id"  value="<?= $data8['total_approved_floors'] ?? '' ?>"></td>
                    <td id="change"><input type="text" name="engineer_id"  value="<?= $data8['total_actual_floors'] ?? '' ?>"></td>
                </tr>
            </table>
                
                    <h2>PROPERTY CONSTRUCTION STAGE</h2>
            <table>
                <tr>
                    <th></th>
                    <th colspan="2">PROPERTY CONSTRUCTION STAGE</th>
                    <td><input type="text" name="engineer_id"  value="<?= $data10['NA'] ?? '' ?>"></td>
                    <td><input type="text" name="engineer_id" value="<?= $data10['NA'] ?? '' ?>"></td>
                    <td><input type="text" name="engineer_id" value="<?= $data10['NA'] ?? '' ?>"></td>
                    </tr>
                <tr>
                    <th id="change">SR. NO.</th>
                    <th id="change">ACTIVITY</th>
                    <th id="change">ALLOCATED % FOR ACTIVITY</th>
                    <th id="change">ACTIVITY COMPLETED TILL FLOOR</th>
                    <th id="change">PRESENT COMPLETION (%)</th>
                    <th id="change">IF BELOW PLINTH/GROUND LVL,MENTION % UPTO 19%</th>
                </tr>
                <tr>
                    <th>1</th>
                        <th>PLINTH</th>
                        <td><input type="text" name="engineer_id"  value="<?=  $data10['NA'] ?? '' ?>"></td>
                        <td><input type="text" name="engineer_id"  value="<?=  $data10['NA'] ?? '' ?>"></td>
                        <td><input type="text" name="engineer_id"  value="<?= $data8['plinth_present_completion'] ?? '' ?>"></td>
                        <td><input type="text" name="engineer_id"  value="<?=  $data10['NA'] ?? '' ?>"></td>

                </tr>
                <tr>
                    <th id="change">2</th>
                    <th id="change">R.C.C.ABOVE GROUND</th>
                    <td><input type="text" name="engineer_id"  value="<?=  $data10['NA'] ?? '' ?>"></td>
                    <td><input type="text" name="engineer_id"  value="<?=  $data10['NA'] ?? '' ?>"></td>

                    <td id="change"><input type="text" name="engineer_id"  value="<?= $data8['rcc_present_completion'] ?? '' ?>"></td>
                    <td><input type="text" name="engineer_id"  value="<?=  $data10['NA'] ?? '' ?>"></td>
                    </tr>
                <tr>
                    <th>3</th>
                    <th>BRICKWORK</th>
                    <td><input type="text" name="engineer_id"  value="<?=  $data10['NA'] ?? '' ?>"></td>
                    <td><input type="text" name="engineer_id"  value="<?=  $data10['NA'] ?? '' ?>"></td>

                    <td><input type="text" name="engineer_id"  value="<?= $data8['brickwork_present_completion'] ?? '' ?>"></td>
                </tr>
                <tr>
                    <th id="change">4</th>
                    <th id="change">INTERNAL PLASTER</th>
                    <td><input type="text" name="engineer_id"  value="<?=  $data10['NA'] ?? '' ?>"></td>
                    <td><input type="text" name="engineer_id"  value="<?=  $data10['NA'] ?? '' ?>"></td>

                    <td id="change"><input type="text" name="engineer_id"  value="<?= $data8['internal_plaster_present_completion'] ?? '' ?>"></td>
                    <td><input type="text" name="engineer_id"  value="<?=  $data10['NA'] ?? '' ?>"></td>

                </tr>
                <tr>
                    <th>5</th>
                    <th>EXTERNAL PLASTER</th>
                    <td><input type="text" name="engineer_id"  value="<?=  $data10['NA'] ?? '' ?>"></td>
                    <td><input type="text" name="engineer_id"  value="<?=  $data10['NA'] ?? '' ?>"></td>
                       <td><input type="text" name="engineer_id"  value="<?= $data8['external_plaster_present_completion'] ?? '' ?>"></td>
                       <td><input type="text" name="engineer_id"  value="<?=  $data10['NA'] ?? '' ?>"></td>

                </tr>
                <tr>
                    <th id="change">6</th>
                    <th id="change">FLOORING</th>
                    <td><input type="text" name="engineer_id"  value="<?=  $data10['NA'] ?? '' ?>"></td>
                    <td><input type="text" name="engineer_id"  value="<?=  $data10['NA'] ?? '' ?>"></td>

                    <td id="change"><input type="text" name="engineer_id"  value="<?= $data8['flooring_present_completion'] ?? '' ?>"></td>
                    <td><input type="text" name="engineer_id"  value="<?=  $data10['NA'] ?? '' ?>"></td>

                </tr>
                <tr>
                    <th>7</th>
                    <th>PLUMBING & ELECTRIC WORK</th>
                    <td><input type="text" name="engineer_id"  value="<?=  $data10['NA'] ?? '' ?>"></td>
                    <td><input type="text" name="engineer_id"  value="<?=  $data10['NA'] ?? '' ?>"></td>

                    <th id="change">DOOR,WINDOW & PAINT</th>
                    <td><input type="text" name="engineer_id"  value="<?=  $data8['door_window_paint_present_completion']?? '' ?>"></td>
                    <td><input type="text" name="engineer_id"  value="<?=  $data10['NA'] ?? '' ?>"></td>

                    <td id="change"><input type="text" name="engineer_id"  value="<?= $data8['door_window_paint_present_completion'] ?? '' ?>"></td>
                    <td><input type="text" name="engineer_id"  value="<?=  $data10['NA'] ?? '' ?>"></td>
                    </tr>
                <tr>
                    <th>9</th>
                    <th>FINISHING & POSSESSION</th>
                    <td><input type="text" name="engineer_id"  value="<?=  $data10['NA'] ?? '' ?>"></td>
                    <td><input type="text" name="engineer_id"  value="<?=  $data10['NA'] ?? '' ?>"></td>

                    <td><input type="text" name="engineer_id"  value="<?= $data8['finishing_possession_present_completion'] ?? '' ?>"></td>
                    <td><input type="text" name="engineer_id"  value="<?=  $data10['NA'] ?? '' ?>"></td>

                </tr>
                <tr>
                    <th colspan="2" id="change">TOTAL COMPLETION (%)</th>
                    <td><input type="text" name="engineer_id"  value="<?=  $data8['total_completion_present'] ?? '' ?>"></td>
                    <td><input type="text" name="engineer_id"  value="<?=  $data10['NA'] ?? '' ?>"></td>

                    <td  id="change"><input type="text" name="engineer_id"  value="<?= $data8['total_completion_present'] ?? '' ?>"></td>
                    <td><input type="text" name="engineer_id"  value="<?=  $data10['NA'] ?? '' ?>"></td>
                    </tr>
            </table>
                    <h2>TECHNICAL DOCUMENTS DETAILS</h2>
            <table>
                <tr>
                    <th>Document Name</th>
                    <th>Applicability & Availability</th>
                    <th>Document Approved By Competent Authority</th>
                    <th>Approving Authority</th>
                    <th>Details of Approval</th>
                </tr>
                <tr>
                    <th id="change">Approved Layout Plan</th>
                   <td><input type="text" name="engineer_id"  value="<?=  $data10['NA'] ?? '' ?>"></td>
                   <td><input type="text" name="engineer_id"  value="<?=  $data10['NA'] ?? '' ?>"></td>
                   <td><input type="text" name="engineer_id"  value="<?= $data9['layout_authority'] ?? '' ?>"></td>
c               </tr>
               <tr>
                    <th>APPROVED FLOOR PLAN</th>
                   <td><input type="text" name="engineer_id"  value="<?= $data9['floor_availability'] ?? '' ?>"></td>
                   <td><input type="text" name="engineer_id"  value="<?= $data9['floor_document'] ?? '' ?>"></td>
                   <td><input type="text" name="engineer_id"  value="<?= $data9['floor_authority'] ?? '' ?>"></td>
                   <td><input type="text" name="engineer_id"  value="<?= $data9['floor_detailss'] ?? '' ?>"></td>
               </tr>   <tr>
                    <th id="change">CONSTRUCTION PERMISSION/BUILDING PERMISSION/COMMENCEMENT CERTIFICATE</th>
                   <td><input type="text" name="engineer_id"  value="<?=  $data10['NA'] ?? '' ?>"></td>
                   <td><input type="text" name="engineer_id"  value="<?= $data10['NA']?? '' ?>"></td>
                   <td><input type="text" name="engineer_id"  value="<?=  $data10['NA'] ?? '' ?>"></td>
                   <td><input type="text" name="engineer_id"  value="<?=  $data10['NA']?? '' ?>"></td>
               </tr>   <tr>
                    <th>BUILDING COMPLETION/OCCUPATION PERMISSION/USE PERMISSION/POSSESSION CERTIFICATE</th>
                   <td><input type="text" name="engineer_id"  value="<?=  $data10['NA'] ?? '' ?>"></td>
                   <td><input type="text" name="engineer_id"  value="<?=  $data10['NA']?? '' ?>"></td>
                   <td><input type="text" name="engineer_id"  value="<?=  $data10['NA'] ?? '' ?>"></td>
                   <td><input type="text" name="engineer_id"  value="<?= $data9['possesion_details'] ?? '' ?>"></td>
               </tr>   <tr>
                    <th id="change">NON AGRICULTURAL PERMISSION/LAND CONVERSION/DIVERSION ORDER</th>
                   <td><input type="text" name="engineer_id"  value="<?=  $data10['NA']?? '' ?>"></td>
                   <td><input type="text" name="engineer_id"  value="<?=  $data10['NA'] ?? '' ?>"></td>
                   <td><input type="text" name="engineer_id"  value="<?=  $data10['NA'] ?? '' ?>"></td>
                   <td><input type="text" name="engineer_id"  value="<?= $data9['nonagricultural_details'] ?? '' ?>"></td>
               </tr>   <tr>
                    <th>LOCATION SKETCH/CERTIFICATE</th>
                   <td><input type="text" name="engineer_id"  value="<?=  $data10['NA'] ?? '' ?>"></td>
                   <td><input type="text" name="engineer_id"  value="<?= $data10['NA'] ?? '' ?>"></td>
                   <td><input type="text" name="engineer_id"  value="<?=  $data10['NA']?? '' ?>"></td>
                   <td><input type="text" name="engineer_id"  value="<?= $data9['location_details'] ?? '' ?>"></td>
               </tr>   <tr>
                    <th id="change">PROPERTY TAX RECIEPTS</th>
                   <td><input type="text" name="engineer_id"  value="<?= $data10['NA'] ?? '' ?>"></td>
                   <td><input type="text" name="engineer_id"  value="<?=  $data10['NA'] ?? '' ?>"></td>
                   <td><input type="text" name="engineer_id"  value="<?=  $data10['NA']?? '' ?>"></td>
                   <td><input type="text" name="engineer_id"  value="<?= $data9['reciepts_details'] ?? '' ?>"></td>
               </tr>   <tr>
                    <th>AUTHORITY ALLOTMENT LETTER</th>
                   <td><input type="text" name="engineer_id"  value="<?=  $data10['NA'] ?? '' ?>"></td>
                   <td><input type="text" name="engineer_id"  value="<?=  $data10['NA']?? '' ?>"></td>
                   <td><input type="text" name="engineer_id"  value="<?=  $data10['NA'] ?? '' ?>"></td>
                   <td><input type="text" name="engineer_id"  value="<?= $data10['NA']?? '' ?>"></td>
               </tr>   <tr>
                    <th id="change">CONSTRUCTION/IMPROVEMENT/EXTENSION ESTIMATE FROM REGISTERED ENGINEER/ARCHITECT</th>
                   <td><input type="text" name="engineer_id"  value="<?=  $data10['NA'] ?? '' ?>"></td>
                   <td><input type="text" name="engineer_id"  value="<?=  $data10['NA']?? '' ?>"></td>
                   <td><input type="text" name="engineer_id"  value="<?=  $data10['NA']?? '' ?>"></td>
                   <td><input type="text" name="engineer_id"  value="<?= $data10['NA'] ?? '' ?>"></td>
               </tr>   <tr>
                    <th>OWNERSHIP DOCUMENT VERIFIED 1(PLS SPECIFY NAME OF DOCUMENT IN DETAILS OF APPPROVAL)</th>
                   <td><input type="text" name="engineer_id"  value="<?=  $data10['NA'] ?? '' ?>"></td>
                   <td><input type="text" name="engineer_id"  value="<?= $data9['ownership1_document'] ?? '' ?>"></td>
                   <td><input type="text" name="engineer_id"  value="<?=  $data10['NA']?? '' ?>"></td>
                   <td><input type="text" name="engineer_id"  value="<?= $data9['ownership1_details'] ?? '' ?>"></td>
               </tr>   <tr>
                    <th id="change">OWNERSHIP DOCUMENT VERIFIED 2(PLS SPECIFY NAME OF DOCUMENT IN DETAILS OF APPPROVAL)</th>
                   <td><input type="text" name="engineer_id"  value="<?= $data10['NA'] ?? '' ?>"></td>
                   <td><input type="text" name="engineer_id"  value="<?= $data9['ownership2_document'] ?? '' ?>"></td>
                   <td><input type="text" name="engineer_id"  value="<?=  $data10['NA'] ?? '' ?>"></td>
                   <td><input type="text" name="engineer_id"  value="<?= $data9['ownership2_details'] ?? '' ?>"></td>
               </tr>
               <tr>
                <th>REMARKS ON DOCUMENTS VERIFIED</th>
                <td colspan="4"><input type="text" name="engineer_id"  value="<?= $data9['list_documents'] ?? '' ?>"></td>
                </tr>
        </table>
        <h2>TECHNICAL DEVIATIONS OBSERVED IN PROPERTY</h2>
        <table>
            <tr>
                <th colspan="3">DETAILS OF DEVIATION & MITIGATES IF AVAILABLE</th>
                <th>DEVIATION SEVERITY</th>
                <th>DEMOLITION RISK</th>
            </tr>
            <tr>
                <td colspan="3"><input type="text" name="engineer_id"  value="<?= $data10['NA'] ?? '' ?>"></td>
                 <td><input type="text" name="engineer_id"  value="<?=  $data10['NA'] ?? '' ?>"></td>
                 <td><input type="text" name="engineer_id"  value="<?= $data9['demolition_risk_1'] ?? '' ?>"></td>
                </tr>
                <tr>
                <td colspan="3"><input type="text" name="engineer_id"  value="<?= $data10['NA']?? '' ?>"></td>
                 <td><input type="text" name="engineer_id"  value="<?= $data10['NA'] ?? '' ?>"></td>
                 <td><input type="text" name="engineer_id"  value="<?= $data10['NA']?? '' ?>"></td>
                </tr> <tr>
                <td colspan="3"><input type="text" name="engineer_id"  value="<?=  $data10['NA']?? '' ?>"></td>
                 <td><input type="text" name="engineer_id"  value="<?=  $data10['NA'] ?? '' ?>"></td>
                 <td><input type="text" name="engineer_id"  value="<?= $data10['NA']?? '' ?>"></td>
                </tr> <tr>
                <td colspan="3"><input type="text" name="engineer_id"  value="<?= $data10['NA'] ?? '' ?>"></td>
                 <td><input type="text" name="engineer_id"  value="<?= $data10['NA'] ?? '' ?>"></td>
                 <td><input type="text" name="engineer_id"  value="<?=  $data10['NA']?? '' ?>"></td>
                </tr> <tr>
                <td colspan="3"><input type="text" name="engineer_id"  value="<?= $data10['NA']?? '' ?>"></td>
                 <td><input type="text" name="engineer_id"  value="<?=  $data10['NA']?? '' ?>"></td>
                 <td><input type="text" name="engineer_id"  value="<?= $data10['NA'] ?? '' ?>"></td>
                </tr>
            </table>
            <h2>ADDITIONAL CONDITIONS /DOCUMENTS TO BE OBTAINED FOR TECHNICAL COMPLIANCE,IF ANY</h2>
            <table>
                <tr>
                    <th>SR.NO.</th>
                    <th colspan="5">CONDITION/ADDITIONAL DOCUMENT TO BE OBTAINED FOR COMPLIANCE , if any</th>
                </tr>
                <tr>
                    <th id="change">1</th>
                    <td colspan="5"><input type="text" name="engineer_id"  value="<?= $data10['NA']?? '' ?>"></td>
                    </tr>
                    <tr>
                    <th>2</th>
                    <td colspan="5"><input type="text" name="engineer_id"  value="<?=  $data10['NA'] ?? '' ?>"></td>
                    </tr> <tr>
                    <th id="change">3</th>
                    <td colspan="5"><input type="text" name="engineer_id"  value="<?= $data10['NA'] ?? '' ?>"></td>
                    </tr>
                </table>
                <h2>PHOTOGRAPHS REQUIRED ALONGWITH TECHNICAL APPRAISAL REPORT</h2>
                <table>
                    <tr>
                        <th>SR.NO.</th>
                        <th colspan="3">PHOTOGRAPH DESCRIPTION</th>
                        <th>PHOTOGRAPH SUBMITTED ALONGWITH REPORT</th>
                        <th></th>
                    </tr>
                    <tr>
                        <th id="change">1</th>
                        <td id="change" colspan="3">ROUTE SKETCH TO PROPERTY(FROM MAJOR LANDMARK/ROAD)</td>
                         <td><input type="text" name="engineer_id"  value="<?=$data3['landmark_1']?? '' ?>"></td>
                         <td><input type="text" name="engineer_id"  value="<?= $data3['landmark_2'] ?? '' ?>"></td>
                     </tr>
                        <tr>
                        <th>2</th>
                        <th id="change2" colspan="3" >GOOGLE MAP WITH LATITUDE AND LONGITUDE</th>
                        <td><input type="text" name="engineer_id"  value="<?=$data3['latitude_value'] ?? '' ?>"></td>
                        <td><input type="text" name="engineer_id"  value="<?= $data3['longitude_value'] ?? '' ?>"></td>
              
                        </tr> <t>
                        <th id="change">3</th>
                        <td colspan="3" id="change">APROACH ROAD TO PROPERTY</td>
                        <td><input type="text" name="engineer_id"  value="<?=$data2['approach_road_to_property'] ?? '' ?>"></td>
                        <td><input type="text" name="engineer_id"  value="<?=$data2['width_of_approach_road'] ?? '' ?>"></td>
                        </tr> <>
                        <th>4</th>
                        <th colspan="3">PHYSICAL IDENTIFICATION(SOCIETY NAME BOARD,NAME,PLATE,SIGN BOARD)</th>
                        <td><input type="text" name="engineer_id"  value="<?=$data10['NA'] ?? '' ?>"></td>
                        <td><input type="text" name="engineer_id"  value="<?=$data10['NA'] ?? '' ?>"></td>
                        </tr> <t>
                        <th id="change">5</th>
                        <td colspan="3" id="change">PHOTOGRAPH OF ENGINEER WITH PROPERTY</td>
                        <td><input type="text" name="engineer_id"  value="<?=$data10['NA'] ?? '' ?>"></td>
                        <td><input type="text" name="engineer_id"  value="<?=$data10['NA'] ?? '' ?>"></td>
                        </tr> 
                        <t>
                        <th>6</th>
                        <th colspan="3">MAIN DOOR OF PROPERTY</th>
                        <td><input type="text" name="engineer_id"  value="<?=$data10['NA'] ?? '' ?>"></td>
                        <td><input type="text" name="engineer_id"  value="<?=$data10['NA'] ?? '' ?>"></td>
                    </tr> <t>
                        <th id="change">7</th>
                        <td colspan="3" id="change">INTERNAL PROPERTY PHOTOGRAPH 1</td>
                        <td><input type="text" name="engineer_id"  value="<?=$data10['NA'] ?? '' ?>"></td>
                        <td><input type="text" name="engineer_id"  value="<?=$data10['NA'] ?? '' ?>"></td>
                        </tr> <t>
                        <th>8</th>
                        <th colspan="3">INTERNAL PROPERTY PHOTOGRAPH 2</th>
                        <td><input type="text" name="engineer_id"  value="<?=$data10['NA'] ?? '' ?>"></td>
                        <td><input type="text" name="engineer_id"  value="<?=$data10['NA'] ?? '' ?>"></td>
                        </tr> <t>
                        <th id="change">9</th>
                        <td colspan="3" id="change">INTERNAL PROPERTY PHOTOGRAPH 3</td>
                        <td><input type="text" name="engineer_id"  value="<?=$data10['NA'] ?? '' ?>">
                        <td><input type="text" name="engineer_id"  value="<?=$data10['NA'] ?? '' ?>"></td>
                        </td></tr>
                    </table>
                    <h2>TECHNICAL RECOMMENDATION ON THE PROPERTY</h2>
         <table>
      <tr>
        <th colspan="2">PROPERTY TECHNICALLY ACCEPTABLE?</th>
        <td colspan="1" class="input-cell"><input type="text" name="engineer_id"  value="<?= $data10['NA'] ??  '' ?>"></td>
        <th colspan="2" rowspan="2">REMARKS ON THE PROPERTY</th>
        <td  colspan="4" rowspan="2"><input type="text" name="engineer_id"  value="<?= $data2['NA'] ?? '' ?>"></td>
      </tr>
      <tr>
        <th colspan="2" id="change">MARKETABILITY OF PROPERTY</th>
        <td colspan="1" class="input-cell"><input type="text" name="engineer_id"  value="<?= $data9['markebility'] ?? '' ?>"></td>
      </tr>         `
      <tr>
        <th colspan="2">PROPERTY VISITED BY</th>
        <td class="input-cell"><input type="text" name="engineer_id"  value="<?= $engineer_name ?>"></td>
        <th colspan="2">REPORT PREPARED BY</th>
        <td class="input-cell"><input type="text" name="engineer_id"  value="<?=  $report_name ?>"></td>
        <th colspan="2">REPORT SUBMITTED TO</th>
        <td class="input-cell"><input type="text" name="engineer_id"  value="<?=  $technical_name ?>"></td>
      </tr>
      <tr>
      <th colspan="2" id="change">VISITED ON (DATE)</th>
        <td class="input-cell"><input type="text" name="engineer_id"  value="<?= $data1['fe_to_coordinator_assign_at'] ?? '' ?>"></td>
        <th colspan="2" id="change">PREPARED ON (DATE)</th>
        <td class="input-cell"><input type="text" name="engineer_id"  value="<?= $data9['report_assigned_at'] ?? '' ?>"></td>
        <th colspan="2" id="change">SUBMITTED ON (DATE)</th>
        <td class="input-cell"><input type="text" name="engineer_id"  value="<?= $data1['report_assigned_at'] ?? '' ?>"></td>
      </tr>
      </table>
        <h2>REMARKS ON THE PROPERTY</h2>
        <table>
      <tr>
      <textarea rows="10"  id="remarks" name="engineer_id" oninput="autoResize(this)"><?= $data10['remarks'] ?? '' ?></textarea>
        </tr></table>
        <h2>VALUER'S DISCLAIMERS/CAVEATS, IF AN</h2>
        <textarea rows="10"  id="remarks" name="engineer_id" oninput="autoResize(this)"><?= $data10['declaration'] ?? '' ?></textarea>

        <h2>PHOTOGRAPH GRID</h2>
        <table>
      
       
   
        <!-- Header Section -->
        <div class="header">
            <h2 style="font-style: italic;">IMAGE UPLOAD FORM</h2>
        </div>
        <div class="image-gallery">
        <?php


// Database connection
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "project_db"; // Replace with your database name
$message = "";
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Step 2: Retrieve reference_id from session (if set)
$reference_id = $_SESSION['reference_id'] ?? null;

// Fetch reference_id from GET or session
$reference_id = isset($_GET['reference_id']) ? $_GET['reference_id'] : $reference_id;


// Ensure reference_id is available
if ($reference_id) {
    // Fetch the images from the database using a prepared statement
    $sql = "SELECT 
                image1, image2, image3, image4, image5, 
                image6, image7, image8, image9, image10, 
                image11, image12 
            FROM final_uploaded_images 
            WHERE reference_id = ?";
    
    $stmt = $conn->prepare($sql);
    if ($stmt === false) {
        die("Error preparing the SQL statement: " . $conn->error);
    }

    // Bind the parameter
    $stmt->bind_param("s", $reference_id); // "s" indicates the parameter is a string

    // Execute the statement
    $stmt->execute();

    // Get the result
    $result = $stmt->get_result();

    if ($result->num_rows > 0) {
        while ($row = $result->fetch_assoc()) {
            if (!empty($row['image1'])) {
                echo '<div>';
                echo '<img src="data:image/jpeg;base64,' . base64_encode($row['image1']) . '" alt="Image 1">';
                echo '<p>EXTERNAL PHOTOS</p>';
                echo '</div>';
            }
            if (!empty($row['image2'])) {
                echo '<div>';
                echo '<img src="data:image/jpeg;base64,' . base64_encode($row['image2']) . '" alt="Image 2">';
                echo '<p>Kitchen</p>';
                echo '</div>';
            }
            if (!empty($row['image3'])) {
                echo '<div>';
                echo '<img src="data:image/jpeg;base64,' . base64_encode($row['image3']) . '" alt="Image 3">';
                echo '<p>Selfie</p>';
                echo '</div>';
            }
            if (!empty($row['image4'])) {
                echo '<div>';
                echo '<img src="data:image/jpeg;base64,' . base64_encode($row['image4']) . '" alt="Image 4">';
                echo '<p>Electric Meter</p>';
                echo '</div>';
            }
            if (!empty($row['image5'])) {
                echo '<div>';
                echo '<img src="data:image/jpeg;base64,' . base64_encode($row['image5']) . '" alt="Image 5">';
                echo '<p>Google Map</p>';
                echo '</div>';
            }
            if (!empty($row['image6'])) {
                echo '<div>';
                echo '<img src="data:image/jpeg;base64,' . base64_encode($row['image6']) . '" alt="Image 6">';
                echo '<p>Other 1</p>';
                echo '</div>';
            }
            if (!empty($row['image7'])) {
                echo '<div>';
                echo '<img src="data:image/jpeg;base64,' . base64_encode($row['image7']) . '" alt="Image 7">';
                echo '<p>Other 2</p>';
                echo '</div>';
            }
            if (!empty($row['image8'])) {
                echo '<div>';
                echo '<img src="data:image/jpeg;base64,' . base64_encode($row['image8']) . '" alt="Image 8">';
                echo '<p>Other 3</p>';
                echo '</div>';
            }
            if (!empty($row['image9'])) {
                echo '<div>';
                echo '<img src="data:image/jpeg;base64,' . base64_encode($row['image9']) . '" alt="Image 9">';
                echo '<p>Other 4</p>';
                echo '</div>';
            }
            if (!empty($row['image10'])) {
                echo '<div>';
                echo '<img src="data:image/jpeg;base64,' . base64_encode($row['image10']) . '" alt="Image 10">';
                echo '<p>Other 5</p>';
                echo '</div>';
            }
            if (!empty($row['image11'])) {
                echo '<div>';
                echo '<img src="data:image/jpeg;base64,' . base64_encode($row['image11']) . '" alt="Image 11">';
                echo '<p>Other 6</p>';
                echo '</div>';
            }
            if (!empty($row['image12'])) {
                echo '<div>';
                echo '<img src="data:image/jpeg;base64,' . base64_encode($row['image12']) . '" alt="Image 12">';
                echo '<p>Other 7</p>';
                echo '</div>';
            }
        }
    } else {
        echo "<p style='text-align:center;'>No images found.</p>";
    }
    
    // Close the statement
    $stmt->close();
} else {
    echo "<p style='text-align:center;'>Reference ID is missing.</p>";
}


?>

   
</div>
  </table>
    </div>
    <form method="post">
  <input type="hidden" name="download_images" value="1">
  <button type="submit">Download All Images</button>
</form>
     <!-- <button onclick="window.print()">Download PDF</button> -->
  <button onclick="setPrintMargins()">DOWNLOAD PDF</button>
  <script>
    document.getElementById('downloadPdf').addEventListener('click', () => {
      // Select the content you want to convert to PDF
      const element = document.getElementById('content');
      const options = {
        margin:[0,0],
        filename:'report.pdf',
        image: { type: 'jpeg', quality: 0.98 },
        html2canvas: { scale: 2 },
        jsPDF: { unit: 'in', format: 'letter', orientation: 'portrait' }
      };

      // Generate and download the PDF
      html2pdf().set(options).from(element).save();
    });
    function setPrintMargins() {
      const style = document.createElement('style');
      style.innerHTML = `
      @media print {
          body {
            margin:0.5;
          }
        }
      `;
      document.head.appendChild(style);
      window.print();
    }
    // Disable all input fields in the form
    document.querySelectorAll('input').forEach(function(input) {
        input.disabled = true;  // Disables the field completely
    });
    </script>
</body>
</html>
