<?php include('auth.php'); ?>
<?php


// Enable error reporting for debugging
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

// Database connection details
$servername = "localhost";
$username = "root";
  $password = "";
$dbname = "project_db";

// PDO connection for fetching data
try {
    $pdo = new PDO("mysql:host=$servername;dbname=$dbname", $username, $password);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

    // Fetch technical managers for dropdown
    $stmt = $pdo->prepare("SELECT technical_manager_id, name FROM technical_login");
    $stmt->execute();
    $managersResult = $stmt->fetchAll(PDO::FETCH_ASSOC);
} catch (PDOException $e) {
    die("Database Connection Error: " . $e->getMessage());
}

// MySQLi connection for form handling
$conn = new mysqli($servername, $username, $password, $dbname);
if ($conn->connect_error) {
    die("Database connection failed: " . $conn->connect_error);
}

// Get current reference_id
$reference_id = $_SESSION['reference_id'] ?? null;
if (!$reference_id) {
    die("Error: Reference ID is missing. Please ensure it is set in the session.");
}

// Get old_reference_id from mis table
$old_reference_id = null;
$stmt = $conn->prepare("SELECT old_reference_id FROM mis WHERE reference_id = ?");
$stmt->bind_param("s", $reference_id);
$stmt->execute();
$stmt->bind_result($old_reference_id);
$stmt->fetch();
$stmt->close();

// If old_reference_id exists and no session data set, fetch old remarks for display
if ($old_reference_id) {
    if (!isset($_SESSION['remarks_table']) && !isset($_POST['remarks_table'])) {
        $stmt = $conn->prepare("SELECT remarks, negative_remarks FROM remarks_table WHERE reference_id = ?");
        $stmt->bind_param("s", $old_reference_id);
        $stmt->execute();
        $stmt->bind_result($remarks_table, $negative_remarks);
        if ($stmt->fetch()) {
            $_SESSION['remarks_table'] = $remarks_table;
            $_SESSION['negative_remarks'] = $negative_remarks;
        }
        $stmt->close();
    }
}

// Handle POST form actions
if ($_SERVER["REQUEST_METHOD"] === "POST") {
    $action = $_POST['action'] ?? '';

    if ($action === "save") {
        $_SESSION['remarks_table'] = $_POST['remarks_table'] ?? "WRITE REMARKS HERE.....";
        $_SESSION['negative_remarks'] = $_POST['negative_remarks'] ?? "WRITE NEGATIVE REMARKS HERE.....";
        $message = "Data saved successfully on the webpage!";
    }

    if ($action === "submit") {
        // Call respective save functions if data exists in session
        if (isset($_SESSION['bank_details'])) saveBankDetailsToDatabase($_SESSION['bank_details']);
        if (isset($_SESSION['property_details'])) saveGeneralDetailsToDatabase($_SESSION['property_details']);
        if (isset($_SESSION['address_details'])) saveAddressToDatabase($_SESSION['address_details']);
        if (isset($_SESSION['critical_parameters'])) savecriticalparametersDetailsToDatabase($_SESSION['critical_parameters']);
        if (isset($_SESSION['area_valuation'])) saveAreaValuationToDatabase($_SESSION['area_valuation'], $pdo);
        if (isset($_SESSION['floor_details'])) saveFloorDetailsToDatabase($_SESSION['floor_details']);
        if (isset($_SESSION['technical_details'])) saveTechnicalDetailsToDatabase($_SESSION['technical_details']);
if (isset($_SESSION['mandatory_details'])) {
    $result = saveMandatoryDetailsToDatabase($_SESSION['mandatory_details']);

    if (strpos($result, "Error:") === 0) {
        // Error → show popup and redirect to REPORT13
        echo "<script>
                alert(" . json_encode($result) . ");
                window.location.href = 'REPORT13.php';
              </script>";
        exit;
    } else {
        // Success → proceed normally (keep $result message if needed)
        unset($_SESSION['mandatory_details']);
    }
}

        $remarks_table = $_SESSION['remarks_table'] ?? ($_POST['remarks_table'] ?? "WRITE REMARKS HERE.....");
        $negative_remarks = $_SESSION['negative_remarks'] ?? ($_POST['negative_remarks'] ?? "WRITE NEGATIVE REMARKS HERE.....");

        // Insert or Update remarks_table
        $stmt = $conn->prepare("SELECT id FROM remarks_table WHERE reference_id = ?");
        $stmt->bind_param("s", $reference_id);
        $stmt->execute();
        $stmt->store_result();

        if ($stmt->num_rows > 0) {
            $stmt->close();
            $stmt = $conn->prepare("UPDATE remarks_table SET remarks = ?, negative_remarks = ? WHERE reference_id = ?");
            $stmt->bind_param("sss", $remarks_table, $negative_remarks, $reference_id);
        } else {
            $stmt->close();
            $stmt = $conn->prepare("INSERT INTO remarks_table (reference_id, remarks, negative_remarks) VALUES (?, ?, ?)");
            $stmt->bind_param("sss", $reference_id, $remarks_table, $negative_remarks);
        }

        if ($stmt->execute()) {
            $stmt->close();

            // Set flag in mis table
            $updateQuery = "UPDATE mis SET flag_report_preview  = 1 WHERE reference_id = ?";
            $stmt = $conn->prepare($updateQuery);
            $stmt->bind_param("s", $reference_id);
            $stmt->execute();

            // Clear session data
            $formSessionKeys = [
                'bank_details', 'property_details', 'address_details',
                'critical_parameters','mandatory_details', 'area_valuation', 'axis_area_valuation',
                'floor_details', 'technical_details', 'remarks_table', 'negative_remarks','mandatory_details'
            ];
            foreach ($formSessionKeys as $key) unset($_SESSION[$key]);
        } else {
            $message = "Error submitting data: " . $stmt->error;
        }

        $stmt->close();
    }
}
 


// Function to save Bank Details to the database
function saveBankDetailsToDatabase($data) {
    global $conn; // Ensure the global $conn variable is used

    // SQL query to insert data into 'bank_details' table
    $sql = "INSERT INTO bank_details (reference_id, bankName, branchname, applicationNo, customerMob, customerName, caseType, visitType, address) 
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)";

    // Prepare the SQL statement
    $stmt = $conn->prepare($sql);

    // Check if the prepare statement failed
    if ($stmt === false) {
        $_SESSION['message'] = "Error preparing SQL statement: " . $conn->error;
        return; // Exit function on error
    }

    // Bind the parameters to the prepared statement
    $stmt->bind_param(
        "sssssssss", 
        $data['reference_id'],
        $data['bankName'],
        $data['branchname'],
        $data['applicationNo'],
        $data['customerMob'],
        $data['customerName'],
        $data['caseType'],
        $data['visitType'],
        $data['address']
    );

    // Execute the query
    if ($stmt->execute()) {
        $_SESSION['message'] = "Bank details saved successfully.";
    } else {
        $_SESSION['message'] = "Error executing query: " . $stmt->error;
    }

    // Close the statement
    $stmt->close();
}
function saveGeneralDetailsToDatabase($data) {
    global $conn;

    if (!$conn) {
        die("Error: Database connection is null.");
    }

    $columns = [
        'reference_id', 'project_approval_status', 'project_id', 'project_name', 'property_facing' ,  'community_dominated',
          'year_of_construction', 'age_of_property', 
        'residual_age_of_property', 'structurally_fit', 'approach_road_to_property', 
        'type_of_approach_road', 'width_of_approach_road', 'class_of_locality', 
        'surrounding_infrastructure',  'property_unit_type', 
        'occupancy_status', 'property_furnished_unfurnished', 'occupant_name', 'relation_of_occupant','occupied_since',
        'person_meet_at_site_contact', 'property_leasehold_freehold', 'demarcated_at_site', 
 'electric_meter_no', 'develop_percent',


 
 'electric_bill_no','relation_person_meet_at_site_contact','name_of_tenant','no_of_tenant','name_on_society_board',
 'transaction_type','property_lies_in_area','ratio_of_each_type','name_on_house_board','civic_amenities'

    ];

    $placeholders = implode(", ", array_fill(0, count($columns), '?'));
    $sql = "INSERT INTO property_details (" . implode(", ", $columns) . ") VALUES ($placeholders)";
    $stmt = $conn->prepare($sql);

    if ($stmt === false) {
        die("Error preparing SQL statement: " . $conn->error);
    }

    $params = [];
    $types = '';

    $numericColumns = ['year_of_construction', 'develop_percent'];

    foreach ($columns as $column) {
        $value = isset($data[$column]) ? trim($data[$column]) : null;
        $value = ($value === '') ? null : $value;
        
        if (in_array($column, $numericColumns)) {
            $params[] = ($value === null) ? null : (int)$value;
            $types .= 'i';
        } else {
            $params[] = $value;
            $types .= 's';
        }
    }

    $stmt->bind_param($types, ...$params);

    if ($stmt->execute()) {
        echo "General Details saved successfully.";
    } else {
        die("Error executing query: " . $stmt->error);
    }

    $stmt->close();
}

function saveAddressToDatabase($data) {
    global $conn; // Use the global database connection

    if ($conn === null) {
        die("Error: Database connection is null.");
    }

    // SQL query for inserting data into the address_details table
    $sql = "INSERT INTO address_details (
                reference_id,address_line_1_as_per_doc, address_line_2_as_per_doc, 
                address_line_3_as_per_doc, address_line_4_as_per_doc, 
                landmark_1, landmark_2, pin_code,
                
                 floor_no,no_of_wings,no_of_blocks,
                 village_name,
                latitude_value, longitude_value, nearest_branch_location, 
                distance_from_branch_kms, address_per_site,

                direction_approved_north, direction_approved_south, 
                direction_approved_east, direction_approved_west, 
                direction_as_per_site_north, direction_as_per_site_south, 
                direction_as_per_site_east, direction_as_per_site_west, 
                direction_as_per_document_north, direction_as_per_document_south, 
                direction_as_per_document_east, direction_as_per_document_west,

                boundaries_matching, property_location_in, nearest_bus_stop_distance, nearest_bus_stop_name, 
                nearest_railway_station_distance, nearest_railway_station_name, 
                nearest_school_college_distance, nearest_hospital_distance,


 property_identified_through,distance_from_vendor_branch_kms,nearest_national_highway_distance,
 nearest_national_highway_name,nearest_city_center_distance,nearest_city_center_name,nearest_airport_distance,nearest_airport_name,nearest_police_station_distance,
 nearest_police_station_name,nearest_post_office_name,nearest_post_office_distance
 ,address_matching,if_not_matching_then, municipal_authority_name, taluka_tehsil, street_name



            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?,
             ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";

    // Prepare the SQL statement
    $stmt = $conn->prepare($sql);

    if ($stmt === false) {
        die("Error preparing SQL statement: " . $conn->error);
    }

    // Define column names for binding
    $columns = [
        'reference_id', 'address_line_1_as_per_doc', 'address_line_2_as_per_doc', 
        'address_line_3_as_per_doc', 'address_line_4_as_per_doc',
        'landmark_1', 'landmark_2', 'pin_code', 'latitude_value', 'longitude_value', 
        'nearest_branch_location', 'distance_from_branch_kms', 'address_per_site',

         'floor_no','no_of_wings','no_of_blocks',
                 'village_name',

        'direction_approved_north', 'direction_approved_south', 
        'direction_approved_east', 'direction_approved_west', 
        'direction_as_per_site_north', 'direction_as_per_site_south', 
        'direction_as_per_site_east', 'direction_as_per_site_west', 
        'direction_as_per_document_north', 'direction_as_per_document_south', 
        'direction_as_per_document_east', 'direction_as_per_document_west',

        'boundaries_matching', 'property_location_in', 'nearest_bus_stop_distance', 'nearest_bus_stop_name', 
        'nearest_railway_station_distance', 'nearest_railway_station_name', 
        'nearest_school_college_distance', 'nearest_hospital_distance',
        'property_identified_through', 
'distance_from_vendor_branch_kms', 
 
'nearest_national_highway_distance', 
'nearest_national_highway_name', 
'nearest_city_center_distance', 
'nearest_city_center_name', 
'nearest_airport_distance', 
'nearest_airport_name', 
'nearest_police_station_distance', 
'nearest_police_station_name', 
 
'nearest_post_office_name', 
'nearest_post_office_distance',
'address_matching', 
'if_not_matching_then', 
'municipal_authority_name', 
'taluka_tehsil', 
'street_name'

    ];

    // Ensure we have the correct number of values
    if (count($columns) !== substr_count($sql, '?')) {
        die("Error: Column count does not match the number of values.");
    }

    // Initialize the parameters array and type string
    $params = [];
    $types = "";

    // Loop through the columns and set the values
    foreach ($columns as $column) {
        $value = $data[$column] ?? NULL; // Use NULL if not set

        // Determine the type
        if (is_null($value)) {
            $params[] = NULL;
            $types .= "s";  // Using "s" for NULL values
        } elseif (is_numeric($value)) {
            $params[] = (float) $value;
            $types .= "d";  // Use "d" for numbers
        } else {
            $params[] = (string) $value;
            $types .= "s";  // Use "s" for strings
        }
    }

    // Bind parameters dynamically
    $stmt->bind_param($types, ...$params);

    // Execute the query
    if ($stmt->execute()) {
        echo "Address and surrounding details saved successfully.";
    } else {
        die("Error executing query: " . $stmt->error);
    }

    // Close the statement
    $stmt->close();
}


function saveCriticalParametersDetailsToDatabase($data) {
    global $conn;

    if (!$conn) {
        die("Error: Database connection is null.");
    }

    $columns = [
        'reference_id', 'zoning_development_plan', 'caution_area', 'failing_in_road_widening', 
        'within_50_mtrs_railway', 'near_high_tension', 'vertical_distance_from_line', 'presence_of_nala', 
        'current_property_usage', 'approved_property_usage', 'comment_on_location_risk', 'abutting_agriculture_land', 
        'seismic_zone', 'structure_type', 'costal_regulatory_zone', 'roof_type',
        'flooring_type','purpose_of_valuation','valuation_method_used','no_of_houses','population_of_village',
        'internal_visit_done','allocated_by_ro_bm','properties_250_meters','properties_500_meters','board_on_house',
        'vertical','corner_plot','registered_or_not','remarks_on_critical_params','habitation_1km',
        'property_configuration','rate_of_agriculture_land','nature_of_building','shape_of_building','fire_exit_available',
        'steel_grade','ground_slope_more_than_20','soil_liquefiable','soil_slope_vulnerable','flood_prone_area',
        'mortar_type','concrete_grade','expansion_joint_available','structural_system','environment_exposure_condition',
        'cyclone_zone_wind_speed','footing_type','projected_parts_available','soil_type','plan_aspect_ratio','soil_strata',
        'type_of_masonary','liquefiable','landslide','exposure_condition'
    ];

    $placeholders = implode(", ", array_fill(0, count($columns), '?'));
    $sql = "INSERT INTO critical_parameters (" . implode(", ", $columns) . ") VALUES ($placeholders)";
    $stmt = $conn->prepare($sql);

    if ($stmt === false) {
        die("Error preparing SQL statement: " . $conn->error);
    }

    $params = [];
    $types = '';

    // Define numeric columns explicitly
    $numericColumns = [
        'no_of_houses','population_of_village','ground_slope_more_than_20','cyclone_zone_wind_speed',
        'rate_of_agriculture_land'
    ];

    foreach ($columns as $column) {
        $value = isset($data[$column]) ? trim($data[$column]) : null;
        $value = ($value === '') ? null : $value;

        if (in_array($column, $numericColumns)) {
            $params[] = ($value === null) ? null : (int)$value;
            $types .= 'i';
        } else {
            $params[] = $value;
            $types .= 's';
        }
    }

    $stmt->bind_param($types, ...$params);

    if ($stmt->execute()) {
        echo "Critical Parameters Details saved successfully.";
    } else {
        die("Error executing query: " . $stmt->error);
    }

    $stmt->close();
}

function saveAreaValuationToDatabase($data, $pdo) {
     // 🔁 Ensure reference_id is set inside the data array
    if (empty($data['reference_id'])) {
        $data['reference_id'] = $_SESSION['reference_id'] ?? null;
    }

    if (empty($data['reference_id'])) {
        die("Missing reference_id. Cannot save data.");
    }
    // Columns to be inserted
    $columns = [
        'reference_id', 'propertyType','plot_square_feet', 'plot_rate', 
        'carpet_square_feet', 'carpet_rate', 'final_plot_square_feet',
        'final_plot_rate', 'final_construction_square_feet', 'final_construction_rate','finally_construction_valuation',
        'distress_value_percent', 'construction_square_feet', 'construction_rate',

'construction_name_1', 'construction_area_sqft_1', 'construction_rate_1', 'construction_valuation_1',
'construction_name_2', 'construction_area_sqft_2', 'construction_rate_2', 'construction_valuation_2',
'construction_name_3', 'construction_area_sqft_3', 'construction_rate_3', 'construction_valuation_3',


        'saleable_square_feet', 'saleable_rate', 'saleable_valuation',
        'actual_plot_square_feet', 'actual_plot_rate', 'actual_plot_valuation',
        'actual_carpet_square_feet', 'actual_carpet_rate', 'actual_carpet_valuation',
        'actual_construction_square_feet', 'actual_construction_rate', 'actual_construction_valuation',
        'actual_saleable_square_feet', 'actual_saleable_rate', 'actual_saleable_valuation',
        'enquiry_remarks','insurable_value', 'loading', 'dimension_as_per_site_north', 'dimension_as_per_site_south', 
        'dimension_as_per_site_east', 'dimension_as_per_site_west',
        'dimension_as_per_document_north', 'dimension_as_per_document_south', 
        'dimension_as_per_document_east', 'dimension_as_per_document_west',
        'car_parking_amount','car_parking',
        'addition_amenities_description_2', 'addition_amenities_amount_2',
        'addition_amenities_description_3', 'addition_amenities_amount_3',
        'addition_amenities_description_4', 'addition_amenities_amount_4',
        'total_valuation', 'final_area_square_feet', 'final_area_rate', 
        'total_valuation_words', 'distress_value_words', 'axis_plot_area', 'axis_plot_sanction', 'axis_plot_document', 'axis_plot_area_document',

        // Actual Built-up Area
        'axis_final_plot_square_feet', 'axis_ground_actual', 'axis_first_actual', 'axis_second_actual',
        'axis_3_actual', 'axis_4_actual', 'axis_other_actual',
        'axis_basement_floor1', 'axis_basement_floor2', 'axis_basement_floor3',

        // Built-up Area As Per Document
        'axis_total_area', 'axis_ground', 'axis_1_floor', 'axis_2_floor',
        'axis_3_floor', 'axis_4_floor', 'axis_other_floor',

        // Approved Built-up Area
        'axis_ground_approved_0', 'axis_ground_approved_1', 'axis_ground_approved_2',
        'axis_ground_approved_3', 'axis_ground_approved_4', 'axis_ground_approved_other',
        'axis_basement_approved_1', 'axis_basement_approved_2', 'axis_basement_approved_3',
        'axis_na_total_area',

        // Permissible Area
        'axis_permissible_area', 'axis_ground_permissible', 'axis_first_permissible',
        'axis_second_permissible', 'axis_third_permissible', 'axis_forth_permissible',
        'axis_other_permissible_floors', 'axis_basement_approved_4', 'axis_basement_approved_5',
        'axis_basement_approved_6',

        // Built-up Area Considered for Valuation
        'axis_total_considered_area', 'axis_ground_considered', 'axis_first_considered',
        'axis_second_considered', 'axis_third_considered', 'axis_forth_considered',
        'axis_other_considered_floors', 'axis_basement_approved_7', 'axis_basement_approved_8',
        'axis_basement_approved_9',
        'gross_monthly_rental', 'guideline_rate', 'replacement_cost',
        'gov_plot_area_sqft',
'gov_plot_area_rate',
'gov_plot_area_valuation',
'gov_construction_name1',
'gov_construction_area1',
'gov_construction_rate1',
'gov_construction_valuation1',
'gov_construction_name2',
'gov_construction_area2',
'gov_construction_rate2',
'gov_construction_valuation2',
'gov_construction_name3',
'gov_construction_area3',
'gov_construction_rate3',
'gov_construction_valuation3',
'gov_builtup_area_sqft',
'gov_builtup_area_rate',
'gov_builtup_area_valuation',
'gov_saleable_area_sqft',
'gov_saleable_area_rate',
'gov_saleable_area_valuation',
'gov_final_area_valuation',
'proposed_plot_area_sqft',
'proposed_plot_rate',
'proposed_plot_valuation',
'proposed_construction_name1',
'proposed_construction_area_sqft1',
'proposed_construction_rate1',
'proposed_construction_valuation1',
'proposed_construction_name2',
'proposed_construction_area_sqft2',
'proposed_construction_rate2',
'proposed_construction_valuation2',
'proposed_construction_name3',
'proposed_construction_area_sqft3',
'proposed_construction_rate3',
'proposed_construction_valuation3',
'proposed_builtup_area_sqft',
'proposed_builtup_rate',
'proposed_builtup_valuation',
'proposed_saleable_area_sqft',
'proposed_saleable_rate',
'proposed_saleable_valuation',
'proposed_final_area_valuation',
'estimated_cost_rs','estimated_cost_per_sqft','justified_estimated_cost_per_sqft','adoptable_justified_estimated_cost','loading1','insurable_value_1'

];

    // Generate placeholders for prepared statement
    $placeholders = implode(", ", array_fill(0, count($columns), '?'));
    $sql = "INSERT INTO area_valuation (" . implode(", ", $columns) . ") VALUES ($placeholders)";

    try {
        $stmt = $pdo->prepare($sql);

        // Bind values dynamically
        $params = [];
        foreach ($columns as $column) {
            $params[] = $data[$column] ?? null;
        }

        if ($stmt->execute($params)) {
            return true;
        }
    } catch (PDOException $e) {
        die("Database Insert Error: " . $e->getMessage());
    }

    return false;
} 
function saveFloorDetailsToDatabase($floor_details) {
    global $conn;

    if (!$conn) {
        die("Error: Database connection is null.");
    }

    // 🔁 Ensure reference_id is set inside the data array
    if (empty($floor_details['reference_id'])) {
        $floor_details['reference_id'] = $_SESSION['reference_id'] ?? null;
    }

    if (empty($floor_details['reference_id'])) {
        die("Missing reference_id. Cannot save data.");
    }

    // ✅ All columns for the floor_details table
    $columns = [
        'propertyType', 'reference_id', 'stage_construction_actual_present_completion',
        'stage_construction_recommend_present_completion', 'description_stage_construction_allotted',

        'plinth_present_completion', 'number_of_units_each_floor', 'number_of_lifts',
        'rcc_present_completion', 'brickwork_present_completion',

        'internal_plaster_present_completion', 'Present_quality_of_structure', 'total_actual_floors',
        'external_plaster_present_completion', 'area_total', 'total_approved_floors',

        'flooring_present_completion', 'plumbing_present_completion',
        'door_window_paint_present_completion', 'finishing_possession_present_completion',
        'total_completion_present', 'basements_remarks',

        'document_area_saledeed', 'actual_configuration_building', 'approved_configuration_building',

        // Ground Floor
        'ground_accommodation', 'ground_completed', 'ground_approved_area', 'ground_permissible_area',
        'ground_actual_area', 'ground_proposed_area', 'ground_rate', 'ground_valuation',

        // First Floor
        'first_accommodation', 'first_completed', 'first_approved_area', 'first_permissible_area',
        'first_actual_area', 'first_proposed_area', 'first_rate', 'first_valuation',

        // Second Floor
        'second_accommodation', 'second_completed', 'second_approved_area', 'second_permissible_area',
        'second_actual_area', 'second_proposed_area', 'second_rate', 'second_valuation',

        // Other Floors
        'other_accommodation', 'other_completed', 'other_approved_area', 'other_permissible_area',
        'other_actual_area', 'other_proposed_area', 'other_rate', 'other_valuation',

        // Total Floors
        'total_accommodation', 'total_completed', 'total_approved_area', 'total_permissible_area',
        'total_actual_area', 'total_proposed_area', 'total_rate', 'total_valuation',

        'plinth_completion_present', 'plinth_floors_completed',
        'rcc_completion_present', 'rcc_floors_completed',
        'brickwork_completion_present', 'brickwork_floors_completed',
        'internal_plaster_completion_present', 'internal_plaster_floors_completed',
        'external_plaster_completion_present', 'external_plaster_floors_completed',
        'flooring_completion_present', 'flooring_floors_completed',
        'painting_completion_present', 'painting_floors_completed',
        'plumbing_completion_present', 'plumbing_floors_completed',
        'fixtures_completion_present', 'fixtures_floors_completed',
        'foundation_completion_present', 'foundation_floors_completed',

        // Additional fields
        'total_completion_floors_completed',
        'old_stage_construction_allotted',
        'estimate_provided',
        'estimate_method',

        // Setbacks
        'front_as_per_plan', 'front_as_per_bye_laws', 'front_actual_site', 'front_extra_plan', 'front_extra_bye_laws',
        'site1_as_per_plan', 'site1_as_per_bye_laws', 'site1_actual_site', 'site1_extra_plan', 'site1_extra_bye_laws',
        'site2_as_per_plan', 'site2_as_per_bye_laws', 'site2_actual_site', 'site2_extra_plan', 'site2_extra_bye_laws',
        'rear_as_per_plan', 'rear_as_per_bye_laws', 'rear_actual_site', 'rear_extra_plan', 'rear_extra_bye_laws',

        // Floors Info
        'basement_approved', 'basement_actual_planned', 'basement_remarks',
        'number_ground_approved', 'ground_actual_planned', 'number_ground_remarks',
        'number_first_approved', 'first_actual_planned', 'number_first_remarks',
        'number_second_approved', 'second_actual_planned', 'number_second_remarks',
        'number_third_approved', 'third_actual_planned', 'number_third_remarks','number_of_units_building',
        'total_floors_approved', 'total_floors_actual_planned', 'total_number_floors_remarks','progress_remarks'
    ];

    // ✅ Numeric columns
    $numericColumns = [
        'stage_construction_actual_present_completion',
        'stage_construction_recommend_present_completion', 'total_approved_floors',

        'plinth_present_completion', 'number_of_units_each_floor', 'number_of_lifts',
        'rcc_present_completion', 'brickwork_present_completion',
        'internal_plaster_present_completion', 'external_plaster_present_completion',

        

        'flooring_present_completion', 'plumbing_present_completion',
        'door_window_paint_present_completion', 'finishing_possession_present_completion',
        'total_completion_present', 'area_total',

        'ground_completed', 'ground_approved_area', 'ground_permissible_area', 'ground_actual_area', 'ground_proposed_area', 'ground_rate', 'ground_valuation',
        'first_completed', 'first_approved_area', 'first_permissible_area', 'first_actual_area', 'first_proposed_area', 'first_rate', 'first_valuation',
        'second_completed', 'second_approved_area', 'second_permissible_area', 'second_actual_area', 'second_proposed_area', 'second_rate', 'second_valuation',
        'other_completed', 'other_approved_area', 'other_permissible_area', 'other_actual_area', 'other_proposed_area', 'other_rate', 'other_valuation',
        'total_completed', 'total_approved_area', 'total_permissible_area', 'total_actual_area', 'total_proposed_area', 'total_rate', 'total_valuation',

        'plinth_completion_present', 'plinth_floors_completed',
        'rcc_completion_present', 'rcc_floors_completed',
        'brickwork_completion_present', 'brickwork_floors_completed',
        'internal_plaster_completion_present', 'internal_plaster_floors_completed',
        'external_plaster_completion_present', 'external_plaster_floors_completed',
        'flooring_completion_present', 'flooring_floors_completed',
        'painting_completion_present', 'painting_floors_completed',
        'plumbing_completion_present', 'plumbing_floors_completed',
        'fixtures_completion_present', 'fixtures_floors_completed',
        'foundation_completion_present', 'foundation_floors_completed',

        // Additional numeric-like fields
        'Present_quality_of_structure',
        'total_completion_floors_completed',
        'old_stage_construction_allotted',
        'estimate_provided',
        'estimate_method',

        // Setbacks
        'front_as_per_plan', 'front_as_per_bye_laws', 'front_actual_site', 'front_extra_plan', 'front_extra_bye_laws',
        'site1_as_per_plan', 'site1_as_per_bye_laws', 'site1_actual_site', 'site1_extra_plan', 'site1_extra_bye_laws',
        'site2_as_per_plan', 'site2_as_per_bye_laws', 'site2_actual_site', 'site2_extra_plan', 'site2_extra_bye_laws',
        'rear_as_per_plan', 'rear_as_per_bye_laws', 'rear_actual_site', 'rear_extra_plan', 'rear_extra_bye_laws',

        // Floors Info
        'basement_approved', 'basement_actual_planned',
        'number_ground_approved', 'ground_actual_planned',
        'number_first_approved', 'first_actual_planned',
        'number_second_approved', 'second_actual_planned',
        'number_third_approved', 'third_actual_planned',
        'total_floors_approved', 'total_floors_actual_planned','number_of_units_building'
    ];

    // Create placeholders
    $placeholders = implode(", ", array_fill(0, count($columns), '?'));

    // Prepare SQL query
    $sql = "INSERT INTO floor_details (" . implode(", ", $columns) . ") VALUES ($placeholders)";
    $stmt = $conn->prepare($sql);

    if ($stmt === false) {
        die("Error preparing SQL statement: " . $conn->error);
    }

    // Prepare the data for binding
    $params = [];
    $types = '';

    foreach ($columns as $column) {
        $value = isset($floor_details[$column]) ? trim((string)$floor_details[$column]) : null;
        $value = ($value === '') ? null : $value;

        if (in_array($column, $numericColumns, true)) {
            $params[] = ($value === null) ? null : (float)$value;
            $types .= 'd';
        } else {
            $params[] = $value;
            $types .= 's';
        }
    }

    // ✅ bind_param requires variables by reference
    $bindNames[] = $types;
    foreach ($params as $key => $val) {
        $bindNames[] = &$params[$key];
    }

    call_user_func_array([$stmt, 'bind_param'], $bindNames);

    if ($stmt->execute()) {
        echo "✅ Floor details saved successfully.";
    } else {
        die("❌ Error executing query: " . $stmt->error);
    }

    $stmt->close();
}

function saveTechnicalDetailsToDatabase($data) {
    global $conn;

    if (!$conn) {
        die("Error: Database connection is null.");
    }

    $columns = [
        'reference_id', 'positive_report', 'markebility',
        'demolition_risk_1', 'owner_name', 'seller_name',
        'fsi_deviation', 'vertical_deviation', 'fsi_far_deviation', 'seller_type',

        'map_available','sanction_approving_authority','sanction_approval_no','sanction_approval_date',
        'layout_applicable','layout_approving_authority','layout_approval_details','layout_approval_date',
        'completion_certificate','completion_approving_authority','completion_approval_details','completion_approval_date',
        'occupancy_certificate','occupancy_approving_authority','occupancy_approval_details','occupancy_approval_date',
        'na_permission_details','na_approving_authority','na_approval_details','na_approval_date',
        'rera_details','rera_approving_authority','rera_approval_details','rera_approval_date',
        'lease_details','lease_approving_authority','lease_approval_details','lease_approval_date',
        'ownership1_approving_authority', 'ownership1_no','ownership1_date',
        'ownership2_approving_authority', 'ownership2_no','ownership2_date','ownership1_details','ownership2_details',
        'ownership3_approving_authority','ownership3_details','ownership3_no','ownership3_date',
        'ownership4_approving_authority','ownership4_details','ownership4_no','ownership4_date',
        'list_documents'
    ];

    $placeholders = implode(", ", array_fill(0, count($columns), '?'));
    $sql = "INSERT INTO technical_details (" . implode(", ", $columns) . ") VALUES ($placeholders)";
    $stmt = $conn->prepare($sql);

    if ($stmt === false) {
        die("Error preparing SQL statement: " . $conn->error);
    }

    $params = [];
    $types = '';

    // Define numeric columns (adjust as per schema)
    $numericColumns = ['fsi_deviation', 'vertical_deviation', 'fsi_far_deviation'];

    foreach ($columns as $column) {
        $value = isset($data[$column]) ? trim($data[$column]) : null;
        $value = ($value === '') ? null : $value;

        if (in_array($column, $numericColumns)) {
            $params[] = ($value === null) ? null : (float)$value;
            $types .= 'd'; // decimals for numeric values
        } else {
            $params[] = $value;
            $types .= 's';
        }
    }

    $stmt->bind_param($types, ...$params);

    if ($stmt->execute()) {
        echo "Technical details saved successfully.";
    } else {
        die("Error executing query: " . $stmt->error);
    }

    $stmt->close();
}

function saveMandatoryDetailsToDatabase($data) {
    global $conn;

    if (!$conn) {
        return "Error: Database connection is null.";
    }

    if (!isset($data['bill_address_per_site']) || trim($data['bill_address_per_site']) === '') {
        return "Error: 'Billing Address per Site' is mandatory.";
    }

    if (!isset($data['bill_latitude']) || $data['bill_latitude'] === '' || !is_numeric($data['bill_latitude'])) {
        return "Error: 'Bill Latitude' is mandatory and must be a valid number.";
    }

    if (!isset($data['bill_longitude']) || $data['bill_longitude'] === '' || !is_numeric($data['bill_longitude'])) {
        return "Error: 'Bill Longitude' is mandatory and must be a valid number.";
    }

    if (!isset($data['bill_nearest_branch']) || trim($data['bill_nearest_branch']) === '') {
        return "Error: 'Bill Nearest Branch' is mandatory.";
    }

    if (!isset($data['bill_property_type']) || trim($data['bill_property_type']) === '') {
        return "Error: 'Bill Property Type' is mandatory.";
    }

    $columns = [
        'reference_id',
        'bill_address_per_site',
        'bill_latitude',
        'bill_longitude',
        'bill_nearest_branch',
        'bill_property_type'
    ];

    $placeholders = implode(", ", array_fill(0, count($columns), '?'));
    $sql = "INSERT INTO mandatory_details (" . implode(", ", $columns) . ") VALUES ($placeholders)";
    $stmt = $conn->prepare($sql);

    if ($stmt === false) {
        return "Error preparing SQL statement: " . $conn->error;
    }

    $params = [];
    $types = '';
    $numericColumns = [];

    foreach ($columns as $column) {
        $value = isset($data[$column]) ? trim($data[$column]) : null;
        $value = ($value === '') ? null : $value;

        if (in_array($column, $numericColumns)) {
            $params[] = ($value === null) ? null : (int)$value;
            $types .= 'i';
        } else {
            $params[] = $value;
            $types .= 's';
        }
    }

    $stmt->bind_param($types, ...$params);

    if ($stmt->execute()) {
        return "Critical Parameters Details saved successfully.";
    } else {
        return "Error executing query: " . $stmt->error;
    }
}

?>


<!-- JavaScript for alert and redirect -->
<script>
    <?php if (isset($_POST['action']) && $_POST['action'] == 'submit'): ?>
        alert("Form submitted successfully.");
        window.location.href = "Pending_Report.php";  // Redirect to Pending_Report.php after the alert
    <?php endif; ?>
</script>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Property Details Form</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
    <link rel="shortcut icon" href="favicon.ico" type="image/x-icon">
    <link rel="stylesheet" href="REPORT12.css">
       <style>
        /* Loader Overlay */
        #loaderOverlay {
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background-color: rgba(255, 255, 255, 0.95);
            z-index: 9999;
            display: flex;
            justify-content: center;
            align-items: center;
            font-size: 2em;
            color: #333;
        }

        /* Optional: Prevent scrolling while loading */
        body.loading {
            overflow: hidden;
        }

        /* Dim all content when loading */
        #mainContent {
            pointer-events: none; /* Disable interaction */
            opacity: 0.5;
        }

        body:not(.loading) #mainContent {
            pointer-events: auto;
            opacity: 1;
        }
    </style>
</head>

<body class="loading">
    <!-- Loader -->
    <div id="loaderOverlay">LOADING, PLEASE WAIT...</div><button id="toggleSidebar">&#9776;</button>
<div id="sidebar" class="sidebar">
    <div style="display: flex">
      <img class="logo" src="logo.png" alt="" />
      <h1>Magpie Engineering</h1>
    </div>
    <div class="rotating-text">Report Drafter</div>
    <a href="clear_and_go_home.php"><i class="fas fa-home icon"></i>Home</a>        

    
  <a href="clear_sessions.php" class="active"><i class="fas fa-clock watch-icon"></i>Pending For Drafting</a>
    <a href="technical.php"><i class="fas fa-clipboard-list icon"></i> Preview Report</a>    
          <a href="clear_and_logout.php"><i class="fas fa-sign-out-alt icon"></i>Logout</a>
  </div>
  
<!-- Tab Buttons -->
<div class="tab-links"> 
    <button class="tab tab-button" data-href="REPORT3.php"><img src="info.png" alt="Icon" width="50" height="50"> INFO</button>
    <button class="tab tab-button" data-href="REPORT4.php"><img src="general.png" alt="Icon" width="50" height="50" style="margin-bottom:4px;"> GENERAL</button>
    <button class="tab tab-button" data-href="REPORT2.php"><img src="location.png" alt="Icon" width="50" height="50"> LOCATION</button>
    <button class="tab tab-button" data-href="REPORT5.php"><img src="Zoning.png" alt="Icon" width="50" height="50"> ZONING</button>
    <button class="tab tab-button" data-href="REPORT7.php"><img src="value.png" alt="Icon" width="50" height="50"> VALUE</button>
    <button class="tab tab-button" data-href="REPORT9.php"><img src="Floor.png" alt="Icon" width="50" height="50"> STRUCTURE</button>
    <button class="tab tab-button" data-href="REPORT10.php"><img src="documents.png" alt="Icon" width="50" height="50"> DOCUMENTS</button>
    <button class="tab tab-button" data-href="REPORT115.php"><img src="photo.png" alt="Icon" width="50" height="50"> PHOTOS</button>
    <button class="tab tab-button" style="font-weight:800px;"  data-href="REPORT13.php"><img src="mandatory.png" alt="Icon" width="80" height="80"> MANDATORY FIELDS</button>

    <button class="tab tab-button" class="tab active"  data-href="REPORT12.php"><img src="remark.png" alt="Icon" width="50" height="50"> REMARK</button>
    <div class="slider"></div>
</div>
        <div class="section valuation-table" style="margin-top:5px;">
    <form id="autosave-form" method="POST" action="">
        <h2>POSITIVE REMARKS ON THE PROPERTY</h2>
        <textarea name="remarks_table" cols="166" rows="10" style="background-color: rgba(207, 233, 252, 0.282); margin:auto;" placeholder="  WRITE REMARKS HERE....."><?= isset($_SESSION['remarks_table']) && is_string($_SESSION['remarks_table']) ? htmlspecialchars($_SESSION['remarks_table']) : "" ?></textarea>

        <h2 style="margin-top:15px;">NEGATIVE REMARKS ON THE PROPERTY</h2>
        <textarea name="negative_remarks" cols="166" rows="10" style="background-color: rgba(252, 207, 207, 0.282); margin:auto;" placeholder="  WRITE NEGATIVE REMARKS HERE....."><?= isset($_SESSION['negative_remarks']) && is_string($_SESSION['negative_remarks']) ? htmlspecialchars($_SESSION['negative_remarks']) : "" ?></textarea>

</div>

    
            <div class="section ">
                <h2>Valuer's Disclaimers/Caveats, If Any</h2>
                <ul>
                    <li>The property is physically inspected by our Engineer/Representative.</li>
                    <li>We have no direct/indirect interest in the property valued.</li>
                    <li>The information furnished above is true & correct to the best of our knowledge and belief and
                        takes account information and/or documents submitted or shown to us by the client.</li>
                    <li>The ownership papers/sale deeds may please be verified at your end to ascertain the right title
                        & area.</li>
                    <li>The fair market value indicated in the report is an opinion of the value prevailing on the date
                        of the said report and is based on market feedback on values of similar properties. The client
                        is free to obtain other independent opinions on the same. The fair market value of such
                        properties/localities may increase or decrease depending on future market conditions and
                        scenarios. This report does not certify or confirm any ownership or title of the property that
                        has been valued.</li>
                </ul>
            </div>

          
 
            <div class="submit-button">
            <input type="hidden" name="action" value="save">
            <button type="submit" id="saveBtn" name="action" value="save">Save</button>
            <button type="submit" name="action" value="submit">SUBMIT</button>
        </div>
    </form>
          
            </div>
           <!-- Script to hide loader -->
    <script>
        // Run when page is fully loaded
        window.addEventListener('load', function () {
            // Hide loader
            document.getElementById('loaderOverlay').style.display = 'none';
            // Re-enable page interaction
            document.body.classList.remove('loading');
        });
    </script>
<script>
 // On Save button click, set saved flag in sessionStorage
    document.getElementById('saveBtn').addEventListener('click', function () {
        sessionStorage.setItem('isFormSaved', 'true');
    });

    // Intercept tab button clicks
    document.querySelectorAll('.tab-button').forEach(button => {
        button.addEventListener('click', function (e) {
            const isSaved = sessionStorage.getItem('isFormSaved') === 'true';
            if (!isSaved) {
                e.preventDefault();
                alert("Please click 'Save' before switching tabs.");
            } else {
                const url = this.getAttribute('data-href');
                window.location.href = url;
            }
        });
    });

    // Reset save flag if user edits any input
    document.querySelectorAll('input, textarea, select').forEach(field => {
        field.addEventListener('input', function () {
            sessionStorage.setItem('isFormSaved', 'false');
        });
    });


    


    document.addEventListener("DOMContentLoaded", function () {
    let tabs = document.querySelectorAll(".tab-links .tab");
    let slider = document.querySelector(".tab-links .slider");

    function moveSlider(activeTab) {
        slider.style.width = activeTab.offsetWidth + "px";
        slider.style.left = activeTab.offsetLeft + "px";
    }

    tabs.forEach(tab => {
        tab.addEventListener("click", function () {
            tabs.forEach(t => t.classList.remove("active"));
            this.classList.add("active");
            moveSlider(this);
        });

        // Initialize position on load for the active tab
        if (tab.classList.contains("active")) {
            moveSlider(tab);
        }
    });
});
  
document.getElementById("toggleSidebar").addEventListener("click", function () {
    if (confirm("Are you sure to open the side bar? Your data will be lost/erased.")) {
        // Redirect to "Pending For Drafting" page
        window.location.href = "clear_sessions.php";
    } else {
        // If user clicks Cancel, do nothing
        return false;
    }
});


var modal = document.getElementById("myModal");

// Get the <span> element that closes the modal
var span = document.getElementsByClassName("close")[0];

// Function to show the modal with custom text
function showPopup(text) {
    document.getElementById("modalText").innerText = text;
    modal.style.display = "block";
}

// When the user clicks on <span> (x), close the modal
span.onclick = function() {
    modal.style.display = "none";
}

// When the user clicks anywhere outside of the modal, close it
window.onclick = function(event) {
    if (event.target == modal) {
        modal.style.display = "none";
    }
}

function openGoogleMaps(location) {
            const baseUrl = "https://www.google.com/maps/search/?api=1&query=";
            window.open(baseUrl + encodeURIComponent(location), '_blank');
        }
function triggerFileInput2() {
            document.getElementById("imageInput").click();
        }

        document.getElementById("imageInput").addEventListener("change", function (event) {
            const files = event.target.files;
            const previewContainer = document.getElementById("imagePreviewContainer");

            // Clear previous previews
            previewContainer.innerHTML = "";

            // Display previews for each selected image
            Array.from(files).forEach((file) => {
                if (file.type.startsWith("image/")) {
                    const reader = new FileReader();
                    reader.onload = function (e) {
                        const img = document.createElement("img");
                        img.src = e.target.result;
                        previewContainer.appendChild(img);
                    };
                    reader.readAsDataURL(file);
                }
            });
        });
function triggerFileInput1() {
            document.getElementById("pdfInput").click();
        }

        // Handle file selection
        document.getElementById("pdfInput").addEventListener("change", function (event) {
            const file = event.target.files[0];
            if (file && file.type === "application/pdf") {
                // Create a FileReader instance
                const reader = new FileReader();

                // When the file is read successfully, open it in a new tab
                reader.onload = function (e) {
                    const pdfUrl = e.target.result;

                    // Try to open the PDF in a new tab using embed
                    const newTab = window.open();
                    if (newTab) {
                        newTab.document.write('<html><body><embed src="' + pdfUrl + '" type="application/pdf" width="100%" height="100%"></body></html>');
                        newTab.document.close();

                        // Fallback if the PDF does not load correctly
                        setTimeout(function() {
                            if (newTab.document.body.innerHTML === "") {
                                // Use PDF.js as a fallback to display the PDF
                                newTab.document.body.innerHTML = '<div id="pdf-container" style="width: 100%; height: 100%;"></div>';
                                const loadingTask = pdfjsLib.getDocument(pdfUrl);
                                loadingTask.promise.then(function(pdf) {
                                    pdf.getPage(1).then(function(page) {
                                        const scale = 1.5;
                                        const viewport = page.getViewport({ scale: scale });
                                        const canvas = document.createElement('canvas');
                                        const ctx = canvas.getContext('2d');
                                        canvas.height = viewport.height;
                                        canvas.width = viewport.width;
                                        document.getElementById('pdf-container').appendChild(canvas);

                                        // Render PDF page
                                        page.render({
                                            canvasContext: ctx,
                                            viewport: viewport
                                        });
                                    });
                                });
                            }
                        }, 1000); // Check if the embed failed after 1 second
                    }
                };

                // Read the file as a data URL
                reader.readAsDataURL(file);
            } else {
                alert("Please select a valid PDF file.");
            }
        });
</script>
</body>

</html>
