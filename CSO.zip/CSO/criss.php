 
<?php include('auth.php'); ?>
<?php
// Start session


// Database credentials
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "project_db";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Retrieve reference_id from session
if (!isset($_SESSION['reference_id'])) {
    die("Error: Reference ID not found.");
}

$reference_id = $_SESSION['reference_id'];

// Debugging: Output for verification
echo "Session reference_id: " . htmlspecialchars($reference_id) . "<br>";


 

// Fetch data from bank_details table
$sql_property = "SELECT * FROM mis WHERE reference_id = ?";
$stmt_property = $conn->prepare($sql_property);
$stmt_property->bind_param("s", $reference_id);
$stmt_property->execute();
$result_property = $stmt_property->get_result();
$data1 = $result_property->fetch_assoc();




// Fetch data from property_details table
$sql_property = "SELECT * FROM property_details WHERE reference_id = ?";
$stmt_property = $conn->prepare($sql_property);
$stmt_property->bind_param("s", $reference_id);
$stmt_property->execute();
$result_property = $stmt_property->get_result();
$data2= $result_property->fetch_assoc();




// Fetch data from area_valuation table
$sql_area = "SELECT * FROM address_details WHERE reference_id = ?";
$stmt_area = $conn->prepare($sql_area); 
$stmt_area->bind_param("s", $reference_id);
$stmt_area->execute();
$result_area = $stmt_area->get_result();
$data3 = $result_area->fetch_assoc();





// Fetch data from area_valuation table
$sql_area = "SELECT * FROM critical_parameters WHERE reference_id = ?";
$stmt_area = $conn->prepare($sql_area); 
$stmt_area->bind_param("s", $reference_id);
$stmt_area->execute();
$result_area = $stmt_area->get_result();
$data4 = $result_area->fetch_assoc();

 
// Fetch data from area_valuation table
$sql_area = "SELECT * FROM surroundings_details WHERE reference_id = ?";
$stmt_area = $conn->prepare($sql_area); 
$stmt_area->bind_param("s", $reference_id);
$stmt_area->execute();
$result_area = $stmt_area->get_result();
$data5 = $result_area->fetch_assoc();
$stmt_area->close();
 
// Fetch data from area_valuation table
$sql_area = "SELECT * FROM area_valuation WHERE reference_id = ?";
$stmt_area = $conn->prepare($sql_area); 
$stmt_area->bind_param("s", $reference_id);
$stmt_area->execute();
$result_area = $stmt_area->get_result();
$data6 = $result_area->fetch_assoc();
$stmt_area->close();
 



// Fetch data from area_valuation table
$sql_area = "SELECT * FROM floor_details WHERE reference_id = ?";
$stmt_area = $conn->prepare($sql_area); 
$stmt_area->bind_param("s", $reference_id);
$stmt_area->execute();
$result_area = $stmt_area->get_result();
$data8= $result_area->fetch_assoc();
$stmt_area->close();
 


// Fetch data from area_valuation table
$sql_area = "SELECT * FROM technical_details WHERE reference_id = ?";
$stmt_area = $conn->prepare($sql_area); 
$stmt_area->bind_param("s", $reference_id);
$stmt_area->execute();
$result_area = $stmt_area->get_result();
$data9 = $result_area->fetch_assoc();
$stmt_area->close();
 
// Fetch data from area_valuation table
$sql_area = "SELECT * FROM remarks_table WHERE reference_id = ?";
$stmt_area = $conn->prepare($sql_area); 
$stmt_area->bind_param("s", $reference_id);
$stmt_area->execute();
$result_area = $stmt_area->get_result();
$data10 = $result_area->fetch_assoc();
$stmt_area->close();


// Step 1: Fetch the engineer_id from the mis table
$sql_mis = "SELECT engineer_id FROM mis WHERE reference_id = ?";
$stmt_mis = $conn->prepare($sql_mis);
$stmt_mis->bind_param("s", $reference_id);
$stmt_mis->execute();
$result_mis = $stmt_mis->get_result();
$row_mis = $result_mis->fetch_assoc();
$stmt_mis->close(); 

if ($row_mis) {
    $engineer_id = $row_mis['engineer_id'];

    // Step 2: Fetch the engineer's name from engineer_login table
    $sql_engineer = "SELECT name FROM engineer_login WHERE engineer_id = ?";
    $stmt_engineer = $conn->prepare($sql_engineer);
    $stmt_engineer->bind_param("s", $engineer_id);
    $stmt_engineer->execute();
    $result_engineer = $stmt_engineer->get_result();
    $row_engineer = $result_engineer->fetch_assoc();
    $stmt_engineer->close();

    if ($row_engineer) {
        $engineer_name = $row_engineer['name'];
        echo "Engineer Name: " . $engineer_name;
    } else {
        echo "Engineer not found.";
    }
} else {
    echo "No engineer assigned for this reference_id.";
}



// Step 1: Fetch the engineer_id from the mis table
$sql_mis = "SELECT report_id FROM mis WHERE reference_id = ?";
$stmt_mis = $conn->prepare($sql_mis);
$stmt_mis->bind_param("s", $reference_id);
$stmt_mis->execute();
$result_mis = $stmt_mis->get_result();
$row_mis = $result_mis->fetch_assoc();
$stmt_mis->close(); 

if ($row_mis) {
    $report_id = $row_mis['report_id'];

    // Step 2: Fetch the engineer's name from engineer_login table
    $sql_engineer = "SELECT name FROM report_login WHERE report_id = ?";
    $stmt_engineer = $conn->prepare($sql_engineer);
    $stmt_engineer->bind_param("s", $report_id);
    $stmt_engineer->execute();
    $result_engineer = $stmt_engineer->get_result();
    $row_engineer = $result_engineer->fetch_assoc();
    $stmt_engineer->close();

    if ($row_engineer) {
        $report_name = $row_engineer['name'];
        echo "Engineer Name: " . $report_name;
    } else {
        echo "Engineer not found.";
    }
} else {
    echo "No engineer assigned for this reference_id.";
}


// Step 1: Fetch the engineer_id from the mis table
$sql_mis = "SELECT report_drafter_to_technical FROM mis WHERE reference_id = ?";
$stmt_mis = $conn->prepare($sql_mis);
$stmt_mis->bind_param("s", $reference_id);
$stmt_mis->execute();
$result_mis = $stmt_mis->get_result();
$row_mis = $result_mis->fetch_assoc();
$stmt_mis->close(); 

if ($row_mis) {
    $report_drafter_to_technical = $row_mis['report_drafter_to_technical'];

    // Step 2: Fetch the engineer's name from engineer_login table
    $sql_engineer = "SELECT name FROM technical_login WHERE technical_manager_id = ?";
    $stmt_engineer = $conn->prepare($sql_engineer);
    $stmt_engineer->bind_param("s", $report_drafter_to_technical);
    $stmt_engineer->execute();
    $result_engineer = $stmt_engineer->get_result();
    $row_engineer = $result_engineer->fetch_assoc();
    $stmt_engineer->close();

    if ($row_engineer) {
        $technical_name = $row_engineer['name'];
        echo "Engineer Name: " . $technical_name;
    } else {
        echo "Engineer not found.";
    }
} else {
    echo "No engineer assigned for this reference_id.";
}


?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Criss Report</title>
    <link rel="shortcut icon" href="favicon.png" type="image/x-icon"> 
    <link rel="stylesheet" href="criss3.css">
</head>
<body>
    <div class="container">
        <header>
            <div class="footer">
            <div class="logo">
                <img <img src="images/Magpie_logo.jpg" alt="Magpie Logo">
            </div>
            <div class="header-content">
                <h1>MAGPIE ENGINEERING PVT. LTD.</h1>
                <p>Valuer Designer Architects</p>
                <p>Address : Office no. 201, 2nd floor, Gravity Mall, Mechanic nagar, warehouse road, near vijay nagar, Indore, Madhya Pradesh- 452011</p>
            </div>
            </div>
        </header>

        <!-- Section 1 -->
         <h3> VALUATION REPORT FOR CRISS FINANCE </h3>
        <div class="section">
            <table>
                <tr>
                  
                    <th colspan="4" class="section-title">Section-1</th>
                </tr>
                <tr>
                    <th>Date of technical visit</th>
                    <td><input type="text" name="report_assigned_at" placeholder="Enter date" value="<?= $data1['assigned_at'] ?? '' ?>"></td>
                    <th>Type of Product</th>
                    <td><input type="text" name="caseType"  value="<?= $data1['caseType'] ?? '' ?>"></td>
                </tr>
                <tr>
                    <th>Application No.</th>
                    <td  colspan="3"><input type="text" name="applicationNo"  value="<?= $data1['applicationNo'] ?? '' ?>"></td>
                </tr>
                <tr>
                    <th>Serial No</th>
                    <td  colspan="3"><input type="text" name="applicationNo"  value="<?= $data1['applicationNo'] ?? '' ?>"></td>
                </tr>
                <tr>
                    <th>Name of Customer</th>
                    <td colspan="3"><input type="text" name="customerName" value="<?= $data1['customerName'] ?? '' ?>"></td>
                </tr>
                <tr>
                    <th>Co-Applicant</th>
                    <td colspan="3"><input type="text" name="co_applicant_name" value="<?= $data1['co_applicant_name'] ?? '' ?>"></td>
                </tr>
                <tr>
                    <th>Ownership as per document</th>	
                    <td colspan="3"><input type="text" name="customerName" value="<?= $data9['owner_name'] ?? '' ?>"></td>
                </tr>
                <tr>
                    <th>Contact No. of customer</th>
                    <td  colspan="3"><input type="text" name="customerName" value="<?= $data1['customerMob'] ?? '' ?>"></td>
                </tr>
                <tr>
                    <th>Lease Hold or Free Hold</th>
                    <td  colspan="3"><input type="text" name="engineer_id"  value="<?= $data2['property_leasehold_freehold'] ?? '' ?>"></td>
                </tr>
                <tr>
                    <th>Occupation status</th>
                    <td  colspan="3"><input type="text" name="occupancy_status" value="<?= $data2['occupancy_status'] ?? '' ?>"></td>
                </tr>
                <tr>
                    <th>Property title</th>
                    <td  colspan="3"><input type="text" name="customerName" value="<?= $data10['NA'] ?? '' ?>"></td> 
                </tr>
                <tr>
                    <th>Documents Provided for Valuation</th>
                    <td  colspan="3"><input type="text" name="customerName" value="<?= $data1['document_provided_for_valuation'] ?? '' ?>"></td>
                </tr>
                <tr>
                    <th>Population of Village (G.P)</th>
                    <td  colspan="3"><input type="text" name="NA" value="NA"></td>
                </tr>
                <tr>
                    <th>Development</th>
                    <td colspan="3"><input type="text" name="customerName" value="<?= $data2['develop_percent'] ?? '' ?>%"></td>
                </tr>
            </table>
        </div>
        <table>
            <tr>
                <th>Address of Property as per Document</th>
                <td  colspan="3"><?= htmlspecialchars($data3['address_per_document'] ?? '') ?></td>
            </tr>
            <tr>
                <th>Address of Property as per Actual</th>
                <td  colspan="3"><input type="text" name="engineer_id"  value="<?= $data3['address_per_site'] ?? '' ?> "></td>
            </tr>
            <tr>
                <th>Address Pin Code</th>
                <td><input type="text" name="engineer_id"  value="<?= $data3['pin_code'] ?? '' ?>"></td>
                <th>Property Lies In Area</th>
                <td><input type="text" name="engineer_id"  value="<?= $data2['surrounding_infrastructure'] ?? '' ?>"></td>
            </tr>
            <tr>
                <th>Person met at site and his relationship with owner or applicant of the property</th>
                <td><input type="text" name="engineer_id"  value="<?= $data2['person_meet_at_site_contact'] ?? '' ?>"></td>
                <th>Electricity Meter</th>
                <td><input type="text" name="engineer_id"  value="<?= $data2['electric_meter_no'] ?? '' ?>"></td>
            </tr>
            <tr>
    <th>Area of land (Sq.mt.)</th>
    <td  colspan="3">
        <input type="text" name="engineer_id"  
               value="<?= isset($data6['plot_square_feet']) ? round($data6['plot_square_feet'] * 0.092903, 2) : '' ?>">
    </td>
</tr>
<tr>
    <th>Area of land (Sq.yd)</th>
    <td  colspan="3">
        <input type="text" name="engineer_id"  
               value="<?= isset($data6['plot_square_feet']) ? round($data6['plot_square_feet'] / 9, 2) : '' ?>">
    </td>
</tr>
            <tr>
                <th >Area of land (Sq.ft.)</th>
                <td  colspan="3"><input type="text" name="engineer_id"  value="<?= $data6['plot_square_feet'] ?? '' ?>"></td>
            </tr>
            <tr>
                <th>Plinth area of house (Sq.ft.)</th>
                <td  colspan="3"><input type="text" name="engineer_id"  value="<?= $data8['plinth_present_completion'] ?? '' ?> (in %)"></td>
            </tr>
            <tr>
                <th>Built up area of house (Sq.ft.)</th>
                <td  colspan="3"><input type="text" name="engineer_id"  value="<?= $data6['actual_construction_square_feet'] ?? '' ?>"></td>
            </tr>
        </table>
    
        <br>
        <table>
            <tr>
                <th>Area Detail</th>
                <th>Actual Area (Sq.ft)</th>
                <th>Permissible Area (Sq.ft)</th>
            </tr>
            <tr>
                <th>Basement</th>
                <td><input type="text" name="engineer_id"  value="<?= $data8['area_basements'] ?? '' ?>"></td>
                <td><input type="text" name="engineer_id"  value="<?= $data10['NA'] ?? '' ?>"></td>
            </tr>
            <tr>
                <th>Ground Floor Rec</th>
                <td><input type="text" name="engineer_id"  value="<?= $data8['area_grounds'] ?? '' ?>"></td>
 <td><input type="text" name="engineer_id"  value="<?= $data10['NA'] ?? '' ?>"></td>            </tr>
            <tr>
                <th>First Floor</th>
                <td><input type="text" name="engineer_id"  value="<?= $data8['area_upper_floor'] ?? '' ?>"></td>
                <td><input type="text" name="engineer_id"  value="<?= $data10['NA'] ?? '' ?>"></td>            </tr>
            <tr>
                <th>Second Floor</th>
                <td><input type="text" name="engineer_id"  value="<?=$data8['area_upper_floor']?? '' ?>"></td>
                <td><input type="text" name="engineer_id"  value="<?= $data10['NA'] ?? '' ?>"></td>            </tr>
            <tr>
                <th>Total Built up area of house in sqft.</th>
                <td><input type="text" name="engineer_id"  value="<?= $data6['actual_construction_square_feet'] ?? '' ?>"></td>
                <td><input type="text" name="engineer_id"  value="<?= $data6['construction_square_feet'] ?? '' ?>"></td>            </tr>
            <tr>
                <th>Total Permissible Built up area of house in sqft.</th>
                <td><input type="text" name="engineer_id"  value="<?= $data6['actual_construction_square_feet'] ?? '' ?>"></td>
                <td><input type="text" name="engineer_id"  value="<?= $data6['construction_square_feet'] ?? '' ?>"></td>            </tr>
        </table>
    
        <div class="section-title">Section 3</div>
        <table>
            <tr>
                <th colspan="2">Usage (Residential / Partly Commercial / Fully Commercial)</th>
                <td colspan="2"><input type="text" name="engineer_id"  value="<?= $data4['current_property_usage'] ?? '' ?>  <?= $data4['approved_property_usage'] ?? '' ?>"></td>
            </tr>
            <tr>
                <th colspan="2">Ratio of each type (Residential/Commercial)</th>
                <td colspan="2"><input type="text" name="engineer_id"  value="<?= $data10['NA'] ?? '' ?>"></td>
            </tr>
            <tr>
                <th colspan="2">Nature of Construction</th>
                <td colspan="2"><input type="text" name="engineer_id"  value="<?= $data4['structure_type']?? '' ?>"></td>
            </tr>
            <tr>
                <th>Age of the property (50 Years)</th>
                <td><input type="text" name="engineer_id"  value="<?= $data2['age_of_property'] ?? '' ?>"></td>
                <th>Residual age</th>
                <td><input type="text" name="engineer_id"  value="<?= $data2['residual_age_of_property'] ?? '' ?>"></td>
            </tr>
            <tr>
                <th>Occupant (If occupied, Name of the Occupant)</th>
                <td colspan="3"><input type="text" name="engineer_id"  value="<?= $data2['occupant_name'] ?? '' ?>"></td>
            </tr>
            <tr>
                <th>If rented, list of occupants</th>
                <td colspan="3"><input type="text" name="engineer_id"  value="<?= $data2['NA'] ?? '' ?>"></td>
            </tr>
            <tr>
                <th>Plot demarcated at site</th>
                <td><input type="text" name="engineer_id"  value="<?= $data2['demarcated_at_site'] ?? '' ?>"></td>
                <th>Property Identified through</th>
                <td><input type="text" name="engineer_id"  value="<?= $data2['NA'] ?? '' ?>"></td>
            </tr>
        </table>
    
        <br>
        <div class="section-title">Locality Details</div>
        <table>
            <tr>
                <th>Distance from to the Branch</th>
                <td><input type="text" name="engineer_id"  value="<?= $data3['distance_from_branch_kms'] ?? '' ?>"></td>
                <th>Near By landmark</th>
                <td><input type="text" name="engineer_id"  value="<?= $data3['landmark_1'] ?? '' ?>"></td>
            </tr>
            <tr>
                <th>Nearest Railway station</th>
                <td><input type="text" name="engineer_id"  value="<?= $data3['nearest_railway_station_name'] ?? '' ?>   <?= $data3['nearest_railway_station_distance'] ?? '' ?>"></td>

                <th>Type of Locality</th>
                <td><input type="text" name="engineer_id"  value="<?= $data2['class_of_locality'] ?? '' ?>"></td>
            </tr>
            <tr>
                <th>Nearest Bus stand</th>
                <td><input type="text" name="engineer_id"  value="<?= $data3['nearest_bus_stop_name'] ?? '' ?>  <?= $data3['nearest_bus_stop_distance'] ?? '' ?>"></td>
                <th>Condition of Approach Road</th>
                <td><input type="text" name="engineer_id"  value="<?= $data2['type_of_approach_road'] ?? '' ?>   <?= $data2['width_of_approach_road'] ?? '' ?>"></td>
            </tr>
            <tr>
                <th>Nearest City center</th>
                <td><input type="text" name="engineer_id"  value="<?= $data2['NA'] ?? '' ?>"></td>
                <th>Seismic Zone</th>
                <td><input type="text" name="engineer_id"  value="<?= $data4['seismic_zone'] ?? '' ?>"></td>
            </tr>
        </table>
    
        <br>
        <div class="section-title">Dimension Detail</div>
        <table>
            <tr>
                <th>Description</th>
                <th>North</th>
                <th>South</th>
                <th>East</th>
                <th>West</th>
            </tr>
            <tr>
                <th>As Per Document</th>
                <td><input type="text" name="engineer_id"  value="<?= $data6['dimension_as_per_document_north'] ?? '' ?>"></td>
                <td><input type="text" name="engineer_id"  value="<?= $data6['dimension_as_per_document_south'] ?? '' ?>"></td>
                <td><input type="text" name="engineer_id"  value="<?= $data6['dimension_as_per_document_east'] ?? '' ?>"></td>
                <td><input type="text" name="engineer_id"  value="<?= $data6['dimension_as_per_document_west'] ?? '' ?>"></td>
            </tr>
            <tr>
                <th>As per Actual</th>
                <td><input type="text" name="engineer_id"  value="<?= $data6['dimension_as_per_site_north'] ?? '' ?>"></td>
                <td><input type="text" name="engineer_id"  value="<?= $data6['dimension_as_per_site_south'] ?? '' ?>"></td>
                <td><input type="text" name="engineer_id"  value="<?= $data6['dimension_as_per_site_east'] ?? '' ?>"></td>
                <td><input type="text" name="engineer_id"  value="<?= $data6['dimension_as_per_site_west'] ?? '' ?>"></td>            </tr>
        </table>

        <!-- Boundaries Detail -->
        <div class="section">
            <div class="section-title">Boundaries Detail</div>
            <table>
                <tr>
                    <td>Description</td>
                    <td>North</td>
                    <td>South</td>
                    <td>East</td>
                    <td>West</td>
                </tr>
                <tr>
                    <td>As Per Document</td>
                    <td><input type="text" name="engineer_id"  value="<?= $data3['direction_as_per_document_north'] ?? '' ?>"></td></td>
                    <td><input type="text" name="engineer_id"  value="<?= $data3['direction_as_per_document_south'] ?? '' ?>"></td></td>
                    <td><input type="text" name="engineer_id"  value="<?= $data3['direction_as_per_document_east'] ?? '' ?>"></td></td>
                    <td><input type="text" name="engineer_id"  value="<?= $data3['direction_as_per_document_west'] ?? '' ?>"></td></td>
                </tr>           
                <tr>
                    <td>As Per Actual</td>
                    <td><input type="text" name="engineer_id"  value="<?= $data3['direction_as_per_site_north'] ?? '' ?>"></td></td>
                    <td><input type="text" name="engineer_id"  value="<?= $data3['direction_as_per_site_south'] ?? '' ?>"></td></td>
                    <td><input type="text" name="engineer_id"  value="<?= $data3['direction_as_per_site_east'] ?? '' ?>"></td></td>
                    <td><input type="text" name="engineer_id"  value="<?= $data3['direction_as_per_site_west'] ?? '' ?>"></td></td>
                </tr>
                <tr>
                    <td>Approach Road</td>
                    <td colspan="4"><input type="text" name="approach_road" value="<?= $data2['approach_road_to_property'] ?? '' ?>"></td>
                </tr>
            </table>
        </div>

        <!-- Section 4 -->
        <div class="section-title">Section 4</div>
        <table>
            <tr>
                <th>Setbacks</th>
                <th>As per Government by Laws</th>
                <th>Actual Setbacks</th>
            </tr>
            <tr>
                <td>Front</td>
                <td contenteditable="true"><input type="text" name="engineer_id"  value="<?= $data2['NA'] ?? '' ?>"></td>
                <td contenteditable="true"><input type="text" name="engineer_id"  value="<?= $data2['NA'] ?? '' ?>"></td>
            </tr>
            <tr>
                <td>Back</td>
                <td contenteditable="true"><input type="text" name="engineer_id"  value="<?= $data2['NA'] ?? '' ?>"></td>
                <td contenteditable="true"><input type="text" name="engineer_id"  value="<?= $data2['NA'] ?? '' ?>"></td>
            </tr>
            <tr>
                <td>Side</td>
                <td contenteditable="true"><input type="text" name="engineer_id"  value="<?= $data2['NA'] ?? '' ?>"></td>
                <td contenteditable="true"><input type="text" name="engineer_id"  value="<?= $data2['NA'] ?? '' ?>"></td>
            </tr>
            <tr>
                <td>Side</td>
                <td contenteditable="true"><input type="text" name="engineer_id"  value="<?= $data2['NA'] ?? '' ?>"></td>
                <td contenteditable="true"><input type="text" name="engineer_id"  value="<?= $data2['NA'] ?? '' ?>"></td>
            </tr>
            <tr>
                <td>Type of Structure</td>
                <td contenteditable="true"><input type="text" name="engineer_id"  value="<?= $data4['structure_type'] ?? '' ?>"></td>
                <td contenteditable="true"><input type="text" name="engineer_id"  value="<?= $data8['Present_quality_of_structure'] ?? '' ?>"></td>

            </tr>
            <tr>
                <td>No. of Floors (Actual)</td>
                <td colspan="2" contenteditable="true"><input type="text" name="engineer_id"  value="<?= $data10['NA'] ?? '' ?>"></td>
            </tr>
            <tr>
                <td>Internal composition of the property</td>
                <td colspan="2" contenteditable="true"><input type="text" name="engineer_id"  value="<?= $data2['NA'] ?? '' ?>"></td>
            </tr>
            <tr>
                <td>Availability of basic amenities viz, electricity, water</td>
                <td colspan="2" contenteditable="true"><input type="text" name="engineer_id"  value="<?= $data2['electric_meter_no'] ?? '' ?>"></td>
            </tr>
            <tr>
                <td>Violation observed if any Or is there any risk of demolition in case of violation</td>
                <td colspan="2" contenteditable="true"><input type="text" name="engineer_id"  value="<?= $data9['demolition_risk_1'] ?? '' ?>"></td>
            </tr>
    
            <tr>
                <td>Structure confirming to safety (Load resistance)</td>
                <td colspan="2" contenteditable="true"><input type="text" name="engineer_id"  value="<?= $data10['NA'] ?? '' ?>"></td>
            </tr>
    
            <tr>
                <td>If plans not available then is the structure confirming to the local practice</td>
                <td colspan="2" contenteditable="true"><input type="text" name="engineer_id"  value="<?= $data10['NA'] ?? '' ?>"></td>
            </tr>
            <tr>
                <td>As per visual inspections & maintenance levels - Does the Structure raise any concern in event of earthquake, cyclones etc.</td>
                <td colspan="2" contenteditable="true"><input type="text" name="engineer_id"  value="NO"></td>
            </tr>
            <tr>
                <td>Any other features like board of the financier indicating mortgage, notice of court/any authority which may affect the security</td>
                <td colspan="2" contenteditable="true"><input type="text" name="engineer_id"  value="<?= $data10['NA'] ?? '' ?>"></td>
            </tr>
            <tr>
                <td>Whether Construction of the Building is meeting all the norms of NDMA Guidelines</td>
                <td colspan="2" contenteditable="true"><input type="text" name="engineer_id"  value="<?= $data10['NA'] ?? '' ?>"></td>
            </tr>
        </table>

        <!-- Section 5 -->
        <div class="section-title">Section 5</div>
    <table>
        <tr>
            <th colspan="4">VALUE AS PER GOVERNMENT (DLC)</th>
        </tr>
        <tr>
            <th>Particulars</th>
            <th>Area</th>
            <th>Rate</th>
            <th>Value</th>
        </tr>
        <tr>
            <td>Cost of Land (Sq.ft.)</td>
            <td contenteditable="true"><input type="text" name="engineer_id"  value="<?= $data6['plot_square_feet'] ?? '' ?>"></td>
            <td contenteditable="true"><input type="text" name="engineer_id"  value="<?= $data6['actual_plot_rate'] ?? '' ?>"></td>
            <td contenteditable="true"><input type="text" name="engineer_id"  value="<?= $data6['plot_valuation_computed'] ?? '' ?>"></td>
        </tr>
        <tr>
            <td>Ground Floor (Rec)</td>
            <td contenteditable="true"><input type="text" name="engineer_id"  value="<?= $data6['carpet_square_feet'] ?? '' ?>"></td>
            <td contenteditable="true"><input type="text" name="engineer_id"  value="<?= $data6['actual_carpet_rate'] ?? '' ?>"></td>
            <td contenteditable="true"><input type="text" name="engineer_id"  value="<?= $data6['carpet_valuation_computed'] ?? '' ?>"></td>
        </tr>
        <tr>
            <td>Ground Floor Tin Shed </td>
            <td contenteditable="true"><input type="text" name="engineer_id"  value="<?= $data2['NA'] ?? '' ?>"></td>
            <td contenteditable="true"><input type="text" name="engineer_id"  value="<?= $data2['NA'] ?? '' ?>"></td>
            <td contenteditable="true"><input type="text" name="engineer_id"  value="<?= $data2['NA'] ?? '' ?>"></td>
        </tr>
        <tr>
            <td>First Floor</td>
            <td contenteditable="true"><input type="text" name="engineer_id"  value="<?= $data2['NA'] ?? '' ?>"></td>
            <td contenteditable="true"><input type="text" name="engineer_id"  value="<?= $data2['NA'] ?? '' ?>"></td>
            <td contenteditable="true"><input type="text" name="engineer_id"  value="<?= $data2['NA'] ?? '' ?>"></td>
        </tr>
        <tr class="total">
            <td>Total Cost of Existing Property</td>
            <td colspan="3" contenteditable="true"><input type="text" name="engineer_id"  value="<?= $data6['total_finally_area_valuation'] ?? '' ?>"></td>
        </tr>
    </table>
    <br>
    <table>
        <tr>
            <th colspan="4">MARKET VALUE</th>
        </tr>
        <tr>
            <th>Particulars</th>
            <th>Area</th>
            <th>Rate</th>
            <th>Value</th>
        </tr>
        <tr>
            <td>Cost of Land (Sq.ft.)</td>
            <td contenteditable="true"><input type="text" name="engineer_id"  value="<?= $data6['actual_plot_square_feet'] ?? '' ?>"></td>
            <td contenteditable="true"><input type="text" name="engineer_id"  value="<?= $data6['actual_plot_rate'] ?? '' ?>"></td>
            <td contenteditable="true"><input type="text" name="engineer_id"  value="<?= $data6['actual_plot_valuation_computed'] ?? '' ?>"></td>
        </tr>
        <tr>
            <td>Ground Floor Rec</td>
            <td contenteditable="true"><input type="text" name="engineer_id"  value="<?= $data6['actual_carpet_square_feet'] ?? '' ?>"></td>
            <td contenteditable="true"><input type="text" name="engineer_id"  value="<?= $data6['actual_carpet_rate'] ?? '' ?>"></td>
            <td contenteditable="true"><input type="text" name="engineer_id"  value="<?= $data6['actual_carpet_valuation_computed'] ?? '' ?>"></td>
            
        </tr>
        <tr>
            <td>Ground Floor Tin Shed</td>
            <td contenteditable="true"><input type="text" name="engineer_id"  value="<?= $data2['NA'] ?? '' ?>"></td>
            <td contenteditable="true"><input type="text" name="engineer_id"  value="<?= $data2['NA'] ?? '' ?>"></td>
            <td contenteditable="true"><input type="text" name="engineer_id"  value="<?= $data2['NA'] ?? '' ?>"></td>
        </tr>
        <tr>
            <td>First  Floor</td>
            <td contenteditable="true"><input type="text" name="engineer_id"  value="<?= $data2['NA'] ?? '' ?>"></td>
            <td contenteditable="true"><input type="text" name="engineer_id"  value="<?= $data2['NA'] ?? '' ?>"></td>
            <td contenteditable="true"><input type="text" name="engineer_id"  value="<?= $data2['NA'] ?? '' ?>"></td>
        </tr>
        <tr class="total">
            <td>Total Cost of Property</td>
            <td colspan="3" contenteditable="true"><input type="text" name="engineer_id"  value="<?=$data6['total_finally_area_valuation'] ?? '' ?>"></td>
        </tr>
        <tr>
            <td>QSV / Distress Value (85%)</td>
            <td colspan="3" contenteditable="true"><input type="text" name="engineer_id"  value="<?= $data6['total_distress_value'] ?? '' ?>"></td>
        </tr>
        <tr>
            <td>Price confirm from</td>
            <td colspan="3" contenteditable="true"><input type="text" name="engineer_id"  value="Sanjay Saini"></td>
        </tr>
        <tr>
            <td>Market Rate in Locality</td>
            <td colspan="3" contenteditable="true"><input type="text" name="engineer_id"  value="<?= $data6['actual_plot_square_feet'] ?? '' ?>"></td>
        </tr>
        <tr>
            <td>Last Visit Date</td>
            <td colspan="3" contenteditable="true"><input type="text" name="engineer_id"  value="<?=  $data1['fe_to_coordinator_assign_at'] ?? '' ?>"></td>
        </tr>
        <tr>
            <td>Stage of Construction</td>
            <td colspan="3" contenteditable="true"><input type="text" name="engineer_id"  value="<?= $data8['stage_construction_actual_present_completion'] ?? '' ?>%"></td>
        </tr>
    </table>  
                  
      <table>
            <tr><th colspan="7">Remarks:-</th></tr>
             <td>     <textarea rows="25"  id="remarks" name="engineer_id" oninput="autoResize(this)"><?= $data10['remarks'] ?? '' ?></textarea>
             </td>
            </table>
        <table class="remarks-table">
            <thead>
                <tr>
                    <th colspan="4"> DECLARATION </th>
                </tr>
            </thead>
            <tbody>
                <tr>
                    <td class="remarks">
                 
                    <textarea rows="10" placeholder="Enter Property DECLARATION" name="engineer_id"><?= $data10['declaration'] ?? '' ?></textarea>
                    </td>
                </tr>
            </tbody>
        </table>

        <table>
            <thead>
                <tr>
                    <th>Latitude</th>
                    <th>Longitude</th>

                </tr>
            </thead>
            <tbody>
                <tr>
                    <td contenteditable="true"><input type="text" name="engineer_id"  value="<?= $data3['latitude_value'] ?? '' ?>"></td>
                    <td contenteditable="true"><input type="text" name="engineer_id"  value="<?= $data3['longitude_value'] ?? '' ?>"></td>
                </tr>
                
            </tbody>
        </table>

        <div class="container">
            <div class="header">
            <h2 style="font-style: italic;">IMAGE UPLOAD FORM</h2>
        </div>
        <div class="image-gallery">

<?php
// Database connection
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "project_db"; // Replace with your database name
$message = "";
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Step 2: Retrieve reference_id from session (if set)
$reference_id = $_SESSION['reference_id'] ?? null;

// Fetch reference_id from GET or session
$reference_id = isset($_GET['reference_id']) ? $_GET['reference_id'] : $reference_id;

// Ensure reference_id is available
if ($reference_id) {
    // Fetch the images from the database using a prepared statement
    $sql = "SELECT 
                image1, image2, image3, image4, image5, 
                image6, image7, image8, image9, image10, 
                image11, image12 
            FROM final_uploaded_images 
            WHERE reference_id = ?";

    $stmt = $conn->prepare($sql);
    if ($stmt === false) {
        die("Error preparing the SQL statement: " . $conn->error);
    }

    // Bind the parameter
    $stmt->bind_param("s", $reference_id); // "s" indicates the parameter is a string

    // Execute the statement
    $stmt->execute();

    // Get the result
    $result = $stmt->get_result();

    if ($result->num_rows > 0) {
        while ($row = $result->fetch_assoc()) {
            if (!empty($row['image1'])) {
                echo '<div>';
                echo '<img src="data:image/jpeg;base64,' . base64_encode($row['image1']) . '" alt="Image 1">';
                echo '<p>EXTERNAL PHOTOS</p>';
                echo '</div>';
            }
            if (!empty($row['image2'])) {
                echo '<div>';
                echo '<img src="data:image/jpeg;base64,' . base64_encode($row['image2']) . '" alt="Image 2">';
                echo '<p>Kitchen</p>';
                echo '</div>';
            }
            if (!empty($row['image3'])) {
                echo '<div>';
                echo '<img src="data:image/jpeg;base64,' . base64_encode($row['image3']) . '" alt="Image 3">';
                echo '<p>Selfie</p>';
                echo '</div>';
            }
            if (!empty($row['image4'])) {
                echo '<div>';
                echo '<img src="data:image/jpeg;base64,' . base64_encode($row['image4']) . '" alt="Image 4">';
                echo '<p>Electric Meter</p>';
                echo '</div>';
            }
            if (!empty($row['image5'])) {
                echo '<div>';
                echo '<img src="data:image/jpeg;base64,' . base64_encode($row['image5']) . '" alt="Image 5">';
                echo '<p>Google Map</p>';
                echo '</div>';
            }
            if (!empty($row['image6'])) {
                echo '<div>';
                echo '<img src="data:image/jpeg;base64,' . base64_encode($row['image6']) . '" alt="Image 6">';
                echo '<p>Other 1</p>';
                echo '</div>';
            }
            if (!empty($row['image7'])) {
                echo '<div>';
                echo '<img src="data:image/jpeg;base64,' . base64_encode($row['image7']) . '" alt="Image 7">';
                echo '<p>Other 2</p>';
                echo '</div>';
            }
            if (!empty($row['image8'])) {
                echo '<div>';
                echo '<img src="data:image/jpeg;base64,' . base64_encode($row['image8']) . '" alt="Image 8">';
                echo '<p>Other 3</p>';
                echo '</div>';
            }
            if (!empty($row['image9'])) {
                echo '<div>';
                echo '<img src="data:image/jpeg;base64,' . base64_encode($row['image9']) . '" alt="Image 9">';
                echo '<p>Other 4</p>';
                echo '</div>';
            }
            if (!empty($row['image10'])) {
                echo '<div>';
                echo '<img src="data:image/jpeg;base64,' . base64_encode($row['image10']) . '" alt="Image 10">';
                echo '<p>Other 5</p>';
                echo '</div>';
            }
            if (!empty($row['image11'])) {
                echo '<div>';
                echo '<img src="data:image/jpeg;base64,' . base64_encode($row['image11']) . '" alt="Image 11">';
                echo '<p>Other 6</p>';
                echo '</div>';
            }
            if (!empty($row['image12'])) {
                echo '<div>';
                echo '<img src="data:image/jpeg;base64,' . base64_encode($row['image12']) . '" alt="Image 12">';
                echo '<p>Other 7</p>';
                echo '</div>';
            }
        }
    } else {
        echo "<p style='text-align:center;'>No images found.</p>";
    }

    // Close the statement
    $stmt->close();
} else {
    echo "<p style = 'text-align:center;'>Reference ID is missing.</p>";
}
?>
</div>
  </table>
    </div>
    <!-- <button onclick="window.print()">Download PDF</button> -->
  <button id="downloadPdf" onclick="setPrintMargins()">DOWNLOAD PDF</button>
  <script>
    document.getElementById('downloadPdf').addEventListener('click', () => {
      // Select the content you want to convert to PDF
      const element = document.getElementById('content');
      const options = {
        margin:[0,0],
        filename:'report.pdf',
        image: { type: 'jpeg', quality: 0.98 },
        html2canvas: { scale: 2 },
        jsPDF: { unit: 'in', format: 'letter', orientation: 'portrait' }
      };

      // Generate and download the PDF
      html2pdf().set(options).from(element).save();
    });
    function setPrintMargins() {
      const style = document.createElement('style');
      style.innerHTML = `
      @media print {
          body {
            margin:0.5;
          }
        }
      `;
      document.head.appendChild(style);
      window.print();
    }
    // Disable all input fields in the form
    document.querySelectorAll('input').forEach(function(input) {
        input.disabled = true;  // Disables the field completely
    });
    </script>
</body>
</html>
