<?php include('auth.php'); ?>
<?php
ini_set('display_errors', 1);
error_reporting(E_ALL);

// Increase PHP execution time and memory limit
ini_set('max_execution_time', 600); // Increase execution time to 600 seconds (10 minutes)
ini_set('memory_limit', '4096M'); // Increase memory limit to 4096MB
// Start session


$servername = "localhost";
$username = "root";
$password = "";
$dbname = "project_db";

// Create DB connection
$conn = new mysqli($servername, $username, $password, $dbname);
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

if (!isset($_SESSION['reference_id'])) {
    die("Reference ID not found in session.");
}
$reference_id = $_SESSION['reference_id'];

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['download_images'])) {

    // Get customer name
    $stmt_name = $conn->prepare("SELECT customerName FROM mis WHERE reference_id = ?");
    $stmt_name->bind_param("s", $reference_id);
    $stmt_name->execute();
    $result_name = $stmt_name->get_result();
    $customerName = "customer";
    if ($row = $result_name->fetch_assoc()) {
        $customerName = preg_replace('/[^a-zA-Z0-9]/', '', $row['customerName']);
    }
    $stmt_name->close();

    // Fetch image BLOBs
    $stmt = $conn->prepare("SELECT image1, image2, image3, image4, image5, image6, image7, image8, image9, image10, image11, image12,image13, image14, image15, image16, image17, image18, image19, image20 FROM final_uploaded_images WHERE reference_id = ?");
    $stmt->bind_param("s", $reference_id);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows > 0 && ($row = $result->fetch_assoc())) {
        $tempDir = sys_get_temp_dir() . DIRECTORY_SEPARATOR . uniqid('images_', true);
        mkdir($tempDir);

        $imageFiles = [];
        for ($i = 1; $i <= 12; $i++) {
            if (!empty($row["image$i"])) {
                $filename = $tempDir . DIRECTORY_SEPARATOR . "image{$i}.jpg";
                file_put_contents($filename, $row["image$i"]);
                $imageFiles[] = $filename;
            }
        }

        if (empty($imageFiles)) {
            die("No images to download.");
        }

        // Create ZIP
        $zipFileName = "images_" . preg_replace('/[^a-zA-Z0-9]/', '_', $reference_id) . "_{$customerName}.zip";
        $zipPath = $tempDir . DIRECTORY_SEPARATOR . $zipFileName;

        $zip = new ZipArchive();
        if ($zip->open($zipPath, ZipArchive::CREATE) !== TRUE) {
            die("Failed to create ZIP file.");
        }

        foreach ($imageFiles as $file) {
            $zip->addFile($file, basename($file));
        }
        $zip->close();

        // Send ZIP to browser
        header('Content-Type: application/zip');
        header('Content-Disposition: attachment; filename="' . basename($zipFileName) . '"');
        header('Content-Length: ' . filesize($zipPath));
        flush();
        readfile($zipPath);

        // Cleanup
        foreach ($imageFiles as $file) {
            unlink($file);
        }
        unlink($zipPath);
        rmdir($tempDir);
        exit;
    } else {
        echo "<p style='color:red;'>No image data found for this reference ID.</p>";
    }
}

$page = isset($_GET['page']) ? $_GET['page'] : 1;
$limit = 50;
$offset = ($page - 1) * $limit;
$sql_property = "SELECT * FROM mis WHERE reference_id = ? LIMIT $limit OFFSET $offset";
$stmt_property = $conn->prepare($sql_property);
$stmt_property->bind_param("s", $reference_id);
$stmt_property->execute();
$result_property = $stmt_property->get_result();
$data1 = $result_property->fetch_assoc();




// Fetch data from property_details table
$sql_property = "SELECT * FROM property_details WHERE reference_id = ?";
$stmt_property = $conn->prepare($sql_property);
$stmt_property->bind_param("s", $reference_id);
$stmt_property->execute();
$result_property = $stmt_property->get_result();
$data2= $result_property->fetch_assoc();




// Fetch data from area_valuation table
$sql_area = "SELECT * FROM address_details WHERE reference_id = ?";
$stmt_area = $conn->prepare($sql_area); 
$stmt_area->bind_param("s", $reference_id);
$stmt_area->execute();
$result_area = $stmt_area->get_result();
$data3 = $result_area->fetch_assoc();





// Fetch data from area_valuation table
$sql_area = "SELECT * FROM critical_parameters WHERE reference_id = ?";
$stmt_area = $conn->prepare($sql_area); 
$stmt_area->bind_param("s", $reference_id);
$stmt_area->execute();
$result_area = $stmt_area->get_result();
$data4 = $result_area->fetch_assoc();

 
// Fetch data from area_valuation table
$sql_area = "SELECT * FROM surroundings_details WHERE reference_id = ?";
$stmt_area = $conn->prepare($sql_area); 
$stmt_area->bind_param("s", $reference_id);
$stmt_area->execute();
$result_area = $stmt_area->get_result();
$data5 = $result_area->fetch_assoc();
$stmt_area->close();
 
// Fetch data from area_valuation table
$sql_area = "SELECT * FROM area_valuation WHERE reference_id = ?";
$stmt_area = $conn->prepare($sql_area); 
$stmt_area->bind_param("s", $reference_id);
$stmt_area->execute();
$result_area = $stmt_area->get_result();
$data6 = $result_area->fetch_assoc();
$stmt_area->close();
 



// Fetch data from area_valuation table
$sql_area = "SELECT * FROM floor_details WHERE reference_id = ?";
$stmt_area = $conn->prepare($sql_area); 
$stmt_area->bind_param("s", $reference_id);
$stmt_area->execute();
$result_area = $stmt_area->get_result();
$data8= $result_area->fetch_assoc();
$stmt_area->close();
 


// Fetch data from area_valuation table
$sql_area = "SELECT * FROM technical_details WHERE reference_id = ?";
$stmt_area = $conn->prepare($sql_area); 
$stmt_area->bind_param("s", $reference_id);
$stmt_area->execute();
$result_area = $stmt_area->get_result();
$data9 = $result_area->fetch_assoc();
$stmt_area->close();
 
// Fetch data from area_valuation table
$sql_area = "SELECT * FROM remarks_table WHERE reference_id = ?";
$stmt_area = $conn->prepare($sql_area); 
$stmt_area->bind_param("s", $reference_id);
$stmt_area->execute();
$result_area = $stmt_area->get_result();
$data10 = $result_area->fetch_assoc();
$stmt_area->close();


// Step 1: Fetch the engineer_id from the mis table
$sql_mis = "SELECT engineer_id FROM mis WHERE reference_id = ?";
$stmt_mis = $conn->prepare($sql_mis);
$stmt_mis->bind_param("s", $reference_id);
$stmt_mis->execute();
$result_mis = $stmt_mis->get_result();
$row_mis = $result_mis->fetch_assoc();
$stmt_mis->close(); 

if ($row_mis) {
    $engineer_id = $row_mis['engineer_id'];

    // Step 2: Fetch the engineer's name from engineer_login table
    $sql_engineer = "SELECT name FROM engineer_login WHERE engineer_id = ?";
    $stmt_engineer = $conn->prepare($sql_engineer);
    $stmt_engineer->bind_param("s", $engineer_id);
    $stmt_engineer->execute();
    $result_engineer = $stmt_engineer->get_result();
    $row_engineer = $result_engineer->fetch_assoc();
    $stmt_engineer->close();

    if ($row_engineer) {
        $engineer_name = $row_engineer['name'];
         //echo "Engineer Name: " . $engineer_name;
    } else {
        echo "Engineer not found.";
    }
} else {
    echo "No engineer assigned for this reference_id.";
}



// Step 1: Fetch the engineer_id from the mis table
$sql_mis = "SELECT report_id FROM mis WHERE reference_id = ?";
$stmt_mis = $conn->prepare($sql_mis);
$stmt_mis->bind_param("s", $reference_id);
$stmt_mis->execute();
$result_mis = $stmt_mis->get_result();
$row_mis = $result_mis->fetch_assoc();
$stmt_mis->close(); 

if ($row_mis) {
    $report_id = $row_mis['report_id'];

    // Step 2: Fetch the engineer's name from engineer_login table
    $sql_engineer = "SELECT name FROM report_login WHERE report_id = ?";
    $stmt_engineer = $conn->prepare($sql_engineer);
    $stmt_engineer->bind_param("s", $report_id);
    $stmt_engineer->execute();
    $result_engineer = $stmt_engineer->get_result();
    $row_engineer = $result_engineer->fetch_assoc();
    $stmt_engineer->close();

    if ($row_engineer) {
        $report_name = $row_engineer['name'];
         //echo "Engineer Name: " . $report_name;
    } else {
        echo "Engineer not found.";
    }
} else {
    echo "No engineer assigned for this reference_id.";
}


// Step 1: Fetch the engineer_id from the mis table
$sql_mis = "SELECT report_drafter_to_technical FROM mis WHERE reference_id = ?";
$stmt_mis = $conn->prepare($sql_mis);
$stmt_mis->bind_param("s", $reference_id);
$stmt_mis->execute();
$result_mis = $stmt_mis->get_result();
$row_mis = $result_mis->fetch_assoc();
$stmt_mis->close(); 

if ($row_mis) {
    $report_drafter_to_technical = $row_mis['report_drafter_to_technical'];

    // Step 2: Fetch the engineer's name from engineer_login table
    $sql_engineer = "SELECT name FROM technical_login WHERE technical_manager_id = ?";
    $stmt_engineer = $conn->prepare($sql_engineer);
    $stmt_engineer->bind_param("s", $report_drafter_to_technical);
    $stmt_engineer->execute();
    $result_engineer = $stmt_engineer->get_result();
    $row_engineer = $result_engineer->fetch_assoc();
    $stmt_engineer->close();

    if ($row_engineer) {
        $technical_name = $row_engineer['name'];
        //echo "Engineer Name: " . $technical_name;
    } else {
        echo "Engineer not found.";
    }
} else {
    echo "No engineer assigned for this reference_id.";
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Technical Initiation Request Form</title>
  <style>
    body {
  font-family: Arial, sans-serif;
  font-size: 14px;
}

table {
  width: 100%;
  border-collapse: collapse;
  table-layout: fixed;
}

th, td {
  border: 1px solid #999;
  padding: 6px;
  vertical-align: top;
  text-align: left;
}

input[type="text" readonly  value="<?= $data10['NA'] ?? '' ?>"] {
  width: 100%;
  border: none;
  font-size: 14px;
  padding: 4px;
  box-sizing: border-box;
  background-color: #fefefe;
}

.header-agency {
  background-color: #f9d7d7;
  font-weight: bold;
  text-align: center;
}

.section-title {
  background-color: #cbe2ce;
  text-align: center;
  font-size: 16px;
}
    
.content{
  width:auto;
  margin: 0 auto;
  margin-top:10px;
  background: #ffffff;
  padding:5px;
  margin-bottom: 0px;
  box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
  border: 1px solid black;
}

header {
  display: flex;
  align-items: center;
}

.logo img {
  width: 100px;
  margin-left:30px;
  height: auto;
}

.header-content {
  text-align: center;
  flex: 1;
}
   
         
.container {
            width: 90%;
            margin: 20px auto;
            padding: 20px;
        }
.header-content {
    text-align: center;
    flex: 1;
}

.header-content h1 {
    margin: 0;
    margin-top:25px;  
     font-size: 38px;
    color: #902d2d;
}

.header-content p {
    margin: 2px 0;
    font-size: 26px;
    color: #333;
}
.footer{
    display: flex;
}
      button{
  padding:8px;
  margin-left:45%;
  background-color: #f9d7d7;
  font-weight:500;
  font-style:italic;
}
button:hover{
  background-color: #cbe2ce;
}
@media print{
  body{
    margin:0;
  }
  button{
    display:none;
    margin-left:30%;
  }

  }
  </style>

   <style>
    body {
      font-family: Arial, sans-serif;
      font-size: 13px;
      padding: 20px;
    }

    table {
      width: 100%;
      border-collapse: collapse;
      table-layout: fixed;
    }

    td, th {
      border: 1px solid #000;
      padding: 6px;
      vertical-align: top;
    }

    .section-header {
      font-weight: bold;
      text-align: center;
    }

    input[ type="text" value="<?= $data10['NA'] ?? '' ?>"readonly], textarea {
      width: 100%;
      border: none;
      padding: 4px;
      font-size: 13px;
      box-sizing: border-box;
    }

header {
  display: flex;
  align-items: center;
}

.logo img {
  width: 120px;
  margin-left:30px;
  height: auto;
}

.header-content {
  text-align: center;
  flex: 1;
  margin-left:-190x
}

header h1 {
  margin: 0;
  font-weight:700;
  font-size:27px;
  color: #a60000;
  
}

header p {
  margin: 2px 0;
  font-size: 14px;
  font-weight: bolder;
  color: #9e2424;
  
}
    textarea {
      resize: vertical;
      min-height: 40px;
    }
       
/* Force a stable 4-column grid that wkhtmltopdf respects */
.image-gallery { width: 100%; }
.image-grid { width: 100%; border-collapse: collapse; table-layout: fixed; }
.image-grid tr { page-break-inside: avoid; }
.image-grid td { width: 25%; padding: 6px; vertical-align: top; }

.image-grid .img-wrap { display: block; }
.image-grid img { display: block; width: 100%; height: auto; }
.image-grid .caption { font-size: 12px; text-align: center; margin-top: 4px; }

/* If you had a flex layout before, neutralize it */
.image-gallery { display: block !important; }



    /* Print-specific rules */
    @media print {
      .no-print {
        display: none !important;
      }

      body {
        margin: 0;
      }
 
    }
  button{
    padding:8px;
    margin-left:45%;
    background-color:#808485;
    color:white;
    font-weight:700;
    font-style:italic;
  }
  button:hover{
    background-color:rgba(216,216,216,255);
    color:white;
  }
    .google-map-container {
    max-width: 90%;           /* Keep container within page width */
    margin: 20px auto;        /* Center it with spacing */
    border: 2px solid #ccc;   /* Light gray border */
    padding: 10px;
    box-shadow: 0 0 10px rgba(0, 0, 0, 0.1); /* Optional: subtle shadow */
    background-color: #f9f9f9; /* Optional: light background */
    border-radius: 8px;       /* Rounded corners */
    text-align: center;       /* Center image and caption */
}

.google-map-container img {
    max-width: 100%;          /* Scale image to container */
    height: auto;             /* Keep image aspect ratio */
    display: inline-block;
    border: 1px solid #999;   /* Border around the image itself */
    border-radius: 4px;
} 
  </style>
</head>
<body>
<div class="content">
    <header>
    <div class="logo">
        <img src="images/logo.png" alt=" Logo">
</div>
    <div class="header-content">
                <h1>MAGPIE ENGINEERING PVT. LTD.</h1>
                <p>Valuer Designer Architects</p>
                <p>Address : Office no. 201, 2nd floor, Gravity Mall, Mechanic nagar, warehouse road, near vijay nagar, Indore, Madhya Pradesh- 452011</p>
        
 </div>
</header>
</div> 
  <table>
    <tr>
      <th colspan="4" class="header-agency">Name of Valuation Agency</th>
      <td colspan="4">
        <span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        MAGPIE ENGINEERING PVT. LTD.
        </span> 
      </td>
    </tr>
    <tr>
      <th colspan="8" class="header-agency">Technical Initiation Request Form Data</th>
    </tr>
    <tr>
      <td class="section-title">Serial No</td>
      <td colspan="3"><span style="display: inline-block; min-width: 50px; padding: 2px;"><?= htmlspecialchars($data1['applicationNo'] ?? '') ?></span></td>
      <td>Date of Valuation</td>
      <td colspan="3"><span style="display: inline-block; min-width: 50px; padding: 2px;"><?= htmlspecialchars($data1['report_assigned_at'] ?? '') ?></span></td>
      </tr>
      <tr>
      <td class="section-title">Proposal No</td>
      <td colspan="3"><span style="display: inline-block; min-width: 50px; padding: 2px;"><?= htmlspecialchars($data1['applicationNo'] ?? '') ?></span></td>
      <td>Case Type</td>
      <td colspan="3"><span style="display: inline-block; min-width: 50px; padding: 2px;"><?= htmlspecialchars($data1['caseType'] ?? '') ?></span></td>
    </tr>
    <tr>
      <td class="section-title">Date of Inspection / Site visit</td>
      <td colspan="2"><span style="display: inline-block; min-width: 50px; padding: 2px;"><?= htmlspecialchars($data1['report_assigned_at'] ?? '') ?></span></td>
      <td>Nearest Landmark</td>
      <td colspan="4"><span style="display: inline-block; min-width: 50px; padding: 2px;"><?= htmlspecialchars($data3['landmark_1'] ?? '') ?>  <?= htmlspecialchars($data3['landmark_2'] ?? '') ?></span></td>
    </tr>
    <tr>
      <td class="section-title">Name of the Customer / Applicant & Contact Details</td>
      <td colspan="7"><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data1['customerName'] ?? '') ?>
    </span></td>
    </tr>
    <tr>
      <td class="section-title">Name of Current Owner / Seller</td>
      <td colspan="7"><span style="display: inline-block; min-width: 50px; padding: 2px;"><?= htmlspecialchars($data9['owner_name'] ?? '') ?></span></td>
    </tr>
    <tr>
      <td class="section-title">Name of the Person met at site & Contact No.</td>
      <td colspan="7"><span style="display: inline-block; min-width: 50px; padding: 2px;"><?= htmlspecialchars($data2['person_meet_at_site_contact'] ?? '') ?></span></td>
    </tr>
    </table>
    <table>
    <tr>
      <td rowspan="3" class="section-title">Address of the property being appraised</td>
      <td class="section-title">As per TRF</td>
      <td colspan="2"><span style="display: inline-block; min-width: 50px; padding: 2px;"><?= htmlspecialchars($data10['NA'] ?? '') ?></span></td>
    </tr>
      <tr>
      <td class="section-title">As per Document</td>
      <td colspan="2"><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data3['address_per_document'] ?? '') ?>
</span></td> 
      </tr>
      <tr>
      <td class="section-title">As per Actual at site</td>
      <td colspan="2"><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data3['address_per_site'] ?? '') ?>
    </span></td>
    </tr>
    <tr>
   <td colspan="2" class="section-title">Documents Provided by MHF/MFL
    <td colspan="2"><span style="display: inline-block; min-width: 50px; padding: 2px;"><?= htmlspecialchars($data1['document_provided_for_valuation'] ?? '') ?></span></td>
    </tr>
</table>
<table>
    <tr>
        <td  class="header-agency" colspan="4"></td>
    </tr>
    <!-- Additional Section -->
    <tr>
      <td class="section-title">Status of Land Holding (Freehold/Leasehold)</td>
      <td><span style="display: inline-block; min-width: 50px; padding: 2px;"><?= htmlspecialchars($data2['property_leasehold_freehold'] ?? '') ?></span></td>
      <td>Developed By (Self/Colonizer/Builder/Authority)</td>
      <td><span style="display: inline-block; min-width: 50px; padding: 2px;"><?= htmlspecialchars($data10['NA'] ?? '') ?></span></td>
      </tr>
<tr>
      <td class="section-title">Type of Property</td>
      <td><span style="display: inline-block; min-width: 50px; padding: 2px;"><?= htmlspecialchars($data2['property_unit_type'] ?? '') ?></span></td>
      <td>Classification of Area</td>
      <td><span style="display: inline-block; min-width: 50px; padding: 2px;"><?= htmlspecialchars($data10['NA'] ?? '') ?></span></td>
    </tr>
    <tr>
      <td class="section-title">Location/Zoning as per Master Plan or actual</td>
      <td><span style="display: inline-block; min-width: 50px; padding: 2px;"><?= htmlspecialchars($data4['zoning_development_plan'] ?? '') ?></span></td>
      <td>Locality Class</td>
      <td><span style="display: inline-block; min-width: 50px; padding: 2px;"><?= htmlspecialchars($data2['class_of_locality'] ?? '') ?></span></td>
      </tr>
      <tr>
       <td class="section-title">Plot Demarcation</td>
      <td><span style="display: inline-block; min-width: 50px; padding: 2px;"><?= htmlspecialchars($data2['demarcated_at_site'] ?? '') ?></span></td>
      <td>Occupation Status</td>
      <td><span style="display: inline-block; min-width: 50px; padding: 2px;"><?= htmlspecialchars($data2['occupancy_status'] ?? '') ?></span></td>
    </tr>
    <tr>
      <td class="section-title">Identified Through (legal docs / Site Map)</td>
      <td><span style="display: inline-block; min-width: 50px; padding: 2px;"><?= htmlspecialchars($data10['NA'] ?? '') ?></span></td>
      <td>Property Usage</td>
      <td><span style="display: inline-block; min-width: 50px; padding: 2px;"><?= htmlspecialchars($data4['current_property_usage'] ?? '') ?></span></td>
      </tr>
      <tr>
      <td class="section-title">Amenities available</td>
      <td><span style="display: inline-block; min-width: 50px; padding: 2px;"><?= htmlspecialchars($data10['NA'] ?? '') ?></span></td>
      <td>Property Identifiable</td>
      <td><span style="display: inline-block; min-width: 50px; padding: 2px;"><?= htmlspecialchars($data10['NA'] ?? '') ?></span></td>
    </tr>
    <tr>
      <td class="section-title">Internal Finishing</td>
      <td><span style="display: inline-block; min-width: 50px; padding: 2px;"><?= htmlspecialchars($data10['NA'] ?? '') ?></span></td>
      <td>Within MC / GP Limit and distance from nearest MC</td>
      <td><span style="display: inline-block; min-width: 50px; padding: 2px;"><?= htmlspecialchars($data3['property_location_in'] ?? '') ?></span></td>
      <tr>
    <td class="section-title">No. of Floors in the building</td>
      <td><span style="display: inline-block; min-width: 50px; padding: 2px;"><?= htmlspecialchars($data10['NA'] ?? '') ?></span></td>
       <td>Type of Structure</td>
      <td><span style="display: inline-block; min-width: 50px; padding: 2px;"><?= htmlspecialchars($data4['structure_type'] ?? '') ?></span></td>
      </tr>
    <tr>
     <td class="section-title">Total No. of Flats / Units in building</td>
      <td><span style="display: inline-block; min-width: 50px; padding: 2px;"><?= htmlspecialchars($data10['NA'] ?? '') ?></span></td>
      <td>Year of Completion</td>
      <td><span style="display: inline-block; min-width: 50px; padding: 2px;"><?= htmlspecialchars($data2['year_of_construction'] ?? '') ?></span></td>
    </tr>
    <tr>
    <td class="section-title">Present Age of the Property</td>
      <td><span style="display: inline-block; min-width: 50px; padding: 2px;"><?= htmlspecialchars($data2['age_of_property'] ?? '') ?></span></td>
    <td>Future Physical Life of  Property</td>
      <td><span style="display: inline-block; min-width: 50px; padding: 2px;"><?= htmlspecialchars($data2['residual_age_of_property'] ?? '') ?></span></td>
    </tr>
</table>
<table>   
    <tr>
        <td colspan="5" class="header-agency">Boundaries</td>
    </tr>
    <tr>
    <td class="section-title">Boundaries</td>
      <td class="section-title">North</td>
      <td class="section-title">South</td>
      <td class="section-title">East</td>
      <td class="section-title">West</td>
    </tr>
    <tr>
        <td class="section-title">As per Documents (A)</td>
        <td><span style="display: inline-block; min-width: 50px; padding: 2px;"><?= htmlspecialchars($data3['direction_as_per_site_north'] ?? '') ?></span></td>
                <td><span style="display: inline-block; min-width: 50px; padding: 2px;"><?= htmlspecialchars($data3['direction_as_per_site_south'] ?? '') ?></span></td>
                <td><span style="display: inline-block; min-width: 50px; padding: 2px;"><?= htmlspecialchars($data3['direction_as_per_document_east'] ?? '') ?></span></td>
                <td><span style="display: inline-block; min-width: 50px; padding: 2px;"><?= htmlspecialchars($data3['direction_as_per_document_west'] ?? '') ?></span></td>
            </tr>
        <tr>
        <td class="section-title">As per Site / Actual</td>
        <td><span style="display: inline-block; min-width: 50px; padding: 2px;"><?= htmlspecialchars($data3['direction_as_per_site_north'] ?? '') ?></span></td>
                <td><input type="text" readonly  value="<?=  $data3['direction_as_per_site_south'] ?? '' ?>" name="actual_south"></td>
                <td><span style="display: inline-block; min-width: 50px; padding: 2px;"><?= htmlspecialchars($data3['direction_as_per_site_east'] ?? '') ?></span></td>
                <td><input type="text" readonly  value="<?=  $data3['direction_as_per_site_west'] ?? '' ?>" name="actual_west"></td>
            </tr>
    <tr>
        <td class="section-title">Boundaries Matching (Yes/Partly matching/No)</td>
         <td><span style="display: inline-block; min-width: 50px; padding: 2px;"><?= htmlspecialchars($data3['boundaries_matching'] ?? '') ?></span></td> 
         <td>If No, then reason thereon</td>
          <td colspan="2"><span style="display: inline-block; min-width: 50px; padding: 2px;"><?= htmlspecialchars($data10['NA'] ?? '') ?></span></td> 
    </tr>
  </table>
   <table>
    <!-- Setbacks / Margin Section -->
    <tr>
      <th colspan="6"  class="header-agency">Setbacks / Margin in the Building (in Ft)</th>
    </tr>
    <tr>
      <td colspan="2" class="section-title">Setbacks / Margin in the Building (in Ft)</td>
      <td class="section-title">Front</td>
      <td class="section-title">Rear</td>   
      <td class="section-title">Left Side</td>
      <td class="section-title">Right Side</td>
    </tr>
    <tr>
  <td colspan="2" class="section-title">As per sanctioned/ permissible byelaws</td>
      <td><span style="display: inline-block; min-width: 50px; padding: 2px;"><?= htmlspecialchars($data10['NA'] ?? '') ?></span></td>
      <td><span style="display: inline-block; min-width: 50px; padding: 2px;"><?= htmlspecialchars($data10['NA'] ?? '') ?></span></td>
      <td><span style="display: inline-block; min-width: 50px; padding: 2px;"><?= htmlspecialchars($data10['NA'] ?? '') ?></span></td>
      <td><span style="display: inline-block; min-width: 50px; padding: 2px;"><?= htmlspecialchars($data10['NA'] ?? '') ?></span></td>
    </tr>
        <tr>
  <td colspan="2" class="section-title">As per Site / Actual</td>
      <td><span style="display: inline-block; min-width: 50px; padding: 2px;"><?= htmlspecialchars($data10['NA'] ?? '') ?></span></td>
      <td><span style="display: inline-block; min-width: 50px; padding: 2px;"><?= htmlspecialchars($data10['NA'] ?? '') ?></span></td>
      <td><span style="display: inline-block; min-width: 50px; padding: 2px;"><?= htmlspecialchars($data10['NA'] ?? '') ?></span></td>
      <td><span style="display: inline-block; min-width: 50px; padding: 2px;"><?= htmlspecialchars($data10['NA'] ?? '') ?></span></td>
    </tr>
      <tr>
      <th colspan="6" class="header-agency">Height/Storiey</th>
    </tr>
    <tr>
      <td colspan="2" class="section-title">As per sanctioned/ permissible byelaws</td>
   <td colspan="4"><span style="display: inline-block; min-width: 50px; padding: 2px;"><?= htmlspecialchars($data10['NA'] ?? '') ?></span></td>   
    </tr>
        <tr>
      <td colspan="2" class="section-title">As per Site / Actua</td>
   <td colspan="4"><span style="display: inline-block; min-width: 50px; padding: 2px;"><?= htmlspecialchars($data10['NA'] ?? '') ?></span></td>   
    </tr>
</table>
<table>
    <!-- BUA Details -->
    <tr>
      <td colspan="9" class="header-agency"></td>
    </tr>
    <tr>
      <td class="section-title" >Floor (Pl mention floorwise)</td>
      <td class="section-title"  colspan="2">Accomodation (As per Site )- no of rooms,toilets, kitchen, balcony etc</td>
      <td  class="section-title"  colspan="2">Actual Carpet Area (SBA)(Mandatory)</td>
      <td class="section-title">Actual BUA / SBA (Sft)</td>
      <td class="section-title" colspan="2">Sanctioned BUA (Sft)// As per Estimate BUA (Sft)</td>
      <td class="section-title">Adopted Built-up Area (Sft)</td>
    </tr>
    <tr>
      <td>Ground Floor</td>
      <td colspan="2"><span style="display: inline-block; min-width: 50px; padding: 2px;"><?= htmlspecialchars($data8['basements_remarks'] ?? '') ?></span></td>
      <td colspan="2"><span style="display: inline-block; min-width: 50px; padding: 2px;"><?= htmlspecialchars($data6['actual_carpet_square_feet'] ?? '') ?></span></td>
      <td><span style="display: inline-block; min-width: 50px; padding: 2px;"><?= htmlspecialchars($data6['actual_construction_square_feet'] ?? '') ?></span></td>
      <td colspan="2"><span style="display: inline-block; min-width: 50px; padding: 2px;"><?= htmlspecialchars($data6['construction_square_feet'] ?? '') ?></span></td>
      <td><span style="display: inline-block; min-width: 50px; padding: 2px;"><?= htmlspecialchars($data6['final_construction_square_feet'] ?? '') ?></span></td>
      
    </tr>
    <tr>
      <td>1st Floor</td>
    <td colspan="2"><span style="display: inline-block; min-width: 50px; padding: 2px;"><?= htmlspecialchars($data10['NA'] ?? '') ?></span></td>
       <td colspan="2"><span style="display: inline-block; min-width: 50px; padding: 2px;"><?= htmlspecialchars($data10['NA'] ?? '') ?></span></td>
      <td><span style="display: inline-block; min-width: 50px; padding: 2px;"><?= htmlspecialchars($data10['NA'] ?? '') ?></span></td>
     <td colspan="2"><span style="display: inline-block; min-width: 50px; padding: 2px;"><?= htmlspecialchars($data10['NA'] ?? '') ?></span></td>
      <td><span style="display: inline-block; min-width: 50px; padding: 2px;"><?= htmlspecialchars($data10['NA'] ?? '') ?></span></td>
  </tr>
    <tr>
      <td>2nd Floor</td>
      <td colspan="2"><span style="display: inline-block; min-width: 50px; padding: 2px;"><?= htmlspecialchars($data10['NA'] ?? '') ?></span></td>
       <td colspan="2"><span style="display: inline-block; min-width: 50px; padding: 2px;"><?= htmlspecialchars($data10['NA'] ?? '') ?></span></td>
      <td><span style="display: inline-block; min-width: 50px; padding: 2px;"><?= htmlspecialchars($data10['NA'] ?? '') ?></span></td>
     <td colspan="2"><span style="display: inline-block; min-width: 50px; padding: 2px;"><?= htmlspecialchars($data10['NA'] ?? '') ?></span></td>
      <td><span style="display: inline-block; min-width: 50px; padding: 2px;"><?= htmlspecialchars($data10['NA'] ?? '') ?></span></td>
    </tr>
      <tr>
      <td>3rd Floor</td>
      <td colspan="2"><span style="display: inline-block; min-width: 50px; padding: 2px;"><?= htmlspecialchars($data10['NA'] ?? '') ?></span></td>
       <td colspan="2"><span style="display: inline-block; min-width: 50px; padding: 2px;"><?= htmlspecialchars($data10['NA'] ?? '') ?></span></td>
      <td><span style="display: inline-block; min-width: 50px; padding: 2px;"><?= htmlspecialchars($data10['NA'] ?? '') ?></span></td>
     <td colspan="2"><span style="display: inline-block; min-width: 50px; padding: 2px;"><?= htmlspecialchars($data10['NA'] ?? '') ?></span></td>
      <td><span style="display: inline-block; min-width: 50px; padding: 2px;"><?= htmlspecialchars($data10['NA'] ?? '') ?></span></td>
    </tr>
    <tr>
      <td>Total</td>
      <td colspan="2"><span style="display: inline-block; min-width: 50px; padding: 2px;"><?= htmlspecialchars($data10['NA'] ?? '') ?></span></td>
      <td colspan="2"><span style="display: inline-block; min-width: 50px; padding: 2px;"><?= htmlspecialchars($data10['NA'] ?? '') ?></span></td>
      <td><span style="display: inline-block; min-width: 50px; padding: 2px;"><?= htmlspecialchars($data10['NA'] ?? '') ?></span></td>
      <td colspan="2"><span style="display: inline-block; min-width: 50px; padding: 2px;"><?= htmlspecialchars($data10['NA'] ?? '') ?></span></td>
    <td><span style="display: inline-block; min-width: 50px; padding: 2px;"><?= htmlspecialchars($data10['NA'] ?? '') ?></span></td>
    </tr>
    <tr>
      <td colspan="7">Whether toilet built in house / outside house but within the plot boundary / not available at site:</td>
      <td colspan="2"> <span style="display: inline-block; min-width: 50px; padding: 2px;"><?= htmlspecialchars($data10['NA'] ?? '') ?></span></td>
    </tr>
    <tr>
      <td colspan="7" class="section-title">Violation observed (if any): </td>
      <td colspan="2"><span style="display: inline-block; min-width: 50px; padding: 2px;"><?= htmlspecialchars($data10['NA'] ?? '') ?></span></td>
    </tr>
</table>
<table> 
    <!-- Plan Approval -->
    <tr>
      <th colspan="8" class="header-agency">Plan Approvals</th>
    </tr>
    <tr>
      <td colspan="2" class="section-title">Construction as per approved/ sanctioned plans</td>
      <td colspan="2"><span style="display: inline-block; min-width: 50px; padding: 2px;"><?= htmlspecialchars($data10['NA'] ?? '') ?></span></td>
      <td colspan="2" class="section-title">Details of approved plan with number & date</td>
      <td colspan="2"><span style="display: inline-block; min-width: 50px; padding: 2px;"><?= htmlspecialchars($data9['floor_authority'] ?? '') ?>  <?= htmlspecialchars($data9['floor_details'] ?? '') ?></span></td>
    </tr>
    <tr>
        <td colspan="2" class="section-title">Construction permission Number & Date</td>
      <td colspan="2"><span style="display: inline-block; min-width: 50px; padding: 2px;"><?= htmlspecialchars($data10['NA'] ?? '') ?></span></td>
      <td colspan="2" class="section-title">Violations Observed if Any</td>
      <td colspan="2"><span style="display: inline-block; min-width: 50px; padding: 2px;"><?= htmlspecialchars($data10['NA'] ?? '') ?></span></td>
    </tr>
    <tr>
      <td colspan="6" class="section-title">If plans not available then is the structure confirming to the local byelaws (Yes/No </td>
      <td colspan="2"> <span style="display: inline-block; min-width: 50px; padding: 2px;"><?= htmlspecialchars($data10['NA'] ?? '') ?></span></td>
    </tr>

    <!-- NDMA Section -->
    <tr>
      <th colspan="8" class="header-agency">NDMA PARAMETERS</th>
    </tr>
    <tr>
      <td>Nature of Building/Wing</td>
      <td><span style="display: inline-block; min-width: 50px; padding: 2px;"><?= htmlspecialchars($data2['structurally_fit'] ?? '') ?></span></td>
      <td>Plan Aspect Ratio</td>
      <td colspan="2"><span style="display: inline-block; min-width: 50px; padding: 2px;"><?= htmlspecialchars($data10['NA'] ?? '') ?></span></td>
      <td>Structure Type</td>
      <td colspan="2"><span style="display: inline-block; min-width: 50px; padding: 2px;"><?= htmlspecialchars($data4['structure_type'] ?? '') ?></span></td>
    </tr>
    <tr>
      <td>Projected Parts Available</td>
      <td><span style="display: inline-block; min-width: 50px; padding: 2px;"><?= htmlspecialchars($data10['NA'] ?? '') ?></span></td>
        <td>Type of Masonary</td>
      <td colspan="2"><span style="display: inline-block; min-width: 50px; padding: 2px;"><?= htmlspecialchars($data10['NA'] ?? '') ?></span></td>
        <td>Expansion Joint Available</td>
      <td colspan="2"><span style="display: inline-block; min-width: 50px; padding: 2px;"><?= htmlspecialchars($data10['NA'] ?? '') ?></span></td>
    </tr>
      <tr>
      <td>Roof Type</td>
      <td><span style="display: inline-block; min-width: 50px; padding: 2px;"><?= htmlspecialchars($data4['roof_type'] ?? '') ?></span></td>
      <td>Steel Grade</td>
      <td colspan="2"><span style="display: inline-block; min-width: 50px; padding: 2px;"><?= htmlspecialchars($data10['NA'] ?? '') ?></span></td>
      <td>Mortar Type</td>
      <td colspan="2"><span style="display: inline-block; min-width: 50px; padding: 2px;"><?= htmlspecialchars($data10['NA'] ?? '') ?></span></td>
    </tr>
    <tr>
         <td></td>
      <td><span style="display: inline-block; min-width: 50px; padding: 2px;"><?= htmlspecialchars($data10['NA'] ?? '') ?></span></td>
      <td>Environment Exposure Condition</td>
      <td colspan="2"><span style="display: inline-block; min-width: 50px; padding: 2px;"><?= htmlspecialchars($data10['NA'] ?? '') ?></span></td>
      <td>FOOTING TYPE</td>
      <td colspan="2"><span style="display: inline-block; min-width: 50px; padding: 2px;"><?= htmlspecialchars($data10['NA'] ?? '') ?></span></td>
    </tr>
    <tr>
      <td>Seismic Zone</td>
      <td><span style="display: inline-block; min-width: 50px; padding: 2px;"><?= htmlspecialchars($data4['seismic_zone'] ?? '') ?></span></td>
      <td>SOIL LIQUEFIABLE</td>
      <td colspan="2"><span style="display: inline-block; min-width: 50px; padding: 2px;"><?= htmlspecialchars($data10['NA'] ?? '') ?></span></td>
      <td>COASTAL REGULATORY ZONE(Yes /No)</td>
      <td colspan="2"><span style="display: inline-block; min-width: 50px; padding: 2px;"><?= htmlspecialchars($data4['costal_regulatory_zone'] ?? '') ?></span></td>
      </tr>
      <tr>
      <td>SOIL SLOPE VULNERABLE TO LANDSLIDE</td>
      <td><span style="display: inline-block; min-width: 50px; padding: 2px;"><?= htmlspecialchars($data10['NA'] ?? '') ?></span></td>  
      <td>Flood Prone Area</td>
      <td colspan="2"><span style="display: inline-block; min-width: 50px; padding: 2px;"><?= htmlspecialchars($data10['NA'] ?? '') ?></span></td>
      <td>GROUND SLOPE MORE THAN 20%</td>
      <td colspan="2"><span style="display: inline-block; min-width: 50px; padding: 2px;"><?= htmlspecialchars($data10['NA'] ?? '') ?></span></td>
      </tr>
      <tr>
        <td colspan="4"></td>
      <td>Fire Exit</td>
      <td colspan="3"><span style="display: inline-block; min-width: 50px; padding: 2px;"><?= htmlspecialchars($data10['NA'] ?? '') ?></span></td>
    </tr>

    <!-- Slab-wise Status -->
    <tr>
      <th colspan="8" class="header-agency">Slab wise Construction Status</th>
    </tr>
    <tr>
      <td class="section-title" >Sr. No</td>
      <td class="section-title" >Activity</td>
      <td class="section-title" >Allocated % For Activity</td>
      <td class="section-title" >Present Completion %</td>
      <td  class="section-title" colspan="4">Remarks on Progress</td>
    </tr>
    <tr>
    <td >1</td>
    <td>PLINTH</td>
    <td><span style="display: inline-block; min-width: 50px; padding: 2px;"><?= htmlspecialchars($data10['NA'] ?? '') ?></span></td>
    <td><span style="display: inline-block; min-width: 50px; padding: 2px;"><?= htmlspecialchars($data8['plinth_present_completion'] ?? '') ?></span></td>
    <td colspan="4"><span style="display: inline-block; min-width: 50px; padding: 2px;"><?= htmlspecialchars($data10['NA'] ?? '') ?></span></td>
  </tr>
    <tr>
      <td>2</td>
      <td>R.C.C. ABOVE GROUND</td>
      <td><span style="display: inline-block; min-width: 50px; padding: 2px;"><?= htmlspecialchars($data10['NA'] ?? '') ?></span></td>
      <td><span style="display: inline-block; min-width: 50px; padding: 2px;"><?= htmlspecialchars($data8['rcc_present_completion'] ?? '') ?></span></td>
      <td colspan="4" rowspan="8"><span style="display: inline-block; min-width: 50px; padding: 2px;"><?= htmlspecialchars($data10['NA'] ?? '') ?></span></td>
    </tr>
    <tr>
      <td>3</td>
      <td>BRICKWORK</td>
      <td><span style="display: inline-block; min-width: 50px; padding: 2px;"><?= htmlspecialchars($data10['NA'] ?? '') ?></span></td>
      <td><span style="display: inline-block; min-width: 50px; padding: 2px;"><?= htmlspecialchars($data8['brickwork_present_completion'] ?? '') ?></span></td>
    </tr>
    <tr>
      <td>4</td>
      <td>INTERNAL PLASTER</td>
      <td><span style="display: inline-block; min-width: 50px; padding: 2px;"><?= htmlspecialchars($data10['NA'] ?? '') ?></span></td>
      <td><span style="display: inline-block; min-width: 50px; padding: 2px;"><?= htmlspecialchars($data8['internal_plaster_present_completion'] ?? '') ?></span></td>
    </tr>
    <tr>
      <td>5</td>
      <td>EXTERNAL PLASTER </td>
      <td><span style="display: inline-block; min-width: 50px; padding: 2px;"><?= htmlspecialchars($data10['NA'] ?? '') ?></span></td>
      <td><span style="display: inline-block; min-width: 50px; padding: 2px;"><?= htmlspecialchars($data8['external_plaster_present_completion'] ?? '') ?></span></td>
    </tr>
    <tr>
      <td>6</td>
    <td>FLOORING (PCC)</td>
    <td><span style="display: inline-block; min-width: 50px; padding: 2px;"><?= htmlspecialchars($data10['NA'] ?? '') ?></span></td>
    <td><span style="display: inline-block; min-width: 50px; padding: 2px;"><?= htmlspecialchars($data8['flooring_present_completion'] ?? '') ?></span></td>
  </tr>
    <tr>
      <td>7</td>

    <td>PLUMBING & ELECTRIC WORK</td>
    <td><span style="display: inline-block; min-width: 50px; padding: 2px;"><?= htmlspecialchars($data10['NA'] ?? '') ?></span></td>
    <td><span style="display: inline-block; min-width: 50px; padding: 2px;"><?= htmlspecialchars($data8['plumbing_present_completion'] ?? '') ?></span></td>
  </tr>
    <tr>
      <td>8</td>
    <td>DOOR, WINDOW & PAINT</td>
    <td><span style="display: inline-block; min-width: 50px; padding: 2px;"><?= htmlspecialchars($data10['NA'] ?? '') ?></span></td>
    <td><span style="display: inline-block; min-width: 50px; padding: 2px;"><?= htmlspecialchars($data8['door_window_paint_present_completion'] ?? '') ?></span></td>
  </tr>
    <tr>
      <td>9</td>
    <td>FINISHING & POSSESSION</td>
    <td><span style="display: inline-block; min-width: 50px; padding: 2px;"><?= htmlspecialchars($data10['NA'] ?? '') ?></span></td><td><span style="display: inline-block; min-width: 50px; padding: 2px;"><?= htmlspecialchars($data8['finishing_possession_present_completion'] ?? '') ?></span></td></tr>
<tr><td colspan="2">TOTAL COMPLETION (%)</td><td><span style="display: inline-block; min-width: 50px; padding: 2px;"><?= htmlspecialchars($data10['NA'] ?? '') ?></span></td><td><span style="display: inline-block; min-width: 50px; padding: 2px;"><?= htmlspecialchars($data8['total_completion_present'] ?? '') ?></span></td><td colspan="4"><span style="display: inline-block; min-width: 50px; padding: 2px;"><?= htmlspecialchars($data10['NA'] ?? '') ?></span></td></tr>
    <tr>
      <td class="header-agency" colspan="8"></td>
    </tr>
    <tr>
      <td colspan="2"  class="section-title" >Estimated Cost ( in Rs)</td>
      <td colspan="2"><span style="display: inline-block; min-width: 50px; padding: 2px;"><?= htmlspecialchars($data6['actual_construction_valuation_computed'] ?? '') ?></span></td>
       <td colspan="2">Estimated Cost (in Rs per Sqft)</td>
      <td colspan="2"><span style="display: inline-block; min-width: 50px; padding: 2px;"><?= htmlspecialchars($data6['actual_construction_rate'] ?? '') ?></span></td>
      </tr>
      <tr>
      <td colspan="2"  class="section-title" >Justified Cost ( in Rs per Sqft)</td>
      <td colspan="2"><span style="display: inline-block; min-width: 50px; padding: 2px;"><?= htmlspecialchars($data10['NA'] ?? '') ?></span></td>
      <td colspan="2">Adjusted / Justified Estimated Cost (in Rs)</td>
      <td colspan="2"><span style="display: inline-block; min-width: 50px; padding: 2px;"><?= htmlspecialchars($data10['NA'] ?? '') ?></span></td>
    </tr>
  </table>
  <table>
     <tr><th colspan="8"  class="header-agency">Valuation of Property (Fair Market Valuation / Distress Valuation) - All Areas to be mentioned in Sqft only</th></tr>
     <tr>
      <td colspan="2"  class="section-title" >Land Area (As per Legal Docs)</td>
      <td colspan="2"><span style="display: inline-block; min-width: 50px; padding: 2px;"><?= htmlspecialchars($data6['plot_square_feet'] ?? '') ?></span></td>
      <td colspan="2">Adoptable Built-up Area (in Sqft)</td>
      <td colspan="2"><span style="display: inline-block; min-width: 50px; padding: 2px;"><?= htmlspecialchars($data6['construction_square_feet'] ?? '') ?></span></td>
     </tr>
      <tr>
      <td colspan="2"  class="section-title" >Land Area (in Sqft)</td>
      <td colspan="2"><span style="display: inline-block; min-width: 50px; padding: 2px;"><?= htmlspecialchars($data6['actual_plot_square_feet'] ?? '') ?></span></td>
      <td colspan="2">Construction Cost (Rs per sqft)</td>
      <td colspan="2"><span style="display: inline-block; min-width: 50px; padding: 2px;"><?= htmlspecialchars($data6['construction_rate'] ?? '') ?></span></td>
    </tr>
    <tr>
      <td colspan="2"  class="section-title" >Current Market Rate in the locality (Range) in Rs Per Sqft</td>
      <td colspan="2"><span style="display: inline-block; min-width: 50px; padding: 2px;"><?= htmlspecialchars($data6['actual_plot_rate'] ?? '') ?></span></td>
      <td colspan="2">Total Construction Value for 100% completed building (in Rs)</td>
      <td colspan="2"><span style="display: inline-block; min-width: 50px; padding: 2px;"><?= htmlspecialchars($data6['finally_construction_valuation'] ?? '') ?></span></td>
   </tr>
     <tr>
      <td colspan="2"  class="section-title" >Recommended Rate of Land(Rs per sqft)</td>
      <td colspan="2"><span style="display: inline-block; min-width: 50px; padding: 2px;"><?= htmlspecialchars($data6['actual_plot_rate'] ?? '') ?></span></td>
<td colspan="2">Total Construction Value for present construction stage (in Rs)</td>
<td colspan="2"><span style="display: inline-block; min-width: 50px; padding: 2px;"><?= htmlspecialchars($data6['finally_construction_valuation'] ?? '') ?></span></td>
    </tr>
    <tr>
      <td colspan="2"  class="section-title" >Total Land Value (in Rs)</td>
      <td colspan="2"><span style="display: inline-block; min-width: 50px; padding: 2px;"><?= htmlspecialchars($data6['actual_plot_valuation_computed'] ?? '') ?></span></td>
      <td colspan="2">MV of Land & Building for present completed property (in Rs)</td>
      <td colspan="2"><span style="display: inline-block; min-width: 50px; padding: 2px;"><?= htmlspecialchars($data6['total_finally_area_valuation'] ?? '') ?></span></td>
      </tr>
      <tr>
     <td colspan="2"  class="section-title" >Market Value of Land & Building for 100% complete property (in Rs)</td>
     <td colspan="2"><span style="display: inline-block; min-width: 50px; padding: 2px;"><?= htmlspecialchars($data6['total_finally_area_valuation'] ?? '') ?></span></td>
      <td colspan="2">Distress Value of present completed property @ 75% of MV</td>
      <td colspan="2"><span style="display: inline-block; min-width: 50px; padding: 2px;"><?= htmlspecialchars($data6['total_distress_value'] ?? '') ?></span></td>
    </tr>
 <tr>
  <td colspan="2"  class="section-title" >Flat / row house / Shop / Office ( area in Sqft)</td>
  <td colspan="2"><span style="display: inline-block; min-width: 50px; padding: 2px;"><?= htmlspecialchars($data10['NA'] ?? '') ?></span></td>
    <td colspan="2">Composite sale rate (Rs per sqft)</td>
  <td colspan="2"><span style="display: inline-block; min-width: 50px; padding: 2px;"><?= htmlspecialchars($data10['NA'] ?? '') ?></span></td>
 </tr>
  <tr>
  <td colspan="2"  class="section-title" >MV of 100% complete Shop / Flat / Row house/Office (Rs) including all amenities and other cost</td>
  <td colspan="2"><span style="display: inline-block; min-width: 50px; padding: 2px;"><?= htmlspecialchars($data10['NA'] ?? '') ?></span></td>
    <td colspan="2">MV on present completion stage Shop/ Flat / Row house/ Office (Rs) including all amenities and other cost</td>
  <td colspan="2"><span style="display: inline-block; min-width: 50px; padding: 2px;"><?= htmlspecialchars($data10['NA'] ?? '') ?></span></td>
 </tr>
  <tr>
  <td colspan="2"  class="section-title" >Government Guideline/ Circle rate/Guidance rate for Land (Rs per sqft) - Mandatory</td>
  <td colspan="2"><span style="display: inline-block; min-width: 50px; padding: 2px;"><?= htmlspecialchars($data6['guideline_rate'] ?? '') ?></span></td>
    <td colspan="2">Total Land Value as per Government Rate (Rs)</td>
  <td colspan="2"><span style="display: inline-block; min-width: 50px; padding: 2px;"><?= htmlspecialchars($data6['guideline_values'] ?? '') ?></span></td>
 </tr>
  <tr>
  <td colspan="2"  class="section-title" >Government Guideline/ Circle rate /Guidance rate for Flats (Rs per sqft) - Mandatory</td>
  <td colspan="2"><span style="display: inline-block; min-width: 50px; padding: 2px;"><?= htmlspecialchars($data6['guideline_rate'] ?? '') ?></span></td>
    <td colspan="2">Total Flat / Apartment Value as per Government Rate (Rs) </td>
  <td colspan="2"><span style="display: inline-block; min-width: 50px; padding: 2px;"><?= htmlspecialchars($data6['guideline_values'] ?? '') ?></span></td>
 </tr>
</table>
 <table>
    <!-- Remarks & Observation -->
    <tr><th colspan="8" class="header-agency">Property Specific Remarks & Observation</th></tr>
    <tr class="remarks">
      <td colspan="3" class="section-title">Remarks / Observation:</td>
      <td colspan="5"><span style="white-space: pre-line; font-size:14px; display: block; text-align: left; padding: 0; margin: 0;">
        <?= htmlspecialchars($data10['remarks'] ?? '') ?>
    </span></td>
    </tr>
</table>
<table>
<tr>
  <td colspan="8" class="header-agency"></td>
</tr>
<tr>
      <td colspan="2"  class="section-title">Date of Visit</td>
      <td colspan="2"><span style="display: inline-block; min-width: 50px; padding: 2px;"><?= htmlspecialchars($data1['report_assigned_at'] ?? '') ?></span></td>
      <td colspan="2">Date of Report Submission</td>
      <td colspan="2"><span style="display: inline-block; min-width: 50px; padding: 2px;"><?= htmlspecialchars($data1['report_assigned_at'] ?? '') ?></span></td>
     </tr>
      <tr>
      <td colspan="2"  class="section-title">Name of Engineer Visited</td>
      <td colspan="2"><input type="text" readonly  value="<?= $engineer_name ?>"></td>
      <td colspan="2">Authorized Signatory Name & Signature</td>
      <td colspan="2"><span style="display: inline-block; min-width: 50px; padding: 2px;"><?= htmlspecialchars($data10['NA'] ?? '') ?></span></td>
    </tr>
    <tr>
      <td colspan="4"  class="section-title">Latitude, Longitude:</td>
      <td colspan="4"  class="section-title"><span style="white-space: pre-line; font-size:14px; display: block; text-align: left; padding: 0; margin: 0;">
        <?= htmlspecialchars($data3['latitude_value'] ?? '') ?>, <?= htmlspecialchars($data3['longitude_value'] ?? '') ?>
    </span></td>
    </tr>
 
    <tr>
      <td colspan="2"  class="section-title">Name of the Customer / Applicant</td>
      <td colspan="2"><span style="display: inline-block; min-width: 50px; padding: 2px;"><?= htmlspecialchars($data1['customerName'] ?? '') ?></span></td>
      <td colspan="2">Proposal No.</td>
      <td colspan="2"><span style="display: inline-block; min-width: 50px; padding: 2px;"><?= htmlspecialchars($data10['applicationNo'] ?? '') ?></span></td>
    </tr>
    <tr>
      <td colspan="2"  class="section-title">Address of the property being appraised</td>
      <td colspan="6"><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data3['address_per_site'] ?? '') ?>
    </span></td>
    </tr>
  </table>
  <table>
 
  <tr>

<div class="google-map-container">
<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "project_db";
$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$reference_id = $_SESSION['reference_id'] ?? null;
$reference_id = $_GET['reference_id'] ?? $reference_id;

if ($reference_id) {
    $sql = "SELECT image5 FROM final_uploaded_images WHERE reference_id = ?";
    $stmt = $conn->prepare($sql);
    if ($stmt === false) {
        die("Error preparing the SQL statement: " . $conn->error);
    }

    $stmt->bind_param("s", $reference_id);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows > 0) {
        $row = $result->fetch_assoc();
        if (!empty($row['image5'])) {
 
            echo '<div><img src="data:image/jpeg;base64,' . base64_encode($row['image5']) . '" alt="Google Map"><p>Google Map</p></div>';
        } else {
            echo "<p style='text-align:center;'>Google Map image not available.</p>";
        }
    } else {
        echo "<p style='text-align:center;'>No record found for Google Map image.</p>";
    }

    $stmt->close();
} else {
    echo "<p style='text-align:center;'>Reference ID is missing.</p>";
}
?>
</tr>
</div>
    </table>


 
<table>
  <tr>
    <td class="section-title">Name of Engineer Visted the property</td>
    <td><input type="text" readonly  value="<?= $engineer_name ?>"></td>
    <td class="header-agency">Authorized Signatory Name & Signature</td>
    <td><span style="display: inline-block; min-width: 50px; padding: 2px;"><?= htmlspecialchars($data10['NA'] ?? '') ?></span></td>
  </tr>
  <tr>
    <td class="header-agency" colspan="4">Location cum Route map showing property Boundaries from Nearby Landmarks with approx distance)</td>
  </tr>
   <tr>
      <td  class="section-title">Name of the Customer / Applicant</td>
      <td><span style="display: inline-block; min-width: 50px; padding: 2px;"><?= htmlspecialchars($data1['customerName'] ?? '') ?></span></td>
      <td  class="section-title">Proposal No.</td>
      <td><span style="display: inline-block; min-width: 50px; padding: 2px;"><?= htmlspecialchars($data1['applicationNo'] ?? '') ?></span></td>
    </tr>
    <tr>
      <td class="section-title">Address of the property being appraised</td>
      <td colspan="3"><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data3['address_per_site'] ?? '') ?>
    </span></td>
    </tr>
</table>
<h3>Google map ki photo</h3>
<table>
  <tr>
     <td>Latitude</td>
      <td><span style="display: inline-block; min-width: 50px; padding: 2px;"><?= htmlspecialchars($data3['latitude_value'] ?? '') ?></span></td>
      <td>Longitude</td>
      <td><span style="display: inline-block; min-width: 50px; padding: 2px;"><?= htmlspecialchars($data3['longitude_value'] ?? '') ?></span></td>
  </tr>
 <tr>
    <td class="section-title">Name of Engineer Visted the property</td>
    <td><input type="text" readonly  value="<?= $engineer_name ?>"></td>
    <td class="header-agency">Authorized Signatory Name & Signature</td>
    <td><span style="display: inline-block; min-width: 50px; padding: 2px;"><?= htmlspecialchars($data10['NA'] ?? '') ?></span></td>
  </tr>
</table>

     <!-- <button onclick="window.print()">Download PDF</button> -->
    <form method="post">
  <input type="hidden" name="download_images" value="1">
  <button type="submit">Download All Images</button>
</form>
     <!-- <button onclick="window.print()">Download PDF</button> -->
  <button id="downloadPdf" onclick="setPrintMargins()">DOWNLOAD PDF</button>
  <script>
    document.getElementById('downloadPdf').addEventListener('click', () => {
      // Select the content you want to convert to PDF
      const element = document.getElementById('content');
      const options = {
        margin:[0,0],
        filename:'report.pdf',
        image: { type: 'jpeg', quality: 0.98 },
        html2canvas: { scale: 2 },
        jsPDF: { unit: 'in', format: 'letter', orientation: 'portrait' }
      };

      // Generate and download the PDF
      html2pdf().set(options).from(element).save();
    });
    function setPrintMargins() {
      const style = document.createElement('style');
      style.innerHTML = `
      @media print {
          body {
            margin:0.5;
          }
        }
      `;
      document.head.appendChild(style);
      window.print();
    }
    // Disable all input fields in the form
    document.querySelectorAll('input').forEach(function(input) {
        input.disabled = true;  // Disables the field completely
    });
    </script>
     </div>
</body>
</html>
