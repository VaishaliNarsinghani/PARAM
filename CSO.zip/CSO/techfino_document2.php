<?php include('auth.php'); ?>
<?php
ini_set('display_errors', 1);
error_reporting(E_ALL);

// Increase PHP execution time and memory limit
ini_set('max_execution_time', 3000); // 300 seconds = 5 minutes
ini_set('memory_limit', '1024M'); // Increase memory limit to 512MB

// Start session


$servername = "localhost";
$username = "root";
$password = "";
$dbname = "project_db";

// Create DB connection
$conn = new mysqli($servername, $username, $password, $dbname);
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

if (!isset($_SESSION['reference_id'])) {
    die("Reference ID not found in session.");
}
$reference_id = $_SESSION['reference_id'];

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['download_images'])) {

    // Get customer name
    $stmt_name = $conn->prepare("SELECT customerName FROM mis WHERE reference_id = ?");
    $stmt_name->bind_param("s", $reference_id);
    $stmt_name->execute();
    $result_name = $stmt_name->get_result();
    $customerName = "customer";
    if ($row = $result_name->fetch_assoc()) {
        $customerName = preg_replace('/[^a-zA-Z0-9]/', '', $row['customerName']);
    }
    $stmt_name->close();

    // Fetch image BLOBs
    $stmt = $conn->prepare("SELECT image1, image2, image3, image4, image5, image6, image7, image8, image9, image10, image11, image12,image13, image14, image15, image16, image17, image18, image19, image20 FROM final_uploaded_images WHERE reference_id = ?");    $stmt->bind_param("s", $reference_id);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows > 0 && ($row = $result->fetch_assoc())) {
        $tempDir = sys_get_temp_dir() . DIRECTORY_SEPARATOR . uniqid('images_', true);
        mkdir($tempDir);

        $imageFiles = [];
        for ($i = 1; $i <= 12; $i++) {
            if (!empty($row["image$i"])) {
                $filename = $tempDir . DIRECTORY_SEPARATOR . "image{$i}.jpg";
                file_put_contents($filename, $row["image$i"]);
                $imageFiles[] = $filename;
            }
        }

        if (empty($imageFiles)) {
            die("No images to download.");
        }

        // Create ZIP
        $zipFileName = "images_" . preg_replace('/[^a-zA-Z0-9]/', '_', $reference_id) . "_{$customerName}.zip";
        $zipPath = $tempDir . DIRECTORY_SEPARATOR . $zipFileName;

        $zip = new ZipArchive();
        if ($zip->open($zipPath, ZipArchive::CREATE) !== TRUE) {
            die("Failed to create ZIP file.");
        }

        foreach ($imageFiles as $file) {
            $zip->addFile($file, basename($file));
        }
        $zip->close();

        // Send ZIP to browser
        header('Content-Type: application/zip');
        header('Content-Disposition: attachment; filename="' . basename($zipFileName) . '"');
        header('Content-Length: ' . filesize($zipPath));
        flush();
        readfile($zipPath);

        // Cleanup
        foreach ($imageFiles as $file) {
            unlink($file);
        }
        unlink($zipPath);
        rmdir($tempDir);
        exit;
    } else {
        echo "<p style='color:red;'>No image data found for this reference ID.</p>";
    }
}

$page = isset($_GET['page']) ? $_GET['page'] : 1;
$limit = 50;
$offset = ($page - 1) * $limit;
$sql_property = "SELECT * FROM mis WHERE reference_id = ? LIMIT $limit OFFSET $offset";
$stmt_property = $conn->prepare($sql_property);
$stmt_property->bind_param("s", $reference_id);
$stmt_property->execute();
$result_property = $stmt_property->get_result();
$data1 = $result_property->fetch_assoc();




// Fetch data from property_details table
$sql_property = "SELECT * FROM property_details WHERE reference_id = ?";
$stmt_property = $conn->prepare($sql_property);
$stmt_property->bind_param("s", $reference_id);
$stmt_property->execute();
$result_property = $stmt_property->get_result();
$data2= $result_property->fetch_assoc();




// Fetch data from area_valuation table
$sql_area = "SELECT * FROM address_details WHERE reference_id = ?";
$stmt_area = $conn->prepare($sql_area); 
$stmt_area->bind_param("s", $reference_id);
$stmt_area->execute();
$result_area = $stmt_area->get_result();
$data3 = $result_area->fetch_assoc();





// Fetch data from area_valuation table
$sql_area = "SELECT * FROM critical_parameters WHERE reference_id = ?";
$stmt_area = $conn->prepare($sql_area); 
$stmt_area->bind_param("s", $reference_id);
$stmt_area->execute();
$result_area = $stmt_area->get_result();
$data4 = $result_area->fetch_assoc();

 
// Fetch data from area_valuation table
$sql_area = "SELECT * FROM surroundings_details WHERE reference_id = ?";
$stmt_area = $conn->prepare($sql_area); 
$stmt_area->bind_param("s", $reference_id);
$stmt_area->execute();
$result_area = $stmt_area->get_result();
$data5 = $result_area->fetch_assoc();
$stmt_area->close();
 
// Fetch data from area_valuation table
$sql_area = "SELECT * FROM area_valuation WHERE reference_id = ?";
$stmt_area = $conn->prepare($sql_area); 
$stmt_area->bind_param("s", $reference_id);
$stmt_area->execute();
$result_area = $stmt_area->get_result();
$data6 = $result_area->fetch_assoc();
$stmt_area->close();
 



// Fetch data from area_valuation table
$sql_area = "SELECT * FROM floor_details WHERE reference_id = ?";
$stmt_area = $conn->prepare($sql_area); 
$stmt_area->bind_param("s", $reference_id);
$stmt_area->execute();
$result_area = $stmt_area->get_result();
$data8= $result_area->fetch_assoc();
$stmt_area->close();
 


// Fetch data from area_valuation table
$sql_area = "SELECT * FROM technical_details WHERE reference_id = ?";
$stmt_area = $conn->prepare($sql_area); 
$stmt_area->bind_param("s", $reference_id);
$stmt_area->execute();
$result_area = $stmt_area->get_result();
$data9 = $result_area->fetch_assoc();
$stmt_area->close();
 
// Fetch data from area_valuation table
$sql_area = "SELECT * FROM remarks_table WHERE reference_id = ?";
$stmt_area = $conn->prepare($sql_area); 
$stmt_area->bind_param("s", $reference_id);
$stmt_area->execute();
$result_area = $stmt_area->get_result();
$data10 = $result_area->fetch_assoc();
$stmt_area->close();


// Step 1: Fetch the engineer_id from the mis table
$sql_mis = "SELECT engineer_id FROM mis WHERE reference_id = ?";
$stmt_mis = $conn->prepare($sql_mis);
$stmt_mis->bind_param("s", $reference_id);
$stmt_mis->execute();
$result_mis = $stmt_mis->get_result();
$row_mis = $result_mis->fetch_assoc();
$stmt_mis->close(); 

if ($row_mis) {
    $engineer_id = $row_mis['engineer_id'];

    // Step 2: Fetch the engineer's name from engineer_login table
    $sql_engineer = "SELECT name FROM engineer_login WHERE engineer_id = ?";
    $stmt_engineer = $conn->prepare($sql_engineer);
    $stmt_engineer->bind_param("s", $engineer_id);
    $stmt_engineer->execute();
    $result_engineer = $stmt_engineer->get_result();
    $row_engineer = $result_engineer->fetch_assoc();
    $stmt_engineer->close();

    if ($row_engineer) {
        $engineer_name = $row_engineer['name'];
//         //echo "Engineer Name: " . $engineer_name;
    } else {
//        echo "Engineer not found.";
    }
} else {
    echo "No engineer assigned for this reference_id.";
}



// Step 1: Fetch the engineer_id from the mis table
$sql_mis = "SELECT report_id FROM mis WHERE reference_id = ?";
$stmt_mis = $conn->prepare($sql_mis);
$stmt_mis->bind_param("s", $reference_id);
$stmt_mis->execute();
$result_mis = $stmt_mis->get_result();
$row_mis = $result_mis->fetch_assoc();
$stmt_mis->close(); 

if ($row_mis) {
    $report_id = $row_mis['report_id'];

    // Step 2: Fetch the engineer's name from engineer_login table
    $sql_engineer = "SELECT name FROM report_login WHERE report_id = ?";
    $stmt_engineer = $conn->prepare($sql_engineer);
    $stmt_engineer->bind_param("s", $report_id);
    $stmt_engineer->execute();
    $result_engineer = $stmt_engineer->get_result();
    $row_engineer = $result_engineer->fetch_assoc();
    $stmt_engineer->close();

    if ($row_engineer) {
        $report_name = $row_engineer['name'];
 //        //echo "Engineer Name: " . $report_name;
    } else {
 //       echo "Engineer not found.";
    }
} else {
    echo "No engineer assigned for this reference_id.";
}


// Step 1: Fetch the engineer_id from the mis table
$sql_mis = "SELECT report_drafter_to_technical FROM mis WHERE reference_id = ?";
$stmt_mis = $conn->prepare($sql_mis);
$stmt_mis->bind_param("s", $reference_id);
$stmt_mis->execute();
$result_mis = $stmt_mis->get_result();
$row_mis = $result_mis->fetch_assoc();
$stmt_mis->close(); 

if ($row_mis) {
    $report_drafter_to_technical = $row_mis['report_drafter_to_technical'];

    // Step 2: Fetch the engineer's name from engineer_login table
    $sql_engineer = "SELECT name FROM technical_login WHERE technical_manager_id = ?";
    $stmt_engineer = $conn->prepare($sql_engineer);
    $stmt_engineer->bind_param("s", $report_drafter_to_technical);
    $stmt_engineer->execute();
    $result_engineer = $stmt_engineer->get_result();
    $row_engineer = $result_engineer->fetch_assoc();
    $stmt_engineer->close();

    if ($row_engineer) {
        $technical_name = $row_engineer['name'];
   //     //echo "Engineer Name: " . $technical_name;
    } else {
   //     echo "Engineer not found.";
    }
} else {
    echo "No engineer assigned for this reference_id.";
}


?>


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <style>
           .container {
            width: 90%;
            margin: 20px auto;
            border: 1px solid black;
            padding: 20px;
        }
.header-content {
    text-align: center;
    flex: 1;
}

.header-content h1 {
    margin: 0;
    margin-top:25px;  
     font-size: 30px;
    color: #902d2d;
}

.header-content p {
    margin: 2px 0;
    font-size: 20px;
    color: #333;
}
.footer{
    display: flex;
}
h3{
    background-color:rgb(243, 234, 222) ;
    padding:5px;
    text-align: center;
    border:1px solid black;
}  
               
             body {
      font-family: Arial, sans-serif;
      margin: 20px;
      font-size: 14px;
    }
    .heading {
      text-align: center;
      font-weight: bold;
      font-size: 16px;
    }
    .sub-heading {
      font-weight: bold;
      padding: 8px 0;
    }
    .info-line {
      font-size: 13px;
      margin: 5px 0;
    }
    table {
      width: 100%;
      border-collapse: collapse;
      margin-top: 10px;
    }
    th, td {
      border: 1px solid #555;
      padding: 8px;
      vertical-align: top;
    }
    th {
      background-color: #f2f2f2;
      font-weight: bold;
    }
    input[type="text"], textarea {
      width: 100%;
     border:none;
      padding: 4px;
      font-size: 13px;
      box-sizing: border-box;
    }
    textarea {
      resize: vertical;
    }
    .centered {
      text-align: center;
    }
            
  
    </style>
    <style>
 
            

.container {
    max-width: 1200px;
    margin: 20px auto;
    padding: 20px;
    background-color: white;
    box-shadow: 0px 0px 10px rgba(0, 0, 0, 0.1);
    border-radius: 8px;
}

.title {
    text-align: center;
    font-size: 24px;
    font-weight: bold;
    margin-bottom: 20px;
}
.grid-container {
    display: grid;
    grid-template-columns: repeat(4, 1fr);
    gap: 15px;
}

.grid-item {
    position: relative;
    border-radius: 8px;
    overflow: hidden;
    box-shadow: 0px 4px 6px rgba(0, 0, 0, 0.1);
}

.grid-item img {
    width: 100%;
    height: 200px;
    object-fit: cover;
    transition: transform 0.3s ease;
}
.grid-item:hover img {
    transform: scale(1.05);
}

.overlay {
    position: absolute;
    bottom: 0;
    left: 0;
    background: rgba(0, 0, 0, 0.6);
    color: white;
    width: 100%;
    padding: 8px;
    font-size: 14px;
    text-align: center;
}
 
   
/* Force a stable 4-column grid that wkhtmltopdf respects */
.image-gallery { width: 100%; }
.image-grid { width: 100%; border-collapse: collapse; table-layout: fixed; }
.image-grid tr { page-break-inside: avoid; }
.image-grid td { width: 25%; padding: 6px; vertical-align: top; }

.image-grid .img-wrap { display: block; }
.image-grid img { display: block; width: 100%; height: auto; }
.image-grid .caption { font-size: 12px; text-align: center; margin-top: 4px; }

/* If you had a flex layout before, neutralize it */
.image-gallery { display: block !important; }



    /* Print-specific rules */
    @media print {
      .no-print {
        display: none !important;
      }

      body {
        margin: 0;
      }
 
    }
  button{
    padding:8px;
    margin-left:45%;
    background-color:#808485;
    color:white;
    font-weight:700;
    font-style:italic;
  }
  button:hover{
    background-color:rgba(216,216,216,255);
    color:white;
  }

/* Optional: Google map styling */
    .google-map-container {
      max-width: 90%;
      margin: 20px auto;
      border: 2px solid #ccc;
      padding: 10px;
      box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
      background-color: #f9f9f9;
      border-radius: 8px;
      text-align: center;
    }

    .google-map-container img {
      max-width: 100%;
      height: auto;
      display: inline-block;
      border: 1px solid #999;
      border-radius: 4px;
    }
    
.logo img {
  width: 120px;
  margin-left:30px;
  height: auto;
}

 .image2-container {
      max-width: 50%;
      margin: 20px auto;
      border: 2px solid #ccc;
      padding: 10px;
      box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
      background-color: #f9f9f9;
      border-radius: 8px;
      text-align: center;
    }

    .image2-container img {
      max-width: 60%;
      height: 20%;
      display: inline-block;
      border: 1px solid #999;
      border-radius: 4px;
    }
    
 .image13-container {
      max-width: 40%;
      margin: 20px auto;
      border: 2px solid #ccc;
      padding: 10px;
      box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
      background-color: #f9f9f9;
      border-radius: 8px;
      text-align: center;
    }

    .image13-container img {
      max-width: 30%;
      height: 10%;
      display: inline-block;
      border: 1px solid #999;
      border-radius: 4px;
    }
 </style>
</head>
<body>
      <div class="container">
        <header>
            <div class="footer">
            <div class="logo">
                <img <img src="images/Magpie_logo.jpg" alt="Magpie Logo">
            </div>
            <div class="header-content">
                <h1>MAGPIE ENGINEERING PVT. LTD.</h1>
                <p>Valuer Designer Architects</p>
                <p>Address : Office no. 201, 2nd floor, Gravity Mall, Mechanic nagar, warehouse road, near vijay nagar, Indore, Madhya Pradesh- 452011</p>
            </div>
            </div>
        </header>
        <table>
            <tr>
                <td>Ref.No.: </td>
                <td colspan="3"><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data1['reference_id'] ?? '') ?>
    </span></td>
          
              </tr>
            </table>

      <table>
  </tr>
  <tr>

<div class="image2-container">
<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "project_db";
$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$reference_id = $_SESSION['reference_id'] ?? null;
$reference_id = $_GET['reference_id'] ?? $reference_id;

if ($reference_id) {
    $sql = "SELECT image1 FROM final_uploaded_images WHERE reference_id = ?";
    $stmt = $conn->prepare($sql);
    if ($stmt === false) {
        die("Error preparing the SQL statement: " . $conn->error);
    }

    $stmt->bind_param("s", $reference_id);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows > 0) {
        $row = $result->fetch_assoc();
        if (!empty($row['image1'])) {
            echo '<div><img src="data:image/jpeg;base64,' . base64_encode($row['image1']) . '" alt="Google Map"></div>';
        } else {
            echo "<p style='text-align:center;'>Google Map image not available.</p>";
        }
    } else {
        echo "<p style='text-align:center;'>No record found for Google Map image.</p>";
    }

    $stmt->close();
} else {
    echo "<p style='text-align:center;'>Reference ID is missing.</p>";
}
?>
</tr>
</div>
    </table>

<table>

            <tr>
                <th colspan="4">Valuation Report</th>
            </tr>
             <tr>
                <td> OWNER: </td>
                <td colspan="3"><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data9['owner_name'] ?? '') ?>
    </span></td>
             </tr>
             <tr>
                <td>House Address:</td>
                <td colspan="3"><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
  <?= htmlspecialchars($data3['address_per_document'] ?? '') ?>  <?= htmlspecialchars($data3['pin_code'] ?? '') ?>  </span></td>
             </tr>
              <tr>
               
                 <td>DATE : </td>
                <td><span style="display: inline-block; min-width: 50px; padding: 2px;">
 <?= htmlspecialchars(date('d M Y h:i A', strtotime($data1['report_assigned_at'] ?? ''))) ?></span></td>
            </tr>
            <tr>
              <th colspan="4">TECHFINO CAPITAL PVT. LTD.</th>
            </tr>
        </table>
        
<table style="margin-top: 0px;">
    <tr>
        <th colspan="6">APPLICATION DETAILS</th>
    </tr>
  <tr>
    <th style="width: 5%;">1</th>
    <th>Name of the Applicant</th>
    <td colspan="4"><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data1['customerName'] ?? '') ?>
    </span></td>
  </tr>
  <tr>
    <th rowspan="2">2</th>
    <th rowspan="2">Contact Person</th>
   
    <td rowspan="2"> <span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data2['person_meet_at_site_contact'] ?? '') ?>
    </span><br></td>
    <th>LANNO</th>
     <td colspan="2"><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data1['applicationNo'] ?? '') ?></span></td>
  </tr>
  <tr>
     <th>Product </th>
     <td colspan="2"><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data1['caseType'] ?? '') ?></span></td>
  </tr>
  <tr>
    <th>3</th>
    <th>Developer's Name</th>
    <td colspan="4"><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data10['NA'] ?? '') ?></span></td>
  </tr>
  <tr>
    <th>4</th>
    <th>Name of Current Property Owner(s)</th>
    <td colspan="4"><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data9['owner_name'] ?? '') ?>
    </span></td>
  </tr>
  <tr>
    <th>5</th>
    <th>Property Description</th>
    <td colspan="4"><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data2['property_unit_type'] ?? '') ?></span></td>
  </tr>
  <tr>
    <th>6</th>
    <th>Property documents verification details</th>
    <td colspan="4"><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data9['list_documents'] ?? '') ?></span></td>
  </tr>
  <tr>
    <th>7</th>
    <th>Holding Type</th>
    <td colspan="4"><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data2['property_leasehold_freehold'] ?? '') ?></span></td>
  </tr>
  <tr>
    <th>8</th>
    <th>Property Usage Actual</th>
    <td colspan="4"><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data4['current_property_usage'] ?? '') ?></span></td>
  </tr>
  <tr>
    <th>9</th>
    <th>Area Authorized For</th>
    <td colspan="4"><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data10['NA'] ?? '') ?></span></td>
  </tr>
  <tr>
    <th>10</th>
    <th>Within Municipal Limit</th>
    <td colspan="4"><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data3['property_location_in'] ?? '') ?></span></td>
  </tr>
  <tr>
    <th>11</th>
    <th>In Demolition list of Municipal Authority?</th>
    <td colspan="4"><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data10['NA'] ?? '') ?></span></td>
  </tr>
  <tr>
    <th colspan="6">MUNICIPAL DETAILS</th>
  </tr>
  <tr>
    <th rowspan="3">12</th>
    <th> Sanctioned Plan Provided </th>
    <td><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data9['floor_availability'] ?? '') ?></span></td>
    <th> Sanction/Permit No. </th>
    <td colspan="2"><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data9['floor_authority'] ?? '') ?></span></td>
  </tr>
   <tr>
    <th>Date of Sanction  </th>
    <td><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data9['floor_details'] ?? '') ?></span></td>
    <th> Valid Till </th>
    <td colspan="2"><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data10['NA'] ?? '') ?></span></td>
  </tr> 
  <tr>
    <th> Number of Floord  </th>
    <td><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data10['NA'] ?? '') ?></span></td>
    <th> Sancioning Authority </th>
    <td colspan="2"><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data9['floor_document'] ?? '') ?></span></td>
  </tr>
  <tr>
    <th colspan="6">LOCATION  DETAILS</th>
  </tr>
  <tr>
    <th rowspan="2">13</th>
    <th rowspan="2"> Address of the property </th>
    <th> Postal Address</th>
    <td colspan="3"><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data3['address_per_document'] ?? '') ?>   <?= htmlspecialchars($data3['pin_code'] ?? '') ?>
</span></td>
  </tr>
  <tr>
     <th> Technical  Address</th>
    <td colspan="4"><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data3['address_per_site'] ?? '') ?>
    </span></td>
  </tr>
  <tr>
    <th>14</th>
    <th>Person Met</th>
    <td colspan="4"><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data2['person_meet_at_site_contact'] ?? '') ?></span></td>
  </tr>
   <tr>
    <th>15</th>
    <th>Landmark</th>
    <td colspan="4"><span style="display: inline-block; min-width: 50px; padding: 2px;">
       <?= htmlspecialchars($data3['landmark_1'] ?? '') ?><?= htmlspecialchars($data3['landmark_2'] ?? '') ?></span></td>
  </tr>

  <tr>
    <th rowspan="4">16</th>
    <th>Site Boundaries</th>
    <th>North</th>
    <th>South</th>
    <th>East</th>
    <th>West</th>
  </tr>  
  <tr> 
    <td class="section-heading">As per Document 1</td>
    <td><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data3['direction_as_per_document_north'] ?? '') ?>
    </span></td>
    <td><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data3['direction_as_per_document_south'] ?? '') ?>
    </span></td>
    <td><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data3['direction_as_per_document_east'] ?? '') ?>
    </span></td>
    <td><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data3['direction_as_per_document_west'] ?? '') ?>
    </span></td>
  </tr>   
  
   <tr> 
    <td class="section-heading">As per Document 2</td>
    <td><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data3['direction_approved_north'] ?? '') ?>
    </span></td>
    <td><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data3['direction_approved_south'] ?? '') ?>
    </span></td>
    <td><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data3['direction_approved_east'] ?? '') ?>
    </span></td>
    <td> <span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data3['direction_approved_west'] ?? '') ?>
    </span></td>
  </tr>  

  <tr>    
    <td class="section-heading">As per Visit</td>
    <td><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data3['direction_as_per_site_north'] ?? '') ?>
    </span></td>
    <td><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data3['direction_as_per_site_south'] ?? '') ?>
    </span></td>
    <td><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data3['direction_as_per_site_east'] ?? '') ?>
    </span></td>
    <td> <span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data3['direction_as_per_site_west'] ?? '') ?>
    </span></td>
  </tr>

  <tr>
    <th rowspan="4">16(a)</th>
    <th>Site Dimension (in Ft)</th>
    <th>North</th>
    <th>South</th>
    <th>East</th>
    <th>West</th>
  </tr>  
  <tr> 
    <th>As per Document 1</th>  
     <td><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data6['dimension_as_per_document_north'] ?? '') ?>
    </span></td>
    <td><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data6['dimension_as_per_document_south'] ?? '') ?>
    </span></td>
    <td><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data6['dimension_as_per_document_east'] ?? '') ?>
    </span></td>
    <td> <span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data6['dimension_as_per_document_west'] ?? '') ?>
    </span></td>
        </tr>   

          <tr> 
    <th>As per Document 2</th>  
     <td><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data8['plinth_present_completion'] ?? '') ?>
    </span></td>
    <td><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data8['rcc_present_completion'] ?? '') ?>
    </span></td>
    <td><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data8['brickwork_present_completion'] ?? '') ?>
    </span></td>
    <td> <span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data8['internal_plaster_present_completion'] ?? '') ?>
    </span></td>
        </tr> 

            <tr>
                <th>As per Actual</th>
                 <td><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data6['dimension_as_per_site_north'] ?? '') ?>
    </span></td>
    <td><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data6['dimension_as_per_site_south'] ?? '') ?>
    </span></td>
    <td><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data6['dimension_as_per_site_east'] ?? '') ?>
    </span></td>
    <td> <span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data6['dimension_as_per_site_west'] ?? '') ?>
    </span></td>
  </tr>
  <tr>
    <th>17</th>
    <th>Neighbor hood Type</th>
    <td colspan="4"><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data2['property_unit_type'] ?? '') ?></span></td>
  </tr>
  <tr>
    <th>18</th>
    <th>Marketability</th>
    <td colspan="4"><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data9['markebility'] ?? '') ?></span></td>
  </tr>
  <tr>
    <th>19</th>
    <th>Is Property Easily Locatable/Identifiable</th>
    <td colspan="4"><input type="text" readonly  name="engineer_id" value="YES"></td>
  </tr>
  <tr>
    <th>20</th>
    <th>Connectivity</th>
    <td colspan="4"><input type="text" readonly  name="engineer_id" value="Available"></td>
  </tr>
  <tr>
    <th>21</th>
    <th>Proximity to Amenities</th>
    <td colspan="4"><input type="text" readonly  name="engineer_id" value="Available"></td>
  </tr>
  <tr>
    <th>22</th>
    <th>Accessibility</th>
    <td colspan="4"><input type="text" readonly  name="engineer_id" value="Available"></td>
  </tr>
 <tr>
    <th>23</th>
    <th>Site Access</th>
    <td colspan="4"><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data2['width_of_approach_road'] ?? '') ?></span></td>
  </tr>
  <tr><th colspan="6" class="section-heading">Technical Details</th></tr>
  <tr>

    <th>24</th>
    <th>Type of Property</th>
    <td colspan="4"><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data2['property_unit_type'] ?? '') ?></span></td>
  </tr>
  <tr>
    <th>25</th>
    <th>No. of Stories</th>
    <td colspan="4"><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data8['basements_remarks'] ?? '') ?></span></td>
  </tr>
  <tr>
    <th>26</th>
    <th>Tenement Position</th>
    <td colspan="4"><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data10['NA'] ?? '') ?></span></td>
  </tr>
  <tr>
    <th>27</th>
    <th>Construction Type</th>
    <td colspan="4"><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data4['structure_type'] ?? '') ?></span></td>
  </tr>
  <tr>
    <th>28</th>
    <th>No. of Lifts, If Any</th>
    <td colspan="4"><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data8['number_of_lifts'] ?? '') ?></span></td>
  </tr>
  <tr>
    <th>29</th>
    <th>Accommodation</th>
    <td colspan="4"><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data10['NA'] ?? '') ?></span></td>
  </tr>
  <tr>
    <th>30</th>
    <th>Occupant Status</th>
    <td colspan="4"><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data2['occupancy_status'] ?? '') ?></span></td>
  </tr>
  <tr>
    <th>32</th>
    <th>Details of Commercial Usage of Any </th>
    <td colspan="4"><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data4['current_property_usage'] ?? '') ?></span></td>
  </tr>
  <tr>
    <th rowspan="5">33</th>
    <th rowspan="5"> Finishes </th>
    <th>Exterior</th>
    <td colspan="3"><input type="text" readonly  name="engineer_id" value="Average"></td>
  </tr>
  <tr>
     <th>Wall Finish</th>
    <td colspan="3"><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data10['NA'] ?? '') ?></span></td>
  </tr>
  <tr>
    <th>Flooring</th>
    <td colspan="3"><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data10['NA'] ?? '') ?></span></td> 
  </tr>
  <tr>
     <th>Door/Windows</th>
    <td colspan="3"><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data10['NA'] ?? '') ?></span></td>
  </tr>
  <tr>
     <th>Fittings</th>
    <td colspan="3"><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data10['NA'] ?? '') ?></span></td>
  </tr>
  <tr>
    <th rowspan="2">34</th>
    <th rowspan="2">Land Area </th>
<td><input type="text" readonly  name="engineer_id"  
value="<?= isset($data6['plot_square_feet']) ? round(floatval($data6['plot_square_feet']) * 0.092903, 2) : '' ?>"></td>
        <th>Sq.Mtr</th> 
    <td colspan=""><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data6['plot_square_feet'] ?? '') ?></span></td>
    <th>Sq.Ft (Document)</th>
  </tr>
  <tr>
    <td>
    <input type="text" readonly  name="engineer_id"  
        value="<?= isset($data6['actual_plot_square_feet']) ? round(floatval($data6['actual_plot_square_feet']) * 0.092903, 2) : '' ?>">
</td>
    <th>Sq.Mtr</th> 
    <td colspan=""><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data6['actual_plot_square_feet'] ?? '') ?></span></td>
    <th>Sq.Ft (Site)</th>
  </tr>
  <tr>
    <th rowspan="3">35</th>
    <th rowspan="3"> Area of Unit </th>
    <td colspan=""><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data6['construction_area_sqft_1']) ? round(floatval($data6['construction_area_sqft_1']) * 0.092903, 2) : '' ?></span></td>
    <th>Sq.Mtr</th> 
    <td colspan=""><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data6['construction_area_sqft_1'] ?? '') ?></span></td>
    <th>Sq.Ft (OnSite-RCC)</th>
  </tr>
  <tr>
    <td colspan=""><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data2['NA'] ?? '') ?></span></td>
    <th>Sq.Mtr</th> 
    <td colspan=""><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data2['NA'] ?? '') ?></span></td>
    <th>Sq.Ft (OnSite-Tinshed)</th>
  </tr>
  <tr> 
     <td colspan=""><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data10['NA'] ?? '') ?></span></td>
    <th>Sq.Mtr</th> 
    <td colspan=""><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data10['NA'] ?? '') ?></span></td>
    <th>Sq.Ft (BUA-Permissible)</th>
  </tr>
  <tr><th colspan="6" class="section-heading">COMPLETION STATUS </th></tr>
  <TR>
    <th>36</th>
   <th>Stage of Construction</th>
   <th>Progressing %</th>
   <td colspan=""><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data8['stage_construction_actual_present_completion'] ?? '') ?></span></td>
   <th>Recommended %</th>
   <td colspan=""><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data8['stage_construction_recommend_present_completion'] ?? '') ?></span></td>
  </TR>
   <tr>
    <th>37</th>
    <th>Age of the Property</th>
    <td colspan="2"><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data2['age_of_property'] ?? '') ?></span></td>
    <th colspan="2">YEAR</th>
  </tr>
  <tr>
    <th>38</th>
    <th>Residual Age</th>
    <td colspan="2"><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data2['residual_age_of_property'] ?? '') ?></span></td>
    <th colspan="2">YEAR</th>
  </tr>
  <tr><th colspan="6" class="section-heading"> VALUATION </th></tr>
  <tr>
    <th rowspan="3">39</th>
    <th> </th>
    <th>Area(Sq. Ft.)</th>
    <th>Rate(In Rs.)</th>
    <th colspan="2">Total Amount(In Rs.)</th>
  </tr>
  <tr>
    <th>Land/Land Share</th>
    <td><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data6['final_plot_square_feet'] ?? '') ?></span></td>
    <td><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data6['final_plot_rate'] ?? '') ?></span></td>
    <td colspan="2"><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data6['finally_plot_valuation'] ?? '') ?></span></td>
  </tr>
  <tr>
    <th>Built up Area</th>
    <td><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data6['final_construction_square_feet'] ?? '') ?></span></td>
    <td><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data6['final_construction_rate'] ?? '') ?></span></td>
    <td colspan="2"><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data6['finally_construction_valuation'] ?? '') ?></span></td>
  </tr>
  <tr>
    <th>40</th>
    <th colspan="3" class="section-title">MARKET VALUE</th>
    <td colspan="2">₹ <span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data6['total_finally_area_valuation'] ?? '') ?></span></td>
  </tr>
  <tr>
    <th>41</th>
    <th colspan="3">SAY</th>
    <td colspan="2"> <span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data10['NA'] ?? '') ?></span></td>
  </tr>
  <tr><th colspan="6" class="section-title">THUS IN MY OPINION</th></tr>
   <tr>
    <th>1</th>
    <th colspan="3">Fair Market Value of Property</th>
    <td colspan="2">₹ <span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data6['total_finally_area_valuation'] ?? '') ?></span></td>
  </tr>
  <tr>
    <th>2</th>
    <th colspan="3">Distress Value</th>
    <td colspan="2">₹ <span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data6['total_distress_value'] ?? '') ?></span></td>
  </tr>
    <tr>
      <th colspan="6"> REMARKS </th>
      </tr>
         <tr>
          <td colspan="6"><span style="white-space: pre-line; font-size:14px; display: block; text-align: left; padding: 0; margin: 0;font-weight:400;"readonly>
        <?= htmlspecialchars($data10['remarks'] ?? '') ?>
    </span></td>
         </tr>
       <tr>
        <th colspan="6">FACTORS TAKEN INTO CONSIDERATION  </th>
            </tr>
              <tr>
                <td colspan="6"><span style="white-space: pre-line; font-size:14px; display: block; text-align: left; padding: 0; margin: 0;font-weight:400;"readonly>
                
                   •? The right to sell/transfer/leaseof land.
                   •? Free-hold or lease-hold nature of land.
                   •? Legal and physical end cum brace on land.
                   •? Depreciation for physical wear sand tears.
                   •? Utility and design of such building structure.
                   •? Age, remaining use fule economic life of the structure.
                   •? Type of genera land special specification of construction.
                   •? Obsolescence–Techno logical, functional land economic.
                   •? Actual physical condition, state of repairs and maintenance.
                   •? Demand and prospective buyers for such type of Property
</span>
                </td>
              </tr>
        <tr>
        <th colspan="6">UNDERTAKING</th>
        </tr>
          <tr>
            <td colspan="6"><span style="white-space: pre-line; font-size:14px; display: block; text-align: left; padding: 0; margin: 0;font-weight:400;" readonly>
    <?= nl2br(htmlspecialchars(formatDeclaration($data10['declaration'] ?? ''))) ?>
</span></td>
          </tr>
            <?php
function formatDeclaration($text) {
    // Insert a newline before every occurrence of a number followed by a dot and space (e.g., "1. ", "10. ")
    // Only if it's NOT already at the beginning of the string or a new line
    $text = preg_replace('/(?<!^)(?<!\n)(\d+\.\s)/', "\n$1", $text);
    return $text;
}
?>
    </table>


  <table>
<tr><th style="margin-bottom:-18px;">PHOTOGRAPH OF THE PROPERTY</tr></th></table>
<br>

<br>
<div class="container">
    <div class="image-gallery">
<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "project_db";
$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$reference_id = $_SESSION['reference_id'] ?? null;
$reference_id = $_GET['reference_id'] ?? $reference_id;

if ($reference_id) {
    $sql = "SELECT 
                image1, image2, image3, image4, 
                image6, image7, image8, image9, 
                image10, image11, image12, image14, image15, image16, image17, image18, image19, image20
            FROM final_uploaded_images 
            WHERE reference_id = ?";

    $stmt = $conn->prepare($sql);
    if ($stmt === false) {
        die("Error preparing the SQL statement: " . $conn->error);
    }

    $stmt->bind_param("s", $reference_id);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows > 0) {
        while ($row = $result->fetch_assoc()) {
            if (!empty($row['image1'])) {
                echo '<div><img src="data:image/jpeg;base64,' . base64_encode($row['image1']) . '" alt="Image 1"><p>EXTERNAL PHOTOS</p></div>';
            }
            if (!empty($row['image2'])) {
                echo '<div><img src="data:image/jpeg;base64,' . base64_encode($row['image2']) . '" alt="Image 2"><p>Kitchen</p></div>';
            }
            if (!empty($row['image3'])) {
                echo '<div><img src="data:image/jpeg;base64,' . base64_encode($row['image3']) . '" alt="Image 3"><p>Selfie</p></div>';
            }
            if (!empty($row['image4'])) {
                echo '<div><img src="data:image/jpeg;base64,' . base64_encode($row['image4']) . '" alt="Image 4"><p>Electric Meter</p></div>';
            }
             if (!empty($row['image5'])) {
                echo '<div><img src="data:image/jpeg;base64,' . base64_encode($row['image5']) . '" alt="Image 5"><p>Other </p></div>';
            }
            if (!empty($row['image6'])) {
                echo '<div><img src="data:image/jpeg;base64,' . base64_encode($row['image6']) . '" alt="Image 6"><p>Other 1</p></div>';
            }
            if (!empty($row['image7'])) {
                echo '<div><img src="data:image/jpeg;base64,' . base64_encode($row['image7']) . '" alt="Image 7"><p>Other 2</p></div>';
            }
            if (!empty($row['image8'])) {
                echo '<div><img src="data:image/jpeg;base64,' . base64_encode($row['image8']) . '" alt="Image 8"><p>Other 3</p></div>';
            }
            if (!empty($row['image9'])) {
                echo '<div><img src="data:image/jpeg;base64,' . base64_encode($row['image9']) . '" alt="Image 9"><p>Other 4</p></div>';
            }
            if (!empty($row['image10'])) {
                echo '<div><img src="data:image/jpeg;base64,' . base64_encode($row['image10']) . '" alt="Image 10"><p>Other 5</p></div>';
            }
            if (!empty($row['image11'])) {
                echo '<div><img src="data:image/jpeg;base64,' . base64_encode($row['image11']) . '" alt="Image 11"><p>Other 6</p></div>';
            }
            if (!empty($row['image12'])) {
                echo '<div><img src="data:image/jpeg;base64,' . base64_encode($row['image12']) . '" alt="Image 12"><p>Other 7</p></div>';
            }

if (!empty($row['image14'])) {
    echo '<div><img src="data:image/jpeg;base64,' . base64_encode($row['image14']) . '" alt="Image 14"><p>Other 9</p></div>';
}
if (!empty($row['image15'])) {
    echo '<div><img src="data:image/jpeg;base64,' . base64_encode($row['image15']) . '" alt="Image 15"><p>Other 10</p></div>';
}
if (!empty($row['image16'])) {
    echo '<div><img src="data:image/jpeg;base64,' . base64_encode($row['image16']) . '" alt="Image 16"><p>Other 11</p></div>';
}
if (!empty($row['image17'])) {
    echo '<div><img src="data:image/jpeg;base64,' . base64_encode($row['image17']) . '" alt="Image 17"><p>Other 12</p></div>';
}
if (!empty($row['image18'])) {
    echo '<div><img src="data:image/jpeg;base64,' . base64_encode($row['image18']) . '" alt="Image 18"><p>Other 13</p></div>';
}
if (!empty($row['image19'])) {
    echo '<div><img src="data:image/jpeg;base64,' . base64_encode($row['image19']) . '" alt="Image 19"><p>Other 14</p></div>';
}
if (!empty($row['image20'])) {
    echo '<div><img src="data:image/jpeg;base64,' . base64_encode($row['image20']) . '" alt="Image 20"><p>Other 15</p></div>';
}

        }
    } else {
        echo "<p style='text-align:center;'>No images found.</p>";
    }

    $stmt->close();
} else {
    echo "<p style='text-align:center;'>Reference ID is missing.</p>";
}
?>
    </div>
</div>
 
  <table>
<tr><th style="margin-bottom:-18px;">Location cum Route map showing property boundaries</tr></th></table>
      <table>

  <tr>

<div class="google-map-container">
<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "project_db";
$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$reference_id = $_SESSION['reference_id'] ?? null;
$reference_id = $_GET['reference_id'] ?? $reference_id;

if ($reference_id) {
    $sql = "SELECT image5 FROM final_uploaded_images WHERE reference_id = ?";
    $stmt = $conn->prepare($sql);
    if ($stmt === false) {
        die("Error preparing the SQL statement: " . $conn->error);
    }

    $stmt->bind_param("s", $reference_id);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows > 0) {
        $row = $result->fetch_assoc();
        if (!empty($row['image5'])) {
            echo '<div><img src="data:image/jpeg;base64,' . base64_encode($row['image5']) . '" alt="Google Map"><p>Google Map</p></div>';
        } else {
            echo "<p style='text-align:center;'>Google Map image not available.</p>";
        }
    }  
    $stmt->close();
} else {
    echo "<p style='text-align:center;'>Reference ID is missing.</p>";
}
?>
</tr>
</div>
    </table>
    <table>

  <tr>

<div>
<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "project_db";
$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$reference_id = $_SESSION['reference_id'] ?? null;
$reference_id = $_GET['reference_id'] ?? $reference_id;

if ($reference_id) {
    $sql = "SELECT image13 FROM final_uploaded_images WHERE reference_id = ?";
    $stmt = $conn->prepare($sql);
    if ($stmt === false) {
        die("Error preparing the SQL statement: " . $conn->error);
    }

    $stmt->bind_param("s", $reference_id);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows > 0) {
        $row = $result->fetch_assoc();
        if (!empty($row['image13'])) {
            echo '<div><img src="data:image/jpeg;base64,' . base64_encode($row['image13']) . '" alt="Google Map"><p>Khasra</p></div>';
        } 
    } 

    $stmt->close();
} else {
    echo "<p style='text-align:center;'>Reference ID is missing.</p>";
}
?>
</tr>
</div>
    </table>
    </table>
     
   <!-- Buttons: Hidden during print -->
<div class="no-print">
  <form method="post">
    <input type="hidden" name="download_images" value="1">
    <button type="submit">Download All Images</button>
  </form>

  <button id="downloadPdf" onclick="setPrintMargins()">DOWNLOAD PDF</button>
</div>

  <script>
    document.getElementById('downloadPdf').addEventListener('click', () => {
      // Select the content you want to convert to PDF
      const element = document.getElementById('content');
      const options = {
        margin:[0,0],
        filename:'report.pdf',
        image: { type: 'jpeg', quality: 0.98 },
        html2canvas: { scale: 2 },
        jsPDF: { unit: 'in', format: 'letter', orientation: 'portrait' }
      };

      // Generate and download the PDF
      html2pdf().set(options).from(element).save();
    });
    function setPrintMargins() {
      const style = document.createElement('style');
      style.innerHTML = `
      @media print {
          body {
            margin:0.5;
          }
        }
      `;
      document.head.appendChild(style);
      window.print();
    }
    // Disable all input fields in the form
    document.querySelectorAll('input').forEach(function(input) {
        input.disabled = true;  // Disables the field completely
    });
     function resizeFakeInput(input) {
    const fake = document.getElementById('fakeWrap');
    fake.textContent = input.value || ' ';
    input.style.height = fake.scrollHeight + 'px';
  }

  // Initialize height
  resizeFakeInput(document.getElementById('longInput'));
   function autoResize(el) {
    el.style.height = 'auto'; // reset height
    el.style.height = el.scrollHeight + 'px'; // set to content height
  }
  // Auto-resize on load
  document.querySelectorAll('.clean-textarea').forEach(t => autoResize(t));
    </script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/jspdf/2.5.1/jspdf.umd.min.js"></script>

  <script>
    // Disable input fields before generating PDF
    function disableInputs() {
      document.querySelectorAll('input, textarea').forEach(input => input.disabled = true);
    }

    // Re-enable input fields after PDF generation (optional)
    function enableInputs() {
      document.querySelectorAll('input, textarea').forEach(input => input.disabled = false);
    }

    // Auto-resize textareas
    function autoResize(el) {
      el.style.height = 'auto';
      el.style.height = el.scrollHeight + 'px';
    }

    document.querySelectorAll('.clean-textarea').forEach(t => autoResize(t));

    // PDF generation logic using jsPDF with html()
    document.getElementById('downloadPdf').addEventListener('click', async () => {
      disableInputs();

      const { jsPDF } = window.jspdf;
      const doc = new jsPDF({
        orientation: 'portrait',
        unit: 'pt',
        format: 'a4'
      });

      await doc.html(document.getElementById('content'), {
        callback: function (doc) {
          doc.save('report.pdf');
          enableInputs();
        },
        margin: [40, 40, 40, 40],
        autoPaging: 'text',
        x: 10,
        y: 10,
        html2canvas: {
          scale: 1,
          useCORS: true
        }
      });
    });
  </script>
</div>
</body>
</html>

