<?php
session_start();
if (!isset($_SESSION["cso_id"])) {
    header("Location: login.php");
    exit();
}
?>
