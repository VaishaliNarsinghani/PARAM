<?php include('auth.php'); ?>
<?php include 'watermark.html'; ?>

<?php
ini_set('display_errors', 1);
error_reporting(E_ALL);

// Increase these limits further at the beginning of your script
ini_set('memory_limit', '8192M'); // Double the memory
ini_set('max_execution_time', 1200); // Double the execution time

// Database credentials
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "project_db";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Retrieve reference_id from session
if (!isset($_SESSION['reference_id'])) {
    die("Error: Reference ID not found.");
}

$reference_id = $_SESSION['reference_id'];


if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['download_images'])) {

    // Get customer name
    $stmt_name = $conn->prepare("SELECT customerName FROM mis WHERE reference_id = ?");
    $stmt_name->bind_param("s", $reference_id);
    $stmt_name->execute();
    $result_name = $stmt_name->get_result();
    $customerName = "customer";
    if ($row = $result_name->fetch_assoc()) {
        $customerName = preg_replace('/[^a-zA-Z0-9]/', '', $row['customerName']);
    }
    $stmt_name->close();

    // Fetch image BLOBs
    $stmt = $conn->prepare("SELECT image1, image2, image3, image4, image5, image6, image7, image8, image9, image10, image11, image12,image13, image14, image15, image16, image17, image18, image19, image20 FROM final_uploaded_images WHERE reference_id = ?");    $stmt->bind_param("s", $reference_id);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows > 0 && ($row = $result->fetch_assoc())) {
        $tempDir = sys_get_temp_dir() . DIRECTORY_SEPARATOR . uniqid('images_', true);
        mkdir($tempDir);

        $imageFiles = [];
        for ($i = 1; $i <= 12; $i++) {
            if (!empty($row["image$i"])) {
                $filename = $tempDir . DIRECTORY_SEPARATOR . "image{$i}.jpg";
                file_put_contents($filename, $row["image$i"]);
                $imageFiles[] = $filename;
            }
        }

        if (empty($imageFiles)) {
            die("No images to download.");
        }

        // Create ZIP
        $zipFileName = "images_" . preg_replace('/[^a-zA-Z0-9]/', '_', $reference_id) . "_{$customerName}.zip";
        $zipPath = $tempDir . DIRECTORY_SEPARATOR . $zipFileName;

        $zip = new ZipArchive();
        if ($zip->open($zipPath, ZipArchive::CREATE) !== TRUE) {
            die("Failed to create ZIP file.");
        }

        foreach ($imageFiles as $file) {
            $zip->addFile($file, basename($file));
        }
        $zip->close();

        // Send ZIP to browser
        header('Content-Type: application/zip');
        header('Content-Disposition: attachment; filename="' . basename($zipFileName) . '"');
        header('Content-Length: ' . filesize($zipPath));
        flush();
        readfile($zipPath);

        // Cleanup
        foreach ($imageFiles as $file) {
            unlink($file);
        }
        unlink($zipPath);
        rmdir($tempDir);
        exit;
    } else {
        echo "<p style='color:red;'>No image data found for this reference ID.</p>";
    }
}

// Debugging: Output for verification
//echo "Session reference_id: " . htmlspecialchars($reference_id) . "<br>";


$page = isset($_GET['page']) ? $_GET['page'] : 1;
$limit = 50;
$offset = ($page - 1) * $limit;
$sql_property = "SELECT * FROM mis WHERE reference_id = ? LIMIT $limit OFFSET $offset";
$stmt_property = $conn->prepare($sql_property);
$stmt_property->bind_param("s", $reference_id);
$stmt_property->execute();
$result_property = $stmt_property->get_result();
$data1 = $result_property->fetch_assoc();




// Fetch data from property_details table
$sql_property = "SELECT * FROM property_details WHERE reference_id = ?";
$stmt_property = $conn->prepare($sql_property);
$stmt_property->bind_param("s", $reference_id);
$stmt_property->execute();
$result_property = $stmt_property->get_result();
$data2= $result_property->fetch_assoc();




// Fetch data from area_valuation table
$sql_area = "SELECT * FROM address_details WHERE reference_id = ?";
$stmt_area = $conn->prepare($sql_area); 
$stmt_area->bind_param("s", $reference_id);
$stmt_area->execute();
$result_area = $stmt_area->get_result();
$data3 = $result_area->fetch_assoc();





// Fetch data from area_valuation table
$sql_area = "SELECT * FROM critical_parameters WHERE reference_id = ?";
$stmt_area = $conn->prepare($sql_area); 
$stmt_area->bind_param("s", $reference_id);
$stmt_area->execute();
$result_area = $stmt_area->get_result();
$data4 = $result_area->fetch_assoc();

 
// Fetch data from area_valuation table
$sql_area = "SELECT * FROM surroundings_details WHERE reference_id = ?";
$stmt_area = $conn->prepare($sql_area); 
$stmt_area->bind_param("s", $reference_id);
$stmt_area->execute();
$result_area = $stmt_area->get_result();
$data5 = $result_area->fetch_assoc();
$stmt_area->close();
 
// Fetch data from area_valuation table
$sql_area = "SELECT * FROM area_valuation WHERE reference_id = ?";
$stmt_area = $conn->prepare($sql_area); 
$stmt_area->bind_param("s", $reference_id);
$stmt_area->execute();
$result_area = $stmt_area->get_result();
$data6 = $result_area->fetch_assoc();
$stmt_area->close();
 



// Fetch data from area_valuation table
$sql_area = "SELECT * FROM floor_details WHERE reference_id = ?";
$stmt_area = $conn->prepare($sql_area); 
$stmt_area->bind_param("s", $reference_id);
$stmt_area->execute();
$result_area = $stmt_area->get_result();
$data8= $result_area->fetch_assoc();
$stmt_area->close();
 


// Fetch data from area_valuation table
$sql_area = "SELECT * FROM technical_details WHERE reference_id = ?";
$stmt_area = $conn->prepare($sql_area); 
$stmt_area->bind_param("s", $reference_id);
$stmt_area->execute();
$result_area = $stmt_area->get_result();
$data9 = $result_area->fetch_assoc();
$stmt_area->close();
 
// Fetch data from area_valuation table
$sql_area = "SELECT * FROM remarks_table WHERE reference_id = ?";
$stmt_area = $conn->prepare($sql_area); 
$stmt_area->bind_param("s", $reference_id);
$stmt_area->execute();
$result_area = $stmt_area->get_result();
$data10 = $result_area->fetch_assoc();
$stmt_area->close();


// Step 1: Fetch the engineer_id from the mis table
$sql_mis = "SELECT engineer_id FROM mis WHERE reference_id = ?";
$stmt_mis = $conn->prepare($sql_mis);
$stmt_mis->bind_param("s", $reference_id);
$stmt_mis->execute();
$result_mis = $stmt_mis->get_result();
$row_mis = $result_mis->fetch_assoc();
$stmt_mis->close(); 

if ($row_mis) {
    $engineer_id = $row_mis['engineer_id'];

    // Step 2: Fetch the engineer's name from engineer_login table
    $sql_engineer = "SELECT name FROM engineer_login WHERE engineer_id = ?";
    $stmt_engineer = $conn->prepare($sql_engineer);
    $stmt_engineer->bind_param("s", $engineer_id);
    $stmt_engineer->execute();
    $result_engineer = $stmt_engineer->get_result();
    $row_engineer = $result_engineer->fetch_assoc();
    $stmt_engineer->close();

    if ($row_engineer) {
        $engineer_name = $row_engineer['name'];
         //echo "Engineer Name: " . $engineer_name;
    } else {
        echo "Engineer not found.";
    }
} else {
    echo "No engineer assigned for this reference_id.";
}



// Step 1: Fetch the engineer_id from the mis table
$sql_mis = "SELECT report_id FROM mis WHERE reference_id = ?";
$stmt_mis = $conn->prepare($sql_mis);
$stmt_mis->bind_param("s", $reference_id);
$stmt_mis->execute();
$result_mis = $stmt_mis->get_result();
$row_mis = $result_mis->fetch_assoc();
$stmt_mis->close(); 

if ($row_mis) {
    $report_id = $row_mis['report_id'];

    // Step 2: Fetch the engineer's name from engineer_login table
    $sql_engineer = "SELECT name FROM report_login WHERE report_id = ?";
    $stmt_engineer = $conn->prepare($sql_engineer);
    $stmt_engineer->bind_param("s", $report_id);
    $stmt_engineer->execute();
    $result_engineer = $stmt_engineer->get_result();
    $row_engineer = $result_engineer->fetch_assoc();
    $stmt_engineer->close();

    if ($row_engineer) {
        $report_name = $row_engineer['name'];
         //echo "Engineer Name: " . $report_name;
    } else {
        echo "Engineer not found.";
    }
} else {
    echo "No engineer assigned for this reference_id.";
}


// Step 1: Fetch the engineer_id from the mis table
$sql_mis = "SELECT report_drafter_to_technical FROM mis WHERE reference_id = ?";
$stmt_mis = $conn->prepare($sql_mis);
$stmt_mis->bind_param("s", $reference_id);
$stmt_mis->execute();
$result_mis = $stmt_mis->get_result();
$row_mis = $result_mis->fetch_assoc();
$stmt_mis->close(); 

if ($row_mis) {
    $report_drafter_to_technical = $row_mis['report_drafter_to_technical'];

    // Step 2: Fetch the engineer's name from engineer_login table
    $sql_engineer = "SELECT name FROM technical_login WHERE technical_manager_id = ?";
    $stmt_engineer = $conn->prepare($sql_engineer);
    $stmt_engineer->bind_param("s", $report_drafter_to_technical);
    $stmt_engineer->execute();
    $result_engineer = $stmt_engineer->get_result();
    $row_engineer = $result_engineer->fetch_assoc();
    $stmt_engineer->close();

    if ($row_engineer) {
        $technical_name = $row_engineer['name'];
        //echo "Engineer Name: " . $technical_name;
    } else {
        echo "Engineer not found.";
    }
} else {
    echo "No engineer assigned for this reference_id.";
}
?>
 <!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="UTF-8" />
    <title>Valuation Report Form</title>
    <style>
      body {
        font-family: Arial, sans-serif;
        margin: 0;
        padding: 10px;
      }

      .container {
        max-width: 1200px;
        margin: auto;
        padding: 10px;
        border: 2px solid #000;
      }
      table {
        width: 100%;
        border-collapse: collapse;
      }
      th,
      td {
        border: 1px solid #000;
        padding: 3px 5px;
        font-size: 15px;
        vertical-align: center;
        text-align: center;
      }
      th {
        font-weight: bold;
      }

      input[type="text"] {
        width: 100%;
        border:none;
        outline: none;
        text-align: center;
      }
             button{
  padding:8px;
  margin-left:45%;
  background-color:#5d5e5f8f ;
  font-weight:500;
  font-style:italic;
}
button:hover{
  background-color:#bdbabaf4 ;
}
@media print{
  body{
    margin:0;
  }
  button{
    display:none;
    margin-left:30%;
  }

  }
  pre{
      font-size:15px;
      font-family: Arial, sans-serif;
      font-style: oblique;
  }
  textarea{
      width:100%;
    height:200px;
  }
  .number-column {
    width: 40px;
    text-align: center;
    font-weight: bold;
}

      input[type="text"] {
        width: 100%;
        padding: 6px;
        text-align: left;
        box-sizing: border-box;
        border: 1px solid #ccc;
        border-radius: 4px;
      }
      .photo-gallery {
      display: grid;
      grid-template-columns: repeat(4, 1fr);
      gap: 10px;
    }
    .photo-gallery img {
      width: 100%;
      height: auto;
      border: 1px solid #000;
    }
            
.header-content {
    text-align: center;
    flex: 1;
}

.header-content h1 {
    margin: 0;
    margin-top:25px;  
    font-size: 35px;
    color: #902d2d;
}

.header-content p {
    margin: 2px 0;
    font-size: 16px;
    color: #381515;
}
.footer{
    display: flex;
}
.blue{
    background-color:#dce6f1;
}
.green{
    background-color:#ebf1de;
}
.pink{
    background-color:#f2dcdb;
}

    </style>
     <style>
 
            

.container {
    max-width: 1200px;
    margin: 20px auto;
    padding: 20px;
    background-color: white;
    box-shadow: 0px 0px 10px rgba(0, 0, 0, 0.1);
    border-radius: 8px;
}

.title {
    text-align: center;
    font-size: 24px;
    font-weight: bold;
    margin-bottom: 20px;
}
.grid-container {
    display: grid;
    grid-template-columns: repeat(4, 1fr);
    gap: 15px;
}

.grid-item {
    position: relative;
    border-radius: 8px;
    overflow: hidden;
    box-shadow: 0px 4px 6px rgba(0, 0, 0, 0.1);
}

.grid-item img {
    width: 100%;
    height: 200px;
    object-fit: cover;
    transition: transform 0.3s ease;
}
.grid-item:hover img {
    transform: scale(1.05);
}

.overlay {
    position: absolute;
    bottom: 0;
    left: 0;
    background: rgba(0, 0, 0, 0.6);
    color: white;
    width: 100%;
    padding: 8px;
    font-size: 14px;
    text-align: center;
}
 


    /* Print-specific rules */
    @media print {
      .no-print {
        display: none !important;
      }

      body {
        margin: 0;
      }
 
    }
  button{
    padding:8px;
    margin-left:45%;
    background-color:#808485;
    color:white;
    font-weight:700;
    font-style:italic;
  }
  button:hover{
    background-color:rgba(216,216,216,255);
    color:white;
  }

/* Optional: Google map styling */

.logo img {
  width: 120px;
  margin-left:30px;
  height: auto;
}

 </style>
   <style>
 
            

.container {
    max-width: 1200px;
    margin: 20px auto;
    padding: 20px;
    background-color: white;
    box-shadow: 0px 0px 10px rgba(0, 0, 0, 0.1);
    border-radius: 8px;
}

.title {
    text-align: center;
    font-size: 24px;
    font-weight: bold;
    margin-bottom: 20px;
}
.grid-container {
    display: grid;
    grid-template-columns: repeat(4, 1fr);
    gap: 15px;
}

.grid-item {
    position: relative;
    border-radius: 8px;
    overflow: hidden;
    box-shadow: 0px 4px 6px rgba(0, 0, 0, 0.1);
}

.grid-item img {
    width: 100%;
    height: 200px;
    object-fit: cover;
    transition: transform 0.3s ease;
}
.grid-item:hover img {
    transform: scale(1.05);
}

.overlay {
    position: absolute;
    bottom: 0;
    left: 0;
    background: rgba(0, 0, 0, 0.6);
    color: white;
    width: 100%;
    padding: 8px;
    font-size: 14px;
    text-align: center;
}
 
   
/* Force a stable 4-column grid that wkhtmltopdf respects */
.image-gallery { width: 100%; }
.image-grid { width: 100%; border-collapse: collapse; table-layout: fixed; }
.image-grid tr { page-break-inside: avoid; }
.image-grid td { width: 25%; padding: 6px; vertical-align: top; }

.image-grid .img-wrap { display: block; }
.image-grid img { display: block; width: 100%; height: auto; }
.image-grid .caption { font-size: 12px; text-align: center; margin-top: 4px; }

/* If you had a flex layout before, neutralize it */
.image-gallery { display: block !important; }



    /* Print-specific rules */
    @media print {
      .no-print {
        display: none !important;
      }

      body {
        margin: 0;
      }
 
    }
  button{
    padding:8px;
    margin-left:45%;
    background-color:#808485;
    color:white;
    font-weight:700;
    font-style:italic;
  }
  button:hover{
    background-color:rgba(216,216,216,255);
    color:white;
  }

/* Optional: Google map styling */
    .google-map-container {
      max-width: 100%;
      margin: 20px auto;
       padding: 10px;
      text-align: center;
    }

    .google-map-container img {
      max-width: 100%;
      height: auto;
      display: inline-block;
       border-radius: 4px;
    }
    
.logo img {
  width: 120px;
  margin-left:30px;
  height: auto;
}
h3{
    border:1px solid black;
    padding:10px;
    margin-top:-1px;
   margin-bottom:-1px;
}
 </style>
</head>
<body>
   <div class="container">
        <header>
            <div class="footer">
            <div class="logo">
               <img src="images/logo.png" alt="Magpie Logo">
            </div>
            <div class="header-content">
                <h1>MAGPIE ENGINEERING PVT. LTD.</h1>
                <p>Valuer Designer Architects</p>
                <p>Address : Office no. 201, 2nd floor, Gravity Mall, Mechanic nagar, warehouse road, near vijay nagar, Indore, Madhya Pradesh- 452011</p>
            </div>
            </div>
        </header>
    <table>
  <tr>
    <h3 style="text-align: center;">VALUATION REPORT FOR ROHA HOUSING FINANCE PRIVATE LTD</h3>
  </tr>
      <tr>
        <th>Loan Number</th>
        <td colspan="2"><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data1['applicationNo'] ?? '') ?></span></td>
        <th>Product type</th>
        <td colspan="2"><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data1['caseType'] ?? '') ?></span></td>
        </tr>
        <tr>
        <th>Branch Name</th>
        <td colspan="2"><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data1['bank_branchname'] ?? '') ?></span></td>
        <th>Sub Product Type</th>
        <td colspan="2"><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data10['NA'] ?? '') ?></span></td>
        </tr> 
        <tr>
        <th>Valuer Name</th>
        <td colspan="2"><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars('MAGPIE ENGINEERING PRIVATE LIMITED') ?></span></td>
        <th>Type of Case</th>
        <td colspan="2"><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data1['caseType'] ?? '') ?></span></td>
        </tr>  
        <tr>
        <th>Valuer Ref No</th>
        <td colspan="2"><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data1['reference_id'] ?? '') ?></span></td>
        <th>Date of Visit</th>
        <td colspan="2"><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data1['fe_to_coordinator_assign_at'] ?? '') ?></span></td>
        </tr>
        <tr>
        <th>Valuer Status</th>
        <td colspan="2"><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data9['positive_report'] ?? '') ?></span></td>
        <th>Date of Report</th>
        <td colspan="2"><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data1['report_assigned_at'] ?? '') ?></span></td>
        </tr>
        <tr>
        <th>Contacted Person</th>
        <td><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data2['person_meet_at_site_contact'] ?? '') ?></span></td>
        <th>Relation with Customer</th>
        <td><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data2['relation_person_meet_at_site_contact'] ?? '') ?></span></td>
        <th>Contact No</th>
        <td><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data1['customerMob'] ?? '') ?></span></td>
        </tr>
        </table> 

        
        <h3>BASIC DETAILS</h3>
        <table>
        <tr>
        <th rowspan="3" style="width:35px;">1</th>
        <th>Applicant Name</th>
        <td colspan="3"><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data1['customerName'] ?? '') ?>
    </span></td>
        </tr>
        <tr>
        <th rowspan="2">Ownership As Per Documents</th>
        <td colspan="3"><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data9['owner_name'] ?? '') ?></span></td>
        </tr>
              <td colspan="3"><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data9['seller_name'] ?? '') ?></span></td>
        <tr>
        <th>2</th>
        <th>Originally type of property</th>
        <td><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars('Residential') ?></span></td>
        <th>Current Usage</th>
        <td><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data4['current_property_usage'] ?? '') ?></span></td></tr>
        <tr>
        <th rowspan="15">3</th>
         <th>Address as per request</th>
        <td colspan="3"><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
  <?= htmlspecialchars($data3['address_per_document'] ?? '') ?> <?= htmlspecialchars($data3['pin_code'] ?? '') ?>  </span></td>

           </tr>
        <tr>
        <th>Address as per document</th>
        <td colspan="3"><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
  <?= htmlspecialchars($data3['address_per_document'] ?? '') ?> <?= htmlspecialchars($data3['pin_code'] ?? '') ?>  </span></td>
      </tr>
      <tr>
        <th>Address as per Site</th>
        <td colspan="3"><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data3['address_per_site'] ?? '') ?> <?= htmlspecialchars($data3['pin_code'] ?? '') ?> 
    </span></td>
      </tr>
      <tr>
        <th>Project/Colony/Layout Name</th>
        <td colspan="3"><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data2['project_name'] ?? '') ?></span></td>
      </tr>
      <tr>
         <th>Unit/Flat no/ Bungalow/Plot/House no.</th>
        <td><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
         <?= htmlspecialchars($data3['address_line_1_as_per_doc'] ?? '') ?></span></td>
        <th>Floor No</th>
        <td><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data3['floor_no'] ?? '') ?></span></td>
      </tr>
      <tr>
         <th>Building Name</th>
        <td><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
         <?= htmlspecialchars($data2['project_approval_status'] ?? '') ?></span></td>
        <th>Wing Name</th>
        <td><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars('Refer Address') ?></span></td>
      </tr>
      <tr>
        <th>S.No/G.No/Khasra No</th>
        <td colspan="3"><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data3['khasra_no'] ?? '') ?></span></td>
      </tr>
      <tr>
       <th>Close Vicinity/Landmark</th>
       <td colspan="3"><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data3['landmark_1'] ?? '') ?> </span></td>
      </tr>
      <tr>
        <th>Street Name</th>
        <td><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
    <?= htmlspecialchars($data3['street_name'] ?? '') ?></span></td>
        <th>Village Name</th>
        <td><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
          <?= htmlspecialchars($data3['village_name'] ?? '') ?></span></td>
        </tr>
        <tr>
        <th>City</th>
        <td><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data3['address_line_3_as_per_doc'] ?? '') ?></span></td>
        <th>State</th>
        <td><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data3['address_line_4_as_per_doc'] ?? '') ?></span></td>
        </tr>
        <tr>
        <th>Main Locality of the Property</th>
        <td><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data2['property_unit_type'] ?? '') ?></span></td>
        <th>Sub Locality</th>
        <td><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data2['property_unit_type'] ?? '') ?></span></td>
        </tr>
        <tr>
       <th>Pin code of the Property</th>
       <td colspan="3"><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data3['pin_code'] ?? '') ?></span></td>
      </tr>
      <th>Nearest Police station</th>
       <td colspan="2"><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data3['nearest_police_station_name'] ?? '') ?></span></td>
       <td><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data3['nearest_police_station_distance'] ?? '') ?></span></td>
      </tr>
      <th>Nearest Post office</th>
       <td colspan="2"><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data3['nearest_post_office_name'] ?? '') ?></span></td>
       <td><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data3['nearest_post_office_distance'] ?? '') ?></span></td>
      </tr>
      <th>Latitude-Longitude</th>
       <td colspan="3"><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data3['latitude_value'] ?? '') ?> <?= htmlspecialchars($data3['longitude_value'] ?? '') ?></span></td>
      </tr>
      <th>4</th>
      <th>Has the valuator valued this property before, If yes, when, for whom</th>
       <td colspan="3"><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars('No') ?></span></td>
      </tr>
             </table>
      <h3>SURROUNDING & LOCALITY DETAILS</h3>
        <table>

<th rowspan="7">5</th>
      <th rowspan="7">Location</th>
      <th>Type (Comm, Res, Ind, Mix)</th>
       <td><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars('Residential') ?></span></td>
      </tr>
      <tr>
      <th>Locality (Low, Medium, Posh)</th>
      <td><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars('Medium') ?></span></td>
      </tr>
      <tr>
      <th>Site is (Dev, Under Dev, Developing)</th>
      <td><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars('Developing') ?></span></td>
      </tr>
      <tr>
      <th>Proximity to civic amenities/public transport</th>
      <td><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars('1-2 Km') ?></span></td>
      </tr>
      <tr>
        <th>Electric Connection Available</th>
        <td><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data2['electric_meter_no'] ?? '') ?></span></td>
      </tr>
      <tr>
      <th>Railway Station</th>
      <td><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data3['nearest_railway_station_name'] ?? '') ?>  <?= htmlspecialchars($data3['nearest_railway_station_distance'] ?? '') ?></span></td>
      </tr>
      <tr>
      <th>Bus Stop </th>
      <td><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data3['nearest_bus_stop_name'] ?? '') ?>  <?= htmlspecialchars($data3['nearest_bus_stop_distance'] ?? '') ?></span></td>
      </tr>
      <tr>
            <th>6</th>
            <th>Distance from Sourcing Branch</th>
            <td colspan="2"><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data3['distance_from_branch_kms'] ?? '') ?></span></td>
      </tr>
      <tr>
            <th>7</th>
            <th>Nature of approach Road</th>
            <td colspan="2"><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data2['type_of_approach_road'] ?? '') ?></span></td>
        </tr>
        <tr>
            <th>8</th>
            <th>Approach Road width</th>
            <td colspan="2"><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data2['width_of_approach_road'] ?? '') ?></span></td>
        </tr>
        <tr>
            <th>9</th>
            <th>Approach to the property as per Site</th>
            <td colspan="2"><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data2['width_of_approach_road'] ?? '') ?></span></td>
        </tr>
        <tr>
            <th>10</th>
            <th>Approach to the property as per Docs</th>
            <td colspan="2"><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data2['width_of_approach_road'] ?? '') ?></span></td>
        </tr>
        <tr>
            <th>11</th>
            <th>Any observation which affects security</th>
            <td colspan="2"><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data10['NA'] ?? '') ?></span></td>
        </tr>
       </table>
<h3>PROPERTY DETAILS</h3>
        <table>

        <tr>
            <th style="width:35px;">12</th>
            <th>Occupant</th>
            <th>Occupied By</th>
            <td colspan="2"><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data2['occupancy_status'] ?? '') ?></span></td>
        </tr>
        <tr>
          <th rowspan="15">13</th>
            <th rowspan="15">Building details</th>
            <th>Name of Occupant</th>
            <td colspan="2"><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data2['occupant_name'] ?? '') ?></span></td>
        </tr>
        <tr>
            <th>No of Tenants/duration</th>
            <td><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data10['NA'] ?? '') ?></span></td>
            <td><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data10['NA'] ?? '') ?></span></td>
          </tr>
          <tr>
            <th>Relation with applicant</th>
            <td colspan="2"><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data2['relation_of_occupant'] ?? '') ?></span></td>
          </tr>
          <tr>
            <th>Property Demarcation</th>
            <td colspan="2"><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data2['demarcated_at_site'] ?? '') ?></span></td>
          </tr>   <tr>
            <th>Property Identified(Y/N)</th>
            <td colspan="2"><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data4['abutting_agriculture_land'] ?? '') ?></span></td>
          </tr>   <tr>
            <th>Property Identified through</th>
            <td colspan="2"><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data4['costal_regulatory_zone'] ?? '') ?></span></td>
          </tr>
          <tr>
            <th>Type of structure</th>
            <td colspan="2"><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data4['structure_type'] ?? '') ?></span></td>
          </tr>
          <tr>
            <th>Seismic Zone</th>
            <td colspan="2"><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars('3rd') ?></span></td>
          </tr>
          <tr>
            <th>Type of soil</th>
            <td colspan="2"><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars('Black Cotton Soil') ?></span></td>
          </tr>
          <tr>
            <th>Land/Plot Area -UDS </th>
            <td><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data6['plot_square_feet'] ?? '') ?></span></td>
            <td><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars('SQ.FT') ?></span></td>
          </tr>
          <tr>
            <th>No of Blocks</th>
            <td colspan="2"><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data10['NA'] ?? '') ?></span></td>
          </tr>
          <tr>
            <th>No of Units on each floor</th>
            <td colspan="2"><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars('NA') ?></span></td>
          </tr>
          <tr>
            <th>No. of Floors</th>
            <td colspan="2"><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data8['basements_remarks'] ?? '') ?></span></td>
          </tr>
          <tr>
            <th>No. of Lifts</th>
            <td colspan="2"><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data10['NA'] ?? '') ?></span></td>
          </tr>
          <tr>
            <th>Amenities Available</th>
            <td colspan="2"><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars('Basic Amenities Available') ?></span></td>
          </tr>
          <tr>
            <th rowspan="5">14</th>
            <th rowspan="5">Unit Details</th>
            <th>Property located on Floor</th>
            <td colspan="2"><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars('Entire Property') ?></span></td>
          </tr>
          <tr>
          <th>Unit Configuration</th>
          <td colspan="2"><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data8['actual_configuration_building'] ?? '') ?></span></td>
          </tr>
          <tr>
            <th>Carpet area</th>
            <td><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data6['actual_carpet_square_feet'] ?? '') ?></span></td>
            <td><input type="text" value="SQ.FT Apprx"readonly></td>
          </tr>
          <tr>
            <th>Total BUA of</th>
            <td><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data6['actual_construction_square_feet'] ?? '') ?></span></td>
            <td><input type="text" value="SQ.FT"readonly></td>
          </tr>
          <tr>
          <th>View from property</th>
          <td colspan="2"><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data2['property_facing'] ?? '') ?></span></td>
          </tr>
                 </table>
                  <table>

          <tr>
            <th style="width:35px;">15</th>
            <th>Construction Quality (Good/Avg/Bad)</th>
            <th>Exteriors</th>
            <td><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars('Average') ?></span></td>
            <th>Interiors</th>
            <td><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars('Average') ?></span></td>
          </tr>
          <tr>
            <th>16</th>
            <th>Age of the property(Yrs)</th>
            <td><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data2['age_of_property'] ?? '') ?></span></td>
            <th>Residual age (Yrs)</th>
            <td colspan="2"><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data2['residual_age_of_property'] ?? '') ?></span></td>
          </tr>        
          <tr>
            <th class="index">17</th>
            <th colspan="1">Occupancy (%)</th>  
            <td colspan="5"><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data2['develop_percent'] ?? '') ?></span></td>
          </tr>

          <tr>
            <th class="index" rowspan="2">17 A</th>
            <th rowspan="2">IF PROPERTY COMINING IN TO MC LIMIT </th>
            <td rowspan="3" ><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data3['property_location_in'] ?? '') ?></span></td>
            <th class="center">No.of Properties hithin 250 mtr Radius</th>
            <td colspan="2"><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data4['properties_250_meters'] ?? '') ?></span></td>
          </tr>
          <tr>
            <th class="center">No.of Properties within 500 mtr Radius</th>
            <td colspan="2"><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data4['properties_500_meters'] ?? '') ?></span></td>
          </tr>

          <tr>
            <th class="index" rowspan="1">17 B</th>
            <th rowspan="1">IF PROPERTY COMINING IN TO GP LIMIT</th>
          
            <th class="center">No. of Properties in the Village</th>
            <td colspan="2"><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data4['within_50_mtrs_railway'] ?? '') ?></span></td>
          </tr>
          <tr>
            <th class="index" rowspan="2">17 C</th>
            <th rowspan="2">For Builder Projects</th>
            <td rowspan="2"><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data2['project_id'] ?? '') ?></span></td>
            <th class="center">Occupancy in the Project</th>
            <td colspan="2"><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data4['near_high_tension'] ?? '') ?></span></td>
          </tr>
          <tr>
          
            <th class="center">Occupancy in the Vicinity</th>
            <td colspan="2"><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data4['vertical_distance_from_line'] ?? '') ?></span></td>
          </tr>
           </table>
    <h3>SANCTION PLAN APPROVAL & OTHER DOCUMENTS DETAILS</h3>
            <table>

        <tr>
           <th style="width:35px;">18</th>
            <th>Sanction Plan Available</th>
            <td colspan="4"><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data9['floor_availability'] ?? '') ?></span></td>
        </tr>
        <tr>
          <th rowspan="5">19</th>
            <th>Description</th>
            <th>Approval No</th>
            <th>Date of Approval</th>
            <th>Expiry Date</th>
            <th>Sanctioning</th>
        </tr>
        <tr>
            <th>Layout Plan</th>
            <td><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data10['NA'] ?? '') ?></span></td>
            <td><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data10['NA'] ?? '') ?></span></td>
            <td><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data10['NA'] ?? '') ?></span></td>
            <td><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data10['NA'] ?? '') ?></span></td>
        </tr>
        <tr>
            <th>Building Plan</th>
            <td><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data10['NA'] ?? '') ?></span></td>
            <td><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data10['NA'] ?? '') ?></span></td>
            <td><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data10['NA'] ?? '') ?></span></td>
            <td><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data10['NA'] ?? '') ?></span></td>
        </tr>
        <tr>
            <th>Const. Permission</th>
            <td><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data10['NA'] ?? '') ?></span></td>
            <td><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data10['NA'] ?? '') ?></span></td>
            <td><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data10['NA'] ?? '') ?></span></td>
            <td><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data10['NA'] ?? '') ?></span></td>
        </tr>
        <tr>
            <th>Const. Certificate</th>
            <td><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data10['NA'] ?? '') ?></span></td>
            <td><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data10['NA'] ?? '') ?></span></td>
            <td><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data10['NA'] ?? '') ?></span></td>
            <td><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data10['NA'] ?? '') ?></span></td>
        </tr>
        <tr>
          <th>20</th>
            <th>Construction commencement date</th>
            <td><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data10['NA'] ?? '') ?></span></td>
            <th>Expected Completion Date</th>
            <td colspan="2"><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data10['NA'] ?? '') ?></span></td>
        </tr>
        <tr>
          <th>21</th>
            <th>Ownership Type(Free/Lease Hold)</th>
            <td colspan="4"><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data2['property_leasehold_freehold'] ?? '') ?></span></td>
        </tr>
        <tr>
          <th>22</th>
            <th>Property documents verification details</th>
            <td colspan="4"><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data9['list_documents'] ?? '') ?></span></td>
        </tr>
        <tr>
          <th>23</th>
            <th>Property Jurisdiction</th>
            <td colspan="4"><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data3['property_location_in'] ?? '') ?></span></td>
        </tr>
        <tr>
          <th>24</th>
            <th>Permissible zoning as per master plan</th>
            <td><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data4['zoning_development_plan'] ?? '') ?></span></td>
            <th>Usage As per Site</th>
            <td colspan="2"><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data4['current_property_usage'] ?? '') ?></span></td>
        </tr>
        <tr>
          <th>25</th>
          <th>Whether property under demolition list as per authority (Y/N)</th>
        <td><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data10['NA'] ?? '') ?></span></td>
        </tr>
        <tr>
          <th rowspan="5">26</th>
            <th>Setbacks (Fts)</th>
            <th colspan="2">As per plan/Byelaws (Fts)</th>
            <th colspan="2">As per site (Fts)</th>
        </tr>
        <tr>
            <th>Front</th>
            <td colspan="2"><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data10['NA'] ?? '') ?></span></td>
            <td colspan="2"><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data10['NA'] ?? '') ?></span></td>
        </tr>
        <tr>
            <th>Side1(Left)</th>
            <td colspan="2"><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data10['NA'] ?? '') ?></span></td>
            <td colspan="2"><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data10['NA'] ?? '') ?></span></td>
        </tr>
        <tr>
            <th>Side2(Right)</th>
            <td colspan="2"><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data10['NA'] ?? '') ?></span></td>
            <td colspan="2"><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data10['NA'] ?? '') ?></span></td>
        </tr>
        <tr>
            <th>Rear</th>
            <td colspan="2"><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data10['NA'] ?? '') ?></span></td>
            <td colspan="2"><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data10['NA'] ?? '') ?></span></td>
        </tr>
     
               </table>
                <table>

        <tr>
          <th rowspan="10" style="width:35px;">27</th>
            <th colspan="3">B.U.A Area (In Sq.ft.)</th>
            <td colspan="2"><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data6['construction_square_feet'] ?? '') ?></span></td>
            <td colspan="2"><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data6['actual_construction_square_feet'] ?? '') ?></span></td>
          </tr>
          <tr>
            <th colspan="3">Floor</th>
            <th colspan="2">As per plan/Byelaws(Sqft)</th>
            <th colspan="2">As per site(Sqft)</th>
          </tr>
          <tr>
            <th colspan="3">Ground Floor</th>
            <td colspan="2"><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars('0') ?></span></td>
            <td colspan="2"><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars('0') ?></span></td>
          </tr>
        <tr>
            <th colspan="3">First Floor</th>
            <td colspan="2"><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars('0') ?></span></td>
            <td colspan="2"><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars('0') ?></span></td>
        </tr>
        <tr>
            <th colspan="3">Second Floor</th>
            <td colspan="2"><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars('0') ?></span></td>
            <td colspan="2"><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars('0') ?></span></td>
        </tr>
        <tr>
            <th colspan="3">Total B.U.A SQFT</th>
            <td colspan="2"><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars('0') ?></span></td>
            <td colspan="2"><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars('0') ?></span></td>
        </tr>
        <tr>
            <th colspan="3">Dimensions Details</th>
            <td colspan="2"><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data10['NA'] ?? '') ?></span></td>
          </tr>
<tr>
          <th colspan="3">Description</th>
            <td>North</td>
            <td>East</td>
            <td>West</td>
            <td>South</td>
        </tr>
        <tr>
            <th colspan="3">As Per Documents</th>
            <td><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data6['dimension_as_per_document_north'] ?? '') ?></span></td>
            <td><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data6['dimension_as_per_document_east'] ?? '') ?></span></td>
            <td><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data6['dimension_as_per_document_west'] ?? '') ?></span></td>
            <td><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data6['dimension_as_per_document_south'] ?? '') ?></span></td>
        </tr>
        <tr>
            <th colspan="3">As Per Site</th>
            <td><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data6['dimension_as_per_site_north'] ?? '') ?></span></td>
            <td><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data6['dimension_as_per_site_east'] ?? '') ?></span></td>
            <td><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data6['dimension_as_per_site_west'] ?? '') ?></span></td>
            <td><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data6['dimension_as_per_site_south'] ?? '') ?></span></td>
        </tr>
        </table>
 <h3>VALUATION DETAILS</h3>
 <table>
        <tr>
          <th rowspan="28"style="width:35px;">28</th>
            <th colspan="5" style="text-align:left;">(A) Description of Land & Constructed Area and Rates</th>
          
        </tr>
        <tr>
            <th colspan="5" style="text-align:left;">Property Type: </th>
        </tr>
        <tr>
            <th>Description</th>
            <th>Unit of Measurement</th>
            <th>Area</th>
            <th>Rate/unit</th>
            <th>Amount</th>
        </tr>
        <tr>
            <th>Land Area</th>
            <td><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars('SQ. FT.') ?></span></td>
            <td><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data6['final_plot_square_feet'] ?? '') ?></span></td>
            <td><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data6['final_plot_rate'] ?? '') ?></span></td>
            <td><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data6['finally_plot_valuation'] ?? '') ?></span></td>
        </tr>
      <tr>
    <th>Existing BUA Area</th>
    <td><span style="display: inline-block; min-width: 50px; padding: 2px;" readonly>
            <?= htmlspecialchars('SQ. FT.') ?></span></td>
             <td><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data6['construction_area_sqft_1'] ?? '') ?></span></td>
                <td><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data6['construction_rate_1'] ?? '') ?></span></td>
                   <td><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data6['construction_valuation_1'] ?? '') ?></span></td>
    </td>
</tr>
   <tr>
    <th>FF-Existing BUA Area</th>
    <td><span style="display: inline-block; min-width: 50px; padding: 2px;" readonly>
            <?= htmlspecialchars('SQ. FT.') ?></span></td>
             <td><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data6['construction_area_sqft_2'] ?? '') ?></span></td>
                <td><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data6['construction_rate_2'] ?? '') ?></span></td>
                   <td><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data6['construction_valuation_2'] ?? '') ?></span></td>
    </td>
</tr>
   <tr>
    <th>SF-Existing BUA Area</th>
    <td><span style="display: inline-block; min-width: 50px; padding: 2px;" readonly>
            <?= htmlspecialchars('SQ. FT.') ?></span></td>
             <td><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data6['construction_area_sqft_3'] ?? '') ?></span></td>
                <td><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data6['construction_rate_3'] ?? '') ?></span></td>
                   <td><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data6['construction_valuation_3'] ?? '') ?></span></td>
    </td>
</tr>
        <tr>
            <th>Proposed BUA</th>
            <td><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars('SQ. FT.') ?></span></td>
            <td><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data6['proposed_construction_area_sqft1'] ?? '') ?></span></td>
            <td><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data6['proposed_construction_rate1'] ?? '') ?></span></td>
            <td><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data6['proposed_construction_valuation1'] ?? '') ?></span></td>
        </tr>
         <tr>
            <th>FF-Proposed BUA</th>
            <td><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars('SQ. FT.') ?></span></td>
           <td><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data6['proposed_construction_area_sqft2'] ?? '') ?></span></td>
            <td><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data6['proposed_construction_rate2'] ?? '') ?></span></td>
            <td><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data6['proposed_construction_valuation2'] ?? '') ?></span></td>
        </tr>
         <tr>
            <th>SF-Proposed BUA</th>
            <td><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars('SQ. FT.') ?></span></td>
          <td><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data6['proposed_construction_area_sqft3'] ?? '') ?></span></td>
            <td><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data6['proposed_construction_rate3'] ?? '') ?></span></td>
            <td><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data6['proposed_construction_valuation3'] ?? '') ?></span></td>
       
        </tr>
        <tr>
            <th>Construction Progress</th>
            <td colspan="4"><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data8['Present_quality_of_structure'] ?? '') ?></span></td>
        </tr>
        <tr>
            <th>% Completion</th>
            <td colspan="2"><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data8['stage_construction_actual_present_completion'] ?? '') ?></span></td>
            <th>% Recommendation</th>
            <td><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data8['stage_construction_recommend_present_completion'] ?? '') ?></span></td>
        </tr>
        <tr>
            <th colspan="2">(B) Value of Extra Amenities if applicable</th>
            <td colspan="3"><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data6['amenities_total'] ?? '') ?></span></td>
        </tr>
        <tr>
            <th>No of Car Parks</th>
            <td colspan="4"><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data10['NA'] ?? '') ?></span></td>
        </tr>
        <tr>
            <th>Car Parking Charges Lumpsum (INR)</th>
            <td colspan="4"><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data10['NA'] ?? '') ?></span></td>
        </tr>
        <tr>
            <th>EDC, IDC Lumpsum (INR)</th>
            <td colspan="4"><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data10['NA'] ?? '') ?></span></td>
        </tr>
        <tr>
            <th>PLC Charges Lumpsum (INR)</th>
            <td colspan="4"><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data10['NA'] ?? '') ?></span></td>
        </tr>
        <tr>
            <th>Power Backup</th>
            <td colspan="4"><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data10['NA'] ?? '') ?></span></td>
        </tr>
        <tr>
            <th>Interiors/Amenities</th>
            <td colspan="4"><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars('NA') ?></span></td>
        </tr>
        <tr>
            <th>Interiors % completion</th>
            <td colspan="4"><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data10['NA'] ?? '') ?></span></td>
        </tr>
<tr>
    <th>Total of Component A on Completion</th>
<td colspan="4">
    <span style="display: inline-block; min-width: 50px; padding: 2px;" readonly>
        <?php
        $total =
            ($data6['finally_plot_valuation'] ?? 0) +
            ($data6['construction_valuation_1'] ?? 0) +
            ($data6['construction_valuation_2'] ?? 0) +
            ($data6['construction_valuation_3'] ?? 0) +
            ($data6['proposed_construction_valuation1'] ?? 0) +
            ($data6['proposed_construction_valuation2'] ?? 0) +
            ($data6['proposed_construction_valuation3'] ?? 0);

        echo htmlspecialchars($total);
        ?>
    </span>
</td>

</tr>
       
        <tr>
            <th>Total of Component B on Completion</th>
            <td colspan="4"><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data10['NA'] ?? '') ?></span></td>
        </tr>
        <tr>
            <th>Total Market Value of the property on Completion (A+B)</th>
           <td colspan="4">
    <span style="display: inline-block; min-width: 50px; padding: 2px;" readonly>
        <?php
        $total =
            ($data6['finally_plot_valuation'] ?? 0) +
            ($data6['construction_valuation_1'] ?? 0) +
            ($data6['construction_valuation_2'] ?? 0) +
            ($data6['construction_valuation_3'] ?? 0) +
            ($data6['proposed_construction_valuation1'] ?? 0) +
            ($data6['proposed_construction_valuation2'] ?? 0) +
            ($data6['proposed_construction_valuation3'] ?? 0);

        echo htmlspecialchars($total);
        ?>
    </span>
</td>

        </span></td>
        </tr>

     <?php
// Function to convert number into words
function convertNumberToWords($number) {
    $words = array(
        0 => 'Zero', 1 => 'One', 2 => 'Two', 3 => 'Three', 4 => 'Four',
        5 => 'Five', 6 => 'Six', 7 => 'Seven', 8 => 'Eight', 9 => 'Nine',
        10 => 'Ten', 11 => 'Eleven', 12 => 'Twelve', 13 => 'Thirteen', 14 => 'Fourteen',
        15 => 'Fifteen', 16 => 'Sixteen', 17 => 'Seventeen', 18 => 'Eighteen', 19 => 'Nineteen',
        20 => 'Twenty', 30 => 'Thirty', 40 => 'Forty', 50 => 'Fifty',
        60 => 'Sixty', 70 => 'Seventy', 80 => 'Eighty', 90 => 'Ninety'
    );

    $levels = array(
        10000000 => 'Crore',
        100000 => 'Lakh',
        1000 => 'Thousand',
        100 => 'Hundred'
    );

    if ($number == 0) {
        return $words[0];
    }

    $result = '';

    foreach ($levels as $value => $label) {
        if ($number >= $value) {
            $count = intval($number / $value);
            $result .= convertNumberToWords($count) . " " . $label . " ";
            $number %= $value;
        }
    }

    if ($number > 0) {
        if ($number < 20) {
            $result .= $words[$number];
        } else {
            $tens = intval($number / 10) * 10;
            $units = $number % 10;
            $result .= $words[$tens];
            if ($units > 0) {
                $result .= " " . $words[$units];
            }
        }
    }

    return trim($result);
}

// Calculate total
$total =
    ($data6['finally_plot_valuation'] ?? 0) +
    ($data6['construction_valuation_1'] ?? 0) +
    ($data6['construction_valuation_2'] ?? 0) +
    ($data6['construction_valuation_3'] ?? 0) +
    ($data6['proposed_construction_valuation1'] ?? 0) +
    ($data6['proposed_construction_valuation2'] ?? 0) +
    ($data6['proposed_construction_valuation3'] ?? 0);
?>

<tr>
    <th>Total Market Value of Property on Completion in Words</th>
    <td colspan="4">
        <span style="display: inline-block; min-width: 50px; padding: 2px;" readonly>
            <?php echo htmlspecialchars($total); ?> 
            (<?php echo convertNumberToWords($total); ?>)
        </span>
    </td>
</tr>


        <tr>
          <th>Total Market Value of Property as on Date(A+B)</th>
          <td colspan="4"><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data6['total_finally_area_valuation'] ?? '') ?></span></td>
        </tr>
        <tr>
          <th>Guideline Value of The Property</th>
          <td colspan="4"><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data6['guideline_values'] ?? '') ?></span></td>
        </tr>
<tr>
    <th>Distress Sale Value as on date (80%)</th>
   <td colspan="4">
    <span style="display: inline-block; min-width: 50px; padding: 2px;" readonly>
        <?php
        $value = $data6['total_finally_area_valuation'] ?? 0;
        $eightyPercent = ($value * 80) / 100;
        echo htmlspecialchars($eightyPercent);
        ?>
    </span>
</td>

</tr>

        
        <tr>
          <th>Approx. Rentals in case of 100% complete property</th>
          <td colspan="4"><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data10['NA'] ?? '') ?></span></td>
        </tr>
    </table>
    <h3>BOUNDARIES</h3>
    <table>
    <tr>
            <th style="width:35px;"></th>
            <th colspan="2">Boundaries</th>
            <th>North</th>
            <th>South</th>
            <th>East</th>
            <th>West</th>
        </tr>
        <tr> 
             <th></th>
            <th colspan="2">As per Docs</th>
            <td><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data3['direction_as_per_document_north'] ?? '') ?></span></td>
            <td><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data3['direction_as_per_document_south'] ?? '') ?></span></td>
            <td><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data3['direction_as_per_document_east'] ?? '') ?></span></td>
            <td><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data3['direction_as_per_document_west'] ?? '') ?></span></td>
        </tr>
        <tr>
            <th></th>
            <th colspan="2">At site</th>
            <td><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data3['direction_as_per_site_north'] ?? '') ?></span></td>
            <td><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data3['direction_as_per_site_south'] ?? '') ?></span></td>
            <td><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data3['direction_as_per_site_east'] ?? '') ?></span></td>
            <td><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data3['direction_as_per_site_west'] ?? '') ?></span></td>
        </tr>
        <tr>
          <th></th>
            <th colspan="2">As per Plan/Drone</th>
            <td><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data3['direction_approved_north'] ?? '') ?></span></td>
            <td><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data3['direction_approved_south'] ?? '') ?></span></td>
            <td><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data3['direction_approved_east'] ?? '') ?></span></td>
            <td><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data3['direction_approved_west'] ?? '') ?></span></td>
        </tr>
        <tr>
          <th></th>
            <th colspan="2">Boundaries Matching</th>
            <td colspan="4"><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data3['boundaries_matching'] ?? '') ?></span></td>
        </tr>
    </table>
    <table>
   <tr> 
    <td><strong>REMARKS</strong></td>
  </tr>
<tr>
  <td><span style="white-space: pre-line; font-size:14px; display: block; text-align: left; padding: 0; margin: 0;font-weight:400;"readonly>
        <?= htmlspecialchars($data10['remarks'] ?? '') ?>
    </span></td>
  </tr>
      <tr>  
        <td><strong>DECLARATION</strong></td>
      </tr>
<tr> 
  <td><span style="white-space: pre-line; font-size:14px; display: block; text-align: left; padding: 0; margin: 0;font-weight:400;" readonly>
    <?= nl2br(htmlspecialchars(formatDeclaration($data10['declaration'] ?? ''))) ?>
</span></td>
</tr>
  <?php
function formatDeclaration($text) {
    // Insert a newline before every occurrence of a number followed by a dot and space (e.g., "1. ", "10. ")
    // Only if it's NOT already at the beginning of the string or a new line
    $text = preg_replace('/(?<!^)(?<!\n)(\d+\.\s)/', "\n$1", $text);
    return $text;
}
?>

</table>
</div>


  
   <table>
<tr><th style="margin-bottom:-18px;">PHOTOGRAPH OF THE PROPERTY</tr></th></table>
<br>

    
<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

$servername = "localhost";
$username   = "root";
$password   = "";
$dbname     = "project_db";

$conn = new mysqli($servername, $username, $password, $dbname);
if ($conn->connect_error) {
    die("Connection failed: " . htmlspecialchars($conn->connect_error));
}

$reference_id = $_SESSION['reference_id'] ?? null;
$reference_id = $_GET['reference_id'] ?? $reference_id;

if ($reference_id) {

    // Map captions
    $captions = [
        'image1'  => 'EXTERNAL PHOTOS',
        'image2'  => 'Kitchen',
        'image3'  => 'Selfie',
        'image6'  => 'Other 1',
        'image7'  => 'Other 2',
        'image8'  => 'Other 3',
        'image9'  => 'Other 4',
        'image10' => 'Other 5',
        'image11' => 'Other 6',
        'image12' => 'Other 7',
        'image13' => 'Other 8',
        'image14' => 'Other 9',
        'image15' => 'Other 10',
        'image16' => 'Other 11'
        
    ];

    // === Helper: EXIF-aware orientation detection ===
    function classify_orientation_after_exif(string $imageData): ?string {
        $size = @getimagesizefromstring($imageData);
        if (!$size || !isset($size[0], $size[1])) {
            return null;
        }
        $width  = (int)$size[0];
        $height = (int)$size[1];

        $mime = $size['mime'] ?? '';
        if ($mime === 'image/jpeg' && function_exists('exif_read_data')) {
            $tmp = @tempnam(sys_get_temp_dir(), 'exif_');
            if ($tmp !== false) {
                @file_put_contents($tmp, $imageData);
                $exif = @exif_read_data($tmp);
                @unlink($tmp);

                if (!empty($exif['Orientation'])) {
                    $orientation = (int)$exif['Orientation'];
                    if ($orientation === 6 || $orientation === 8) {
                        $t = $width; $width = $height; $height = $t;
                    }
                }
            }
        }
        return ($width >= $height) ? 'horizontal' : 'vertical';
    }

    // === Helper: Fix orientation physically with Imagick ===
    function fixImageOrientation($binaryData) {
        $img = new Imagick();
        $img->readImageBlob($binaryData);

        switch ($img->getImageOrientation()) {
            case Imagick::ORIENTATION_BOTTOMRIGHT:
                $img->rotateImage("#000", 180);
                break;
            case Imagick::ORIENTATION_RIGHTTOP:
                $img->rotateImage("#000", 90);
                break;
            case Imagick::ORIENTATION_LEFTBOTTOM:
                $img->rotateImage("#000", -90);
                break;
        }

        $img->setImageOrientation(Imagick::ORIENTATION_TOPLEFT);
        $fixed = $img->getImageBlob();
        $img->destroy();

        return $fixed;
    }

    $sql = "SELECT 
                image1, image2, image3, 
                image6, image7, image8, image9, 
                image10, image11, image12, image13, image14, image15, image16 
            FROM final_uploaded_images 
            WHERE reference_id = ?";

    $stmt = $conn->prepare($sql);
    if ($stmt === false) {
        die("Error preparing the SQL statement: " . htmlspecialchars($conn->error));
    }

    $stmt->bind_param("s", $reference_id);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result && $result->num_rows > 0) {
        $horizontal_images = [];
        $vertical_images   = [];

        while ($row = $result->fetch_assoc()) {
            foreach ($row as $key => $imageData) {
                if (!empty($imageData)) {

                    // Actually fix image before displaying
                    $fixedData = fixImageOrientation($imageData);

                    $orientation = classify_orientation_after_exif($fixedData) ?? 'horizontal';
                    $imgString   = base64_encode($fixedData);
                    $caption     = $captions[$key] ?? 'Image';

                    $item = [
                        'data'    => $imgString,
                        'caption' => $caption,
                        'alt'     => $key,
                    ];

                    if ($orientation === 'horizontal') {
                        $horizontal_images[] = $item;
                    } else {
                        $vertical_images[]   = $item;
                    }
                }
            }
        }

 
// Output as a stable 4-column table (works in wkhtmltopdf)
$all_images = array_merge($vertical_images, $horizontal_images);

echo '<table class="image-grid">';
$rows = array_chunk($all_images, 4);
foreach ($rows as $row) {
    echo '<tr>';
    foreach ($row as $img) {
        echo '<td>';
        echo '<div class="img-wrap">';
        echo '<img src="data:image/jpeg;base64,' . $img['data'] . '" alt="' . htmlspecialchars($img['alt']) . '">';
        echo '<div class="caption">' . htmlspecialchars($img['caption']) . '</div>';
        echo '</div>';
        echo '</td>';
    }
    // pad remaining cells to keep 4 columns
    $remaining = 4 - count($row);
    if ($remaining > 0) {
        echo str_repeat('<td></td>', $remaining);
    }
    echo '</tr>';
}
echo '</table>';

    } else {
        echo "<p style='text-align:center;'>No images found.</p>";
    }

    $stmt->close();
} else {
    echo "<p style='text-align:center;'>Reference ID is missing.</p>";
}
?>  
   <br>
   <div class="google-map-container">
 <?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "project_db";
$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$reference_id = $_SESSION['reference_id'] ?? null;
$reference_id = $_GET['reference_id'] ?? $reference_id;

if ($reference_id) {
    $sql = "SELECT image5 FROM final_uploaded_images WHERE reference_id = ?";
    $stmt = $conn->prepare($sql);
    if ($stmt === false) {
        die("Error preparing the SQL statement: " . $conn->error);
    }

    $stmt->bind_param("s", $reference_id);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows > 0) {
        $row = $result->fetch_assoc();
        if (!empty($row['image5'])) {
 
            echo '<div><img src="data:image/jpeg;base64,' . base64_encode($row['image5']) . '" alt="Google Map"></div>';
        } else {
         }
    } else {
     }

    $stmt->close();
} else {
    echo "<p style='text-align:center;'>Reference ID is missing.</p>";
}
?>
</div>
  <br>
<div class="google-map-container">
 <?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "project_db";
$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$reference_id = $_SESSION['reference_id'] ?? null;
$reference_id = $_GET['reference_id'] ?? $reference_id;

if ($reference_id) {
    $sql = "SELECT image20 FROM final_uploaded_images WHERE reference_id = ?";
    $stmt = $conn->prepare($sql);
    if ($stmt === false) {
        die("Error preparing the SQL statement: " . $conn->error);
    }

    $stmt->bind_param("s", $reference_id);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows > 0) {
        $row = $result->fetch_assoc();
        if (!empty($row['image20'])) {
 
            echo '<div><img src="data:image/jpeg;base64,' . base64_encode($row['image20']) . '" alt="Google Map"></div>';
        } else {
         }
    } else {
     }

    $stmt->close();
} else {
    echo "<p style='text-align:center;'>Reference ID is missing.</p>";
}
?>
</div>
 <br>
 <div class="google-map-container">
 <?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "project_db";
$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$reference_id = $_SESSION['reference_id'] ?? null;
$reference_id = $_GET['reference_id'] ?? $reference_id;

if ($reference_id) {
    $sql = "SELECT image19 FROM final_uploaded_images WHERE reference_id = ?";
    $stmt = $conn->prepare($sql);
    if ($stmt === false) {
        die("Error preparing the SQL statement: " . $conn->error);
    }

    $stmt->bind_param("s", $reference_id);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows > 0) {
        $row = $result->fetch_assoc();
        if (!empty($row['image19'])) {
 
            echo '<div><img src="data:image/jpeg;base64,' . base64_encode($row['image19']) . '" alt="Google Map"></div>';
        } else {
         }
    } else {
     }

    $stmt->close();
} else {
    echo "<p style='text-align:center;'>Reference ID is missing.</p>";
}
?>
</div>
<br>
   <div class="google-map-container">
 <?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "project_db";
$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$reference_id = $_SESSION['reference_id'] ?? null;
$reference_id = $_GET['reference_id'] ?? $reference_id;

if ($reference_id) {
    $sql = "SELECT image4 FROM final_uploaded_images WHERE reference_id = ?";
    $stmt = $conn->prepare($sql);
    if ($stmt === false) {
        die("Error preparing the SQL statement: " . $conn->error);
    }

    $stmt->bind_param("s", $reference_id);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows > 0) {
        $row = $result->fetch_assoc();
        if (!empty($row['image4'])) {
 
            echo '<div><img src="data:image/jpeg;base64,' . base64_encode($row['image4']) . '" alt="Electric Meter"></div>';
        } else {
         }
    } else {
     }

    $stmt->close();
} else {
    echo "<p style='text-align:center;'>Reference ID is missing.</p>";
}
?>
</div><br>
<div class="google-map-container">
  <?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "project_db";
$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$reference_id = $_SESSION['reference_id'] ?? null;
$reference_id = $_GET['reference_id'] ?? $reference_id;

if ($reference_id) {
    $sql = "SELECT image18 FROM final_uploaded_images WHERE reference_id = ?";
    $stmt = $conn->prepare($sql);
    if ($stmt === false) {
        die("Error preparing the SQL statement: " . $conn->error);
    }

    $stmt->bind_param("s", $reference_id);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows > 0) {
        $row = $result->fetch_assoc();
        if (!empty($row['image18'])) {
 
            echo '<div><img src="data:image/jpeg;base64,' . base64_encode($row['image18']) . '" alt="Google Map"></div>';
        } else {
         }
    } else {
     }

    $stmt->close();
} else {
    echo "<p style='text-align:center;'>Reference ID is missing.</p>";
}
?>
<br> <br>
</div>
<div class="google-map-container">
  <?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "project_db";
$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$reference_id = $_SESSION['reference_id'] ?? null;
$reference_id = $_GET['reference_id'] ?? $reference_id;

if ($reference_id) {
    $sql = "SELECT image17 FROM final_uploaded_images WHERE reference_id = ?";
    $stmt = $conn->prepare($sql);
    if ($stmt === false) {
        die("Error preparing the SQL statement: " . $conn->error);
    }

    $stmt->bind_param("s", $reference_id);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows > 0) {
        $row = $result->fetch_assoc();
        if (!empty($row['image17'])) {
 
            echo '<div><img src="data:image/jpeg;base64,' . base64_encode($row['image17']) . '" alt="Google Map"></div>';
        } else {
         }
    } else {
     }

    $stmt->close();
} else {
    echo "<p style='text-align:center;'>Reference ID is missing.</p>";
}
?>
 
</div>
   <!-- Buttons: Hidden during print -->
<div class="no-print">
  <form method="post">
    <input type="hidden" name="download_images" value="1">
    <button type="submit">Download All Images</button>
  </form>

  <button id="downloadPdf" onclick="setPrintMargins()">DOWNLOAD PDF</button>
</div>

  <script>
   document.getElementById('downloadPdf').addEventListener('click', () => {
  const element = document.getElementById('content');
  const options = {
    margin: [0, 0],
    filename: 'report.pdf',
    image: { type: 'jpeg', quality: 0.75 }, // reduce quality for compression
    html2canvas: { scale: 2 },
    jsPDF: { unit: 'in', format: 'letter', orientation: 'portrait', compress: true }
  };

  // Generate PDF and compress
  html2pdf().set(options).from(element).toPdf().get('pdf').then(function (pdf) {
    // Convert to blob and force download
    pdf.save(options.filename); // <-- this line was missing earlier
  });
});

    function setPrintMargins() {         
      const style = document.createElement('style');
      style.innerHTML = `
      @media print {
          body {
            margin:0.5;
          }
        }
      `;
      document.head.appendChild(style);
      window.print();
    }
    // Disable all input fields in the form
    document.querySelectorAll('input').forEach(function(input) {
        input.disabled = true;  // Disables the field completely
    });
     function resizeFakeInput(input) {
    const fake = document.getElementById('fakeWrap');
    fake.textContent = input.value || ' ';
    input.style.height = fake.scrollHeight + 'px';
  }

  // Initialize height
  resizeFakeInput(document.getElementById('longInput'));
   function autoResize(el) {
    el.style.height = 'auto'; // reset height
    el.style.height = el.scrollHeight + 'px'; // set to content height
  }
  // Auto-resize on load
  document.querySelectorAll('.clean-textarea').forEach(t => autoResize(t));
  </script>
</div>
</body>
</html>


