<?php include('auth.php'); ?>
<?php include 'watermark.html'; ?>

<?php
ini_set('display_errors', 1);
error_reporting(E_ALL);

// Increase PHP execution time and memory limit
ini_set('max_execution_time', 600); // Increase execution time to 600 seconds (10 minutes)
ini_set('memory_limit', '4096M'); // Increase memory limit to 4096MB
// Start session

$servername = "localhost";
$username = "root";
$password = "";
$dbname = "project_db";

// Create DB connection
$conn = new mysqli($servername, $username, $password, $dbname);
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

if (!isset($_SESSION['reference_id'])) {
    die("Reference ID not found in session.");
}
$reference_id = $_SESSION['reference_id'];

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['download_images'])) {

    // Get customer name
    $stmt_name = $conn->prepare("SELECT customerName FROM mis WHERE reference_id = ?");
    $stmt_name->bind_param("s", $reference_id);
    $stmt_name->execute();
    $result_name = $stmt_name->get_result();
    $customerName = "customer";
    if ($row = $result_name->fetch_assoc()) {
        $customerName = preg_replace('/[^a-zA-Z0-9]/', '', $row['customerName']);
    }
    $stmt_name->close();

      // Fetch image BLOBs
    $stmt = $conn->prepare("SELECT image1, image2, image3, image4, image5, image6, image7, image8, image9, image10, image11, image12, image13, image14, image15, image16, image17, image18, image19, image20 FROM final_uploaded_images WHERE reference_id = ?");
    $stmt->bind_param("s", $reference_id);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows > 0 && ($row = $result->fetch_assoc())) {
        $tempDir = sys_get_temp_dir() . DIRECTORY_SEPARATOR . uniqid('images_', true);
        mkdir($tempDir);

        $imageFiles = [];
        for ($i = 1; $i <= 12; $i++) {
            if (!empty($row["image$i"])) {
                $filename = $tempDir . DIRECTORY_SEPARATOR . "image{$i}.jpg";
                file_put_contents($filename, $row["image$i"]);
                $imageFiles[] = $filename;
            }
        }

        if (empty($imageFiles)) {
            die("No images to download.");
        }

        // Create ZIP
        $zipFileName = "images_" . preg_replace('/[^a-zA-Z0-9]/', '_', $reference_id) . "_{$customerName}.zip";
        $zipPath = $tempDir . DIRECTORY_SEPARATOR . $zipFileName;

        $zip = new ZipArchive();
        if ($zip->open($zipPath, ZipArchive::CREATE) !== TRUE) {
            die("Failed to create ZIP file.");
        }

        foreach ($imageFiles as $file) {
            $zip->addFile($file, basename($file));
        }
        $zip->close();

        // Send ZIP to browser
        header('Content-Type: application/zip');
        header('Content-Disposition: attachment; filename="' . basename($zipFileName) . '"');
        header('Content-Length: ' . filesize($zipPath));
        flush();
        readfile($zipPath);

        // Cleanup
        foreach ($imageFiles as $file) {
            unlink($file);
        }
        unlink($zipPath);
        rmdir($tempDir);
        exit;
    } else {
        echo "<p style='color:red;'>No image data found for this reference ID.</p>";
    }
}



// Debugging: Output for verification 
//echo "Session reference_id: " . htmlspecialchars($reference_id) . "<br>";


$page = isset($_GET['page']) ? $_GET['page'] : 1;
$limit = 50;
$offset = ($page - 1) * $limit;
$sql_property = "SELECT * FROM mis WHERE reference_id = ? LIMIT $limit OFFSET $offset";
$stmt_property = $conn->prepare($sql_property);
$stmt_property->bind_param("s", $reference_id);
$stmt_property->execute();
$result_property = $stmt_property->get_result();
$data1 = $result_property->fetch_assoc();




// Fetch data from property_details table
$sql_property = "SELECT * FROM property_details WHERE reference_id = ?";
$stmt_property = $conn->prepare($sql_property);
$stmt_property->bind_param("s", $reference_id);
$stmt_property->execute();
$result_property = $stmt_property->get_result();
$data2= $result_property->fetch_assoc();




// Fetch data from area_valuation table
$sql_area = "SELECT * FROM address_details WHERE reference_id = ?";
$stmt_area = $conn->prepare($sql_area); 
$stmt_area->bind_param("s", $reference_id);
$stmt_area->execute();
$result_area = $stmt_area->get_result();
$data3 = $result_area->fetch_assoc();





// Fetch data from area_valuation table
$sql_area = "SELECT * FROM critical_parameters WHERE reference_id = ?";
$stmt_area = $conn->prepare($sql_area); 
$stmt_area->bind_param("s", $reference_id);
$stmt_area->execute();
$result_area = $stmt_area->get_result();
$data4 = $result_area->fetch_assoc();

 
// Fetch data from area_valuation table
$sql_area = "SELECT * FROM surroundings_details WHERE reference_id = ?";
$stmt_area = $conn->prepare($sql_area); 
$stmt_area->bind_param("s", $reference_id);
$stmt_area->execute();
$result_area = $stmt_area->get_result();
$data5 = $result_area->fetch_assoc();
$stmt_area->close();
 
// Fetch data from area_valuation table
$sql_area = "SELECT * FROM area_valuation WHERE reference_id = ?";
$stmt_area = $conn->prepare($sql_area); 
$stmt_area->bind_param("s", $reference_id);
$stmt_area->execute();
$result_area = $stmt_area->get_result();
$data6 = $result_area->fetch_assoc();
$stmt_area->close();
 



// Fetch data from area_valuation table
$sql_area = "SELECT * FROM floor_details WHERE reference_id = ?";
$stmt_area = $conn->prepare($sql_area); 
$stmt_area->bind_param("s", $reference_id);
$stmt_area->execute();
$result_area = $stmt_area->get_result();
$data8= $result_area->fetch_assoc();
$stmt_area->close();
 


// Fetch data from area_valuation table
$sql_area = "SELECT * FROM technical_details WHERE reference_id = ?";
$stmt_area = $conn->prepare($sql_area); 
$stmt_area->bind_param("s", $reference_id);
$stmt_area->execute();
$result_area = $stmt_area->get_result();
$data9 = $result_area->fetch_assoc();
$stmt_area->close();
 
// Fetch data from area_valuation table
$sql_area = "SELECT * FROM remarks_table WHERE reference_id = ?";
$stmt_area = $conn->prepare($sql_area); 
$stmt_area->bind_param("s", $reference_id);
$stmt_area->execute();
$result_area = $stmt_area->get_result();
$data10 = $result_area->fetch_assoc();
$stmt_area->close();


// Step 1: Fetch the engineer_id from the mis table
$sql_mis = "SELECT engineer_id FROM mis WHERE reference_id = ?";
$stmt_mis = $conn->prepare($sql_mis);
$stmt_mis->bind_param("s", $reference_id);
$stmt_mis->execute();
$result_mis = $stmt_mis->get_result();
$row_mis = $result_mis->fetch_assoc();
$stmt_mis->close(); 

if ($row_mis) {
    $engineer_id = $row_mis['engineer_id'];

    // Step 2: Fetch the engineer's name from engineer_login table
    $sql_engineer = "SELECT name FROM engineer_login WHERE engineer_id = ?";
    $stmt_engineer = $conn->prepare($sql_engineer);
    $stmt_engineer->bind_param("s", $engineer_id);
    $stmt_engineer->execute();
    $result_engineer = $stmt_engineer->get_result();
    $row_engineer = $result_engineer->fetch_assoc();
    $stmt_engineer->close();

    if ($row_engineer) {
        $engineer_name = $row_engineer['name'];
         //echo "Engineer Name: " . $engineer_name;
    } else {
        echo "Engineer not found.";
    }
} else {
    echo "No engineer assigned for this reference_id.";
}



// Step 1: Fetch the engineer_id from the mis table
$sql_mis = "SELECT report_id FROM mis WHERE reference_id = ?";
$stmt_mis = $conn->prepare($sql_mis);
$stmt_mis->bind_param("s", $reference_id);
$stmt_mis->execute();
$result_mis = $stmt_mis->get_result();
$row_mis = $result_mis->fetch_assoc();
$stmt_mis->close(); 

if ($row_mis) {
    $report_id = $row_mis['report_id'];

    // Step 2: Fetch the engineer's name from engineer_login table
    $sql_engineer = "SELECT name FROM report_login WHERE report_id = ?";
    $stmt_engineer = $conn->prepare($sql_engineer);
    $stmt_engineer->bind_param("s", $report_id);
    $stmt_engineer->execute();
    $result_engineer = $stmt_engineer->get_result();
    $row_engineer = $result_engineer->fetch_assoc();
    $stmt_engineer->close();

    if ($row_engineer) {
        $report_name = $row_engineer['name'];
         //echo "Engineer Name: " . $report_name;
    } else {
        echo "Engineer not found.";
    }
} else {
    echo "No engineer assigned for this reference_id.";
}


// Step 1: Fetch the engineer_id from the mis table
$sql_mis = "SELECT report_drafter_to_technical FROM mis WHERE reference_id = ?";
$stmt_mis = $conn->prepare($sql_mis);
$stmt_mis->bind_param("s", $reference_id);
$stmt_mis->execute();
$result_mis = $stmt_mis->get_result();
$row_mis = $result_mis->fetch_assoc();
$stmt_mis->close(); 

if ($row_mis) {
    $report_drafter_to_technical = $row_mis['report_drafter_to_technical'];

    // Step 2: Fetch the engineer's name from engineer_login table
    $sql_engineer = "SELECT name FROM technical_login WHERE technical_manager_id = ?";
    $stmt_engineer = $conn->prepare($sql_engineer);
    $stmt_engineer->bind_param("s", $report_drafter_to_technical);
    $stmt_engineer->execute();
    $result_engineer = $stmt_engineer->get_result();
    $row_engineer = $result_engineer->fetch_assoc();
    $stmt_engineer->close();

    if ($row_engineer) {
        $technical_name = $row_engineer['name'];
        //echo "Engineer Name: " . $technical_name;
    } else {
        echo "Engineer not found.";
    }
} else {
    echo "No engineer assigned for this reference_id.";
}
?>



<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Muthoot Home Fin Report</title>
    <link rel="shortcut icon" href="favicon.png" type="image/x-icon"> 
</head>

<style>
    .container {
         width: 90%;
         margin: 20px auto;
         border: 1px solid black;
         padding: 20px;
     }
.header-content {
 text-align: center;
 flex: 1;
}

.header-content h1 {
 margin: 0;
 margin-top:25px;  
  font-size: 38px;
 color: #902d2d;
}

.header-content p {
 margin: 2px 0;
 font-size: 26px;
 color: #333;
}
.footer{
 display: flex;
}
h3{
 background-color:rgb(243, 234, 222) ;
 padding:5px;
 text-align: center;
 border:1px solid black;
}  

table {
            width:50%;
            border-collapse: collapse;
            font-family: Arial, sans-serif;
        }
        th, td {
            border: 1px solid black;
            padding: 8px;
            text-align: left;
        }
        th {
            background-color: #f2f2f2;
        }
        .center {
            text-align: center;
            font-weight: bold;
        }
        input {
            width: 100%;
            padding: 5px;
        }
        body {
    font-family: Arial, sans-serif;
}

table {
    width: 100%;
    border-collapse: collapse;
}

th, td {
    border: 1px solid black;
    padding: 8px;
    text-align: center;
}

th {
    font-weight: bold;
    background-color: #f2f2f2;
}

input {
    width: 90%;  
    text-align: center;
    font-size: 14px;
    border:none;
    background-color:transparent;
    color:black;
    font-weight:500;
    padding: 5px;
}

#highlight{
    background-color: #d9d9d9;
     font-weight: bold;
}
.container {
    max-width: 1200px;
    margin: 20px auto;
    padding: 20px;
    background-color: white;
    box-shadow: 0px 0px 10px rgba(0, 0, 0, 0.1);
    border-radius: 8px;
}

.title {
    text-align: center;
    font-size: 24px;
    font-weight: bold;
    margin-bottom: 20px;
}
.overlay {
    position: absolute;
    bottom: 0;
    left: 0;
    background: rgba(0, 0, 0, 0.6);
    color: white;
    width: 100%;
    padding: 8px;
    font-size: 14px;
    text-align: center;
}

textarea{
  width:100%;
  height:200px;
}
</style>
<style>
.container {
    max-width: 1200px;
    margin: 20px auto;
    padding: 20px;
    background-color: white;
    box-shadow: 0px 0px 10px rgba(0, 0, 0, 0.1);
    border-radius: 8px;
}

.title {
    text-align: center;
    font-size: 24px;
    font-weight: bold;
    margin-bottom: 20px;
}
.grid-container {
    display: grid;
    grid-template-columns: repeat(4, 1fr);
    gap: 15px;
}

.grid-item {
    position: relative;
    border-radius: 8px;
    overflow: hidden;
    box-shadow: 0px 4px 6px rgba(0, 0, 0, 0.1);
}

.grid-item img {
    width: 100%;
    height: 200px;
    object-fit: cover;
    transition: transform 0.3s ease;
}
.grid-item:hover img {
    transform: scale(1.05);
}

.overlay {
    position: absolute;
    bottom: 0;
    left: 0;
    background: rgba(0, 0, 0, 0.6);
    color: white;
    width: 100%;
    padding: 8px;
    font-size: 14px;
    text-align: center;
}
 
   
/* Force a stable 4-column grid that wkhtmltopdf respects */
.image-gallery { width: 100%; }
.image-grid { width: 100%; border-collapse: collapse; table-layout: fixed; }
.image-grid tr { page-break-inside: avoid; }
.image-grid td { width: 25%; padding: 6px; vertical-align: top; }

.image-grid .img-wrap { display: block; }
.image-grid img { display: block; width: 100%; height: auto; }
.image-grid .caption { font-size: 12px; text-align: center; margin-top: 4px; }

/* If you had a flex layout before, neutralize it */
.image-gallery { display: block !important; }



    /* Print-specific rules */
    @media print {
      .no-print {
        display: none !important;
      }

      body {
        margin: 0;
      }
 
    }
  button{
    padding:8px;
    margin-left:45%;
    background-color:#808485;
    color:white;
    font-weight:700;
    font-style:italic;
  }
  button:hover{
    background-color:rgba(216,216,216,255);
    color:white;
  }

/* Optional: Google map styling */
    .google-map-container {
      max-width: 90%;
      margin: 20px auto;
      border: 2px solid #ccc;
      padding: 10px;
      box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
      background-color: #f9f9f9;
      border-radius: 8px;
      text-align: center;
    }

    .google-map-container img {
      max-width: 100%;
      height: auto;
      display: inline-block;
      border: 1px solid #999;
      border-radius: 4px;
    }
    
.logo img {
  width: 120px;
  margin-left:30px;
  height: auto;
}
</style>


<body>
    <div class="container">
        <header>
            <div class="footer">
            <div class="logo">
        <img src="images/logo.png" alt="Magpie Logo">
            </div>
            <div class="header-content">
                <h1>MAGPIE ENGINEERING PVT. LTD.</h1>
                <p>Valuer Designer Architects</p>
                <p>Office: 208, Sunrise Tower, 579, M.G. Road, Indore (M.P.)</p>
            </div>
            </div>
        </header>

        <table>
    <tr>
        <td>SERIAL NO.</td>
        <td><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data3['reference_id'] ?? '') ?>
    </span></td>
        <td>DATE OF VISIT</td>
        <td><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data1['fe_to_coordinator_assign_at'] ?? '') ?>
    </span></td>
        <td>DATE OF REPORT</td>
        <td><span style="display: inline-block; min-width: 50px; padding: 2px;">
 <?= htmlspecialchars(date('d M Y h:i A', strtotime($data1['report_assigned_at'] ?? ''))) ?>
    </span></td>
    </tr>
    <tr>
        <th colspan="6" class="center" id="highlight">TECHNICAL SCRUTINY REPORT</th>
    </tr>
    <tr>
        <th colspan="6" class="center" id="highlight">LOAN APPLICATION DETAILS</th>
    </tr>
    <tr>
        <td>BRANCH NAME</td>
        <td><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data1['bank_branchname'] ?? '') ?>
    </span></td>
        <td>APPLICANT/CO-APPLICANT NAME</td>
        <td><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data1['customerName'] ?? '') ?>/ <?= htmlspecialchars($data1['co_applicant_name'] ?? '') ?>

    </span></td>
        <td>APPL MOB NO:</td>
        <td><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data1['customerMob'] ?? '') ?>
    </span></td>
    </tr>
    <tr>
        <td>PRODUCT</td>
        <td><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data1['caseType'] ?? '') ?>
    </span></td>
        <td>TRANSACTION TYPE</td>
        <td><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data2['transaction_type'] ?? '') ?>
    </span></td>
        <td>LAN</td>
        <td><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data1['applicationNo'] ?? '') ?>
    </span></td>
    </tr>
    <tr>
        <th colspan="6" id="highlight" class="center">PROJECT DETAILS</th>
    </tr>
    <tr>
        <td>PROJECT NAME & NO. (IF ANY)</td>
        <td colspan="5"> <span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data2['project_name'] ?? '') ?>  </span>
   </td>
    </tr>
    <tr>
        <th colspan="6" id="highlight" class="center">ADDRESS DETAILS</th>
    </tr>
    <tr>
        <td>ADDRESS AS PER DOCUMENT</td>
        <td colspan="5"><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data3['address_per_document'] ?? '') ?>
</span></td>
    </tr>
    <tr>
        <td>ADDRESS AS PER SITE</td>
        <td colspan="5"><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data3['address_per_site'] ?? '') ?></span></td>
    </tr>
    <tr>
        <td>GEO CO-ORDINATES</td>
        <td><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data3['latitude_value'] ?? '') ?> <?= htmlspecialchars($data3['longitude_value'] ?? '') ?>
    </span></td>
        <td>LANDMARK</td>
        <td colspan="3"><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data3['landmark_1'] ?? '') ?> <?= htmlspecialchars($data3['landmark_2'] ?? '') ?>
    </span></td>
    </tr>
    <tr>
        <td>DISTRICT</td>
        <td><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data3['address_line_3_as_per_doc'] ?? '') ?>
    </span></td>
        <td>STATE</td>
        <td><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data3['address_line_4_as_per_doc'] ?? '') ?>
    </span></td>
        <td>PINCODE</td>
        <td><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data3['pin_code'] ?? '') ?>
    </span></td>
    </tr>
    <tr>
        <th colspan="6" id="highlight"class="center">BOUNDARIES</th>
    </tr>
    <tr>
        <td>DIRECTIONS</td>
        <td>NORTH</td>
        <td>SOUTH</td>
        <td>EAST</td>
        <td>WEST</td>
        <td></td>
    </tr>
    <tr>
        <td>AS PER DOCUMENT</td>
        <td><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data3['direction_as_per_document_north'] ?? '') ?>
    </span></td>
        <td><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data3['direction_as_per_document_south'] ?? '') ?>
    </span></td>
        <td><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data3['direction_as_per_document_east'] ?? '') ?>
    </span></td>
        <td><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data3['direction_as_per_document_west'] ?? '') ?>
    </span></td>
     <td rowspan="2"><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data3['boundaries_matching'] ?? '') ?>
    </span></td>    </tr>
    <tr>
        <td>AS PER SITE INVESTIGATION</td>
        <td><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data3['direction_as_per_site_north'] ?? '') ?>
    </span></td>
        <td><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data3['direction_as_per_site_south'] ?? '') ?>
    </span></td>
        <td><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data3['direction_as_per_site_east'] ?? '') ?>
    </span></td>
        <td><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data3['direction_as_per_site_west'] ?? '') ?>
    </span></td>
        
    </tr>
     <tr>
        <td><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data3['property_identified_through'] ?? '') ?>
    </span></td>
        <td><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data3['direction_approved_north'] ?? '') ?>
    </span></td>
        <td><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data3['direction_approved_south'] ?? '') ?>
    </span></td>
        <td><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data3['direction_approved_east'] ?? '') ?>
    </span></td>
        <td><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data3['direction_approved_west'] ?? '') ?>
    </span></td>
        
    </tr>
    <tr>
        <th colspan="6" id="highlight"class="center">GENERAL DETAILS</th>
    </tr>
    <tr>
        <td>APPROVAL AUTHORITY (NAME IF APPROVED)</td>
        <td><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data3['municipal_authority_name'] ?? '') ?>
    </span></td>
        <td>APPROVAL AUTHORITY LIMIT</td>
        <td><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data3['property_location_in'] ?? '') ?>
    </span></td>
        <td>AGE OF PROPERTY</td>
        <td><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data2['age_of_property'] ?? '') ?>
    </span></td>
    </tr>
    <tr>
        <td>TOTAL NO OF UNITS IN APARTMENT/FLOOR</td>
        <td colspan="2"><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data8['number_of_units_each_floor'] ?? '') ?>
    </span></td>
        <td>TOTAL NO OF UNITS OCCUPIED</td>
        <td colspan="2"><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data8['number_of_units_building'] ?? '') ?>
    </span></td>        
    </tr>
    <tr>
        <td>SELLER NAME </td>
        <td><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data9['seller_name'] ?? '') ?>
    </span></td>
        <td>OCCUPANCY STATUS</td>
        <td><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data2['occupancy_status'] ?? '') ?>
    </span></td>
        <td>PROPERTY RESIDUAL AGE</td>
        <td><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data2['residual_age_of_property'] ?? '') ?>
    </span></td>
    </tr>
    <tr>
        <td>OCCUPIED BY </td>
         <td><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data2['relation_of_occupant'] ?? '') ?>
    </span></td>       
        <td>OCCUPANT NAME</td>
        <td colspan="3"><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data2['occupant_name'] ?? '') ?>
    </span></td>
          </tr>
    <tr>
        <td>SELLER TYPE</td>
        <td><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data9['seller_type'] ?? '') ?>
    </span></td>      
        <td>TYPE OF UNIT / PROPERTY</td>
        <td><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data2['property_unit_type'] ?? '') ?>
    </span></td>
        <td>APPROACH ROAD TO PROPERTY - TYPE</td>
        <td><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data2['type_of_approach_road'] ?? '') ?>
    </span></td>
    </tr>
            <tr>
                <td>APPROACH ROAD WIDTH</td>
                <td><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data2['width_of_approach_road'] ?? '') ?>
    </span></td>
                <td>PROPERTY FALLING IN CAUTION AREA & REASON</td>
                <td colspan="3"><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data4['caution_area'] ?? '') ?>
    </span></td>
            </tr>
            <tr>
                <td>ZONE CLASSIFICATION AS PER MASTER PLAN</td>
                <td><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data4['zoning_development_plan'] ?? '') ?>
    </span></td>
                <td>NAME OF CURRENT PROPERTY OWNER</td>
                <td colspan="3"><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data9['owner_name'] ?? '') ?>
    </span></td>
            </tr>          
        </table>
        <table>
            <tr>
                <th id="highlight"colspan="4">CONNECTIVITY & SURROUNDING DEVELOPMENT</th>
            </tr>
            <tr>
                <th>SR.NO.</th>
                <th>PREMISES LIST</th>
                <th>APPROX. DISTANCE FROM PROPERTY (IN KMS)</th>
                <th>NAME OF THE STATION / ROAD</th>
            </tr>
            <tr>
                <td><input type="text" readonly  value="01"></td>
                <td>NEAREST RAILWAY STATION</td>
                <td><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data3['nearest_railway_station_distance'] ?? '') ?>
    </span></td>
                <td><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data3['nearest_railway_station_name'] ?? '') ?>
    </span></td>
            </tr>
            <tr>
                <td><input type="text" readonly  value="02"></td>
                <td>NEAREST SCHOOL</td>
                <td><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data3['nearest_school_college_distance'] ?? '') ?>
    </span></td>
     <td><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data3['nearest_school_college_name'] ?? '') ?>
    </span></td>
            </tr>
            <tr>
                <td><input type="text" readonly  value="03"></td>
                <td>NEAREST MARKET/LANDMARK/TEMPLE</td>
<td><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data3['nearest_city_center_distance'] ?? '') ?>
    </span></td>
                    <td><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data3['nearest_city_center_name'] ?? '') ?>
    </span></td>
            </tr>
            <tr>
                <td><input type="text" readonly  value="04"></td>
                <td>NEAREST BUS STOP</td>
                <td><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data3['nearest_bus_stop_distance'] ?? '') ?>
    </span></td>
                <td><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data3['nearest_bus_stop_name'] ?? '') ?>
    </span></td>
            </tr>
            <tr>
                <td><input type="text" readonly  value="05"></td>
                <td>NEAREST HIGHWAY/MAJOR ROAD</td>
                <td><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data3['nearest_national_highway_distance'] ?? '') ?>
    </span></td>
                <td><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data3['nearest_national_highway_name'] ?? '') ?>
    </span></td>
            </tr>
            <tr>
                <td colspan="3">PERCENTAGE OF SURROUNDING DEVELOPMENT CONSIDERING CONNECTIVITY, BASIC AMENITIES, CONSTRUCTION ACTIVITY & OCCUPANCY*</td>
                <td><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data2['develop_percent'] ?? '') ?>
    </span></td>
            </tr>
        </table>
        <table>
       
<tr>
    <th colspan="6" id="highlight">AREA DETAILS</th>
</tr>
<tr>
    <th>AREA TYPE</th>
    <th>SQUARE FEET</th>
    <th>SQUARE METER</th>
    <th colspan="3">REMARKS ON AREA OF PROPERTY - FLOOR WISE DETAILS</th>
</tr>
<tr>
    <td>PLOT AREA</td>
    <td><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data6['final_plot_square_feet'] ?? '') ?>
    </span></td>
    <td><input type="text" readonly  name="engineer_id" value="<?= isset($data6['final_plot_square_feet']) ? round(floatval($data6['final_plot_square_feet']) * 0.092903, 2) : '' ?>"></td>
    <td colspan="2"><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars( 'Land Area / UDS Area') ?>
    </span></td>
    <td rowspan="5"><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data8['basements_remarks'] ??'') ?>
    </span></td>
</tr>
<tr>
    <td>CARPET AREA</td>
    <td><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data6['actual_carpet_square_feet'] ?? '') ?>
    </span></td>
    <td><input type="text" readonly  name="engineer_id" value="<?= isset($data6['actual_carpet_square_feet']) ? round(floatval($data6['actual_carpet_square_feet']) * 0.092903, 2) : '' ?>"></td>
    <td colspan="2"><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars( 'As Per Actual On Site') ?>
    </span></td>
</tr>
<tr>
    <td>EXISTING BUILT UP RCC</td>
    <td><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data6['actual_construction_square_feet'] ?? '') ?>
    </span></td>
        <td><input type="text" readonly  name="engineer_id" value="<?= isset($data6['actual_construction_square_feet']) ? round(floatval($data6['actual_construction_square_feet']) * 0.092903, 2) : '' ?>"></td>

    <td colspan="2"><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars('NOT MORE THAN 20 % OF CA ') ?>
    </span></td>
</tr>
<tr>
    <td>PROPOSED BUILT-UP</td>
    <td><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data6['construction_square_feet'] ?? '') ?>
    </span></td>
            <td><input type="text" readonly  name="engineer_id" value="<?= isset($data6['construction_square_feet']) ? round(floatval($data6['construction_square_feet']) * 0.092903, 2) : '' ?>"></td>


            <td colspan="2"><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars('AS PER APPROVAL / BYE-LAWS/POLICY') ?>
    </span></td>
</tr>
<tr>
    <td>SALE AREA/SBA</td>
    <td><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data6['final_plot_square_feet'] ?? '') ?>
    </span></td>
                <td><input type="text" readonly  name="engineer_id" value="<?= isset($data6['final_plot_square_feet']) ? round(floatval($data6['final_plot_square_feet']) * 0.092903, 2) : '' ?>"></td>

    <td colspan="2"><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars('AS PER APPROVAL / BYE-LAWS/POLICY') ?>
    </span></td>
</tr>
<tr>
    <td colspan="2">ZONE CLASSIFICATION AS PER MASTER PLAN </td>
    <td colspan="4"><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data4['zoning_development_plan'] ?? '') ?>
    </span></td>
</tr>
</table>
<table border="1" style="border-collapse: collapse; width: 100%; font-family: Arial; font-size: 14px;">
  <tr id="highlight">
    <td colspan="6" align="center">NO. OF ROOM & INTERNAL AMENITIES DETAILS</td>
  </tr>
  <tr align="center">
    <td>DRAWING / HALL / LIVING</td>
    <td>KITCHEN / DINING ROOM</td>
    <td>BEDROOM</td>
    <td>STUDY ROOM / POOJA ROOM</td>
    <td>TOTAL NO. OF ROOMS / FLAT CONFIGURATION</td>
    <td>WC / BATH / TOILET</td>
  </tr>
  <tr align="center">
    <td colspan ="6"><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data8['number_of_lifts'] ?? '') ?>
    </span></td>
  
  </tr>

  <!-- Valuation Section -->
  <tr style="background-color: #d9d9d9; font-weight: bold;">
    <td colspan="6" align="center">VALUATION DETAILS</td>
  </tr>
  <tr align="center" style="font-weight: bold;">
    <td></td>
    <td>AREA TYPE *</td>
    <td>AREA (SQ. FEET) *</td>
    <td>RATE/SFT *</td>
    <td>VALUATION*</td>
  </tr>

  <!-- A. Area Valuation -->
  <tr>
    <td>A) AREA VALUATION</td>
    <td>AREA TO BE CONSIDERED FOR VALUATION</td>
    <td><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data6['final_plot_square_feet'] ?? '') ?>
    </span></td>
    <td><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data6['final_plot_rate'] ?? '') ?>
    </span></td>
    <td><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data6['finally_plot_valuation'] ?? '') ?>
    </span></td>
    <td>Rs.</td>
  </tr>

  <!-- B. Construction Cost -->
  <tr>
    <td rowspan="2">B) CONSTRUCTION / EXTENSION / IMPROVEMENT COST</td>
    <td>EXISTING BUILT UP AREA</td>
    <td><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data6['construction_area_sqft_1'] ?? '') ?>
    </span></td>
    <td><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data6['construction_rate_1'] ?? '') ?>
    </span></td>
    <td><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data6['construction_valuation_1'] ?? '') ?>
    </span></td>
    <td>Rs.</td>
  </tr>

  <tr>
    <td>PROPOSED BUILT UP AREA</td>
    <td><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data6['construction_area_sqft_2'] ?? '') ?>
    </span></td>
    <td><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data6['construction_rate_2'] ?? '') ?>
    </span></td>
    <td><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data6['construction_valuation_2'] ?? '') ?>
    </span></td>    
    <td>Rs.</td>
  </tr>
<tr>
    <td rowspan="2">C) FOR FLOOR PROPERTY</td>
    <td>SBUA/ BUA/ CARPET AREA </td>
    <td><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data6['carpet_square_feet'] ?? '') ?>
    </span></td>
    <td><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data6['carpet_rate'] ?? '') ?>
    </span></td>
    <td><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data6['carpet_valuation_computed'] ?? '') ?>
    </span></td>    
    <td>Rs.</td>
  </tr>
  <!-- D. Amenities -->
  <tr>
    <td>D) AMENITIES</td>
    <td>DESCRIPTION</td>
    <td>AREA/QUANTITY</td>
    <td>UNIT (LOV)</td>
    <td>AMOUNT</td>
    <td rowspan="2"></td>
  </tr>
  <tr>
    <td>1</td>
    <td><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data10['NA'] ?? '') ?>
    </span></td>
    <td><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data10['NA'] ?? '') ?>
    </span></td>
    <td><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data10['NA'] ?? '') ?>
    </span></td>
    <td><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data10['NA'] ?? '') ?>
    </span></td>
  </tr>

  <!-- Total Costs -->
  <tr style="font-weight: bold;">
    <td colspan="4" align="right">TOTAL AMENITIES COST (D)</td>
    <td><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data6['amenities_total'] ?? '') ?>
    </span></td>
    <td>Rs.</td>
  </tr>
  <tr style="font-weight: bold;">
    <td colspan="4" align="right">TOTAL MARKET VALUE / REALISABLE VALUE (A + B + C + D)</td>
    <td><span style="display: inline-block; min-width: 50px; padding: 2px;">
    <?php
$totalValuation = 
    floatval($data6['finally_plot_valuation'] ?? 0) +
    floatval($data6['construction_valuation_1'] ?? 0) +
        floatval($data6['construction_valuation_2'] ?? 0) +

    floatval($data6['carpet_valuation_computed'] ?? 0) +
    floatval($data6['amenities_total'] ?? 0);
?>

<?= htmlspecialchars($totalValuation) ?>

    </span></td>
    <td>Rs.</td>
  </tr>
  <tr style="font-weight: bold;">
    <td colspan="4" align="right">DISTRESS VALUE (75%)</td>
    <td><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data6['total_distress_value'] ?? '') ?>
    </span></td>
    <td>Rs.</td>
  </tr>
</table>
<table border="1" style="border-collapse: collapse; width: 100%; font-family: Arial; font-size: 14px;">
                <tr>
                    <th colspan="11" id="highlight">FLOOR DETAILS</th>
                </tr>
                <tr>
                    <th></th>
                    <th colspan="3">FLOORS</th>
                    <th colspan="2">APPROVED</th>
                    <th colspan="2">ACTUAL / PROPOSED</th>
                    <th colspan="3">REMARKS ON NO. OF FLOORS - APPROVED & PROPOSED</th>
                </tr>
                <tr>
                    <td>(A)</td>
                    <td colspan="3"> NO OF BASEMENT(S)</td>
                    <td colspan="2"><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data8['basement_approved'] ?? '') ?>
    </span></td>
                    <td colspan="2"><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data8['basement_actual_planned'] ?? '') ?>
    </span></td>
                    <td colspan="3" rowspan="4"><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data8['number_ground_remarks'] ?? '') ?> 
    </span></td>
                </tr>
                <tr>
                    <td> (B)</td>    
                    <td colspan="3"> NO OF GROUND / PARKING/STILT</td>
                    <td colspan="2"><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data8['number_ground_approved'] ?? '') ?>
    </span></td>
                    <td colspan="2"><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data8['ground_actual_planned'] ?? '') ?>
    </span></td>
                    
                </tr>
                <tr>
                    <td>(C)</td>
                    <td colspan="3"> NO. OF UPPER FLOOR(S)</td>
                    <td colspan="2"><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data8['number_first_approved'] ?? '') ?>
    </span></td>
                    <td colspan="2"><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data8['first_actual_planned'] ?? '') ?>
    </span></td>
                   
                </tr>
                <tr>
                    <td>(E) = (A + B + C)</td>
                    <td colspan="3"> TOTAL NO. OF FLOOR(S)</td>
                    <td colspan="2"><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data8['total_floors_approved'] ?? '') ?>
    </span></td>
                    <td colspan="2"><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data8['total_floors_actual_planned'] ?? '') ?>
    </span></td>
                </tr>
</table><table>
                <tr>
                    <th colspan="6" id="highlight">TECHNICAL DOCUMENTS DETAILS</th>
                </tr>
                <tr>
                    <th>DOCUMENT TYPE</th>
                    <th>DOCUMENT NAME</th>
                    <th>RECD TYPE - COPY / ORIGINAL</th>
                    <th>REF NO / SERIAL NO.</th>
                    <th>REF DATE - APPROVAL / DOCUMENT DATE</th>
                    <th>DETAILS OF APPROVAL - AUTHORITY & NO. OF FLOORS</th>
                </tr>
            
                <tr>
                    <td colspan="3">REMARKS ON DOCUMENTS VERIFIED  </td>
                    <td colspan="3"><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data9['list_documents'] ?? '') ?>
    </span></td>
                </tr>
                </table>
                <table>
                 <tr>
                <th colspan="6" id="highlight">NDMC PARAMETERS</th>
                </tr>
                <tr>
                    <th>NATURE OF BUILDING / WING</th>
                    <td><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data2['property_unit_type'] ?? '') ?>
    </span></td>
                    <th>STRUCTURE TYPE</th>
                    <td><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data4['structure_type'] ?? '') ?>
    </span></td>
                    <th>FOOTING TYPE</th>
                    <td><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data4['failing_in_road_widening'] ?? '') ?>
    </span></td>
                </tr>
                <tr>
                    <th>TYPE OF MASONARY</th>
                    <td><input type="text" readonly  name="type_of_masonary" value="Brick Masonary"></td>
                    <th>SEISMIC ZONE</th>
                    <td><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data4['seismic_zone'] ?? '') ?>
    </span></td>
                    <th>SHAPE OF BUILDING</th>
                    <td><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data10['NA'] ?? '') ?>
    </span></td>
                </tr>
                <tr>
                    <th>MORTAR TYPE</th>
                    <td><input type="text" readonly  name="mortar_type" value="Cement Mortar "></td>
                    <th>ROOF TYPE</th>
                    <td><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data4['roof_type'] ?? '') ?>
    </span></td>
                    <th>FIRE EXIT AVAILABLE</th>
                    <td><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data10['NA'] ?? '') ?>
    </span></td>
                </tr>
                <tr>
                    <th>CONCRETE GRADE</th>
                    <td><input type="text" readonly  name="concrete_grade" value="M-20"></td>
                    <th>FLOOD PRONE AREA</th>
                    <td><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data10['NA'] ?? '') ?>
    </span></td>
                    <th>STEEL GRADE</th>
                    <td><input type="text" readonly  name="steel_grade" value="FE-415"></td>
                </tr>
 <tr>
                    <th>EXPANSION JOIN AVAILABLE</th>
 <td><span style="display: inline-block; min-width: 50px; padding: 2px;"><?= htmlspecialchars($data10['NA'] ?? '') ?> </span></td>
                        <th>PROJECTED PARTS AVAILABLE</th>
 <td><span style="display: inline-block; min-width: 50px; padding: 2px;"><?= htmlspecialchars($data10['NA'] ?? '') ?> </span></td>
                    <th>GROUND SLOP MORE THAN 20%</th>
 <td><span style="display: inline-block; min-width: 50px; padding: 2px;"><?= htmlspecialchars($data10['NA'] ?? '') ?> </span></td>
                </tr>
                <tr>
                    <th>STRUCTURAL SYSTEM</th>
               <td><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data10['NA'] ?? '') ?>
    </span></td>
                    <th>SOIL TYPE</th>
                    <td><input type="text" readonly  name="flood_prone_area" value="BLACK COTTON SOIL"></td>

                    <th>SOIL LIQUEFIABLE</th>
    <td><input type="text" readonly  name="flood_prone_area" value="NO ">
</td>                </tr>
                <tr>
                    <th>ENVIRONMENT EXPOSURE CONDITION</th> 
    <td><input type="text" readonly  name="flood_prone_area" value="MILD"></td>  
                      <th>PLAN ASPECT RATIO</th>
 <td><span style="display: inline-block; min-width: 50px; padding: 2px;"><?= htmlspecialchars($data10['NA'] ?? '') ?> </span></td>
                    <th>SOIL SLOPE VULNERABLE TO LIQUEFIABLE</th>
 <td><span style="display: inline-block; min-width: 50px; padding: 2px;"><?= htmlspecialchars($data10['NA'] ?? '') ?> </span></td>
                </tr>
                <tr>
                    <th>CYCLONE ZONE - WIND SPEED</th>
 <td><span style="display: inline-block; min-width: 50px; padding: 2px;"><?= htmlspecialchars($data10['NA'] ?? '') ?> </span></td>
                    <th>COASTAL REGULATORY ZONE</th>
                 <td><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data4['costal_regulatory_zone'] ?? '') ?>
    </span></td>

                    <th>SOIL STRATA</th>
 <td><span style="display: inline-block; min-width: 50px; padding: 2px;"><?= htmlspecialchars($data10['NA'] ?? '') ?> </span></td>
                </tr>
                <tr>
                    <th colspan="6"id="highlight">SITE INVESTIGATION</th>
                </tr>
                <tr>
                    <th>SR.NO.</th>
                    <th>ACTIVITY</th>
                    <th>ALLOTTED % FOR ACTIVITY</th>
                    <th>PRESENT COMPLETION (%)</th>
                    <th>NO OF FLOORS COMPLETED</th>
                    <th>REMARKS ON PROGRESS</th>
                </tr>
                <tr>
                    <td colspan="6"> IN CASE OF EXTENSION / IMPROVEMENT CASE,REMARKS ON THE PROPOSED STRUCTURE & EXISTING STRUCTURE IS MANDATORY </td>
                
                </tr>
                <tr>
                    <td>1</td>
                    <td><input type="text" readonly  value="Plinth"></td>
                    <td><input type="text" readonly  value="15%"></td>
                    <td><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data8['plinth_completion_present'] ?? '') ?>
    </span></td>
 <td><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data8['plinth_floors_completed'] ?? '') ?>
    </span></td>
                        <td rowspan="10"><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data8['total_completion_present'] ?? '') ?>
    </span></td>
                </tr>
                <tr>
                    <td>2</td>
                    <td><input type="text" readonly  value="R.C.C../SLAB COMPLETION"></td>
                    <td><input type="text" readonly  value="30%"></td>
                    <td><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data8['rcc_completion_present'] ?? '') ?>
    </span></td>
 <td><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data8['rcc_floors_completed'] ?? '') ?>
    </span></td>
                </tr>
                <tr>
                    <td>3</td>
                    <td><input type="text" readonly  value="Brickwork"></td>
                    <td><input type="text" readonly  value="15%"></td>
                    <td><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data8['brickwork_completion_present'] ?? '') ?>
    </span></td>
 <td><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data8['brickwork_floors_completed'] ?? '') ?>
    </span></td>
</tr>                <tr>
                    <td>4</td>
                    <td><input type="text" readonly  value="Internal Plaster"></td>
                    <td><input type="text" readonly  value="5%"></td>
                    <td><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data8['internal_plaster_completion_present'] ?? '') ?>
    </span></td>
 <td><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data8['internal_plaster_floors_completed'] ?? '') ?>
    </span></td></tr>
                <tr>
                    <td>5</td>
                    <td><input type="text" readonly  value="External Plaster"></td>
                    <td><input type="text" readonly  value="5%"></td>
                    <td><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data8['external_plaster_completion_present'] ?? '') ?>
    </span></td>
 <td><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data8['external_plaster_floors_completed'] ?? '') ?>
    </span></td>               </tr>
                <tr>
                    <td>6</td>
                    <td><input type="text" readonly  value="Flooring"></td>
                    <td><input type="text" readonly  value="5%"></td>
                    <td><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data8['flooring_completion_present'] ?? '') ?>
    </span></td>
 <td><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data8['flooring_floors_completed'] ?? '') ?>
    </span></td>                </tr>
                <tr>
                    <td>7</td>
                    <td><input type="text" readonly  value="PANTING"></td>
                    <td><input type="text" readonly  value="5%"></td>
                    <td><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data8['painting_completion_present'] ?? '') ?>
    </span></td>
 <td><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data8['painting_floors_completed'] ?? '') ?>
    </span></td>              </tr>
                <tr>
                    <td>8</td>
                    <td><input type="text" readonly  value="PLUMBING"></td>
                    <td><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars('5%') ?>
    </span></td>
                    <td><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data8['plumbing_completion_present'] ?? '') ?>
    </span></td>
 <td><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data8['plumbing_floors_completed'] ?? '') ?>
    </span></td>      </tr>
                <tr>
                    <td>9</td>
                    <td><input type="text" readonly  value="FIXTURES & FINISING"></td>
                    <td><input type="text" readonly  value="5%"></td>
                    <td><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data8['fixtures_completion_present'] ?? '') ?>
    </span></td>
 <td><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data8['fixtures_floors_completed'] ?? '') ?>
    </span></td>     </tr>
                <tr>
                    <td>10</td>
                    <td><input type="text" value="Foundation "></td>
                    <td><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars('10%') ?>
    </span></td>
                    <td><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data8['foundation_completion_present'] ?? '') ?>
    </span></td>
 <td><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data8['foundation_floors_completed'] ?? '') ?>
    </span></td>           </tr>
                <tr>
                    <th colspan="2">TOTAL COMPLETION</th>
                    <td><input type="text" readonly  name="total_completion_100" value="100%"></td>
                    <td><input type="text" readonly  name="total_completion_actual" value="<?=$data8['total_completion_present']  ?? '' ?>"></td>
            <td colspan="2"><input type="text" class="manual-input" name="rcc_completion_manual"></td>                </tr>
                <tr>
                    <th colspan="6">RECOMMENDED PERCENTAGE TO BE CONSIDERED 100% HIGHER THAN COMPLETION PERCENTAGE, MAXIMUM UPTO 100%</th>
                </tr>
                <tr>
                    <th colspan="3">IS THE PROPERTY TECHNICALLY ACCEPTABLE?</th>
                    <td><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data9['positive_report'] ?? '') ?>
    </span></td>
                    <th>MARKETABILITY OF PROPERTY</th>
                    <td><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data9['markebility'] ?? '') ?>
    </span></td>
                </tr>

                <tr>
                    <th colspan="6" id="highlight" align="left">Remarks</th>
                </tr>
                <tr>
                    <td colspan="6"><span style="white-space: pre-line; font-size:14px; display: block; text-align: left; padding: 0; margin: 0;"readonly>
        <?= htmlspecialchars($data10['remarks'] ?? '') ?></span></td>
                </tr>


                <tr>
                    <th colspan="6" id="highlight">TSR DEVIATION</th>
                </tr>
                <tr>
                    <th colspan="2">SR NO</th>
                    <th colspan="2">DEVIATION TYPE</th>
                    <th colspan="2">IF YES, THEN DETAILS.</th>
                </tr>
                <tr>
                    <td colspan="2">1</td>
                    <td colspan="2">DOCUMENT DEVIATION</td>
                    <td colspan="2"><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data2['NA'] ?? '') ?>
    </span></td>
                </tr>
                <tr>
                    <td colspan="2">2</td>
                    <td colspan="2">ROAD DEVIATION</td>
                    <td colspan="2"><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data2['NA'] ?? '') ?>
    </span></td>
                </tr>
                <tr>
                    <td colspan="2">3</td>
                    <td colspan="2">PROPERTY USAGE DEVIATION</td>
                    <td colspan="2"><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data2['NA'] ?? '') ?>
    </span></td>
                </tr>
                <tr>
                    <td colspan="2">4</td>
                    <td colspan="2">OTHER DEVIATION</td>
                    <td colspan="2"><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data2['NA'] ?? '') ?>
    </span></td>
                </tr>
            </table>
            
            <br>
            
            <table>
            <tr>
                    <th colspan="6" id="highlight">TSR CONDITION</th>
                </tr>
                <tr>
                    <th>SR.NO.</th>
                    <th>TSR CONDITIONS FOR COMPLIANCE</th>
                </tr>
                <tr>
                    <td>1</td>
                    <td><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data2['NA'] ?? '') ?>
    </span></td>
                </tr>
                <tr>
                    <td>2</td>
                    <td><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data2['NA'] ?? '') ?>
    </span></td>
                </tr>
                <tr>
                    <td>GEO POSITION</td>
                    <td><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data3['latitude_value'] ?? '') ?> <?=  htmlspecialchars($data3['longitude_value'] ?? '') ?>
    </span></td>
                </tr>       
<table>
<tr><th style="margin-bottom:-18px;">PHOTOGRAPH OF THE PROPERTY</tr></th></table>
<br>

    
<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

$servername = "localhost";
$username   = "root";
$password   = "";
$dbname     = "project_db";

$conn = new mysqli($servername, $username, $password, $dbname);
if ($conn->connect_error) {
    die("Connection failed: " . htmlspecialchars($conn->connect_error));
}

$reference_id = $_SESSION['reference_id'] ?? null;
$reference_id = $_GET['reference_id'] ?? $reference_id;

if ($reference_id) {

    // Map captions
    $captions = [
        'image1'  => 'EXTERNAL PHOTOS',
        'image2'  => 'Kitchen',
        'image3'  => 'Selfie',
        'image4'  => 'Electric Meter',
        'image6'  => 'Other 1',
        'image7'  => 'Other 2',
        'image8'  => 'Other 3',
        'image9'  => 'Other 4',
        'image10' => 'Other 5',
        'image11' => 'Other 6',
        'image12' => 'Other 7',
        'image13' => 'Other 8',
        'image14' => 'Other 9',
        'image15' => 'Other 10',
        'image16' => 'Other 11',
        'image17' => 'Other 12',
        'image18' => 'Other 13',
        'image19' => 'Other 14',
        'image20' => 'Other 15',
    ];

    // === Helper: EXIF-aware orientation detection ===
    function classify_orientation_after_exif(string $imageData): ?string {
        $size = @getimagesizefromstring($imageData);
        if (!$size || !isset($size[0], $size[1])) {
            return null;
        }
        $width  = (int)$size[0];
        $height = (int)$size[1];

        $mime = $size['mime'] ?? '';
        if ($mime === 'image/jpeg' && function_exists('exif_read_data')) {
            $tmp = @tempnam(sys_get_temp_dir(), 'exif_');
            if ($tmp !== false) {
                @file_put_contents($tmp, $imageData);
                $exif = @exif_read_data($tmp);
                @unlink($tmp);

                if (!empty($exif['Orientation'])) {
                    $orientation = (int)$exif['Orientation'];
                    if ($orientation === 6 || $orientation === 8) {
                        $t = $width; $width = $height; $height = $t;
                    }
                }
            }
        }
        return ($width >= $height) ? 'horizontal' : 'vertical';
    }

    // === Helper: Fix orientation physically with Imagick ===
    function fixImageOrientation($binaryData) {
        $img = new Imagick();
        $img->readImageBlob($binaryData);

        switch ($img->getImageOrientation()) {
            case Imagick::ORIENTATION_BOTTOMRIGHT:
                $img->rotateImage("#000", 180);
                break;
            case Imagick::ORIENTATION_RIGHTTOP:
                $img->rotateImage("#000", 90);
                break;
            case Imagick::ORIENTATION_LEFTBOTTOM:
                $img->rotateImage("#000", -90);
                break;
        }

        $img->setImageOrientation(Imagick::ORIENTATION_TOPLEFT);
        $fixed = $img->getImageBlob();
        $img->destroy();

        return $fixed;
    }

    $sql = "SELECT 
                image1, image2, image3, image4, 
                image6, image7, image8, image9, 
                image10, image11, image12, image13, image14, image15, image16, image17, image18, image19, image20
            FROM final_uploaded_images 
            WHERE reference_id = ?";

    $stmt = $conn->prepare($sql);
    if ($stmt === false) {
        die("Error preparing the SQL statement: " . htmlspecialchars($conn->error));
    }

    $stmt->bind_param("s", $reference_id);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result && $result->num_rows > 0) {
        $horizontal_images = [];
        $vertical_images   = [];

        while ($row = $result->fetch_assoc()) {
            foreach ($row as $key => $imageData) {
                if (!empty($imageData)) {

                    // Actually fix image before displaying
                    $fixedData = fixImageOrientation($imageData);

                    $orientation = classify_orientation_after_exif($fixedData) ?? 'horizontal';
                    $imgString   = base64_encode($fixedData);
                    $caption     = $captions[$key] ?? 'Image';

                    $item = [
                        'data'    => $imgString,
                        'caption' => $caption,
                        'alt'     => $key,
                    ];

                    if ($orientation === 'horizontal') {
                        $horizontal_images[] = $item;
                    } else {
                        $vertical_images[]   = $item;
                    }
                }
            }
        }

 
// Output as a stable 4-column table (works in wkhtmltopdf)
$all_images = array_merge($vertical_images, $horizontal_images);

echo '<table class="image-grid">';
$rows = array_chunk($all_images, 4);
foreach ($rows as $row) {
    echo '<tr>';
    foreach ($row as $img) {
        echo '<td>';
        echo '<div class="img-wrap">';
        echo '<img src="data:image/jpeg;base64,' . $img['data'] . '" alt="' . htmlspecialchars($img['alt']) . '">';
        echo '<div class="caption">' . htmlspecialchars($img['caption']) . '</div>';
        echo '</div>';
        echo '</td>';
    }
    // pad remaining cells to keep 4 columns
    $remaining = 4 - count($row);
    if ($remaining > 0) {
        echo str_repeat('<td></td>', $remaining);
    }
    echo '</tr>';
}
echo '</table>';

    } else {
        echo "<p style='text-align:center;'>No images found.</p>";
    }

    $stmt->close();
} else {
    echo "<p style='text-align:center;'>Reference ID is missing.</p>";
}
?>

        <table>
                <tr>
                    <td>APPLICANT/CO-APPLICANT NAME</td>
                    <td><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data1['customerName'] ?? '') ?>
    </span></td>
                    <td>LAN</td>
                    <td><input type="text" readonly  name="lan" value="<?=$data1['applicationNo']?? '' ?>"></td>
                </tr>
                <tr>
                    <td>ADDRESS DETAILS</td>
                    <td colspan="4"><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data3['address_per_site'] ?? '') ?>
    </span></td>
                </tr>
        </table>
 <table>
 
  <tr>

<div class="google-map-container">
<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "project_db";
$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$reference_id = $_SESSION['reference_id'] ?? null;
$reference_id = $_GET['reference_id'] ?? $reference_id;

if ($reference_id) {
    $sql = "SELECT image5 FROM final_uploaded_images WHERE reference_id = ?";
    $stmt = $conn->prepare($sql);
    if ($stmt === false) {
        die("Error preparing the SQL statement: " . $conn->error);
    }

    $stmt->bind_param("s", $reference_id);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows > 0) {
        $row = $result->fetch_assoc();
        if (!empty($row['image5'])) {
                          echo "<p style='text-align:center;'>Location cum Route map showing property boundaries</p>";

            echo '<div><img src="data:image/jpeg;base64,' . base64_encode($row['image5']) . '" alt="Google Map"><p>Google Map</p></div>';
        } else {
            echo "<p style='text-align:center;'>Google Map image not available.</p>";
        }
    } else {
        echo "<p style='text-align:center;'>No record found for Google Map image.</p>";
    }

    $stmt->close();
} else {
    echo "<p style='text-align:center;'>Reference ID is missing.</p>";
}
?>
</tr>
</div>
    </table>
 
            <table>
            
                <tr>
                    <td>TSR PREPARED BY  </td>
                    <td><input type="text" readonly  value="MAGPIE ENGINEERING PVT. LTD."></td>
                    <td>VISITED BY (NAME)</td>
                    <td><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data1['engineer_id'] ?? '') ?>
    </span></td>
    
                </tr>
                <tr>
                    <td>TSR DATE </td>
                    <td ><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data1['fe_to_coordinator_assign_at'] ?? '') ?>
    </span></td>
                    <td>VISIT DATE </td>
                    <td ><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data1['fe_to_coordinator_assign_at'] ?? '') ?>
    </span></td>
                </tr>
                <tr>
                    <td>SIGN (TA) </td>
                    <td ><input type="text" readonly  value="            "></td>
                    <td>SIGN & STAMP (TM/ATM/RTM) </td>
                    <td ><input type="text" readonly  value="         "></td>
                </tr>
                            </table>
        
                           <!-- Buttons: Hidden during print -->
<div class="no-print">
  <form method="post">
    <input type="hidden" name="download_images" value="1">
    <button type="submit">Download All Images</button>
  </form>

  <button id="downloadPdf" onclick="setPrintMargins()">DOWNLOAD PDF</button>
</div>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jspdf/2.5.1/jspdf.umd.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/html2pdf.js/0.10.1/html2pdf.bundle.min.js"></script>

<script>
  // Function to disable only non-manual inputs
  function disableInputs() {
    document.querySelectorAll('input:not(.manual-input), textarea:not(.manual-input)').forEach(input => {
      input.disabled = true;
    });
  }

  // Function to re-enable all inputs (optional)
  function enableInputs() {
    document.querySelectorAll('input, textarea').forEach(input => input.disabled = false);
  }

  // Auto-resize textareas with class
  function autoResize(el) {
    el.style.height = 'auto';
    el.style.height = el.scrollHeight + 'px';
  }

  document.querySelectorAll('.clean-textarea').forEach(t => autoResize(t));

  // Final PDF download function (html2pdf with disabled inputs logic)
  document.getElementById('downloadPdf').addEventListener('click', () => {
    disableInputs(); // disable non-manual inputs before saving

    const element = document.getElementById('content');
    const options = {
      margin: [0, 0],
      filename: 'report.pdf',
      image: { type: 'jpeg', quality: 0.98 },
      html2canvas: { scale: 2, useCORS: true },
      jsPDF: { unit: 'in', format: 'letter', orientation: 'portrait' }
    };

    html2pdf().set(options).from(element).save().then(() => {
      enableInputs(); // re-enable inputs after save
    });
  });

  // Optional print margin styling
  function setPrintMargins() {
    const style = document.createElement('style');
    style.innerHTML = `
      @media print {
        body {
          margin: 0.5in;
        }
      }
    `;
    document.head.appendChild(style);
    window.print();
  }
</script>

</div>
</body>
</html>