<?php include('auth.php'); ?>
<?php

// Database credentials
$host = 'localhost';
$db = 'project_db';
$user = 'root';
$pass = '';

try {
    $conn = new PDO("mysql:host=$host;dbname=$db", $user, $pass);
    $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (PDOException $e) {
    die("Database connection failed: " . $e->getMessage());
}

// Validate reference_id
if (!isset($_GET['reference_id']) || !isset($_GET['bankName'])) {
    die("Error: Missing reference_id or bankName.");
}

$reference_id = $_GET['reference_id'];
$bankName = trim($_GET['bankName']);

// Store reference_id in session
$_SESSION['reference_id'] = $reference_id;

// Sanitize bank name
$bankName = preg_replace('/[^a-zA-Z0-9_]/', '_', $bankName);
$targetPage = strtolower($bankName) . ".php";

// Redirect to the respective bank page
if (file_exists($targetPage)) {
    header("Location: $targetPage");
    exit();
} else {
    die("Error: Page for '$bankName' not found.");
}