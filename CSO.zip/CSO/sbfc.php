<?php include('auth.php'); ?>
<?php
ini_set('display_errors', 1);
error_reporting(E_ALL);

// Increase PHP execution time and memory limit
ini_set('max_execution_time', 600); // Increase execution time to 600 seconds (10 minutes)
ini_set('memory_limit', '4096M'); // Increase memory limit to 4096MB
// Start session


// Database credentials
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "project_db";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Retrieve reference_id from session
if (!isset($_SESSION['reference_id'])) {
    die("Error: Reference ID not found.");
}

$reference_id = $_SESSION['reference_id'];

// Debugging: Output for verification
echo "Session reference_id: " . htmlspecialchars($reference_id) . "<br>";


$page = isset($_GET['page']) ? $_GET['page'] : 1;
$limit = 50;
$offset = ($page - 1) * $limit;
$sql_property = "SELECT * FROM mis WHERE reference_id = ? LIMIT $limit OFFSET $offset";
$stmt_property = $conn->prepare($sql_property);
$stmt_property->bind_param("s", $reference_id);
$stmt_property->execute();
$result_property = $stmt_property->get_result();
$data1 = $result_property->fetch_assoc();




// Fetch data from property_details table
$sql_property = "SELECT * FROM property_details WHERE reference_id = ?";
$stmt_property = $conn->prepare($sql_property);
$stmt_property->bind_param("s", $reference_id);
$stmt_property->execute();
$result_property = $stmt_property->get_result();
$data2= $result_property->fetch_assoc();




// Fetch data from area_valuation table
$sql_area = "SELECT * FROM address_details WHERE reference_id = ?";
$stmt_area = $conn->prepare($sql_area); 
$stmt_area->bind_param("s", $reference_id);
$stmt_area->execute();
$result_area = $stmt_area->get_result();
$data3 = $result_area->fetch_assoc();





// Fetch data from area_valuation table
$sql_area = "SELECT * FROM critical_parameters WHERE reference_id = ?";
$stmt_area = $conn->prepare($sql_area); 
$stmt_area->bind_param("s", $reference_id);
$stmt_area->execute();
$result_area = $stmt_area->get_result();
$data4 = $result_area->fetch_assoc();

 
// Fetch data from area_valuation table
$sql_area = "SELECT * FROM surroundings_details WHERE reference_id = ?";
$stmt_area = $conn->prepare($sql_area); 
$stmt_area->bind_param("s", $reference_id);
$stmt_area->execute();
$result_area = $stmt_area->get_result();
$data5 = $result_area->fetch_assoc();
$stmt_area->close();
 
// Fetch data from area_valuation table
$sql_area = "SELECT * FROM area_valuation WHERE reference_id = ?";
$stmt_area = $conn->prepare($sql_area); 
$stmt_area->bind_param("s", $reference_id);
$stmt_area->execute();
$result_area = $stmt_area->get_result();
$data6 = $result_area->fetch_assoc();
$stmt_area->close();
 



// Fetch data from area_valuation table
$sql_area = "SELECT * FROM floor_details WHERE reference_id = ?";
$stmt_area = $conn->prepare($sql_area); 
$stmt_area->bind_param("s", $reference_id);
$stmt_area->execute();
$result_area = $stmt_area->get_result();
$data8= $result_area->fetch_assoc();
$stmt_area->close();
 


// Fetch data from area_valuation table
$sql_area = "SELECT * FROM technical_details WHERE reference_id = ?";
$stmt_area = $conn->prepare($sql_area); 
$stmt_area->bind_param("s", $reference_id);
$stmt_area->execute();
$result_area = $stmt_area->get_result();
$data9 = $result_area->fetch_assoc();
$stmt_area->close();
 
// Fetch data from area_valuation table
$sql_area = "SELECT * FROM remarks_table WHERE reference_id = ?";
$stmt_area = $conn->prepare($sql_area); 
$stmt_area->bind_param("s", $reference_id);
$stmt_area->execute();
$result_area = $stmt_area->get_result();
$data10 = $result_area->fetch_assoc();
$stmt_area->close();


// Step 1: Fetch the engineer_id from the mis table
$sql_mis = "SELECT engineer_id FROM mis WHERE reference_id = ?";
$stmt_mis = $conn->prepare($sql_mis);
$stmt_mis->bind_param("s", $reference_id);
$stmt_mis->execute();
$result_mis = $stmt_mis->get_result();
$row_mis = $result_mis->fetch_assoc();
$stmt_mis->close(); 

if ($row_mis) {
    $engineer_id = $row_mis['engineer_id'];

    // Step 2: Fetch the engineer's name from engineer_login table
    $sql_engineer = "SELECT name FROM engineer_login WHERE engineer_id = ?";
    $stmt_engineer = $conn->prepare($sql_engineer);
    $stmt_engineer->bind_param("s", $engineer_id);
    $stmt_engineer->execute();
    $result_engineer = $stmt_engineer->get_result();
    $row_engineer = $result_engineer->fetch_assoc();
    $stmt_engineer->close();

    if ($row_engineer) {
        $engineer_name = $row_engineer['name'];
         //echo "Engineer Name: " . $engineer_name;
    } else {
        echo "Engineer not found.";
    }
} else {
    echo "No engineer assigned for this reference_id.";
}



// Step 1: Fetch the engineer_id from the mis table
$sql_mis = "SELECT report_id FROM mis WHERE reference_id = ?";
$stmt_mis = $conn->prepare($sql_mis);
$stmt_mis->bind_param("s", $reference_id);
$stmt_mis->execute();
$result_mis = $stmt_mis->get_result();
$row_mis = $result_mis->fetch_assoc();
$stmt_mis->close(); 

if ($row_mis) {
    $report_id = $row_mis['report_id'];

    // Step 2: Fetch the engineer's name from engineer_login table
    $sql_engineer = "SELECT name FROM report_login WHERE report_id = ?";
    $stmt_engineer = $conn->prepare($sql_engineer);
    $stmt_engineer->bind_param("s", $report_id);
    $stmt_engineer->execute();
    $result_engineer = $stmt_engineer->get_result();
    $row_engineer = $result_engineer->fetch_assoc();
    $stmt_engineer->close();

    if ($row_engineer) {
        $report_name = $row_engineer['name'];
         //echo "Engineer Name: " . $report_name;
    } else {
        echo "Engineer not found.";
    }
} else {
    echo "No engineer assigned for this reference_id.";
}


// Step 1: Fetch the engineer_id from the mis table
$sql_mis = "SELECT report_drafter_to_technical FROM mis WHERE reference_id = ?";
$stmt_mis = $conn->prepare($sql_mis);
$stmt_mis->bind_param("s", $reference_id);
$stmt_mis->execute();
$result_mis = $stmt_mis->get_result();
$row_mis = $result_mis->fetch_assoc();
$stmt_mis->close(); 

if ($row_mis) {
    $report_drafter_to_technical = $row_mis['report_drafter_to_technical'];

    // Step 2: Fetch the engineer's name from engineer_login table
    $sql_engineer = "SELECT name FROM technical_login WHERE technical_manager_id = ?";
    $stmt_engineer = $conn->prepare($sql_engineer);
    $stmt_engineer->bind_param("s", $report_drafter_to_technical);
    $stmt_engineer->execute();
    $result_engineer = $stmt_engineer->get_result();
    $row_engineer = $result_engineer->fetch_assoc();
    $stmt_engineer->close();

    if ($row_engineer) {
        $technical_name = $row_engineer['name'];
        //echo "Engineer Name: " . $technical_name;
    } else {
        echo "Engineer not found.";
    }
} else {
    echo "No engineer assigned for this reference_id.";
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Valuation Report</title>
    <link rel="shortcut icon" href="favicon.png" type="image/x-icon"> 
    <link rel="stylesheet" href="sbfc.css">
</head>
<body>

    <div class="container">
        <div class="header">
            <img <img src="images/Magpie_logo.jpg" alt="Company Logo">
            <h1>MAGPIE ENGINEERING PVT. LTD.</h1>
            <p>Valuer Designer Architects</p>
            <p>Address : Office no. 201, 2nd floor, Gravity Mall, Mechanic nagar, warehouse road, near vijay nagar, Indore, Madhya Pradesh- 452011</p>
        </div>

        <div class="report-title">
            SMALL BUSINESS FIN CREDIT INDIA PVT. LTD.<br>
            AREA OFFICE INDORE<br>
            VALUATION REPORT BY PANEL VALUER FOR RESALE / LAP / BT
        </div>

        <table class="table-container">
            <tr>
                <td>Serial No.</td>
                <td><input type="text" name="serial_no" value="<?php echo $row['serial_no']; ?>"></td>
            </tr>
            <tr>
                <td>Application No.</td>
                <td><input type="text" name="application_no" value="<?php echo $row['application_no']; ?>"></td>
            </tr>
            <tr>
                <td>Contacted Person for Property Inspection</td>
                <td><input type="text" name="contacted_person" value="<?php echo $row['contacted_person']; ?>"></td>
            </tr>
            <tr>
                <td>Mobile No. of Contacted Person</td>
                <td><input type="text" name="mobile_no" value="<?php echo $row['mobile_no']; ?>"></td>
            </tr>
            <tr>
                <td>Date of Visit</td>
                <td><input type="text" name="date_of_visit" value="<?php echo $row['date_of_visit']; ?>"></td>
            </tr>
            <tr>
                <td>Date of Report</td>
                <td><input type="text" name="date_of_report" value="<?php echo $row['date_of_report']; ?>"></td>
            </tr>
            <tr>
                <td>Type of Case</td>
                <td><input type="text" name="type_of_case" value="<?php echo $row['type_of_case']; ?>"></td>
            </tr>
        </table>
    

    <!-- Repeat for other sections -->
    <table class="table-container">
            <tr>
                <th colspan="2" class="section-title">A. APPLICANT'S DETAIL</th>
            </tr>
            <tr>
                <td>1. Name of the Applicant</td>
                <td><input type="text" name="applicant_name" value="<?php echo htmlspecialchars($row['applicant_name']); ?>" placeholder="Enter Applicant Name"></td>
            </tr>
            <tr>
                <td>2. Property Owner (as per documents shared by SBFC)</td>
                <td><input type="text" name="property_owner" value="<?php echo htmlspecialchars($row['property_owner']); ?>" placeholder="Enter Property Owner"></td>
            </tr>
            <tr>
                <td>3. Name of Document Holder</td>
                <td><input type="text" name="document_holder" value="<?php echo htmlspecialchars($row['document_holder']); ?>" placeholder="Enter Document Holder"></td>
            </tr>
            <tr>
                <td>4. Approved Usage of the Property (Agri / Industrial / Commercial / Residential / Mix)</td>
                <td><input type="text" name="approved_usage" value="<?php echo htmlspecialchars($row['approved_usage']); ?>" placeholder="Enter Approved Usage"></td>
            </tr>
            <tr>
                <td>5. Actual Usage of the Property (Agri / Industrial / Commercial / Residential / Mix)</td>
                <td><input type="text" name="actual_usage" value="<?php echo htmlspecialchars($row['actual_usage']); ?>" placeholder="Enter Actual Usage"></td>
            </tr>
            <tr>
                <td>6. Address of the Property as per Documents</td>
                <td><input type="text" name="document_address" value="<?php echo htmlspecialchars($row['document_address']); ?>" placeholder="Enter Address as per Documents"></td>
            </tr>
            <tr>
                <td>7. Address of the Property as per Site</td>
                <td><input type="text" name="site_address" value="<?php echo htmlspecialchars($row['site_address']); ?>" placeholder="Enter Address as per Site"></td>
            </tr>
            <tr>
                <td>8. Has the Valuer Done Valuation of this Property Before?</td>
                <td><input type="text" name="valuer_done_before" value="<?php echo htmlspecialchars($row['valuer_done_before']); ?>" placeholder="Enter Yes/No"></td>
            </tr>
            <tr>
                <td>9. Property Before this? If Yes, When, for Whom?</td>
                <td><input type="text" name="property_before" value="<?php echo htmlspecialchars($row['property_before']); ?>" placeholder="Enter Details"></td>
            </tr>
        </table>

        <table class="table-container">
        <tr>
            <th colspan="2">B SURROUNDING & LOCALITY DETAILS</th>
        </tr>
        <tr>
            <td>1. Type of Property (Open Plot / Commercial / Residential / Industry / Mix / Under Construction)</td>
            <td><input type="text" name="type_of_property" value="<?php echo htmlspecialchars($row['type_of_property'] ?? ''); ?>"></td>
        </tr>
        <tr>
            <td>2. Class of Locality (Middle Class / Upper Middle Class / Elite Class / Posh Class)</td>
            <td><input type="text" name="class_of_locality" value="<?php echo htmlspecialchars($row['class_of_locality'] ?? ''); ?>"></td>
        </tr>
        <tr>
            <td>3. Site Condition (Developed / Under Developed)</td>
            <td><input type="text" name="site_condition" value="<?php echo htmlspecialchars($row['site_condition'] ?? ''); ?>"></td>
        </tr>
        <tr>
            <td>5. Amenities/Public Transport</td>
            <td><input type="text" name="amenities" value="<?php echo htmlspecialchars($row['amenities'] ?? ''); ?>"></td>
        </tr>
        <tr>
            <td>6. Railway Station / Bus Stop in Kms. (Approx)</td>
            <td><input type="text" name="railway_bus_stop_kms" value="<?php echo htmlspecialchars($row['railway_bus_stop_kms'] ?? ''); ?>"></td>
        </tr>
        <tr>
            <td>8. Close Vicinity / Landmark</td>
            <td><input type="text" name="close_vicinity" value="<?php echo htmlspecialchars($row['close_vicinity'] ?? ''); ?>"></td>
        </tr>
        <tr>
            <td>9. Distance from City Centre in Kms. (Approx)</td>
            <td><input type="text" name="distance_city_centre" value="<?php echo htmlspecialchars($row['distance_city_centre'] ?? ''); ?>"></td>
        </tr>
        <tr>
            <td>10. Condition of width of Approach Road (Good / Bad / Kaccha Road)</td>
            <td><input type="text" name="approach_road_condition" value="<?php echo htmlspecialchars($row['approach_road_condition'] ?? ''); ?>"></td>
        </tr>
    </table>

       
    <form>
    <table class="table-container">
        <tr>
            <th colspan="2">C PROPERTY DETAILS</th>
        </tr>
        <tr>
            <td>1. Vacant / Occupied / Under Construction</td>
            <td><input type="text" name="status" value="<?php echo htmlspecialchars($row['status'] ?? ''); ?>"></td>
        </tr>
        <tr>
            <td>2. Name of Occupant</td>
            <td><input type="text" name="occupant_name" value="<?php echo htmlspecialchars($row['occupant_name'] ?? ''); ?>"></td>
        </tr>
        <tr>
            <td>3. Relation with Applicant</td>
            <td><input type="text" name="relation_with_applicant" value="<?php echo htmlspecialchars($row['relation_with_applicant'] ?? ''); ?>"></td>
        </tr>
        <tr>
            <td>4. Property Demarcation (Yes / No)</td>
            <td><input type="text" name="property_demarcation" value="<?php echo htmlspecialchars($row['property_demarcation'] ?? ''); ?>"></td>
        </tr>
        <tr>
            <td>5. Property Identified through (Neighbour's Inquiry / Four Boundary)</td>
            <td><input type="text" name="property_identification" value="<?php echo htmlspecialchars($row['property_identification'] ?? ''); ?>"></td>
        </tr>
        <tr>
            <td>6. Type of Structure (Rcc / Teen / Load Bearing)</td>
            <td><input type="text" name="structure_type" value="<?php echo htmlspecialchars($row['structure_type'] ?? ''); ?>"></td>
        </tr>
        <tr>
            <td>7. Plot / Land Area in Sqft.</td>
            <td><input type="text" name="land_area" value="<?php echo htmlspecialchars($row['land_area'] ?? ''); ?>"></td>
        </tr>
        <tr>
            <td>10. No. of Floor's</td>
            <td><input type="text" name="number_of_floors" value="<?php echo htmlspecialchars($row['number_of_floors'] ?? ''); ?>"></td>
        </tr>
        <tr>
            <td>13. No. of Room's</td>
            <td><input type="text" name="number_of_rooms" value="<?php echo htmlspecialchars($row['number_of_rooms'] ?? ''); ?>"></td>
        </tr>
        <tr>
            <td>11. No. of Lift's</td>
            <td><input type="text" name="number_of_lifts" value="<?php echo htmlspecialchars($row['number_of_lifts'] ?? ''); ?>"></td>
        </tr>
        <tr>
            <td>14. Super Built - Up in Sqft.</td>
            <td><input type="text" name="super_built_up" value="<?php echo htmlspecialchars($row['super_built_up'] ?? ''); ?>"></td>
        </tr>
        <tr>
            <td>15. Built-up Area in Sqft.</td>
            <td><input type="text" name="built_up_area" value="<?php echo htmlspecialchars($row['built_up_area'] ?? ''); ?>"></td>
        </tr>
        <tr>
            <td>16. Carpet Area in Sqft.</td>
            <td><input type="text" name="carpet_area" value="<?php echo htmlspecialchars($row['carpet_area'] ?? ''); ?>"></td>
        </tr>
        <tr>
            <td>17. Property View Remark</td>
            <td><input type="text" name="property_view_remark" value="<?php echo htmlspecialchars($row['property_view_remark'] ?? ''); ?>"></td>
        </tr>
        <tr>
            <td>18. Exterior (Excellent / Very Good / Good / Average / Poor)</td>
            <td><input type="text" name="exterior_condition" value="<?php echo htmlspecialchars($row['exterior_condition'] ?? ''); ?>"></td>
        </tr>
        <tr>
            <td>19. Interior (Excellent / Very Good / Good / Average / Poor)</td>
            <td><input type="text" name="interior_condition" value="<?php echo htmlspecialchars($row['interior_condition'] ?? ''); ?>"></td>
        </tr>
        <tr>
            <td>20. Current Life in Years</td>
            <td><input type="text" name="current_life" value="<?php echo htmlspecialchars($row['current_life'] ?? ''); ?>"></td>
        </tr>
        <tr>
            <td>21. Residual Life in Years</td>
            <td><input type="text" name="residual_life" value="<?php echo htmlspecialchars($row['residual_life'] ?? ''); ?>"></td>
        </tr>
    </table>
</form>

<form>
    <table class="table-container">
        <tr>
            <th colspan="2">D SANCTIONED PLAN APPROVAL & OTHER DOCUMENTS DETAIL</th>
        </tr>
        <tr>
            <td>1. Sanctioned Plan Verified with approval no.</td>
            <td><input type="text" name="sanctioned_plan_no" value="<?php echo htmlspecialchars($row['sanctioned_plan_no'] ?? ''); ?>"></td>
        </tr>
        <tr>
            <td>2. Ownership Type (Lease Hold / Free Hold)</td>
            <td><input type="text" name="ownership_type" value="<?php echo htmlspecialchars($row['ownership_type'] ?? ''); ?>"></td>
        </tr>
        <tr>
            <td>3. Photocopy of Property Documents Provided (Sale deed / Agreement / Draft deed, Agreement / Sanctioned Map / TCP Layout / Estimate / Prakostha / Electricity Bill / PTR etc.)</td>
            <td><input type="text" name="documents_provided" value="<?php echo htmlspecialchars($row['documents_provided'] ?? ''); ?>"></td>
        </tr>
        <tr>
            <td>4. Is the Property under Municipal Limits (Yes / No)</td>
            <td><input type="text" name="municipal_limits" value="<?php echo htmlspecialchars($row['municipal_limits'] ?? ''); ?>"></td>
        </tr>
    </table>
</form>
<table class="rate-analysis">
        <thead>
            <tr>
                <th colspan="5">RATE ANALYSIS</th>
            </tr>
        </thead>
        <tbody>
            <tr>
                <td rowspan="2">( A ) Description of Constructed Area & Rates.</td>
                <td>Area (In Sqft.)</td>
                <td>Rate (per Sqft.)</td>
                <td>Amount</td>
            </tr>
            <tr>
                <td colspan="3"></td>
            </tr>
            <tr>
                <td>Plot</td>
                <td><?php echo $row['plot_area1']; ?></td>
                <td></td>
                <td></td>
            </tr>
            <tr>
                <td>Carpet area</td>
                <td><?php echo $row['carpet_area1']; ?></td>
                <td></td>
                <td></td>
            </tr>
            <tr>
                <td>Built-up area</td>
                <td><?php echo $row['built_up_area1']; ?></td>
                <td></td>
                <td></td>
            </tr>
            <tr>
                <td>Super Built-up area</td>
                <td><?php echo $row['super_built_up_area1']; ?></td>
                <td></td>
                <td></td>
            </tr>
            <tr>
                <td>Amenities</td>
                <td>0</td>
                <td>0</td>
                <td>0</td>
            </tr>
            <tr>
                <td>Total</td>
                <td></td>
                <td></td>
                <td></td>
            </tr>
            <tr>
                <td>( B ) Value of Extra Amenities if Applicable</td>
                <td colspan="3"></td>
            </tr>
            <tr>
                <td>TOTAL MARKET VALUE OF PROPERTY (A + B)</td>
                <td colspan="3"><?php echo $row['total_market_value1']; ?></td>
            </tr>
            <tr>
                <td>MENTIONED UNIT COST</td>
                <td colspan="3"><?php echo $row['unit_cost1']; ?></td>
            </tr>
            <tr>
                <td>FORCED SALE VALUE @ 90%</td>
                <td colspan="3"><?php echo $row['forced_sale_value1']; ?></td>
            </tr>
            <tr>
                <td>DISTRESS SALE VALUE @ 85%</td>
                <td colspan="3"><?php echo $row['distress_sale_value1']; ?></td>
            </tr>
            <tr>
                <td>Guide Line Value In Sqmt.</td>
                <td colspan="3"><?php echo $row['guide_line_value1']; ?></td>
            </tr>
            <tr>
                <td>Rental Value of the Completed Property @ Rs.</td>
                <td colspan="3"><?php echo $row['rental_value1']; ?></td>
            </tr>
            <tr>
                <td>Stage of construction</td>
                <td>Completed %</td>
                <td>100%</td>
                <td>Recommended %</td>
                <td>100%</td>
            </tr>
        </tbody>
    </table>
</div>

<div class="container">
    <table class="boundaries">
        <thead>
            <tr>
                <th colspan="5">BOUNDARIES OF PROPERTY</th>
            </tr>
        </thead>
        <tbody>
            <tr>
                <td>1</td>
                <td>EAST</td>
                <td>:</td>
                <td><?php echo $row['east_boundary1']; ?></td>
                <td>As per Site</td>
            </tr>
            <tr>
                <td>2</td>
                <td>WEST</td>
                <td>:</td>
                <td><?php echo $row['west_boundary1']; ?></td>
                <td></td>
            </tr>
            <tr>
                <td>3</td>
                <td>NORTH</td>
                <td>:</td>
                <td><?php echo $row['north_boundary1']; ?></td>
                <td></td>
            </tr>
            <tr>
                <td>4</td>
                <td>SOUTH</td>
                <td>:</td>
                <td><?php echo $row['south_boundary1']; ?></td>
                <td></td>
            </tr>
            <tr>
                <td colspan="2">Boundaries Matching</td>
                <td>:</td>
                <td colspan="2"><?php echo $row['boundaries_matching1']; ?></td>
            </tr>
        </tbody>
    </table>
</div>
<div class="container">
<table class="section">
        <thead>
            <tr>
                <th colspan="2">G Remarks</th>
            </tr>
        </thead>
        <tbody>
            <tr>
                <td>
                    <!-- Fetch and display remarks from database -->
                    <p><?php echo htmlspecialchars($row['remarks']); ?></p>
                </td>
            </tr>
        </tbody>
    </table>
    </div>  

    <div class="container">
    <table class="section">
        <thead>
            <tr>
                <th>DISCLAIMER:-</th>
            </tr>
        </thead>
        <tbody>
            <tr>
                <td>
                    <!-- Fetch and display disclaimer from database -->
                    <p><?php echo htmlspecialchars($row['disclaimer']); ?></p>
                </td>
            </tr>
        </tbody>
    </table>
</div>

<div class="container">
    <h2 class="title">Property Photos</h2>
    <div class="grid-container">
        <div class="grid-item">
            <img src="image1.jpg" alt="Property 1">
            <div class="overlay">
                <p>Indore, Madhya Pradesh</p>
                <p>2025-01-27</p>
            </div>
        </div>
        <div class="grid-item">
            <img src="image2.jpg" alt="Property 2">
            <div class="overlay">
                <p>Indore, Madhya Pradesh</p>
                <p>2025-01-27</p>
            </div>
        </div>
        <div class="grid-item">
            <img src="image3.jpg" alt="Property 3">
            <div class="overlay">
                <p>Indore, Madhya Pradesh</p>
                <p>2025-01-27</p>
            </div>
        </div>
        <div class="grid-item">
            <img src="image4.jpg" alt="Property 4">
            <div class="overlay">
                <p>Indore, Madhya Pradesh</p>
                <p>2025-01-27</p>
            </div>
        </div>
            <div class="grid-item">
                <img src="image4.jpg" alt="Property 4">
                <div class="overlay">
                    <p>Indore, Madhya Pradesh</p>
                    <p>2025-01-27</p>
                </div>
            </div>
            <div class="grid-item">
                <img src="image4.jpg" alt="Property 4">
                <div class="overlay">
                    <p>Indore, Madhya Pradesh</p>
                    <p>2025-01-27</p>
                </div>
            </div>
            <div class="grid-item">
                <img src="image4.jpg" alt="Property 4">
                <div class="overlay">
                    <p>Indore, Madhya Pradesh</p>
                    <p>2025-01-27</p>
                </div>
            </div>
            <div class="grid-item">
                <img src="image4.jpg" alt="Property 4">
                <div class="overlay">
                    <p>Indore, Madhya Pradesh</p>
                    <p>2025-01-27</p>
                </div>
            </div>
            <div class="grid-item">
                <img src="image4.jpg" alt="Property 4">
                <div class="overlay">
                    <p>Indore, Madhya Pradesh</p>
                    <p>2025-01-27</p>
                </div>
            </div>
            <div class="grid-item">
                <img src="image4.jpg" alt="Property 4">
                <div class="overlay">
                    <p>Indore, Madhya Pradesh</p>
                    <p>2025-01-27</p>
                </div>
            </div>
            <div class="grid-item">
                <img src="image4.jpg" alt="Property 4">
                <div class="overlay">
                    <p>Indore, Madhya Pradesh</p>
                    <p>2025-01-27</p>
                </div>
            </div>
        </div>
    </div>


</div> 
</body>
</html>
