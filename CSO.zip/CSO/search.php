<?php
// Database connection details
$host = 'localhost';
$db = 'project_db';
$user = 'root';
$pass = '';
$message = "";

try {
    // Create a new PDO instance
    $pdo = new PDO("mysql:host=$host;dbname=$db;charset=utf8", $user, $pass);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

    $results = [];
  
    if ($_SERVER['REQUEST_METHOD'] === 'POST') {
        // Initialize the SQL query for the search functionality
        $query = "SELECT * FROM mis WHERE 1=1";
        $params = [];

        // Add filters only if fields are filled
      
        if (!empty($_POST['reference_id'])) {
            $query .= " AND reference_id LIKE ?";
            $params[] = "%" . $_POST['reference_id'] . "%";
        }
        
        if (!empty($_POST['customerName'])) {
            $query .= " AND customerName LIKE ?";
            $params[] = "%" . $_POST['customerName'] . "%";
        }
        if (!empty($_POST['city'])) {
            $query .= " AND address LIKE ?";
            $params[] = "%" . $_POST['city'] . "%";
        }
        if (!empty($_POST['applicationNo'])) {
            $query .= " AND applicationNo LIKE ?";
            $params[] = "%" . $_POST['applicationNo'] . "%";
        }
        if (!empty($_POST['bankName'])) {
            $query .= " AND bankName LIKE ?";
            $params[] = "%" . $_POST['bankName'] . "%";
        }
        
        if (!empty($_POST['branchname'])) {
          $query .= " AND branchname LIKE ?";
          $params[] = "%" . $_POST['branchname'] . "%";
    }
        if (!empty($_POST['caseType'])) {
            $query .= " AND caseType LIKE ?";
            $params[] = "%" . $_POST['caseType'] . "%";
        }

        // Execute the search query
        $stmt = $pdo->prepare($query);
        $stmt->execute($params);
        $results = $stmt->fetchAll(PDO::FETCH_ASSOC);
    }
   

    // Handle form submission for updating data (if required)
    if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['update']))
    
    {
        $stmt = $pdo->prepare("UPDATE mis SET customerName = ?, address = ?, customerMob = ?, visitType = ?, bankName = ?, branchname= ?,caseType = ?, applicationNo = ?, initiatorMailId = ?, initiationDate = ? WHERE reference_id = ?");
        $stmt->execute([
            $_POST['customerName'],
            $_POST['address'],
            $_POST['customerMob'],
            $_POST['visitType'],
            $_POST['bankName'],
            $_POST['branchname'],
            $_POST['caseType'],
            $_POST['applicationNo'],
            $_POST['initiatorMailId'],
            $_POST['initiationDate'],
            $_POST['reference_id']
        ]);
        $message = "Details updated successfully!";
    }
} catch (PDOException $e) {
  $message = "Error: " . $e->getMessage();
}
?>

<!-- JavaScript for Alert -->
<script>
    <?php if (!empty($message)): ?>
    alert("<?= htmlspecialchars_decode(addslashes($message)) ?>");
    <?php endif; ?>
</script>

<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Magpie Engineering</title>
    <link rel="icon" href="favicon.png" type="image/png">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
    <link rel="stylesheet" href="search01.css">
  </head>

  <th>
    <button class="toggle-btn" id="toggle-btn">☰</button>
    <div class="container">
      <!-- Sidebar -->

      <div class="sidebar" id="sidebar">
        <div style="display: flex">
          <img class="logo" src="logo.png" alt="" />
          <h1>Magpie Engineering</h1>
        </div>
        <div class="rotating-text">Customer Service Officer</div>
        <a href="search.php"class="active"><i class="fas fa-search icon"></i>Search</a>
        <a href="homecso.php"><i class="fas fa-home icon"></i>Home</a>
        <a href="pending.php"><i class="fas fa-clock icon"></i> Pending For Dispatch</a>
        <a href="login.php"><i class="fas fa-sign-out-alt icon"></i>Logout</a>
      </div>

    <!-- Main Content -->
    <div class="content" id="content">
            <div class="search-filters">
                <h2>Search Filters</h2>
                <form id="searchForm" method="POST" action="search.php">
                <div class="form-row">
            <input type="text" name="reference_id" placeholder="Reference ID" />
            <input type="text" name="customerName" placeholder="Customer Name" />
          </div>
          <div class="form-row">
            <input type="text" name="city" placeholder="City" />
            <input type="text" name="applicationNo" placeholder="Application No." />
          </div>
          <div class="form-row">
            <input type="text" name="bankName" placeholder="Bank Name" />
            <input type="text" name="branchname" placeholder="Branch Name" />
            <input type="text" name="caseType" placeholder="Case Type" />
          </div>
                    <button type="submit"style="background: #4A90E2;">Search</button>
                </form>
                </div>
    </div>
    <?php 

       if (!empty($results)): ?>
       <table  id="sortableTable">       <?php         
         echo "<style>
       /* Main Content */
 .content {
  margin: 0; /* Remove conflicting margins */
  padding: 20px;
  animation: fadeIn 1.5s ease-in-out;
  transition: transform 0.3s ease-in-out;
}

table {
  width:75%;
  margin: 0 1% 0 23%; /* Use the same margin in both pages */
  border-collapse: collapse;
  background:rgb(207, 222, 240);
  color: #2C3E50;
  border-radius: 10px;
  overflow: hidden;
  table-layout: fixed; /* Enforce fixed column widths */ 
}
th, td {
  padding: 12px;
  text-align: left;
  border: 1px solid rgba(255, 255, 255, 0.2);
  font-size: 15px;
  word-wrap: break-word; /* Allow wrapping of text */
  white-space: normal; /* Ensure wrapping is allowed */
  min-width: 100px; /* Set a minimum width for columns */
}
th {
  font-size: 13px;
  background-color:rgb(102, 146, 190);
   color:white;
  font-weight: bold;
}
table {
    table-layout: fixed; /* Enforces fixed column widths */
}
th, td {
     /* Adjust as needed for your preferred column width */
    word-wrap: break-word; /* Allows text to wrap onto the next line */
    white-space: normal; /* Ensures wrapping is allowed */
}
 tr:nth-child(even) {
   background-color:rgb(234, 236, 250);
 }

 tr:hover {
   background-color:rgb(138, 177, 215);
   color:white;
   font-weight:bolder;
   font-style:italic;
 }
h2{
  margin-left:48% ; 
   font-style: oblique;
    color:#2C3E50;      
}
 button{
    padding: 5px 10px;
    background-color: #005f8a;
    color: white;
    text-decoration: none;
    border: none;
    border-radius: 5px;
    cursor: pointer;
    font-size: 14px;
}
    @media (max-width: 768px) {

  .content {
    margin-left: 0;
  }

  .search-filters input,
  .search-filters button {
    width: 90%;
  }
}
.content {
  margin-left: 270px; /* Adjust based on sidebar width */
}
@media (min-width: 1200px) {

 @media (max-width: 768px) {
 .toggle-btn {
   display: block;
 }

 .sidebar {
   transform: translateX(-100%);
 }

 .sidebar.visible {
   transform: translateX(0);
 }
.content {
   margin-left: 0;
   margin:0;

 }
  
 .search-filters input,
 .search-filters button {
   width: 90%;
 }
}
@keyframes slideIn {
 from {
   transform: translateX(-100%);
   opacity: 0;
 }

 to {
   transform: translateX(0);
   opacity: 1;
 }
}

@keyframes fadeIn {
 from {
   opacity: 0;
 }

 to {
   opacity: 1;
 }
}
.logo{
 width: 40px;
 height: 40px;
 padding: 15px;
}
  @media (max-width: 768px) {
    .toggle-btn {
      display: block;
    }

    .sidebar {
      transform: translateX(-100%);
    }

    .sidebar.visible {
      transform: translateX(0);
    }

    .content {
      margin-left: 0;

    }

    .search-filters input,
    .search-filters button {
      width: 90%;
    }
  }
   </style>";
   echo "<h2>Customer Information Table</h2>";?>
   <thead>
           <tr>
               <th>Reference Number</th>
               <th>Customer Name</th>
               <th>Address</th>
               <th>Customer Mobile Number</th>
               <th>Visit Type</th>
               <th>Bank Name</th>
               <th>Branch Name</th>
               <th>Case Type</th>
               <th>Application Number</th>
               <th>Mail ID</th>
               <th>Date</th>
           </tr>
    </thead>
           <?php foreach ($results as $row): ?>
        <tr>
        <td><?= htmlspecialchars($row['reference_id']) ?></td>
<td><?= htmlspecialchars($row['customerName']) ?></td>
<td><?= htmlspecialchars($row['address']) ?></td>
<td><?= htmlspecialchars($row['customerMob']) ?></td>
<td><?= htmlspecialchars($row['visitType']) ?></td>
<td><?= htmlspecialchars($row['bankName']) ?></td>
<td><?= htmlspecialchars($row['branchname']) ?></td>
<td><?= htmlspecialchars($row['caseType']) ?></td>
<td><?= htmlspecialchars($row['applicationNo']) ?></td>
<td><?= htmlspecialchars($row['initiatorMailId']) ?></td>
<td><?= htmlspecialchars($row['initiationDate']) ?></td>

        </tr>
        <?php endforeach; ?>
    </table>
<?php else: ?>
    <p>No results found.</p>
<?php endif; ?>


    <script>
      const toggleBtn = document.getElementById("toggle-btn");
      const sidebar = document.getElementById("sidebar");

      // Toggle Sidebar
      toggleBtn.addEventListener("click", () => {
        sidebar.classList.toggle("visible");
      });

      function search() {
        window.location.href = "search.php";
      }
    </script>
     <script>
document.addEventListener("DOMContentLoaded", function () {
    const table = document.getElementById("sortableTable");
    const headers = table.querySelectorAll("th");
    let sortDirection = 1;
    let activeColumn = -1;

    headers.forEach((header, index) => {
        header.addEventListener("click", () => {
            const tbody = table.tBodies[0];
            const rows = Array.from(tbody.querySelectorAll("tr"));
            
            if (activeColumn === index) {
                sortDirection *= -1; // toggle
            } else {
                sortDirection = 1;
            }
            activeColumn = index;

            // Remove sort classes
            headers.forEach(h => h.classList.remove("asc", "desc"));
            header.classList.add(sortDirection === 1 ? "asc" : "desc");

            rows.sort((a, b) => {
                let aText = a.cells[index].textContent.trim();
                let bText = b.cells[index].textContent.trim();

                // Check if date
                if (/\d{4}-\d{2}-\d{2}/.test(aText) && /\d{4}-\d{2}-\d{2}/.test(bText)) {
                    return (new Date(aText) - new Date(bText)) * sortDirection;
                }

                // Check if number
                let aNum = parseFloat(aText.replace(/[^0-9.\-]/g, ""));
                let bNum = parseFloat(bText.replace(/[^0-9.\-]/g, ""));
                if (!isNaN(aNum) && !isNaN(bNum) && aText !== "" && bText !== "") {
                    return (aNum - bNum) * sortDirection;
                }

                // Default string compare
                return aText.localeCompare(bText, undefined, {numeric: true}) * sortDirection;
            });

            rows.forEach(row => tbody.appendChild(row));
        });
    });
});
</script>
  </body>
</html>
