
<?php include('auth.php'); ?>
<?php include 'watermark.html'; ?>

<?php
ini_set('display_errors', 1);
error_reporting(E_ALL);
// Increase PHP execution time and memory limit
ini_set('max_execution_time', 3000); // 300 seconds = 5 minutes
ini_set('memory_limit', '1024M'); // Increase memory limit to 512MB
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "project_db";

// Create DB connection
$conn = new mysqli($servername, $username, $password, $dbname);
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

if (!isset($_SESSION['reference_id'])) {
    die("Reference ID not found in session.");
}
$reference_id = $_SESSION['reference_id'];

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['download_images'])) {

    // Get customer name
    $stmt_name = $conn->prepare("SELECT customerName FROM mis WHERE reference_id = ?");
    $stmt_name->bind_param("s", $reference_id);
    $stmt_name->execute();
    $result_name = $stmt_name->get_result();
    $customerName = "customer";
    if ($row = $result_name->fetch_assoc()) {
        $customerName = preg_replace('/[^a-zA-Z0-9]/', '', $row['customerName']);
    }
    $stmt_name->close();

    // Fetch image BLOBs
    $stmt = $conn->prepare("SELECT image1, image2, image3, image4, image5, image6, image7, image8, image9, image10, image11, image12,image13, image14, image15, image16, image17, image18, image19, image20 FROM final_uploaded_images WHERE reference_id = ?");    $stmt->bind_param("s", $reference_id);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows > 0 && ($row = $result->fetch_assoc())) {
        $tempDir = sys_get_temp_dir() . DIRECTORY_SEPARATOR . uniqid('images_', true);
        mkdir($tempDir);

        $imageFiles = [];
        for ($i = 1; $i <= 12; $i++) {
            if (!empty($row["image$i"])) {
                $filename = $tempDir . DIRECTORY_SEPARATOR . "image{$i}.jpg";
                file_put_contents($filename, $row["image$i"]);
                $imageFiles[] = $filename;
            }
        }

        if (empty($imageFiles)) {
            die("No images to download.");
        }

        // Create ZIP
        $zipFileName = "images_" . preg_replace('/[^a-zA-Z0-9]/', '_', $reference_id) . "_{$customerName}.zip";
        $zipPath = $tempDir . DIRECTORY_SEPARATOR . $zipFileName;

        $zip = new ZipArchive();
        if ($zip->open($zipPath, ZipArchive::CREATE) !== TRUE) {
            die("Failed to create ZIP file.");
        }

        foreach ($imageFiles as $file) {
            $zip->addFile($file, basename($file));
        }
        $zip->close();

        // Send ZIP to browser
        header('Content-Type: application/zip');
        header('Content-Disposition: attachment; filename="' . basename($zipFileName) . '"');
        header('Content-Length: ' . filesize($zipPath));
        flush();
        readfile($zipPath);

        // Cleanup
        foreach ($imageFiles as $file) {
            unlink($file);
        }
        unlink($zipPath);
        rmdir($tempDir);
        exit;
    } else {
        echo "<p style='color:red;'>No image data found for this reference ID.</p>";
    }
}

$page = isset($_GET['page']) ? $_GET['page'] : 1;
$limit = 50;
$offset = ($page - 1) * $limit;
$sql_property = "SELECT * FROM mis WHERE reference_id = ? LIMIT $limit OFFSET $offset";

$stmt_property = $conn->prepare($sql_property);
$stmt_property->bind_param("s", $reference_id);
$stmt_property->execute();
$result_property = $stmt_property->get_result();
$data1 = $result_property->fetch_assoc();




// Fetch data from property_details table
$sql_property = "SELECT * FROM property_details WHERE reference_id = ?";
$stmt_property = $conn->prepare($sql_property);
$stmt_property->bind_param("s", $reference_id);
$stmt_property->execute();
$result_property = $stmt_property->get_result();
$data2= $result_property->fetch_assoc();




// Fetch data from area_valuation table
$sql_area = "SELECT * FROM address_details WHERE reference_id = ?";
$stmt_area = $conn->prepare($sql_area); 
$stmt_area->bind_param("s", $reference_id);
$stmt_area->execute();
$result_area = $stmt_area->get_result();
$data3 = $result_area->fetch_assoc();





// Fetch data from area_valuation table
$sql_area = "SELECT * FROM critical_parameters WHERE reference_id = ?";
$stmt_area = $conn->prepare($sql_area); 
$stmt_area->bind_param("s", $reference_id);
$stmt_area->execute();
$result_area = $stmt_area->get_result();
$data4 = $result_area->fetch_assoc();

 
// Fetch data from area_valuation table
$sql_area = "SELECT * FROM surroundings_details WHERE reference_id = ?";
$stmt_area = $conn->prepare($sql_area); 
$stmt_area->bind_param("s", $reference_id);
$stmt_area->execute();
$result_area = $stmt_area->get_result();
$data5 = $result_area->fetch_assoc();
$stmt_area->close();
 
// Fetch data from area_valuation table
$sql_area = "SELECT * FROM area_valuation WHERE reference_id = ?";
$stmt_area = $conn->prepare($sql_area); 
$stmt_area->bind_param("s", $reference_id);
$stmt_area->execute();
$result_area = $stmt_area->get_result();
$data6 = $result_area->fetch_assoc();
$stmt_area->close();
 



// Fetch data from area_valuation table
$sql_area = "SELECT * FROM floor_details WHERE reference_id = ?";
$stmt_area = $conn->prepare($sql_area); 
$stmt_area->bind_param("s", $reference_id);
$stmt_area->execute();
$result_area = $stmt_area->get_result();
$data8= $result_area->fetch_assoc();
$stmt_area->close();
 


// Fetch data from area_valuation table
$sql_area = "SELECT * FROM technical_details WHERE reference_id = ?";
$stmt_area = $conn->prepare($sql_area); 
$stmt_area->bind_param("s", $reference_id);
$stmt_area->execute();
$result_area = $stmt_area->get_result();
$data9 = $result_area->fetch_assoc();
$stmt_area->close();
 
// Fetch data from area_valuation table
$sql_area = "SELECT * FROM remarks_table WHERE reference_id = ?";
$stmt_area = $conn->prepare($sql_area); 
$stmt_area->bind_param("s", $reference_id);
$stmt_area->execute();
$result_area = $stmt_area->get_result();
$data10 = $result_area->fetch_assoc();
$stmt_area->close();


// Step 1: Fetch the engineer_id from the mis table
$sql_mis = "SELECT engineer_id FROM mis WHERE reference_id = ?";
$stmt_mis = $conn->prepare($sql_mis);
$stmt_mis->bind_param("s", $reference_id);
$stmt_mis->execute();
$result_mis = $stmt_mis->get_result();
$row_mis = $result_mis->fetch_assoc();
$stmt_mis->close(); 

if ($row_mis) {
    $engineer_id = $row_mis['engineer_id'];

    // Step 2: Fetch the engineer's name from engineer_login table
    $sql_engineer = "SELECT name FROM engineer_login WHERE engineer_id = ?";
    $stmt_engineer = $conn->prepare($sql_engineer);
    $stmt_engineer->bind_param("s", $engineer_id);
    $stmt_engineer->execute();
    $result_engineer = $stmt_engineer->get_result();
    $row_engineer = $result_engineer->fetch_assoc();
    $stmt_engineer->close();

    if ($row_engineer) {
        $engineer_name = $row_engineer['name'];
//         //echo "Engineer Name: " . $engineer_name;
    } else {
//        echo "Engineer not found.";
    }
} else {
    echo "No engineer assigned for this reference_id.";
}



// Step 1: Fetch the engineer_id from the mis table
$sql_mis = "SELECT report_id FROM mis WHERE reference_id = ?";
$stmt_mis = $conn->prepare($sql_mis);
$stmt_mis->bind_param("s", $reference_id);
$stmt_mis->execute();
$result_mis = $stmt_mis->get_result();
$row_mis = $result_mis->fetch_assoc();
$stmt_mis->close(); 

if ($row_mis) {
    $report_id = $row_mis['report_id'];

    // Step 2: Fetch the engineer's name from engineer_login table
    $sql_engineer = "SELECT name FROM report_login WHERE report_id = ?";
    $stmt_engineer = $conn->prepare($sql_engineer);
    $stmt_engineer->bind_param("s", $report_id);
    $stmt_engineer->execute();
    $result_engineer = $stmt_engineer->get_result();
    $row_engineer = $result_engineer->fetch_assoc();
    $stmt_engineer->close();

    if ($row_engineer) {
        $report_name = $row_engineer['name'];
 //        //echo "Engineer Name: " . $report_name;
    } else {
 //       echo "Engineer not found.";
    }
} else {
    echo "No engineer assigned for this reference_id.";
}


// Step 1: Fetch the engineer_id from the mis table
$sql_mis = "SELECT report_drafter_to_technical FROM mis WHERE reference_id = ?";
$stmt_mis = $conn->prepare($sql_mis);
$stmt_mis->bind_param("s", $reference_id);
$stmt_mis->execute();
$result_mis = $stmt_mis->get_result();
$row_mis = $result_mis->fetch_assoc();
$stmt_mis->close(); 

if ($row_mis) {
    $report_drafter_to_technical = $row_mis['report_drafter_to_technical'];

    // Step 2: Fetch the engineer's name from engineer_login table
    $sql_engineer = "SELECT name FROM technical_login WHERE technical_manager_id = ?";
    $stmt_engineer = $conn->prepare($sql_engineer);
    $stmt_engineer->bind_param("s", $report_drafter_to_technical);
    $stmt_engineer->execute();
    $result_engineer = $stmt_engineer->get_result();
    $row_engineer = $result_engineer->fetch_assoc();
    $stmt_engineer->close();

    if ($row_engineer) {
        $technical_name = $row_engineer['name'];
   //     //echo "Engineer Name: " . $technical_name;
    } else {
   //     echo "Engineer not found.";
    }
} else {
    echo "No engineer assigned for this reference_id.";
}


?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <style>
                                                 
.container {
            width: 90%;
            margin: 20px auto;
            border: 1px solid black;
            padding: 20px;
        }
.header-content {
    text-align: center;
    flex: 1;
}

.header-content h1 {
    margin: 0;
    margin-top:25px;  
    font-size: 38px;
    color: #902d2d;
}

.header-content p {
    margin: 2px 0;
    font-size: 26px;
    color: #333;
}
.footer{
    display: flex;
}
h3{
    background-color:rgb(243, 234, 222) ;
    padding:5px;
    text-align: center;
    border:1px solid black;
}   
                 body {
      font-family: Arial, sans-serif;
      font-size: 13px;
    }
    table {
      width: 100%;
      border-collapse: collapse;
    }
    th, td {
      border: 1px solid #000;
      padding: 4px;
      vertical-align: top;
    }
    th {
      background-color: #f0f0f0;
      text-align: center;
    }
    .heading {
      text-align: center;
      font-weight: bold;
      font-size: 16px;
      border: none;
    } 
         
    </style>
    <style>
.container {
    max-width: 1200px;
    margin: 20px auto;
    padding: 20px;
    background-color: white;
    box-shadow: 0px 0px 10px rgba(0, 0, 0, 0.1);
    border-radius: 8px;
}

.title {
    text-align: center;
    font-size: 24px;
    font-weight: bold;
    margin-bottom: 20px;
}
.grid-container {
    display: grid;
    grid-template-columns: repeat(4, 1fr);
    gap: 15px;
}

.grid-item {
    position: relative;
    border-radius: 8px;
    overflow: hidden;
    box-shadow: 0px 4px 6px rgba(0, 0, 0, 0.1);
}

.grid-item img {
    width: 100%;
    height: 200px;
    object-fit: cover;
    transition: transform 0.3s ease;
}
.grid-item:hover img {
    transform: scale(1.05);
}

.overlay {
    position: absolute;
    bottom: 0;
    left: 0;
    background: rgba(0, 0, 0, 0.6);
    color: white;
    width: 100%;
    padding: 8px;
    font-size: 14px;
    text-align: center;
}
 
   
/* Force a stable 4-column grid that wkhtmltopdf respects */
.image-gallery { width: 100%; }
.image-grid { width: 100%; border-collapse: collapse; table-layout: fixed; }
.image-grid tr { page-break-inside: avoid; }
.image-grid td { width: 25%; padding: 6px; vertical-align: top; }

.image-grid .img-wrap { display: block; }
.image-grid img { display: block; width: 100%; height: auto; }
.image-grid .caption { font-size: 12px; text-align: center; margin-top: 4px; }

/* If you had a flex layout before, neutralize it */
.image-gallery { display: block !important; }



    /* Print-specific rules */
    @media print {
      .no-print {
        display: none !important;
      }

      body {
        margin: 0;
      }
 
    }
  button{
    padding:8px;
    margin-left:45%;
    background-color:#808485;
    color:white;
    font-weight:700;
    font-style:italic;
  }
  button:hover{
    background-color:rgba(216,216,216,255);
    color:white;
  }

 
/* Optional: Google map styling */
    .google-map-container {
      max-width: 90%;
      margin: 20px auto;
      border: 2px solid #ccc;
      padding: 10px;
      box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
      background-color: #f9f9f9;
      border-radius: 8px;
      text-align: center;
    }

    .google-map-container img {
      max-width: 100%;
      height: auto;
      display: inline-block;
      border: 1px solid #999;
      border-radius: 4px;
    }
    
    
.logo img {
  width: 120px;
  margin-left:30px;
  height: auto;
}
</style>
</head>
<body>
    <div class="container">
        <header>
            <div class="footer">
            <div class="logo">
               <img src="images/logo.png" alt="Magpie Logo">
            </div>
            <div class="header-content">
                <h1>MAGPIE ENGINEERING PVT. LTD.</h1>
                <p>Valuer Designer Architects</p>
                <p>Office no. 201, 2nd floor, Gravity Mall, Mechanic nagar, warehouse road, near vijay nagar, Indore, Madhya Pradesh- 452011</p>
            </div>
            </div>
        </header>
       
<div class="heading"><b>VALUATION REPORT (Credit Saison)</b></div>

<table>
<tr>
    <td><b>Ref No.</b></td>
    <td colspan=3><b><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data1['reference_id'] ?? '') ?></span></b></td>
  </tr>
  <tr>
    <td> LOS NO.</td>
    <td colspan=""><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data1['applicationNo'] ?? '') ?></span></td>
    <td class="wide-label"> Dated: </td>
    <td colspan="7"><span style="display: inline-block; min-width: 50px; padding: 2px;">
 <?= htmlspecialchars(date('d M Y h:i A', strtotime($data1['report_assigned_at'] ?? ''))) ?></span></td>
  </tr>
  <tr>
    <td colspan="">Valuer Name, Contact Details, Email ID & Code:</td>
        <td colspan="3"><span style="display: inline-block; min-width: 50px; padding: 2px;">MAGPIE ENGINEERING PVT.LTD.  indoresaa@gmail.com</span></td>
  </tr>
  <tr>
    <td colspan="">Branch Name or DSA Name: </td>
    <td colspan="7"><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data1['bank_branchname'] ?? '') ?></span></td>
  </tr>
</table>

<br>

<table>
  <tr>
    <th colspan="7">GENERAL DETAILS:</th>
  </tr>
  <tr>
    <td class="small-cell">1</td>
    <td colspan="3">Purpose of Valuation: </td>
        <td colspan="3"><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data1['caseType'] ?? '') ?></span></td>
  </tr>
  <tr>
    <td class="small-cell">2</td>
    <td colspan="3">Date on which Valuation is done: </td>
    <td colspan="3"><span style="display: inline-block; min-width: 50px; padding: 2px;">
 <?= htmlspecialchars(date('d M Y h:i A', strtotime($data1['report_assigned_at'] ?? ''))) ?></span></td>
  </tr>
  <tr>
    <td class="small-cell" rowspan="2">3</td>
    <td  rowspan="2">Name of the applicant / Property Owner</td>
    <td colspan="2"><b>Name of the applicant:</b></td>
    <td colspan="2"><b>As per Ownership Document: </b></td>
    <td><b>As per Physical Visit:</b></td>
  </tr>
  <tr>
  
    <td colspan="2"><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data1['customerName'] ?? '') ?></span></td>
    <td colspan="2"><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data9['owner_name'] ?? '') ?></span></td>
   <td><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data9['seller_name'] ?? '') ?></span></td>
  </tr>
  <tr>
    <td class="small-cell">4</td>
    <td colspan="3">Person Name & Contact No. available During Visit:</td>
    <td colspan="4"><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data2['person_meet_at_site_contact'] ?? '') ?></span></td>

  </tr>
  <tr>
    <td class="small-cell">5</td>
    <td colspan="" class="section-label">Particulars</td>
    <td colspan="2"><b>As per ownership Document</b></td>
    <td colspan="2"><b>As per Approved plans & Permission</b></td>
    <td colspan="2"><b>As per Physical visit</b></td>
  </tr>
  <tr>
    <td class="small-cell">5.a</td>
    <td colspan="">Property Address Description </td>
    <td colspan="2"><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
   <?= htmlspecialchars($data3['address_per_document'] ?? '') ?></span></td>
    <td colspan="2"><span style="display: inline-block; min-width: 50px; padding: 2px;">
    <?= htmlspecialchars($data10['NA'] ?? '') ?></span></td>
    
    <td colspan="2"><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
    <?= htmlspecialchars($data3['address_per_site'] ?? '') ?>
    </span></td>
  </tr>
  <tr>
    <td class="small-cell">5.b</td>
    <td colspan="">Plot No. & Sub Plot No.</td>
        <td colspan="2"><span style="display: inline-block; min-width: 50px; padding: 2px;">
    <?= htmlspecialchars($data3['address_line_1_as_per_doc'] ?? '') ?></span></td>
        <td colspan="2"><span style="display: inline-block; min-width: 50px; padding: 2px;">
    <?= htmlspecialchars($data10['NA'] ?? '') ?></span></td>
        <td colspan="2"><span style="display: inline-block; min-width: 50px; padding: 2px;">
    <?= htmlspecialchars($data3['address_line_1_as_per_doc'] ?? '') ?></span></td>
  </tr>
  <tr>
    <td class="small-cell">5.c</td>
    <td colspan="">CTS Nos/S.Nos/Gat Nos./Hissa Nos/Khasra</td>
    <td colspan="2"><span style="display: inline-block; min-width: 50px; padding: 2px;">
    <?= htmlspecialchars($data3['khasra_no'] ?? '') ?></span></td>
    <td colspan="2"><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data10['NA'] ?? '') ?></span></td>
    <td colspan="2"><span style="display: inline-block; min-width: 50px; padding: 2px;">
    <?= htmlspecialchars($data3['khasra_no'] ?? '') ?></span></td>
  </tr>
  <tr>
    <td class="small-cell">5.d</td>
    <td colspan="">Village/ Town/ Location</td>
    <td colspan="2"><span style="display: inline-block; min-width: 50px; padding: 2px;">
    <?= htmlspecialchars($data3['village_name'] ?? '') ?></span></td>
    <td colspan="2"><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data10['NA'] ?? '') ?></span></td>
    <td colspan="2"><span style="display: inline-block; min-width: 50px; padding: 2px;">
    <?= htmlspecialchars($data3['village_name'] ?? '') ?></span></td>
  </tr>
  <tr>
    <td class="small-cell">5.e</td>
    <td colspan="">Taluka</td>
    <td colspan="2"><span style="display: inline-block; min-width: 50px; padding: 2px;">    <?= htmlspecialchars($data3['taluka_tehsil'] ?? '') ?></span></td>

    <td colspan="2"><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data10['NA'] ?? '') ?></span></td>
    <td colspan="2"><span style="display: inline-block; min-width: 50px; padding: 2px;">    <?= htmlspecialchars($data3['taluka_tehsil'] ?? '') ?></span></td>

  </tr>
  <tr>
    <td class="small-cell">5.f</td>
        <td colspan="">District</td>
    <td colspan="2"><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data3['address_line_3_as_per_doc'] ?? '') ?></span></td>
    <td colspan="2"><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data10['NA'] ?? '') ?></span></td>
    <td colspan="2"><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data3['address_line_3_as_per_doc'] ?? '') ?></span></td>
  </tr>
  <tr>
    <td class="small-cell">5.g</td>
    <td colspan="">State</td>
    <td colspan="2"><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data3['address_line_4_as_per_doc'] ?? '') ?></span></td>
    <td colspan="2"><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data10['NA'] ?? '') ?></span></td>
    <td colspan="2"><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data3['address_line_4_as_per_doc'] ?? '') ?></span></td>
  </tr>
  <tr>
    <td class="small-cell">5.h</td>
    <td colspan="">Pin Code </td>
    <td colspan="2"><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data3['pin_code'] ??'') ?></span></td>
    <td colspan="2"><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data10['NA']??'') ?></span></td>
    <td colspan="2"><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data3['pin_code']??'') ?></span></td>
  </tr>
  <tr>
    <td class="small-cell" rowspan="2">5.i</td>
    <td colspan="" rowspan="2"> GPS Coordinates: </td>
    <td colspan=""> <b>LATITUDE :</b> </td>
    <td colspan="4"><span style="display: inline-block; min-width: 50px; padding: 2px;"><?= htmlspecialchars($data3['latitude_value'] ?? '') ?></span></td>
  </tr>
  <TR>
     <td colspan=""> <b>LONGITUDE:</b> </td>
    <td colspan="4"><span style="display: inline-block; min-width: 50px; padding: 2px;"><?= htmlspecialchars($data3['longitude_value'] ?? '') ?></span></td>
  </TR>
  <tr>
    <td class="small-cell">5.j</td>
    <td colspan="">Nearest Landmark: </td>
    <td colspan="5"><span style="display: inline-block; min-width: 50px; padding: 2px;"><?= htmlspecialchars($data3['landmark_1'] ?? '') ?> <?= htmlspecialchars($data3['landmark_2'] ?? '') ?></span></td>
  </tr>
  <tr>
    <td class="small-cell">5.k</td>
    <td colspan="">Name on the Society Name Board:</td>
    <td colspan="5"><span style="display: inline-block; min-width: 50px; padding: 2px;"><?= htmlspecialchars($data4['board_on_house'] ?? '') ?></span></td>
  </tr>
  <tr>
    <td class="small-cell">5.l</td>
    <td colspan="">Property Door/Entrance Name & Owner Confirmation:</td>
    <td colspan="5"><span style="display: inline-block; min-width: 50px; padding: 2px;"><?= htmlspecialchars($data10['NA'] ?? '') ?></span></td>
  </tr>
   <tr>
    <td class="small-cell">5.M</td>
    <td colspan=""> Name,Address and contact No. of the Neighbour/Treasurer/Secretary/Chairman who confirmed the Property owners Name & Existence : </td>
    <td colspan="5"><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data10['NA'] ?? '') ?></span></td>
  </tr>
  <tr>
    <td class="small-cell">6</td>
    <td colspan="" class="section-label"><b>Particulars</b></td>
    <td colspan="3"><b>Name</b></td>
    <td colspan="3"><b>Distance</b></td>
  </tr>
  <tr>
    <td class="small-cell">6.a</td>
    <TD> Nearest Government offices from property </TD>
    <td colspan="3"><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data3['nearest_post_office_name'] ?? '') ?></span></td>
    <td colspan="3"><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data3['nearest_post_office_distance'] ?? '') ?></span></td>
  </tr>
  <tr>
    <td class="small-cell">6.b</td>
    <TD> Nearest Railway Station from property </TD>
    <td colspan="3"><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data3['nearest_railway_station_name'] ?? '') ?></span></td>
    <td colspan="3"><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data3['nearest_railway_station_distance'] ?? '') ?></span></td>
  </tr>
  <tr>
    <td class="small-cell">6.c</td>
    <td>Nearest Bus Station from property</td>
    <td colspan="3"><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data3['nearest_bus_stop_name'] ?? '') ?></span></td>
    <td colspan="3"><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data3['nearest_bus_stop_distance'] ?? '') ?></span></td>
  </tr>
  <tr>
    <td class="small-cell">6.d</td>
    <td> Nearest Airport Station from property</td>
    <td colspan="3"><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data3['nearest_airport_name'] ?? '') ?></span></td>
    <td colspan="3"><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data3['nearest_airport_distance'] ?? '') ?></span></td>
  </tr>
  <tr>
    <td class="small-cell">6.e</td>
      <td> Nearest National Highway from property </td>
    <td colspan="3"><span style="display: inline-block; min-width: 50px; padding: 2px;">
       <?= htmlspecialchars($data3['nearest_national_highway_name'] ?? '') ?></span></td>
    <td colspan="3"><span style="display: inline-block; min-width: 50px; padding: 2px;">
       <?= htmlspecialchars($data3['nearest_national_highway_distance'] ?? '') ?></span></td>
  </tr>
  <tr>
    <td class="small-cell">6.f</td>
    <td>  Community centers like Hotels,Restaurants,Theaters, Auditoriums,Clubs, Lakes,Ponds etc Approximate Distance from Property </td>
    <td colspan="3"><span style="display: inline-block; min-width: 50px; padding: 2px;">
        </span></td>
        <td colspan="3"><span style="display: inline-block; min-width: 50px; padding: 2px;">
       <?= htmlspecialchars($data3['nearest_bus_stop_distance'] ?? '') ?></span></td>
   
  </tr>
  <tr>
    <td class="small-cell">6.g</td>
    <td>  School, College Hospital, Market etc Approximate Distance from Property </td>
    <td colspan="3"><span style="display: inline-block; min-width: 50px; padding: 2px;"><?= htmlspecialchars($data3 ['nearest_school_college_name'] ?? '') ?></span></td>
   <td colspan="3"><span style="display: inline-block; min-width: 50px; padding: 2px;">
       <?= htmlspecialchars($data3['nearest_bus_stop_distance'] ?? '') ?></span></td>
  </tr>

</table>
<table border="1" cellspacing="0" cellpadding="6" style="width: 100%; border-collapse: collapse; font-family: Arial, sans-serif; font-size: 14px;">
  <!-- DOCUMENT DETAILS -->
    <tr style="background-color: #f2f2f2; font-weight: bold;">
    <tr><th colspan="60" class="section-header">DOCUMENT DETAILS:</th></tr>
  </tr>
  <tr>
    <td rowspan="">7</td>
    <td><b>Particulars</b></td>
    <td><b>Date</b></td>
    <td><b>No.</b></td>
    <td colspan="2"><b>Registrar office/ Competent Authority/ Owner Name</b></td>
  </tr>
  <tr>
    <td>7.a</td>
    <td> <span> Ownership Documents- Sale deed , Memorandum of Deposit of Title Deed, Agreement to sale, Gift Deed, Draft Co-Ownership Agreement</span></td>
    <td><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data9['ownership1_date'] ?? '') ?></span></td>
    <td><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data9['ownership1_no'] ?? '') ?></span></td>
    <td colspan="2"><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data9['ownership1_details'] ?? '') ?></span></td>
  </tr>
  <tr>
    <td>7.b</td>
    <td><span> Mutation Certificate </span></td>
    <td><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data9['ownership2_date'] ?? '') ?></span></td>
    <td><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data9['ownership2_no'] ?? '') ?></span></td>
    <td colspan="2"><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data9['ownership2_details'] ?? '') ?></span></td>
  </tr>
  <tr>
    <td>7.c </td>
    <td><span> Property Tax Receipt </span></td>
    <td><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data9['ownership3_date'] ?? '') ?></span></td>
    <td><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data9['ownership3_no'] ?? '') ?></span></td>
    <td colspan="2"><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data9['ownership3_details'] ?? '') ?></span></td>
  </tr>
  <tr>
    <td>7.d</td>
    <td><span>Commencement Certificate/ Construction Permission/ Building Permission</span></td>
    <td><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data9['ownership4_date'] ?? '') ?></span></td>
    <td><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data9['ownership4_no'] ?? '') ?></span></td>
    <td colspan="2"><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data9['ownership4_details'] ?? '') ?></span></td>

  </tr>
  <tr>
    <td colspan="6" style="background-color: #f9f9f9;"><b> SANCTIONED PLANS </b></td>
  </tr>
  <tr>
    <td rowspan="2">7.e</td>
    <td> <span> Building Plan </span></td>
    <td><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data9['sanction_approval_date'] ?? '') ?></span></td>
    <td><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data9['sanction_approval_no'] ?? '') ?></span></td>
    <td colspan="2"><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data9['sanction_approving_authority'] ?? '') ?></span></td>
  </tr>
  <tr>
    <td><span>Layout Plan</span></td>
   <td><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data9['layout_approval_date'] ?? '') ?></span></td>
    <td><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data9['layout_approval_details'] ?? '') ?></span></td>
    <td colspan="2"><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data9['layout_approving_authority'] ?? '') ?></span></td>
  </tr>
  <tr>
    <td>7.f</td>
    <td> <span>Occupancy Certificate/ Completion</span></td>
    <td><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars('Not Provided') ?></span></td>
    <td><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars('Not Provided') ?></span></td>
    <td colspan="2"><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars('Not Provided') ?></span></td>
  </tr>
  <tr>
    <td>7.g</td>
    <td> <span>Regularisation Certificate / Order</span></td>
    <td><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars('Not Provided') ?></span></td>
    <td><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars('Not Provided') ?></span></td>
    <td colspan="2"><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars('Not Provided') ?></span></td>
  </tr>
  <tr>
    <td>7.h</td>
    <td> <span>Share Certificate</span></td>
    <td><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars('Not Provided') ?></span></td>
    <td><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars('Not Provided') ?></span></td>
    <td colspan="2"><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars('Not Provided') ?></span></td>
  </tr>
  <tr>
    <td>7.i</td>
    <td> <span>Latest Property Tax Paid Bill</span></td>
    <td><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars('Not Provided') ?></span></td>
    <td><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars('Not Provided') ?></span></td>
    <td colspan="2"><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars('Not Provided') ?></span></td>
  </tr>
</table><table>
  <!-- BOUNDARIES -->
  <tr style="background-color: #f2f2f2; font-weight: bold;">
     <tr><th colspan="6" class="section-header">BOUNDARIES::</th></tr>

  </tr>
  <tr>
    <td rowspan="">8</td>
    <td style="width:20px;"><b>Direction</b></td>
    <td><b>As per Ownership Documents</b></td>
    <td><b>As per Approved Plans</b></td>
    <td colspan="2"><b>As per Site</b></td>
  </tr>
  <tr>
    <td>8.a</td>
    <td> <span>East</span></td>
    <td><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data3['direction_as_per_document_east'] ?? '') ?></span></td>
    <td><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data10['NA'] ?? '') ?></span></td>
    <td colspan="2"><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data3['direction_as_per_site_east'] ?? '') ?></span></td>
  </tr>
  <tr>
    <td>8.b</td>
    <td> <span>West</span></td>
    <td><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data3['direction_as_per_document_west'] ?? '') ?></span></td>
    <td><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data10['NA'] ?? '') ?></span></td>
    <td colspan="2"><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data3['direction_as_per_site_west'] ?? '') ?></span></td>
  </tr>
  <tr>
    <td>8.c</td>
    <td> <span>North</span></td>
    <td><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data3['direction_as_per_document_north'] ?? '') ?></span></td>
    <td><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data10['NA'] ?? '') ?></span></td>
    <td colspan="2"><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data3['direction_as_per_site_north'] ?? '') ?></span></td>
  </tr>
  <tr>
    <td>8.d</td>
    <td> <span>South</span></td>
    <td><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data3['direction_as_per_document_south'] ?? '') ?></span></td>
    <td><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data10['NA'] ?? '') ?></span></td>
    <td colspan="2"><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data3['direction_as_per_site_south'] ?? '') ?></span></td>
  </tr>
</table>
<table>
  <!-- TECHNICAL DETAILS -->
  <tr style="background-color: #f2f2f2; font-weight: bold;">
      <tr><th colspan="6" class="section-header">TECHNICAL DETAILS:</th></tr>

  </tr>
  <tr>
    <td rowspan="">9</td>
    <td colspan="5" style="font-weight: bold;">  LAND/PLOT - (Applicable in Plot + Construction cases only)</td>
  </tr>
  <tr>
    <td>9.a</td>
    <td> <span><b>Particulars</span></b></td>
    <td><b>As per ownership Document</b></td>
    <td><b>As per approved plans & Permission</b></td>
    <td colspan="2"><b>As per Physical visit</b></td>
  </tr>
  <tr>
    <td>9.a.1</td>
    <td> <span>Area of Land / Plot</span></td>
    <td><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data6['plot_square_feet'] ?? '') ?></span></td>
    <td><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data6['replacement_cost'] ?? '') ?></span></td>
    <td colspan="2"><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data6['actual_plot_square_feet'] ?? '') ?></span></td>
  </tr>
  <tr>
    <td>9.a.2</td>
    <td> <span>Plot Usage</span></td>
    <td><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data4['approved_property_usage'] ?? '') ?></span></td>
    <td><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data10['NA'] ?? '') ?></span></td>
    <td colspan="2"><span style="display: inline-block; min-width: 50px; padding: 2px;">
      <?= htmlspecialchars($data4['current_property_usage'] ?? '') ?></span></td>
  </tr>
  <tr>
    <td>9.a.3</td>
    <td> <span>Details of Access</span></td>
    <td><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data2['project_approval_status'] ?? '') ?></span></td>
     <td> <span><b>Road width</b></span></td>
    <td colspan="2"><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data2['width_of_approach_road'] ?? '') ?></span></td>
  </tr>
  <tr>
    <td>9.a.4</td>
    <td> <span>Margin Area/ Set Backs (sqft)</span></td>
    <td><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars( '0') ?></span></td>
    <td><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars( '0') ?></span></td>
    <td colspan="2"><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars( '0') ?></span></td>
  </tr>
  <tr>
    <td>9.a.5</td>
    <td> <span>Can Plot Demarcated/ Identified on site</span></td>
    <td colspan="4"><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data2['demarcated_at_site'] ?? '') ?></span></td>
   </tr>
  <tr>
    <td>9.a.6</td>
    <td> <span>Ownership</span></td>
    <td colspan="4"><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data9['list_documents'] ?? '') ?></span></td>
  </tr>
  <tr>
    <td rowspan="5">9.a.7</td>
    <td><span>If tenant</span></td>
    <td colspan="4"><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data2['project_id'] ?? '') ?></span></td>
  </tr>
  <tr>
   <td>1 <span>Name of Owner</span></td>
    <td colspan="4"><span style=" display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data9['owner_name'] ?? '') ?></span></td>
  </tr>
  <tr>
    <td>2 <span>Name of Tenant</span></td>
    <td colspan="4"><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data2['name_of_tenant'] ?? '') ?></span></td>
  </tr>
  <tr>
    <td>3 <span>Rent Agreement/Lease deed details (Date & No.)</span></td>
    <td colspan="4"><span style="display: inline-block; min-width: 50px; padding: 2px;">      
        <?= htmlspecialchars($data9['lease_approving_authority'] ?? '') ?>, <?= htmlspecialchars($data9['lease_approval_date'] ?? '') ?>, <?= htmlspecialchars($data9['lease_approval_details'] ?? '') ?></span></td>
  </tr>
  <tr>
    <td>4 <span>Occupation age from Day1</span></td>
    <td><span>From</span></td>
    <td><span style="display: inline-block; min-width: 50px; padding: 2px;"><?= htmlspecialchars($data2['year_of_construction'] ?? '') ?></span></td>
    <td><span>To</span></td>
    <td><span style="display: inline-block; min-width: 50px; padding: 2px;"><?= htmlspecialchars('TILL NOW') ?></span></td>
  </tr>
  <tr>
    <td>9.a.8</td>
    <td> <span>Present Occupancy</span></td>
    <td colspan="4"><span style="display: inline-block; min-width: 50px; padding: 2px;"><?= htmlspecialchars($data2['occupancy_status'] ?? '') ?></span></td>
  </tr>
  <tr>
    <Td>9.a.9</Td>
    <td> <span>Land /Plot Area Considered for Valuation</span></td>
    <td colspan="4"><span style="display: inline-block; min-width: 50px; padding: 2px;"><?= htmlspecialchars($data6['final_plot_square_feet'] ?? '') ?></span></td>
  </tr>
  <tr>
    <td>9.a.10</td>
    <td> <span>Agreement Value</span></td>
    <td colspan="4"><span style="display: inline-block; min-width: 50px; padding: 2px;"><?= htmlspecialchars($data10['NA'] ?? '') ?></span></td>
  </tr>
  <tr>
    <td>9.a.11</td>
    <td> <span>Government Guideline Rate(Rs./sqft)</span></td>
    <td colspan="4"><span style="display: inline-block; min-width: 50px; padding: 2px;"><?= htmlspecialchars($data6['guideline_rate'] ?? '') ?></span></td>
  </tr>
  <tr>
    <td>9.a.12</td>
    <td> <span>Prevailing Market Rate Range(Rs./sqft)</span></td>
    <td colspan=""><span>From</span></td>
    <td colspan=""><span style="display: inline-block; min-width: 50px; padding: 2px;"><?= htmlspecialchars($data6['estimated_cost_rs'] ?? '') ?></span></td>
    <td colspan=""><span>To</span></td>
    <td colspan=""><span style="display: inline-block; min-width: 50px; padding: 2px;"><?= htmlspecialchars($data6['estimated_cost_per_sqft'] ?? '') ?></span></td>
  </tr>
  <tr>
    <td>9.a.13 </td>
    <td><span>Rate Adopted for Valuation</span></td>
    <td colspan="4"><span style="display: inline-block; min-width: 50px; padding: 2px;"><?= htmlspecialchars($data6['final_plot_rate'] ?? '') ?></span></td>
  </tr>
  <tr>
     <td>9.a.14</td>
    <td> <span>Fair Market Value/ Realisable Value</span></td>
    <td colspan="4"><span style="display: inline-block; min-width: 50px; padding: 2px;"><?= htmlspecialchars($data6['finally_plot_valuation'] ?? '') ?></span></td>
  </tr>
</table>

<table>
  <tr><th colspan="6" class="section-header">9.b CONSTRUCTION / APARTMENTS</th></tr>

  <tr>
    <td>9.b.1</td>
    <td colspan="1">Property</td> <td colspan="3"><span style="display: inline-block; min-width: 50px; padding: 2px;"><?= htmlspecialchars($data2['NA'] ?? '') ?></span></td>
  </tr>

  <tr>
    <td>9.b.2</td>
    <td><b>Particulars</b></td>
    <td><b>As per Ownership Document</b></td>
    <td><b>As per Approved Plans &amp; Permission</b></td>
    <td colspan="2"><b>As per Physical Visit</b></td>
  </tr>
  
  <tr>
    <td>9.b.3</td>
    <td> Usage </td>
    <td><span style="display: inline-block; min-width: 50px; padding: 2px;">
      <?= htmlspecialchars($data4['approved_property_usage'] ?? '') ?></span></td>
    <td><span style="display: inline-block; min-width: 50px; padding: 2px;">
      <?= htmlspecialchars($data10['NA'] ?? '') ?></span></td>
    <td colspan="2"><span style="display: inline-block; min-width: 50px; padding: 2px;">
      <?= htmlspecialchars($data4['current_property_usage'] ?? '') ?></span></td>
  </tr>
  <tr>
    <td>9.b.4</td>
    <td> No. of Storey </td>
    <td><span style="display: inline-block; min-width: 50px; padding: 2px;"><?= htmlspecialchars($data8['basements_remarks'] ?? '') ?></span></td>
    <td><span style="display: inline-block; min-width: 50px; padding: 2px;"><?= htmlspecialchars($data10['NA'] ?? '') ?></span></td>
    <td colspan="2"><span style="display: inline-block; min-width: 50px; padding: 2px;"><?= htmlspecialchars($data8['basements_remarks'] ?? '') ?></span></td>
  </tr>
  <tr>
    <td>9.b.5</td>
    <td>Property type</td>
    <td><span style="display: inline-block; min-width: 50px; padding: 2px;"><?= htmlspecialchars($data4['approved_property_usage'] ?? '') ?></span></td>
    <td><span style="display: inline-block; min-width: 50px; padding: 2px;"><?= htmlspecialchars($data10['NA'] ?? '') ?></span></td>
    <td colspan="2"><span style="display: inline-block; min-width: 50px; padding: 2px;"><?= htmlspecialchars($data4['current_property_usage'] ?? '') ?></span></td>
  </tr>
  <tr>
    <td>9.b.6</td>
    <td>Structure</td>
    <td><span style="display: inline-block; min-width: 50px; padding: 2px;"><?= htmlspecialchars($data4['structure_type'] ?? '') ?></span></td>
    <td><span style="display: inline-block; min-width: 50px; padding: 2px;"><?= htmlspecialchars($data10['NA'] ?? '') ?></span></td>
    <td colspan="2"><span style="display: inline-block; min-width: 50px; padding: 2px;"><?= htmlspecialchars($data4['structure_type'] ?? '') ?></span></td>
  </tr>
  <tr>
    <td>9.b.7</td>
    <td>Completion / Occupancy Date</td>
    <td><span style="display: inline-block; min-width: 50px; padding: 2px;"><?= htmlspecialchars($data2['age_of_property'] ?? '') ?></span></td>
    <td><span style="display: inline-block; min-width: 50px; padding: 2px;"><?= htmlspecialchars($data10['NA'] ?? '') ?></span></td>
    <td colspan="2"><span style="display: inline-block; min-width: 50px; padding: 2px;"><?= htmlspecialchars($data2['age_of_property'] ?? '') ?></span></td>
  </tr>
  <tr>
    <td>9.b.8</td>
    <td>Residual Age</td>
    <td><span style="display: inline-block; min-width: 50px; padding: 2px;"><?= htmlspecialchars($data2['residual_age_of_property'] ?? '') ?></span></td>
    <td><span style="display: inline-block; min-width: 50px; padding: 2px;"><?= htmlspecialchars($data10['NA'] ?? '') ?></span></td>
    <td colspan="2"><span style="display: inline-block; min-width: 50px; padding: 2px;"><?= htmlspecialchars($data2['residual_age_of_property'] ?? '') ?></span></td>
  </tr>
  <tr>
    <td>9.b.9</td>
    <td>Carpet Area (SQFT)</td>
    <td><span style="display: inline-block; min-width: 50px; padding: 2px;"><?= htmlspecialchars($data6['carpet_square_feet'] ?? '') ?></span></td>
    <td><span style="display: inline-block; min-width: 50px; padding: 2px;"><?= htmlspecialchars($data10['NA'] ?? '') ?></span></td>
    <td colspan="2"><span style="display: inline-block; min-width: 50px; padding: 2px;"><?= htmlspecialchars($data6['actual_carpet_square_feet'] ?? '') ?></span></td>
  </tr>
  <tr>
    <td rowspan="2">9.b.10</td>
    <td>Built up Area (SQFT)</td>
    <td><span style="display: inline-block; min-width: 50px; padding: 2px;"><?= htmlspecialchars($data6['construction_square_feet'] ?? '') ?></span></td>
    <td><span style="display: inline-block; min-width: 50px; padding: 2px;"><?= htmlspecialchars($data10['NA'] ?? '') ?></span></td>
    <td colspan="2"><span style="display: inline-block; min-width: 50px; padding: 2px;"><?= htmlspecialchars($data6['actual_construction_square_feet'] ?? '') ?></span></td>
  </tr>
  <tr>
    <td>Loading used in %</td>
    <td colspan="4"><span style="display: inline-block; min-width: 50px; padding: 2px;"> <?= htmlspecialchars($data10['NA'] ?? '') ?></span></td>
  </tr>
  <tr>
    <td rowspan="2">9.b.11</td>
    <td>Super Built up/ Saleable Area/ Constructed Area (SQFT)</td>
    <td><span style="display: inline-block; min-width: 50px; padding: 2px;"><?= htmlspecialchars($data6['saleable_square_feet'] ?? '') ?></span></td>
    <td><span style="display: inline-block; min-width: 50px; padding: 2px;"><?= htmlspecialchars($data10['NA'] ?? '') ?></span></td>
    <td colspan="1"><span style="display: inline-block; min-width: 50px; padding: 2px;"><?= htmlspecialchars($data6['actual_saleable_square_feet'] ?? '') ?></span></td>
  </tr>
   <tr>
    <td>Loading used in %</td>
    <td colspan="4"><span style="display: inline-block; min-width: 50px; padding: 2px;"><?= htmlspecialchars($data10['NA'] ?? '') ?></span></td>
  </tr>
  <tr>
    <td>9.b.12</td>
    <td> FSI </td>
    <td><span style="display: inline-block; min-width: 50px; padding: 2px;"><?= htmlspecialchars('1.5') ?></span></td>
    <td><span style="display: inline-block; min-width: 50px; padding: 2px;"><?= htmlspecialchars($data10['NA'] ?? '') ?></span></td>
    <td colspan="2"><span style="display: inline-block; min-width: 50px; padding: 2px;"><?= htmlspecialchars('2') ?></span></td>
  </tr>
  <tr>
    <td>9.b.13</td>
    <td> Structural Condition </td>
    <td colspan="4"><b><span style="display: inline-block; min-width: 50px; padding: 2px;">
      <?= htmlspecialchars($data2['structurally_fit'] ?? '') ?></span></b></td>
  </tr>
  <tr>
    <td>9.b.14</td>
    <td>Present Occupancy</td>
    <td colspan="4"><span style="display: inline-block; min-width: 50px; padding: 2px;"><?= htmlspecialchars($data2['occupancy_status'] ?? '') ?></span></td>
  </tr>
  <tr>
    <td>9.b.15</td>
    <td> Final Area in SQFT Considered for Valuation </td>
    <td colspan="4"><span style="display: inline-block; min-width: 50px; padding: 2px;"><?= htmlspecialchars($data6['final_construction_square_feet'] ?? '') ?></span></td>
  </tr>
  <tr>
    <td>9.b.16</td>
    <td> Prevailing Market Rate Range (Rs./sqft) </td>
    <td colspan="">From </td>
    <td colspan=""><span style="display: inline-block; min-width: 50px; padding: 2px;"><?= htmlspecialchars($data6['justified_estimated_cost_per_sqft'] ?? '') ?></span></td>
    <td>TO </td>
    <td><span style="display: inline-block; min-width: 50px; padding: 2px;"><?= htmlspecialchars($data6['adoptable_justified_estimated_cost'] ?? '') ?></span></td>

  </tr>
  <tr>
    <td>9.b.17</td>
    <td> Rate Adopted for Valuation </td>
    <td colspan="4"><span style="display: inline-block; min-width: 50px; padding: 2px;"><?= htmlspecialchars($data6['final_construction_rate'] ?? '') ?></span></td>
  </tr>
  <tr>
    <td>9.b.18</td>
    <td>Fair Market Value / Realisable value</td>
    <td colspan="4"><span style="display: inline-block; min-width: 50px; padding: 2px;"><?= htmlspecialchars($data6['finally_construction_valuation'] ?? '') ?></span></td>
  </tr>
  <tr>
    <td>9.b.19</td>
    <td> Depreciation Considered in percentage </td>
    <td colspan="4"><span style="display: inline-block; min-width: 50px; padding: 2px; "><?= htmlspecialchars($data4['presence_of_nala'] ?? '') ?></span></td>
  </tr>
  <tr>
    <td>9.b.20</td>
    <td> Distress Value </td>
    <td colspan="4"><span style=" display: inline-block; min-width: 50px; padding: 2px;"><?= htmlspecialchars($data6['total_distress_value'] ?? '') ?></span></td>
  </tr>
  <tr>
    <td>9.b.21</td>
    <td> Unapproved Construction Value (SQFT) </td>
    <td colspan=""> Area: </td>
    <TD><span style="display: inline-block; min-width: 50px; padding: 2px;"><?= htmlspecialchars($data6['axis_plot_area'] ?? '') ?></span></TD>
     <TD> Rate: </td>
     <td><span style="display: inline-block; min-width: 50px; padding: 2px;"><?= htmlspecialchars($data6['axis_plot_sanction'] ?? '') ?></span></td>
  </tr>
  <tr>
    <td>9.b.22</td>
    <td> Internal and External Amenities </td>
    <td colspan="4"><span style="display: inline-block; min-width: 50px; padding: 2px;"><?= htmlspecialchars($data10['NA'] ?? '') ?></span></td>
  </tr>
  <tr>
    <td>9.b.23</td>
    <td> Violation Observed in % </td>
    <td colspan="4"><span style="display: inline-block; min-width: 50px; padding: 2px;"><?= htmlspecialchars($data10['NA'] ?? '') ?></span></td>
  </tr>
  <tr>
    <td>9.b.24</td>
    <td> Does property fall in Demolition list </td>
    <td colspan="4"><span style="display: inline-block; min-width: 50px; padding: 2px;"><?= htmlspecialchars($data9['demolition_risk_1'] ?? '') ?></span></td>
  </tr>

  <tr>
    <td>9.b.25</td>
    <td> Remarks on Last 3 years average price of </td>
    <td colspan="4"><span style="display: inline-block; min-width: 50px; padding: 2px;"><?= htmlspecialchars($data10['NA'] ?? '') ?></span></td>
  </tr>
  <tr>
    <td>9.b.26</td>
    <td> Insurable value of Property </td>
    <td colspan="4"><span style=" display: inline-block; min-width: 50px; padding: 2px;"><?= htmlspecialchars($data6['insurable_value'] ?? '') ?></span></td>
  </tr>
  

  <tr><th colspan="6" class="section-header">SUMMARY</th></tr>

  <tr>
    <td>10.a</td>
    <td><b>Land Value</b></td>
    <td><b>Approved/Authorized Construction/Unit Value/Actual </b></td>
    <td><b>Unapproved/Unauthorized Construction/Unit Value</b></td>
    <td><b>Interiors & Amenities Cost </b></td>
    <td><b>Total Value of Property</b></td>
  </tr>
  <tr>
    <td></td>
           <td><span style="display: inline-block; min-width: 50px; padding: 2px;"><?= htmlspecialchars($data6['finally_plot_valuation'] ?? '') ?></span></td>

    <td><span style="display: inline-block; min-width: 50px; padding: 2px;"><?= htmlspecialchars((int)$data6['finally_construction_valuation'] ?? '') ?></span></td>
<?php
$plotArea = isset($data6['axis_plot_area']) ? (int)$data6['axis_plot_area'] : 0;
$plotSanction = isset($data6['axis_plot_sanction']) ? (int)$data6['axis_plot_sanction'] : 0;

$total = $plotArea * $plotSanction;
?>

<td>
    <span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars((string)$total, ENT_QUOTES, 'UTF-8') ?>
    </span>
</td>


   
    <td><span style="display: inline-block; min-width: 50px; padding: 2px;"><?= htmlspecialchars($data6['amenities_total'] ?? '') ?></span></td>
    <td><span style="display: inline-block; min-width: 50px; padding: 2px;"><?= htmlspecialchars($data6['total_finally_area_valuation'] ?? '') ?></span></td>
  </tr>
  <tr>
    <td>10.b</td>
    <td colspan="">Less for Depreciation @%@ 1.5PA</td>
    <td><span style="display: inline-block; min-width: 50px; padding: 2px;"><?= htmlspecialchars($data10['NA'] ?? '') ?></span></td>
    <TD>NET VALUE</TD>
    <td colspan="2"><span style="display: inline-block; min-width: 50px; padding: 2px;"><?= htmlspecialchars($data10['NA'] ?? '') ?></span></td>
  </tr>
  <tr>
    <td>11</td>
    <td colspan="5">Thus the Final Recommended Value For the Said Property (Excluding unauthorized construction value) is:<span style="display: inline-block; min-width: 50px; padding: 2px;"><?= htmlspecialchars($data6['total_valuation_words'] ?? '') ?></span></td>
  </tr>
  <tr><td class="section-title" colspan="6"> REMARKS </td></tr>
  <tr>
    <td class="remark-list" colspan="6"><span style="white-space: pre-line; font-size:14px; display: block; text-align: left; padding: 0; margin: 0;font-weight:400;"readonly>
        <?= htmlspecialchars($data10['remarks'] ?? '') ?>
    </span>
    </td>
  </tr>
</table>

 <table>
<tr><th style="margin-bottom:-18px;">PHOTOGRAPH OF THE PROPERTY</tr></th></table>
<br>

    
<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

$servername = "localhost";
$username   = "root";
$password   = "";
$dbname     = "project_db";

$conn = new mysqli($servername, $username, $password, $dbname);
if ($conn->connect_error) {
    die("Connection failed: " . htmlspecialchars($conn->connect_error));
}

$reference_id = $_SESSION['reference_id'] ?? null;
$reference_id = $_GET['reference_id'] ?? $reference_id;

if ($reference_id) {

    // Map captions
    $captions = [
        'image1'  => 'EXTERNAL PHOTOS',
        'image2'  => 'Kitchen',
        'image3'  => 'Selfie',
        'image4'  => 'Electric Meter',
        'image6'  => 'Other 1',
        'image7'  => 'Other 2',
        'image8'  => 'Other 3',
        'image9'  => 'Other 4',
        'image10' => 'Other 5',
        'image11' => 'Other 6',
        'image12' => 'Other 7',
        'image13' => 'Other 8',
        'image14' => 'Other 9',
        'image15' => 'Other 10',
        'image16' => 'Other 11',
        'image17' => 'Other 12',
        'image18' => 'Other 13',
        'image19' => 'Other 14',
        'image20' => 'Other 15',
    ];

    // === Helper: EXIF-aware orientation detection ===
    function classify_orientation_after_exif(string $imageData): ?string {
        $size = @getimagesizefromstring($imageData);
        if (!$size || !isset($size[0], $size[1])) {
            return null;
        }
        $width  = (int)$size[0];
        $height = (int)$size[1];

        $mime = $size['mime'] ?? '';
        if ($mime === 'image/jpeg' && function_exists('exif_read_data')) {
            $tmp = @tempnam(sys_get_temp_dir(), 'exif_');
            if ($tmp !== false) {
                @file_put_contents($tmp, $imageData);
                $exif = @exif_read_data($tmp);
                @unlink($tmp);

                if (!empty($exif['Orientation'])) {
                    $orientation = (int)$exif['Orientation'];
                    if ($orientation === 6 || $orientation === 8) {
                        $t = $width; $width = $height; $height = $t;
                    }
                }
            }
        }
        return ($width >= $height) ? 'horizontal' : 'vertical';
    }

    // === Helper: Fix orientation physically with Imagick ===
    function fixImageOrientation($binaryData) {
        $img = new Imagick();
        $img->readImageBlob($binaryData);

        switch ($img->getImageOrientation()) {
            case Imagick::ORIENTATION_BOTTOMRIGHT:
                $img->rotateImage("#000", 180);
                break;
            case Imagick::ORIENTATION_RIGHTTOP:
                $img->rotateImage("#000", 90);
                break;
            case Imagick::ORIENTATION_LEFTBOTTOM:
                $img->rotateImage("#000", -90);
                break;
        }

        $img->setImageOrientation(Imagick::ORIENTATION_TOPLEFT);
        $fixed = $img->getImageBlob();
        $img->destroy();

        return $fixed;
    }

    $sql = "SELECT 
                image1, image2, image3, image4, 
                image6, image7, image8, image9, 
                image10, image11, image12, image13, image14, image15, image16, image17, image18, image19, image20
            FROM final_uploaded_images 
            WHERE reference_id = ?";

    $stmt = $conn->prepare($sql);
    if ($stmt === false) {
        die("Error preparing the SQL statement: " . htmlspecialchars($conn->error));
    }

    $stmt->bind_param("s", $reference_id);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result && $result->num_rows > 0) {
        $horizontal_images = [];
        $vertical_images   = [];

        while ($row = $result->fetch_assoc()) {
            foreach ($row as $key => $imageData) {
                if (!empty($imageData)) {

                    // Actually fix image before displaying
                    $fixedData = fixImageOrientation($imageData);

                    $orientation = classify_orientation_after_exif($fixedData) ?? 'horizontal';
                    $imgString   = base64_encode($fixedData);
                    $caption     = $captions[$key] ?? 'Image';

                    $item = [
                        'data'    => $imgString,
                        'caption' => $caption,
                        'alt'     => $key,
                    ];

                    if ($orientation === 'horizontal') {
                        $horizontal_images[] = $item;
                    } else {
                        $vertical_images[]   = $item;
                    }
                }
            }
        }

 
// Output as a stable 4-column table (works in wkhtmltopdf)
$all_images = array_merge($vertical_images, $horizontal_images);

echo '<table class="image-grid">';
$rows = array_chunk($all_images, 4);
foreach ($rows as $row) {
    echo '<tr>';
    foreach ($row as $img) {
        echo '<td>';
        echo '<div class="img-wrap">';
        echo '<img src="data:image/jpeg;base64,' . $img['data'] . '" alt="' . htmlspecialchars($img['alt']) . '">';
        echo '<div class="caption">' . htmlspecialchars($img['caption']) . '</div>';
        echo '</div>';
        echo '</td>';
    }
    // pad remaining cells to keep 4 columns
    $remaining = 4 - count($row);
    if ($remaining > 0) {
        echo str_repeat('<td></td>', $remaining);
    }
    echo '</tr>';
}
echo '</table>';

    } else {
        echo "<p style='text-align:center;'>No images found.</p>";
    }

    $stmt->close();
} else {
    echo "<p style='text-align:center;'>Reference ID is missing.</p>";
}
?>
      <table>
  </tr>
  <tr>

<div class="google-map-container">
<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "project_db";
$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$reference_id = $_SESSION['reference_id'] ?? null;
$reference_id = $_GET['reference_id'] ?? $reference_id;

if ($reference_id) {
    $sql = "SELECT image5 FROM final_uploaded_images WHERE reference_id = ?";
    $stmt = $conn->prepare($sql);
    if ($stmt === false) {
        die("Error preparing the SQL statement: " . $conn->error);
    }

    $stmt->bind_param("s", $reference_id);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows > 0) {
        $row = $result->fetch_assoc();
        if (!empty($row['image5'])) {
                          echo "<p style='text-align:center;'>Location cum Route map showing property boundaries</p>";

            echo '<div><img src="data:image/jpeg;base64,' . base64_encode($row['image5']) . '" alt="Google Map"><p>Google Map</p></div>';
        } else {
            echo "<p style='text-align:center;'>Google Map image not available.</p>";
        }
    } else {
        echo "<p style='text-align:center;'>No record found for Google Map image.</p>";
    }

    $stmt->close();
} else {
    echo "<p style='text-align:center;'>Reference ID is missing.</p>";
}
?>
</tr>
</div>
    </table>
    </table>
     
   <!-- Buttons: Hidden during print -->
<div class="no-print">
  <form method="post">
    <input type="hidden" name="download_images" value="1">
    <button type="submit">Download All Images</button>
  </form>

  <button id="downloadPdf" onclick="setPrintMargins()">DOWNLOAD PDF</button>
</div>

  <script>
    document.getElementById('downloadPdf').addEventListener('click', () => {
      // Select the content you want to convert to PDF
      const element = document.getElementById('content');
      const options = {
        margin:[0,0],
        filename:'report.pdf',
        image: { type: 'jpeg', quality: 0.98 },
        html2canvas: { scale: 2 },
        jsPDF: { unit: 'in', format: 'letter', orientation: 'portrait' }
      };

      // Generate and download the PDF
      html2pdf().set(options).from(element).save();
    });
    function setPrintMargins() {
      const style = document.createElement('style');
      style.innerHTML = `
      @media print {
          body {
            margin:0.5;
          }
        }
      `;
      document.head.appendChild(style);
      window.print();
    }
    // Disable all input fields in the form
    document.querySelectorAll('input').forEach(function(input) {
        input.disabled = true;  // Disables the field completely
    });
     function resizeFakeInput(input) {
    const fake = document.getElementById('fakeWrap');
    fake.textContent = input.value || ' ';
    input.style.height = fake.scrollHeight + 'px';
  }

  // Initialize height
  resizeFakeInput(document.getElementById('longInput'));
   function autoResize(el) {
    el.style.height = 'auto'; // reset height
    el.style.height = el.scrollHeight + 'px'; // set to content height
  }
  // Auto-resize on load
  document.querySelectorAll('.clean-textarea').forEach(t => autoResize(t));
    </script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/jspdf/2.5.1/jspdf.umd.min.js"></script>

  <script>
    // Disable input fields before generating PDF
    function disableInputs() {
      document.querySelectorAll('input, textarea').forEach(input => input.disabled = true);
    }

    // Re-enable input fields after PDF generation (optional)
    function enableInputs() {
      document.querySelectorAll('input, textarea').forEach(input => input.disabled = false);
    }

    // Auto-resize textareas
    function autoResize(el) {
      el.style.height = 'auto';
      el.style.height = el.scrollHeight + 'px';
    }

    document.querySelectorAll('.clean-textarea').forEach(t => autoResize(t));

    // PDF generation logic using jsPDF with html()
    document.getElementById('downloadPdf').addEventListener('click', async () => {
      disableInputs();

      const { jsPDF } = window.jspdf;
      const doc = new jsPDF({
        orientation: 'portrait',
        unit: 'pt',
        format: 'a4'
      });

      await doc.html(document.getElementById('content'), {
        callback: function (doc) {
          doc.save('report.pdf');
          enableInputs();
        },
        margin: [40, 40, 40, 40],
        autoPaging: 'text',
        x: 10,
        y: 10,
        html2canvas: {
          scale: 1,
          useCORS: true
        }
      });
    });
  </script>
</div>
</body>
</html>


