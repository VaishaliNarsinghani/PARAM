<?php include('auth.php'); ?>
<?php
ini_set('display_errors', 1);
error_reporting(E_ALL);

// Increase PHP execution time and memory limit
ini_set('max_execution_time', 600); // Increase execution time to 600 seconds (10 minutes)
ini_set('memory_limit', '4096M'); // Increase memory limit to 4096MB
// Start session


$servername = "localhost";
$username = "root"; 
$password = "";
$dbname = "project_db";

// Create DB connection
$conn = new mysqli($servername, $username, $password, $dbname);
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

if (!isset($_SESSION['reference_id'])) {
    die("Reference ID not found in session.");
}
$reference_id = $_SESSION['reference_id'];

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['download_images'])) {

    // Get customer name
    $stmt_name = $conn->prepare("SELECT customerName FROM mis WHERE reference_id = ?");
    $stmt_name->bind_param("s", $reference_id);
    $stmt_name->execute();
    $result_name = $stmt_name->get_result();
    $customerName = "customer";
    if ($row = $result_name->fetch_assoc()) {
        $customerName = preg_replace('/[^a-zA-Z0-9]/',  
          '', $row['customerName']);
    }
    $stmt_name->close();

    // Fetch image BLOBs
    $stmt = $conn->prepare("SELECT image1, image2, image3, 
     image4, image5, image6, image7, image8, image9, image10, ima
     ge11, image12 FROM final_uploaded_images WHERE reference_id = ?");
    $stmt->bind_param("s", $reference_id);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows > 0 && ($row = $result->fetch_assoc())) {
        $tempDir = sys_get_temp_dir() . DIRECTORY_SEPARATOR . uniqid('images_', true);
        mkdir($tempDir);

        $imageFiles = [];
        for ($i = 1; $i <= 12; $i++) {
            if (!empty($row["image$i"])) {
                $filename = $tempDir . DIRECTORY_SEPARATOR . "image{$i}.jpg";
                file_put_contents($filename, $row["image$i"]);
                $imageFiles[] = $filename;
            }
        }

        if (empty($imageFiles)) {
            die("No images to download.");
        }

        // Create ZIP
        $zipFileName = "images_" . preg_replace('/[^a-zA-Z0-9]/', '_', $reference_id) . "_{$customerName}.zip";
        $zipPath = $tempDir . DIRECTORY_SEPARATOR . $zipFileName;

        $zip = new ZipArchive();
        if ($zip->open($zipPath, ZipArchive::CREATE) !== TRUE) {
            die("Failed to create ZIP file.");
        }

        foreach ($imageFiles as $file) {
            $zip->addFile($file, basename($file));
        }
        $zip->close();

        // Send ZIP to browser
        header('Content-Type: application/zip');
        header('Content-Disposition: attachment; filename="' . basename($zipFileName) . '"');
        header('Content-Length: ' . filesize($zipPath));
        flush();
        readfile($zipPath);

        // Cleanup
        foreach ($imageFiles as $file) {
            unlink($file);
        }
        unlink($zipPath);
        rmdir($tempDir);
        exit;
    } else {
        echo "<p style='color:red;'>No image data found for this reference ID.</p>";
    }
}
$page = isset($_GET['page']) ? $_GET['page'] : 1;
$limit = 50;
$offset = ($page - 1) * $limit;
$sql_property = "SELECT * FROM mis WHERE reference_id = ? LIMIT $limit OFFSET $offset";
$stmt_property = $conn->prepare($sql_property);
$stmt_property->bind_param("s", $reference_id);
$stmt_property->execute();
$result_property = $stmt_property->get_result();
$data1 = $result_property->fetch_assoc();




// Fetch data from property_details table
$sql_property = "SELECT * FROM property_details WHERE reference_id = ?";
$stmt_property = $conn->prepare($sql_property);
$stmt_property->bind_param("s", $reference_id);
$stmt_property->execute();
$result_property = $stmt_property->get_result();
$data2= $result_property->fetch_assoc();




// Fetch data from area_valuation table
$sql_area = "SELECT * FROM address_details WHERE reference_id = ?";
$stmt_area = $conn->prepare($sql_area); 
$stmt_area->bind_param("s", $reference_id);
$stmt_area->execute();
$result_area = $stmt_area->get_result();
$data3 = $result_area->fetch_assoc();

// Fetch data from area_valuation table
$sql_area = "SELECT * FROM critical_parameters WHERE reference_id = ?";
$stmt_area = $conn->prepare($sql_area); 
$stmt_area->bind_param("s", $reference_id);
$stmt_area->execute();
$result_area = $stmt_area->get_result();
$data4 = $result_area->fetch_assoc();

 
// Fetch data from area_valuation table
$sql_area = "SELECT * FROM surroundings_details WHERE reference_id = ?";
$stmt_area = $conn->prepare($sql_area); 
$stmt_area->bind_param("s", $reference_id);
$stmt_area->execute();
$result_area = $stmt_area->get_result();
$data5 = $result_area->fetch_assoc();
$stmt_area->close();
 
// Fetch data from area_valuation table
$sql_area = "SELECT * FROM area_valuation WHERE reference_id = ?";
$stmt_area = $conn->prepare($sql_area); 
$stmt_area->bind_param("s", $reference_id);
$stmt_area->execute();
$result_area = $stmt_area->get_result();
$data6 = $result_area->fetch_assoc();
$stmt_area->close();
 



// Fetch data from area_valuation table
$sql_area = "SELECT * FROM floor_details WHERE reference_id = ?";
$stmt_area = $conn->prepare($sql_area); 
$stmt_area->bind_param("s", $reference_id);
$stmt_area->execute();
$result_area = $stmt_area->get_result();
$data8= $result_area->fetch_assoc();
$stmt_area->close();
 


// Fetch data from area_valuation table
$sql_area = "SELECT * FROM technical_details WHERE reference_id = ?";
$stmt_area = $conn->prepare($sql_area); 
$stmt_area->bind_param("s", $reference_id);
$stmt_area->execute();
$result_area = $stmt_area->get_result();
$data9 = $result_area->fetch_assoc();
$stmt_area->close();
 
// Fetch data from area_valuation table
$sql_area = "SELECT * FROM remarks_table WHERE reference_id = ?";
$stmt_area = $conn->prepare($sql_area); 
$stmt_area->bind_param("s", $reference_id);
$stmt_area->execute();
$result_area = $stmt_area->get_result();
$data10 = $result_area->fetch_assoc();
$stmt_area->close();


// Step 1: Fetch the engineer_id from the mis table
$sql_mis = "SELECT engineer_id FROM mis WHERE reference_id = ?";
$stmt_mis = $conn->prepare($sql_mis);
$stmt_mis->bind_param("s", $reference_id);
$stmt_mis->execute();
$result_mis = $stmt_mis->get_result();
$row_mis = $result_mis->fetch_assoc();
$stmt_mis->close(); 

if ($row_mis) {
    $engineer_id = $row_mis['engineer_id'];

    // Step 2: Fetch the engineer's name from engineer_login table
    $sql_engineer = "SELECT name FROM engineer_login WHERE engineer_id = ?";
    $stmt_engineer = $conn->prepare($sql_engineer);
    $stmt_engineer->bind_param("s", $engineer_id);
    $stmt_engineer->execute();
    $result_engineer = $stmt_engineer->get_result();
    $row_engineer = $result_engineer->fetch_assoc();
    $stmt_engineer->close();

    if ($row_engineer) {
        $engineer_name = $row_engineer['name'];
         //echo "Engineer Name: " . $engineer_name;
    } else {
        echo "Engineer not found.";
    }
} else {
    echo "No engineer assigned for this reference_id.";
}



// Step 1: Fetch the engineer_id from the mis table
$sql_mis = "SELECT report_id FROM mis WHERE reference_id = ?";
$stmt_mis = $conn->prepare($sql_mis);
$stmt_mis->bind_param("s", $reference_id);
$stmt_mis->execute();
$result_mis = $stmt_mis->get_result();
$row_mis = $result_mis->fetch_assoc();
$stmt_mis->close(); 

if ($row_mis) {
    $report_id = $row_mis['report_id'];

    // Step 2: Fetch the engineer's name from engineer_login table
    $sql_engineer = "SELECT name FROM report_login WHERE report_id = ?";
    $stmt_engineer = $conn->prepare($sql_engineer);
    $stmt_engineer->bind_param("s", $report_id);
    $stmt_engineer->execute();
    $result_engineer = $stmt_engineer->get_result();
    $row_engineer = $result_engineer->fetch_assoc();
    $stmt_engineer->close();

    if ($row_engineer) {
        $report_name = $row_engineer['name'];
         //echo "Engineer Name: " . $report_name;
    } else {
        echo "Engineer not found.";
    }
} else {
    echo "No engineer assigned for this reference_id.";
}


// Step 1: Fetch the engineer_id from the mis table
$sql_mis = "SELECT report_drafter_to_technical FROM mis WHERE reference_id = ?";
$stmt_mis = $conn->prepare($sql_mis);
$stmt_mis->bind_param("s", $reference_id);
$stmt_mis->execute();
$result_mis = $stmt_mis->get_result();
$row_mis = $result_mis->fetch_assoc();
$stmt_mis->close(); 

if ($row_mis) {
    $report_drafter_to_technical = $row_mis['report_drafter_to_technical'];

    // Step 2: Fetch the engineer's name from engineer_login table
    $sql_engineer = "SELECT name FROM technical_login WHERE technical_manager_id = ?";
    $stmt_engineer = $conn->prepare($sql_engineer);
    $stmt_engineer->bind_param("s", $report_drafter_to_technical);
    $stmt_engineer->execute();
    $result_engineer = $stmt_engineer->get_result();
    $row_engineer = $result_engineer->fetch_assoc();
    $stmt_engineer->close();

    if ($row_engineer) {
        $technical_name = $row_engineer['name'];
        //echo "Engineer Name: " . $technical_name;
    } else {
        echo "Engineer not found.";
    }
} else {
    echo "No engineer assigned for this reference_id.";
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <style>                                
.container {
  width: 90%;
  margin: 20px auto;
  border: 1px solid black;
  padding: 20px;
}
.header-content {
  text-align: center;
  flex: 1;
}
.header-content h1 {
  margin: 0;
  margin-top:25px;  
  font-size: 38px;
  color: #902d2d;
}
.header-content p {
  margin: 2px 0;
  font-size: 26px;
  color: #333;
}
.footer{
  display: flex;
}
h3{
  background-color:rgb(243, 234, 222) ;
  padding:5px;
  text-align: center;
  border:1px solid black;
} 
 @media print{
    body{
      margin:0;
    }
    button{
      display:none;
      margin-left:30%;
    }
}

.container {
    max-width: 1200px;
    margin: 20px auto;
    padding: 20px;
    background-color: white;
    box-shadow: 0px 0px 10px rgba(0, 0, 0, 0.1);
    border-radius: 8px;
}

.title {
    text-align: center;
    font-size: 24px;
    font-weight: bold;
    margin-bottom: 20px;
}
.grid-container {
    display: grid;
    grid-template-columns: repeat(4, 1fr);
    gap: 15px;
}

.grid-item {
    position: relative;
    border-radius: 8px;
    overflow: hidden;
    box-shadow: 0px 4px 6px rgba(0, 0, 0, 0.1);
}

.grid-item img {
    width: 100%;
    height: 200px;
    object-fit: cover;
    transition: transform 0.3s ease;
}
.grid-item:hover img {
    transform: scale(1.05);
}

.overlay {
    position: absolute;
    bottom: 0;
    left: 0;
    background: rgba(0, 0, 0, 0.6);
    color: white;
    width: 100%;
    padding: 8px;
    font-size: 14px;
    text-align: center;
}
 
   
/* Force a stable 4-column grid that wkhtmltopdf respects */
.image-gallery { width: 100%; }
.image-grid { width: 100%; border-collapse: collapse; table-layout: fixed; }
.image-grid tr { page-break-inside: avoid; }
.image-grid td { width: 25%; padding: 6px; vertical-align: top; }

.image-grid .img-wrap { display: block; }
.image-grid img { display: block; width: 100%; height: auto; }
.image-grid .caption { font-size: 12px; text-align: center; margin-top: 4px; }

/* If you had a flex layout before, neutralize it */
.image-gallery { display: block !important; }



    /* Print-specific rules */
    @media print {
      .no-print {
        display: none !important;
      }

      body {
        margin: 0;
      }
 
    }
  button{
    padding:8px;
    margin-left:45%;
    background-color:#808485;
    color:white;
    font-weight:700;
    font-style:italic;
  }
  button:hover{
    background-color:rgba(216,216,216,255);
    color:white;
  }

/* Optional: Google map styling */
    .google-map-container {
      max-width: 90%;
      margin: 20px auto;
      border: 2px solid #ccc;
      padding: 10px;
      box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
      background-color: #f9f9f9;
      border-radius: 8px;
      text-align: center;
    }

    .google-map-container img {
      max-width: 100%;
      height: auto;
      display: inline-block;
      border: 1px solid #999;
      border-radius: 4px;
    }
    
.logo img {
  width: 120px;
  margin-left:30px;
  height: auto;
}
 @media print{
    body{
      margin:0;
    }
    button{
      display:none;
      margin-left:30%;
    }
}
input[type="text"] {
  width: 100%;
  border: none;
  outline: none;
}                   
body {
  font-family: Arial, sans-serif;
  margin: 20px;
  font-size: 14px;
}
table {
  width: 100%;
  border-collapse: collapse;
}
td, th {
  border: 1px solid #333;
  padding: 4px 8px;
  vertical-align: top;
}
th {
  background-color: #eee;
}
.section-title {
  text-align: center;
  font-weight: bold;
  background-color: #ddd;
}
.input-span {
  display: inline-block;
  min-width: 100px;
  border-bottom: 1px dotted #999;
  padding: 2px;
}
</style>
</head>
<body>
    <div class="container">
        <header>
            <div class="footer">
            <div class="logo">
               <img src="images/logo.png" alt="Magpie Logo">
            </div>
            <div class="header-content">
                <h1>MAGPIE ENGINEERING PVT. LTD.</h1>
                <p>Valuer Designer Architects</p>
                <p> Office No. 201, 2nd floor, Gravity Mall, Mechanic Nagar, Warehouse Road, Near Vijay<br>
      Nagar, Indore, Madhya Pradesh - 452011</p>
            </div>
            </div>
        </header>
<table>
    <tr>
        <td>FIRM NAME / NAME OF VALUER AND LOGO </td>
        <td colspan="5"><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars("MAGPIE ENGINEERING PRIVATE LIMITE") ?>
    </span></td>
    </tr>
    <tr>
        <td>ADDRESS OF THE VALUER :</td>
         <td colspan="5"><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars("201, Gravity Mall, 27 Mechanic nagar, Scheme 54, Indore, M.P.") ?>
    </span></td>
    </tr>
    <TR>
        <td>REG NO.</td>
        <td colspan="5"><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars("25324") ?>
    </span></td>
    </TR>
    <tr>
        <td> GST & PAN NO. </td>
        <td colspan="5"><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars("23AALCM9010E1ZR & AALCM9010E") ?>
    </span></td>
    </tr>    
    <tr><td colspan="6" class="section-title"> SRG HOUSING FINANCE LTD, UDAIPUR,RAJ </td></tr>
  <tr><td colspan="6" class="section-title"> VALUATION REPORT </td></tr>
  <tr><td colspan="6" class="section-title"> Section 1. INFORMATION SHARED DURING ASSIGNMENT OF VALUATION. </td></tr>
  <tr>
    <td> Date of technical visit </td>
    <td colspan="2"><span style="display: inline-block; min-width: 50px; padding: 2px;">
 <?= htmlspecialchars(date('d M Y h:i A', strtotime($data1['report_assigned_at'] ?? ''))) ?>
    </span></td>
    <td> Property title </td>
    <td colspan="2"><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data9['ownership1_document'] ?? '') ?>
    </span></td>
  </tr>
  <tr>
    <td> Application Ref. / I.R. No. </td>
    <td colspan="2"><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data1['applicationNo'] ?? '') ?>
    </span></td>
    <td> Product </td>
    <td colspan="2"><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data1['caseType'] ?? '') ?>
    </span></td>
  </tr>
  <tr>
    <td> Name of Customer / Co-Applicant </td>
    <td colspan="5"><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data1['customerName'] ?? '') ?>
    </span></td>
  </tr>
  <tr>
    <td> Ownership as per document </td>
    <td colspan="5"><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data9['owner_name'] ?? '') ?>
    </span></td>
  </tr>
  <tr>
    <td> Contact No. of customer </td>
    <td colspan="2"><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data1['customerMob'] ?? '') ?>
    </span></td>
    <td> Purpose of Valuation </td>
    <td colspan="2"><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars('FMV') ?>
    </span></td>
  </tr>
  <tr>
    <td> Lease Hold or Free Hold </td>
    <td colspan="2"><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data2['property_leasehold_freehold'] ?? '') ?>
    </span></td>
    <td> Occupation status </td>
    <td colspan="2"><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data2['occupancy_status'] ?? '') ?>
    </span></td>
  </tr>
  <tr>
    <td colspan="2"> Documents Provided for Valuation </td>
    <td><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data9['list_documents'] ?? '') ?>
    </span></td>
    <td> Allocated By </td>
    <td colspan="2"><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data4['abutting_agriculture_land'] ??'') ?>
    </span></td>
  </tr>
  <tr>
    <td rowspan="2">Address of property</td>
    <td> As Per Document </td>
    <td colspan="4"><span style="display: inline-block; min-width: 50px; padding: 2px;">
       <?= htmlspecialchars($data3['address_per_document'] ?? '') ?>
    </span></td>
  </tr>
  <tr>
    <td> As per Actual/Postal </td>
    <td colspan="4"><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data3['address_per_site'] ?? '') ?>
    </span></td>
  </tr>
  <tr>
    <td> Difference if any - if yes give reason </td>
    <td colspan="5"><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data10['NA'] ?? '') ?>
    </span></td>
  </tr>

  <tr><td colspan="6" class="section-title"> Section 2. Locality Details </td></tr>
  <tr>
    <td> Type of locality </td>
    <td colspan="5"><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data2['class_of_locality'] ?? '') ?>
    </span></td>
  </tr>
  <tr>
    <td>Distance from SRG Branch</td>
    <td colspan="2">Nearest Railway Station(with distance)</td>
    <td>Nearest Bus Stand(with distance)</td>
    <td colspan="2">Nearest Hospital(with distance)</td>
  </tr>
  <tr>
     <td><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data3['distance_from_branch_kms'] ?? '') ?>
    </span></td>
    <td colspan="2"><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data3['nearest_railway_station_name'] ?? '') ?> <?= htmlspecialchars($data3['nearest_railway_station_distance'] ?? '') ?>
    </span></td>
    <td><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data3['nearest_bus_stop_name'] ?? '') ?> <?= htmlspecialchars($data3['nearest_bus_stop_distance'] ?? '') ?>
    </span></td>
    <td colspan="2"><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data3['nearest_hospital_distance'] ?? '') ?>
    </span></td>
  </tr>
  <tr>
    <td>No. of houses in Village in Rural cases</td>
    <td colspan="5"><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data4['no_of_houses'] ?? '') ?>
    </span></td>
  </tr>
  <TR>
     <td>Total development in Area/Locality (%)</td>
    <td colspan="5"><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data2['develop_percent'] ?? '') ?>
    </span></td>
  </TR>
  <tr>
     <td>Type of locality (Lower/Middle / Upper Middle)</td>
    <td colspan="5"><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data2['class_of_locality'] ?? '') ?>
    </span></td>
  </tr>
  <tr>
    <td>Any Negative to the Locality</td>
    <td colspan="5"><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data10['NA'] ?? '') ?>
    </span></td>
  </tr>
  <tr>
    <td>ZONE NO.</td>
    <td colspan="2">SUB REGISTRAR OFFICE</td>
    <td>DLC RATE</td>
    <td colspan="2">Location Name</td>
  </tr>
  <tr>
    <td><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data4['seismic_zone'] ?? '') ?>
    </span></td>
    <td colspan="2"><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data3['address_line_3_as_per_doc'] ?? '') ?>
    </span></td>
    <td><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data6['guideline_rate'] ?? '') ?>
    </span></td>
    <td colspan="2"><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data10['NA'] ?? '') ?>
    </span></td>
  </tr>
  <tr>
    <td>Usage</td>
    <td colspan="5"><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data4['current_property_usage'] ?? '') ?>
    </span></td>
  </tr>
  <tr>
    <td>Seismic Zone</td>
    <td colspan="2">Cyclone Zone</td>
    <td>Flood Zone</td>
    <td colspan="2">Landslide Zone</td>
  </tr>
  <tr>
    <td><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data4['seismic_zone'] ?? '') ?>
    </span></td>
    <td colspan="2"><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data10['NA'] ?? '') ?>
    </span></td>
    <td><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data10['NA'] ?? '') ?>
    </span></td>
    <td colspan="2"><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data10['NA'] ?? '') ?>
    </span></td>
  </tr>
  <tr>
    <td colspan="3">Width and Condition of Approach Road</td>
    <td colspan="3"><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data2['width_of_approach_road'] ?? '') ?> <?= htmlspecialchars($data2['type_of_approach_road'] ?? '') ?>
    </span></td>
  </tr>
  <tr>
   <td colspan="3">Near by landmark</td>
   <td colspan="3"><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data3['landmark_1'] ?? '') ?>
    </span></td>
  </tr>
  <tr>
    <td colspan="3">Basic amenities available?</td>
    <td colspan="3"><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data6['addition_amenities_description_2'] ?? '') ?>
    </span></td>
  </tr>

  <tr><td colspan="6" class="section-title">Section 3. Property Details</td></tr>
  <tr>
    <td rowspan="2">Area of land</td>
    <td>Area in sq.m:</td>
    <td>Area in sq. yds:</td>
    <td>Area in sq. ft</td>
    <td>Plinth area of house (in sq.ft.)</td>
    <td>Build up area of house (in sq.ft.)</td>
  </tr>
  <tr>
    <td> <input type="text" readonly  
        value="<?= isset($data8['document_area_saledeed']) ? round(floatval($data8['document_area_saledeed']) * 0.092903, 2) : '' ?>">
</td>
    <td><input type="text" readonly  
    value="<?= isset($data8['document_area_saledeed']) ? round(floatval($data8['document_area_saledeed']) / 9, 2) : '' ?>">
</td>
    <td><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data8['document_area_saledeed'] ?? '') ?>
    </span></td>
    <td><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data8['ground_actual'] ?? '') ?>
    </span></td>
    <td><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data8['total_actual_floors'] ?? '') ?>
    </span></td>
  </tr>
  <tr>
    <td></td>
    <td>B.F.</td>
    <td>G.F.</td>
    <td>F.F.</td>
    <td>S.F</td>
    <td>TOTAL</td>
  </tr>
  <tr>
    <td>Actual Built-up area of houses(sqr-ft)</td>
    <td><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data10['NA'] ?? '') ?>
    </span></td>
    <td><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data8['ground_actual'] ?? '') ?>
    </span></td>
    <td><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data8['first_actual'] ?? '') ?>
    </span></td>
    <td><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data8['second_actual'] ?? '') ?>
    </span></td>
    <td><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data8['total_actual_floors'] ?? '') ?>
    </span></td>
  </tr>
  <tr>
    <td>Permissible Built-up area of house</td>
   <td><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data10['NA'] ?? '') ?>
    </span></td>
    <td><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data8['ground_permissible'] ?? '') ?>
    </span></td>
    <td><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data8['first_permissible'] ?? '') ?>
    </span></td>
    <td><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data8['second_permissible'] ?? '') ?>
    </span></td>
    <td><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data8['total_permissible_floors'] ?? '') ?>
    </span></td>
    
  </tr>
  <tr>
    <td colspan="3">Total permissible Built-up area in sq.ft</td>
    <td colspan="3"><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data8['total_permissible_floors'] ?? '') ?>
    </span></td>
  </tr>
  <tr>
    <td colspan="3">Usage</td>
    <td colspan="3"><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data4['approved_property_usage'] ?? '') ?>
    </span></td>
   
  </tr>
  <tr>
    <td colspan="3">Ratio of each type</td>
    <td colspan="3"><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data2['ratio_of_each_type'] ?? '') ?>
    </span></td>
  </tr>
  <tr>
    <td colspan="3">Nature of Construction</td>
    <td colspan="3"><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data2['structurally_fit'] ?? '') ?>
    </span></td>

  </tr>
  <tr>
    <td colspan="3">Age of the property</td>
    <td colspan="3"><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data2['age_of_property'] ?? '') ?>
    </span></td>
  </tr>
  <tr>
    <td colspan="3">Residual usage</td>
    <td colspan="3"><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data2['residual_age_of_property'] ?? '') ?>
    </span></td>
  </tr>
  <tr>
    <td colspan="3">If Occupied, Name of the Occupant</td>
    <td colspan="3"><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data2['occupant_name'] ?? '') ?>
    </span></td>
  </tr>
</table>
<table>
  <tr>
    <td class="label">If rented, list of tenants</td>
    <td colspan="4">
      <span style="display: inline-block; min-width: 50px; padding: 2px;">
          <?= htmlspecialchars($data4['costal_regulatory_zone'] ?? '') ?>
      </span>
    </td>
  </tr>
<tr>
  <td class="label">Plot demarcated</td>
  <td colspan="4">
    <span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data2['demarcated_at_site'] ?? '') ?>
    </span>
  </td>
</tr>
<tr>
  <td class="label">Property identified through</td>
  <td colspan="4">
    <span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data3['property_identified_through'] ?? '') ?>
    </span>
  </td>
</tr>

  <tr><td colspan="5" class="label" >Dimensions Details</td></tr>
  <tr>
    <td>DESCRIPTION(IN FEETS)</td>
    <td><b>EAST (Feets)</b></td>
    <td><b>WEST (Feets)</b></td>
    <td><b>NORTH (Feets)</b></td>
    <td><b>SOUTH (Feets)</b></td>
  </tr>
  <tr>
    <td>As per document</td>
    <td><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data6['dimension_as_per_document_east'] ?? '') ?>
    </span></td>
    <td><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data6['dimension_as_per_document_west'] ?? '') ?>
    </span></td>
    <td><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data6['dimension_as_per_document_north'] ?? '') ?>
    </span></td>
    <td><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data6['dimension_as_per_document_south'] ?? '') ?>
    </span></td>
  </tr>
  <tr>
    <td>Actual</td>
    <td><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data6['dimension_as_per_site_east'] ?? '') ?>
    </span></td>
    <td><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data6['dimension_as_per_site_west'] ?? '') ?>
    </span></td>
    <td><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data6['dimension_as_per_site_north'] ?? '') ?>
    </span> </td>
    <td><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data6['dimension_as_per_site_south'] ?? '') ?>
    </span></td>
  </tr>
  <tr><td colspan="5" class="label">Neighbour (four corners) Details</td></tr>
  <tr>
    <td>DESCRIPTION</td>
    <td><b>EAST</b></td>
    <td><b>WEST</b></td>
    <td><b>NORTH</b></td>
     <td><b>SOUTH</b></td>
  </tr>
  <tr>
    <td>As per document</td>
    <td><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data3['direction_as_per_document_east'] ?? '') ?>
    </span></td>
    <td><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data3['direction_as_per_document_west'] ?? '') ?>
    </span></td>
    <td><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data3['direction_as_per_document_north'] ?? '') ?>
    </span></td>
    <td><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data3['direction_as_per_document_south'] ?? '') ?>
    </span></td>
  </tr>
  <tr>
    <td>Actual</td>
    <td><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data3['direction_as_per_site_east'] ?? '') ?>
    </span></td>
    <td><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data3['direction_as_per_site_west'] ?? '') ?>
    </span></td>
    <td><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data3['direction_as_per_site_north'] ?? '') ?>
    </span></td>
    <td><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data3['direction_as_per_site_south'] ?? '') ?>
    </span></td>
  </tr>

  <tr>
    <td>Are all neighbours relatives of same caste?</td>
    <td colspan="4"><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data10['NA'] ?? '') ?>
    </span></td>
  </tr>
  <tr>
    <td>Any board/notice/security features?</td>
    <td colspan="4"><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data4['board_on_house'] ?? '') ?>
    </span></td>
  </tr>
  <tr>
    <td>Marketability of the Property</td>
    <td colspan="4"><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data9['markebility'] ?? '') ?>
    </span></td>
  </tr>
  <tr><td colspan="5" class="label"> DETAILS OF CONSTRUCTION (IF AVAILABLE)</td></tr>
  <tr>
    <td>Stage of Construction</td>
    <td><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data8['stage_construction_actual_present_completion'] ?? '') ?>
    </span></td>
    <td colspan="2">% of work completed at last visit:</td>
    <td><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data8['stage_construction_recommend_present_completion'] ?? '') ?>
    </span></td>
  </tr>
   <tr>
    <td>LAST VISIT DATE </td>
    <td><span style="display: inline-block; min-width: 50px; padding: 2px;">
 <?= htmlspecialchars(date('d M Y h:i A', strtotime($data1['report_assigned_at'] ?? ''))) ?>
    </span></td>
    <td colspan="2">% of work completed at ON DATE:</td>
    <td><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data8['total_completion_present'] ?? '') ?>
    </span></td>
  </tr>
  <tr><td colspan="5" class="section-title">Section 4.Specification & Maintenance</td></tr>
  <tr>
    <td>Foundation/Roof/Flooring</td>
    <td colspan="4"><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data4['roof_type'] ?? '') ?>
    </span></td>
  </tr>
  <tr>
    <td>Construction Quality</td>
    <td colspan="4"><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars('Average') ?>
    </span></td>
  </tr>
  <tr>
    <td>Maintenance</td>
    <td colspan="4"><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars('Average') ?>
     </span></td>
  </tr>

  <tr><td colspan="5" class="section-title">SECTION 5. Local Authority Compliance & Safety Aspects</td></tr>
  <tr>
    <td class="section-title">Whether excess construction can be regularised by way of paying fee/penalty</td>
    <td colspan="4" class="section-title"><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data10['NA'] ?? '') ?>
    </span></td>
  </tr>
  <tr>
    <td class="section-title">Risk of Demolition</td>
    <td colspan="4" class="section-title"><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data8['demolition_risk_1'] ?? '') ?>
    </span></td>
  </tr>
  <tr>
    <td colspan="3">Setbacks(AS PER GOVERNMENT BY LAWS)</td>
    <TD colspan="2">ACTUAL SETBACKS </TD>
  </tr>
  <tr>
    <td>Front</td>
    <td colspan="2"><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data10['NA'] ?? '') ?>
    </span></td>
    <td colspan="2"><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data10['NA'] ?? '') ?>
    </span></td>
  </tr>
  <tr>
    <td>No.</td>
    <td colspan="2"><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data10['NA'] ?? '') ?>
    </span></td>
    <td colspan="2"><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data10['NA'] ?? '') ?>
    </span></td>
  </tr>
  <tr>
    <td>Type of Structure</td>
    <td colspan="4"><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data4['structure_type'] ?? '') ?>
    </span></td>
  </tr>
    <tr>
    <td>NO. OF FLOORS(PERMISSIBLE & ACTUAL )</td>
    <td colspan="4"><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data8['actual_configuration_building'] ?? '') ?>
    </span></td>
  </tr>
  <tr>
    <td>No. of Wings </td>
    <td colspan="4"><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data10['NA'] ?? '') ?>
    </span></td>
  </tr>
    <tr>
    <td>No.of Flat on each Floor </td>
    <td colspan="4"><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data10['NA'] ?? '') ?>
    </span></td>
  </tr>
    <tr>
    <td>Internal composition of the property(no of rooms, kitchen, hall, w/c, bathroom/varanda)
   </td>
    <td colspan="4"><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data8['actual_configuration_building'] ?? '') ?>
    </span></td>
  </tr>
  <tr>
    <td>No. of lifts in each wings  </td>
    <td colspan="4"><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data8['number_of_lifts'] ?? '') ?>
    </span></td>
  </tr>
  <tr>
    <td>Construction as per approved sanctioned plans </td>
    <td colspan="4"><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data9['floor_availability'] ?? '') ?>
    </span></td>
  </tr>
  <tr>
    <td>Details of approved plan and plans with approval no and date </td>
    <td colspan="4"><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data10['NA'] ?? '') ?>
    </span></td>
  </tr>
   <tr>
    <td>Construction permission number and date</td>
    <td colspan="4"><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data10['NA'] ?? '') ?>
    </span></td>
  </tr>
   <tr>
    <td>Violation observed if any Or is there any risk of demolition in case of violation</td>
    <td colspan="4"><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data10['NA'] ?? '') ?>
    </span></td>
  </tr>
   <tr>
    <td>Structure confirming to safety (load resistance)  </td>
    <td colspan="4"><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data10['NA'] ?? '') ?>
    </span></td>
  </tr>
   <tr>
    <td>As per visual inspections & maintenance levels- Does the Structure raise any co </td>
    <td colspan="4"><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data10['NA'] ?? '') ?>
    </span></td>
  </tr>
  <tr>
    <td>event of earthquake, cyclones etc.</td>
    <td colspan="4"><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data10['NA'] ?? '') ?>
    </span></td>
  </tr>
  <tr>
    <td colspan="5">Applicable in case of multistorey buildings</td>
    </tr>
  
</table>


<table>
  <tr><td class="section-title" colspan="6">Section 6. Valuation (area to be mentioned in feet only)</td></tr>
  <tr><th colspan="6">VALUE AS PER GOVERNMENT</th></tr>
  <tr>
    <th rowspan="2">Particulars</th>
    <th rowspan="2">AREA</th>
    <th rowspan="2">RATE</th>
  </tr>
  <tr>
    <th>Particulars</th>
    <th colspan="2">VALUE IN RS.</th>
  </tr>
  <tr>
    <td><span>Cost of Land Sqft</span></td>
    <td><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data6['gov_plot_area_sqft'] ?? '') ?>
    </span></td>
    <td><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data6['gov_plot_area_rate'] ?? '') ?>
    </span></td>
    <td><span>DLC Value in Rs.</span></td>
    <td colspan="2"><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data6['gov_plot_area_valuation'] ?? '') ?>
    </span></td>

  </tr>
  <tr>
    <td>
      <span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data6['gov_construction_name1'] ?? '') ?>
    </span>
  </td>
    <td>
      <span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data6['gov_construction_area1'] ?? '') ?>
    </span>
  </td>
    <td>
      <span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data6['gov_construction_rate1'] ?? '') ?>
    </span>
  </td>
    <td>
      <span>Market Value in Rs.</span>
    </td>
   <td colspan="2">
 <span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data6['gov_construction_valuation1'] ?? '') ?>
    </span>
</td>

  </tr>

  <tr>
    <td>
      <span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data6['gov_construction_name2'] ?? '') ?>
    </span>
  </td>
    <td>
      <span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data6['gov_construction_area2'] ?? '') ?>
    </span>
  </td>
    <td>
      <span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data6['gov_construction_rate2'] ?? '') ?>
    </span>
  </td>
    <td>
      <span>Market Value in Rs.</span>
    </td>
    <td colspan="2">
     
  <span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data6['gov_construction_valuation2'] ?? '') ?>
    </span>
  </td>
  </tr>
  <tr>
    <td colspan="5"><strong>Total Cost of Property as per Govt.</strong></td>
    <td>  <span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data6['gov_final_area_valuation'] ?? '') ?>
    </span></td>
  </tr>
  <tr>
    <td colspan="5"><strong>Total Cost of Existing property (As on date)</strong></td>
    <td><span style="display: inline-block; min-width: 50px; padding: 2px;">
<?php
$plotValuation = floatval($data6['plot_valuation_computed'] ?? 0);
$constructionValue = floatval($data6['construction_area_sqft_1'] ?? 0) * floatval($data6['construction_rate'] ?? 0);
$total = $plotValuation + $constructionValue;
?>

<?= htmlspecialchars($total) ?>
    </span></td>
  </tr>
</table>

<table>
  <tr><td class="section-title" colspan="9">MARKET VALUE</td></tr>
  <tr>
    <th>Particulars</th>
    <th colspan="2">AREA</th>
    <th>RATE</th>
    <th>Particulars</th>
    <th colspan="4">VALUE IN RS.</th>
  </tr>
  <tr>
    <td><span>Cost of Land Sqft</span></td>
    <td colspan="2"><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data6['final_plot_square_feet'] ?? '') ?>
    </span></td>
    <td><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data6['final_plot_rate'] ?? '') ?>
    </span></td>
    <td><span>Market Rate</span></td>
    <td colspan="4"><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data6['finally_plot_valuation'] ?? '') ?>
    </span></td>
  </tr>
  <tr>
    <td ><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data6['construction_name_1'] ?? '') ?>
    </span></td>
    <td colspan="2"><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data6['construction_area_sqft_1'] ?? '') ?>
    </span></td>
    <td><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data6['construction_rate_1'] ?? '') ?>
    </span></td>
    <td><span>Market Value in Rs.</span></td>
    <td colspan="4"><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data6['construction_valuation_1'] ?? '') ?>
    </span></td>
  </tr>
  <tr>
<td><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data6['construction_name_2'] ?? '') ?>
    </span></td>
    <td colspan="2"><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data6['construction_area_sqft_2'] ?? '') ?>
    </span></td>
    <td><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data6['construction_rate_2'] ?? '') ?>
    </span></td>
    <td><span>Market Value in Rs.</span></td>
    <td colspan="4"><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data6['construction_valuation_2'] ?? '') ?>
    </span></td>
  </tr>
  <tr>
    <td><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data6['construction_name_3'] ?? '') ?>
    </span></td>
    <td colspan="2"><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data6['construction_area_sqft_3'] ?? '') ?>
    </span></td>
    <td><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data6['construction_rate_3'] ?? '') ?>
    </span></td>
    <td><span>Market Value in Rs.</span></td>
    <td colspan="4"><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data6['construction_valuation_3'] ?? '') ?>
    </span></td>
  </tr>
  <tr>
    <td colspan="4"><strong>Total Cost Of Property</strong></td>
    <td colspan="5"><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data6['total_finally_area_valuation'] ?? '') ?>
    </span></td>
  </tr>
  <tr>
  <td colspan="4"><strong>REALISABLE VALUE</strong></td>
  <td colspan="4"><strong>DISTRESS VALUE</strong></td>
  <td colspan="2"><strong>GOVT VALUE</strong></td>
  </tr>
  <tr>
   <td colspan="4">  
        <input type="text" 
               readonly 
               value="<?= isset($data6['total_finally_area_valuation']) ? round($data6['total_finally_area_valuation'] * 0.91, 2) : '' ?>" 
               name="">
    </td>
    <td colspan="4"><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data6['total_distress_value'] ?? '') ?>
    </span></td>
    <td colspan="2"><span style="display: inline-block; min-width: 50px; padding: 2px;">
<?php
$plotValuation = floatval($data6['plot_valuation_computed'] ?? 0);
$constructionValue = floatval($data6['construction_area_sqft_1'] ?? 0) * floatval($data6['construction_rate'] ?? 0);
$total = $plotValuation + $constructionValue;
?>

<?= htmlspecialchars($total) ?>
    </span></td>
  </tr>
  <tr>
    <td><strong>Land Cost</strong></td>
    <td colspan=""> <input type="text" 
               readonly 
                 value="<?= isset($data6['finally_plot_valuation']) ? round($data6['finally_plot_valuation'] * 0.91, 2) : '' ?>" 
               name="">
</td>
    <td><strong>Build Cost</strong></td>
    <td colspan=""><input type="text" 
               readonly 
               value="<?= isset($data6['finally_construction_valuation']) ? round($data6['finally_construction_valuation'] * 0.91, 2) : '' ?>" 
               name=""></td>
    <td><strong>Land Cost</strong></td>
    <td colspan=""><input type="text" 
               readonly 
                 value="<?= isset($data6['finally_plot_valuation']) ? round($data6['finally_plot_valuation'] * 0.80, 2) : '' ?>" 
               name=""></td>
     <td><strong>Build Cost</strong></td>
    <td colspan="2"><input type="text" 
               readonly 
               value="<?= isset($data6['finally_construction_valuation']) ? round($data6['finally_construction_valuation'] * 0.80, 2) : '' ?>" 
               name=""></td>
  </tr>
  <tr>
    <td rowspan="3"> <strong> PRICE COMFIRM FROM </strong></td>
    <td colspan="8"> Local Property Dealer / Local Person NAME (should not be blank) </td>
  </tr>
  <tr>
    <td colspan="8"> Local Dealer No. / Local Dealer Shop Name (should not be blank) </td>
  </tr>
  <tr>
    <td colspan="8"> Value Rate according to Me (should not be blank) 
    </td>
  </tr>
</table>
<table>
  <tr><td class="section-title" colspan="4">Section 8.REMARKS</td></tr>
  <tr>
    <td class="remark-list" colspan="4">
    <span style="white-space: pre-line; font-size:14px; display: block; text-align: left; padding: 0; margin: 0;">
        <?= htmlspecialchars($data10['remarks'] ?? '') ?>
    </span>
    </td>
  </tr>
  <tr>
    <td class="section-title" colspan="4">Section 9.DECLARATION</td>
  </tr>
  <tr>
    <td class="remark-list" colspan="4">
     <span style="display: inline-block; min-width: 50px; padding: 2px;" style="width:100%; height:90px; border:none;outline:none;" rows="10"  id="remarks" name="engineer_id" oninput="autoResize(this)"><?= $data10['declaration'] ?? '' ?></span>
    </td>
  </tr>
 <table>
<tr><th style="margin-bottom:-18px;">PHOTOGRAPH OF THE PROPERTY</tr></th></table>
<br>

    
<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

$servername = "localhost";
$username   = "root";
$password   = "";
$dbname     = "project_db";

$conn = new mysqli($servername, $username, $password, $dbname);
if ($conn->connect_error) {
    die("Connection failed: " . htmlspecialchars($conn->connect_error));
}

$reference_id = $_SESSION['reference_id'] ?? null;
$reference_id = $_GET['reference_id'] ?? $reference_id;

if ($reference_id) {

    // Map captions
    $captions = [
        'image1'  => 'EXTERNAL PHOTOS',
        'image2'  => 'Kitchen',
        'image3'  => 'Selfie',
        'image4'  => 'Electric Meter',
        'image6'  => 'Other 1',
        'image7'  => 'Other 2',
        'image8'  => 'Other 3',
        'image9'  => 'Other 4',
        'image10' => 'Other 5',
        'image11' => 'Other 6',
        'image12' => 'Other 7',
        'image13' => 'Other 8',
        'image14' => 'Other 9',
        'image15' => 'Other 10',
        'image16' => 'Other 11',
        'image17' => 'Other 12',
        'image18' => 'Other 13',
        'image19' => 'Other 14',
        'image20' => 'Other 15',
    ];

    // === Helper: EXIF-aware orientation detection ===
    function classify_orientation_after_exif(string $imageData): ?string {
        $size = @getimagesizefromstring($imageData);
        if (!$size || !isset($size[0], $size[1])) {
            return null;
        }
        $width  = (int)$size[0];
        $height = (int)$size[1];

        $mime = $size['mime'] ?? '';
        if ($mime === 'image/jpeg' && function_exists('exif_read_data')) {
            $tmp = @tempnam(sys_get_temp_dir(), 'exif_');
            if ($tmp !== false) {
                @file_put_contents($tmp, $imageData);
                $exif = @exif_read_data($tmp);
                @unlink($tmp);

                if (!empty($exif['Orientation'])) {
                    $orientation = (int)$exif['Orientation'];
                    if ($orientation === 6 || $orientation === 8) {
                        $t = $width; $width = $height; $height = $t;
                    }
                }
            }
        }
        return ($width >= $height) ? 'horizontal' : 'vertical';
    }

    // === Helper: Fix orientation physically with Imagick ===
    function fixImageOrientation($binaryData) {
        $img = new Imagick();
        $img->readImageBlob($binaryData);

        switch ($img->getImageOrientation()) {
            case Imagick::ORIENTATION_BOTTOMRIGHT:
                $img->rotateImage("#000", 180);
                break;
            case Imagick::ORIENTATION_RIGHTTOP:
                $img->rotateImage("#000", 90);
                break;
            case Imagick::ORIENTATION_LEFTBOTTOM:
                $img->rotateImage("#000", -90);
                break;
        }

        $img->setImageOrientation(Imagick::ORIENTATION_TOPLEFT);
        $fixed = $img->getImageBlob();
        $img->destroy();

        return $fixed;
    }

    $sql = "SELECT 
                image1, image2, image3, image4, 
                image6, image7, image8, image9, 
                image10, image11, image12, image13, image14, image15, image16, image17, image18, image19, image20
            FROM final_uploaded_images 
            WHERE reference_id = ?";

    $stmt = $conn->prepare($sql);
    if ($stmt === false) {
        die("Error preparing the SQL statement: " . htmlspecialchars($conn->error));
    }

    $stmt->bind_param("s", $reference_id);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result && $result->num_rows > 0) {
        $horizontal_images = [];
        $vertical_images   = [];

        while ($row = $result->fetch_assoc()) {
            foreach ($row as $key => $imageData) {
                if (!empty($imageData)) {

                    // Actually fix image before displaying
                    $fixedData = fixImageOrientation($imageData);

                    $orientation = classify_orientation_after_exif($fixedData) ?? 'horizontal';
                    $imgString   = base64_encode($fixedData);
                    $caption     = $captions[$key] ?? 'Image';

                    $item = [
                        'data'    => $imgString,
                        'caption' => $caption,
                        'alt'     => $key,
                    ];

                    if ($orientation === 'horizontal') {
                        $horizontal_images[] = $item;
                    } else {
                        $vertical_images[]   = $item;
                    }
                }
            }
        }

 
// Output as a stable 4-column table (works in wkhtmltopdf)
$all_images = array_merge($vertical_images, $horizontal_images);

echo '<table class="image-grid">';
$rows = array_chunk($all_images, 4);
foreach ($rows as $row) {
    echo '<tr>';
    foreach ($row as $img) {
        echo '<td>';
        echo '<div class="img-wrap">';
        echo '<img src="data:image/jpeg;base64,' . $img['data'] . '" alt="' . htmlspecialchars($img['alt']) . '">';
        echo '<div class="caption">' . htmlspecialchars($img['caption']) . '</div>';
        echo '</div>';
        echo '</td>';
    }
    // pad remaining cells to keep 4 columns
    $remaining = 4 - count($row);
    if ($remaining > 0) {
        echo str_repeat('<td></td>', $remaining);
    }
    echo '</tr>';
}
echo '</table>';

    } else {
        echo "<p style='text-align:center;'>No images found.</p>";
    }

    $stmt->close();
} else {
    echo "<p style='text-align:center;'>Reference ID is missing.</p>";
}
?>

    
      <table>
  </tr>
  <tr>

<div class="google-map-container">
<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "project_db";
$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$reference_id = $_SESSION['reference_id'] ?? null;
$reference_id = $_GET['reference_id'] ?? $reference_id;

if ($reference_id) {
    $sql = "SELECT image5 FROM final_uploaded_images WHERE reference_id = ?";
    $stmt = $conn->prepare($sql);
    if ($stmt === false) {
        die("Error preparing the SQL statement: " . $conn->error);
    }

    $stmt->bind_param("s", $reference_id);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows > 0) {
        $row = $result->fetch_assoc();
        if (!empty($row['image5'])) {
 
            echo '<div><img src="data:image/jpeg;base64,' . base64_encode($row['image5']) . '" alt="Google Map"><p>Google Map</p></div>';
        } else {
            echo "<p style='text-align:center;'>Google Map image not available.</p>";
        }
    } else {
        echo "<p style='text-align:center;'>No record found for Google Map image.</p>";
    }

    $stmt->close();
} else {
    echo "<p style='text-align:center;'>Reference ID is missing.</p>";
}
?>
</tr>
</div>
    </table>
    </table>
 
 
   <!-- Buttons: Hidden during print -->
<div class="no-print">
  <form method="post">
    <input type="hidden" name="download_images" value="1">
    <button type="submit">Download All Images</button>
  </form>

  <button onclick="setPrintMargins()">DOWNLOAD PDF</button>
</div>

  <script>
    document.getElementById('downloadPdf').addEventListener('click', () => {
      // Select the content you want to convert to PDF
      const element = document.getElementById('content');
      const options = {
        margin:[0,0],
        filename:'report.pdf',
        image: { type: 'jpeg', quality: 0.98 },
        html2canvas: { scale: 2 },
        jsPDF: { unit: 'in', format: 'letter', orientation: 'portrait' }
      };

      // Generate and download the PDF
      html2pdf().set(options).from(element).save();
    });
    function setPrintMargins() {
      const style = document.createElement('style');
      style.innerHTML = `
      @media print {
          body {
            margin:0.5;
          }
        }
      `;
      document.head.appendChild(style);
      window.print();
    }
    // Disable all input fields in the form
    document.querySelectorAll('input').forEach(function(input) {
        input.disabled = true;  // Disables the field completely
    });
     function resizeFakeInput(input) {
    const fake = document.getElementById('fakeWrap');
    fake.textContent = input.value || ' ';
    input.style.height = fake.scrollHeight + 'px';
  }

  // Initialize height
  resizeFakeInput(document.getElementById('longInput'));
   function autoResize(el) {
    el.style.height = 'auto'; // reset height
    el.style.height = el.scrollHeight + 'px'; // set to content height
  }
  // Auto-resize on load
  document.querySelectorAll('.clean-textarea').forEach(t => autoResize(t));
    </script>
</div>
</body>
</html>

