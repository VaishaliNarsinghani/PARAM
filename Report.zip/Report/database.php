  $password = "";


$pass = '';


$password = '';





$conn = new mysqli("localhost", "root", "", "project_db");




$conn = new mysqli("localhost", "root", "", "project_db");