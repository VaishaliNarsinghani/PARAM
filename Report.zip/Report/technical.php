<?php include('auth.php'); ?>
<?php
// Start the session to access session variables
if (isset($_SESSION['report_in_progress'])) {
    $allowed_pages = ['technical2.php', 'technical3.php', 'technical4.php', 'technical5.php',
                      'REPORT6.php', 'technical7.php', 'REPORT8.php', 'technical9.php',
                      'technical10.php', 'technical115.php', 'technical12.php'];

    $current_page = basename($_SERVER['PHP_SELF']);

    if (!in_array($current_page, $allowed_pages)) {
        header("Location: technical3.php"); // Force user back to report
        exit();
    }
}

 

// Database credentials
$host = 'localhost';
$db = 'project_db';
$user = 'root';
$pass = '';

try {
    // Create database connection using PDO
    $conn = new PDO("mysql:host=$host;dbname=$db", $user, $pass);
    $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (PDOException $e) {
    die("Database connection failed: " . $e->getMessage());
}
 
// If the lock is active and this is NOT a report page, then block access
if (isset($_SESSION['report_in_progress'])) {
    $allowed_pages = ['technical2.php', 'technical3.php', 'technical4.php', 'technical5.php', 'REPORT6.php',
                      'technical7.php', 'REPORT8.php', 'technical9.php', 'technical10.php', 'technical115.php', 'technical12.php'];

    $current_page = basename($_SERVER['PHP_SELF']);

    if (!in_array($current_page, $allowed_pages)) {
        // Redirect user to the report page they should be on
        header("Location: technical2.php"); // or whichever page you want them to return to
        exit();
    }
}

// Check if engineer_id is set in session (i.e., user is logged in)
if (!isset($_SESSION['report_id'])) {
    // Redirect to login page if not logged in
    header("Location: login.php");
    exit();
}

$report_id = $_SESSION['report_id'];

// Fetch records from the `mis` table where report_id or report_drafter_to_technical matches the logged-in user
$sql = "SELECT * FROM mis 
        WHERE report_id = :report_id
        AND flag_report_preview != 0 
        AND flag_preview_submit = 0";



        $stmt = $conn->prepare($sql);

// Bind the parameter to the logged-in technical manager's ID
$stmt->bindParam(':report_id', $report_id, PDO::PARAM_STR);

// Execute the query
$stmt->execute();

// Fetch all matching records
$results = $stmt->fetchAll(PDO::FETCH_ASSOC);


?>

<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Magpie Engineering</title>
  <link rel="shortcut icon" href="favicon.ico" type="image/x-icon">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">

  <link rel="stylesheet" href="technical.css">
</head>
  <button class="toggle-btn" id="toggle-btn">☰</button>
  <div class="container">
    <!-- Sidebar -->

    <div class="sidebar" id="sidebar">
      <div style="display: flex;">
        <img class="logo" src="logo.png" alt="">
        <h1>Magpie Engineering</h1>
        </div>
     <div class="rotating-text">Report Drafter</div>
    <a href="clear_and_go_home.php"><i class="fas fa-home icon"></i>Home</a>        

    
  <a href="clear_sessions.php" ><i class="fas fa-clock watch-icon"></i>Pending For Drafting</a>
        <a href="technical.php"class=" active"><i class="fas fa-clipboard-list icon"></i> Preview Report</a>         

    <a href="clear_and_logout.php"><i class="fas fa-sign-out-alt icon"></i>Logout</a>

  </div>
    <!-- Main Content -->
    <div class="content" id="content">
            <div class="search-filters">
                <h2>Search Filters</h2>
                <form id="searchForm" method="POST" action="technical.php">
                <div class="form-row">
            <input type="text" name="reference_id" placeholder="Reference ID" />
            <input type="text" name="customerName" placeholder="Customer Name" />
          </div>
          <div class="form-row">
            <input type="text" name="city" placeholder="City" />
            <input type="text" name="applicationNo" placeholder="Application No." />
          </div>
          <div class="form-row">
            <input type="text" name="bankName" placeholder="Bank Name" />
            <input type="text" name="branchname" placeholder="Branch Name" />
            <input type="text" name="bank_branchname" placeholder="Bank Branch Name" />
            <input type="text" name="caseType" placeholder="Case Type" />
           
          </div>
                    <button type="submit" style="background: #4A90E2;" >Search</button>

   
                    <?php
    if (!empty($results)): ?>
       <table>       <?php         
         ?>
      <table> <tr>
      <th>Reference Number</th>
          <th>Customer Name</th>
          <th>Bank Name</th>
          <th>MEPL Branch Name</th>
          <th>Bank Branch Name</th>
          <th>Application Number</th>
          <th>Customer Mobile Number</th>
          <th>Case Type</th>
          <th>Visit Type</th>
          <th>Address</th>
          <th>Co Applicant Name</th>
          <th>Date</th>
          <th>Assign</th>
        </tr>

        <?php foreach ($results as $task): ?>
        <tr>
            <td data-label="Reference Number"><?= htmlspecialchars($task['reference_id']) ?></td>
            <td data-label="Customer Name"><?= htmlspecialchars($task['customerName']) ?></td>
            <td data-label="Bank Name"><?= htmlspecialchars($task['bankName']) ?></td>
            <td data-label="Branch Name"><?= htmlspecialchars($task['branchname']) ?></td>
             <td data-label="Bank Branch Name"><?= htmlspecialchars($task['bank_branchname']) ?></td>

            <td data-label="Application Number"><?= htmlspecialchars($task['applicationNo']) ?></td>
            <td data-label="Customer Mobile Number"><?= htmlspecialchars($task['customerMob']) ?></td>
            <td data-label="Case Type"><?= htmlspecialchars($task['caseType']) ?></td>
            <td data-label="Visit Type"><?= htmlspecialchars($task['visitType']) ?></td>
            <td data-label="Address"><?= htmlspecialchars($task['address']) ?></td>
        <td data-label="Co Applicant Name"><?= htmlspecialchars($task['co_applicant_name']) ?></td>
           
           
            <td data-label="Date"><?= htmlspecialchars($task['initiationDate']) ?></td>
            <td data-label="Assign">
   <a href="technical3.php?reference_id=<?= urlencode($task['reference_id']) ?>
&customerName=<?= urlencode($task['customerName']) ?>
&bankName=<?= urlencode($task['bankName']) ?>
&branchname=<?= urlencode($task['branchname']) ?>
  &bank_branchname=<?= urlencode($task['bank_branchname']) ?>
&applicationNo=<?= urlencode($task['applicationNo']) ?>
&customerMob=<?= urlencode($task['customerMob']) ?> 
&caseType=<?= urlencode($task['caseType']) ?>
&co_applicant_name=<?= urlencode($task['co_applicant_name']) ?>

&visitType=<?= urlencode($task['visitType']) ?>
&address=<?= urlencode($task['address']) ?>
" 
class="upload-button" style="text-decoration:none;">
    View Report 
</a>


</td>

        </tr>
    <?php endforeach; ?>
      </table>
      <?php endif; ?>
    </div>


  <script>
    const toggleBtn = document.getElementById("toggle-btn");
    const sidebar = document.getElementById("sidebar");

    // Toggle Sidebar
    toggleBtn.addEventListener("click", () => {
      sidebar.classList.toggle("visible");
    });
  </script>
</body>
</html>
                           