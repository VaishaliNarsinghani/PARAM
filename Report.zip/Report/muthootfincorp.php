<?php include('auth.php'); ?>
<?php include 'watermark.html'; ?><?php
ini_set('display_errors', 1);
error_reporting(E_ALL);

// Increase PHP execution time and memory limit
ini_set('max_execution_time', 3000); // 300 seconds = 5 minutes
ini_set('memory_limit', '1024M'); // Increase memory limit to 512MB

// Start session


$servername = "localhost";
$username = "root";
$password ="";
$dbname = "project_db";

// Create DB connection
$conn = new mysqli($servername, $username, $password, $dbname);
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

if (!isset($_SESSION['reference_id'])) {
    die("Reference ID not found in session.");
}
$reference_id = $_SESSION['reference_id'];

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['download_images'])) {

    // Get customer name
    $stmt_name = $conn->prepare("SELECT customerName FROM mis WHERE reference_id = ?");
    $stmt_name->bind_param("s", $reference_id);
    $stmt_name->execute();
    $result_name = $stmt_name->get_result();
    $customerName = "customer";
    if ($row = $result_name->fetch_assoc()) {
        $customerName = preg_replace('/[^a-zA-Z0-9]/', '', $row['customerName']);
    }
    $stmt_name->close();

    // Fetch image BLOBs
    $stmt = $conn->prepare("SELECT image1, image2, image3, image4, image5, image6, image7, image8, image9, image10, image11, image12 FROM final_uploaded_images WHERE reference_id = ?");
    $stmt->bind_param("s", $reference_id);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows > 0 && ($row = $result->fetch_assoc())) {
        $tempDir = sys_get_temp_dir() . DIRECTORY_SEPARATOR . uniqid('images_', true);
        mkdir($tempDir);

        $imageFiles = [];
        for ($i = 1; $i <= 12; $i++) {
            if (!empty($row["image$i"])) {
                $filename = $tempDir . DIRECTORY_SEPARATOR . "image{$i}.jpg";
                file_put_contents($filename, $row["image$i"]);
                $imageFiles[] = $filename;
            }
        }

        if (empty($imageFiles)) {
            die("No images to download.");
        }

        // Create ZIP
        $zipFileName = "images_" . preg_replace('/[^a-zA-Z0-9]/', '_', $reference_id) . "_{$customerName}.zip";
        $zipPath = $tempDir . DIRECTORY_SEPARATOR . $zipFileName;

        $zip = new ZipArchive();
        if ($zip->open($zipPath, ZipArchive::CREATE) !== TRUE) {
            die("Failed to create ZIP file.");
        }

        foreach ($imageFiles as $file) {
            $zip->addFile($file, basename($file));
        }
        $zip->close();

        // Send ZIP to browser
        header('Content-Type: application/zip');
        header('Content-Disposition: attachment; filename="' . basename($zipFileName) . '"');
        header('Content-Length: ' . filesize($zipPath));
        flush();
        readfile($zipPath);

        // Cleanup
        foreach ($imageFiles as $file) {
            unlink($file);
        }
        unlink($zipPath);
        rmdir($tempDir);
        exit;
    } else {
        echo "<p style='color:red;'>No image data found for this reference ID.</p>";
    }
}

$page = isset($_GET['page']) ? $_GET['page'] : 1;
$limit = 50;
$offset = ($page - 1) * $limit;
$sql_property = "SELECT * FROM mis WHERE reference_id = ? LIMIT $limit OFFSET $offset";
$stmt_property = $conn->prepare($sql_property);
$stmt_property->bind_param("s", $reference_id);
$stmt_property->execute();
$result_property = $stmt_property->get_result();
$data1 = $result_property->fetch_assoc();




// Fetch data from property_details table
$sql_property = "SELECT * FROM property_details WHERE reference_id = ?";
$stmt_property = $conn->prepare($sql_property);
$stmt_property->bind_param("s", $reference_id);
$stmt_property->execute();
$result_property = $stmt_property->get_result();
$data2= $result_property->fetch_assoc();




// Fetch data from area_valuation table
$sql_area = "SELECT * FROM address_details WHERE reference_id = ?";
$stmt_area = $conn->prepare($sql_area); 
$stmt_area->bind_param("s", $reference_id);
$stmt_area->execute();
$result_area = $stmt_area->get_result();
$data3 = $result_area->fetch_assoc();





// Fetch data from area_valuation table
$sql_area = "SELECT * FROM critical_parameters WHERE reference_id = ?";
$stmt_area = $conn->prepare($sql_area); 
$stmt_area->bind_param("s", $reference_id);
$stmt_area->execute();
$result_area = $stmt_area->get_result();
$data4 = $result_area->fetch_assoc();

 
// Fetch data from area_valuation table
$sql_area = "SELECT * FROM surroundings_details WHERE reference_id = ?";
$stmt_area = $conn->prepare($sql_area); 
$stmt_area->bind_param("s", $reference_id);
$stmt_area->execute();
$result_area = $stmt_area->get_result();
$data5 = $result_area->fetch_assoc();
$stmt_area->close();
 
// Fetch data from area_valuation table
$sql_area = "SELECT * FROM area_valuation WHERE reference_id = ?";
$stmt_area = $conn->prepare($sql_area); 
$stmt_area->bind_param("s", $reference_id);
$stmt_area->execute();
$result_area = $stmt_area->get_result();
$data6 = $result_area->fetch_assoc();
$stmt_area->close();
 



// Fetch data from area_valuation table
$sql_area = "SELECT * FROM floor_details WHERE reference_id = ?";
$stmt_area = $conn->prepare($sql_area); 
$stmt_area->bind_param("s", $reference_id);
$stmt_area->execute();
$result_area = $stmt_area->get_result();
$data8= $result_area->fetch_assoc();
$stmt_area->close();
 


// Fetch data from area_valuation table
$sql_area = "SELECT * FROM technical_details WHERE reference_id = ?";
$stmt_area = $conn->prepare($sql_area); 
$stmt_area->bind_param("s", $reference_id);
$stmt_area->execute();
$result_area = $stmt_area->get_result();
$data9 = $result_area->fetch_assoc();
$stmt_area->close();
 
// Fetch data from area_valuation table
$sql_area = "SELECT * FROM remarks_table WHERE reference_id = ?";
$stmt_area = $conn->prepare($sql_area); 
$stmt_area->bind_param("s", $reference_id);
$stmt_area->execute();
$result_area = $stmt_area->get_result();
$data10 = $result_area->fetch_assoc();
$stmt_area->close();


// Step 1: Fetch the engineer_id from the mis table
$sql_mis = "SELECT engineer_id FROM mis WHERE reference_id = ?";
$stmt_mis = $conn->prepare($sql_mis);
$stmt_mis->bind_param("s", $reference_id);
$stmt_mis->execute();
$result_mis = $stmt_mis->get_result();
$row_mis = $result_mis->fetch_assoc();
$stmt_mis->close(); 

if ($row_mis) {
    $engineer_id = $row_mis['engineer_id'];

    // Step 2: Fetch the engineer's name from engineer_login table
    $sql_engineer = "SELECT name FROM engineer_login WHERE engineer_id = ?";
    $stmt_engineer = $conn->prepare($sql_engineer);
    $stmt_engineer->bind_param("s", $engineer_id);
    $stmt_engineer->execute();
    $result_engineer = $stmt_engineer->get_result();
    $row_engineer = $result_engineer->fetch_assoc();
    $stmt_engineer->close();

    if ($row_engineer) {
        $engineer_name = $row_engineer['name'];
//         //echo "Engineer Name: " . $engineer_name;
    } else {
//        echo "Engineer not found.";
    }
} else {
    echo "No engineer assigned for this reference_id.";
}



// Step 1: Fetch the engineer_id from the mis table
$sql_mis = "SELECT report_id FROM mis WHERE reference_id = ?";
$stmt_mis = $conn->prepare($sql_mis);
$stmt_mis->bind_param("s", $reference_id);
$stmt_mis->execute();
$result_mis = $stmt_mis->get_result();
$row_mis = $result_mis->fetch_assoc();
$stmt_mis->close(); 

if ($row_mis) {
    $report_id = $row_mis['report_id'];

    // Step 2: Fetch the engineer's name from engineer_login table
    $sql_engineer = "SELECT name FROM report_login WHERE report_id = ?";
    $stmt_engineer = $conn->prepare($sql_engineer);
    $stmt_engineer->bind_param("s", $report_id);
    $stmt_engineer->execute();
    $result_engineer = $stmt_engineer->get_result();
    $row_engineer = $result_engineer->fetch_assoc();
    $stmt_engineer->close();

    if ($row_engineer) {
        $report_name = $row_engineer['name'];
 //        //echo "Engineer Name: " . $report_name;
    } else {
 //       echo "Engineer not found.";
    }
} else {
    echo "No engineer assigned for this reference_id.";
}


// Step 1: Fetch the engineer_id from the mis table
$sql_mis = "SELECT report_drafter_to_technical FROM mis WHERE reference_id = ?";
$stmt_mis = $conn->prepare($sql_mis);
$stmt_mis->bind_param("s", $reference_id);
$stmt_mis->execute();
$result_mis = $stmt_mis->get_result();
$row_mis = $result_mis->fetch_assoc();
$stmt_mis->close(); 

if ($row_mis) {
    $report_drafter_to_technical = $row_mis['report_drafter_to_technical'];

    // Step 2: Fetch the engineer's name from engineer_login table
    $sql_engineer = "SELECT name FROM technical_login WHERE technical_manager_id = ?";
    $stmt_engineer = $conn->prepare($sql_engineer);
    $stmt_engineer->bind_param("s", $report_drafter_to_technical);
    $stmt_engineer->execute();
    $result_engineer = $stmt_engineer->get_result();
    $row_engineer = $result_engineer->fetch_assoc();
    $stmt_engineer->close();

    if ($row_engineer) {
        $technical_name = $row_engineer['name'];
   //     //echo "Engineer Name: " . $technical_name;
    } else {
   //     echo "Engineer not found.";
    }
} else {
    echo "No engineer assigned for this reference_id.";
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <style>
        .container {
            width: 90%;
            margin: 20px auto;
            border: 1px solid black;
            padding: 20px;
        }
.header-content {
    text-align: center;
    flex: 1;
}

.header-content h1 {
    margin: 0;
    margin-top:25px;  
    font-size: 25px;
    color: #902d2d;
}

.header-content p {
    margin: 2px 0;
    font-size: 20px;
    color: #333;
}
.footer{
    display: flex;
}
h3{
    background-color:rgb(243, 234, 222) ;
    padding:5px;
    text-align: center;
    border:1px solid black;
}                     
      table {
        width: 100%;
        border-collapse: collapse;
        font-family: Arial, sans-serif;
        font-size: 14px;
    }
    th, td {
        border: 1px solid black;
        padding: 4px 6px;
        vertical-align: top;
    }
    th.section-header {
        background-color: #e6e6e6;
        text-align: center;
        font-weight: bold;
    }
    span[contenteditable="true"] {
        display: inline-block;
        min-width: 80px;
    }


</style>
<style>
.container {
    max-width: 1200px;
    margin: 20px auto;
    padding: 20px;
    background-color: white;
    box-shadow: 0px 0px 10px rgba(0, 0, 0, 0.1);
    border-radius: 8px;
}

.title {
    text-align: center;
    font-size: 24px;
    font-weight: bold;
    margin-bottom: 20px;
}
.grid-container {
    display: grid;
    grid-template-columns: repeat(4, 1fr);
    gap: 15px;
}

.grid-item {
    position: relative;
    border-radius: 8px;
    overflow: hidden;
    box-shadow: 0px 4px 6px rgba(0, 0, 0, 0.1);
}

.grid-item img {
    width: 100%;
    height: 200px;
    object-fit: cover;
    transition: transform 0.3s ease;
}
.grid-item:hover img {
    transform: scale(1.05);
}

.overlay {
    position: absolute;
    bottom: 0;
    left: 0;
    background: rgba(0, 0, 0, 0.6);
    color: white;
    width: 100%;
    padding: 8px;
    font-size: 14px;
    text-align: center;
}
 
   
/* Force a stable 4-column grid that wkhtmltopdf respects */
.image-gallery { width: 100%; }
.image-grid { width: 100%; border-collapse: collapse; table-layout: fixed; }
.image-grid tr { page-break-inside: avoid; }
.image-grid td { width: 25%; padding: 6px; vertical-align: top; }

.image-grid .img-wrap { display: block; }
.image-grid img { display: block; width: 100%; height: auto; }
.image-grid .caption { font-size: 12px; text-align: center; margin-top: 4px; }

/* If you had a flex layout before, neutralize it */
.image-gallery { display: block !important; }



    /* Print-specific rules */
    @media print {
      .no-print {
        display: none !important;
      }

      body {
        margin: 0;
      }
 
    }
  button{
    padding:8px;
    margin-left:45%;
    background-color:#808485;
    color:white;
    font-weight:700;
    font-style:italic;
  }
  button:hover{
    background-color:rgba(216,216,216,255);
    color:white;
  }
input{
    border:none;
}
/* Optional: Google map styling */
    .google-map-container {
      max-width: 90%;
      margin: 20px auto;
      border: 2px solid #ccc;
      padding: 10px;
      box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
      background-color: #f9f9f9;
      border-radius: 8px;
      text-align: center;
    }

    .google-map-container img {
      max-width: 100%;
      height: auto;
      display: inline-block;
      border: 1px solid #999;
      border-radius: 4px;
    }
    
.logo img {
  width: 120px;
  margin-left:30px;
  height: auto;
}
</style>
</head>
<body>
     <div class="container">
        <header>
            <div class="footer">
            <div class="logo">
               <img src="images/logo.png" alt="Magpie Logo">
            </div>
            <div class="header-content">
                <h1> MAGPIE ENGINEERING PVT. LTD. </h1>
                <p>  Valuer Designer Architects </p>
                <p>  Reg.Add,:5th Floor,E-509,Casa Green,A.B.Road,Talawall Chanda,Indore(M.P)-453771 </p>
                <p>  Office No.201,2nd floor,Gravity Mall,Mechanic Nagar,Warehouse Road Near Vijay Nagar,Indore,Madhya Pradesh-452011 </p>    
            </div>
            </div>
        </header>
    <table>
    <tr>
        <th class="section-header" colspan="4"> TECHNICAL I - VALUATION REPORT</th>
    </tr>
    <tr>
        <td><strong>Verification Type</strong></td>
        <td colspan="3"><span style="display: inline-block; min-width: 50px; padding: 2px;">TECHNICAL I </span></td>
        
    </tr>
    <tr>
     <td><strong>Reference No.</strong></td>
        <td colspan="3"><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data1['reference_id'] ?? '') ?></span></td>
    </tr>
    <tr>
        <td><strong> Valuer Name, Contact Details, Email ID & Code </strong></td>
        <td colspan="3"><span style="display: inline-block; min-width: 50px; padding: 2px;">
       MAGPIE ENGINEERING PVT.LTD.  indoresaa@gmail.com </span></td>
    </tr>

    <tr>
        <td><strong>Muthoot Fincorp Ltd Processing Centre Name</strong></td>
        <td colspan="3"><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data1['bank_branchname'] ?? '') ?></span></td>
    </tr>

    <tr>
        <td><strong>Loan Application Number</strong></td>
        <td colspan="3"><span style="display: inline-block; min-width: 50px; padding: 2px;"> <?= htmlspecialchars($data1['applicationNo'] ?? '') ?></span></td>
    </tr>
    <tr>
        <td><strong>Name of Applicant</strong></td>
        <td colspan="3"><span style="display: inline-block; min-width: 50px; padding: 2px;"> <?= htmlspecialchars($data1['customerName'] ?? '') ?></span></td>
      
    </tr>
    <tr>
        <td><strong>Name of Co-Applicant</strong></td>
        <td colspan="3"><span style="display: inline-block; min-width: 50px; padding: 2px;"> <?= htmlspecialchars($data1['co_applicant_name'] ?? '') ?></span></td>
    </tr>
    <tr>
        <td><strong>Product</strong></td>
        <td colspan="3"><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data1['caseType'] ?? '') ?></span></td>
    </tr>
    <tr>
           <td><strong>Loan Type</strong></td>
        <td colspan="3"><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data2['project_approval_status'] ?? '') ?></span></td>
    </tr>
    <tr>
        <td><strong> Distance from Muthoot Fincorp Ltd Processing Centre in Km </strong></td>
        <td colspan="3"><span style="display: inline-block; min-width: 50px; padding: 2px;">
           <?= htmlspecialchars($data3['distance_from_branch_kms'] ?? '') ?></span></td>
    </tr>
</table>
<table>
    <tr>
        <th class="section-header" colspan="5"> GENERAL DETAILS: </th>
    </tr>
    <tr>
        <td class="number-col">1</td>
        <td>Property Jurisdiction</td>
        <td colspan="3"><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data2['project_id'] ?? '') ?></span></td>
    </tr>
    <tr>
        <td class="number-col">2</td>
        <td>Property Type</td>
        <td colspan="3"><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data2['property_unit_type'] ?? '') ?></span></td>
    </tr>
    <tr>
        <td class="number-col">3</td>
        <td>Locality Type</td>
        <td colspan="3"><span style="display: inline-block; min-width: 50px; padding: 2px;"><?= htmlspecialchars($data2['class_of_locality'] ?? '') ?></span></td>
    </tr>
    <tr>
        <td class="number-col">4</td>
        <td>Amenities Available</td>
        <td colspan="3"><span style="display: inline-block; min-width: 50px; padding: 2px;"><?= htmlspecialchars($data10['NA'] ?? '') ?></span></td>
    </tr>
    <tr>
        <td class="number-col">5</td>
        <td>Date on which Visit is done</td>
        <td colspan="3"><span style="display: inline-block; min-width: 50px; padding: 2px;"><?= htmlspecialchars($data1['fe_to_coordinator_assign_at'] ?? '') ?></span></td>
    </tr>
    <tr>
        <td class="number-col">6</td>
        <td>Has the Valuer Done Valuation of this Property Previously? If yes, When and for Whom</td>
        <td colspan="3"><span style="display: inline-block; min-width: 50px; padding: 2px;">
            <?= htmlspecialchars('NO') ?></span></td>
    </tr>
    <tr>
        <td class="number-col">7</td>
        <td>Persons Name & Contact No. available During Visit</td>
        <td colspan="3"><span style="display: inline-block; min-width: 50px; padding: 2px;"><?= htmlspecialchars($data2['person_meet_at_site_contact'] ?? '') ?></span></td>
    </tr>

    <!-- Description Header -->
    <tr>
        <th colspan="1"> </th>
        <th>Description</th>
        <th>As per Ownership Documents</th>
        <th>As per Approved plans</th>
        <th>As per Physical visit</th>
    </tr>
    
    <tr>
        <td class="number-col">8</td>
        <td> Name of the Property Owner </td>
        <td><span style="display: inline-block; min-width: 50px; padding: 2px;"><?= htmlspecialchars($data9['owner_name'] ?? '') ?></span></td>
        <td><span style="display: inline-block; min-width: 50px; padding: 2px;"><?= htmlspecialchars($data10['NA'] ?? '') ?></span></td>
        <td><span style="display: inline-block; min-width: 50px; padding: 2px;"><?= htmlspecialchars($data9['owner_name'] ?? '') ?></span></td>
    </tr>
    <tr>
        <td class="number-col">9</td>
        <td> Property Address as per Ownership Documents </td>
        <td colspan="3"><span style="display: inline-block; min-width: 50px; padding: 2px;"><?= htmlspecialchars($data3['address_per_document'] ?? '') ?></span></td>
    </tr>
    <tr>
        <td class="number-col">10</td>
        <td> Property Address as per Approved Plan </td>
        <td colspan="3"><span style="display: inline-block; min-width: 50px; padding: 2px;"><?= htmlspecialchars($data4['abutting_agriculture_land'] ?? '') ?></span></td>
       
    </tr>
    <tr>
        <td class="number-col">11</td>
        <td>Property Address as per Site Visit</td>
        <td colspan="3"><span style="display: inline-block; min-width: 50px; padding: 2px;"><?= htmlspecialchars($data3['address_per_site'] ?? '') ?></span></td>
    </tr>
    <tr>
        <td class="number-col">12</td>
        <td>State</td>
        <td colspan="3"><span style="display: inline-block; min-width: 50px; padding: 2px;"><?= htmlspecialchars($data3['address_line_4_as_per_doc'] ?? '') ?></span></td>
    </tr>
    <tr>
        <td class="number-col">13</td>
        <td>Pin Code</td>
        <td colspan="3"><span style="display: inline-block; min-width: 50px; padding: 2px;"><?= htmlspecialchars($data3['pin_code'] ?? '') ?></span></td>
    </tr>
    <tr>
        <td class="number-col">14</td>
        <td>GPS Coordinates</td>
        <td>Latitude: <span style="display: inline-block; min-width: 50px; padding: 2px;"><?= htmlspecialchars($data3['latitude_value'] ?? '') ?></span></td>
        <td>Longitude: <span style="display: inline-block; min-width: 50px; padding: 2px;"><?= htmlspecialchars($data3['longitude_value'] ?? '') ?></span></td>
        <td></td>
    </tr>
    <tr>
        <td class="number-col">15</td>
        <td>Nearest Landmark</td>
        <td colspan="3"><span style="display: inline-block; min-width: 50px; padding: 2px;"><?= htmlspecialchars($data3['landmark_1'] ?? '') ?> <?= htmlspecialchars($data3['landmark_2'] ?? '') ?></span></td>
    </tr>
    <tr>
        <td class="number-col">16</td>
        <td>Within The Limits Of</td>
        <td colspan="3"><span style="display: inline-block; min-width: 50px; padding: 2px;"><?= htmlspecialchars($data3['property_location_in'] ?? '') ?></span></td>
    </tr>

    <!-- Particulars Header -->
    <tr>
        <th colspan="2">Particulars</th>
        <th>Name</th>
        <th colspan="2">Distance in Km</th>
    </tr>
    <tr>
        <td class="number-col">17</td>
        <td> Nearest Railway Station from property </td>
        <td><span style="display: inline-block; min-width: 50px; padding: 2px;">
            <?= htmlspecialchars($data3['nearest_railway_station_name'] ?? '') ?></span></td>
        <td colspan="2"><span style="display: inline-block; min-width: 50px; padding: 2px;">
            <?= htmlspecialchars($data3['nearest_railway_station_distance'] ?? '') ?></span></td>
    </tr>
    <tr>
        <td class="number-col">18</td>
        <td> Nearest Bus Station from property </td>
        <td><span style="display: inline-block; min-width: 50px; padding: 2px;">
            <?= htmlspecialchars($data3['nearest_bus_stop_name'] ?? '') ?></span></td>
        <td colspan="2"><span style="display: inline-block; min-width: 50px; padding: 2px;">
            <?= htmlspecialchars($data3['nearest_bus_stop_distance'] ?? '') ?></span></td>
    </tr>
    <tr>
        <td class="number-col">19</td>
        <td> Nearest State Highway from property </td>
        <td><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data10['NA'] ?? '') ?></span></td>
        <td colspan="2"><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data10['NA'] ?? '') ?></span></td>
    </tr>
    <tr>
        <td class="number-col">20</td>
        <td> Nearby Market,Hospital, School, College and Police Station with Distance </td>
        <td colspan="3"><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data3['nearest_bus_stop_distance'] ?? '') ?></span></td>
    </tr>
</table>
<table>
    <!-- DOCUMENT DETAILS HEADER -->
    <tr>
        <th class="section-header" colspan="5"> DOCUMENT DETAILS: </th>
    </tr>
    <tr>
        <th class="number-col"></th>
        <th> Particulars </th>
        <th> Date </th>
        <th> Ref. No. </th>
        <th> Registrar office/ Competent Authority</th>
    </tr>
    <!-- Document details rows -->
    <tr>
        <td class="number-col">21</td>
        <td>Ownership Documents - Registered Deed</td>
        <td><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data9['ownership2_details'] ?? '') ?></span></td>
        <td><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data9['ownership1_details'] ?? '') ?></span></td>
        <td><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data9['ownership1_document'] ?? '') ?></span></td>
    </tr>
    <tr>
        <td class="number-col">22</td>
        <td>Ownership Documents - Registered Deed</td>
        <td><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data10['NA'] ?? '') ?></span></td> 
        <td><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data10['NA'] ?? '') ?></span></td>
        <td><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data10['NA'] ?? '') ?></span></td>
    </tr>
    <tr>
        <td class="number-col">23</td>
        <td>Sale Agreement</td>
        <td><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data10['NA'] ?? '') ?></span></td>
        <td><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data10['NA'] ?? '') ?></span></td>
        <td><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data9['ownership2_document'] ?? '') ?></span></td>
    </tr>

    <tr>
        <td class="number-col">24</td>
        <td>RERA registration certificate</td>
        <td><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data10['NA'] ?? '') ?></span></td>
        <td><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data9['location_details'] ?? '') ?></span></td>
        <td><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data10['NA'] ?? '') ?></span></td>
    </tr>
    <tr>
        <td class="number-col">25</td>
        <td>Layout Plan</td>
        <td><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data9['layout_authority'] ?? '') ?></span></td>
        <td><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data10['NA'] ?? '') ?></span></td>
        <td><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data9['layout_details'] ?? '') ?></span></td>
    </tr>
    <tr>
        <td class="number-col">26</td>
        <td>Approved Building Plan</td>
        <td><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data9['floor_document'] ?? '') ?></span></td>
        <td><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data9['floor_authority'] ?? '') ?></span></td>
        <td><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data9['floor_details'] ?? '') ?></span></td>
    </tr>
    <tr>
        <td class="number-col">27</td>
        <td>Commencement Certificate / Construction Permission</td>
        <td><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data10['NA'] ?? '') ?></span></td>
        <td><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data10['NA'] ?? '') ?></span></td>
        <td><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data10['NA'] ?? '') ?></span></td>
    </tr>
    <tr>
        <td class="number-col">28</td>
        <td>Occupancy Certificate/ Completion Certificate</td>
        <td><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data10['NA'] ?? '') ?></span></td>
        <td><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data10['NA'] ?? '') ?></span></td>
        <td><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data10['NA'] ?? '') ?></span></td>
    </tr>

    <tr>
        <td class="number-col">29</td>
        <td>Property Tax Paid Bill Latest</td>
        <td><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data10['NA'] ?? '') ?></span></td>
        <td><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data10['NA'] ?? '') ?></span></td>
        <td><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data10['NA'] ?? '') ?></span></td>
    </tr>

    <tr>
        <td class="number-col">30</td>
        <td>Building Estimation</td>
        <td><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data10['NA'] ?? '') ?></span></td>
        <td><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data10['NA'] ?? '') ?></span></td>
        <td><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data10['NA'] ?? '') ?></span></td>
    </tr>

    <tr>
        <td class="number-col">31</td>
        <td>Khata</td>
        <td><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data10['NA'] ?? '') ?></span></td>
        <td><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data10['NA'] ?? '') ?></span></td>
        <td><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data10['NA'] ?? '') ?></span></td>
    </tr>

    <tr>
        <td class="number-col">32</td>
        <td>NA Conversion Order</td>
        <td><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data10['NA'] ?? '') ?></span></td>
        <td><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data10['NA'] ?? '') ?></span></td>
        <td><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data10['NA'] ?? '') ?></span></td>
    </tr>

    <tr>
        <td class="number-col">33</td>
        <td>Allotment Letter</td>
        <td><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data10['NA'] ?? '') ?></span></td>
        <td><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data10['NA'] ?? '') ?></span></td>
        <td><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data10['NA'] ?? '') ?></span></td>
    </tr>

    <tr>
        <td class="number-col">34</td>
        <td>Patta</td>
        <td><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data10['NA'] ?? '') ?></span></td>
        <td><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data10['NA'] ?? '') ?></span></td>
        <td><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data10['NA'] ?? '') ?></span></td>
    </tr>

    <tr>
        <td class="number-col">35</td>
        <td>Location sketch</td>
        <td><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data10['NA'] ?? '') ?></span></td>
        <td><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data10['NA'] ?? '') ?></span></td>
        <td><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data10['NA'] ?? '') ?></span></td>
    </tr>

    <tr>
        <td class="number-col">36</td>
        <td>Land tax receipt</td>
        <td><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data10['NA'] ?? '') ?></span></td>
        <td><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data10['NA'] ?? '') ?></span></td>
        <td><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data10['NA'] ?? '') ?></span></td>
    </tr>

    <tr>
        <td class="number-col">37</td>
        <td>Others 1</td>
        <td colspan="3"><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data9['nonagricultural_details'] ?? '') ?></span></td>
    </tr>

    <tr>
        <td class="number-col">38</td>
        <td>Others 2</td>
        <td><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data10['NA'] ?? '') ?></span></td>
        <td><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data10['NA'] ?? '') ?></span></td>
        <td><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data10['NA'] ?? '') ?></span></td>
    </tr>

    <tr>
        <td class="number-col">39</td>
        <td>Others 3</td>
        <td><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data10['NA'] ?? '') ?></span></td>
        <td><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data10['NA'] ?? '') ?></span></td>
        <td><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data10['NA'] ?? '') ?></span></td>
    </tr>

    <!-- BOUNDARIES -->
    <tr>
        <th class="section-header" colspan="5">BOUNDARIES:</th>
    </tr>

    <tr>
        <td class="number-col" rowspan="5">40</td>
        <th>Direction</th>
        <th>As per Ownership Documents</th>
        <th>As per Approved plans</th>
        <th>As per Physical Visit</th>
    </tr>

    <tr>
        <td>East</td>
        <td><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data3['direction_as_per_document_east'] ?? '') ?></span></td>
        <td><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data10['NA'] ?? '') ?></span></td>
        <td><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data3['direction_as_per_site_east'] ?? '') ?></span></td>
    </tr>

    <tr>
        
        <td>West</td>
        <td><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data3['direction_as_per_document_west'] ?? '') ?></span></td>
        <td><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data10['NA'] ?? '') ?></span></td>
        <td><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data3['direction_as_per_site_west'] ?? '') ?></span></td>
    </tr>

    <tr>  
        <td>North</td>
        <td><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data3['direction_as_per_document_north'] ?? '') ?></span></td>
        <td><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data10['NA'] ?? '') ?></span></td>
        <td><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data3['direction_as_per_site_north'] ?? '') ?></span></td>
    </tr>

    <tr>
       
        <td>South</td>
        <td><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data3['direction_as_per_document_south'] ?? '') ?></span></td>
        <td><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data10['NA'] ?? '') ?></span></td>
        <td><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data3['direction_as_per_site_south'] ?? '') ?></span></td>
    </tr>

    <!-- DIMENSIONS -->
    <tr>
        <th class="section-header" colspan="5">DIMENSIONS IN FEETS:</th>
    </tr>
    <tr>
        <th class="number-col" rowspan="5">41</th>
        <th>Direction</th>
        <th>As per Ownership Documents</th>
        <th>As per Approved plans</th>
        <th>As per Physical Visit</th>
    </tr>

    <tr>
        <td>East</td>
        <td><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data6['dimension_as_per_document_east'] ?? '') ?></span></td>
        <td><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data10['NA'] ?? '') ?></span></td>
        <td><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data6['dimension_as_per_site_east'] ?? '') ?></span></td>
    </tr>

    <tr>
        <td>West</td>
        <td><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data6['dimension_as_per_document_west'] ?? '') ?></span></td>
        <td><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data10['NA'] ?? '') ?></span></td>
        <td><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data6['dimension_as_per_site_west'] ?? '') ?></span></td>
    </tr>

    <tr>
        <td>North</td>
        <td><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data6['dimension_as_per_document_north'] ?? '') ?></span></td>
        <td><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data10['NA'] ?? '') ?></span></td>
        <td><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data6['dimension_as_per_site_north'] ?? '') ?></span></td>
    </tr>

    <tr>
        <td>South</td>
        <td><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data6['dimension_as_per_document_south'] ?? '') ?></span></td>
        <td><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data10['NA'] ?? '') ?></span></td>
        <td><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data6['dimension_as_per_site_south'] ?? '') ?></span></td>
    </tr>

    <!-- LAND/PLOT -->
    <tr>
        <th class="section-header" colspan="5">LAND/PLOT: Details of plot Only</th>
    </tr>
    <tr>
        <th class="number-col"></th>
        <th>Particulars</th>
        <th>As per Ownership Documents</th>
        <th>As per Approved plans</th>
        <th>As per Physical Visit</th>
    </tr>
    <tr>
        <td class="number-col">42</td>
        <td>Plot/Property Usage</td>
        <td><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data4['approved_property_usage'] ?? '') ?></span></td>
        <td><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data10['NA'] ?? '') ?></span></td>
        <td><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data4['current_property_usage'] ?? '') ?></span></td>
    </tr>
    <tr>
        <td class="number-col">43</td>
        <td>Property Demarcation</td>
       
        <td colspan="3"><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data2['demarcated_at_site'] ?? '') ?></span></td>
    </tr>
    <tr>
        <td class="number-col">44</td>
        <td>Property Identification</td>
        <td colspan="3"><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data3['boundaries_matching'] ?? '') ?></span></td>
    </tr>
</table>

<table>
    <!-- Ownership Section -->
    <tr>
        <td class="number-col">45</td>
        <td>Ownership</td>
        <td colspan="3"><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data2['property_leasehold_freehold'] ?? '') ?></span></td>
    </tr>
    <tr>
        <td class="number-col">46</td>
        <td> Agreement Value </td>
        <td colspan="3"><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data10['NA'] ?? '') ?></span></td>
    </tr>
    <tr>
        <td class="number-col">47</td>
        <td>Name of the Seller</td>
        <td colspan="3"><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data9['seller_name'] ?? '') ?></span></td>
    </tr>
    <tr>
        <td class="number-col">48</td>
        <td> Prevailing Market Rate Range for Land (Rs./sqft)</td>
        <td>From <span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars( '0') ?></span></td>
        <td>To <span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars( '0') ?></span></td>
        <td></td>
    </tr>
    <tr>
        <td class="number-col" rowspan="3">49</td>
        <td rowspan="3">Comparables with name and contact number</td>
        <td colspan="3"> <span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data10['NA'] ?? '') ?></span></td>
    </tr>
    <tr>
        <td colspan="3"> <span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data10['NA'] ?? '') ?></span></td>
    </tr>
     <tr>
        <td colspan="3"> <span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data10['NA'] ?? '') ?></span></td>
    </tr>

    <!-- TECHNICAL DETAILS HEADER -->
    <tr>
        <th class="section-header" colspan="5">TECHNICAL DETAILS</th>
    </tr>
    <tr>
        <td class="number-col">50</td>
        <td> Project Name </td>
        <td colspan="3"><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data2['project_name'] ?? '') ?></span></td>
    </tr>
    <tr>
        <td class="number-col">51</td>
        <td> Developer Name </td>
        <td colspan="3"><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data10['NA'] ?? '') ?></span></td>
    </tr>
    <tr>
        <td class="number-col">52</td>
        <td> Type of construction </td>
        <td colspan="3"><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data4['structure_type'] ?? '') ?></span></td>
    </tr>
    <tr>
        <td class="number-col">53</td>
        <td>Number of Storey</td>
        <td colspan="3"><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data8['total_actual_floors'] ?? '') ?></span></td>
    </tr>
    <tr>
        <td class="number-col">54</td>
        <td>Age of Property in Years/Months</td>
        <td colspan="3"><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data2['age_of_property'] ?? '') ?></span></td>
    </tr>
    <tr>
        <td class="number-col">55</td>
        <td>Residual Age in Years</td>
        <td colspan="3"><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data2['residual_age_of_property'] ?? '') ?></span></td>
    </tr>
    <tr>
        <td class="number-col">56</td>
        <td>Type of Access Road in Feets</td>
        <td colspan="3"><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data2['type_of_approach_road'] ?? '') ?></span></td>
    </tr>
    <tr>
        <td class="number-col">57</td>
        <td>Type of Roofing</td>
        <td colspan="3"><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data4['roof_type'] ?? '') ?></span></td>
    </tr>
    <tr>
        <td class="number-col">58</td>
        <td>Type of Flooring</td>
        <td colspan="3"><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data4['costal_regulatory_zone'] ?? '') ?></span></td>
    </tr>
    <tr>
        <td class="number-col">59</td>
        <td>Masonry</td>
        <td colspan="3"><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars('Brick Masonry ') ?></span></td>
    </tr>
    <tr>
        <td class="number-col">60</td>
        <td> Population of the locality as per Jal Jeevan Website </td>
        <td colspan="3"><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data10['NA'] ?? '') ?></span></td>
    </tr>
    <tr>
        <td class="number-col">61</td>
        <td> Provision of Toilet, Water, Electricity, Drainage  </td>
        <td colspan="3"><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data4['presence_of_nala'] ?? '') ?></span></td>
    </tr>
    <tr>
        <td class="number-col">62</td>
        <td>Govt Public Transport Availability to the location</td>
        <td colspan="3"><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars('YES') ?></span></td>
    </tr>
    <tr>
        <td class="number-col">63</td>
        <td>Occupancy Percentage in Project</td>
        <td colspan="3"><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data2['develop_percent'] ?? '') ?></span></td>
    </tr>
    <tr>
        <td class="number-col">64</td>
        <td>Surrounding Development</td>
        <td colspan="3"><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data2['surrounding_infrastructure'] ?? '') ?></span></td>
    </tr>
    <tr>
        <td class="number-col">65</td>
        <td>Property Marketability</td>
        <td colspan="3"><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data9['markebility'] ?? '') ?></span></td>
    </tr>
    <tr>
        <td class="number-col">66</td>
        <td>Present Occupancy Details</td>
        <td colspan="3"><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data2['occupancy_status'] ?? '') ?></span></td>
    </tr>
    <tr>
        <td class="number-col">67</td>
        <td>Does Property is with in NDMA Norms</td>
        <td colspan="3"><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data10['NA'] ?? '') ?></span></td>
    </tr>
    <tr>
        <td class="number-col">68</td>
        <td>Risk of Demolition</td>
        <td colspan="3"><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data9['demolition_risk_1'] ?? '') ?></span></td>
    </tr>

    <!-- Stages of Construction -->
    <tr>
        <td class="number-col">69</td>
        <td colspan="4">
            <table style="width:100%; border-collapse: collapse;">
                <tr>
                    <th style="border:1px solid black;">Stages of Construction</th>
                    <th style="border:1px solid black;">Area As per Plan (Sft)</th>
                    <th style="border:1px solid black;">Measured Area (Sft)</th>
                    <th style="border:1px solid black;">Status</th>
                </tr>
                <tr>
                    <td style="border:1px solid black;">Plinth</td>
                    <td style="border:1px solid black;"><span style="display: inline-block; min-width: 50px; padding: 2px;">
                        <?= htmlspecialchars($data8['ground_approved'] ?? '') ?></span></td>
                    <td style="border:1px solid black;"><span style="display: inline-block; min-width: 50px; padding: 2px;">
                        <?= htmlspecialchars($data8['ground_actual'] ?? '') ?></span></td>
                    <td style="border:1px solid black;"><span style="display: inline-block; min-width: 50px; padding: 2px;">
                        <?= htmlspecialchars($data8['plinth_present_completion'] ?? '') ?></span></td>
                </tr>
                <tr>
                    <td style="border:1px solid black;">Basement</td>
                    <td style="border:1px solid black;"><span style="display: inline-block; min-width: 50px; padding: 2px;">
                       <?= htmlspecialchars($data10['NA'] ?? '') ?></span></td>
                    <td style="border:1px solid black;"><span style="display: inline-block; min-width: 50px; padding: 2px;">
                       <?= htmlspecialchars($data10['NA'] ?? '') ?></span></td>
                    <td style="border:1px solid black;"><span style="display: inline-block; min-width: 50px; padding: 2px;">
                       <?= htmlspecialchars($data10['NA'] ?? '') ?></span></td>
                 </tr>
                <tr>
                    <td style="border:1px solid black;">Ground Floor</td>
                    <td style="border:1px solid black;"><span style="display: inline-block; min-width: 50px; padding: 2px;">
                        <?= htmlspecialchars($data8['ground_approved'] ?? '') ?></span></td>
                    <td style="border:1px solid black;"><span style="display: inline-block; min-width: 50px; padding: 2px;">
                        <?= htmlspecialchars($data8['ground_actual'] ?? '') ?></span></td>
                    <td style="border:1px solid black;"><span style="display: inline-block; min-width: 50px; padding: 2px;">
                      <?= htmlspecialchars($data8['ground_permissible'] ?? '') ?></span></td>
                </tr>
                <tr>
                    <td style="border:1px solid black;">First Floor</td>
                    <td style="border:1px solid black;"><span style="display: inline-block; min-width: 50px; padding: 2px;">
                           <?= htmlspecialchars($data8['first_approved'] ?? '') ?></span></td>
                    <td style="border:1px solid black;"><span style="display: inline-block; min-width: 50px; padding: 2px;">
                           <?= htmlspecialchars($data8['first_actual'] ?? '') ?></span></td>
                    <td style="border:1px solid black;"><span style="display: inline-block; min-width: 50px; padding: 2px;">
                           <?= htmlspecialchars($data8['first_permissible'] ?? '') ?></span></td>
                </tr>
                <tr>
                    <td style="border:1px solid black;">Second Floor</td>
                    <td style="border:1px solid black;"><span style="display: inline-block; min-width: 50px; padding: 2px;">
                            <?= htmlspecialchars($data8['second_approved'] ?? '') ?></span></td>
                    <td style="border:1px solid black;"><span style="display: inline-block; min-width: 50px; padding: 2px;">
                            <?= htmlspecialchars($data8['second_actual'] ?? '') ?></span></td>
                    <td style="border:1px solid black;"><span style="display: inline-block; min-width: 50px; padding: 2px;">
                            <?= htmlspecialchars($data8['second_permissible'] ?? '') ?></span></td>
                </tr>
                <tr>
                    <td style="border:1px solid black;">Third Floor</td>
                    <td style="border:1px solid black;"><span style="display: inline-block; min-width: 50px; padding: 2px;">
                            <?= htmlspecialchars($data8['other_approved_floors'] ?? '') ?></span></td>
                    <td style="border:1px solid black;"><span style="display: inline-block; min-width: 50px; padding: 2px;">
                            <?= htmlspecialchars($data8['other_actual_floors'] ?? '') ?></span></td>
                    <td style="border:1px solid black;"><span style="display: inline-block; min-width: 50px; padding: 2px;">
                            <?= htmlspecialchars($data8['other_permissible_floors'] ?? '') ?></span></td>
                </tr>
                <tr>
                    <td style="border:1px solid black;">Fourth Floor</td>
                    <td style="border:1px solid black;"><span style="display: inline-block; min-width: 50px; padding: 2px;">
                      <?= htmlspecialchars($data10['NA'] ?? '') ?></span></td>
                    <td style="border:1px solid black;"><span style="display: inline-block; min-width: 50px; padding: 2px;">
                      <?= htmlspecialchars($data10['NA'] ?? '') ?></span></td>
                    <td style="border:1px solid black;"><span style="display: inline-block; min-width: 50px; padding: 2px;">
                      <?= htmlspecialchars($data10['NA'] ?? '') ?></span></td>
                </tr>
                <tr>
                    <td style="border:1px solid black;"> Fifth Floor </td>
                    <td style="border:1px solid black;"><span style="display: inline-block; min-width: 50px; padding: 2px;">
                        <?= htmlspecialchars($data10['NA'] ?? '') ?></span></td>
                    <td style="border:1px solid black;"><span style="display: inline-block; min-width: 50px; padding: 2px;">
                        <?= htmlspecialchars($data10['NA'] ?? '') ?></span></td>
                    <td style="border:1px solid black;"><span style="display: inline-block; min-width: 50px; padding: 2px;">
                         <?= htmlspecialchars($data10['NA'] ?? '') ?></span></td>
                </tr>
            </table>
        </td>
    </tr>
</table>

<table>
    <tr>
        <td class="number-col">70</td>
        <td> Description of Construction Stage in Words </td>
        <td colspan="3"><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data8['description_stage_construction_allotted'] ?? '') ?></span></td>
    </tr>
    <tr>
        <td class="number-col">71</td>
        <td> Over all Construction Stage in Percentage </td>
        <td colspan="3"><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data8['total_completion_present'] ?? '') ?></span></td>
    </tr>

    <tr>
        <td class="number-col">72</td>
        <td>Land area as per Document in Sft</td>
        <td colspan="3"><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data6['actual_plot_square_feet'] ?? '') ?></span></td>
    </tr>

    <tr>
        <td class="number-col">73</td>
        <td>Measured Land area as per actual at site in Sft</td>
        <td colspan="3"><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data6['final_plot_square_feet'] ?? '') ?></span></td>
    </tr>

    <tr>
        <td class="number-col">74</td>
        <td> BUA as per Documents in Sft </td>
        <td colspan="3"><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data6['construction_square_feet'] ?? '') ?></span></td>
    </tr>
    
    <tr>
        <td class="number-col">75</td>
        <td> Measured BUA as per actuals in Sft </td>
        <td colspan="3"><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data6['actual_construction_square_feet'] ?? '') ?></span></td>
    </tr>

    <!-- Setbacks Table -->
    <tr>
        <td class="number-col">76</td>
        <td colspan="4">
            <table style="width:100%; border-collapse: collapse;">
                <tr>
                    <th style="border:1px solid black;">Setbacks</th>
                    <th style="border:1px solid black;">As per Plan</th>
                    <th style="border:1px solid black;">Actual at site</th>
                    <th style="border:1px solid black;">Deviation</th>
                </tr>
                <tr>
                    <td style="border:1px solid black;">Front</td>
                    <td style="border:1px solid black;"><span style="display: inline-block; min-width: 50px; padding: 2px;">
                        <?= htmlspecialchars($data10['NA'] ?? '') ?></span></td>
                    <td style="border:1px solid black;"><span style="display: inline-block; min-width: 50px; padding: 2px;">
                        <?= htmlspecialchars($data10['NA'] ?? '') ?></span></td>
                    <td style="border:1px solid black;"><span style="display: inline-block; min-width: 50px; padding: 2px;">
                        <?= htmlspecialchars($data10['NA'] ?? '') ?></span></td>
                </tr>
                <tr>
                    <td style="border:1px solid black;">Side1 (Left)</td>
                    <td style="border:1px solid black;"><span style="display: inline-block; min-width: 50px; padding: 2px;">
                            <?= htmlspecialchars($data10['NA'] ?? '') ?></span></td>
                    <td style="border:1px solid black;"><span style="display: inline-block; min-width: 50px; padding: 2px;">
                            <?= htmlspecialchars($data10['NA'] ?? '') ?></span></td>
                    <td style="border:1px solid black;"><span style="display: inline-block; min-width: 50px; padding: 2px;">
                            <?= htmlspecialchars($data10['NA'] ?? '') ?></span></td>
                </tr>
                <tr>
                    <td style="border:1px solid black;">Side2 (Right)</td>
                    <td style="border:1px solid black;"><span style="display: inline-block; min-width: 50px; padding: 2px;">
                              <?= htmlspecialchars($data10['NA'] ?? '') ?></span></td>
                    <td style="border:1px solid black;"><span style="display: inline-block; min-width: 50px; padding: 2px;">
                             <?= htmlspecialchars($data10['NA'] ?? '') ?></span></td>
                    <td style="border:1px solid black;"><span style="display: inline-block; min-width: 50px; padding: 2px;">
                              <?= htmlspecialchars($data10['NA'] ?? '') ?></span></td>
                </tr>
                <tr>
                    <td style="border:1px solid black;">Rear</td>
                    <td style="border:1px solid black;"><span style="display: inline-block; min-width: 50px; padding: 2px;">
                                <?= htmlspecialchars($data10['NA'] ?? '') ?></span></td>
                    <td style="border:1px solid black;"><span style="display: inline-block; min-width: 50px; padding: 2px;">
                               <?= htmlspecialchars($data10['NA'] ?? '') ?></span></td>
                    <td style="border:1px solid black;"><span style="display: inline-block; min-width: 50px; padding: 2px;">
                               <?= htmlspecialchars($data10['NA'] ?? '') ?></span></td>
                </tr>
            </table>
        </td>
    </tr>

    <!-- Valuation Header -->
    <tr>
        <th class="section-header" colspan="5">VALUATION</th>
    </tr>
    <tr>
        <th style="border:1px solid black;">No.</th>
        <th style="border:1px solid black;">Particulars</th>
        <th style="border:1px solid black;">Area (SqFt)</th>
        <th style="border:1px solid black;">Rate (Rs.)</th>
        <th style="border:1px solid black;">Value (Rs.)</th>
    </tr>
    <tr>
        <td class="number-col">77</td>
        <td>Land Value</td>
        <td><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data6['final_plot_square_feet'] ?? '') ?></span></td>
        <td><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data6['final_plot_rate'] ?? '') ?></span></td>
        <td><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data6['finally_plot_valuation'] ?? '') ?></span></td>
    </tr>
    <tr>
        <td class="number-col">78</td>
        <td>Current Building Value (Semi Finished)</td>
        <td><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data6['construction_square_feet'] ?? '') ?></span></td>
        <td><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data6['construction_rate'] ?? '') ?></span></td>
        <td><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data6['construction_valuation_computed'] ?? '') ?></span></td>
    </tr>
    <tr>
        <td class="number-col">79</td>
        <td>Building Value (Post 100% Building Completion)</td>
        <td><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data6['final_construction_square_feet'] ?? '') ?></span></td>
        <td><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data6['final_construction_rate'] ?? '') ?></span></td>
        <td><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data6['finally_construction_valuation'] ?? '') ?></span></td>
    </tr>
    <tr>
        <td class="number-col">80</td>
        <td>Fair Market Value of Property (Semi Finished)</td>
        <td colspan="3"><span style="display: inline-block; min-width: 50px; padding: 2px;">
    <?= htmlspecialchars(
        floatval($data6['finally_plot_valuation'] ?? 0) + 
        floatval($data6['construction_valuation_computed'] ?? 0)
    ) ?>
</span></td>

    </tr>

    <tr>
        <td class="number-col">81</td>
        <td>Fair Market Value of Property (100% Completed)</td>
       <td colspan="3"><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data6['total_finally_area_valuation'] ?? '') ?></span></td>
    </tr>

    <tr>
        <td class="number-col">82</td>
        <td>Fair Market Value (100% Building Completed) in Words</td>
        <td colspan="3"><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data6['total_valuation_words'] ?? '') ?></span></td>
    </tr>
    <tr>
        <td class="number-col">83</td>
        <td>Fair Market Value (Semi Finished) in Words</td>
        <td colspan="3"><span><input type="text" style="width:100%;"></span></td>
    </tr>
    <tr>
        <td class="number-col">84</td>
        <td>Forced Sale Value (Semi Finished)</td>
        <td colspan="3"><span style="display: inline-block; min-width: 50px; padding: 2px;">
    <?= htmlspecialchars(
        (floatval($data6['finally_plot_valuation'] ?? 0) + 
        floatval($data6['construction_valuation_computed'] ?? 0)) * 0.75
    ) ?>
</span>
</td>
    </tr>
    <tr>
        <td class="number-col">85</td>
        <td>Forced Sale Value (100% Completed)</td>
        <td colspan="3"><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data6['total_distress_value'] ?? '') ?></span></td>
    </tr>
    <tr>
        <td class="number-col" rowspan="3" >86</td>
        <td rowspan="3"> Government Guideline Value (Plot/Land) </td>
        <td>LAND</td>
        <td colspan="2"><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data10['NA'] ?? '') ?></span></td>
    </tr>

    <tr>
        <td>CONSTRUCTION</td>
         <td colspan="2"><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data10['NA'] ?? '') ?></span></td>
    </tr>

    <tr>
        <td> TOTAL </td>
         <td colspan="2"><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data10['NA'] ?? '') ?></span></td>
    </tr>
    <!-- Final Remarks -->

    <tr>
        <td class="number-col">87</td>
        <td>Final Remarks</td>
        <td colspan="3"><span style="white-space: pre-line; font-size:14px; display: block; text-align: left; padding: 0; margin: 0;">
        <?= htmlspecialchars($data10['remarks'] ?? '') ?>
    </span></td>
    </tr>
    
    <tr>
        <td class="number-col">88</td>
        <td>Report Status</td>
        <td colspan="3"><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data9['positive_report'] ?? '') ?></span></td>
    </tr>
    <tr>
        <td class="number-col">89</td>
        <td>Report Date & Time</td>
        <td colspan="3"><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data1['report_assigned_at'] ?? '') ?></span></td>
    </tr>
     <tr>
        <th class="section-header" colspan="5">DECLARATION </th>
    </tr>
    <tr>
        <td colspan="6"><span style="white-space: pre-line; font-size:14px; display: block; text-align: left; padding: 0; margin: 0;font-weight:400;" readonly>
    <?= nl2br(htmlspecialchars(formatDeclaration($data10['declaration'] ?? ''))) ?>
</span></td> </tr>
 <?php
function formatDeclaration($text) {
    // Insert a newline before every occurrence of a number followed by a dot and space (e.g., "1. ", "10. ")
    // Only if it's NOT already at the beginning of the string or a new line
    $text = preg_replace('/(?<!^)(?<!\n)(\d+\.\s)/', "\n$1", $text);
    return $text;
}
?>
    </tr>
</table>
</div>
<table>
<tr><th style="margin-bottom:-18px;">PHOTOGRAPH OF THE PROPERTY</tr></th></table>
<br>

    
<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

$servername = "localhost";
$username   = "root";
$password   = "";
$dbname     = "project_db";

$conn = new mysqli($servername, $username, $password, $dbname);
if ($conn->connect_error) {
    die("Connection failed: " . htmlspecialchars($conn->connect_error));
}

$reference_id = $_SESSION['reference_id'] ?? null;
$reference_id = $_GET['reference_id'] ?? $reference_id;

if ($reference_id) {

    // Map captions
    $captions = [
        'image1'  => 'EXTERNAL PHOTOS',
        'image2'  => 'Kitchen',
        'image3'  => 'Selfie',
        'image4'  => 'Electric Meter',
        'image6'  => 'Other 1',
        'image7'  => 'Other 2',
        'image8'  => 'Other 3',
        'image9'  => 'Other 4',
        'image10' => 'Other 5',
        'image11' => 'Other 6',
        'image12' => 'Other 7',
        'image13' => 'Other 8',
        'image14' => 'Other 9',
        'image15' => 'Other 10',
        'image16' => 'Other 11',
        'image17' => 'Other 12',
        'image18' => 'Other 13',
        'image19' => 'Other 14',
        'image20' => 'Other 15',
    ];

    // === Helper: EXIF-aware orientation detection ===
    function classify_orientation_after_exif(string $imageData): ?string {
        $size = @getimagesizefromstring($imageData);
        if (!$size || !isset($size[0], $size[1])) {
            return null;
        }
        $width  = (int)$size[0];
        $height = (int)$size[1];

        $mime = $size['mime'] ?? '';
        if ($mime === 'image/jpeg' && function_exists('exif_read_data')) {
            $tmp = @tempnam(sys_get_temp_dir(), 'exif_');
            if ($tmp !== false) {
                @file_put_contents($tmp, $imageData);
                $exif = @exif_read_data($tmp);
                @unlink($tmp);

                if (!empty($exif['Orientation'])) {
                    $orientation = (int)$exif['Orientation'];
                    if ($orientation === 6 || $orientation === 8) {
                        $t = $width; $width = $height; $height = $t;
                    }
                }
            }
        }
        return ($width >= $height) ? 'horizontal' : 'vertical';
    }

    // === Helper: Fix orientation physically with Imagick ===
    function fixImageOrientation($binaryData) {
        $img = new Imagick();
        $img->readImageBlob($binaryData);

        switch ($img->getImageOrientation()) {
            case Imagick::ORIENTATION_BOTTOMRIGHT:
                $img->rotateImage("#000", 180);
                break;
            case Imagick::ORIENTATION_RIGHTTOP:
                $img->rotateImage("#000", 90);
                break;
            case Imagick::ORIENTATION_LEFTBOTTOM:
                $img->rotateImage("#000", -90);
                break;
        }

        $img->setImageOrientation(Imagick::ORIENTATION_TOPLEFT);
        $fixed = $img->getImageBlob();
        $img->destroy();

        return $fixed;
    }

    $sql = "SELECT 
                image1, image2, image3, image4, 
                image6, image7, image8, image9, 
                image10, image11, image12, image13, image14, image15, image16, image17, image18, image19, image20
            FROM final_uploaded_images 
            WHERE reference_id = ?";

    $stmt = $conn->prepare($sql);
    if ($stmt === false) {
        die("Error preparing the SQL statement: " . htmlspecialchars($conn->error));
    }

    $stmt->bind_param("s", $reference_id);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result && $result->num_rows > 0) {
        $horizontal_images = [];
        $vertical_images   = [];

        while ($row = $result->fetch_assoc()) {
            foreach ($row as $key => $imageData) {
                if (!empty($imageData)) {

                    // Actually fix image before displaying
                    $fixedData = fixImageOrientation($imageData);

                    $orientation = classify_orientation_after_exif($fixedData) ?? 'horizontal';
                    $imgString   = base64_encode($fixedData);
                    $caption     = $captions[$key] ?? 'Image';

                    $item = [
                        'data'    => $imgString,
                        'caption' => $caption,
                        'alt'     => $key,
                    ];

                    if ($orientation === 'horizontal') {
                        $horizontal_images[] = $item;
                    } else {
                        $vertical_images[]   = $item;
                    }
                }
            }
        }

 
// Output as a stable 4-column table (works in wkhtmltopdf)
$all_images = array_merge($vertical_images, $horizontal_images);

echo '<table class="image-grid">';
$rows = array_chunk($all_images, 4);
foreach ($rows as $row) {
    echo '<tr>';
    foreach ($row as $img) {
        echo '<td>';
        echo '<div class="img-wrap">';
        echo '<img src="data:image/jpeg;base64,' . $img['data'] . '" alt="' . htmlspecialchars($img['alt']) . '">';
        echo '<div class="caption">' . htmlspecialchars($img['caption']) . '</div>';
        echo '</div>';
        echo '</td>';
    }
    // pad remaining cells to keep 4 columns
    $remaining = 4 - count($row);
    if ($remaining > 0) {
        echo str_repeat('<td></td>', $remaining);
    }
    echo '</tr>';
}
echo '</table>';

    } else {
        echo "<p style='text-align:center;'>No images found.</p>";
    }

    $stmt->close();
} else {
    echo "<p style='text-align:center;'>Reference ID is missing.</p>";
}
?>

    
      <table>
  </tr>
  <tr>

<div class="google-map-container">
<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "project_db";
$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$reference_id = $_SESSION['reference_id'] ?? null;
$reference_id = $_GET['reference_id'] ?? $reference_id;

if ($reference_id) {
    $sql = "SELECT image5 FROM final_uploaded_images WHERE reference_id = ?";
    $stmt = $conn->prepare($sql);
    if ($stmt === false) {
        die("Error preparing the SQL statement: " . $conn->error);
    }

    $stmt->bind_param("s", $reference_id);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows > 0) {
        $row = $result->fetch_assoc();
        if (!empty($row['image5'])) {
 
            echo '<div><img src="data:image/jpeg;base64,' . base64_encode($row['image5']) . '" alt="Google Map"><p>Google Map</p></div>';
        } else {
            echo "<p style='text-align:center;'>Google Map image not available.</p>";
        }
    } else {
        echo "<p style='text-align:center;'>No record found for Google Map image.</p>";
    }

    $stmt->close();
} else {
    echo "<p style='text-align:center;'>Reference ID is missing.</p>";
}
?>
</tr>
</div>
    </table>
    </table>
     <!-- <button onclick="window.print()">Download PDF</button> -->
    <form method="post">
  <input type="hidden" name="download_images" value="1">
  <button type="submit">Download All Images</button>
</form>
     <!-- <button onclick="window.print()">Download PDF</button> -->
  <button id="downloadPdf" onclick="setPrintMargins()">DOWNLOAD PDF</button>
  <script>
    document.getElementById('downloadPdf').addEventListener('click', () => {
      // Select the content you want to convert to PDF
      const element = document.getElementById('content');
      const options = {
        margin:[0,0],
        filename:'report.pdf',
        image: { type: 'jpeg', quality: 0.98 },
        html2canvas: { scale: 2 },
        jsPDF: { unit: 'in', format: 'letter', orientation: 'portrait' }
      };

      // Generate and download the PDF
      html2pdf().set(options).from(element).save();
    });
    function setPrintMargins() {
      const style = document.createElement('style');
      style.innerHTML = `
      @media print {
          body {
            margin:0.2;
          }
        }
      `;
      document.head.appendChild(style);
      window.print();
    }
    // Disable all input fields in the form
    document.querySelectorAll('input').forEach(function(input) {
        input.disabled = true;  // Disables the field completely
    });
    </script>
     </div>
    
</body>
</html>
