<?php include('auth.php'); ?>
<?php include 'watermark.html'; ?> 
<?php 
// Database connection
$host = 'localhost';
$db = 'project_db';
$username = 'root'; // Change this to your MySQL username
$password = ''; // Change this to your MySQL password

// Create a connection to the database
$conn = new mysqli($host, $username, $password, $db);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Fetch images from the database (fetching 50 image columns)
$query = "SELECT * FROM uploaded_images LIMIT 1";  // Assuming only one row stores 50 images
$result = $conn->query($query);

$images = [];
if ($result->num_rows > 0) {
    $row = $result->fetch_assoc();
    
    // Fetch and encode the images in base64
    for ($i = 1; $i <= 50; $i++) {
        if ($row["image$i"] !== null) {
            $images[] = 'data:image/jpeg;base64,' . base64_encode($row["image$i"]);
        } else {
            $images[] = null;
        }
    }
}

// Close the database connection
$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Image Upload Form with Slider</title>
    <link rel="stylesheet" href="REPORT11.css">
</head>
<body>

<button id="toggleSidebar">&#9776;</button>

<!-- Sidebar -->
<div id="sidebar" class="sidebar">
    <div style="display: flex">
        <img class="logo" src="logo.png" alt="" />
        <h1>Magpie Engineering</h1>
    </div>
    <div class="rotating-text">Report Drafter</div>
    <a href="clear_and_go_home.php"><i class="fas fa-home icon"></i>Home</a>        

    <a href="search.php"><i class="fas fa-search icon"></i>Search</a>
    <a href="search.php"><i class="fas fa-clock watch-icon"></i>Pending For Drafting</a>
    <a href="clear_and_logout.php"><i class="fas fa-sign-out-alt icon"></i>Logout</a>
</div>

<div class="form-container" id="formContainer">
    <div class="header">
        <h2 style="font-style:italic;">IMAGE UPLOAD FORM</h2>
    </div>
    <div class="container" id="container">
        <!-- Boxes will be dynamically added here -->
    </div>

    <!-- Slider Modal -->
    <div class="slider-modal" id="sliderModal">
        <div class="slider">
            <h3 id="sliderTitle">Title</h3>
            <button class="close" onclick="closeSlider()">✖</button>
            <div class="arrow left" onclick="prevImage()">&#9664;</div>
            <img id="sliderImage" src="" alt="Slider Image">
            <div class="arrow right" onclick="nextImage()">&#9654;</div>
            <div class="buttons">
                <button onclick="selectImage()">Select</button>
                <button onclick="downloadImage()">Download</button>
            </div>
        </div>
    </div>

    <script>
        // Slider Image Data
        const images = <?php echo json_encode($images); ?>; // Get image data from PHP

        let currentIndex = 0;
        let currentBoxId = null;
        let currentBoxTitle = '';  // Variable to store box title

        // Manually adding 12 boxes with custom titles
        const container = document.getElementById('container');
        const titles = [
            'External Photo', 'Kitchen', 'Selfie', 'Electric Meter ', 'Google Map', 
            'Other1', 'Other2', 'Other3', 'Other4', 'Other4', 'Other4', 'Other5'
        ];

        for (let i = 0; i < 12; i++) {
            const box = document.createElement('div');
            box.className = 'box';
            box.id = box${i + 1};
            box.innerHTML = `
                <h3 style="font-style:italic;">${titles[i]}</h3>
                <img id="img${i + 1}" src="" alt="No image selected">
                <div class="buttons">
                    <button onclick="openSlider(${i + 1}, '${titles[i]}')">Select</button>
                    <button onclick="uploadImageBox(${i + 1})">Upload</button>
                </div>
            `;
            container.appendChild(box);
        }

        function openSlider(boxId, boxTitle) {
            currentBoxId = boxId;
            currentBoxTitle = boxTitle; // Store the title of the box
            currentIndex = 0; // Reset to the first image
            document.getElementById('sliderTitle').textContent = boxTitle; // Update the title in the slider
            document.getElementById('sliderImage').src = images[currentIndex] ? images[currentIndex] : '';
            document.getElementById('sliderModal').classList.add('show'); // Add the "show" class to slide in
        }

        function closeSlider() {
            document.getElementById('sliderModal').classList.remove('show'); // Remove the "show" class to slide out
        }

        function nextImage() {
            currentIndex = (currentIndex + 1) % images.length;
            document.getElementById('sliderImage').src = images[currentIndex] ? images[currentIndex] : '';
        }

        function prevImage() {
            currentIndex = (currentIndex - 1 + images.length) % images.length;
            document.getElementById('sliderImage').src = images[currentIndex] ? images[currentIndex] : '';
        }

        function selectImage() {
            if (currentBoxId) {
                const imgElement = document.getElementById(img${currentBoxId});
                imgElement.src = images[currentIndex] ? images[currentIndex] : '';
            }
            closeSlider();
        }

        function downloadImage() {
            const link = document.createElement('a');
            link.href = images[currentIndex] ? images[currentIndex] : '';
            link.download = Image_${currentIndex + 1}.jpg;
            link.click();
        }

        function uploadImageBox(boxId) {
            const input = document.createElement('input');
            input.type = 'file';
            input.accept = 'image/*';
            input.onchange = (e) => {
                const reader = new FileReader();
                reader.onload = () => {
                    document.getElementById(img${boxId}).src = reader.result;
                };
                reader.readAsDataURL(e.target.files[0]);
            };
            input.click();
        }
    </script>
</body>
</html>