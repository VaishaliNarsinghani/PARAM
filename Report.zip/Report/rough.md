<?php include('auth.php'); ?>
<?php

 // Start session

$message = "";

// Check if the form is submitted
if ($_SERVER["REQUEST_METHOD"] === "POST") {
    if (isset($_POST['action']) && $_POST['action'] === 'save') {
        // Save form data in the session
        $_SESSION['bank_details'] = array_map(function ($item) {
            return $item ?: '';
        }, $_POST);
        
        $message = "Bank details saved successfully!";
    } elseif (isset($_POST['action']) && $_POST['action'] === 'submit') {
        // Simulate saving all data to the database or another process
        // Clear session data after submission
        unset($_SESSION['bank_details']);

        // Redirect to a confirmation page
        header("Location: REPORT3.php");
        exit();
    }
}
?>

<!-- JavaScript for Alert -->
<script>
    <?php if (!empty($message)): ?>
    alert("<?= htmlspecialchars($message) ?>");
    <?php endif; ?>
</script>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Property Details Form</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
    <link rel="stylesheet" href="REPORT323.css">
    <style>
        /* Sidebar styles */
        /* Sidebar */
        .rotating-text {
            color:black;
    perspective: 1000px; /* Adds a 3D perspective effect */
    font-size: 1.5rem;
    font-weight:bold;
    width: 100%;
    animation: rotate360 3s linear infinite;
    display: inline-block;
    margin-bottom:10px;
    transform-origin: center center; /* Rotates around its center */
    text-align:center;
    /* margin-left:20px; */
    font-style: italic;
    text-shadow: 
    1px 1px 2px rgba(235, 244, 243, 0.97),
    2px 2px 4px rgba(246, 242, 242, 0.4),
    3px 3px 6px rgba(249, 252, 252, 0.89),
    4px 4px 8px rgba(248, 242, 247, 0.93),
    5px 5px 10px rgba(232, 236, 237, 0.4);
  }
  
  /* Keyframes for rotating the text */
  @keyframes rotate360 {
    0% {
      transform: rotateY(0deg); /* Starts with no rotation */
    }
    50% {
      transform: rotateY(0deg); /* Half rotation */
    }
    100% {
      transform: rotateY(360deg); /* Full rotation */
    }
  }
        .logo {
    /* width: 50px; */
    height:80px;
    padding: 15px;
    
  }
#sidebar {
    background: #B0C4DE; /* Light Steel Blue */
    color: #2C3E50; 
    position: fixed;
    left: -250px;
    top: 0;
    width: 250px;
    height: 100%;
    /* background-color: #111; */
    color: white;
    transition: left 0.3s ease;
    padding: 20px;
}

#sidebar.active {
    left: 35px;
    /* background:grey; */
}
.sidebar {
    width: 250px;
    background: #B0C4DE; /* Light Steel Blue */
    /* background:rgba(245, 245, 245, 0.37); Light Steel Blue */
    color: black; /* Dark Grayish Blue */
    padding:20px;
    height: 100vh;
    position: fixed;
    left: 0;
    top: 0;
    z-index: 1000;
    transition: transform 0.3s ease-in-out;
  }
  .sidebar.hidden {
    transform: translateX(-100%);
  }
  .sidebar h1 {
    font-size: 20px;
    margin-bottom: 20px;
  }

  .sidebar a {
    padding: 15px 20px;
      margin: 10px 0;
      text-decoration: none;
      color: #2C3E50; /* Dark Grayish Blue */
      font-size:16px;
      font-style: italic;
      font-weight: 500;
      margin-bottom:40px;
      border-radius: 5px;
      transition: all 0.3s ease;
      display: flex;
      align-items: center;
  }

  .sidebar a:hover,
  .sidebar a.active {
    background: #4A90E2; /* Light Blue */
    transform: translateX(10px);
    color: white;
  }
  .sidebar a .icon {
    margin-right: 15px;
    font-size: 18px;
  }
/* Toggle Button */
#toggleSidebar {
    border-radius: 20%;
    position: fixed;
    top: 0px; /* Adjusted for better placement */
    left: 0px; /* Adjusted for better placement */
    z-index: 1000;
    background-color:rgb(130, 183, 226); 
    color: white;
    border: none;
    padding: 6px 12px; /* Added padding for a more clickable area */
    cursor: pointer;
    box-shadow: 0 4px 8px rgba(0, 0, 0, 0.7); /* Adds a soft shadow for depth */
    transition: all 0.3s ease; 
    /* Smooth transition for hover and active states */
}

/* Button hover effect */
#toggleSidebar:hover {
    background-color: #1c6abf; /* Slightly darker shade on hover */
    transform: scale(1); /* Slightly enlarges the button for a professional hover effect */
    box-shadow: 0 6px 12px rgba(0, 0, 0, 0.3); /* Stronger shadow on hover */
}

/* Active state for the button */
#toggleSidebar.active {
    background-color: #1a4f82; /* Darker shade for active state */
    transform: rotate(180deg); /* Smooth rotate effect when the sidebar is active */
}

/* Button icon (if you use an icon inside the button) */
#toggleSidebar i {
    font-size: 18px; /* Adjust the icon size */
    transition: transform 0.3s ease; /* Smooth transition when rotating */
}
.watch-icon {
    margin-right: 16px; /* Adds space between the search text and the watch icon */
    color: #555; /* Optional: sets the color of the watch icon */
}
#toggleSidebar {
    border-radius: 20%;
    position: fixed;
    top: 0px; /* Adjust for better placement */
    /* right: -35px; Position it just outside the sidebar */
    z-index: 1001;
    background-color: rgb(130, 183, 226);
    color: white;
    border: none;
    padding: 6px 12px;
    cursor: pointer;
    box-shadow: 0 4px 8px rgba(0, 0, 0, 0.7);
    transition: all 0.3s ease;
}

/* Button hover effect */
#toggleSidebar:hover {
    background-color: #1c6abf;
    box-shadow: 0 6px 12px rgba(0, 0, 0, 0.3);
}

/* Active state for the button */
#toggleSidebar.active {
    background-color: #1a4f82;
    transform: rotate(180deg); /* Smooth 180-degree rotation */
    box-shadow: 0 6px 12px rgba(0, 0, 0, 0.5);
}

/* Sidebar */
#sidebar.active + #toggleSidebar {
    right: 250px; /* Adjust so button moves into view */
}

/* Sidebar when active */
#sidebar.active {
    left: 0px;
}

/* Sidebar hidden state */
#sidebar {
    position: fixed;
    left: -250px;
    top: 0;
    width: 250px;
    height: 100%;
    background: #B0C4DE;
    color: white;
    transition: left 0.3s ease;
}
    </style>
</head>
<body>
    <button id="toggleSidebar">&#9776;</button>

    <!-- Sidebar -->
    <div id="sidebar" class="sidebar">
        <div style="display: flex">
          <img class="logo" src="logo.png" alt="" />
          <h1>Magpie Engineering</h1>
        </div>
        <div class="rotating-text">Report Drafter</div>
        <a href="sample.php"  class="active"><i class="fas fa-home icon"></i>Home</a>
        
        <a href="Pending_Report.php"><i class="fas fa-clock watch-icon"></i>Pending For Drafting</a>
        <a href="clear_and_logout.php"><i class="fas fa-sign-out-alt icon"></i>Logout</a>

      </div>

    <div class="form-container" id="formContainer" style="margin-top:20px;">
        <?php if (!empty($message)): ?>
            <div class="success-message" style="text-align: center; padding: 10px; background-color: #dff0d8; color: #3c763d; border: 1px solid #d6e9c6; margin-bottom: 20px;">
                <?= htmlspecialchars($message) ?>
            </div>
        <?php endif; ?>

        <div class="tab-links">
            <button class="tab active"> <a href="REPORT3.php">BANK DETAILS</a></button>
            <button class="tab"> <a href="REPORT4.php">GENERAL DETAILS</a></button>
            <button class="tab"> <a href="REPORT2.php">ADDRESS</a></button>
            <button class="tab"> <a href="REPORT5.php">PARAMETERS</a></button>
            
            <button class="tab"> <a href="REPORT7.php">AREA</a></button>
   
            <button class="tab"> <a href="REPORT9.php">FLOOR DETAILS</a></button>
            <button class="tab"> <a href="REPORT10.php">TECHNICAL DETAILS</a></button>
            <button class="tab"> <a href="REPORT115.php">PHOTOS</a></button>
            <button class="tab"> <a href="REPORT12.php">REMARK</a></button>
        </div>

        <form action="" method="POST" style="width: 100%;">
            <table class="valuation-table">
                <div class="header valuation-table">BANK DETAILS / LOAN APPLICATION DETAILS</div>
                <?php
                    $fields = [
                        'Branch Name' => 'branch_name',
                        'Application Number' => 'application_number',
                        'Customer No.' => 'customer_no',
                        'Name of Applicant' => 'applicant_name',
                        'Product' => 'product',
                        'Transaction Type' => 'transaction_type',
                    ];
                    $count = 0;
                    echo '<tr>';
                    foreach ($fields as $label => $name) {
                        $value = htmlspecialchars($_SESSION['bank_details'][$name] ?? '');
                        echo "<td><label for='$name'>$label</label></td>
                              <td><input type='text' id='$name' name='$name' value='$value'></td>";
                        $count++;
                        if ($count % 3 === 0) {
                            echo '</tr><tr>';
                        }
                    }
                    echo '</tr>';
                ?>
            </table>
            <div class="submit-button">
                <button type="submit" name="action" value="save">Save</button>
            </div>
            <div id="imagePreviewContainer" class="image-preview-container">
                <p>Selected images will appear here</p>
            </div>
        </form>
    </div>

    <!-- Side Buttons Section -->
    <div class="side-buttons">
        <button type="button" onclick="triggerFileInput()"><img src="https://www.iconpacks.net/icons/1/free-document-icon-901-thumb.png" alt="" width="35px" height="35px"></button>
        <button type="button" onclick="triggerFileInput()"><img src="https://cdn-icons-png.flaticon.com/512/25/25666.png" alt="" width="35px" height="35px"></button>       
        <button type="button" onclick="triggerFileInput()"><img src="https://cdn-icons-png.flaticon.com/512/535/535239.png" alt="" width="35px" height="35px"></button>
        <button type="button" onclick="triggerFileInput()"><img src="https://cdn-icons-png.flaticon.com/512/1456/1456888.png" alt="" width="35px" height="35px"></button>
        <input type="file" id="imageInput" accept="image/*" style="display: none;">
    </div>

    <script>
        
      document.addEventListener("DOMContentLoaded", function () {
    let tabs = document.querySelectorAll(".tab-links .tab");
    let slider = document.querySelector(".tab-links .slider");

    function moveSlider(activeTab) {
        slider.style.width = activeTab.offsetWidth + "px";
        slider.style.left = activeTab.offsetLeft + "px";
    }

    tabs.forEach(tab => {
        tab.addEventListener("click", function () {
            tabs.forEach(t => t.classList.remove("active"));
            this.classList.add("active");
            moveSlider(this);
        });

        // Initialize position on load for the active tab
        if (tab.classList.contains("active")) {
            moveSlider(tab);
        }
    });
});

   document.getElementById("toggleSidebar").addEventListener("click", function() {
    var sidebar = document.getElementById("sidebar");
    var toggleButton = document.getElementById("toggleSidebar");
    
    sidebar.classList.toggle("active");
    
    // Toggle button state
    toggleButton.classList.toggle("active");
});



        function triggerFileInput() {
            document.getElementById("imageInput").click();
        }

        document.getElementById("imageInput").addEventListener("change", function (event) {
            const files = event.target.files;
            const previewContainer = document.getElementById("imagePreviewContainer");

            // Clear previous previews
            previewContainer.innerHTML = "";

            // Display previews for each selected image
            Array.from(files).forEach((file) => {
                if (file.type.startsWith("image/")) {
                    const reader = new FileReader();
                    reader.onload = function (e) {
                        const img = document.createElement("img");
                        img.src = e.target.result;
                        previewContainer.appendChild(img);
                    };
                    reader.readAsDataURL(file);
                }
            });
        });
    </script>
</body>
</html>
