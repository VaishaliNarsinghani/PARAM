document.getElementById('save-btn').addEventListener('click', () => {
    alert('Data saved successfully!');
});

document.getElementById('submit-btn').addEventListener('click', () => {
    alert('Form submitted!');
});

const tabs = document.querySelectorAll('.tab');
tabs.forEach(tab => {
    tab.addEventListener('click', () => {
        document.querySelector('.tab.active').classList.remove('active');
        tab.classList.add('active');
    });
});
