 
<?php include('auth.php'); ?>
<?php 
// Database connection setup
$host = 'localhost';
$db = 'project_db';
$user = 'root';
$pass = '';
$message = '';

try {
    $pdo = new PDO("mysql:host=$host;dbname=$db;charset=utf8", $user, $pass);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (PDOException $e) {
    die('Database connection failed: ' . $e->getMessage());
}

// Fetch engineers for assignment
try {
    $managersQuery = "SELECT engineer_id, name FROM engineer_login";
    $managersStmt = $pdo->query($managersQuery);
    $managersResult = $managersStmt->fetchAll(PDO::FETCH_ASSOC);
} catch (PDOException $e) {
    die('Error fetching Engineers: ' . $e->getMessage());
}

// Ensure values are passed through GET or SESSION
$engineer_id = isset($_GET['reference_id']) ? $_GET['reference_id'] : '';
$customerName = isset($_GET['customerName']) ? $_GET['customerName'] : '';
$address = isset($_GET['address']) ? $_GET['address'] : '';
$customerMob = isset($_GET['customerMob']) ? $_GET['customerMob'] : '';
$visitType = isset($_GET['visitType']) ? $_GET['visitType'] : '';
$caseType = isset($_GET['caseType']) ? $_GET['caseType'] : '';
$bankName = isset($_GET['bankName']) ? $_GET['bankName'] : '';
$branchname = isset($_GET['branchname']) ? $_GET['branchname'] : '';
$applicationNo = isset($_GET['applicationNo']) ? $_GET['applicationNo'] : '';
$initiatorMailId = isset($_GET['initiatorMailId']) ? $_GET['initiatorMailId'] : '';
$initiationDate = isset($_GET['initiationDate']) ? $_GET['initiationDate'] : '';
$message = '';

// Fetch assignments excluding those that already have a technical manager assigned
try {
    $stmt = $pdo->query("SELECT * FROM mis WHERE technical_manager_id IS NULL AND flag_field_engineer IS NULL");
    $assignments = $stmt->fetchAll(PDO::FETCH_ASSOC);
} catch (PDOException $e) {
    $message = 'Error fetching assignments: ' . $e->getMessage();
}

// Assign task to field engineer
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['assign_task'])) {
    $selectedEngineerId = isset($_POST['engineer_id']) ? $_POST['engineer_id'] : '';

    try {
        // Perform task assignment to the field engineer and set flag_field_engineer to 1
        $stmt = $pdo->prepare("UPDATE mis SET engineer_id = ?, assigned_at = CURRENT_TIMESTAMP, flag_field_engineer = 1 WHERE reference_id = ?");
        $stmt->execute([$selectedEngineerId, $engineer_id]);

        if ($stmt->rowCount() > 0) {
            $message = 'The assignment has been successfully assigned to the Field Officer with Reference ID: ' . htmlspecialchars($selectedEngineerId);
            // Redirect to the same page to clear the form data
            header("Location: " . $_SERVER['PHP_SELF']);
            exit;  // Ensure no further code is executed after redirect
        } else {
            $message = 'No record was updated. Please check the Reference ID.';
        }
    } catch (PDOException $e) {
        $message = 'Error assigning the task: ' . $e->getMessage();
    }
}

// Assign task to technical manager
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['assign_task_to_manager'])) {
    $selectedEngineerId = isset($_POST['engineer_id']) ? $_POST['engineer_id'] : '';
    $reference_id = isset($_POST['reference_id']) ? $_POST['reference_id'] : '';

    // Update the 'mis' table to assign the task to the selected technical manager
    try {
        $stmt = $pdo->prepare("UPDATE mis SET flag_field_engineer = 1, assigned_at = CURRENT_TIMESTAMP WHERE reference_id = ?");
        $stmt->execute([$reference_id]);

        if ($stmt->rowCount() > 0) {
            $message = 'Task has been successfully assigned to the Field Engineer.';
        } else {
            $message = 'Failed to assign task to the Field Engineer.';
        }
    } catch (PDOException $e) {
        $message = 'Error: ' . $e->getMessage();
    }
}
 ?>
<!-- JavaScript for Alert -->
<script>
    <?php if (!empty($message)): ?>
    alert("<?= htmlspecialchars_decode(addslashes($message)) ?>");
    <?php endif; ?>
</script>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Property Details Form</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
    <link rel="stylesheet" href="Pending_Report.css">
    <style>
       
    </style>
</head>
<body>
    <button id="toggleSidebar">&#9776;</button>

    <!-- Sidebar -->
    <div id="sidebar" class="sidebar">
        <div style="display: flex; align-items:center;">
          <img class="logo" src="logo.png" alt="" />
          <h1>Magpie Engineering</h1>
        </div>
        <div class="rotating-text">Report Drafter</div>
        <a href="clear_and_go_home.php"><i class="fas fa-home icon"></i>Home</a>        

        
      <a href="clear_sessions.php" class="active"><i class="fas fa-clock watch-icon"></i>Pending For Drafting</a>
 <a href="technical.php"><i class="fas fa-clipboard-list icon"></i> Preview Report</a>      
        <a href="clear_and_logout.php"><i class="fas fa-sign-out-alt icon"></i>Logout</a>

      </div>
        <!-- Content -->
        <div class="content" id="content">
            <div class="search-filters">
                <h2>Assign Task to Field Engineer</h2>
                <?php if (!empty($message)): ?>
                    <p style="color: green;"><?= htmlspecialchars($message) ?></p>
                <?php endif; ?>
                    <form  id="autosave-form" action="" method="POST" >

                    <input type="text" name="reference_id" placeholder="Reference ID" value="<?= htmlspecialchars($engineer_id) ?>" readonly>
                    <input type="text" name="customerName" placeholder="Customer Name" value="<?= htmlspecialchars($customerName) ?>" readonly>
                    <input type="text" name="address" placeholder="Address" value="<?= htmlspecialchars($address) ?>" required>
                    <input type="text" name="customerMob" placeholder="Customer Mobile" value="<?= htmlspecialchars($customerMob) ?>" readonly>
                    <input type="text" name="visitType" placeholder="Visit Type" value="<?= htmlspecialchars($visitType) ?>" readonly>
                    <input type="text" name="bankName" placeholder="Bank Name" value="<?= htmlspecialchars($bankName) ?>" readonly>
                    <input type="text" name="branchname" placeholder="Branch Name" value="<?= htmlspecialchars($branchname) ?>"readonly>
                    <input type="text" name="caseType" placeholder="Case Type" value="<?= htmlspecialchars($caseType) ?>" readonly>
                    <input type="text" name="applicationNo" placeholder="Application Number" value="<?= htmlspecialchars($applicationNo) ?>" readonly>
                    <input type="email" name="initiatorMailId" placeholder="Email ID" value="<?= htmlspecialchars($initiatorMailId) ?>" readonly>
                    <input type="date" name="initiationDate" placeholder="Initiation Date" value="<?= htmlspecialchars($initiationDate) ?>" readonly>
                    <form>
    <div class="form-row">
      <!-- Left Side: Label and Select Box -->
      <div class="form-left">
        <label for="field_engineer_id">Select Field Engineer:</label>
        <select name="engineer_id" id="field_engineer_id" required>
          <option value="" disabled selected>Select Engineer</option>
          <?php foreach ($managersResult as $manager): ?>
            <option value="<?= htmlspecialchars($manager['engineer_id']) ?>">
              <?= htmlspecialchars($manager['name']) ?>
            </option>
          <?php endforeach; ?>
        </select>
      </div>

      <button type="submit" name="assign_task"style="  background-color: #005f8a;">Assign Task</button>
    </div>
  </form>
            </div>
        </div>
    </div>

    <script>
  document.addEventListener("DOMContentLoaded", function () {
    let tabs = document.querySelectorAll(".tab-links .tab");
    let slider = document.querySelector(".tab-links .slider");

    function moveSlider(activeTab) {
        slider.style.width = activeTab.offsetWidth + "px";
        slider.style.left = activeTab.offsetLeft + "px";
    }

    tabs.forEach(tab => {
        tab.addEventListener("click", function () {
            tabs.forEach(t => t.classList.remove("active"));
            this.classList.add("active");
            moveSlider(this);
        });

        // Initialize position on load for the active tab
        if (tab.classList.contains("active")) {
            moveSlider(tab);
        }
    });
});

   document.getElementById("toggleSidebar").addEventListener("click", function() {
    var sidebar = document.getElementById("sidebar");
    var toggleButton = document.getElementById("toggleSidebar");
    
    sidebar.classList.toggle("active");
    
    // Toggle button state
    toggleButton.classList.toggle("active");
});

</script>
</body>

</html>
