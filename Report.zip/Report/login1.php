<?php
// Start session before any output
session_start();

// Error message placeholder
$error_message = '';

// Database credentials
$host = 'localhost';
$db = 'project_db';
$user = 'root';
$pass = '';

try {
    // PDO connection with optimized options
    $conn = new PDO("mysql:host=$host;dbname=$db;charset=utf8mb4", $user, $pass, [
        PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
        PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
    ]);
} catch (PDOException $e) {
    die("Database connection failed: " . $e->getMessage());
}

// Process login form
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['login'])) {
    $report_id = isset($_POST['report_id']) ? trim($_POST['report_id']) : '';
    $password = isset($_POST['password']) ? trim($_POST['password']) : '';
    $user_otp = isset($_POST['otp']) ? trim($_POST['otp']) : '';

    if ($report_id && $password && $user_otp) {
        try {
            // Get user by report_id
            $stmt = $conn->prepare("SELECT * FROM report_login WHERE report_id = ?");
            $stmt->execute([$report_id]);
            $user = $stmt->fetch();

            if ($user && $password === $user['password']) { // Consider password_verify() if using hashing
                // Fetch today's OTP
                $today = date("Y-m-d");
                $otp_stmt = $conn->prepare("SELECT otp FROM otp_login WHERE date = ?");
                $otp_stmt->execute([$today]);
                $otp_row = $otp_stmt->fetch();

                if ($otp_row && $user_otp === $otp_row['otp']) {
                    // Successful login
                    $_SESSION['logged_in'] = true;
                    $_SESSION['report_id'] = $report_id;

                    // Immediate redirect
                    header("Location: Pending_Report.php");
                    exit();
                } else {
                    $error_message = "Invalid OTP.";
                }
            } else {
                $error_message = "Invalid credentials.";
            }
        } catch (PDOException $e) {
            $error_message = "Login error: " . $e->getMessage();
        }
    } else {
        $error_message = "All fields are required.";
    }
}
?>


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Magpie Engineering Login</title>
    <link rel="stylesheet" href="login.css">
    <link rel="shortcut icon" href="favicon.ico" type="image/x-icon">
    
</head>
<body>
    <div class="login-container">
        <div class="login-header">
            Magpie Engineering Pvt. Ltd.
            <form id="loginForm" method="POST" action="">
            <div class="input-group">
                <input type="text" name="report_id" placeholder="Reference ID" class="input-field" required>
            </div>
            <div class="input-group">
                <input type="password" name="password" placeholder="Password" class="input-field" required>
            </div>
            <div class="input-group">
        <input type="text" name="otp" placeholder="Enter OTP" class="input-field" required>
    </div>
            <button type="submit" name="login" class="login-btn">Log In</button>
        </form>
        <?php if (!empty($error_message)) : ?>
            <div class="error-message"><?php echo htmlspecialchars($error_message); ?></div>
        <?php endif; ?>
      </div>

</body>
</html>