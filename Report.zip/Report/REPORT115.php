<?php include('auth.php'); ?>
<?php




ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

// Increase PHP execution time and memory limit
ini_set('max_execution_time', 600); // Increase execution time to 600 seconds (10 minutes)
ini_set('memory_limit', '4096M'); // Increase memory limit to 4096MB
// Start session





$host = 'localhost';
$db = 'project_db';
$username = 'root';
$password = '';
$conn = new mysqli($host, $username, $password, $db);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$reference_id = $_SESSION['reference_id'] ?? null;
$images = [];
$oldImages = [];

if ($reference_id) {
    // Fetch new images from uploaded_images
    $query = "SELECT * FROM uploaded_images WHERE reference_id = ?";
    $stmt = $conn->prepare($query);
    $stmt->bind_param("s", $reference_id);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows > 0) {
        $row = $result->fetch_assoc();
        for ($i = 1; $i <= 50; $i++) {
            $imgField = "image$i";
            $images[] = !empty($row[$imgField]) ? 'data:image/jpeg;base64,' . base64_encode($row[$imgField]) : null;
        }
    }

    // Fetch old_reference_id from mis table
    $oldRefQuery = "SELECT old_reference_id FROM mis WHERE reference_id = ?";
    $oldStmt = $conn->prepare($oldRefQuery);
    $oldStmt->bind_param("s", $reference_id);
    $oldStmt->execute();
    $oldRefResult = $oldStmt->get_result();

    if ($oldRefResult->num_rows > 0) {
        $oldRow = $oldRefResult->fetch_assoc();
        $old_reference_id = $oldRow['old_reference_id'];

        if ($old_reference_id) {
            // Fetch old images from final_uploaded_images
            $oldImgQuery = "SELECT * FROM final_uploaded_images WHERE reference_id = ?";
            $oldImgStmt = $conn->prepare($oldImgQuery);
            $oldImgStmt->bind_param("s", $old_reference_id);
            $oldImgStmt->execute();
            $oldImgResult = $oldImgStmt->get_result();

            if ($oldImgResult->num_rows > 0) {
                $oldImgRow = $oldImgResult->fetch_assoc();
                for ($i = 1; $i <= 20; $i++) {
                    $imgField = "image$i";
                    $oldImages[] = !empty($oldImgRow[$imgField]) ? 'data:image/jpeg;base64,' . base64_encode($oldImgRow[$imgField]) : null;
                }
            }
        }
    }
}

// Handle form submission
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $valid = true;
    $uploadImages = [];

    for ($i = 1; $i <= 20; $i++) {
        if (isset($_FILES["image$i"]) && $_FILES["image$i"]['error'] === UPLOAD_ERR_OK) {
            $fileTmpPath = $_FILES["image$i"]['tmp_name'];
            $fileSize = $_FILES["image$i"]['size'];
            $fileType = mime_content_type($fileTmpPath);

            if ($fileSize > 2 * 1024 * 1024 || !in_array($fileType, ['image/jpeg', 'image/png'])) {
                $message = "File $i is invalid. Ensure it is a JPEG/PNG under 2MB.";
                $valid = false;
                break;
            }

            $uploadImages[$i] = file_get_contents($fileTmpPath);
        } else {
            $uploadImages[$i] = null;
        }
    }

    if ($valid && $reference_id) {
        $query = "INSERT INTO final_uploaded_images 
                  (reference_id, " . implode(", ", array_map(fn($i) => "image$i", range(1, 20))) . ") 
                  VALUES (?, " . implode(", ", array_fill(0, 20, "?")) . ")";

        $stmt = $conn->prepare($query);
        $types = "s" . str_repeat("b", 20);
        $params = array_merge([$reference_id], array_values($uploadImages));
        $stmt->bind_param($types, ...$params);

        foreach ($uploadImages as $key => $imageData) {
            if ($imageData !== null) {
                $stmt->send_long_data($key, $imageData);
            }
        }

        if ($stmt->execute()) {
            $message = "Images saved successfully.";
        } else {
            $message = "Error saving images: " . $stmt->error;
        }
    } else {
        $message = "Reference ID is not set or validation failed.";
    }
}

if (isset($message)) {
    echo "<script>
            alert('" . addslashes($message) . "');
            window.location.href = 'REPORT115.php';
          </script>";
}

$conn->close();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Image Upload Form with Slider</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
    <link rel="shortcut icon" href="favicon.ico" type="image/x-icon">
    <!-- <link rel="stylesheet" href="REPORT0115.css"> -->
    <style>
        /* Loader Overlay */
        #loaderOverlay {
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background-color: rgba(255, 255, 255, 0.95);
            z-index: 9999;
            display: flex;
            justify-content: center;
            align-items: center;
            font-size: 2em;
            color: #333;
        }

        /* Optional: Prevent scrolling while loading */
        body.loading {
            overflow: hidden;
        }

        /* Dim all content when loading */
        #mainContent {
            pointer-events: none; /* Disable interaction */
            opacity: 0.5;
        }

        body:not(.loading) #mainContent {
            pointer-events: auto;
            opacity: 1;
        }
        body {
    font-family: Arial, sans-serif;
    margin: 0;
      text-transform: uppercase;
    padding: 0;
    background-color: #f4f4f4;
}

.header {
    text-align: center;
    margin: 20px 0;
}

.container {
    display: flex;
    flex-direction: column;
    /* Changed to column layout */
    gap: 20px;
    padding: 20px;
    align-items: flex-start;
    margin-left: 20px;
}

.box {
    width: 300px;
    height: 300px;
    border: 2px dashed #aaa;
    display: flex;
    flex-direction: column;
    justify-content: center;
    align-items: center;
    background-color: #fff;
    box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
    position: relative;
    margin-left: 10%;
}

.box img {
    max-width: 100%;
    max-height: 80%;
}

/* Slider modal styling */
.slider-modal {
    position: fixed;
    top: 0;
    right: -50%;
    /* Start off-screen on the right */
    width: 50%;
    height: 100vh;
    display: flex;
    justify-content: center;
    align-items: center;
    transition: right 0.5s ease;
    /* Smooth sliding transition */
    visibility: hidden;
    /* Hidden by default */
}

.slider-modal.show {
    right: 0;
    /* Slide in from the right */
    visibility: visible;
    /* Make it visible when shown */
}

.slider {
    position: relative;
    width: 100%;
    height: 70%;
    background-color: #fff;
    display: flex;
    justify-content: center;
    align-items: center;
    flex-direction: column;
    border-radius: 10px;
    overflow: hidden;
    box-shadow: 0 4px 6px rgba(0, 0, 0, 0.2);
}

.slider img {
    max-width: 90%;
    max-height: 70%;
    border-radius: 10px;
}

.slider .arrow {
    position: absolute;
    top: 50%;
    font-size: 2rem;
    font-weight: bold;
    color: black;
    cursor: pointer;
    transform: translateY(-50%);
}

.slider .arrow.left {
    left: 10px;
}

.slider .arrow.right {
    right: 10px;
}

.slider .buttons {
    margin-top: 10px;
    display: flex;
    gap: 10px;
}

.slider .close {
    position: absolute;
    top: 10px;
    right: 10px;
    font-size: 1.5rem;
    cursor: pointer;
    background: none;
    border: none;
    color: black;
}

/* Title in slider */
.slider h3 {
    font-style: italic;
    color: #333;
    margin-bottom: 10px;
}

/* Sidebar styles */
/* Sidebar */
.rotating-text {
    color: black;
    perspective: 1000px;
    /* Adds a 3D perspective effect */
    font-size: 1.5rem;
    font-weight: bold;
    width: 100%;
    animation: rotate360 3s linear infinite;
    display: inline-block;
    margin-bottom: 10px;
    transform-origin: center center;
    /* Rotates around its center */
    text-align: center;
    /* margin-left:20px; */
    font-style: italic;
    text-shadow:
        1px 1px 2px rgba(235, 244, 243, 0.97),
        2px 2px 4px rgba(246, 242, 242, 0.4),
        3px 3px 6px rgba(249, 252, 252, 0.89),
        4px 4px 8px rgba(248, 242, 247, 0.93),
        5px 5px 10px rgba(232, 236, 237, 0.4);
}

/* Keyframes for rotating the text */
@keyframes rotate360 {
    0% {
        transform: rotateY(0deg);
        /* Starts with no rotation */
    }

    50% {
        transform: rotateY(0deg);
        /* Half rotation */
    }

    100% {
        transform: rotateY(360deg);
        /* Full rotation */
    }
}

.logo {
    /* width: 50px; */
    height: 43px;
    padding: 12px;
    padding-bottom: 33px;
}

#sidebar {
    background: #B0C4DE;
    /* Light Steel Blue */
    color: #2C3E50;
    position: fixed;
    left: -250px;
    top: 0;
    width: 250px;
    height: 100%;
    /* background-color: #111; */
    color: white;
    transition: left 0.3s ease;
    padding: 20px;
}

#sidebar.active {
    left: 35px;
    /* background:grey; */
}

.sidebar {
    width: 250px;
    background: #B0C4DE;
    /* Light Steel Blue */
    /* background:rgba(245, 245, 245, 0.37); Light Steel Blue */
    color: black;
    /* Dark Grayish Blue */
    padding: 20px;
    height: 100vh;
    position: fixed;
    left: 0;
    top: 0;
    z-index: 1000;
    transition: transform 0.3s ease-in-out;
}

.sidebar.hidden {
    transform: translateX(-100%);
}

.sidebar h1 {
    font-size: 20px;
    margin-top: 10px;
    margin-bottom: 20px;
    color: #2C3E50;
}

.sidebar a {
    padding: 15px 20px;
    margin: 10px 0;
    text-decoration: none;
    color: #2C3E50;
    /* Dark Grayish Blue */
    font-size: 16px;
    font-style: italic;
    font-weight: 500;
    margin-bottom: 70px;
    border-radius: 5px;
    transition: all 0.3s ease;
    display: flex;
    align-items: center;
}

.sidebar a:hover,
.sidebar a.active {
    background: #4A90E2;
    /* Light Blue */
    transform: translateX(10px);
    color: white;
}

.sidebar a .icon {
    margin-right: 15px;
    font-size: 18px;
}

/* Toggle Button */
#toggleSidebar {
    border-radius: 20%;
    position: fixed;
    top: 0px;
    /* Adjusted for better placement */
    left: 0px;
    /* Adjusted for better placement */
    z-index: 1000;
    background-color: rgb(130, 183, 226);
    color: white;
    border: none;
    padding: 6px 12px;
    /* Added padding for a more clickable area */
    cursor: pointer;
    box-shadow: 0 4px 8px rgba(0, 0, 0, 0.7);
    /* Adds a soft shadow for depth */
    transition: all 0.3s ease;
    /* Smooth transition for hover and active states */
}

/* Button hover effect */
#toggleSidebar:hover {
    background-color: #1c6abf;
    /* Slightly darker shade on hover */
    transform: scale(1);
    /* Slightly enlarges the button for a professional hover effect */
    box-shadow: 0 6px 12px rgba(0, 0, 0, 0.3);
    /* Stronger shadow on hover */
}

/* Active state for the button */
#toggleSidebar.active {
    background-color: #1a4f82;
    /* Darker shade for active state */
    transform: rotate(180deg);
    /* Smooth rotate effect when the sidebar is active */
}

/* Button icon (if you use an icon inside the button) */
#toggleSidebar i {
    font-size: 18px;
    /* Adjust the icon size */
    transition: transform 0.3s ease;
    /* Smooth transition when rotating */
}

.watch-icon {
    margin-right: 16px;
    /* Adds space between the search text and the watch icon */
    color: #555;
    /* Optional: sets the color of the watch icon */
}

#toggleSidebar {
    border-radius: 20%;
    position: fixed;
    top: 0px;
    /* Adjust for better placement */
    /* right: -35px; Position it just outside the sidebar */
    z-index: 1001;
    background-color: rgb(130, 183, 226);
    color: white;
    border: none;
    padding: 6px 12px;
    cursor: pointer;
    box-shadow: 0 4px 8px rgba(0, 0, 0, 0.7);
    transition: all 0.3s ease;
}

/* Button hover effect */
#toggleSidebar:hover {
    background-color: #1c6abf;
    box-shadow: 0 6px 12px rgba(0, 0, 0, 0.3);
}

/* Active state for the button */
#toggleSidebar.active {
    background-color: #1a4f82;
    transform: rotate(180deg);
    /* Smooth 180-degree rotation */
    box-shadow: 0 6px 12px rgba(0, 0, 0, 0.5);
}

/* Sidebar */
#sidebar.active+#toggleSidebar {
    right: 250px;
    /* Adjust so button moves into view */
}

/* Sidebar when active */
#sidebar.active {
    left: 0px;
}

/* Sidebar hidden state */
#sidebar {
    position: fixed;
    left: -318px;
    top: 0;
    width: 250px;
    height: 100%;
    background: #B0C4DE;
    color: white;
    transition: left 0.3s ease;
}

#pdf-container {
    width: 100%;
    height: 100%;
    overflow: auto;
}

canvas {
    display: block;
    margin: 0 auto;
}

/* Modal background */
/* Modal background */
.modal {
    display: none;
    /* Hidden by default */
    position: fixed;
    /* Stay in place */
    z-index: 1;
    /* Sit on top */
    left: 0;
    top: 0;
    width: 100%;
    /* Full width */
    height: 100%;
    /* Full height */
    overflow: auto;
    /* Enable scroll if needed */
    background-color: rgba(0, 0, 0, 0.6);
    /* Slightly darker overlay for a more professional look */
    animation: fadeIn 0.6s ease-out;
    /* Smooth fade-in effect */
}

/* Modal Content */
.modal {
    display: none;
    /* Hidden by default */
    position: fixed;
    /* Stay in place */
    z-index: 1;
    /* Sit on top */
    left: 0;
    top: 0;
    width: 100%;
    /* Full width */
    height: 100%;
    /* Full height */
    overflow: auto;
    /* Enable scroll if needed */
    background-color: rgba(0, 0, 0, 0.6);
    /* Slightly darker overlay for a more professional look */
    animation: fadeIn 0.6s ease-out;
    /* Smooth fade-in effect */
}

/* Modal Content */
.modal-content {
    font-family: 'Helvetica Neue', sans-serif;
    /* Modern and clean font */
    color: #333;
    /* Dark text for good readability */
    font-size: 12px;
    /* Keeping the font size as requested */
    background: linear-gradient(145deg, rgb(196, 216, 236), rgb(201, 212, 218));
    /* Soft gradient background */
    border-radius: 12px;
    /* Rounded corners */
    margin: auto;
    margin-top: 40px;
    padding-left: 40px;
    /* padding-right: 40px; */
    /* padding-top: 30px; Extra padding at the top for balance */
    /* padding-bottom: 30px; Extra padding at the bottom for balance */
    border: 1px solid #ccc;
    /* Light border for subtle effect */
    width: 70%;
    /* Responsive width */
    transform: scale(0.8);
    /* Initial scale for animation */
    animation: scaleUp 0.5s ease-in-out forwards;
    /* Smooth scaling animation */
    box-shadow: 0 15px 25px rgba(0, 0, 0, 0.1);
    /* Soft shadow for depth */
    transition: all 0.3s ease-in-out;
    /* Smooth transition effect */
    overflow: hidden;
    /* To ensure smooth edges */
}

/* Modal fade-in animation */
@keyframes fadeIn {
    from {
        opacity: 0;
    }

    to {
        opacity: 1;
    }
}

/* Scale-up animation */
@keyframes scaleUp {
    from {
        transform: scale(0.8);
        opacity: 0;
    }

    to {
        transform: scale(1);
        opacity: 1;
    }
}

/* Adjust the close button styling */
.slider .close {
    position: absolute;
    top: 10px;
    right: 10px;
    font-size: 1.5rem;
    cursor: pointer;
    background: none;
    border: none;
    color: black;
    transition: color 0.3s ease;
}

/* The close button inside modal */
.close {
    float: right;
    color: #e74c3c;
    font-size: 38px;
    /* Larger size for close button */
    font-weight: bold;
    cursor: pointer;
    transition: color 0.3s ease, transform 0.3s ease-in-out;
    padding: 0 10px;
    /* Extra space around close button */
}

.close:hover {
    color: #c0392b;
    /* Change color on hover */
    transform: scale(1.2);
    /* Slightly enlarge the close button on hover */
}


/* Stylish list items inside the modal */
.modal-content ul {
    list-style-type: decimal;
    /* Use numbers for list items */
    margin-top: 20px;
    padding-left: 25px;
    /* Add padding to list items */
    color: #555;
    /* Lighter text color for better contrast */
}

.modal-content ul li {
    /* margin-bottom: 10px; */
    line-height: 1.6;
    /* Increased line height for better readability */
    padding-left: 10px;
    /* Padding to align list items nicely */
    transition: transform 0.2s ease-in-out;
    /* Smooth transition effect on hover */
}

.modal-content ul li:hover {
    transform: translateX(5px);
    /* Subtle animation on hover for list items */
}

/* Optional: Add a smooth transition effect when content changes */
.modal-content {
    transition: transform 0.5s ease, opacity 0.5s ease;
}

.tab-links {
  position: fixed;
  top: 0;
  left: 0; right: 0;
  z-index: 999;
  display: flex;
  justify-content: space-between;
  padding: 7px;
    gap:10px;
  overflow-x: auto;
  backdrop-filter: blur(12px);
  border-bottom: 2px solid rgba(0,0,0,0.05);
  box-shadow: 0 2px 10px rgba(0,0,0,0.08);
  text-align: center;
}

.tab-links .tab {
   border: 1px solid #ddd;
  padding:2px 32px;
  border-radius: 50px;
  font-size: 14px;
  font-weight: bold;
  color: #444;

  transition: all 0.3s ease;
  cursor: pointer;
}

.tab-links .tab.active {
  background: linear-gradient(135deg, #9d7cc1ff, #5d7aacff);
  color: #fff;
    box-shadow: 0 12px 30px rgba(106, 17, 203, 0.35),
              0 6px 15px rgba(37, 117, 252, 0.25);
  transition: all 0.5s cubic-bezier(0.25, 1, 0.5, 1);
  animation: gradientMove 4s ease infinite, float 6s ease-in-out infinite;
  transform: scale(1.05);
  box-shadow: 0 4px 12px rgba(0,0,0,0.2);

}

/* Tab Icon */
.tab img {
  width: 45px;
  height: 45px;
  margin-bottom:5px;
  transition: transform 0.3s ease;
}
.tab:hover img {
  transform: rotate(10deg) scale(1.1);
}


/* Optional: Adjust body or main content margin to accommodate the fixed navbar height */
body {
    margin: 0;
    padding-top: 80px;
    /* Adjust this value based on your navbar's height */
}

/* Styling the scrollbar for the entire page */
::-webkit-scrollbar {
    width: 12px;
    /* Width of the vertical scrollbar */
    height: 10px;
    /* Height of horizontal scrollbar */
}

/* Styling the scrollbar track */
::-webkit-scrollbar-track {
    background: linear-gradient(135deg, #f0f0f0, #e0e0e0);
    /* Light gradient track */
    border-radius: 10px;
    /* Rounded corners */
    box-shadow: inset 0 0 10px rgba(0, 0, 0, 0.1);
    /* Subtle shadow */
}

/* Styling the scrollbar thumb (the draggable part) */
::-webkit-scrollbar-thumb {
    background: linear-gradient(135deg, #2f7cab, #0056b3);
    /* Gradient thumb */
    border-radius: 10px;
    /* Rounded corners */
    border: 3px solid transparent;
    /* Add space around thumb */
    background-clip: content-box;
    /* Ensures the thumb’s background doesn’t overlap the border */
    transition: background 0.3s ease, transform 0.3s ease;
    /* Smooth transition for hover */
}

/* Hover effect for the scrollbar thumb */
::-webkit-scrollbar-thumb:hover {
    background: linear-gradient(135deg, #0056b3, #003d80);
    /* Darker gradient on hover */
    transform: scale(1.1);
    /* Slightly enlarge the thumb */
}

/* Styling the horizontal scrollbar */
::-webkit-scrollbar-horizontal {
    height: 8px;
}

/* Styling the horizontal scrollbar track */
::-webkit-scrollbar-track-horizontal {
    background: linear-gradient(135deg, #f0f0f0, #e0e0e0);
    /* Light gradient track */
    border-radius: 10px;
    box-shadow: inset 0 0 10px rgba(0, 0, 0, 0.1);
}

/* Styling the horizontal scrollbar thumb */
::-webkit-scrollbar-thumb-horizontal {
    background: linear-gradient(135deg, #2f7cab, #0056b3);
    border-radius: 10px;
    border: 3px solid transparent;
    background-clip: content-box;
    transition: background 0.3s ease, transform 0.3s ease;
}

/* Hover effect for horizontal scrollbar thumb */
::-webkit-scrollbar-thumb-horizontal:hover {
    background: linear-gradient(135deg, #0056b3, #003d80);
    transform: scale(1.1);
    /* Slightly enlarge the thumb */
}
         .header {
 font-size:15px;background: linear-gradient(135deg, #e4dee7ff);
  color:black;
  font-weight:600;
  padding:3px;
  text-align: center;
  font-size: 20px;
  font-weight: 700;
  letter-spacing: 1px;
  border-bottom: 4px solid #fff;
  box-shadow: 0 4px 15px rgba(0,0,0,0.2);
  text-transform: uppercase;
}
/* Enhanced Submit Button */
.submit-button {
  display: flex;
  justify-content: center;
  margin: 40px 0;
  perspective: 1000px;
}

/* Button styling */
.submit-button button,
.submit-button input[type="submit"] {
  background: linear-gradient(135deg, #6a11cb 0%, #2575fc 100%);
  background-size: 200% 200%;
  border: none;
  padding: 8px 35px;
  border-radius: 999px;
  color: #fff;
  font-size: 20px;
  cursor: pointer;
  font-weight: 800;
  letter-spacing: 0.5px;
  box-shadow: 0 12px 30px rgba(106, 17, 203, 0.35),
              0 6px 15px rgba(37, 117, 252, 0.25);
  transition: all 0.5s cubic-bezier(0.25, 1, 0.5, 1);
  animation: gradientMove 4s ease infinite, float 6s ease-in-out infinite;
  position: relative;
  overflow: hidden;
  outline: none;
  -webkit-tap-highlight-color: transparent;
  transform-style: preserve-3d;
  text-transform: uppercase;
}

/* Shimmer highlight effect */
.submit-button button::before {
  content: "";
  position: absolute;
  top: -50%;
  left: -50%;
  width: 170%;
  height: 170%;
  background: linear-gradient(
    60deg, 
    rgba(255,255,255,0) 0%, 
    rgba(255,255,255,0.15) 50%, 
    rgba(255,255,255,0) 100%
  );
  transform: rotate(25deg) translateX(-100%);
  transition: transform 1.2s cubic-bezier(0.23, 1, 0.32, 1);
  pointer-events: none;
}

/* Hover effects */
.submit-button button:hover {
  transform: translateY(-8px) scale(1.08) rotateX(10deg);
  box-shadow: 0 25px 50px rgba(106, 17, 203, 0.45),
              0 15px 30px rgba(37, 117, 252, 0.35),
              0 0 40px rgba(255, 255, 255, 0.2);
  filter: brightness(1.15) saturate(1.2);
  letter-spacing: 1px;
}

.submit-button button:hover::before {
  transform: rotate(25deg) translateX(100%);
}

/* Active (press) effect */
.submit-button button:active {
  transform: translateY(-2px) scale(0.98);
  box-shadow: 0 8px 20px rgba(106, 17, 203, 0.3);
  transition: all 0.1s ease;
}

/* Pulsing glow effect */
.submit-button button::after {
  content: "";
  position: absolute;
  inset: -4px;
  border-radius: 999px;
  background: linear-gradient(135deg, #6a11cb, #2575fc, #9d7cc1, #5d7aac);
  background-size: 300% 300%;
  z-index: -1;
  filter: blur(12px);
  opacity: 0.7;
  animation: gradientMove 5s ease infinite, pulse 3s ease infinite;
  pointer-events: none;
}

/* Sparkle particles */
.submit-button .sparkle {
  position: absolute;
  width: 4px;
  height: 4px;
  background: white;
  border-radius: 50%;
  pointer-events: none;
  opacity: 0;
  animation: sparkle 1.5s linear infinite;
}
/* Floating Side Buttons */
.side-buttons {
    position: fixed;
    top: 20%;
    right: 20px;
    display: flex;
    flex-direction: column;
    gap: 10px;
    z-index: 1000;
}

.side-buttons button {
    background-color: #2f7cab;
    border: none;
    padding: 10px;
    cursor: pointer;
    border-radius: 50%;
    width: 50px;
    height: 50px;
    display: flex;
    align-items: center;
    justify-content: center;
    transition: background-color 0.3s;
}

.side-buttons button img {
    width: 24px;
    height: 24px;
    filter: invert();
}

.side-buttons button:hover {
    background-color: #0056b3;
}

@media (max-width: 768px) {
    .side-buttons {
        top: 15%;
        right: 10px;
    }

    .tab-links {
        flex-wrap: wrap;
    }
}

@media (max-width: 480px) {
    .tab-links button {
        padding: 8px 10px;
    }

    .header {
        font-size: 16px;
    }

    td {
        font-size: 14px;
    }

    input[type="text"] {
        font-size: 14px;
    }

    .side-buttons {
        top: 10%;
        right: 5px;
    }
}

.image-preview-container {
    display: flex;
    flex-wrap: wrap;
    gap: 10px;
    margin-top: 20px;
    background-color: #f8f9fa;
    border: 2px dashed #dcdcdc;
    padding: 10px;
    border-radius: 8px;
    /* justify-content: center; */
    align-items: center;
    text-align: center;
}

.image-preview-container p {
    color: #888;
    font-size: 14px;
}

.image-preview-container.hidden {
    display: none;
}

/* File input trigger button styling */
.side-buttons button {
    background-color: #2f7cab;
    border: none;
    padding: 10px;
    cursor: pointer;
    border-radius: 50%;
    width: 50px;
    height: 50px;
    display: flex;
    align-items: center;
    justify-content: center;
    transition: background-color 0.3s;
}

.valuation-table {
    width: 100%;
    border-collapse: collapse;
    /* margin-bottom: 20px; */
    font-size: 15px;
    /* margin-top: -1.1%; */
}

.valuation-table th,
.valuation-table td {
    border: 1px solid black;
    padding: 8px;
    text-align: center;
}

.valuation-table th {
    color: white;
    font-weight: bold;
}

.valuation-table tr:nth-child(odd) td {
    background-color: #e9f5fb;
}

.valuation-table td {
    background-color: #fff;
    font-weight: normal;
}
.switch-label {
  display: flex;
  align-items: center;
  justify-content: flex-end;
  font-family: 'Segoe UI', sans-serif;
  font-size: 25px;
  font-weight: 500;
  margin: 20px 0;
}

.label-text {
  margin-right: 25px;
  color: #333;
}

.switch {
  position: relative;
  display: inline-block;
  width: 65px;
  height: 43px;
}

.switch input {
  opacity: 0;
  width: 0;
  height: 0;
}

.slider.round {
  position: absolute;
  cursor: pointer;
  background-color: #ccc;
  border-radius: 34px;
  top: 0;
  left: 0;
  right: 0;
  bottom: 0;
  transition: 0.4s;
  box-shadow: inset 0 0 5px rgba(0, 0, 0, 0.2);
}

.slider.round:before {
  position: absolute;
  content: "";
  height: 24px;
  width: 24px;
  left: 4px;
  bottom: 4px;
  background-color: white;
  transition: 0.4s;
  border-radius: 50%;
}

/* When ON */
.switch input:checked + .slider.round {
  background-color: #28a745;
  box-shadow: 0 0 8px #28a74580;
}

.switch input:checked + .slider.round:before {
  transform: translateX(28px);
}

.buttons {
    margin-top: 10px;
    display: flex;
    gap: 10px;
}

.button {
    padding: 5px 10px;
    border: none;
    border-radius: 5px;
 background: linear-gradient(135deg, #6a11cb 0%, #2575fc 100%);    color: white;
    cursor: pointer;
}
    </style>
</head>
<body class="loading">
    <!-- Loader -->
    <div id="loaderOverlay">LOADING, PLEASE WAIT...</div>
<!-- Sidebar -->
<button id="toggleSidebar">&#9776;</button>
<div id="sidebar" class="sidebar">
    <div style="display: flex">
        <img class="logo" src="logo.png" alt="" />
        <h1>Magpie Engineering</h1>
    </div>
    <div class="rotating-text">Report Drafter</div>
    <a href="clear_and_go_home.php"><i class="fas fa-home icon"></i>Home</a>        

  <a href="clear_sessions.php" class="active"><i class="fas fa-clock watch-icon"></i>Pending For Drafting</a>
 <a href="technical.php"><i class="fas fa-clipboard-list icon"></i> Preview Report</a>      
    <a href="clear_and_logout.php"><i class="fas fa-sign-out-alt icon"></i>Logout</a>
</div>

<!-- Form Container -->
<div class="form-container" id="formContainer">
    <?php if (!empty($message)): ?>
        <div class="success-message" style="text-align: center; padding: 10px; background-color: #dff0d8; color: #3c763d; border: 1px solid #d6e9c6; margin-bottom: 20px;">
            <?= htmlspecialchars($message) ?>
        </div>
    <?php endif; ?>

    <!-- Navigation Tabs -->
    <div class="tab-links">
        <button class="tab" onclick="location.href='REPORT3.php'"><img src="info.png" alt="Icon" width="50" height="50">INFO</button>
        <button class="tab" onclick="location.href='REPORT4.php'"><img src="general.png" alt="Icon" width="50" height="50" style="margin-bottom:4px;">GENERAL</button>
        <button class="tab" onclick="location.href='REPORT2.php'"><img src="location.png" alt="Icon" width="50" height="50">LOCATION</button>
        <button class="tab" onclick="location.href='REPORT5.php'"><img src="Zoning.png" alt="Icon" width="50" height="50">ZONING</button>
        <button class="tab" onclick="location.href='REPORT7.php'"><img src="value.png" alt="Icon" width="50" height="50">VALUE</button>
        <button class="tab" onclick="location.href='REPORT9.php'"><img src="Floor.png" alt="Icon" width="50" height="50">STRUCTURE</button>
        <button class="tab" onclick="location.href='REPORT10.php'"><img src="documents.png" alt="Icon" width="50" height="50">DOCUMENTS</button>
        <button class="tab active" onclick="location.href='REPORT115.php'"><img src="photo.png" alt="Icon" width="50" height="50">PHOTOS</button>
        
        
        <button class="tab" onclick="location.href='REPORT12.php'"><img src="remark.png" alt="Icon" width="50" height="50">REMARK</button>
        <div class="slider"></div>
    </div>

    <!-- Header -->
    <div class="header">
        <h3 style="font-style: italic;">IMAGE UPLOAD FORM</h3>
    </div>

    <!-- Container for Upload Boxes -->
    <div class="container" id="container"></div>

    <!-- Toggle Switch Below Image 12 -->
    <div class="form-group" id="toggleWrapper" style="text-align: center; margin-top: 50px;">
        <label class="switch-label">
            <span class="label-text">Add 8 More Photos</span>
            <label class="switch">
                <input type="checkbox" id="addMorePhotosToggle" onchange="toggleMorePhotoBoxes()">
                <span class="slider round"></span>
            </label>
        </label>
    </div>

    <!-- Select Modal (updated to show Old + New sections) -->
    <div id="selectModal" style="display:none; position:fixed; top:50px; left:0; width:100%; height:100%; background:rgba(0,0,0,0.85); overflow:auto; padding:30px; z-index:1000;">
        <span style="position:fixed; top:70px; right:70px; font-size:36px; color:white; cursor:pointer; z-index:1001;" onclick="closeSelectModal()">&times;</span>

        <div style="color:white; font-size:24px; margin-bottom:10px;text-align:center;">CURRENT ASSIGNMENT IMAGES</div>
        <div id="selectImageGrid" style="display:flex; flex-wrap:wrap; gap:15px; justify-content:center; margin-bottom: 40px;"></div>
<br>  <br>
        <div style="color:white; font-size:24px; margin-bottom:10px;text-align:center;">PREVIOUS REPORT IMAGES</div>
        <div id="oldImageGrid" style="display:flex; flex-wrap:wrap; gap:15px; justify-content:center;"></div>
    </div>

    <!-- Submit Form -->
    <form id="uploadForm" method="POST" action="REPORT115.php" enctype="multipart/form-data" onsubmit="disableSubmitButton()">
    <div class="submit-button">
        <button type="submit" name="action" value="submit" id="submitBtn">Submit</button>
    </div>
</form>

<script>
    function disableSubmitButton() {
        const submitBtn = document.getElementById('submitBtn');
        submitBtn.disabled = true;
        submitBtn.innerText = 'Submitting...'; // Optional: gives user feedback
    }
</script>


</div>
  <!-- Script to hide loader -->
    <script>
        // Run when page is fully loaded
        window.addEventListener('load', function () {
            // Hide loader
            document.getElementById('loaderOverlay').style.display = 'none';
            // Re-enable page interaction
            document.body.classList.remove('loading');
        });
    </script>
<script>
const baseTitles = [
    'External Photo', 'Kitchen', 'Selfie', 'Electric Meter', 'Google Map',
    'Other1', 'Other2', 'Other3', 'Other4', 'Other5', 'Other6', 'Other7'
];

const extraTitles = [
    'Other8', 'Other9', 'Other10', 'Other11', 'Other12', 'Other13', 'Other14', 'Other15'
];

// Images from PHP
const images = <?php echo json_encode($images); ?>;
const oldImages = <?php echo json_encode($oldImages); ?>;

let uploadedImages = [];
let uploadedTitles = [];
let currentBoxId = null;
const container = document.getElementById('container');

function createBox(title, index) {
    const box = document.createElement('div');
    box.className = 'box';
    box.id = `box${index + 1}`;
    box.innerHTML = `
        <h3 style="font-style: italic;">${title}</h3>
        <img id="img${index + 1}" src="" alt="No image selected">
        <div class="buttons">
            <button type="button" class="button" onclick="openSelectModal(${index + 1})">Select</button>
            <button type="button"class="button"  onclick="uploadImageBox(${index + 1})">Upload</button>
        </div>
    `;
    container.appendChild(box);

    if (index === 11) {
        const toggleWrapper = document.getElementById("toggleWrapper");
        container.appendChild(toggleWrapper);
    }
}

baseTitles.forEach((title, i) => createBox(title, i));

function openSelectModal(boxId) {
    currentBoxId = boxId;

    const newGrid = document.getElementById("selectImageGrid");
    const oldGrid = document.getElementById("oldImageGrid");
    newGrid.innerHTML = "";
    oldGrid.innerHTML = "";

    // Populate new images
    images.forEach((imgSrc, i) => {
        if (imgSrc) {
            const imgElem = document.createElement("img");
            imgElem.src = imgSrc;
            imgElem.style.width = "300px";
            imgElem.style.margin = "10px";
            imgElem.style.cursor = "pointer";
            imgElem.style.border = "3px solid white";
            imgElem.style.borderRadius = "10px";
            imgElem.onclick = () => selectImageForBox(imgSrc);
            newGrid.appendChild(imgElem);
        }
    });

    // Populate old images
    oldImages.forEach((imgSrc, i) => {
        if (imgSrc) {
            const imgElem = document.createElement("img");
            imgElem.src = imgSrc;
            imgElem.style.width = "300px";
            imgElem.style.margin = "10px";
            imgElem.style.cursor = "pointer";
            imgElem.style.border = "3px solid yellow";
            imgElem.style.borderRadius = "10px";
            imgElem.onclick = () => selectImageForBox(imgSrc);
            oldGrid.appendChild(imgElem);
        }
    });

    document.getElementById("selectModal").style.display = "block";
}

function selectImageForBox(src) {
    const targetImg = document.getElementById(`img${currentBoxId}`);
    targetImg.src = src;
    uploadedImages[currentBoxId - 1] = src;
    uploadedTitles[currentBoxId - 1] = baseTitles.concat(extraTitles)[currentBoxId - 1];
    closeSelectModal();
}

function closeSelectModal() {
    document.getElementById("selectModal").style.display = "none";
}
function uploadImageBox(id) {
    const input = document.createElement('input');
    input.type = 'file';
    input.accept = 'image/jpeg, image/png';

    input.addEventListener('change', (e) => {
        const file = e.target.files[0];
        if (!file) return;

        const reader = new FileReader();
        reader.onload = function (event) {
            const img = new Image();
            img.onload = function () {
                const canvas = document.createElement('canvas');
                canvas.width = img.width;
                canvas.height = img.height;

                const ctx = canvas.getContext('2d');
                ctx.drawImage(img, 0, 0);

                let quality = 0.85;

                function compressAndCheck() {
                    canvas.toBlob(function (blob) {
                        if (blob.size <= 1024 * 1024 || quality < 0.4) {
                            const finalReader = new FileReader();
                            finalReader.onloadend = function () {
                                const base64data = finalReader.result;
                                document.getElementById(`img${id}`).src = base64data;
                                uploadedImages[id - 1] = base64data;
                                uploadedTitles[id - 1] = baseTitles.concat(extraTitles)[id - 1];
                            };
                            finalReader.readAsDataURL(blob);
                        } else {
                            quality -= 0.05;
                            compressAndCheck();
                        }
                    }, 'image/jpeg', quality);
                }

                compressAndCheck();
            };
            img.src = event.target.result;
        };

        reader.readAsDataURL(file);
    });

    input.click();
}

function dataURItoBlob(dataURI) {
    const byteString = atob(dataURI.split(',')[1]);
    const arrayBuffer = new ArrayBuffer(byteString.length);
    const uintArray = new Uint8Array(arrayBuffer);
    for (let i = 0; i < byteString.length; i++) {
        uintArray[i] = byteString.charCodeAt(i);
    }
    return new Blob([uintArray], { type: 'image/jpeg' });
}

document.getElementById('uploadForm').addEventListener('submit', function (e) {
    e.preventDefault();
    const formData = new FormData(this);

    uploadedImages.forEach((image, index) => {
        if (image) {
            const blob = dataURItoBlob(image);
            formData.append(`image${index + 1}`, blob);
        }
    });

    fetch('REPORT115.php', {
        method: 'POST',
        body: formData
    })
    .then(res => res.text())
    .then(msg => {
        alert("Form Submitted Successfully!");
        window.location.reload();
    })
    .catch(err => console.error('Upload Error:', err));
});

function toggleMorePhotoBoxes() {
    const isChecked = document.getElementById('addMorePhotosToggle').checked;
    const start = 12;

    if (isChecked) {
        extraTitles.forEach((title, i) => {
            const index = start + i;
            if (!document.getElementById(`box${index + 1}`)) {
                createBox(title, index);
            }
        });
    } else {
        for (let i = 13; i <= 20; i++) {
            const box = document.getElementById(`box${i}`);
            if (box) box.remove();
        }
    }
}




    document.addEventListener("DOMContentLoaded", function () {
    let tabs = document.querySelectorAll(".tab-links .tab");
    let slider = document.querySelector(".tab-links .slider");

    function moveSlider(activeTab) {
        slider.style.width = activeTab.offsetWidth + "px";
        slider.style.left = activeTab.offsetLeft + "px";
    }

    tabs.forEach(tab => {
        tab.addEventListener("click", function () {
            tabs.forEach(t => t.classList.remove("active"));
            this.classList.add("active");
            moveSlider(this);
        });

        // Initialize position on load for the active tab
        if (tab.classList.contains("active")) {
            moveSlider(tab);
        }
    });
});

</script>
