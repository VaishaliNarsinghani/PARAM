<?php include('auth.php'); ?>

<?php
// List of all session keys to be cleared
$formSessionKeys = [
    'bank_details', 'property_details', 'address_details',
    'critical_parameters', 'area_valuation', 'axis_area_valuation',
    'floor_details', 'technical_details', 'remarks_table', 'negative_remarks','mandatory_details'
];

// Unset each session key
foreach ($formSessionKeys as $key) {
    unset($_SESSION[$key]);
}

// Optional: Clear reference_id and any other session key if needed
unset($_SESSION['reference_id']);

// Redirect to Pending_Report.php
header("Location: Pending_Report.php");
exit;
?>
