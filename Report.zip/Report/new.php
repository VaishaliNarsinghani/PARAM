<?php
  $reference_id = $_SESSION['reference_id'] ?? '';
    echo '<input type="hidden" name="reference_id" value="' . htmlspecialchars($reference_id) . '">';
?>
    
<table class="valuation-table" style="margin-top:10px;">
    <thead>
         <form  id="autosave-form" action="" method="POST" >
            <input type="hidden" name="reference_id" value="<?= htmlspecialchars($reference_id) ?>">
            <tr class="fixed-property-type-row" style="align-items:center;">
                <th colspan="3" style="font-size:15px;">Choose Property Type For Valuation:</th>
                <td colspan="3">
                    <select id="propertyType" name="propertyType" style="padding:10px 38%;border:2px solid red;" onchange="updateInsurableValue()" required>
                        <option value="select">Select Property Type</option>
                        <option value="Land and Building" <?= ($fieldss['propertyType'] ?? '') == "Land and Building" ? 'selected' : '' ?>>Land and Building</option>
                        <option value="Floor Property" <?= ($fieldss['propertyType'] ?? '') == "Floor Property" ? 'selected' : '' ?>>Floor Property</option>
                    </select>
                </td>
            </tr>
        </thead>

        <script>
        document.addEventListener("DOMContentLoaded", () => {
            const dropdown = document.getElementById("propertyType");
            const allFields = [
                "plot_square_feet", "plot_rate", "plot_valuation_computed",
                "carpet_square_feet", "carpet_rate", "carpet_valuation_computed",
                "construction_square_feet", "construction_rate", "construction_valuation_computed",
                "saleable_square_feet", "saleable_rate", "saleable_valuation_computed",
                "total_area_valuation",
                "actual_plot_square_feet", "actual_plot_rate", "actual_plot_valuation_computed",
                "actual_carpet_square_feet", "actual_carpet_rate", "actual_carpet_valuation_computed",
                "actual_construction_square_feet", "actual_construction_rate", "actual_construction_valuation_computed",
                "actual_saleable_square_feet", "actual_saleable_rate", "actual_saleable_valuation_computed",
                "total_actual_area_valuation",
                "car_parking", "car_parking_amount",
                "addition_amenities_description_2", "addition_amenities_amount_2",
                "addition_amenities_description_3", "addition_amenities_amount_3",
                "addition_amenities_description_4", "addition_amenities_amount_4",
                "amenities_total","final_carpet_area_square_feet",
                "final_plot_square_feet", "final_plot_rate", "finally_plot_valuation", "finally_plot_valuation_hidden",
                "final_construction_square_feet", "final_construction_rate", "finally_construction_valuation", "finally_construction_valuation_hidden",
                "dimension_as_per_site_north", "dimension_as_per_site_south",
                "dimension_as_per_site_east", "dimension_as_per_site_west",
                "dimension_as_per_document_north", "dimension_as_per_document_south",
                "dimension_as_per_document_east", "dimension_as_per_document_west",
                "total_finally_area_valuation", "distress_value_percent",
                "total_distress_value", "total_valuation_words", "distress_value_words",
                "enquiry_remarks", "gross_monthly_rental", "guideline_rate",
                "guideline_values", "replacement_cost", "final_area_square_feet",
                "final_area_rate", "insurable", "loading",
                "construction_name_1", "construction_area_sqft_1", "construction_rate_1",
                "construction_name_2", "construction_area_sqft_2", "construction_rate_2",
                "construction_name_3", "construction_area_sqft_3", "construction_rate_3",
                "axis_plot_area", "axis_plot_sanction", "axis_plot_document", "axis_plot_area_document",
                "axis_final_plot_square_feet", "axis_ground_actual", "axis_first_actual", "axis_second_actual", "axis_3_actual", "axis_4_actual", "axis_other_actual",
                "axis_basement_floor1", "axis_basement_floor2", "axis_basement_floor3",
                "axis_total_area", "axis_ground", "axis_1_floor", "axis_2_floor", "axis_3_floor", "axis_4_floor", "axis_other_floor",
                "axis_ground_approved_0", "axis_ground_approved_1", "axis_ground_approved_2", "axis_ground_approved_3", "axis_ground_approved_4", "axis_ground_approved_other",
                "axis_basement_approved_1", "axis_basement_approved_2", "axis_basement_approved_3", "axis_na_total_area",
                "axis_permissible_area", "axis_ground_permissible", "axis_first_permissible", "axis_second_permissible", "axis_third_permissible", "axis_forth_permissible", "axis_other_permissible_floors",
                "axis_basement_approved_4", "axis_basement_approved_5", "axis_basement_approved_6",
                "axis_total_considered_area", "axis_ground_considered", "axis_first_considered", "axis_second_considered", "axis_third_considered", "axis_forth_considered", "axis_other_considered_floors",
                "axis_basement_approved_7", "axis_basement_approved_8", "axis_basement_approved_9","proposed_plot_area_sqft",
"proposed_plot_rate",
"proposed_plot_valuation",

"proposed_construction_name1",
"proposed_construction_area_sqft1",
"proposed_construction_rate1",
"proposed_construction_valuation1",

"proposed_construction_name2",
"proposed_construction_area_sqft2",
"proposed_construction_rate2",
"proposed_construction_valuation2",

"proposed_construction_name3",
"proposed_construction_area_sqft3",
"proposed_construction_rate3",
"proposed_construction_valuation3",

"proposed_builtup_area_sqft",
"proposed_builtup_rate",
"proposed_builtup_valuation",

"proposed_saleable_area_sqft",
"proposed_saleable_rate",
"proposed_saleable_valuation",

"proposed_final_area_valuation",
"gov_plot_area_sqft",
"gov_plot_area_rate",
"gov_plot_area_valuation",

"gov_construction_name1",
"gov_construction_area1",
"gov_construction_rate1",
"gov_construction_valuation1",

"gov_construction_name2",
"gov_construction_area2",
"gov_construction_rate2",
"gov_construction_valuation2",

"gov_construction_name3",
"gov_construction_area3",
"gov_construction_rate3",
"gov_construction_valuation3",

"gov_builtup_area_sqft",
"gov_builtup_area_rate",
"gov_builtup_area_valuation",

"gov_saleable_area_sqft",
"gov_saleable_area_rate",
"gov_saleable_area_valuation","construction_valuation_computed","construction_valuation_1","construction_valuation_2","construction_valuation_3","final_area_valuation",

"gov_final_area_valuation","estimated_cost_rs","estimated_cost_per_sqft","justified_estimated_cost_per_sqft","adoptable_justified_estimated_cost"
 ,"loading1","insurable_value_1","total_fair_finally_area_valuation"   

            ];

            function toggleFields() {
                const propertyType = dropdown.value;
                let enableFields = [];

                if (propertyType === "Land and Building") {
                    enableFields = [
                        "plot_square_feet", "plot_rate", "carpet_square_feet", "construction_square_feet", "construction_rate",
                        "actual_plot_square_feet", "actual_plot_rate", "actual_carpet_square_feet",
                        "actual_construction_square_feet", "actual_construction_rate",
                        "car_parking", "car_parking_amount","final_carpet_area_square_feet",
                        "addition_amenities_description_2", "addition_amenities_amount_2",
                        "addition_amenities_description_3", "addition_amenities_amount_3",
                        "addition_amenities_description_4", "addition_amenities_amount_4",
                        "final_plot_square_feet", "final_plot_rate",
                        "dimension_as_per_site_north", "dimension_as_per_site_south",
                        "dimension_as_per_site_east", "dimension_as_per_site_west",
                        "dimension_as_per_document_north", "dimension_as_per_document_south",
                        "dimension_as_per_document_east", "dimension_as_per_document_west",
                        "enquiry_remarks", "gross_monthly_rental", "guideline_rate",
                        "replacement_cost", "distress_value_percent",
                        "construction_name_1", "construction_area_sqft_1", "construction_rate_1",
                        "construction_name_2", "construction_area_sqft_2", "construction_rate_2",
                        "construction_name_3", "construction_area_sqft_3", "construction_rate_3",
                        "axis_plot_area", "axis_plot_sanction", "axis_plot_document", "axis_plot_area_document",
                        "axis_final_plot_square_feet", "axis_ground_actual", "axis_first_actual", "axis_second_actual", "axis_3_actual", "axis_4_actual", "axis_other_actual",
                        "axis_basement_floor1", "axis_basement_floor2", "axis_basement_floor3",
                        "axis_total_area", "axis_ground", "axis_1_floor", "axis_2_floor", "axis_3_floor", "axis_4_floor", "axis_other_floor",
                        "axis_ground_approved_0", "axis_ground_approved_1", "axis_ground_approved_2", "axis_ground_approved_3", "axis_ground_approved_4", "axis_ground_approved_other",
                        "axis_basement_approved_1", "axis_basement_approved_2", "axis_basement_approved_3", "axis_na_total_area",
                        "axis_permissible_area", "axis_ground_permissible", "axis_first_permissible", "axis_second_permissible", "axis_third_permissible", "axis_forth_permissible", "axis_other_permissible_floors",
                        "axis_basement_approved_4", "axis_basement_approved_5", "axis_basement_approved_6",
                        "axis_total_considered_area", "axis_ground_considered", "axis_first_considered", "axis_second_considered", "axis_third_considered", "axis_forth_considered", "axis_other_considered_floors",
                        "axis_basement_approved_7", "axis_basement_approved_8", "axis_basement_approved_9","proposed_plot_area_sqft",
"proposed_plot_rate",

"proposed_construction_name1",
"proposed_construction_area_sqft1",
"proposed_construction_rate1",

"proposed_construction_name2",
"proposed_construction_area_sqft2",
"proposed_construction_rate2",

"proposed_construction_name3",
"proposed_construction_area_sqft3",
"proposed_construction_rate3",


"gov_plot_area_sqft",
"gov_plot_area_rate",

"gov_construction_name1",
"gov_construction_area1",
"gov_construction_rate1",

"gov_construction_name2",
"gov_construction_area2",
"gov_construction_rate2",

"gov_construction_name3",
"gov_construction_area3",
"gov_construction_rate3",
 "final_area_square_feet", 


"estimated_cost_rs","estimated_cost_per_sqft","justified_estimated_cost_per_sqft","adoptable_justified_estimated_cost"
 ,"loading1","insurable_value_1"



                    ];
                } else if (propertyType === "Floor Property") {
                    enableFields = [
                        "carpet_square_feet", "carpet_rate", "construction_square_feet", "construction_rate",
                        "saleable_square_feet", "saleable_rate", "distress_value_percent",
                        "actual_saleable_square_feet", "actual_saleable_rate",
                        "dimension_as_per_site_north", "dimension_as_per_site_south",
                        "dimension_as_per_site_east", "dimension_as_per_site_west",
                        "dimension_as_per_document_north", "dimension_as_per_document_south",
                        "dimension_as_per_document_east", "dimension_as_per_document_west",
                        "car_parking", "car_parking_amount", "replacement_cost",
                        "addition_amenities_description_2", "addition_amenities_amount_2",
                        "addition_amenities_description_3", "addition_amenities_amount_3",
                        "addition_amenities_description_4", "addition_amenities_amount_4",
                        "final_area_square_feet", "final_area_rate",
                        "enquiry_remarks", "gross_monthly_rental", "guideline_rate",
                        "construction_name_1", "construction_area_sqft_1", "construction_rate_1",
                        "construction_name_2", "construction_area_sqft_2", "construction_rate_2",
                        "construction_name_3", "construction_area_sqft_3", "construction_rate_3",
                        "axis_plot_area", "axis_plot_sanction", "axis_plot_document", "axis_plot_area_document",
                        "axis_final_plot_square_feet", "axis_ground_actual", "axis_first_actual", "axis_second_actual", "axis_3_actual", "axis_4_actual", "axis_other_actual",
                        "axis_basement_floor1", "axis_basement_floor2", "axis_basement_floor3",
                        "axis_total_area", "axis_ground", "axis_1_floor", "axis_2_floor", "axis_3_floor", "axis_4_floor", "axis_other_floor",
                        "axis_ground_approved_0", "axis_ground_approved_1", "axis_ground_approved_2", "axis_ground_approved_3", "axis_ground_approved_4", "axis_ground_approved_other",
                        "axis_basement_approved_1", "axis_basement_approved_2", "axis_basement_approved_3", "axis_na_total_area",
                        "axis_permissible_area", "axis_ground_permissible", "axis_first_permissible", "axis_second_permissible", "axis_third_permissible", "axis_forth_permissible", "axis_other_permissible_floors",
                        "axis_basement_approved_4", "axis_basement_approved_5", "axis_basement_approved_6",
                        "axis_total_considered_area", "axis_ground_considered", "axis_first_considered", "axis_second_considered", "axis_third_considered", "axis_forth_considered", "axis_other_considered_floors",
                        "axis_basement_approved_7", "axis_basement_approved_8", "axis_basement_approved_9",
"final_carpet_area_square_feet",

"proposed_construction_name1",
"proposed_construction_area_sqft1",
"proposed_construction_rate1",

"proposed_construction_name2",
"proposed_construction_area_sqft2",
"proposed_construction_rate2",

"proposed_construction_name3",
"proposed_construction_area_sqft3",
"proposed_construction_rate3",

"proposed_builtup_area_sqft",
"proposed_builtup_rate",

"proposed_saleable_area_sqft",
"proposed_saleable_rate",



"gov_construction_name1",
"gov_construction_area1",
"gov_construction_rate1",

"gov_construction_name2",
"gov_construction_area2",
"gov_construction_rate2",

"gov_construction_name3",
"gov_construction_area3",
"gov_construction_rate3",

"gov_builtup_area_sqft",
"gov_builtup_area_rate",

"gov_saleable_area_sqft",
"gov_saleable_area_rate",

"estimated_cost_rs","estimated_cost_per_sqft","justified_estimated_cost_per_sqft","adoptable_justified_estimated_cost"
 ,"loading1","insurable_value_1"

                    ];
                }

                allFields.forEach(id => {
                    const el = document.getElementById(id);
                    if (el) {
                        const isEnabled = enableFields.includes(id);
                        if (isEnabled) {
                            el.removeAttribute("readonly");
                            el.style.backgroundColor = "#deffd7ff";
                        } else {
                            el.setAttribute("readonly", true);
                            el.style.backgroundColor = "#bebdc4ff";
                        }
                    }
                });
            }

            toggleFields();
            dropdown.addEventListener("change", toggleFields);
        });
        </script>

        <tr class="fixed-alert-row">
        </tr>

        <tr style="width:100%">
            <td>
                <div class="form-group">
                    <label class="checkbox-container">
                        <input type="checkbox" id="flag_special_submit" name="flag_special_submit" onchange="toggleSpecialText()" <?= isset($fieldss['flag_special_submit']) ? 'checked' : '' ?>>
                        <span class="checkmark"></span>
                        <span class="label-text">ONLY FOR AXIS BANK</span>
                    </label>
                </div>
            </td>
        </tr>
      
        <div class="full-width-table">
            <tr id="specialTextRow" style="display: none;">
                <td>
                    <div class="form-group">
                        <table border="1" cellpadding="8" cellspacing="0" style="width:100%; border-collapse: collapse;">
  <thead>
    <tr>
      <th colspan="3" style="text-align: center;">Plot Area</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <td> 

        <label for="axis_plot_area">Plot Area As Per Site</label><br>
        <input type="text" name="axis_plot_area" id="axis_plot_area" value="<?= $fieldss['axis_plot_area'] ?? '' ?>" readonly>
      </td>
      <td>
        <label for="axis_plot_sanction">Plot Area As Per Sanction</label><br>
        <input type="text" name="axis_plot_sanction" id="axis_plot_sanction" value="<?= $fieldss['axis_plot_sanction'] ?? '' ?>" readonly>
      </td>
      <td>
    <label for="axis_plot_document">Plot Area As Per Document</label><br>
     <input type="text" name="axis_plot_document" id="axis_plot_document" value="<?= $fieldss['axis_plot_document'] ?? '' ?>" readonly>
    </td>
    </tr>
  </tbody>
 <thead>
    <tr>
      <th colspan="3" style="text-align: left;">Plot Area</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <td>
        <label for="axis_plot_area_document">Plot Area As Per Document</label><br>
        <input type="text" name="axis_plot_area_document" id="axis_plot_area_document" value="<?= $fieldss['axis_plot_area_document'] ?? '' ?>" readonly>
      </td>
</tr>
  <thead>
    <tr><th colspan="3" style="text-align: center;">Actual Built-up Area</th></tr>
  </thead>
  <tbody>
    <tr>
     <td colspan="3">
  <label>Total Area</label><br>
  <input type="text" name="axis_final_plot_square_feet" id="axis_final_plot_square_feet" value="<?= $fieldss['axis_final_plot_square_feet'] ?? '' ?>" readonly style="width: 100%;">
</td>
</tr>
<tr>
  <td>
    <label>Ground Floor</label><br>
    <input type="text" name="axis_ground_actual" id="axis_ground_actual" value="<?= $fieldss['axis_ground_actual'] ?? '' ?>" readonly>
  </td>
  <td>
    <label>1st Floor</label><br>
    <input type="text" name="axis_first_actual" id="axis_first_actual" value="<?= $fieldss['axis_first_actual'] ?? '' ?>" readonly>
  </td>
  <td>
    <label>2nd Floor</label><br>
    <input type="text" name="axis_second_actual" id="axis_second_actual" value="<?= $fieldss['axis_second_actual'] ?? '' ?>" readonly>
  </td>
</tr>
<tr>
  <td>
    <label>3rd Floor</label><br>
    <input type="text" name="axis_3_actual" id="axis_3_actual" value="<?= $fieldss['axis_3_actual'] ?? '' ?>" readonly>
  </td>
  <td>
    <label>4th Floor</label><br>
    <input type="text" name="axis_4_actual" id="axis_4_actual" value="<?= $fieldss['axis_4_actual'] ?? '' ?>" readonly>
  </td>
  <td>
    <label>Other Floor</label><br>
    <input type="text" name="axis_other_actual" id="axis_other_actual" value="<?= $fieldss['axis_other_actual'] ?? '' ?>" readonly>
  </td>
</tr>
<tr>
  <td>
    <label>Basement Floor</label><br>
    <input type="text" name="axis_basement_floor1" id="axis_basement_floor1" value="<?= $fieldss['axis_basement_floor1'] ?? '' ?>" readonly>
  </td>
  <td>
    <label>Basement Floor</label><br>
    <input type="text" name="axis_basement_floor2" id="axis_basement_floor2" value="<?= $fieldss['axis_basement_floor2'] ?? '' ?>" readonly>
  </td>
  <td>
    <label>Basement Floor</label><br>
    <input type="text" name="axis_basement_floor3" id="axis_basement_floor3" value="<?= $fieldss['axis_basement_floor3'] ?? '' ?>" readonly>
  </td>
</tr>

  </tbody>

  <!-- Built-up Area As Per Document -->
<thead>
  <tr><th colspan="3" style="text-align: center;">Built-up Area As Per Document</th></tr>
</thead>
<tbody>
  <tr>
    <td colspan="3">
      <label>Total Area</label><br>
      <input type="text" name="axis_total_area" id="axis_total_area" value="<?= $fieldss['axis_total_area'] ?? '' ?>" readonly style="width: 100%;">
    </td>
  </tr>
  <tr>
    <td><label>Ground Floor</label><br><input type="text" name="axis_ground" id="axis_ground" value="<?= $fieldss['axis_ground'] ?? '' ?>" readonly></td>
    <td><label>1st Floor</label><br><input type="text" name="axis_1_floor" id="axis_1_floor" value="<?= $fieldss['axis_1_floor'] ?? '' ?>" readonly></td>
    <td><label>2nd Floor</label><br><input type="text" name="axis_2_floor" id="axis_2_floor" value="<?= $fieldss['axis_2_floor'] ?? '' ?>" readonly></td>
  </tr>
  <tr>
    <td><label>3rd Floor</label><br><input type="text" name="axis_3_floor" id="axis_3_floor" value="<?= $fieldss['axis_3_floor'] ?? '' ?>" readonly></td>
    <td><label>4th Floor</label><br><input type="text" name="axis_4_floor" id="axis_4_floor" value="<?= $fieldss['axis_4_floor'] ?? '' ?>" readonly></td>
    <td><label>Other Floor</label><br><input type="text" name="axis_other_floor" id="axis_other_floor" value="<?= $fieldss['axis_other_floor'] ?? '' ?>" readonly></td>
  </tr>
</tbody>

<!-- Approved Built-up Area -->
<thead>
  <tr><th colspan="3" style="text-align: center;">Approved Built-up Area</th></tr>
</thead>
<tbody>
  <tr>
    <td colspan="3">
      <label>Total Area</label><br>
      <input type="text" name="axis_na_total_area" id="axis_na_total_area" value="<?= $fieldss['axis_na_total_area'] ?? '' ?>"  style="width: 100%;">
    </td>
  </tr>
  <tr>
    <td><label>Ground Floor</label><br><input type="text" name="axis_ground_approved_0" id="axis_ground_approved_0" value="<?= $fieldss['axis_ground_approved_0'] ?? '' ?>" readonly></td>
    <td><label>1st Floor</label><br><input type="text" name="axis_ground_approved_1" id="axis_ground_approved_1" value="<?= $fieldss['axis_ground_approved_1'] ?? '' ?>" readonly></td>
    <td><label>2nd Floor</label><br><input type="text" name="axis_ground_approved_2" id="axis_ground_approved_2" value="<?= $fieldss['axis_ground_approved_2'] ?? '' ?>" readonly></td>
  </tr>
  <tr>
    <td><label>3rd Floor</label><br><input type="text" name="axis_ground_approved_3" id="axis_ground_approved_3" value="<?= $fieldss['axis_ground_approved_3'] ?? '' ?>" readonly></td>
    <td><label>4th Floor</label><br><input type="text" name="axis_ground_approved_4" id="axis_ground_approved_4" value="<?= $fieldss['axis_ground_approved_4'] ?? '' ?>" readonly></td>
    <td><label>Other Floor</label><br><input type="text" name="axis_ground_approved_other" id="axis_ground_approved_other" value="<?= $fieldss['axis_ground_approved_other'] ?? '' ?>" readonly></td>
  </tr>
  <tr>
    <td><label>Basement Floor</label><br><input type="text" name="axis_basement_approved_1" id="axis_basement_approved_1" value="<?= $fieldss['axis_basement_approved_1'] ?? '' ?>" readonly></td>
    <td><label>Basement Floor</label><br><input type="text" name="axis_basement_approved_2" id="axis_basement_approved_2" value="<?= $fieldss['axis_basement_approved_2'] ?? '' ?>" readonly></td>
    <td><label>Basement Floor</label><br><input type="text" name="axis_basement_approved_3" id="axis_basement_approved_3" value="<?= $fieldss['axis_basement_approved_3'] ?? '' ?>" readonly></td>
  </tr>
</tbody>

<!-- Permissible Area -->
<thead>
  <tr><th colspan="3" style="text-align: center;">Permissible Area</th></tr>
</thead>
<tbody>
  <tr>
    <td colspan="3">
      <label>Total Area</label><br>
      <input type="text" name="axis_permissible_area" id="axis_permissible_area" value="<?= $fieldss['axis_permissible_area'] ?? '' ?>" readonly style="width: 100%;">
    </td>
  </tr>
  <tr>
    <td><label>Ground Floor</label><br><input type="text" name="axis_ground_permissible" id="axis_ground_permissible" value="<?= $fieldss['axis_ground_permissible'] ?? '' ?>" readonly></td>
    <td><label>1st Floor</label><br><input type="text" name="axis_first_permissible" id="axis_first_permissible" value="<?= $fieldss['axis_first_permissible'] ?? '' ?>" readonly></td>
    <td><label>2nd Floor</label><br><input type="text" name="axis_second_permissible" id="axis_second_permissible" value="<?= $fieldss['axis_second_permissible'] ?? '' ?>" readonly></td>
  </tr>
  <tr>
    <td><label>3rd Floor</label><br><input type="text" name="axis_third_permissible" id="axis_third_permissible" value="<?= $fieldss['axis_third_permissible'] ?? '' ?>" readonly></td>
    <td><label>4th Floor</label><br><input type="text" name="axis_forth_permissible" id="axis_forth_permissible" value="<?= $fieldss['axis_forth_permissible'] ?? '' ?>" readonly></td>
    <td><label>Other Floor</label><br><input type="text" name="axis_other_permissible_floors" id="axis_other_permissible_floors" value="<?= $fieldss['axis_other_permissible_floors'] ?? '' ?>" readonly></td>
  </tr>
  <tr>
    <td><label>Basement Floor</label><br><input type="text" name="axis_basement_approved_4" id="axis_basement_approved_4" value="<?= $fieldss['axis_basement_approved_4'] ?? '' ?>" readonly></td>
    <td><label>Basement Floor</label><br><input type="text" name="axis_basement_approved_5" id="axis_basement_approved_5" value="<?= $fieldss['axis_basement_approved_5'] ?? '' ?>" readonly></td>
    <td><label>Basement Floor</label><br><input type="text" name="axis_basement_approved_6" id="axis_basement_approved_6" value="<?= $fieldss['axis_basement_approved_6'] ?? '' ?>" readonly></td>
  </tr>
</tbody>

<!-- Built-up Area Considered for Valuation -->
<thead>
  <tr><th colspan="3" style="text-align: center;">Built-up Area Considered for Valuation</th></tr>
</thead>
<tbody>
  <tr>
    <td colspan="3">
      <label>Total Area</label><br>
      <input type="text" name="axis_total_considered_area" id="axis_total_considered_area" value="<?= $fieldss['axis_total_considered_area'] ?? '' ?>" readonly style="width: 100%;">
    </td>
  </tr>
  <tr>
    <td><label>Ground Floor</label><br><input type="text" name="axis_ground_considered" id="axis_ground_considered" value="<?= $fieldss['axis_ground_considered'] ?? '' ?>" readonly></td>
    <td><label>1st Floor</label><br><input type="text" name="axis_first_considered" id="axis_first_considered" value="<?= $fieldss['axis_first_considered'] ?? '' ?>" readonly></td>
    <td><label>2nd Floor</label><br><input type="text" name="axis_second_considered" id="axis_second_considered" value="<?= $fieldss['axis_second_considered'] ?? '' ?>" readonly></td>
  </tr>
  <tr>
    <td><label>3rd Floor</label><br><input type="text" name="axis_third_considered" id="axis_third_considered" value="<?= $fieldss['axis_third_considered'] ?? '' ?>" readonly></td>
    <td><label>4th Floor</label><br><input type="text" name="axis_forth_considered" id="axis_forth_considered" value="<?= $fieldss['axis_forth_considered'] ?? '' ?>" readonly></td>
    <td><label>Other Floor</label><br><input type="text" name="axis_other_considered_floors" id="axis_other_considered_floors" value="<?= $fieldss['axis_other_considered_floors'] ?? '' ?>" readonly></td>
  </tr>
  <tr>
    <td><label>Basement Floor</label><br><input type="text" name="axis_basement_approved_7" id="axis_basement_approved_7" value="<?= $fieldss['axis_basement_approved_7'] ?? '' ?>" readonly></td>
    <td><label>Basement Floor</label><br><input type="text" name="axis_basement_approved_8" id="axis_basement_approved_8" value="<?= $fieldss['axis_basement_approved_8'] ?? '' ?>" readonly></td>
    <td><label>Basement Floor</label><br><input type="text" name="axis_basement_approved_9" id="axis_basement_approved_9" value="<?= $fieldss['axis_basement_approved_9'] ?? '' ?>" readonly></td>
  </tr>
</tbody>

</table>

      </div>
    </td>
  </tr>

</div>






               <!-- Side Buttons Section -->
               <div class="side-buttons">
  <button type="button" onclick="window.open('https://www.magpiecomp.com/QGIS/', '_blank')">
    <img src="https://cdn-icons-png.flaticon.com/512/535/535239.png" alt="Open QGIS" width="35px" height="35px">
  </button>

  <input type="file" id="imageInput" accept="image/*" style="display: none;">
  <input type="file" id="pdfInput" accept="application/pdf" style="display: none;">

  <span class="tooltip-text">RATE ?</span>
</div>
</div>
            <form id="autosave-form" method="post" action="REPORT7.php">
                <tr class="header">
                    <th colspan="6">AREA & VALUATION DETAILS</th>
                </tr>
                <tr class="header">
                    <th colspan="6" >APPROVED AREA & VALUATION</th>
                </tr>
                <tr>
                    <th style="background-color: lightskyblue; color: black; " colspan="2">AREA TYPE</th>
                    <th style="background-color: lightskyblue; color: black; ">SQUARE FEET</th>
                    <th style="background-color: lightskyblue; color: black; ">RATE/SQ.FT</th>
                    <th style="background-color: lightskyblue; color: black; " colspan="2">VALUATION (Rs.)</th>
                </tr>
            </thead>
            <tbody>
            <?php
        // Display the reference_id as a hidden field (assuming it will not be modified by the user)
            $reference_id = $_SESSION['reference_id'] ?? '';
            echo '<input type="hidden" name="reference_id" value="' . htmlspecialchars($reference_id) . '">';
?>



    <tr>
        <td colspan="2">Plot Area</td>
        <td><input type="text" id="plot_square_feet" name="plot_square_feet" value="<?= $fieldss['plot_square_feet'] ?? '' ?>"></td>
        <td><input type="text" id="plot_rate" name="plot_rate" value="<?= $fieldss['plot_rate'] ?? '0' ?>"></td>
        <td>
            <input type="text" id="plot_valuation_computed" readonly>
            <input type="hidden" name="plot_valuation_computed" id="plot_valuation_hidden">
        </td>
    </tr>
    <tr>
        <td colspan="2">Carpet Area</td>
        <td><input type="text" id="carpet_square_feet" name="carpet_square_feet" value="<?= $fieldss['carpet_square_feet'] ?? '' ?>"></td>
        <td><input type="text" id="carpet_rate" name="carpet_rate" value="<?= $fieldss['carpet_rate'] ?? '0' ?>"></td>
        <td>
            <input type="text" id="carpet_valuation_computed" readonly>
            <input type="hidden" name="carpet_valuation_computed" id="carpet_valuation_hidden">
        </td>
    </tr>
    <tr>
        <td colspan="2">Construction Built-Up Area</td>
        <td><input type="text" id="construction_square_feet" name="construction_square_feet" value="<?= $fieldss['construction_square_feet'] ?? '' ?>"></td>
        <td><input type="text" id="construction_rate" name="construction_rate" value="<?= $fieldss['construction_rate'] ?? '0' ?>"></td>
        <td>
            <input type="text" id="construction_valuation_computed" readonly>
            <input type="hidden" name="construction_valuation_computed" id="construction_valuation_hidden">
        </td>
    </tr>
    <tr>
        <td colspan="2">Saleable Area (Super Built-Up Area)</td>
        <td><input type="text" id="saleable_square_feet" name="saleable_square_feet" value="<?= $fieldss['saleable_square_feet'] ?? '1' ?>"></td>
        <td><input type="text" id="saleable_rate" name="saleable_rate" value="<?= $fieldss['saleable_rate'] ?? '0' ?>"></td>
        <td>
            <input type="text" id="saleable_valuation_computed" readonly>
            <input type="hidden" name="saleable_valuation_computed" id="saleable_valuation_hidden">
        </td>
    </tr>
    <tr>
        <td colspan="4">APPROVED AREA VALUATION (A) (i + ii + iii + iv)</td>
        <td>
            <input type="text" id="total_area_valuation" readonly>
            <input type="hidden" name="total_area_valuation" id="total_area_valuation_hidden">
        </td>
    </tr>


            </tbody>
        </table>
     
        <table class="valuation-table">
    <thead>
        <tr class="header">
            <th colspan="6">ACTUAL AREA & VALUATION</th>
        </tr>
        <tr>
            <th style="background-color: lightskyblue; color: black;" colspan="2">AREA TYPE</th>
            <th style="background-color: lightskyblue; color: black;">SQUARE FEET</th>
            <th style="background-color: lightskyblue; color: black;">RATE/SQ.FT</th>
            <th style="background-color: lightskyblue; color: black;" colspan="2">VALUATION (Rs.)</th>
        </tr>
    </thead>
    <tbody>

            <tr>
                <td colspan="2">Plot Area</td>
                <td><input type="text" id="actual_plot_square_feet" name="actual_plot_square_feet" value="<?= $fieldss['actual_plot_square_feet'] ?? '' ?>"></td>
                <td><input type="text" id="actual_plot_rate" name="actual_plot_rate" value="<?= $fieldss['actual_plot_rate'] ?? '' ?>"></td>
                <td>
                    <input type="text" id="actual_plot_valuation_computed" readonly>
                    <input type="hidden" name="actual_plot_valuation_computed" id="actual_plot_valuation_hidden" >
                </td>
                
            </tr>
            <tr>
                <td colspan="2">Carpet Area</td>
                <td><input type="text" id="actual_carpet_square_feet" name="actual_carpet_square_feet" value="<?= $fieldss['actual_carpet_square_feet'] ?? '' ?>"></td>
                <td><input type="text" id="actual_carpet_rate" name="actual_carpet_rate" value="<?= $fieldss['actual_carpet_rate'] ?? '' ?>"></td>
                <td>
                    <input type="text" id="actual_carpet_valuation_computed" readonly>
                    <input type="hidden" name="actual_carpet_valuation_computed" id="actual_carpet_valuation_hidden">
                </td>
            </tr>
            <tr>
                <td colspan="2">Construction Built-Up Area</td>
                <td><input type="text" id="actual_construction_square_feet" name="actual_construction_square_feet" value="<?= $fieldss['actual_construction_square_feet'] ?? '' ?>"></td>
                <td><input type="text" id="actual_construction_rate" name="actual_construction_rate" value="<?= $fieldss['actual_construction_rate'] ?? '' ?>"></td>
                <td>
                    <input type="text" id="actual_construction_valuation_computed" readonly>
                    <input type="hidden" name="actual_construction_valuation_computed" id="actual_construction_valuation_hidden">
                </td>
            </tr>
            <tr>
                <td colspan="2">Saleable Area (Super Built-Up Area)</td>
                <td><input type="text" id="actual_saleable_square_feet" name="actual_saleable_square_feet" value="<?= $fieldss['actual_saleable_square_feet'] ?? '1' ?>"></td>
                <td><input type="text" id="actual_saleable_rate" name="actual_saleable_rate" value="<?= $fieldss['actual_saleable_rate'] ?? '' ?>"></td>
                <td>
                    <input type="text" id="actual_saleable_valuation_computed" readonly>
                    <input type="hidden" name="actual_saleable_valuation_computed" id="actual_saleable_valuation_hidden">
                </td>
            </tr>
            <tr>
                <td colspan="4">ACTUAL AREA VALUATION</td>
                <td>
                    <input type="text" id="total_actual_area_valuation" readonly>
                    <input type="hidden" name="total_actual_area_valuation" id="total_actual_area_valuation_hidden">
                </td>
            </tr>
      
    </tbody>
</table>
 
<script>
document.addEventListener("DOMContentLoaded", function () {
    function calculateValuation(squareFeetId, rateId, valuationId, hiddenId, totalCallback) {
        let squareFeetInput = document.getElementById(squareFeetId);
        let rateInput = document.getElementById(rateId);
        let valuationInput = document.getElementById(valuationId);
        let hiddenInput = document.getElementById(hiddenId);

        function updateValuation() {
            let squareFeet = parseFloat(squareFeetInput.value) || 0;
            let rate = parseFloat(rateInput.value) || 0;
            let valuation = squareFeet * rate;
            valuationInput.value = valuation.toFixed(2);
            hiddenInput.value = valuation.toFixed(2);
            totalCallback();
        }

        squareFeetInput.addEventListener("input", updateValuation);
        rateInput.addEventListener("input", updateValuation);

        updateValuation();
    }

    function updateTotalValuation() {
        let plotValuation = parseFloat(document.getElementById("plot_valuation_computed").value) || 0;
        let carpetValuation = parseFloat(document.getElementById("carpet_valuation_computed").value) || 0;
        let constructionValuation = parseFloat(document.getElementById("construction_valuation_computed").value) || 0;
        let saleableValuation = parseFloat(document.getElementById("saleable_valuation_computed").value) || 0;

        let totalValuation = plotValuation + carpetValuation + constructionValuation + saleableValuation;
        document.getElementById("total_area_valuation").value = totalValuation.toFixed(2);
        document.getElementById("total_area_valuation_hidden").value = totalValuation.toFixed(2);
    }

    function updateTotalActualValuation() {
        let plotValuation = parseFloat(document.getElementById("actual_plot_valuation_computed").value) || 0;
        let carpetValuation = parseFloat(document.getElementById("actual_carpet_valuation_computed").value) || 0;
        let constructionValuation = parseFloat(document.getElementById("actual_construction_valuation_computed").value) || 0;
        let saleableValuation = parseFloat(document.getElementById("actual_saleable_valuation_computed").value) || 0;

        let totalValuation = plotValuation + carpetValuation + constructionValuation + saleableValuation;
        document.getElementById("total_actual_area_valuation").value = totalValuation.toFixed(2);
        document.getElementById("total_actual_area_valuation_hidden").value = totalValuation.toFixed(2);
    }

    calculateValuation("plot_square_feet", "plot_rate", "plot_valuation_computed", "plot_valuation_hidden", updateTotalValuation);
    calculateValuation("carpet_square_feet", "carpet_rate", "carpet_valuation_computed", "carpet_valuation_hidden", updateTotalValuation);
    calculateValuation("construction_square_feet", "construction_rate", "construction_valuation_computed", "construction_valuation_hidden", updateTotalValuation);
    calculateValuation("saleable_square_feet", "saleable_rate", "saleable_valuation_computed", "saleable_valuation_hidden", updateTotalValuation);
    
    calculateValuation("actual_plot_square_feet", "actual_plot_rate", "actual_plot_valuation_computed", "actual_plot_valuation_hidden", updateTotalActualValuation);
    calculateValuation("actual_carpet_square_feet", "actual_carpet_rate", "actual_carpet_valuation_computed", "actual_carpet_valuation_hidden", updateTotalActualValuation);
    calculateValuation("actual_construction_square_feet", "actual_construction_rate", "actual_construction_valuation_computed", "actual_construction_valuation_hidden", updateTotalActualValuation);
    calculateValuation("actual_saleable_square_feet", "actual_saleable_rate", "actual_saleable_valuation_computed", "actual_saleable_valuation_hidden", updateTotalActualValuation);
    
    document.querySelector("form").addEventListener("submit", function (event) {
        updateTotalValuation();
        updateTotalActualValuation();
        
        // Ensure hidden fields have the latest computed values before submission
        document.getElementById("total_area_valuation_hidden").value = document.getElementById("total_area_valuation").value;
        document.getElementById("total_actual_area_valuation_hidden").value = document.getElementById("total_actual_area_valuation").value;
    });

    updateTotalValuation();
    updateTotalActualValuation();
});
</script>

            <!-- Additional Amenities Cost Section -->
            <table class="valuation-table">
                <tr>
                    <th colspan="6">ADDITIONAL AMENITIES COST</th>
                </tr>
                <tr>
                    
                    <th style="background-color: lightskyblue; color: black; " >AMENITIES</th>
                    <th style="background-color: lightskyblue; color: black; " >DESCRIPTION</th>
                    <th style="background-color: lightskyblue; color: black; " >AMOUNT (Rs.)</th>
                </tr>
                <tr>
    <td >Car Parking</td> 
    <td><input type="text" id="car_parking" name="car_parking" value="<?= htmlspecialchars($fieldss['car_parking'] ?? '') ?>"></td>
    <td><input type="text" id="car_parking_amount" name="car_parking_amount" value="<?= htmlspecialchars($fieldss['car_parking_amount'] ?? '0') ?>"></td>
</tr>
<tr>
    <td  >Additional Amenities 1</td>
    <td><input type="text" id="addition_amenities_description_2" name="addition_amenities_description_2" value="<?= htmlspecialchars($fieldss['addition_amenities_description_2'] ?? '') ?>"></td>
    <td><input type="text" id="addition_amenities_amount_2" name="addition_amenities_amount_2" value="<?= htmlspecialchars($fieldss['addition_amenities_amount_2'] ?? '0') ?>"></td>
</tr>
<tr>
    <td  >Additional Amenities 2</td>
    <td><input type="text" id="addition_amenities_description_3" name="addition_amenities_description_3" value="<?= htmlspecialchars($fieldss['addition_amenities_description_3'] ?? '') ?>"></td>
    <td><input type="text" id="addition_amenities_amount_3" name="addition_amenities_amount_3" value="<?= htmlspecialchars($fieldss['addition_amenities_amount_3'] ?? '0') ?>"></td>
</tr> 
<tr>
    <td  >Additional Amenities 3</td>
    <td><input type="text" id="addition_amenities_description_4" name="addition_amenities_description_4" value="<?= htmlspecialchars($fieldss['addition_amenities_description_4'] ?? '') ?>"></td>
    <td><input type="text" id="addition_amenities_amount_4" name="addition_amenities_amount_4" value="<?= htmlspecialchars($fieldss['addition_amenities_amount_4'] ?? '0') ?>"></td>
</tr>
<tr>
    <td colspan="2">AMENITIES TOTAL</td>
    <td>
        <input type="text" id="amenities_total" readonly>
        <input type="hidden" name="amenities_total" id="amenities_total_hidden">
    </td>
</tr>

 
<script>
document.addEventListener("DOMContentLoaded", function () {
    function calculateAmenitiesTotal() {
        let amount1 = parseFloat(document.getElementById("car_parking_amount").value) || 0;
        let amount2 = parseFloat(document.getElementById("addition_amenities_amount_2").value) || 0;
        let amount3 = parseFloat(document.getElementById("addition_amenities_amount_3").value) || 0;
        let amount4 = parseFloat(document.getElementById("addition_amenities_amount_4").value) || 0;

        let total = amount1 + amount2 + amount3 + amount4;
        document.getElementById("amenities_total").value = total.toFixed(2);
        document.getElementById("amenities_total_hidden").value = total.toFixed(2);
    }

    document.getElementById("car_parking_amount").addEventListener("input", calculateAmenitiesTotal);
    document.getElementById("addition_amenities_amount_2").addEventListener("input", calculateAmenitiesTotal);
    document.getElementById("addition_amenities_amount_3").addEventListener("input", calculateAmenitiesTotal);
    document.getElementById("addition_amenities_amount_4").addEventListener("input", calculateAmenitiesTotal);

    calculateAmenitiesTotal();
});
</script>

</table>
   
                                                             

<table>


              <table class="valuation-table">
        <thead>
            <tr class="header">
                <th colspan="6">AS ON DATE / PROPOSED FINAL CONSIDERED</th>
            </tr>
             <tr>
                <th style="background-color: lightskyblue; color: black;" colspan="1">AREA TYPE</th>
                <th style="background-color: lightskyblue; color: black;">SQUARE FEET</th>
                <th style="background-color: lightskyblue; color: black;">RATE/SQ.FT</th>
                <th style="background-color: lightskyblue; color: black;" colspan="2">VALUATION (Rs.)</th>
            </tr>
        </thead>
        <tbody>  
  

  <!-- Proposed Estimate Plot Area -->
  <tr>
    <td>Proposed Plot Area</td>
    <td><input type="text" id="proposed_plot_area_sqft" name="proposed_plot_area_sqft" 
      value="<?= $fieldss['proposed_plot_area_sqft'] ?? '' ?>" placeholder="Enter plot area (sqft)"></td>
    <td><input type="text" id="proposed_plot_rate" name="proposed_plot_rate" 
      value="<?= $fieldss['proposed_plot_rate'] ?? '' ?>" placeholder="Enter rate/sqft"></td>
    <td><input type="text" id="proposed_plot_valuation" name="proposed_plot_valuation" 
      value="<?= $fieldss['proposed_plot_valuation'] ?? '' ?>" placeholder="Auto valuation"></td>
  </tr>

  <!-- Proposed Construction 1 -->
  <tr>
    <td><input type="text" id="proposed_construction_name1" name="proposed_construction_name1" 
      value="<?= $fieldss['proposed_construction_name1'] ?? '' ?>" placeholder="Proposed Construction name 1"></td>
    <td><input type="text" id="proposed_construction_area_sqft1" name="proposed_construction_area_sqft1" 
      value="<?= $fieldss['proposed_construction_area_sqft1'] ?? '' ?>" placeholder="Area sqft"></td>
    <td><input type="text" id="proposed_construction_rate1" name="proposed_construction_rate1" 
      value="<?= $fieldss['proposed_construction_rate1'] ?? '' ?>" placeholder="Rate/sqft"></td>
    <td><input type="text" id="proposed_construction_valuation1" name="proposed_construction_valuation1" 
      value="<?= $fieldss['proposed_construction_valuation1'] ?? '0.00' ?>" placeholder="0.00"></td>
  </tr>

  <!-- Proposed Construction 2 -->
  <tr>
    <td><input type="text" id="proposed_construction_name2" name="proposed_construction_name2" 
      value="<?= $fieldss['proposed_construction_name2'] ?? '' ?>" placeholder="Proposed Construction name 2"></td>
    <td><input type="text" id="proposed_construction_area_sqft2" name="proposed_construction_area_sqft2" 
      value="<?= $fieldss['proposed_construction_area_sqft2'] ?? '' ?>" placeholder="Area sqft"></td>
    <td><input type="text" id="proposed_construction_rate2" name="proposed_construction_rate2" 
      value="<?= $fieldss['proposed_construction_rate2'] ?? '' ?>" placeholder="Rate/sqft"></td>
    <td><input type="text" id="proposed_construction_valuation2" name="proposed_construction_valuation2" 
      value="<?= $fieldss['proposed_construction_valuation2'] ?? '0.00' ?>" placeholder="0.00"></td>
  </tr>

  <!-- Proposed Construction 3 -->
  <tr>
    <td><input type="text" id="proposed_construction_name3" name="proposed_construction_name3" 
      value="<?= $fieldss['proposed_construction_name3'] ?? '' ?>" placeholder="Proposed Construction name 3"></td>
    <td><input type="text" id="proposed_construction_area_sqft3" name="proposed_construction_area_sqft3" 
      value="<?= $fieldss['proposed_construction_area_sqft3'] ?? '' ?>" placeholder="Area sqft"></td>
    <td><input type="text" id="proposed_construction_rate3" name="proposed_construction_rate3" 
      value="<?= $fieldss['proposed_construction_rate3'] ?? '' ?>" placeholder="Rate/sqft"></td>
    <td><input type="text" id="proposed_construction_valuation3" name="proposed_construction_valuation3" 
      value="<?= $fieldss['proposed_construction_valuation3'] ?? '0.00' ?>" placeholder="0.00"></td>
  </tr>

  <!-- Proposed Estimate Construction Built-Up Area -->
  <tr>
    <td>Proposed  Construction Built-Up Area</td>
    <td><input type="text" id="proposed_builtup_area_sqft" name="proposed_builtup_area_sqft" 
      value="<?= $fieldss['proposed_builtup_area_sqft'] ?? '' ?>" placeholder="Proposed Built-up area sqft"></td>
    <td><input type="text" id="proposed_builtup_rate" name="proposed_builtup_rate" 
      value="<?= $fieldss['proposed_builtup_rate'] ?? '' ?>" placeholder="Proposed Rate/sqft"></td>
    <td><input type="text" id="proposed_builtup_valuation" name="proposed_builtup_valuation" 
      value="<?= $fieldss['proposed_builtup_valuation'] ?? '' ?>" placeholder="Proposed Auto valuation"></td>
  </tr>

  <!-- Proposed Estimate Saleable Area -->
  <tr>
    <td>Proposed   Saleable Area (Super Built-Up Area)</td>
    <td><input type="text" id="proposed_saleable_area_sqft" name="proposed_saleable_area_sqft" 
      value="<?= $fieldss['proposed_saleable_area_sqft'] ?? '' ?>" placeholder="Proposed Saleable area sqft"></td>
    <td><input type="text" id="proposed_saleable_rate" name="proposed_saleable_rate" 
      value="<?= $fieldss['proposed_saleable_rate'] ?? '' ?>" placeholder="Proposed Rate/sqft"></td>
    <td><input type="text" id="proposed_saleable_valuation" name="proposed_saleable_valuation" 
      value="<?= $fieldss['proposed_saleable_valuation'] ?? '' ?>" placeholder="Proposed Auto valuation"></td>
  </tr>

  <!-- Proposed Final Area Valuation -->
  <tr>
    <td colspan="3" style="text-align:right;"><strong>PROPOSED FINAL AREA VALUATION</strong></td>
    <td><input type="text" id="proposed_final_area_valuation" name="proposed_final_area_valuation" 
      value="<?= $fieldss['proposed_final_area_valuation'] ?? '0.00' ?>" placeholder="0.00"></td>
  </tr>
</tbody>

<script>
function calculateProposed() {
    const val = id => parseFloat(document.getElementById(id)?.value) || 0;

    // Plot area valuation
    let proposed_plot_area_sqft = val("proposed_plot_area_sqft");
    let proposed_plot_rate = val("proposed_plot_rate");
    let proposed_plot_valuation = proposed_plot_area_sqft * proposed_plot_rate;
    document.getElementById("proposed_plot_valuation").value = proposed_plot_valuation.toFixed(2);

    // Construction 1
    let proposed_construction_area_sqft1 = val("proposed_construction_area_sqft1");
    let proposed_construction_rate1 = val("proposed_construction_rate1");
    let proposed_construction_valuation1 = proposed_construction_area_sqft1 * proposed_construction_rate1;
    document.getElementById("proposed_construction_valuation1").value = proposed_construction_valuation1.toFixed(2);

    // Construction 2
    let proposed_construction_area_sqft2 = val("proposed_construction_area_sqft2");
    let proposed_construction_rate2 = val("proposed_construction_rate2");
    let proposed_construction_valuation2 = proposed_construction_area_sqft2 * proposed_construction_rate2;
    document.getElementById("proposed_construction_valuation2").value = proposed_construction_valuation2.toFixed(2);

    // Construction 3
    let proposed_construction_area_sqft3 = val("proposed_construction_area_sqft3");
    let proposed_construction_rate3 = val("proposed_construction_rate3");
    let proposed_construction_valuation3 = proposed_construction_area_sqft3 * proposed_construction_rate3;
    document.getElementById("proposed_construction_valuation3").value = proposed_construction_valuation3.toFixed(2);

    // Built-up Area
    let proposed_builtup_area_sqft = proposed_construction_area_sqft1 + proposed_construction_area_sqft2 + proposed_construction_area_sqft3;
    let proposed_builtup_area_valuation = proposed_construction_valuation1 + proposed_construction_valuation2 + proposed_construction_valuation3;
    let proposed_builtup_rate = proposed_builtup_area_sqft > 0 ? (proposed_builtup_area_valuation / proposed_builtup_area_sqft) : 0;
    document.getElementById("proposed_builtup_area_sqft").value = proposed_builtup_area_sqft.toFixed(2);
    document.getElementById("proposed_builtup_rate").value = proposed_builtup_rate.toFixed(2);
    document.getElementById("proposed_builtup_valuation").value = proposed_builtup_area_valuation.toFixed(2);

    // Saleable Area
    let proposed_saleable_area_sqft = val("proposed_saleable_area_sqft");
    let proposed_saleable_rate = val("proposed_saleable_rate");
    let proposed_saleable_valuation = proposed_saleable_area_sqft * proposed_saleable_rate;
    document.getElementById("proposed_saleable_valuation").value = proposed_saleable_valuation.toFixed(2);

    // Final Valuation
    let proposed_final_area_valuation = proposed_plot_valuation + proposed_construction_valuation1 + proposed_construction_valuation2 + proposed_construction_valuation3 + proposed_saleable_valuation;
    document.getElementById("proposed_final_area_valuation").value = proposed_final_area_valuation.toFixed(2);
}

// Event listener to update in real time
document.querySelectorAll("input[id^='proposed_']").forEach(input => {
    input.addEventListener("input", calculateProposed);
});
</script>



      <table class="valuation-table">
        <thead>
            <tr class="header">
                <th colspan="6">GOVERNMENT GUIDELINE CONSIDERED</th>
            </tr>
             <tr>
                <th style="background-color: lightskyblue; color: black;" colspan="1">AREA TYPE</th>
                <th style="background-color: lightskyblue; color: black;">SQUARE FEET</th>
                <th style="background-color: lightskyblue; color: black;">RATE/SQ.FT</th>
                <th style="background-color: lightskyblue; color: black;" colspan="2">VALUATION (Rs.)</th>
            </tr>
        </thead>
        <tbody>  
  
 
    <tr>

        <td>GOVERNMENT Plot Area</td>
        <td><input type="text" id="gov_plot_area_sqft" name="gov_plot_area_sqft" value="<?= $fieldss['gov_plot_area_sqft'] ?? '' ?>" placeholder="Enter plot area (sqft)"></td>
        <td><input type="text" id="gov_plot_area_rate" name="gov_plot_area_rate" value="<?= $fieldss['gov_plot_area_rate'] ?? '' ?>" placeholder="Enter rate/sqft"></td>
        <td><input type="text" id="gov_plot_area_valuation" name="gov_plot_area_valuation" value="<?= $fieldss['gov_plot_area_valuation'] ?? '' ?>" placeholder="Auto valuation"></td>
    </tr>

    <!-- GOVERNMENT Construction 1 -->
    <tr>
        <td><input type="text" id="gov_construction_name1" name="gov_construction_name1" value="<?= $fieldss['gov_construction_name1'] ?? '' ?>" placeholder="Government Construction name 1"></td>
        <td><input type="text" id="gov_construction_area1" name="gov_construction_area1" value="<?= $fieldss['gov_construction_area1'] ?? '' ?>" placeholder="Government Construction area sqft 1"></td>
        <td><input type="text" id="gov_construction_rate1" name="gov_construction_rate1" value="<?= $fieldss['gov_construction_rate1'] ?? '' ?>" placeholder="Government Construction rate 1"></td>
        <td><input type="text" id="gov_construction_valuation1" name="gov_construction_valuation1" value="<?= $fieldss['gov_construction_valuation1'] ?? '' ?>" placeholder="0.00"></td>
    </tr>
    

    <!-- GOVERNMENT Construction 2 -->
    <tr>
        <td><input type="text" id="gov_construction_name2" name="gov_construction_name2" value="<?= $fieldss['gov_construction_name2'] ?? '' ?>" placeholder="Government Construction name 2"></td>
        <td><input type="text" id="gov_construction_area2" name="gov_construction_area2" value="<?= $fieldss['gov_construction_area2'] ?? '' ?>" placeholder="Government Construction area sqft 2"></td>
        <td><input type="text" id="gov_construction_rate2" name="gov_construction_rate2" value="<?= $fieldss['gov_construction_rate2'] ?? '' ?>" placeholder="Government Construction rate 2"></td>
        <td><input type="text" id="gov_construction_valuation2" name="gov_construction_valuation2" value="<?= $fieldss['gov_construction_valuation2'] ?? '' ?>" placeholder="0.00"></td>
    </tr>

    <!-- GOVERNMENT Construction 3 -->
    <tr>
        <td><input type="text" id="gov_construction_name3" name="gov_construction_name3" value="<?= $fieldss['gov_construction_name3'] ?? '' ?>" placeholder="Government Construction name 3"></td>
        <td><input type="text" id="gov_construction_area3" name="gov_construction_area3" value="<?= $fieldss['gov_construction_area3'] ?? '' ?>" placeholder="Government Construction area sqft 3"></td>
        <td><input type="text" id="gov_construction_rate3" name="gov_construction_rate3" value="<?= $fieldss['gov_construction_rate3'] ?? '' ?>" placeholder="Government Construction rate 3"></td>
        <td><input type="text" id="gov_construction_valuation3" name="gov_construction_valuation3" value="<?= $fieldss['gov_construction_valuation3'] ?? '' ?>" placeholder="0.00"></td>
    </tr>

    <!-- GOVERNMENT Built-Up Area -->
    <tr>
        <td>GOVERNMENT Built-Up Area</td>
        <td><input type="text" id="gov_builtup_area_sqft" name="gov_builtup_area_sqft" value="<?= $fieldss['gov_builtup_area_sqft'] ?? '' ?>" placeholder="Built-up area sqft"></td>
        <td><input type="text" id="gov_builtup_area_rate" name="gov_builtup_area_rate" value="<?= $fieldss['gov_builtup_area_rate'] ?? '' ?>" placeholder="Rate/sqft"></td>
        <td><input type="text" id="gov_builtup_area_valuation" name="gov_builtup_area_valuation" value="<?= $fieldss['gov_builtup_area_valuation'] ?? '' ?>" placeholder="Auto valuation"></td>
    </tr>

    <!-- GOVERNMENT Saleable Area -->
    <tr>
        <td>GOVERNMENT Saleable Area (Super Built-Up Area)</td>
        <td><input type="text" id="gov_saleable_area_sqft" name="gov_saleable_area_sqft" value="<?= $fieldss['gov_saleable_area_sqft'] ?? '' ?>" placeholder="Saleable area sqft"></td>
        <td><input type="text" id="gov_saleable_area_rate" name="gov_saleable_area_rate" value="<?= $fieldss['gov_saleable_area_rate'] ?? '' ?>" placeholder="Rate/sqft"></td>
        <td><input type="text" id="gov_saleable_area_valuation" name="gov_saleable_area_valuation" value="<?= $fieldss['gov_saleable_area_valuation'] ?? '' ?>" placeholder="Auto valuation"></td>
    </tr>

    <!-- GOVERNMENT FINAL VALUATION -->
    <tr>
        <td colspan="3" style="text-align:right;">GOVERNMENT FINAL AREA VALUATION</td>
        <td><input type="text" id="gov_final_area_valuation" name="gov_final_area_valuation" value="<?= $fieldss['gov_final_area_valuation'] ?? '' ?>" placeholder="0.00"></td>
    </tr>
</table>

   
</tbody>
   
<script>
function calcGovernmentValuations() {
    const val = id => parseFloat(document.getElementById(id)?.value) || 0;
    const set = (id, v) => document.getElementById(id).value = v.toFixed(2);

    // Plot
    set("gov_plot_area_valuation", val("gov_plot_area_sqft") * val("gov_plot_area_rate"));

    // Constructions
    set("gov_construction_valuation1", val("gov_construction_area1") * val("gov_construction_rate1"));
    set("gov_construction_valuation2", val("gov_construction_area2") * val("gov_construction_rate2"));
    set("gov_construction_valuation3", val("gov_construction_area3") * val("gov_construction_rate3"));

    // Built-up
    const builtup_sqft = val("gov_construction_area1") + val("gov_construction_area2") + val("gov_construction_area3");
    const builtup_val = val("gov_construction_valuation1") + val("gov_construction_valuation2") + val("gov_construction_valuation3");
    set("gov_builtup_area_sqft", builtup_sqft);
    set("gov_builtup_area_valuation", builtup_val);
    set("gov_builtup_area_rate", builtup_sqft > 0 ? builtup_val / builtup_sqft : 0);

    // Saleable
    set("gov_saleable_area_valuation", val("gov_saleable_area_sqft") * val("gov_saleable_area_rate"));

    // Final
    set("gov_final_area_valuation",
        val("gov_plot_area_valuation") +
        val("gov_construction_valuation1") +
        val("gov_construction_valuation2") +
        val("gov_construction_valuation3") +
        val("gov_saleable_area_valuation")
    );
}

// Attach real-time calculation
document.querySelectorAll("input").forEach(inp => {
    inp.addEventListener("input", calcGovernmentValuations);
});
</script>

 <table class="valuation-table">
        <thead>
            <tr class="header">
                <th colspan="6">FINAL CONSIDERED</th>
            </tr>
            <tr>
                <th style="background-color: lightskyblue; color: black;" colspan="2">AREA TYPE</th>
                <th style="background-color: lightskyblue; color: black;">SQUARE FEET</th>
                <th style="background-color: lightskyblue; color: black;">RATE/SQ.FT</th>
                <th style="background-color: lightskyblue; color: black;" colspan="2">VALUATION (Rs.)</th>
            </tr>
        </thead>
        <tbody>   
    
            <tr>
                <td colspan="2">Plot Area</td>
                <td>
                    <input type="text" id="final_plot_square_feet" name="final_plot_square_feet" 
                        value="<?= $fieldss['final_plot_square_feet'] ?? '1' ?>">
                </td>
                <td>
                    <input type="text" id="final_plot_rate"   name="final_plot_rate" 
                        value="<?= $fieldss['final_plot_rate'] ?? '0' ?>">
                </td>
                <td>
                    <input type="text" id="finally_plot_valuation" readonly>
                    <input type="hidden" name="finally_plot_valuation_hidden" id="finally_plot_valuation_hidden">
                </td>
            </tr>
    

  <tr>
    <td colspan="2"> <input type="text" id="construction_name_1"  style="text-align:center;" name="construction_name_1"  value="<?= $fieldss['construction_name_1'] ?? '' ?>" placeholder="Construction name 1"></td>
    <td><input type="text" id="construction_area_sqft_1"  name="construction_area_sqft_1"  value="<?= $fieldss['construction_area_sqft_1'] ?? '' ?>" placeholder="Construction area sqft 1" ></td>
    <td><input type="text" id="construction_rate_1"  name="construction_rate_1"  value="<?= $fieldss['construction_rate_1'] ?? '' ?>"  value="<?= $fieldss['final_plot_rate'] ?? '' ?>" placeholder="Construction rate 1" ></td>
<td>
<input type="text" id="construction_valuation_1" name="construction_valuation_1"   value="<?= $fieldss['construction_valuation_1'] ?? '' ?>" placeholder="Construction valuation 1 "readonly>
<input type="hidden" name="final_area_valuation_hiddens" id="final_area_valuation_hiddens"></td>
     
</tr> 
   <tr> <td colspan="2"> <input type="text" id="construction_name_2"  style="text-align:center;"name="construction_name_2"   value="<?= $fieldss['construction_name_2'] ?? '' ?>" placeholder="Construction name 2"></td>
    <td><input type="text" id="construction_area_sqft_2"  name="construction_area_sqft_2"  value="<?= $fieldss['construction_area_sqft_2'] ?? '' ?>" placeholder="Construction area sqft 2" ></td>
    <td> <input type="text" id="construction_rate_2"  name="construction_rate_2"  value="<?= $fieldss['construction_rate_2'] ?? '' ?>" placeholder="Construction rate 2" ></td>
    <td>
    <input type="text" id="construction_valuation_2" name="construction_valuation_2"  value="<?= $fieldss['construction_valuation_2'] ?? '' ?>" placeholder="Construction valuation 2 " readonly>
    <input type="hidden" name="final_area_valuation_hiddens" id="final_area_valuation_hiddens">
    </td>
     
</tr>
   <tr>
    <td colspan="2"> <input type="text" id="construction_name_3"  style="text-align:center;" name="construction_name_3"  value="<?= $fieldss['construction_name_3'] ?? '' ?>" placeholder="Construction name 3 "></td>
    <td><input type="text" id="construction_area_sqft_3"  name="construction_area_sqft_3"  value="<?= $fieldss['construction_area_sqft_3'] ?? '' ?>" placeholder="Construction area sqft 3"> </td>
     <td><input type="text" id="construction_rate_3"  name="construction_rate_3"  value="<?= $fieldss['construction_rate_3'] ?? '' ?>" placeholder="Construction rate 3"></td>
<td>
<input type="text" id="construction_valuation_3" name="construction_valuation_3"  value="<?= $fieldss['construction_valuation_3'] ?? '' ?>" placeholder="Construction valuation 3 " readonly>
<input type="hidden" name="final_area_valuation_hiddens" id="final_area_valuation_hiddens"></td>  
</tr>

<script>
function calculateValuations() {
    // Get individual construction areas and rates
    const area1 = parseFloat(document.getElementById('construction_area_sqft_1').value) || 0;
    const rate1 = parseFloat(document.getElementById('construction_rate_1').value) || 0;
    const area2 = parseFloat(document.getElementById('construction_area_sqft_2').value) || 0;
    const rate2 = parseFloat(document.getElementById('construction_rate_2').value) || 0;
    const area3 = parseFloat(document.getElementById('construction_area_sqft_3').value) || 0;
    const rate3 = parseFloat(document.getElementById('construction_rate_3').value) || 0;

    // Calculate individual valuations
    const valuation1 = area1 * rate1;
    const valuation2 = area2 * rate2;
    const valuation3 = area3 * rate3;

    // Update individual valuation fields
    document.getElementById('construction_valuation_1').value = valuation1.toFixed(2);
    document.getElementById('construction_valuation_2').value = valuation2.toFixed(2);
    document.getElementById('construction_valuation_3').value = valuation3.toFixed(2);

    // Calculate totals
    const totalArea = area1 + area2 + area3;
    const totalValuation = valuation1 + valuation2 + valuation3;

    // Update total area and valuation fields
    document.getElementById('final_construction_square_feet').value = totalArea.toFixed(2);
    document.getElementById('finally_construction_valuation').value = totalValuation.toFixed(2);
    document.getElementById('finally_construction_valuation_hidden').value = totalValuation.toFixed(2);

    // Calculate final rate
    const finalRate = totalArea !== 0 ? totalValuation / totalArea : 0;
    document.getElementById('final_construction_rate').value = finalRate.toFixed(2);
}

// Attach event listeners to trigger calculations
document.querySelectorAll('#construction_area_sqft_1, #construction_rate_1, #construction_area_sqft_2, #construction_rate_2, #construction_area_sqft_3, #construction_rate_3')
    .forEach(el => el.addEventListener('input', calculateValuations));

// Optional: Initial calculation on page load
window.addEventListener('DOMContentLoaded', calculateValuations);
</script>

 
         <tr>
                <td colspan="2">Construction Built-Up Area</td>
                <td>
                    <input type="text" id="final_construction_square_feet" name="final_construction_square_feet" 
                        value="<?= $fieldss['final_construction_square_feet'] ?? '' ?>" oninput="updateInsurableValue()" readonly>
                </td>
                <td>
                    <input type="text" id="final_construction_rate" name="final_construction_rate" 
                        value="<?= $fieldss['final_construction_rate'] ?? '' ?>" oninput="updateInsurableValue()" readonly>
                </td>
                <td>
                     <input type="text" id="finally_construction_valuation" name="finally_construction_valuation" 
                        value="<?= $fieldss['finally_construction_valuation'] ?? '' ?>"  readonly>
                <input type="hidden" name="finally_construction_valuation_hidden" id="finally_construction_valuation_hidden"  >
                   
                </td>
            </tr>
            <script>
function updateConstructionValues() {
    // Get all input values and convert to floats (default to 0 if NaN)
    const area1 = parseFloat(document.querySelector('[placeholder="Construction area sqft 1"]').value) || 0;
    const area2 = parseFloat(document.querySelector('[placeholder="Construction area sqft 2"]').value) || 0;
    const area3 = parseFloat(document.querySelector('[placeholder="Construction area sqft 3"]').value) || 0;

    const rate1 = parseFloat(document.querySelector('[placeholder="Construction rate 1"]').value) || 0;
    const rate2 = parseFloat(document.querySelector('[placeholder="Construction rate 2"]').value) || 0;
    const rate3 = parseFloat(document.querySelector('[placeholder="Construction rate 3"]').value) || 0;

    // Calculate valuations
    const val1 = area1 * rate1;
    const val2 = area2 * rate2;
    const val3 = area3 * rate3;

    // Update construction valuation fields
    const valuationInputs = document.querySelectorAll('#final_area_valuations');
    valuationInputs[0].value = val1.toFixed(2);
    valuationInputs[1].value = val2.toFixed(2);
    valuationInputs[2].value = val3.toFixed(2);

    document.querySelectorAll('#final_area_valuation_hiddens')[0].value = val1.toFixed(2);
    document.querySelectorAll('#final_area_valuation_hiddens')[1].value = val2.toFixed(2);
    document.querySelectorAll('#final_area_valuation_hiddens')[2].value = val3.toFixed(2);

    // Calculate final construction square feet
    const totalArea = area1 + area2 + area3;
    document.getElementById('final_construction_square_feet').value = totalArea.toFixed(2);

    // Calculate final construction valuation
    const totalValuation = val1 + val2 + val3;
    document.getElementById('finally_construction_valuation').value = totalValuation.toFixed(2);
    document.getElementById('finally_construction_valuation_hidden').value = totalValuation.toFixed(2);

    // Calculate final construction rate
    const finalRate = totalArea > 0 ? totalValuation / totalArea : 0;
    document.getElementById('final_construction_rate').value = finalRate.toFixed(2);
}

// Attach listeners
document.querySelectorAll('input[placeholder*="Construction area sqft"], input[placeholder*="Construction rate"]').forEach(input => {
    input.addEventListener('input', updateConstructionValues);
});
</script>
  <tr>
    <td colspan="2">Carpet Area</td>
     
               
                    <td><input type="text" id="final_carpet_area_square_feet"  name="final_carpet_area_square_feet"  value="<?= $fieldss['final_carpet_area_square_feet'] ?? '' ?>"></td>

                       

                <td>
                  
                </td>
                <td>
                    </td>
     
</tr>
            <tr>
    <td colspan="2">Saleable Area (Super Built-Up Area)</td>
    <td>
                    <input type="text" id="final_area_square_feet" name="final_area_square_feet" 
                        value="<?= $fieldss['final_area_square_feet'] ?? '1' ?>" oninput="updateInsurableValue()  ">
                </td>
                <td>
                    <input type="text" id="final_area_rate" name="final_area_rate" 
                        value="<?= $fieldss['final_area_rate'] ?? '' ?>">
                </td>
                <td>
                   
                    <input type="text" id="final_area_valuation" name="final_area_valuation" readonly>
                    <input type="hidden" name="final_area_valuation_hidden" id="final_area_valuation_hidden">
                </td>
     
</tr>
            <tr>
    <td colspan="4">FINAL AREA VALUATION</td>
    <td>
        <input type="text" id="total_finally_area_valuation" name="total_finally_area_valuation" readonly>
        <input type="hidden" name="total_finally_area_valuation_hidden" id="total_finally_area_valuation_hidden">
    </td>
</tr>

        </tbody>
   
        <script>
document.addEventListener("DOMContentLoaded", function () {
    function calculateValuation(squareFeetId, rateId, valuationId, hiddenId) {
        let squareFeetInput = document.getElementById(squareFeetId);
        let rateInput = document.getElementById(rateId);
        let valuationInput = document.getElementById(valuationId);
        let hiddenInput = document.getElementById(hiddenId);

        function updateValuation() {
            let squareFeet = parseFloat(squareFeetInput?.value) || 0;
            let rate = parseFloat(rateInput?.value) || 0;
            let valuation = squareFeet * rate;
            if (valuationInput) valuationInput.value = valuation.toFixed(2);
            if (hiddenInput) hiddenInput.value = valuation.toFixed(2);
            updateTotalValuation();
        }

        if (squareFeetInput) squareFeetInput.addEventListener("input", updateValuation);
        if (rateInput) rateInput.addEventListener("input", updateValuation);
        updateValuation();
    }

    function updateTotalValuation() {
        let plotValuation = parseFloat(document.getElementById("finally_plot_valuation")?.value) || 0;
        let constructionValuation = parseFloat(document.getElementById("finally_construction_valuation")?.value) || 0;
        let areaConsideredValuation = parseFloat(document.getElementById("final_area_valuation")?.value) || 0;
        let amenitiestotal = parseFloat(document.getElementById("amenities_total")?.value) || 0;
        let totalValuation = plotValuation + constructionValuation + areaConsideredValuation + amenitiestotal;

        let totalFinalInput = document.getElementById("total_finally_area_valuation");
        let totalFinalHiddenInput = document.getElementById("total_finally_area_valuation_hidden");

        if (totalFinalInput) totalFinalInput.value = totalValuation.toFixed(2);
        if (totalFinalHiddenInput) totalFinalHiddenInput.value = totalValuation.toFixed(2);
    }

    calculateValuation("final_plot_square_feet", "final_plot_rate", "finally_plot_valuation", "finally_plot_valuation_hidden");
    calculateValuation("final_construction_square_feet", "final_construction_rate", "finally_construction_valuation", "finally_construction_valuation_hidden");
    calculateValuation("final_area_square_feet", "final_area_rate", "final_area_valuation", "final_area_valuation_hidden");

    let form = document.querySelector("form");
    if (form) {
        form.addEventListener("submit", function () {
            updateTotalValuation();
        });
    }
});
</script>

