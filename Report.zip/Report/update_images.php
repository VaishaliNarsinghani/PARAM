<?php
$servername = "localhost";
$username = "root";
  $password = "";$dbname = "project_db";

$conn = new mysqli($servername, $username, $password, $dbname);
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Read the raw POST data
$data = json_decode(file_get_contents("php://input"), true);
$reference_id = $data['reference_id'] ?? '';
$images = $data['images'] ?? [];

if ($reference_id && !empty($images)) {
    $fields = [];
    $params = [];
    $types = '';

    for ($i = 1; $i <= 20; $i++) {
        $key = "image" . $i;
        if (isset($images[$key])) {
            $base64 = $images[$key];
            $binary = base64_decode(explode(',', $base64)[1]);
            
            $fields[] = "$key = ?";
            $params[] = $binary;
            $types .= 's'; // treat as string for bind_param
        }
    }

    if (!empty($fields)) {
        $sql = "UPDATE final_uploaded_images SET " . implode(", ", $fields) . " WHERE reference_id = ?";
        $stmt = $conn->prepare($sql);
        if ($stmt) {
            $types .= 's'; // for reference_id
            $params[] = $reference_id;

            $stmt->bind_param($types, ...$params);
            if ($stmt->execute()) {
                echo "Images updated successfully.";
            } else {
                echo "Error executing update: " . $stmt->error;
            }
            $stmt->close();
        } else {
            echo "Error preparing update statement: " . $conn->error;
        }
    } else {
        echo "No valid image data to update.";
    }
} else {
    echo "Missing reference ID or image data.";
}
$conn->close();
?>
