<?php include('auth.php'); ?>
<?php include 'watermark.html'; ?><?php
ini_set('display_errors', 1);
error_reporting(error_level: E_ALL);

// Increase PHP execution time and memory limit
ini_set('max_execution_time', 600); // Increase execution time to 600 seconds (10 minutes)
ini_set('memory_limit', '4096M'); // Increase memory limit to 4096MB
// Start session


// Database credentials
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "project_db";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Retrieve reference_id from session
if (!isset($_SESSION['reference_id'])) {
    die("Error: Reference ID not found.");
}

$reference_id = $_SESSION['reference_id'];

// Debugging: Output for verification
echo "Session reference_id: " . htmlspecialchars($reference_id) . "<br>";


$page = isset($_GET['page']) ? $_GET['page'] : 1;
$limit = 50;
$offset = ($page - 1) * $limit;
$sql_property = "SELECT * FROM mis WHERE reference_id = ? LIMIT $limit OFFSET $offset";
$stmt_property = $conn->prepare($sql_property);
$stmt_property->bind_param("s", $reference_id);
$stmt_property->execute();
$result_property = $stmt_property->get_result();
$data1 = $result_property->fetch_assoc();




// Fetch data from property_details table
$sql_property = "SELECT * FROM property_details WHERE reference_id = ?";
$stmt_property = $conn->prepare($sql_property);
$stmt_property->bind_param("s", $reference_id);
$stmt_property->execute();
$result_property = $stmt_property->get_result();
$data2= $result_property->fetch_assoc();




// Fetch data from area_valuation table
$sql_area = "SELECT * FROM address_details WHERE reference_id = ?";
$stmt_area = $conn->prepare($sql_area); 
$stmt_area->bind_param("s", $reference_id);
$stmt_area->execute();
$result_area = $stmt_area->get_result();
$data3 = $result_area->fetch_assoc();





// Fetch data from area_valuation table
$sql_area = "SELECT * FROM critical_parameters WHERE reference_id = ?";
$stmt_area = $conn->prepare($sql_area); 
$stmt_area->bind_param("s", $reference_id);
$stmt_area->execute();
$result_area = $stmt_area->get_result();
$data4 = $result_area->fetch_assoc();

 
// Fetch data from area_valuation table
$sql_area = "SELECT * FROM surroundings_details WHERE reference_id = ?";
$stmt_area = $conn->prepare($sql_area); 
$stmt_area->bind_param("s", $reference_id);
$stmt_area->execute();
$result_area = $stmt_area->get_result();
$data5 = $result_area->fetch_assoc();
$stmt_area->close();
 
// Fetch data from area_valuation table
$sql_area = "SELECT * FROM area_valuation WHERE reference_id = ?";
$stmt_area = $conn->prepare($sql_area); 
$stmt_area->bind_param("s", $reference_id);
$stmt_area->execute();
$result_area = $stmt_area->get_result();
$data6 = $result_area->fetch_assoc();
$stmt_area->close();
 



// Fetch data from area_valuation table
$sql_area = "SELECT * FROM floor_details WHERE reference_id = ?";
$stmt_area = $conn->prepare($sql_area); 
$stmt_area->bind_param("s", $reference_id);
$stmt_area->execute();
$result_area = $stmt_area->get_result();
$data8= $result_area->fetch_assoc();
$stmt_area->close();
 


// Fetch data from area_valuation table
$sql_area = "SELECT * FROM technical_details WHERE reference_id = ?";
$stmt_area = $conn->prepare($sql_area); 
$stmt_area->bind_param("s", $reference_id);
$stmt_area->execute();
$result_area = $stmt_area->get_result();
$data9 = $result_area->fetch_assoc();
$stmt_area->close();
 
// Fetch data from area_valuation table
$sql_area = "SELECT * FROM remarks_table WHERE reference_id = ?";
$stmt_area = $conn->prepare($sql_area); 
$stmt_area->bind_param("s", $reference_id);
$stmt_area->execute();
$result_area = $stmt_area->get_result();
$data10 = $result_area->fetch_assoc();
$stmt_area->close();


// Step 1: Fetch the engineer_id from the mis table
$sql_mis = "SELECT engineer_id FROM mis WHERE reference_id = ?";
$stmt_mis = $conn->prepare($sql_mis);
$stmt_mis->bind_param("s", $reference_id);
$stmt_mis->execute();
$result_mis = $stmt_mis->get_result();
$row_mis = $result_mis->fetch_assoc();
$stmt_mis->close(); 

if ($row_mis) {
    $engineer_id = $row_mis['engineer_id'];

    // Step 2: Fetch the engineer's name from engineer_login table
    $sql_engineer = "SELECT name FROM engineer_login WHERE engineer_id = ?";
    $stmt_engineer = $conn->prepare($sql_engineer);
    $stmt_engineer->bind_param("s", $engineer_id);
    $stmt_engineer->execute();
    $result_engineer = $stmt_engineer->get_result();
    $row_engineer = $result_engineer->fetch_assoc();
    $stmt_engineer->close();

    if ($row_engineer) {
        $engineer_name = $row_engineer['name'];
        echo "Engineer Name: " . $engineer_name;
    } else {
        echo "Engineer not found.";
    }
} else {
    echo "No engineer assigned for this reference_id.";
}



// Step 1: Fetch the engineer_id from the mis table
$sql_mis = "SELECT report_id FROM mis WHERE reference_id = ?";
$stmt_mis = $conn->prepare($sql_mis);
$stmt_mis->bind_param("s", $reference_id);
$stmt_mis->execute();
$result_mis = $stmt_mis->get_result();
$row_mis = $result_mis->fetch_assoc();
$stmt_mis->close(); 

if ($row_mis) {
    $report_id = $row_mis['report_id'];

    // Step 2: Fetch the engineer's name from engineer_login table
    $sql_engineer = "SELECT name FROM report_login WHERE report_id = ?";
    $stmt_engineer = $conn->prepare($sql_engineer);
    $stmt_engineer->bind_param("s", $report_id);
    $stmt_engineer->execute();
    $result_engineer = $stmt_engineer->get_result();
    $row_engineer = $result_engineer->fetch_assoc();
    $stmt_engineer->close();

    if ($row_engineer) {
        $report_name = $row_engineer['name'];
        echo "Engineer Name: " . $report_name;
    } else {
        echo "Engineer not found.";
    }
} else {
    echo "No engineer assigned for this reference_id.";
}


// Step 1: Fetch the engineer_id from the mis table
$sql_mis = "SELECT report_drafter_to_technical FROM mis WHERE reference_id = ?";
$stmt_mis = $conn->prepare($sql_mis);
$stmt_mis->bind_param("s", $reference_id);
$stmt_mis->execute();
$result_mis = $stmt_mis->get_result();
$row_mis = $result_mis->fetch_assoc();
$stmt_mis->close(); 

if ($row_mis) {
    $report_drafter_to_technical = $row_mis['report_drafter_to_technical'];

    // Step 2: Fetch the engineer's name from engineer_login table
    $sql_engineer = "SELECT name FROM technical_login WHERE technical_manager_id = ?";
    $stmt_engineer = $conn->prepare($sql_engineer);
    $stmt_engineer->bind_param("s", $report_drafter_to_technical);
    $stmt_engineer->execute();
    $result_engineer = $stmt_engineer->get_result();
    $row_engineer = $result_engineer->fetch_assoc();
    $stmt_engineer->close();

    if ($row_engineer) {
        $technical_name = $row_engineer['name'];
        echo "Engineer Name: " . $technical_name;
    } else {
        echo "Engineer not found.";
    }
} else {
    echo "No engineer assigned for this reference_id.";
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>IFL Report</title>
    <link rel="shortcut icon" href="favicon.png" type="image/x-icon"> 
</head>
<style>
.container {
    width: 90%;
    margin: 20px auto;
    border: 1px solid black;
    padding: 20px;
}
.header-content {
text-align: center;
flex: 1;
}

.header-content h1 {
margin: 0;
margin-top:25px;  
font-size: 38px;
color: #902d2d;
}

.header-content p {
margin: 2px 0;
font-size: 26px;
color: #333;
}
.footer{
display: flex;
}
h3{
background-color:rgb(243, 234, 222) ;
padding:5px;
text-align: center;
border:1px solid black;
}  



body {
            font-family: Arial, sans-serif;
        }
        table {
            width: 100%;
            border-collapse: collapse;
        }
        th, td {
            border: 1px solid black;
            padding: 8px;
            text-align:left ;
        }
        th {
            background-color: #f2f2f2;
          
        }
        input {
            width: 100%;
            border: none;
            padding: 5px;
        }
        pre{
    font-size:15px;
    font-family: Arial, sans-serif;
    font-style: oblique;
}
textarea{
  margin-top:5px;
    width:100%;
  height:200px;
}
.container {
    max-width: 1200px;
    margin: 20px auto;
    padding: 20px;
    background-color: white;
    box-shadow: 0px 0px 10px rgba(0, 0, 0, 0.1);
    border-radius: 8px;
}

.title {
    text-align: center;
    font-size: 24px;
    font-weight: bold;
    margin-bottom: 20px;
}
.grid-container {
    display: grid;
    grid-template-columns: repeat(4, 1fr);
    gap: 15px;
}

.grid-item {
    position: relative;
    border-radius: 8px;
    overflow: hidden;
    box-shadow: 0px 4px 6px rgba(0, 0, 0, 0.1);
}

.grid-item img {
    width: 100%;
    height: 200px;
    object-fit: cover;
    transition: transform 0.3s ease;
}
.grid-item:hover img {
    transform: scale(1.05);
}

.overlay {
    position: absolute;
    bottom: 0;
    left: 0;
    background: rgba(0, 0, 0, 0.6);
    color: white;
    width: 100%;
    padding: 8px;
    font-size: 14px;
    text-align: center;
}

.image-gallery {
    display: grid;
    grid-template-columns: repeat(2, 1fr); /* 3 images per row */
    gap:10px;
    justify-content:space-between;
    margin-top:20px;
    align-items:center;
  }
  .image-gallery img {
    width: 100%;
    height:300px;
    border: 1px solid #ccc;
    object-fit: cover;
    border-radius:5px;
    box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
  }
  .image-gallery p {
    text-align: center;
    margin-top: 5px;
    font-size: 12px;
    color: #333;
  }
  button{
    padding:8px;
    margin-left:45%;
    background-color:#808485;
    color:white;
    font-weight:700;
    font-style:italic;
  }
  button:hover{
    background-color:rgba(216,216,216,255);
    color:white;
  }
  @media print{
    body{
      margin:0;
    }
    button{
      display:none;
      margin-left:30%;
    }
}

</style>
<body>
    <div class="container">
        <header>
            <div class="footer">
            <div class="logo">
                <img src="images/logo.png" alt="Magpie Logo">
            </div>
            <div class="header-content">
                <h1>MAGPIE ENGINEERING PVT. LTD.</h1>
                <p>Valuer Designer Architects</p>
                <p>Address : Office no. 201, 2nd floor, Gravity Mall, Mechanic nagar, warehouse road, near vijay nagar, Indore, Madhya Pradesh- 452011</p>
            </div>
            </div>
        </header>



        <h2>Valuation Report</h2>
        <table>
            <tr>
                <th colspan="3">A. GENERAL DETAILS</th>
                <th>Date</th>
                <td><input type="text" value="<?= $data1['report_assigned_at'] ?? '' ?>"readonly></td>
            </tr>
            <tr>
                <td>Prospect No</td>
                <td colspan="4"><input type="text" value="<?= $data1['reference_id'] ?? '' ?>"readonly></td>
            </tr>
            <tr>
                <td>Type of loan </td>
                <td colspan="4"><input type="text" value="<?= $data1['caseType'] ?? '' ?>"readonly></td>
            </tr>
            <tr>
                <td>Name of Property Owner</td>
                <td colspan="4"><input type="text" value="<?= $data9['owner_name'] ?? '' ?>"readonly></td>
            </tr>
            <tr>
                <td>Name of the Customer(s)</td>
                <td colspan="4"><input type="text" value="<?= $data1['customerName'] ?? '' ?>"readonly></td>
            </tr>
            <tr>
                <td>Property Address as per site</td>
                <td colspan="4"><input type="text" value="<?= $data3['address_per_site'] ?? '' ?>"readonly></td>
            </tr>
            <tr>
                <td>Address as per Firing</td>
                <td colspan="4"><input type="text" value="<?= $data3['address_line_1_as_per_doc'] ?? '' ?>"readonly></td>
            </tr>
            <tr>
                <td>Contact Person’s No</td>
                <td><input type="text" value="<?= $data2['person_meet_at_site_contact'] ?? '' ?>"readonly></td>
                <td>Tenant if Applicable</td>
                <td><input type="text" value="<?= $data2['relation_of_occupant'] ?? '' ?>"readonly></td>
            </tr>
            <tr>
                <td>Landmark</td>
                <td colspan="4"><input type="text" value="<?= $data3['landmark_1'] ?? '' ?>"readonly></td>
            </tr>
            <tr>
                <td>Date of Technical Visit</td>
                <td colspan="4"><input type="text"value="<?= $data1['report_assigned_at'] ?? '' ?>"readonly></td>
            </tr>
            <tr>
               
                <td>Property Usage</td>
                <td>AS PER DOC </td>
                <td><input type="text" value="<?= $data4['approved_property_usage'] ?? '' ?>"readonly></td>
                <td>ON SITE</td>
                <td><input type="text" value="<?= $data4['current_property_usage'] ?? '' ?>"readonly></td>
            </tr>
            <tr>
                <td>Occupancy</td>
                <td><input type="text" value="<?= $data2['occupancy_status'] ?? '' ?>"readonly></td>
            </tr>
            <tr>
                <td>Property in Demolition List of local authority </td>
                <td colspan="4"><input type="text" value="<?= $data10['NA'] ?? '' ?>"readonly></td>
            </tr>
            <tr>
                <td>Marketability</td>
                <td colspan="4"><input type="text" value="<?= $data9['markebility'] ?? '' ?>"readonly></td>
            </tr>
            <tr>
                <td>Front Side Road Width</td>
                <td colspan="4"><input type="text" value="<?= $data2['width_of_approach_road'] ?? '' ?>"readonly></td>
            </tr>
            <tr>
                <th colspan="5">B. SURROUNDING LOCALITY DETAILS</th>
            </tr>
            <tr>
                <td>Ward No / Municipal land No</td>
                <td><input type="text" value="<?= $data2['NA'] ?? '' ?>"readonly></td>
                <td>Type of Locality</td>
                <td colspan="2"><input type="text" value="<?= $data2['class_of_locality'] ?? '' ?>"readonly></td>
            </tr>
            <tr>
                <td>Distance From City Centre</td>
                <td><input type="text" value="<?= $data10['NA'] ?? '' ?>"readonly></td>
                <td>Site Access</td>
                <td><input type="text" value="<?= $data2['approach_road_to_property'] ?? '' ?>"readonly></td>
            </tr>
            <tr>
                <td>Jurisdiction</td>
                <td colspan="4"><input type="text" value="<?= $data3['property_location_in'] ?? '' ?>"readonly></td>
            </tr>
            <tr>
                <td>Layout Plan Approving Authority</td>
                <td colspan="4"><input type="text" value="<?= $data9['layout_authority'] ?? '' ?>"readonly></td>
            </tr>
            <tr>
                <td>Sanction Plan Approving Authority</td>
                <td colspan="4"><input type="text" value="<?= $data9['floor_details'] ?? '' ?>"readonly></td>
            </tr>
            <tr>
                <td>Conditions of Approach Road</td>
                <td colspan="4"><input type="text" value="<?= $data2['type_of_approach_road'] ?? '' ?>"readonly></td>
            </tr>
            <tr>
                <th colspan="5">C. PROPERTY DETAILS</th>
            </tr>
            <tr>
                <td >No of Floors</td>
                <td colspan="4"><input type="text" value="<?= $data10['NA'] ?? '' ?>"readonly></td>
            </tr>
            <tr>
                <td >Floor wise Usage</td>
                <td colspan="4"><input type="text" value="<?= $data4['current_property_usage'] ?? '' ?>"readonly></td>
            </tr>
            <tr>
                <td>Age of the Property</td>
                <td><input type="text" value="<?= $data2['age_of_property'] ?? '' ?>"readonly></td>
                <td>Residual Age</td>
                <td colspan="2"><input type="text" value="<?= $data2['residual_age_of_property'] ?? '' ?>"readonly></td>
            </tr>
            <tr>
                <td>Type of structure </td>
                <td colspan="4"><input type="text" value="<?= $data4['structure_type'] ?? '' ?>"readonly></td>
            </tr>

            <tr>
                <th>Side Boundaries</th>
                <th>As per document</th>
                <th>As per site</th>
                <th colspan="2">As per plan</th>
            </tr>
            <tr>
                <td>North</td>
                <td><input type="text" value="<?= $data3['direction_as_per_document_north'] ?? '' ?>"readonly></td>
                <td><input type="text" value="<?= $data3['direction_as_per_site_north'] ?? '' ?>"readonly></td>
                <td colspan="2"><input type="text" value="<?= $data3['direction_approved_north'] ?? '' ?>"readonly></td>
            </tr>
            <tr>
                <td>South</td>
                <td><input type="text" value="<?= $data3['direction_as_per_document_south'] ?? '' ?>"readonly></td>
                <td><input type="text" value="<?= $data3['direction_as_per_site_south'] ?? '' ?>"readonly></td>
                <td colspan="2"><input type="text" value="<?= $data3['direction_approved_south'] ?? '' ?>"readonly></td>
            </tr>
            <tr>
                <td>East</td>
                <td><input type="text" value="<?= $data3['direction_as_per_document_east'] ?? '' ?>"readonly></td>
                <td><input type="text" value="<?= $data3['direction_as_per_site_east'] ?? '' ?>"readonly></td>

                <td colspan="2"><input type="text" value="<?= $data3['direction_approved_east'] ?? '' ?>"readonly></td>
            </tr>
            <tr>
                <td>West</td>
                <td><input type="text" value="<?= $data3['direction_as_per_document_west'] ?? '' ?>"readonly></td>
                <td><input type="text" value="<?= $data3['direction_as_per_site_west'] ?? '' ?>"readonly></td>
                <td colspan="2"><input type="text" value="<?= $data3['direction_approved_west'] ?? '' ?>"readonly></td>
            </tr>
            <tr>
                <td>Boundaries are matching or not</td>
                <td colspan="4"><input type="text" value="<?= $data3['boundaries_matching'] ?? '' ?>"readonly></td>
            </tr>
            <tr>
                <td>Property Identified through</td>
                <td colspan="4"><input type="text" value="Refer Remarks"readonly></td>
            </tr>
            <tr>
                <td>Plot Demarcated at site</td>
                <td colspan="4"><input type="text" value="<?= $data2['demarcated_at_site'] ?? '' ?>"readonly></td>
            </tr>
            <tr>
                <td>Amenities</td>
                <td colspan="4"><input type="text" value="<?= $data6['amenities_total'] ?? '' ?>"readonly></td>
            </tr>
            <tr>
                <th colspan="5">D. STRUCTURAL DETAILS</th>
            </tr>
            <tr>
                <td>Type of Structure</td>
                <td><input type="text" value="<?= $data4['structure_type'] ?? '' ?>"readonly></td>
                <td>No of floors</td>
                <td colspan="2"><input type="text" value="<?= $data10['NA'] ?? '' ?>"readonly></td>
            </tr>
            <tr>
                <td>No of wings</td>
                <td colspan="4"><input type="text" value="<?= $data10['NA'] ?? '' ?>"readonly></td>
            </tr>
            <tr>
                <td>No. of flats on each floor</td>
                <td colspan="4"><input type="text" value="<?= $data8['number_of_units_each_floor'] ?? '' ?>"readonly></td>
            </tr>
            <tr>
                <td>Quality of construction</td>
                <td colspan="4"><input type="text" value="<?= $data8['Present_quality_of_structure'] ?? '' ?>"readonly></td>
            </tr>
            <tr>
                <td>Structural observation</td>
                <td colspan="4"><input type="text" value="<?= $data2['structurally_fit'] ?? '' ?>"readonly></td>
            </tr>
            <tr>
                <td>Configuration</td>
                <td colspan="4"><input type="text" value="<?= $data8['configuration_building'] ?? '' ?>"readonly></td>
            </tr>
            <tr>
                <th colspan="5">E. INTERIORS</th>
            </tr>
            <tr>
                <td>Flooring & finishing</td>
                <td colspan="4"><input type="text" value="<?= $data2['NA'] ?? '' ?>"readonly></td>
            </tr>
            <tr>
                <td>Roofing and terracing</td>
                <td colspan="4"><input type="text" value="<?= $data2['NA'] ?? '' ?>"readonly></td>
            </tr>
            <tr>
                <td>Quality of fixtures & Settings</td>
                <td colspan="4"><input type="text" value="<?= $data2['NA'] ?? '' ?>"readonly></td>
            </tr>
            <tr>
                <td>Doors & Windows</td>
                <td colspan="4"><input type="text" value="<?= $data8['door_window_paint_present_completion'] ?? '' ?>"readonly></td>
            </tr>
            <tr>
                <th colspan="5">F. PLAN APPROVAL DETAILS</th>
            </tr>
            <tr>
                <td>Construction as per approved / sanctioned plans</td>
                <td colspan="4"><input type="text" value="<?= $data6['construction_square_feet'] ?? '' ?>"readonly></td>
            </tr>
            <tr>
                <td>Sanctioned or approved plan No. & Date</td>
                <td colspan="2"><input type="text" value="<?= $data9['floor_details'] ?? '' ?>"readonly></td>
                <td colspan="2"><input type="text" value="<?= $data10['NA'] ?? '' ?>"readonly></td>
            </tr>
            <tr>
                <td>Construction permission Number and date</td>
                <td colspan="2"><input type="text" value="<?= $data9['possesion_details'] ?? '' ?>"readonly></td>
                <td colspan="2"><input type="text" value="<?= $data10['NA'] ?? '' ?>"readonly></td>
            </tr>
            <tr>
                <td>Occupancy Certificate/Completion Certificate available </td>
                <td colspan="2"><input type="text" value="<?= $data9['nonagricultural_details'] ?? '' ?>"readonly></td>
                <td colspan="2"><input type="text" value="<?= $data10['NA'] ?? '' ?>"readonly></td>
            </tr>
            <tr>
                <td>Violations Observed (if any)</td>
                <td colspan="4"><input type="text" value="<?= $data10['NA'] ?? '' ?>"readonly></td>
            </tr>
            <tr>
                <td>Demolition Risk </td>
                <td colspan="4"><input type="text" value="<?= $data9['demolition_risk_1'] ?? '' ?>"readonly></td>
            </tr>
            <tr>
                <td> IF plans not available then is the structure confirming to the local bye-laws</td>
                <td colspan="4"><input type="text" value="<?= $data10['NA'] ?? '' ?>"readonly></td>
            </tr>
        </table>
        <h2>G. DEVIATION DETAILS</h2>
        <table>
            <tr>
                <th>Floor Details</th>
                <th colspan="2">Deviation in Sqft.</th>
                <th>Deviation in %</th>
            </tr>
            <tr>
                <th>Floor</th>
                <th>As per plan</th>
                <th>At Site</th>
                <th>At Site</th>
            </tr>
            <tr>
                <td>Basement</td>
                <td><input type="text" value="<?= $data10['NA'] ?? '' ?>"readonly></td>
                <td><input type="text" value="<?= $data10['NA'] ?? '' ?>"readonly></td>
                <td><input type="text" value="<?= $data10['NA'] ?? '' ?>"readonly></td>
            </tr>
            <tr>
                <td>Stilt</td>
                <td><input type="text" value="<?= $data10['NA'] ?? '' ?>"readonly></td>
                <td><input type="text" value="<?= $data10['NA'] ?? '' ?>"readonly></td>
                <td><input type="text" value="<?= $data10['NA'] ?? '' ?>"readonly></td>
            </tr>
            <tr>
                <td>Ground Floor</td>
                <td><input type="text" value="<?=$data6['construction_square_feet'] ?? '' ?>"readonly></td>
                <td><input type="text" value="<?=$data10['actual_construction_square_feet']?? '' ?>"readonly></td>
                <td><input type="text" value="<?= $data10['NA'] ?? '' ?>"readonly></td>
            </tr>
            <tr>
                <td>First Floor</td>
                <td><input type="text" value="<?= $data10['NA'] ?? '' ?>"readonly></td>
                <td><input type="text" value="<?= $data10['NA'] ?? '' ?>"readonly></td>
                <td><input type="text" value="<?= $data10['NA'] ?? '' ?>"readonly></td>
            </tr>
            <tr>
                <td>Second Floor</td>
                <td><input type="text" value="<?= $data10['NA'] ?? '' ?>"readonly></td>
                <td><input type="text" value="<?= $data10['NA'] ?? '' ?>"readonly></td>
                <td><input type="text" value="<?= $data10['NA'] ?? '' ?>"readonly></td>
            </tr>
            <tr>
                <td>Third Floor</td>
                <td><input type="text" value="<?= $data10['NA'] ?? '' ?>"readonly></td>
                <td><input type="text" value="<?= $data10['NA'] ?? '' ?>"readonly></td>
                <td><input type="text" value="<?= $data10['NA'] ?? '' ?>"readonly></td>
            </tr>
            <tr>
                <td>Fourth Floor</td>
                <td><input type="text" value="<?= $data10['NA'] ?? '' ?>"readonly></td>
                <td><input type="text" value="<?= $data10['NA'] ?? '' ?>"readonly></td>
                <td><input type="text" value="<?= $data10['NA'] ?? '' ?>"readonly></td>
            </tr>
            <tr>
                <td>5th and above</td>
                <td><input type="text" value="<?= $data10['NA'] ?? '' ?>"readonly></td>
                <td><input type="text" value="<?= $data10['NA'] ?? '' ?>"readonly></td>
                <td><input type="text" value="<?= $data10['NA'] ?? '' ?>"readonly></td>
            </tr>
            <tr>
                <td>Any Other Floor</td>
                <td><input type="text" value="<?= $data10['NA'] ?? '' ?>"readonly></td>
                <td><input type="text" value="<?= $data10['NA'] ?? '' ?>"readonly></td>
                <td><input type="text" value="<?= $data10['NA'] ?? '' ?>"readonly></td>
            </tr>
        </table>
        
        <h2>H. SELF CONSTRUCTION CASE</h2>
        <table>
            <tr>
                <td>Architect certified estimate available or not</td>
                <td><input type="text" value="<?= $data2['NA'] ?? '' ?>"readonly></td>
            </tr>
            <tr>
                <td>Construction Amount certified</td>
                <td><input type="text" value="<?= $data2['NA'] ?? '' ?>"readonly></td>
            </tr>
            <tr>
                <td>Other</td>
                <td><input type="text" value="<?= $data2['NA'] ?? '' ?>"readonly></td>
            </tr>
        </table>
        
        <h2>I. FAIR MARKET VALUE</h2>
        <table>
            <tr>
                <th>Valuation Methodology</th>
                <th>Comparison Method</th>
            </tr>
        </table>
        
        <table>
            <tr>
                <th>Particulars</th>
                <th>Description</th>
                <th>Area (in Sq. ft)</th>
                <th>Rate (per Sq. ft)</th>
                <th>Total Value</th>
                <th>Circle Rate (per Sq ft)</th>
                <th>Value Basis Circle Rate</th>
            </tr>
            <tr>
                <td>Land area as per document</td>
                <td><input type="text" value="<?= $data10['NA'] ?? '' ?>"readonly></td>
                <td><input type="text" value="<?= $data6['plot_square_feet'] ?? '' ?>"readonly></td>
                <td><input type="text" value="<?= $data6['plot_rate'] ?? '' ?>"readonly></td>
                <td><input type="text" value="<?= $data6['plot_valuation_computed'] ?? '' ?>"readonly></td>
                <td><input type="text" value="<?= $data6['guideline_rate'] ?? '' ?>"readonly></td>
                <td><input type="text" value="<?= $data6['guideline_values'] ?? '' ?>"readonly></td>
            </tr> 

            <tr>
                <td>Carpet area as per plan </td>
                <td><input type="text" value="<?= $data10['NA'] ?? '' ?>"readonly></td>
                <td><input type="text" value="<?= $data6['carpet_square_feet'] ?? '' ?>"readonly></td>
                <td><input type="text" value="<?= $data6['carpet_rate'] ?? '' ?>"readonly></td>
                <td><input type="text" value="<?= $data6['carpet_valuation_computed'] ?? '' ?>"readonly></td>
                <td><input type="text" value="<?=  $data6['guideline_rate']?? '' ?>"readonly></td>
                <td><input type="text" value="<?=$data6['guideline_values'] ?? '' ?>"readonly></td>
            </tr>
            <tr>
                <td>Build up area as per plan </td>
                <td><input type="text" value="<?= $data10['NA'] ?? '' ?>"readonly></td>
                <td><input type="text" value="<?= $data6['construction_square_feet'] ?? '' ?>"readonly></td>
                <td><input type="text" value="<?= $data6['construction_rate'] ?? '' ?>"readonly></td>
                <td><input type="text" value="<?= $data6['construction_valuation_computed'] ?? '' ?>"readonly></td>
                <td><input type="text" value="<?=  $data6['guideline_rate'] ?? '' ?>"readonly></td>
                <td><input type="text" value="<?= $data6['guideline_values'] ?? '' ?>"readonly></td>
            </tr>
            <tr>
                <td>super built up area </td>
                <td><input type="text" value="<?= $data10['NA'] ?? '' ?>"readonly></td>
                <td><input type="text" value="<?= $data6['saleable_square_feet'] ?? '' ?>"readonly></td>
                <td><input type="text" value="<?= $data6['saleable_rate'] ?? '' ?>"readonly></td>
                <td><input type="text" value="<?= $data6['saleable_valuation_computed'] ?? '' ?>"readonly></td>
                <td><input type="text" value="<?= $data6['guideline_rate'] ?? '' ?>"readonly></td>
                <td><input type="text" value="<?=$data6['guideline_values'] ?? '' ?>"readonly></td>
            </tr>
            <tr>
                <td>Amenities value </td>
                <td><input type="text" value="<?= $data6['addition_amenities_description_1'] ?? '' ?>"readonly></td>
                <td><input type="text" value="<?= $data10['NA'] ?? '' ?>"readonly></td>
                <td><input type="text" value="<?= $data10['NA'] ?? '' ?>"readonly></td>
                <td><input type="text" value="<?= $data6['amenities_total'] ?? '' ?>"readonly></td>
                <td><input type="text" value="<?=  $data6['guideline_rate'] ?? '' ?>"readonly></td>
                <td><input type="text" value="<?=$data6['guideline_values'] ?? '' ?>"readonly></td>
            </tr>
            <tr>
                <td>Depreciation amount </td>
                <td><input type="text" value="<?= $data10['NA'] ?? '' ?>"readonly></td>
                <td><input type="text" value="<?= $data10['NA'] ?? '' ?>"readonly></td>
                <td><input type="text" value="<?= $data10['NA'] ?? '' ?>"readonly></td>
                <td><input type="text" value="<?= $data10['NA'] ?? '' ?>"readonly></td>
                <td><input type="text" value="<?=  $data6['guideline_rate'] ?? '' ?>"readonly></td>
                <td><input type="text" value="<?= $data6['guideline_values'] ?? '' ?>"readonly></td>
            </tr>
            <tr>
                <td>Particulars </td>
                <td><input type="text" value="<?= $data10['NA'] ?? '' ?>"readonly></td>
                <td><input type="text" value="<?= $data10['NA'] ?? '' ?>"readonly></td>
                <td><input type="text" value="<?= $data10['NA'] ?? '' ?>"readonly></td>
                <td><input type="text" value="<?= $data10['NA'] ?? '' ?>"readonly></td>
                <td><input type="text" value="<?=  $data6['guideline_rate']?? '' ?>"readonly></td>
                <td><input type="text" value="<?= $data6['guideline_values'] ?? '' ?>"readonly></td>
            </tr>
            <tr>
                <td>Car Parking Charges </td>
                <td><input type="text" value="<?= $data10['NA'] ?? '' ?>"readonly></td>
                <td><input type="text" value="<?= $data10['NA'] ?? '' ?>"readonly></td>
                <td><input type="text" value="<?= $data10['NA'] ?? '' ?>"readonly></td>
                <td><input type="text" value="<?= $data10['NA'] ?? '' ?>"readonly></td>
                <td><input type="text" value="<?= $data6['guideline_rate'] ?? '' ?>"readonly></td>
                <td><input type="text" value="<?=$data6['guideline_values'] ?? '' ?>"readonly></td>
            </tr>
            <tr>
                <td>Fairr market value of the property </td>
                <td><input type="text" value="<?= $data10['NA'] ?? '' ?>"readonly></td>
                <td><input type="text" value="<?= $data10['NA'] ?? '' ?>"readonly></td>
                <td colspan="2"><input type="text" value="<?= $data6['total_finally_area_valuation'] ?? '' ?>"readonly></td>
                <td><input type="text" value="<?=  $data6['guideline_rate']?? '' ?>"readonly></td>
                <td><input type="text" value="<?= $data6['guideline_values'] ?? '' ?>"readonly></td>
            </tr>
            <tr>
                <td>Availability of potable drinking water and basic sanitation facility </td>
                <td colspan="6"><input type="text" value="<?= $data10['NA'] ?? '' ?>"readonly></td>
            
            </tr>
        </table>
        <h2>FLOORWISE DETAILS OF USAGE AND RENTAL VALUE</h2>
<table>
    <tr>
        <th>Floor</th>
        <th>Usage</th>
        <th>Units</th>
        <th>Value</th>
        <th>If Tenanted, Year of Current Tenancy</th>
        <th>Rental Assessment</th>
    </tr>
    <tr>
        <td>Basement</td>
        <td><input type="text" value="<?= $data10['NA'] ?? '' ?>"readonly></td>
        <td><input type="text" value="<?= $data10['NA'] ?? '' ?>"readonly></td>
        <td><input type="text" value="<?= $data10['NA'] ?? '' ?>"readonly></td>
        <td><input type="text" value="<?= $data10['NA'] ?? '' ?>"readonly></td>
        <td><input type="text" value="<?= $data10['NA'] ?? '' ?>"readonly></td>
    </tr>
    <tr>
        <td>Gr floor</td>
        <td><input type="text" value="<?= $data10['NA'] ?? '' ?>"readonly></td>
        <td><input type="text" value="<?= $data10['NA'] ?? '' ?>"readonly></td>
        <td><input type="text" value="<?= $data10['NA'] ?? '' ?>"readonly></td>
        <td><input type="text" value="<?= $data10['NA'] ?? '' ?>"readonly></td>
        <td><input type="text" value="<?= $data10['NA'] ?? '' ?>"readonly></td>
    </tr>
    <tr>
        <td>FF</td>
        <td><input type="text" value="<?= $data10['NA'] ?? '' ?>"readonly></td>
        <td><input type="text" value="<?= $data10['NA'] ?? '' ?>"readonly></td>
        <td><input type="text" value="<?= $data10['NA'] ?? '' ?>"readonly></td>
        <td><input type="text" value="<?= $data10['NA'] ?? '' ?>"readonly></td>
        <td><input type="text" value="<?= $data10['NA'] ?? '' ?>"readonly></td>
    </tr>
    <tr>
        <td>2nd / Above</td>
        <td><input type="text" value="<?= $data10['NA'] ?? '' ?>"readonly></td>
        <td><input type="text" value="<?= $data10['NA'] ?? '' ?>"readonly></td>
        <td><input type="text" value="<?= $data10['NA'] ?? '' ?>"readonly></td>
        <td><input type="text" value="<?= $data10['NA'] ?? '' ?>"readonly></td>
        <td><input type="text" value="<?= $data10['NA'] ?? '' ?>"readonly></td>
    </tr>
</table>

<table>
    <tr>
        <td>Latitude of property</td>
        <td><input type="text" value="<?= $data3['latitude_value'] ?? '' ?>"readonly></td>
        <td>Longitude of property</td>
        <td><input type="text" value="<?= $data3['longitude_value'] ?? '' ?>"readonly></td>
    </tr>
    <tr>
        <td>Seismic zone</td>
        <td colspan="3"><input type="text" value="<?= $data4['seismic_zone'] ?? '' ?>"readonly></td>
    </tr>
    <tr>
        <td>Wind & Cyclone zone</td>
        <td colspan="3"><input type="text" value="<?= $data10['NA'] ?? '' ?>"readonly></td>
    </tr>
    <tr>
        <td>Flood area</td>
        <td colspan="3"><input type="text" value="<?= $data10['NA'] ?? '' ?>"readonly></td>
    </tr>
    <tr>
        <td>Land Slide Zone </td>
        <td colspan="3"><input type="text" value="<?= $data10['NA'] ?? '' ?>"readonly></td>
    </tr>

    <tr>
        <th colspan="5" style="align:left";>Remarks</th>
    </tr>
    <tr>
         <td colspan="4">            <textarea rows="10"  id="remarks" name="engineer_id" oninput="autoResize(this)"><?= $data10['remarks'] ?? '' ?></textarea>
</td>
                </tr>
    <tr>
        <th colspan="5" style="align:left";>CONCERNS</th>
    </tr>
    <tr>
        <td colspan="5">
              <ol>
                <li><input type="text" placeholder="Enter Remark 1" size="100" readonly></li>
                <li><input type="text" placeholder="Enter Remark 2" size="100" readonly></li>
                <li><input type="text" placeholder="Enter Remark 3" size="100" readonly></li>
                <li><input type="text" placeholder="Enter Remark 4" size="100" readonly></li>
                <li><input type="text" placeholder="Enter Remark 5" size="100" readonly></li>
                <li><input type="text" placeholder="Enter Remark 6" size="100" readonly></li>
            </ol>
        </td>
    </tr>
    <tr>
        <th colspan="5" style="align:left";>DECLARATION </th>
    </tr>
    <tr>
        <td colspan="5">
          <pre>
          1.The property was inspected by our authorized representative MR. SANJAY SAINI
          2.we have no direct or indirect interest in the property valued
          3.The information furnished above is correct to the best of our knowledge and belief and as per factual position & information given to us and
          is based on the copy of documents/plans submitted to us by IIFL Home Loan or shown to us by the client.

          </pre>
        </td>
    </tr>

    
</table>
<div class="container">

    <h2 class="title">Property Photos</h2>
      <!-- Header Section -->
      <div class="header">
            <h2 style="font-style: italic;">IMAGE UPLOAD FORM</h2>
        </div>
        <div class="image-gallery">
    <?php
// Database connection
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "project_db"; // Replace with your database name
$message = "";
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Step 2: Retrieve reference_id from session (if set)
$reference_id = $_SESSION['reference_id'] ?? null;

// Fetch reference_id from GET or session
$reference_id = isset($_GET['reference_id']) ? $_GET['reference_id'] : $reference_id;

// Ensure reference_id is available
if ($reference_id) {
    // Fetch the images from the database using a prepared statement
    $sql = "SELECT 
                image1, image2, image3, image4, image5, 
                image6, image7, image8, image9, image10, 
                image11, image12 
            FROM final_uploaded_images 
            WHERE reference_id = ?";
    
    $stmt = $conn->prepare($sql);
    if ($stmt === false) {
        die("Error preparing the SQL statement: " . $conn->error);
    }

    // Bind the parameter
    $stmt->bind_param("s", $reference_id); // "s" indicates the parameter is a string

    // Execute the statement
    $stmt->execute();

    // Get the result
    $result = $stmt->get_result();

    if ($result->num_rows > 0) {
        while ($row = $result->fetch_assoc()) {
            if (!empty($row['image1'])) {
                echo '<div>';
                echo '<img src="data:image/jpeg;base64,' . base64_encode($row['image1']) . '" alt="Image 1">';
                echo '<p>EXTERNAL PHOTOS</p>';
                echo '</div>';
            }
            if (!empty($row['image2'])) {
                echo '<div>';
                echo '<img src="data:image/jpeg;base64,' . base64_encode($row['image2']) . '" alt="Image 2">';
                echo '<p>Kitchen</p>';
                echo '</div>';
            }
            if (!empty($row['image3'])) {
                echo '<div>';
                echo '<img src="data:image/jpeg;base64,' . base64_encode($row['image3']) . '" alt="Image 3">';
                echo '<p>Selfie</p>';
                echo '</div>';
            }
            if (!empty($row['image4'])) {
                echo '<div>';
                echo '<img src="data:image/jpeg;base64,' . base64_encode($row['image4']) . '" alt="Image 4">';
                echo '<p>Electric Meter</p>';
                echo '</div>';
            }
            if (!empty($row['image5'])) {
                echo '<div>';
                echo '<img src="data:image/jpeg;base64,' . base64_encode($row['image5']) . '" alt="Image 5">';
                echo '<p>Google Map</p>';
                echo '</div>';
            }
            if (!empty($row['image6'])) {
                echo '<div>';
                echo '<img src="data:image/jpeg;base64,' . base64_encode($row['image6']) . '" alt="Image 6">';
                echo '<p>Other 1</p>';
                echo '</div>';
            }
            if (!empty($row['image7'])) {
                echo '<div>';
                echo '<img src="data:image/jpeg;base64,' . base64_encode($row['image7']) . '" alt="Image 7">';
                echo '<p>Other 2</p>';
                echo '</div>';
            }
            if (!empty($row['image8'])) {
                echo '<div>';
                echo '<img src="data:image/jpeg;base64,' . base64_encode($row['image8']) . '" alt="Image 8">';
                echo '<p>Other 3</p>';
                echo '</div>';
            }
            if (!empty($row['image9'])) {
                echo '<div>';
                echo '<img src="data:image/jpeg;base64,' . base64_encode($row['image9']) . '" alt="Image 9">';
                echo '<p>Other 4</p>';
                echo '</div>';
            }
            if (!empty($row['image10'])) {
                echo '<div>';
                echo '<img src="data:image/jpeg;base64,' . base64_encode($row['image10']) . '" alt="Image 10">';
                echo '<p>Other 5</p>';
                echo '</div>';
            }
            if (!empty($row['image11'])) {
                echo '<div>';
                echo '<img src="data:image/jpeg;base64,' . base64_encode($row['image11']) . '" alt="Image 11">';
                echo '<p>Other 6</p>';
                echo '</div>';
            }
            if (!empty($row['image12'])) {
                echo '<div>';
                echo '<img src="data:image/jpeg;base64,' . base64_encode($row['image12']) . '" alt="Image 12">';
                echo '<p>Other 7</p>';
                echo '</div>';
            }
        }
    } else {
        echo "<p style='text-align:center;'>No images found.</p>";
    }
    
    // Close the statement
    $stmt->close();
} else {
    echo "<p style='text-align:center;'>Reference ID is missing.</p>";
}
?>
</table>

     <!-- <button onclick="window.print()">Download PDF</button> -->
     <button id="downloadPdf" onclick="setPrintMargins()">DOWNLOAD PDF</button>
  <script>
    document.getElementById('downloadPdf').addEventListener('click', () => {
      // Select the content you want to convert to PDF
      const element = document.getElementById('content');
      const options = {
        margin:[0,0],
        filename:'report.pdf',
        image: { type: 'jpeg', quality: 0.98 },
        html2canvas: { scale: 2 },
        jsPDF: { unit: 'in', format: 'letter', orientation: 'portrait' }
      };

      // Generate and download the PDF
      html2pdf().set(options).from(element).save();
    });
    function setPrintMargins() {
      const style = document.createElement('style');
      style.innerHTML = `
      @media print {
          body {
            margin:0.5;
          }
        }
      `;
      document.head.appendChild(style);
      window.print();
    }
    // Disable all input fields in the form
    document.querySelectorAll('input').forEach(function(input) {
        input.disabled = true;  // Disables the field completely
    });
    </script>
     </div>
    
</body>
</html>