<?php
require 'PHPMailer/PHPMailer.php';
require 'PHPMailer/SMTP.php';
require 'PHPMailer/Exception.php';

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;
 // if using Composer

// DB connection
$conn = new mysqli("localhost", "root", "", "otp_login");
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$date_today = date("Y-m-d");
$sql = "SELECT otp FROM otp_login WHERE date = '$date_today'";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
    $row = $result->fetch_assoc();
    $otp = $row['otp'];

    $mail = new PHPMailer(true);
    try {
        // Server settings
        $mail->isSMTP();
        $mail->Host = 'smtp.gmail.com';
        $mail->SMTPAuth = true;
        $mail->Username = 'jyotinarsinghani519@gmail.com'; // Your Gmail
        $mail->Password = 'jnqm qfld fpbd pxqi';   // Gmail App Password
        $mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS;
        $mail->Port = 587;

        // Recipients
        $mail->setFrom('jyotinarsinghani519@gmail.com', "Magpie Engineering Pvt Ltd.");
        $mail->addAddress('avanipurohit2003@gmail.com');
        $mail->addAddress('jyotinarsinghani519@gmail.com');
        $mail->addAddress('amitchoudharyc57@gmail.com'); // Add more if needed

        // Content
        $mail->isHTML(true);
        $mail->Subject = "Hey Team Here Today's OTP : $date_today";
        $mail->Body    = "OTP:<strong>$date_today</strong> is: <strong>$otp</strong>";

        $mail->send();
        echo "OTP sent successfully.";
    } catch (Exception $e) {
        echo "Message could not be sent. Mailer Error: {$mail->ErrorInfo}";
    }
} else {
    echo "No OTP found for today.";
}
$conn->close();
?>
