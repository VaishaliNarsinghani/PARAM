<?php
session_start();
header('Content-Type: application/json');

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $input = json_decode(file_get_contents('php://input'), true);

    if (!isset($input['page']) || !isset($input['data']) || !is_array($input['data'])) {
        http_response_code(400);
        echo json_encode(['status' => 'error', 'message' => 'Invalid input']);
        exit;
    }

    $page = $input['page'];
    $data = $input['data'];

    switch ($page) {
        case 'area_valuation':
            $_SESSION['area_valuation'] = $data;
            break;
        case 'property_details':
            $_SESSION['property_details'] = $data;
            break;
        case 'address_details':
            $_SESSION['address_details'] = $data;
            break;
        case 'cost_details':
            $_SESSION['cost_details'] = $data;
            break;
        case 'floor_details':
            $_SESSION['floor_details'] = $data;
            break;
        case 'technical_details':
            $_SESSION['technical_details'] = $data;
            break;
        case 'remarks_table':
            // This could be a string or object — handle string only
            $_SESSION['remarks_table'] = isset($data['text']) && is_string($data['text']) ? $data['text'] : '';
            break;
        case 'critical_parameters':
            $_SESSION['critical_parameters'] = $data;
            break;

              case 'mandatory_details':
            $_SESSION['mandatory_details'] = $data;
            break;

        default:
            http_response_code(400);
            echo json_encode(['status' => 'error', 'message' => 'Unknown page']);
            exit;
    }

    echo json_encode(['status' => 'success', 'message' => 'Session updated']);
    exit;
}

http_response_code(405);
echo json_encode(['status' => 'error', 'message' => 'Invalid request method']);
