<?php include('auth.php'); ?>
<?php
$message = "";  // Feedback message for the user
// Step 2: Retrieve reference_id from session
$reference_id = $_SESSION['reference_id'] ?? null;
$fieldss = [];

// Step 3: Check for old_reference_id in mis table
if ($reference_id) {
    // Database connection
    $servername = "localhost";
    $username = "root";
      $password = "";    $dbname = "project_db";
    $conn = new mysqli($servername, $username, $password, $dbname);
    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }

    // Check if old_reference_id exists for this reference_id
    $sql_check_old = "SELECT old_reference_id FROM mis WHERE reference_id = ?";
    $stmt_check = $conn->prepare($sql_check_old);
    $stmt_check->bind_param("s", $reference_id);
    $stmt_check->execute();
    $result = $stmt_check->get_result();
    $row = $result->fetch_assoc();
    $old_reference_id = $row['old_reference_id'] ?? null;
    $stmt_check->close();

    // If old_reference_id exists, fetch data from mandatory_details using that
    if (!empty($old_reference_id)) {
        $sql_prop = "SELECT * FROM mandatory_details WHERE reference_id = ?";
        $stmt_prop = $conn->prepare($sql_prop);
        $stmt_prop->bind_param("s", $old_reference_id);
        $stmt_prop->execute();
        $res_prop = $stmt_prop->get_result();
        $db_data = $res_prop->fetch_assoc() ?: [];
        $stmt_prop->close();

        // Merge session data (priority) with DB data
        $fieldss = array_merge($db_data, $_SESSION['mandatory_details'] ?? []);
    } else {
        // If no old_reference_id, use only session data
        $fieldss = $_SESSION['mandatory_details'] ?? [];
    }

    $conn->close();
}


// Handle form submission
if ($_SERVER["REQUEST_METHOD"] === "POST") {
    $action = $_POST['action'] ?? '';
 
    if ($action === 'save') {
      
        $message = " Mandatory Deatils saved successfully!";
    }
    elseif ($action === 'submit') {
    // Final submission: Save to database
    $result = saveMandatoryDetailsToDatabase($_SESSION['mandatory_details']);
    
    if (strpos($result, "Error:") === 0) {
        // Error → stay on REPORT13 and show popup
        $message = $result;
    } else {
        // Success → clear session and redirect with success popup
        unset($_SESSION['mandatory_details']);
        header("Location: REPORT13.php?msg=" . urlencode($result));
        exit();
    }

    }
}

function saveMandatoryDetailsToDatabase($mandatory_details) {
    // Placeholder for the database-saving logic
    // Ensure this function is implemented to handle database storage properly
    // For now, return true to simulate a successful save
    return true;
}


?>
<?php
if (isset($_GET['msg'])) {
    $message = $_GET['msg'];
}
?>
<script>
    <?php if (!empty($message)): ?>
    alert("<?= htmlspecialchars($message) ?>");
    <?php endif; ?>
</script>
 


<script>
document.addEventListener("DOMContentLoaded", function() {
    const form = document.getElementById("autosave-form");
    form.addEventListener("submit", function(e) {
        let isValid = true;

        document.querySelectorAll(".mandatory-field").forEach(input => {
            const errorDiv = document.getElementById("error-" + input.name);
            if (!input.value.trim()) {
                errorDiv.textContent = input.dataset.fieldname + " is required.";
                isValid = false;
            } else {
                errorDiv.textContent = "";
            }
        });

        if (!isValid) {
            e.preventDefault(); // Stop form submit
            alert("Please fill all mandatory fields.");
        }
    });
});
</script>



<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Property Details Form</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
    <link rel="shortcut icon" href="favicon.ico" type="image/x-icon">
    <link rel="stylesheet" href="REPORT13.css">
   
</head>
<body>
<button id="toggleSidebar">&#9776;</button>
<div id="sidebar" class="sidebar">
    <div style="display: flex">
      <img class="logo" src="logo.png" alt="" />
      <h1>Magpie Engineering</h1>
    </div>
    <div class="rotating-text">Report Drafter</div>
    <a href="clear_and_go_home.php"><i class="fas fa-home icon"></i>Home</a>        

    
    <a href="clear_sessions.php" class="active"><i class="fas fa-clock watch-icon"></i>Pending For Drafting</a>

    <a href="clear_and_logout.php"><i class="fas fa-sign-out-alt icon"></i>Logout</a>

  </div>
<div class="form-container">
    <?php if (!empty($message)): ?>
        <div class="success-message" style="text-align: center; padding: 10px; background-color: #dff0d8; color: #3c763d; border: 1px solid #d6e9c6; margin-bottom: 20px;">
            <?= htmlspecialchars($message) ?>
        </div>
    <?php endif; ?>

    <div class="tab-links">
    <button class="tab" onclick="location.href='REPORT3.php'"><img src="info.png" alt="Icon" width="50  " height="50  ">
    INFO</button>
    <button class="tab" onclick="location.href='REPORT4.php'"><img src="general.png" alt="Icon" width="50  " height="50  " style="margin-bottom:4px;">GENERAL</button>
    <button class="tab " onclick="location.href='REPORT2.php'"> <img src="location.png" alt="Icon" width="50  " height="50  ">
    LOCATION</button>
    <button class="tab " onclick="location.href='REPORT5.php'"><img src="Zoning.png" alt="Icon" width="50  " height="50  ">
    ZONING</button>
    <button class="tab" onclick="location.href='REPORT7.php'"><img src="value.png" alt="Icon" width="50  " height="50  ">
    VALUE</button>
    <button class="tab" onclick="location.href='REPORT9.php'"><img src="Floor.png" alt="Icon" width="50  " height="50  ">
    STRUCTURE</button>
    <button class="tab" onclick="location.href='REPORT10.php'"><img src="documents.png" alt="Icon" width="50  " height="50  ">
    DOCUMENTS</button>
    <button class="tab" onclick="location.href='REPORT115.php'"><img src="photo.png" alt="Icon" width="50  " height="50  ">
    PHOTOS</button>
    <button class="tab tab-button" class="tab active" style="font-weight:800px;" onclick="location.href='REPORT13.php'"    ><img src="mandatory.png" alt="Icon" width="80" height="80"> MANDATORY FIELDS</button>
    <button class="tab" onclick="location.href='REPORT12.php'"><img src="remark.png" alt="Icon" width="50  " height="50  ">
    REMARK</button>   
    <div class="slider"></div>
</div>
 
 

 <!-- Address Form -->
    <form  id="autosave-form" action="" method="POST" style="width: 100%;">
        <div class="header valuation-table">
THE BELOW FIELDS ARE THE MOST IMPORTANT FIELDS IN THE WHOLE DRAFTER'S SECTION       </div>
        <table class="valuation-table">
            <?php 
            $fields = [
                'Address As per site' => 'bill_address_per_site',
                'Latitude' => 'bill_latitude',
                'Longitude' => 'bill_longitude',
                'Nearest Branch Location' => 'bill_nearest_branch',
                 'Property Type'=>'bill_property_type',
               
            ];
               // Display the reference_id as a hidden field (assuming it will not be modified by the user)
               $reference_id = $_SESSION['reference_id'] ?? '';
               echo '<input type="hidden" name="reference_id" value="' . htmlspecialchars($reference_id) . '">';
   
    $count = 0;
    echo '<tr>';
    foreach ($fields as $label => $name) {
        $value = htmlspecialchars($fieldss[$name] ?? '');

        // mark mandatory fields
        $mandatoryFields = ['bill_address_per_site','bill_latitude','bill_longitude','bill_nearest_branch','bill_property_type']; // later you can add more
        $isMandatory = in_array($name, $mandatoryFields);

        echo "<td><label for='$name'>$label";
        if ($isMandatory) {
            echo " <span style='color:red'>*</span>";
        }
        echo "</label></td><td>";

        $dropdowns = [
            'demarcated_at_site' => ['NA','Yes', 'No'],
            'structurally_fit' => ['NA','Good', 'Average','Poor'],
            'community_dominated' => ['No', 'Yes'],
            'relation_of_occupant' =>['NA','Self','Tenant','Seller']
        ];

        if (isset($dropdowns[$name])) {
            echo "<select id='$name' name='$name'>";
            foreach ($dropdowns[$name] as $option) {
                $selected = ($value == $option) ? "selected" : "";
                echo "<option value='$option' $selected>$option</option>";
            }
            echo "</select>";
        } else {
            // add data attribute for mandatory
            $extraAttr = $isMandatory ? "class='mandatory-field' data-fieldname='$label'" : "";
            echo "<input type='text' id='$name' name='$name' value='$value' $extraAttr>";
        }

        // placeholder for error message
        if ($isMandatory) {
            echo "<div class='error-message' id='error-$name' style='color:red; font-size:12px;'></div>";
        }

        echo "</td>";
        $count++;
        if ($count % 3 === 0) echo '</tr><tr>';
    }
    echo '</tr>';
    ?>
</table>
         <div class="submit-button">
            <button type="submit" name="action" value="save">Save</button> 
        </div>
       
    </form>
 
  <script>

document.addEventListener('DOMContentLoaded', () => {
    const form = document.getElementById('autosave-form');
    if (!form) return;

    function gatherFormData(form) {
        const formData = new FormData(form);
        const data = {};
        formData.forEach((value, key) => { data[key] = value; });
        return data;
    }

    function autoSaveSession() {
        const data = gatherFormData(form);
        fetch('autosave.php', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ page: 'mandatory_details', data })
        });
    }

    // autosave on field input
    form.addEventListener('input', autoSaveSession);

    // autosave on submit too (non-blocking)
    form.addEventListener('submit', () => {
        const data = gatherFormData(form);
        const payload = JSON.stringify({ page: 'mandatory_details', data });
        if (navigator.sendBeacon) {
            navigator.sendBeacon('autosave.php', new Blob([payload], { type: 'application/json' }));
        } else {
            fetch('autosave.php', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: payload,
                keepalive: true
            });
        }
    });
});
 

 

 document.addEventListener("DOMContentLoaded", function () {
    let tabs = document.querySelectorAll(".tab-links .tab");
    let slider = document.querySelector(".tab-links .slider");

    function moveSlider(activeTab) {
        slider.style.width = activeTab.offsetWidth + "px";
        slider.style.left = activeTab.offsetLeft + "px";
    }

    tabs.forEach(tab => {
        tab.addEventListener("click", function () {
            tabs.forEach(t => t.classList.remove("active"));
            this.classList.add("active");
            moveSlider(this);
        });

        // Initialize position on load for the active tab
        if (tab.classList.contains("active")) {
            moveSlider(tab);
        }
    });
});

  
document.getElementById("toggleSidebar").addEventListener("click", function () {
    if (confirm("Are you sure to open the side bar? Your data will be lost/erased.")) {
        // Redirect to "Pending For Drafting" page
        window.location.href = "clear_sessions.php";
    } else {
        // If user clicks Cancel, do nothing
        return false;
    }
});


var modal = document.getElementById("myModal");

// Get the <span> element that closes the modal
var span = document.getElementsByClassName("close")[0];

// Function to show the modal with custom text
function showPopup(text) {
    document.getElementById("modalText").innerText = text;
    modal.style.display = "block";
}

// When the user clicks on <span> (x), close the modal
span.onclick = function() {
    modal.style.display = "none";
}

// When the user clicks anywhere outside of the modal, close it
window.onclick = function(event) {
    if (event.target == modal) {
        modal.style.display = "none";
    }
}

function openGoogleMaps(location) {
            const baseUrl = "https://www.google.com/maps/search/?api=1&query=";
            window.open(baseUrl + encodeURIComponent(location), '_blank');
        }
function triggerFileInput2() {
            document.getElementById("imageInput").click();
        }

        document.getElementById("imageInput").addEventListener("change", function (event) {
            const files = event.target.files;
            const previewContainer = document.getElementById("imagePreviewContainer");

            // Clear previous previews
            previewContainer.innerHTML = "";

            // Display previews for each selected image
            Array.from(files).forEach((file) => {
                if (file.type.startsWith("image/")) {
                    const reader = new FileReader();
                    reader.onload = function (e) {
                        const img = document.createElement("img");
                        img.src = e.target.result;
                        previewContainer.appendChild(img);
                    };
                    reader.readAsDataURL(file);
                }
            });
        });
function triggerFileInput1() {
            document.getElementById("pdfInput").click();
        }

        // Handle file selection
        document.getElementById("pdfInput").addEventListener("change", function (event) {
            const file = event.target.files[0];
            if (file && file.type === "application/pdf") {
                // Create a FileReader instance
                const reader = new FileReader();

                // When the file is read successfully, open it in a new tab
                reader.onload = function (e) {
                    const pdfUrl = e.target.result;

                    // Try to open the PDF in a new tab using embed
                    const newTab = window.open();
                    if (newTab) {
                        newTab.document.write('<html><body><embed src="' + pdfUrl + '" type="application/pdf" width="100%" height="100%"></body></html>');
                        newTab.document.close();

                        // Fallback if the PDF does not load correctly
                        setTimeout(function() {
                            if (newTab.document.body.innerHTML === "") {
                                // Use PDF.js as a fallback to display the PDF
                                newTab.document.body.innerHTML = '<div id="pdf-container" style="width: 100%; height: 100%;"></div>';
                                const loadingTask = pdfjsLib.getDocument(pdfUrl);
                                loadingTask.promise.then(function(pdf) {
                                    pdf.getPage(1).then(function(page) {
                                        const scale = 1.5;
                                        const viewport = page.getViewport({ scale: scale });
                                        const canvas = document.createElement('canvas');
                                        const ctx = canvas.getContext('2d');
                                        canvas.height = viewport.height;
                                        canvas.width = viewport.width;
                                        document.getElementById('pdf-container').appendChild(canvas);

                                        // Render PDF page
                                        page.render({
                                            canvasContext: ctx,
                                            viewport: viewport
                                        });
                                    });
                                });
                            }
                        }, 1000); // Check if the embed failed after 1 second
                    }
                };

                // Read the file as a data URL
                reader.readAsDataURL(file);
            } else {
                alert("Please select a valid PDF file.");
            }
        });
</script>
</body>
</html>









 