<?php include('auth.php'); ?>
<?php



ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

// Increase PHP execution time and memory limit
ini_set('max_execution_time', 600); // Increase execution time to 600 seconds (10 minutes)
ini_set('memory_limit', '4096M'); // Increase memory limit to 4096MB
// Start session


// Database connection details
$servername = "localhost";
$username = "root";
  $password = "";
$dbname = "project_db";

// PDO connection for fetching data
try {
    $pdo = new PDO("mysql:host=$servername;dbname=$dbname", $username, $password);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

    // Fetch technical managers for dropdown
    $stmt = $pdo->prepare("SELECT technical_manager_id, name FROM technical_login");
    $stmt->execute();
    $managersResult = $stmt->fetchAll(PDO::FETCH_ASSOC);
} catch (PDOException $e) {
    die("Database Connection Error: " . $e->getMessage());
}

// MySQLi connection for form handling
$conn = new mysqli($servername, $username, $password, $dbname);
if ($conn->connect_error) {
    die("Database connection failed: " . $conn->connect_error);
}

// Get current reference_id
$reference_id = $_SESSION['reference_id'] ?? null;
if (!$reference_id) {
    die("Error: Reference ID is missing. Please ensure it is set in the session.");
}

// Get old_reference_id from mis table
$old_reference_id = null;
$stmt = $conn->prepare("SELECT old_reference_id FROM mis WHERE reference_id = ?");
$stmt->bind_param("s", $reference_id);
$stmt->execute();
$stmt->bind_result($old_reference_id);
$stmt->fetch();
$stmt->close();

// If old_reference_id exists and no session data set, fetch old remarks for display
if ($old_reference_id) {
    if (!isset($_SESSION['remarks_table']) && !isset($_POST['remarks_table'])) {
        $stmt = $conn->prepare("SELECT remarks, negative_remarks FROM remarks_table WHERE reference_id = ?");
        $stmt->bind_param("s", $old_reference_id);
        $stmt->execute();
        $stmt->bind_result($remarks_table, $negative_remarks);
        if ($stmt->fetch()) {
            $_SESSION['remarks_table'] = $remarks_table;
            $_SESSION['negative_remarks'] = $negative_remarks;
        }
        $stmt->close();
    }
}
// Handle POST form actions
if ($_SERVER["REQUEST_METHOD"] === "POST") {
    $action = $_POST['action'] ?? '';

    if ($action === "save") {
        $_SESSION['remarks_table'] = $_POST['remarks_table'] ?? "WRITE REMARKS HERE.....";
        $_SESSION['negative_remarks'] = $_POST['negative_remarks'] ?? "WRITE NEGATIVE REMARKS HERE.....";
        $message = "Data saved successfully on the webpage!";
    }

    if ($action === "submit") {

    // Check if reference_id exists in final_uploaded_images
    $checkStmt = $conn->prepare("SELECT id FROM final_uploaded_images WHERE reference_id = ?");
    $checkStmt->bind_param("s", $reference_id);
    $checkStmt->execute();
    $checkStmt->store_result();

    if ($checkStmt->num_rows == 0) {
        // If not found → insert a new row with this reference_id
        $checkStmt->close();
        $insertStmt = $conn->prepare("INSERT INTO final_uploaded_images (reference_id) VALUES (?)");
        $insertStmt->bind_param("s", $reference_id);
        $insertStmt->execute();
        $insertStmt->close();
    } else {
        $checkStmt->close();
    }

    // Proceed with existing logic
    if (isset($_SESSION['address_details'])) {
        $result = saveMandatoryDetailsToDatabase($_SESSION['address_details']);

        if (strpos($result, "Error:") === 0) {
            echo "<script>
                    alert(" . json_encode($result) . ");
                    window.location.href = 'REPORT2.php';
                  </script>";
            exit;
        } else {
           

            if (isset($_SESSION['bank_details'])) {
                saveBankDetailsToDatabase($_SESSION['bank_details']);
                unset($_SESSION['bank_details']);
            }
            if (isset($_SESSION['property_details'])) {
                saveGeneralDetailsToDatabase($_SESSION['property_details']);
                unset($_SESSION['property_details']);
            }
            if (isset($_SESSION['address_details'])) {
                saveAddressToDatabase($_SESSION['address_details']);
                unset($_SESSION['address_details']);
            }
            if (isset($_SESSION['critical_parameters'])) {
                savecriticalparametersDetailsToDatabase($_SESSION['critical_parameters']);
                unset($_SESSION['critical_parameters']);
            }
            if (isset($_SESSION['area_valuation'])) {
                saveAreaValuationToDatabase($_SESSION['area_valuation'], $pdo);
                unset($_SESSION['area_valuation']);
            }
            if (isset($_SESSION['floor_details'])) {
                saveFloorDetailsToDatabase($_SESSION['floor_details']);
                unset($_SESSION['floor_details']);
            }
            if (isset($_SESSION['technical_details'])) {
                saveTechnicalDetailsToDatabase($_SESSION['technical_details']);
                unset($_SESSION['technical_details']);
            }
        }
    }

    $remarks_table = $_SESSION['remarks_table'] ?? ($_POST['remarks_table'] ?? "WRITE REMARKS HERE.....");
    $negative_remarks = $_SESSION['negative_remarks'] ?? ($_POST['negative_remarks'] ?? "WRITE NEGATIVE REMARKS HERE.....");

    $stmt = $conn->prepare("SELECT id FROM remarks_table WHERE reference_id = ?");
    $stmt->bind_param("s", $reference_id);
    $stmt->execute();
    $stmt->store_result();

    if ($stmt->num_rows > 0) {
        $stmt->close();
        $stmt = $conn->prepare("UPDATE remarks_table SET remarks = ?, negative_remarks = ? WHERE reference_id = ?");
        $stmt->bind_param("sss", $remarks_table, $negative_remarks, $reference_id);
    } else {
        $stmt->close();
        $stmt = $conn->prepare("INSERT INTO remarks_table (reference_id, remarks, negative_remarks) VALUES (?, ?, ?)");
        $stmt->bind_param("sss", $reference_id, $remarks_table, $negative_remarks);
    }

    if ($stmt->execute()) {
        $stmt->close();

        $updateQuery = "UPDATE mis SET flag_report_preview = 1 WHERE reference_id = ?";
        $stmt = $conn->prepare($updateQuery);
        $stmt->bind_param("s", $reference_id);
        $stmt->execute();

        $formSessionKeys = [
            'bank_details', 'property_details', 'address_details',
            'critical_parameters', 'mandatory_details', 'area_valuation', 'axis_area_valuation',
            'floor_details', 'technical_details', 'remarks_table', 'negative_remarks'
        ];
        foreach ($formSessionKeys as $key) {
            unset($_SESSION[$key]);
        }
    } else {
        $message = "Error submitting data: " . $stmt->error;
    }

    $stmt->close();
}


}

// Function to save Bank Details to the database
function saveBankDetailsToDatabase($data) {
    global $conn; // Ensure the global $conn variable is used

    // SQL query to insert data into 'bank_details' table
    $sql = "INSERT INTO bank_details (reference_id, bankName, branchname, applicationNo, customerMob, customerName, caseType, visitType, address) 
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)";

    // Prepare the SQL statement
    $stmt = $conn->prepare($sql);

    // Check if the prepare statement failed
    if ($stmt === false) {
        $_SESSION['message'] = "Error preparing SQL statement: " . $conn->error;
        return; // Exit function on error
    }

    // Bind the parameters to the prepared statement
    $stmt->bind_param(
        "sssssssss", 
        $data['reference_id'],
        $data['bankName'],
        $data['branchname'],
        $data['applicationNo'],
        $data['customerMob'],
        $data['customerName'],
        $data['caseType'],
        $data['visitType'],
        $data['address']
    );

    // Execute the query
    if ($stmt->execute()) {
        $_SESSION['message'] = "Bank details saved successfully.";
    } else {
        $_SESSION['message'] = "Error executing query: " . $stmt->error;
    }

    // Close the statement
    $stmt->close();
}
function saveGeneralDetailsToDatabase($data) {
    global $conn;

    if (!$conn) {
        die("Error: Database connection is null.");
    }

    $columns = [
        'reference_id', 'project_approval_status', 'project_id', 'project_name', 'property_facing' ,  'community_dominated',
          'year_of_construction', 'age_of_property', 
        'residual_age_of_property', 'structurally_fit', 'approach_road_to_property', 
        'type_of_approach_road', 'width_of_approach_road', 'class_of_locality', 
        'surrounding_infrastructure',  'property_unit_type', 
        'occupancy_status', 'property_furnished_unfurnished', 'occupant_name', 'relation_of_occupant','occupied_since',
        'person_meet_at_site_contact', 'property_leasehold_freehold', 'demarcated_at_site', 
 'electric_meter_no', 'develop_percent',


 
 'electric_bill_no','relation_person_meet_at_site_contact','name_of_tenant','no_of_tenant','name_on_society_board',
 'transaction_type','property_lies_in_area','ratio_of_each_type','name_on_house_board','civic_amenities'

    ];

    $placeholders = implode(", ", array_fill(0, count($columns), '?'));
    $sql = "INSERT INTO property_details (" . implode(", ", $columns) . ") VALUES ($placeholders)";
    $stmt = $conn->prepare($sql);

    if ($stmt === false) {
        die("Error preparing SQL statement: " . $conn->error);
    }

    $params = [];
    $types = '';

    $numericColumns = ['year_of_construction', 'develop_percent'];

    foreach ($columns as $column) {
        $value = isset($data[$column]) ? trim($data[$column]) : null;
        $value = ($value === '') ? null : $value;
        
        if (in_array($column, $numericColumns)) {
            $params[] = ($value === null) ? null : (int)$value;
            $types .= 'i';
        } else {
            $params[] = $value;
            $types .= 's';
        }
    }

    $stmt->bind_param($types, ...$params);

    if ($stmt->execute()) {
        echo "General Details saved successfully.";
    } else {
        die("Error executing query: " . $stmt->error);
    }

    $stmt->close();
}

function saveAddressToDatabase($address_details) {
    global $conn;

    if (!$conn) {
        die("Error: Database connection is null.");
    }

    if (!isset($address_details['reference_id']) || empty($address_details['reference_id'])) {
        die("Error: Missing reference_id for update.");
    }

    // Define the columns to update
    $columns = [
      'reference_id', 'address_line_1_as_per_doc', 'address_line_2_as_per_doc', 
        'address_line_3_as_per_doc', 'address_line_4_as_per_doc',
        'landmark_1', 'landmark_2', 'pin_code', 
        

         'floor_no','no_of_wings','no_of_blocks',
                 'village_name',

        'direction_approved_north', 'direction_approved_south', 
        'direction_approved_east', 'direction_approved_west', 
        'direction_as_per_site_north', 'direction_as_per_site_south', 
        'direction_as_per_site_east', 'direction_as_per_site_west', 
        'direction_as_per_document_north', 'direction_as_per_document_south', 
        'direction_as_per_document_east', 'direction_as_per_document_west',

        'boundaries_matching', 'property_location_in', 'nearest_bus_stop_distance', 'nearest_bus_stop_name', 
        'nearest_railway_station_distance', 'nearest_railway_station_name', 
        'nearest_school_college_distance', 'nearest_hospital_distance',
        'property_identified_through', 
'distance_from_vendor_branch_kms', 
 
'nearest_national_highway_distance', 
'nearest_national_highway_name', 
'nearest_city_center_distance', 
'nearest_city_center_name', 
'nearest_airport_distance', 
'nearest_airport_name', 
'nearest_police_station_distance', 
'nearest_police_station_name', 
 
'nearest_post_office_name', 
'nearest_post_office_distance',
'address_matching', 
'if_not_matching_then', 
'municipal_authority_name', 
'taluka_tehsil', 
'street_name', 'nearest_school_college_name','nearest_hospital_name',
        'address_per_document','khasra_no'
    ];

    // Build SET part dynamically
    $setParts = [];
    foreach ($columns as $col) {
        $setParts[] = "$col=?";
    }

    $sql = "UPDATE address_details SET " . implode(", ", $setParts) . " WHERE reference_id=?";
    $stmt = $conn->prepare($sql);

    if ($stmt === false) {
        die("Error preparing SQL statement: " . $conn->error);
    }

    // Prepare values and types
    $params = [];
    $types  = '';

    foreach ($columns as $column) {
        $value = isset($address_details[$column]) ? trim($address_details[$column]) : null;
        $value = ($value === '') ? null : $value;
        $params[] = $value;
        $types .= 's';
    }

    // Add reference_id at the end (WHERE clause)
    $params[] = $address_details['reference_id'];
    $types .= 's';

    $stmt->bind_param($types, ...$params);

    if ($stmt->execute()) {
        echo "Address details updated successfully.";
    } else {
        die("Error executing UPDATE query: " . $stmt->error);
    }

    $stmt->close();
}


function saveCriticalParametersDetailsToDatabase($data) {
    global $conn;

    if (!$conn) {
        die("Error: Database connection is null.");
    }

    $columns = [
        'reference_id', 'zoning_development_plan', 'caution_area', 'failing_in_road_widening', 
        'within_50_mtrs_railway', 'near_high_tension', 'vertical_distance_from_line', 'presence_of_nala', 
        'current_property_usage', 'approved_property_usage', 'comment_on_location_risk', 'abutting_agriculture_land', 
        'seismic_zone', 'structure_type', 'costal_regulatory_zone', 'roof_type',
        'flooring_type','purpose_of_valuation','valuation_method_used','no_of_houses','population_of_village',
        'internal_visit_done','allocated_by_ro_bm','properties_250_meters','properties_500_meters','board_on_house',
        'vertical','corner_plot','registered_or_not','remarks_on_critical_params','habitation_1km',
        'property_configuration','rate_of_agriculture_land','nature_of_building','shape_of_building','fire_exit_available',
        'steel_grade','ground_slope_more_than_20','soil_liquefiable','soil_slope_vulnerable','flood_prone_area',
        'mortar_type','concrete_grade','expansion_joint_available','structural_system','environment_exposure_condition',
        'cyclone_zone_wind_speed','footing_type','projected_parts_available','soil_type','plan_aspect_ratio','soil_strata',
        'type_of_masonary','liquefiable','landslide','exposure_condition'
    ];

    $placeholders = implode(", ", array_fill(0, count($columns), '?'));
    $sql = "INSERT INTO critical_parameters (" . implode(", ", $columns) . ") VALUES ($placeholders)";
    $stmt = $conn->prepare($sql);

    if ($stmt === false) {
        die("Error preparing SQL statement: " . $conn->error);
    }

    $params = [];
    $types = '';

    // Define numeric columns explicitly
    $numericColumns = [
        'no_of_houses','population_of_village','ground_slope_more_than_20','cyclone_zone_wind_speed',
        'rate_of_agriculture_land'
    ];

    foreach ($columns as $column) {
        $value = isset($data[$column]) ? trim($data[$column]) : null;
        $value = ($value === '') ? null : $value;

        if (in_array($column, $numericColumns)) {
            $params[] = ($value === null) ? null : (int)$value;
            $types .= 'i';
        } else {
            $params[] = $value;
            $types .= 's';
        }
    }

    $stmt->bind_param($types, ...$params);

    if ($stmt->execute()) {
        echo "Critical Parameters Details saved successfully.";
    } else {
        die("Error executing query: " . $stmt->error);
    }

    $stmt->close();
}

function saveAreaValuationToDatabase($data, $pdo) {
     // 🔁 Ensure reference_id is set inside the data array
    if (empty($data['reference_id'])) {
        $data['reference_id'] = $_SESSION['reference_id'] ?? null;
    }

    if (empty($data['reference_id'])) {
        die("Missing reference_id. Cannot save data.");
    }
    // Columns to be inserted
    $columns = [
        'reference_id', 'propertyType','plot_square_feet', 'plot_rate', 
        'carpet_square_feet', 'carpet_rate', 'final_plot_square_feet',
        'final_plot_rate', 'final_construction_square_feet', 'final_construction_rate','finally_construction_valuation',
        'distress_value_percent', 'construction_square_feet', 'construction_rate',

'construction_name_1', 'construction_area_sqft_1', 'construction_rate_1', 'construction_valuation_1',
'construction_name_2', 'construction_area_sqft_2', 'construction_rate_2', 'construction_valuation_2',
'construction_name_3', 'construction_area_sqft_3', 'construction_rate_3', 'construction_valuation_3',


        'saleable_square_feet', 'saleable_rate', 'saleable_valuation',
        'actual_plot_square_feet', 'actual_plot_rate', 'actual_plot_valuation',
        'actual_carpet_square_feet', 'actual_carpet_rate', 'actual_carpet_valuation',
        'actual_construction_square_feet', 'actual_construction_rate', 'actual_construction_valuation',
        'actual_saleable_square_feet', 'actual_saleable_rate', 'actual_saleable_valuation',
        'enquiry_remarks','insurable_value', 'loading', 'dimension_as_per_site_north', 'dimension_as_per_site_south', 
        'dimension_as_per_site_east', 'dimension_as_per_site_west',
        'dimension_as_per_document_north', 'dimension_as_per_document_south', 
        'dimension_as_per_document_east', 'dimension_as_per_document_west',
        'car_parking_amount','car_parking',
        'addition_amenities_description_2', 'addition_amenities_amount_2',
        'addition_amenities_description_3', 'addition_amenities_amount_3',
        'addition_amenities_description_4', 'addition_amenities_amount_4',
        'total_valuation', 'final_area_square_feet', 'final_area_rate', 
        'total_valuation_words', 'distress_value_words', 'axis_plot_area', 'axis_plot_sanction', 'axis_plot_document', 'axis_plot_area_document',

        // Actual Built-up Area
        'axis_final_plot_square_feet', 'axis_ground_actual', 'axis_first_actual', 'axis_second_actual',
        'axis_3_actual', 'axis_4_actual', 'axis_other_actual',
        'axis_basement_floor1', 'axis_basement_floor2', 'axis_basement_floor3',

        // Built-up Area As Per Document
        'axis_total_area', 'axis_ground', 'axis_1_floor', 'axis_2_floor',
        'axis_3_floor', 'axis_4_floor', 'axis_other_floor',

        // Approved Built-up Area
        'axis_ground_approved_0', 'axis_ground_approved_1', 'axis_ground_approved_2',
        'axis_ground_approved_3', 'axis_ground_approved_4', 'axis_ground_approved_other',
        'axis_basement_approved_1', 'axis_basement_approved_2', 'axis_basement_approved_3',
        'axis_na_total_area',

        // Permissible Area
        'axis_permissible_area', 'axis_ground_permissible', 'axis_first_permissible',
        'axis_second_permissible', 'axis_third_permissible', 'axis_forth_permissible',
        'axis_other_permissible_floors', 'axis_basement_approved_4', 'axis_basement_approved_5',
        'axis_basement_approved_6',

        // Built-up Area Considered for Valuation
        'axis_total_considered_area', 'axis_ground_considered', 'axis_first_considered',
        'axis_second_considered', 'axis_third_considered', 'axis_forth_considered',
        'axis_other_considered_floors', 'axis_basement_approved_7', 'axis_basement_approved_8',
        'axis_basement_approved_9',
        'gross_monthly_rental', 'guideline_rate', 'replacement_cost',
        'gov_plot_area_sqft',
'gov_plot_area_rate',
'gov_plot_area_valuation',
'gov_construction_name1',
'gov_construction_area1',
'gov_construction_rate1',
'gov_construction_valuation1',
'gov_construction_name2',
'gov_construction_area2',
'gov_construction_rate2',
'gov_construction_valuation2',
'gov_construction_name3',
'gov_construction_area3',
'gov_construction_rate3',
'gov_construction_valuation3',
'gov_builtup_area_sqft',
'gov_builtup_area_rate',
'gov_builtup_area_valuation',
'gov_saleable_area_sqft',
'gov_saleable_area_rate',
'gov_saleable_area_valuation',
'gov_final_area_valuation',
'proposed_plot_area_sqft',
'proposed_plot_rate',
'proposed_plot_valuation',
'proposed_construction_name1',
'proposed_construction_area_sqft1',
'proposed_construction_rate1',
'proposed_construction_valuation1',
'proposed_construction_name2',
'proposed_construction_area_sqft2',
'proposed_construction_rate2',
'proposed_construction_valuation2',
'proposed_construction_name3',
'proposed_construction_area_sqft3',
'proposed_construction_rate3',
'proposed_construction_valuation3',
'proposed_builtup_area_sqft',
'proposed_builtup_rate',
'proposed_builtup_valuation',
'proposed_saleable_area_sqft',
'proposed_saleable_rate',
'proposed_saleable_valuation',
'proposed_final_area_valuation',
'estimated_cost_rs','estimated_cost_per_sqft',
'justified_estimated_cost_per_sqft','adoptable_justified_estimated_cost'
,'loading1','insurable_value_1','final_carpet_area_square_feet'

];

    // Generate placeholders for prepared statement
    $placeholders = implode(", ", array_fill(0, count($columns), '?'));
    $sql = "INSERT INTO area_valuation (" . implode(", ", $columns) . ") VALUES ($placeholders)";

    try {
        $stmt = $pdo->prepare($sql);

        // Bind values dynamically
        $params = [];
        foreach ($columns as $column) {
            $params[] = $data[$column] ?? null;
        }

        if ($stmt->execute($params)) {
            return true;
        }
    } catch (PDOException $e) {
        die("Database Insert Error: " . $e->getMessage());
    }

    return false;
} 
function saveFloorDetailsToDatabase($floor_details) {
    global $conn;

    if (!$conn) {
        die("Error: Database connection is null.");
    }

    // 🔁 Ensure reference_id is set inside the data array
    if (empty($floor_details['reference_id'])) {
        $floor_details['reference_id'] = $_SESSION['reference_id'] ?? null;
    }

    if (empty($floor_details['reference_id'])) {
        die("Missing reference_id. Cannot save data.");
    }

    // ✅ All columns for the floor_details table
    $columns = [
        'propertyType', 'reference_id', 'stage_construction_actual_present_completion',
        'stage_construction_recommend_present_completion', 'description_stage_construction_allotted',

        'plinth_present_completion', 'number_of_units_each_floor', 'number_of_lifts',
        'rcc_present_completion', 'brickwork_present_completion',

        'internal_plaster_present_completion', 'Present_quality_of_structure', 'total_actual_floors',
        'external_plaster_present_completion', 'area_total', 'total_approved_floors',

        'flooring_present_completion', 'plumbing_present_completion',
        'door_window_paint_present_completion', 'finishing_possession_present_completion',
        'total_completion_present', 'basements_remarks',

        'document_area_saledeed', 'actual_configuration_building', 'approved_configuration_building',

        // Ground Floor
        'ground_accommodation', 'ground_completed', 'ground_approved_area', 'ground_permissible_area',
        'ground_actual_area', 'ground_proposed_area', 'ground_rate', 'ground_valuation',

        // First Floor
        'first_accommodation', 'first_completed', 'first_approved_area', 'first_permissible_area',
        'first_actual_area', 'first_proposed_area', 'first_rate', 'first_valuation',

        // Second Floor
        'second_accommodation', 'second_completed', 'second_approved_area', 'second_permissible_area',
        'second_actual_area', 'second_proposed_area', 'second_rate', 'second_valuation',

        // Other Floors
        'other_accommodation', 'other_completed', 'other_approved_area', 'other_permissible_area',
        'other_actual_area', 'other_proposed_area', 'other_rate', 'other_valuation',

        // Total Floors
        'total_accommodation', 'total_completed', 'total_approved_area', 'total_permissible_area',
        'total_actual_area', 'total_proposed_area', 'total_rate', 'total_valuation',

        'plinth_completion_present', 'plinth_floors_completed',
        'rcc_completion_present', 'rcc_floors_completed',
        'brickwork_completion_present', 'brickwork_floors_completed',
        'internal_plaster_completion_present', 'internal_plaster_floors_completed',
        'external_plaster_completion_present', 'external_plaster_floors_completed',
        'flooring_completion_present', 'flooring_floors_completed',
        'painting_completion_present', 'painting_floors_completed',
        'plumbing_completion_present', 'plumbing_floors_completed',
        'fixtures_completion_present', 'fixtures_floors_completed',
        'foundation_completion_present', 'foundation_floors_completed',

        // Additional fields
        'total_completion_floors_completed',
        'old_stage_construction_allotted',
        'estimate_provided',
        'estimate_method',

        // Setbacks
        'front_as_per_plan', 'front_as_per_bye_laws', 'front_actual_site', 'front_extra_plan', 'front_extra_bye_laws',
        'site1_as_per_plan', 'site1_as_per_bye_laws', 'site1_actual_site', 'site1_extra_plan', 'site1_extra_bye_laws',
        'site2_as_per_plan', 'site2_as_per_bye_laws', 'site2_actual_site', 'site2_extra_plan', 'site2_extra_bye_laws',
        'rear_as_per_plan', 'rear_as_per_bye_laws', 'rear_actual_site', 'rear_extra_plan', 'rear_extra_bye_laws',

        // Floors Info
        'basement_approved', 'basement_actual_planned', 'basement_remarks',
        'number_ground_approved', 'ground_actual_planned', 'number_ground_remarks',
        'number_first_approved', 'first_actual_planned', 'number_first_remarks',
        'number_second_approved', 'second_actual_planned', 'number_second_remarks',
        'number_third_approved', 'third_actual_planned', 'number_third_remarks','number_of_units_building',
        'total_floors_approved', 'total_floors_actual_planned', 'total_number_floors_remarks','progress_remarks'
    ];

    // ✅ Numeric columns
    $numericColumns = [
        'stage_construction_actual_present_completion',
        'stage_construction_recommend_present_completion', 'total_approved_floors',

        'plinth_present_completion', 'number_of_units_each_floor', 'number_of_lifts',
        'rcc_present_completion', 'brickwork_present_completion',
        'internal_plaster_present_completion', 'external_plaster_present_completion',

        

        'flooring_present_completion', 'plumbing_present_completion',
        'door_window_paint_present_completion', 'finishing_possession_present_completion',
        'total_completion_present', 'area_total',

        'ground_completed', 'ground_approved_area', 'ground_permissible_area', 'ground_actual_area', 'ground_proposed_area', 'ground_rate', 'ground_valuation',
        'first_completed', 'first_approved_area', 'first_permissible_area', 'first_actual_area', 'first_proposed_area', 'first_rate', 'first_valuation',
        'second_completed', 'second_approved_area', 'second_permissible_area', 'second_actual_area', 'second_proposed_area', 'second_rate', 'second_valuation',
        'other_completed', 'other_approved_area', 'other_permissible_area', 'other_actual_area', 'other_proposed_area', 'other_rate', 'other_valuation',
        'total_completed', 'total_approved_area', 'total_permissible_area', 'total_actual_area', 'total_proposed_area', 'total_rate', 'total_valuation',

        'plinth_completion_present', 'plinth_floors_completed',
        'rcc_completion_present', 'rcc_floors_completed',
        'brickwork_completion_present', 'brickwork_floors_completed',
        'internal_plaster_completion_present', 'internal_plaster_floors_completed',
        'external_plaster_completion_present', 'external_plaster_floors_completed',
        'flooring_completion_present', 'flooring_floors_completed',
        'painting_completion_present', 'painting_floors_completed',
        'plumbing_completion_present', 'plumbing_floors_completed',
        'fixtures_completion_present', 'fixtures_floors_completed',
        'foundation_completion_present', 'foundation_floors_completed',

        // Additional numeric-like fields
        'Present_quality_of_structure',
        'total_completion_floors_completed',
        'old_stage_construction_allotted',
        'estimate_provided',
        'estimate_method',

        // Setbacks
        'front_as_per_plan', 'front_as_per_bye_laws', 'front_actual_site', 'front_extra_plan', 'front_extra_bye_laws',
        'site1_as_per_plan', 'site1_as_per_bye_laws', 'site1_actual_site', 'site1_extra_plan', 'site1_extra_bye_laws',
        'site2_as_per_plan', 'site2_as_per_bye_laws', 'site2_actual_site', 'site2_extra_plan', 'site2_extra_bye_laws',
        'rear_as_per_plan', 'rear_as_per_bye_laws', 'rear_actual_site', 'rear_extra_plan', 'rear_extra_bye_laws',

        // Floors Info
        'basement_approved', 'basement_actual_planned',
        'number_ground_approved', 'ground_actual_planned',
        'number_first_approved', 'first_actual_planned',
        'number_second_approved', 'second_actual_planned',
        'number_third_approved', 'third_actual_planned',
        'total_floors_approved', 'total_floors_actual_planned','number_of_units_building'
    ];

    // Create placeholders
    $placeholders = implode(", ", array_fill(0, count($columns), '?'));

    // Prepare SQL query
    $sql = "INSERT INTO floor_details (" . implode(", ", $columns) . ") VALUES ($placeholders)";
    $stmt = $conn->prepare($sql);

    if ($stmt === false) {
        die("Error preparing SQL statement: " . $conn->error);
    }

    // Prepare the data for binding
    $params = [];
    $types = '';

    foreach ($columns as $column) {
        $value = isset($floor_details[$column]) ? trim((string)$floor_details[$column]) : null;
        $value = ($value === '') ? null : $value;

        if (in_array($column, $numericColumns, true)) {
            $params[] = ($value === null) ? null : (float)$value;
            $types .= 'd';
        } else {
            $params[] = $value;
            $types .= 's';
        }
    }

    // ✅ bind_param requires variables by reference
    $bindNames[] = $types;
    foreach ($params as $key => $val) {
        $bindNames[] = &$params[$key];
    }

    call_user_func_array([$stmt, 'bind_param'], $bindNames);

    if ($stmt->execute()) {
        echo "✅ Floor details saved successfully.";
    } else {
        die("❌ Error executing query: " . $stmt->error);
    }

    $stmt->close();
}

function saveTechnicalDetailsToDatabase($data) {
    global $conn;

    if (!$conn) {
        die("Error: Database connection is null.");
    }

    $columns = [
        'reference_id', 'positive_report', 'markebility',
        'demolition_risk_1', 'owner_name', 'seller_name',
        'fsi_deviation', 'vertical_deviation', 'fsi_far_deviation', 'seller_type',

        'map_available','sanction_approving_authority','sanction_approval_no','sanction_approval_date',
        'layout_applicable','layout_approving_authority','layout_approval_details','layout_approval_date',
        'completion_certificate','completion_approving_authority','completion_approval_details','completion_approval_date',
        'occupancy_certificate','occupancy_approving_authority','occupancy_approval_details','occupancy_approval_date',
        'na_permission_details','na_approving_authority','na_approval_details','na_approval_date',
        'rera_details','rera_approving_authority','rera_approval_details','rera_approval_date',
        'lease_details','lease_approving_authority','lease_approval_details','lease_approval_date',
        'ownership1_approving_authority', 'ownership1_no','ownership1_date',
        'ownership2_approving_authority', 'ownership2_no','ownership2_date','ownership1_details','ownership2_details',
        'ownership3_approving_authority','ownership3_details','ownership3_no','ownership3_date',
        'ownership4_approving_authority','ownership4_details','ownership4_no','ownership4_date',
        'list_documents'
    ];

    $placeholders = implode(", ", array_fill(0, count($columns), '?'));
    $sql = "INSERT INTO technical_details (" . implode(", ", $columns) . ") VALUES ($placeholders)";
    $stmt = $conn->prepare($sql);

    if ($stmt === false) {
        die("Error preparing SQL statement: " . $conn->error);
    }

    $params = [];
    $types = '';

    // Define numeric columns (adjust as per schema)
    $numericColumns = ['fsi_deviation', 'vertical_deviation', 'fsi_far_deviation'];

    foreach ($columns as $column) {
        $value = isset($data[$column]) ? trim($data[$column]) : null;
        $value = ($value === '') ? null : $value;

        if (in_array($column, $numericColumns)) {
            $params[] = ($value === null) ? null : (float)$value;
            $types .= 'd'; // decimals for numeric values
        } else {
            $params[] = $value;
            $types .= 's';
        }
    }

    $stmt->bind_param($types, ...$params);

    if ($stmt->execute()) {
        echo "Technical details saved successfully.";
    } else {
        die("Error executing query: " . $stmt->error);
    }

    $stmt->close();
}
function saveMandatoryDetailsToDatabase($data) {
    global $conn;

    if (!$conn) {
        return "Error: Database connection is null.";
    }

 
    // Define mandatory fields
    $address_details = [
        'address_per_site'   => "Billing Address per Site",
        'latitude_value'          => "Bill Latitude",
        'longitude_value'         => "Bill Longitude",
        'nearest_branch_location'    => "Name of Nearest Branch Location",
        'distance_from_branch_kms' =>"Distance From Branch Location (KMS)",

        'bill_property_type'     => "Bill Property Type"
    ];

    // Check all mandatory fields
    foreach ($address_details as $field => $label) {
        if (!isset($data[$field]) || trim($data[$field]) === '') {
            return "Error: '$label' is mandatory.";
        }
        // Special check for numeric fields
        if (in_array($field, ['latitude_value', 'longitude_value']) && !is_numeric($data[$field])) {
            return "Error: '$label' must be a valid number.";
        }
    }

    // ✅ If we reach here → all mandatory fields are filled
    $columns = array_keys($address_details);
    array_unshift($columns, 'reference_id'); // add reference_id at start

    $placeholders = implode(", ", array_fill(0, count($columns), '?'));
    $sql = "INSERT INTO address_details (" . implode(", ", $columns) . ") VALUES ($placeholders)";
    $stmt = $conn->prepare($sql);

    if ($stmt === false) {
        return "Error preparing SQL statement: " . $conn->error;
    }

    $params = [];
    $types = '';

    foreach ($columns as $column) {
        $value = isset($data[$column]) ? trim($data[$column]) : null;
        $value = ($value === '') ? null : $value;

        if (in_array($column, ['latitude_value', 'longitude_value'])) {
            $params[] = ($value === null) ? null : (float)$value;
            $types .= 'd';
        } else {
            $params[] = $value;
            $types .= 's';
        }
    }

    $stmt->bind_param($types, ...$params);

    if ($stmt->execute()) {
        return "Mandatory Details saved successfully.";
    } else {
        return "Error executing query: " . $stmt->error;
    }
}
?>


<!-- JavaScript for alert and redirect -->
<script>
    <?php if (isset($_POST['action']) && $_POST['action'] == 'submit'): ?>
        alert("Form submitted successfully.");
        window.location.href = "Pending_Report.php";  // Redirect to Pending_Report.php after the alert
    <?php endif; ?>
</script>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Property Details Form</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
    <link rel="shortcut icon" href="favicon.ico" type="image/x-icon">
    <!-- <link rel="stylesheet" href="REPORT012.css"> -->
       <style>
        /* Loader Overlay */
        #loaderOverlay {
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background-color: rgba(255, 255, 255, 0.95);
            z-index: 9999;
            display: flex;
            justify-content: center;
            align-items: center;
            font-size: 2em;
            color: #333;
        }

        /* Optional: Prevent scrolling while loading */
        body.loading {
            overflow: hidden;
        }

        /* Dim all content when loading */
        #mainContent {
            pointer-events: none; /* Disable interaction */
            opacity: 0.5;
        }

        body:not(.loading) #mainContent {
            pointer-events: auto;
            opacity: 1;
        }
        .section {
    /* border-top: 2px solid #2f7cab; */
    padding: 10px 20px;
    margin-top: 3.7%;
}

.section:first-child {
    border-top: none;
}

* {
    margin: 0;
    padding: 0;
    box-sizing: border-box;
    font-family: Arial, sans-serif;
}

body {
    background-color: #f4f8fb;
    min-height: 100%;
    padding-top: 110px;
    /* padding: 20px; */
    position: relative;
}

.form-container {
    width: 100%;
    max-width: 100%;
    margin: 0 auto;
    display: flex;
    flex-direction: column;
    gap: 10px;
}

/* Styling the scrollbar for the entire page */
::-webkit-scrollbar {
    width: 12px;
    /* Width of the vertical scrollbar */
    height: 10px;
    /* Height of horizontal scrollbar */
}

/* Styling the scrollbar track */
::-webkit-scrollbar-track {
    background: linear-gradient(135deg, #f0f0f0, #e0e0e0);
    /* Light gradient track */
    border-radius: 10px;
    /* Rounded corners */
    box-shadow: inset 0 0 10px rgba(0, 0, 0, 0.1);
    /* Subtle shadow */
}

/* Styling the scrollbar thumb (the draggable part) */
::-webkit-scrollbar-thumb {
    background: linear-gradient(135deg, #2f7cab, #0056b3);
    /* Gradient thumb */
    border-radius: 10px;
    /* Rounded corners */
    border: 3px solid transparent;
    /* Add space around thumb */
    background-clip: content-box;
    /* Ensures the thumb’s background doesn’t overlap the border */
    transition: background 0.3s ease, transform 0.3s ease;
    /* Smooth transition for hover */
}

/* Hover effect for the scrollbar thumb */
::-webkit-scrollbar-thumb:hover {
    background: linear-gradient(135deg, #0056b3, #003d80);
    /* Darker gradient on hover */
    transform: scale(1.1);
    /* Slightly enlarge the thumb */
}

/* Styling the horizontal scrollbar */
::-webkit-scrollbar-horizontal {
    height: 8px;
}

/* Styling the horizontal scrollbar track */
::-webkit-scrollbar-track-horizontal {
    background: linear-gradient(135deg, #f0f0f0, #e0e0e0);
    /* Light gradient track */
    border-radius: 10px;
    box-shadow: inset 0 0 10px rgba(0, 0, 0, 0.1);
}

/* Styling the horizontal scrollbar thumb */
::-webkit-scrollbar-thumb-horizontal {
    background: linear-gradient(135deg, #2f7cab, #0056b3);
    border-radius: 10px;
    border: 3px solid transparent;
    background-clip: content-box;
    transition: background 0.3s ease, transform 0.3s ease;
}

/* Hover effect for horizontal scrollbar thumb */
::-webkit-scrollbar-thumb-horizontal:hover {
    background: linear-gradient(135deg, #0056b3, #003d80);
    transform: scale(1.1);
    /* Slightly enlarge the thumb */
}

/* -------------------------------
   Header
-------------------------------- */
.header {
  background: linear-gradient(90deg, #6a11cb, #2575fc);
  color: #fff;
  padding: 16px;
  text-align: center;
  font-size: 1.8rem;
  font-weight: 700;
  letter-spacing: 1px;
  border-bottom: 4px solid #fff;
  box-shadow: 0 4px 15px rgba(0,0,0,0.2);
  text-transform: uppercase;
}

/* Main Content Styling */
form {
    width: 100%;
}

/* Enhanced Submit Button */
.submit-button {
  display: flex;
  gap:20px;
  justify-content: center;
  margin: 40px 0;
  perspective: 1000px;
}

/* Button styling */
.submit-button button,
.submit-button input[type="submit"] {
  background: linear-gradient(135deg, #6a11cb 0%, #2575fc 100%);
  background-size: 200% 200%;
  border: none;
  padding: 8px 25px;
  border-radius: 999px;
  color: #fff;
  font-size: 20px;
  cursor: pointer;
  font-weight: 800;
  letter-spacing: 0.5px;
  box-shadow: 0 12px 30px rgba(106, 17, 203, 0.35),
              0 6px 15px rgba(37, 117, 252, 0.25);
  transition: all 0.5s cubic-bezier(0.25, 1, 0.5, 1);
  animation: gradientMove 4s ease infinite, float 6s ease-in-out infinite;
  position: relative;
  overflow: hidden;
  outline: none;
  -webkit-tap-highlight-color: transparent;
  transform-style: preserve-3d;
  text-transform: uppercase;
}

/* Shimmer highlight effect */
.submit-button button::before {
  content: "";
  position: absolute;
  top: -50%;
  left: -50%;
  width: 120%;
  height: 120%;
  background: linear-gradient(
    60deg, 
    rgba(255,255,255,0) 0%, 
    rgba(255,255,255,0.15) 50%, 
    rgba(255,255,255,0) 100%
  );
  transform: rotate(25deg) translateX(-100%);
  transition: transform 1.2s cubic-bezier(0.23, 1, 0.32, 1);
  pointer-events: none;
}

/* Hover effects */
.submit-button button:hover {
  transform: translateY(-8px) scale(1.08) rotateX(10deg);
  box-shadow: 0 25px 50px rgba(106, 17, 203, 0.45),
              0 15px 30px rgba(37, 117, 252, 0.35),
              0 0 40px rgba(255, 255, 255, 0.2);
  filter: brightness(1.15) saturate(1.2);
  letter-spacing: 1px;
}

.submit-button button:hover::before {
  transform: rotate(25deg) translateX(100%);
}

/* Active (press) effect */
.submit-button button:active {
  transform: translateY(-2px) scale(0.98);
  box-shadow: 0 8px 20px rgba(106, 17, 203, 0.3);
  transition: all 0.1s ease;
}

/* Pulsing glow effect */
.submit-button button::after {
  content: "";
  position: absolute;
  inset: -4px;
  border-radius: 999px;
  background: linear-gradient(135deg, #6a11cb, #2575fc, #9d7cc1, #5d7aac);
  background-size: 300% 300%;
  z-index: -1;
  filter: blur(12px);
  opacity: 0.7;
  animation: gradientMove 5s ease infinite, pulse 3s ease infinite;
  pointer-events: none;
}

/* Sparkle particles */
.submit-button .sparkle {
  position: absolute;
  width: 4px;
  height: 4px;
  background: white;
  border-radius: 50%;
  pointer-events: none;
  opacity: 0;
  animation: sparkle 1.5s linear infinite;
}

/* Floating Side Buttons */
.side-buttons {
    position: fixed;
    top: 20%;
    right: 20px;
    display: flex;
    flex-direction: column;
    gap: 10px;
    z-index: 1000;
}

.side-buttons button {
    background-color: #2f7cab;
    border: none;
    padding: 10px;
    cursor: pointer;
    border-radius: 50%;
    width: 50px;
    height: 50px;
    display: flex;
    align-items: center;
    justify-content: center;
    transition: background-color 0.3s;
}

.side-buttons button img {
    width: 24px;
    height: 24px;
    filter: invert();
}

.side-buttons button:hover {
    background-color: #0056b3;
}

@media (max-width: 768px) {
    .side-buttons {
        top: 15%;
        right: 10px;
    }

    .tab-links {
        flex-wrap: wrap;
    }
}

@media (max-width: 480px) {
    .tab-links button {
        padding: 8px 10px;
    }

    .header {
        font-size: 16px;
    }

    td {
        font-size: 14px;
    }

    input[type="text"] {
        font-size: 14px;
    }

    .side-buttons {
        top: 10%;
        right: 5px;
    }
}

.image-preview-container {
    display: flex;
    flex-wrap: wrap;
    gap: 10px;
    margin-top: 20px;
    background-color: #f8f9fa;
    border: 2px dashed #dcdcdc;
    padding: 10px;
    border-radius: 8px;
    /* justify-content: center; */
    align-items: center;
    text-align: center;
}

.image-preview-container p {
    color: #888;
    font-size: 14px;
}

.image-preview-container.hidden {
    display: none;
}

/* File input trigger button styling */
.side-buttons button {
    background-color: #2f7cab;
    border: none;
    padding: 10px;
    cursor: pointer;
    border-radius: 50%;
    width: 50px;
    height: 50px;
    display: flex;
    align-items: center;
    justify-content: center;
    transition: background-color 0.3s;
}

.valuation-table {
    width: 100%;
    border-collapse: collapse;
    margin-bottom: 20px;
    font-size: 12px;
    margin-top: -1.1%;
}

.valuation-table th,
.valuation-table td {
    border: 1px solid #333;
    padding: 8px;
    text-align: center;
}

.valuation-table th {
    background-color: #2f7cab;
    color: white;
    font-weight: bold;
}

.valuation-table tr:nth-child(odd) td {
    background-color: #e9f5fb;
}

.valuation-table td {
    background-color: #fff;
    font-weight: normal;
}

.section {
    width: 100%;
    /* border-top: 2px solid #2f7cab; */
    /* padding: 10px 20px; */
    /* margin-top: 3.7%; */
}

.section:first-child {
    border-top: none;
}



ul {
    list-style: none;
    padding: 0;
}

li {
    margin: 5px 0;
    font-size: 13px;
    line-height: 1.6;
}

.section {
    /* border-top: 2px solid #2f7cab; */
    padding: 10px 20px;
    margin-top: 3.7%;
}

.section:first-child {
    border-top: none;
}

* {
    margin: 0;
    padding: 0;
    box-sizing: border-box;
    font-family: Arial, sans-serif;
}

body {
    background-color: #f4f8fb;
    min-height: 100%;
    /* padding: 20px; */
    position: relative;
}

.form-container {
    width: 100%;
    max-width: 100%;
    margin: 0 auto;
    display: flex;
    flex-direction: column;
    gap: 10px;
}


/* Styling the scrollbar for the entire page */
::-webkit-scrollbar {
    width: 12px;
    /* Width of the vertical scrollbar */
    height: 10px;
    /* Height of horizontal scrollbar */
}

/* Styling the scrollbar track */
::-webkit-scrollbar-track {
    background: linear-gradient(135deg, #f0f0f0, #e0e0e0);
    /* Light gradient track */
    border-radius: 10px;
    /* Rounded corners */
    box-shadow: inset 0 0 10px rgba(0, 0, 0, 0.1);
    /* Subtle shadow */
}

/* Styling the scrollbar thumb (the draggable part) */
::-webkit-scrollbar-thumb {
    background: linear-gradient(135deg, #2f7cab, #0056b3);
    /* Gradient thumb */
    border-radius: 10px;
    /* Rounded corners */
    border: 3px solid transparent;
    /* Add space around thumb */
    background-clip: content-box;
    /* Ensures the thumb’s background doesn’t overlap the border */
    transition: background 0.3s ease, transform 0.3s ease;
    /* Smooth transition for hover */
}

/* Hover effect for the scrollbar thumb */
::-webkit-scrollbar-thumb:hover {
    background: linear-gradient(135deg, #0056b3, #003d80);
    /* Darker gradient on hover */
    transform: scale(1.1);
    /* Slightly enlarge the thumb */
}

/* Styling the horizontal scrollbar */
::-webkit-scrollbar-horizontal {
    height: 8px;
}

/* Styling the horizontal scrollbar track */
::-webkit-scrollbar-track-horizontal {
    background: linear-gradient(135deg, #f0f0f0, #e0e0e0);
    /* Light gradient track */
    border-radius: 10px;
    box-shadow: inset 0 0 10px rgba(0, 0, 0, 0.1);
}

/* Styling the horizontal scrollbar thumb */
::-webkit-scrollbar-thumb-horizontal {
    background: linear-gradient(135deg, #2f7cab, #0056b3);
    border-radius: 10px;
    border: 3px solid transparent;
    background-clip: content-box;
    transition: background 0.3s ease, transform 0.3s ease;
}

/* Hover effect for horizontal scrollbar thumb */
::-webkit-scrollbar-thumb-horizontal:hover {
    background: linear-gradient(135deg, #0056b3, #003d80);
    transform: scale(1.1);
    /* Slightly enlarge the thumb */
}


/* Main Content Styling */
form {
    width: 100%;
}

/* -------------------------------
   Forms + Tables
-------------------------------- */
table {
  width: 100%;
  border-collapse: collapse;
  margin: 10px 0;
}

td {
  padding: 10px;
  vertical-align: middle;
  transition: background 0.3s;
}

td:nth-child(odd) {
  background: #f0f8ff;
  font-weight: 600;
  color: #2c3e50;
}

td:nth-child(even) {
  background: #ffffff;
}

input[type="text"] {
  width: 100%;
  padding: 8px 12px;
  border: 1px solid #ddd;
  border-radius: 8px;
  transition: border-color 0.3s, box-shadow 0.3s;
}

input[type="text"]:focus {
  border-color: #6a11cb;
  box-shadow: 0 0 6px rgba(106, 17, 203, 0.4);
  outline: none;
}
/* Floating Side Buttons */
.side-buttons {
    position: fixed;
    top: 20%;
    right: 20px;
    display: flex;
    flex-direction: column;
    gap: 10px;
    z-index: 1000;
}

.side-buttons button {
    background-color: #2f7cab;
    border: none;
    padding: 10px;
    cursor: pointer;
    border-radius: 50%;
    width: 50px;
    height: 50px;
    display: flex;
    align-items: center;
    justify-content: center;
    transition: background-color 0.3s;
}

.side-buttons button img {
    width: 24px;
    height: 24px;
    filter: invert();
}

.side-buttons button:hover {
    background-color: #0056b3;
}

@media (max-width: 768px) {
    .side-buttons {
        top: 15%;
        right: 10px;
    }

    .tab-links {
        flex-wrap: wrap;
    }
}

@media (max-width: 480px) {
    .tab-links button {
        padding: 8px 10px;
    }

    .header {
        font-size: 16px;
    }

    td {
        font-size: 14px;
    }

    input[type="text"] {
        font-size: 14px;
    }

    .side-buttons {
        top: 10%;
        right: 5px;
    }
}

.image-preview-container {
    display: flex;
    flex-wrap: wrap;
    gap: 10px;
    margin-top: 20px;
    background-color: #f8f9fa;
    border: 2px dashed #dcdcdc;
    padding: 10px;
    border-radius: 8px;
    /* justify-content: center; */
    align-items: center;
    text-align: center;
}

.image-preview-container p {
    color: #888;
    font-size: 14px;
}

.image-preview-container.hidden {
    display: none;
}

/* File input trigger button styling */
.side-buttons button {
    background-color: #2f7cab;
    border: none;
    padding: 10px;
    cursor: pointer;
    border-radius: 50%;
    width: 50px;
    height: 50px;
    display: flex;
    align-items: center;
    justify-content: center;
    transition: background-color 0.3s;
}

.valuation-table {
    width: 100%;
    border-collapse: collapse;
    margin-bottom: 20px;
    font-size: 12px;
    margin-top: -1.1%;
}

.valuation-table th,
.valuation-table td {
    border: 1px solid #333;
    padding: 8px;
    text-align: center;
}

.valuation-table th {
    background-color: #2f7cab;
    color: white;
    font-weight: bold;
}

.valuation-table tr:nth-child(odd) td {
    background-color: #e9f5fb;
}

.valuation-table td {
    background-color: #fff;
    font-weight: normal;
}

.section {
    width: 100%;
    /* border-top: 2px solid #2f7cab; */
    /* padding: 10px 20px; */
    /* margin-top: 3.7%; */
}

.section:first-child {
    border-top: none;
}

h2 {
    font-size: 15px;
    margin-bottom:10px;
    /* border-radius: 5px; */
    background-color: #2f7cab;
    color: #ffffff;
    text-align:center;
    font-weight:900;
    padding: 10px;
    /* margin:auto; */
}

ul {
    list-style: none;
    padding: 0;
}

li {
    margin: 5px 0;
    font-size: 13px;
    line-height: 1.6;
}

.rotating-text {
    color: black;
    perspective: 1000px;
    /* Adds a 3D perspective effect */
    font-size: 1.5rem;
    font-weight: bold;
    font-style: italic;
    width: 100%;
    animation: rotate360 3s linear infinite;
    display: inline-block;
    margin-bottom: 10px;
    transform-origin: center center;
    /* Rotates around its center */
    text-align: center;
    /* margin-left:20px; */
    text-shadow:
        1px 1px 2px rgba(235, 244, 243, 0.97),
        2px 2px 4px rgba(246, 242, 242, 0.4),
        3px 3px 6px rgba(249, 252, 252, 0.89),
        4px 4px 8px rgba(248, 242, 247, 0.93),
        5px 5px 10px rgba(232, 236, 237, 0.4);
}

/* Keyframes for rotating the text */
@keyframes rotate360 {
    0% {
        transform: rotateY(0deg);
        /* Starts with no rotation */
    }

    50% {
        transform: rotateY(0deg);
        /* Half rotation */
    }

    100% {
        transform: rotateY(360deg);
        /* Full rotation */
    }
}

.logo {
    /* width: 50px; */
    height: 83px;
    padding: 12px;
    padding-bottom: 33px;

}

#sidebar {
    background: #B0C4DE;
    /* Light Steel Blue */
    color: #2C3E50;
    position: fixed;
    left: -250px;
    top: 0;
    width: 250px;
    height: 100%;
    /* background-color: #111; */
    color: white;
    transition: left 0.3s ease;
    padding: 20px;
}

#sidebar.active {
    left: 35px;
    /* background:grey; */
}

.sidebar {
    width: 250px;
    background: #B0C4DE;
    /* Light Steel Blue */
    /* background:rgba(245, 245, 245, 0.37); Light Steel Blue */
    color: black;
    /* Dark Grayish Blue */
    padding: 20px;
    height: 100vh;
    position: fixed;
    left: 0;
    top: 0;
    z-index: 1000;
    transition: transform 0.3s ease-in-out;
}

.sidebar.hidden {
    transform: translateX(-100%);
}

.sidebar h1 {
    font-size: 20px;
    margin-top: 10px;
    margin-bottom: 20px;
    color: #2C3E50;
}

.sidebar a {
    padding: 15px 20px;
    margin: 10px 0;
    text-decoration: none;
    color: #2C3E50;
    /* Dark Grayish Blue */
    font-size: 16px;
    font-style: italic;
    font-weight: 500;
    margin-bottom: 70px;
    border-radius: 5px;
    transition: all 0.3s ease;
    display: flex;
    align-items: center;
}

.sidebar a:hover,
.sidebar a.active {
    background: #4A90E2;
    /* Light Blue */
    transform: translateX(10px);
    color: white;
}

.sidebar a .icon {
    margin-right: 15px;
    font-size: 18px;
}

/* Toggle Button */
#toggleSidebar {
    border-radius: 20%;
    position: fixed;
    top: 0px;
    /* Adjusted for better placement */
    left: 0px;
    /* Adjusted for better placement */
    z-index: 1000;
    background-color: rgb(130, 183, 226);
    color: white;
    border: none;
    padding: 6px 12px;
    /* Added padding for a more clickable area */
    cursor: pointer;
    box-shadow: 0 4px 8px rgba(0, 0, 0, 0.7);
    /* Adds a soft shadow for depth */
    transition: all 0.3s ease;
    /* Smooth transition for hover and active states */
}

/* Button hover effect */
#toggleSidebar:hover {
    background-color: #1c6abf;
    /* Slightly darker shade on hover */
    transform: scale(1);
    /* Slightly enlarges the button for a professional hover effect */
    box-shadow: 0 6px 12px rgba(0, 0, 0, 0.3);
    /* Stronger shadow on hover */
}

/* Active state for the button */
#toggleSidebar.active {
    background-color: #1a4f82;
    /* Darker shade for active state */
    transform: rotate(180deg);
    /* Smooth rotate effect when the sidebar is active */
}

/* Button icon (if you use an icon inside the button) */
#toggleSidebar i {
    font-size: 18px;
    /* Adjust the icon size */
    transition: transform 0.3s ease;
    /* Smooth transition when rotating */
}

.watch-icon {
    margin-right: 16px;
    /* Adds space between the search text and the watch icon */
    color: #555;
    /* Optional: sets the color of the watch icon */
}

#toggleSidebar {
    border-radius: 20%;
    position: fixed;
    top: 0px;
    /* Adjust for better placement */
    /* right: -35px; Position it just outside the sidebar */
    z-index: 1001;
    background-color: rgb(130, 183, 226);
    color: white;
    border: none;
    padding: 6px 12px;
    cursor: pointer;
    box-shadow: 0 4px 8px rgba(0, 0, 0, 0.7);
    transition: all 0.3s ease;
}

/* Button hover effect */
#toggleSidebar:hover {
    background-color: #1c6abf;
    box-shadow: 0 6px 12px rgba(0, 0, 0, 0.3);
}

/* Active state for the button */
#toggleSidebar.active {
    background-color: #1a4f82;
    transform: rotate(180deg);
    /* Smooth 180-degree rotation */
    box-shadow: 0 6px 12px rgba(0, 0, 0, 0.5);
}

/* Sidebar */
#sidebar.active+#toggleSidebar {
    right: 250px;
    /* Adjust so button moves into view */
}

/* Sidebar when active */
#sidebar.active {
    left: 0px;
}

/* Sidebar hidden state */
#sidebar {
    position: fixed;
    left: -250px;
    top: 0;
    width: 250px;
    height: 100%;
    background: #B0C4DE;
    color: white;
    transition: left 0.3s ease;
}

#pdf-container {
    width: 100%;
    height: 100%;
    overflow: auto;
}

canvas {
    display: block;
    margin: 0 auto;
}

/* Modal background */
/* Modal background */
.modal {
    display: none;
    /* Hidden by default */
    position: fixed;
    /* Stay in place */
    z-index: 1;
    /* Sit on top */
    left: 0;
    top: 0;
    width: 100%;
    /* Full width */
    height: 100%;
    /* Full height */
    overflow: auto;
    /* Enable scroll if needed */
    background-color: rgba(0, 0, 0, 0.6);
    /* Slightly darker overlay for a more professional look */
    animation: fadeIn 0.6s ease-out;
    /* Smooth fade-in effect */
}

/* Modal Content */
.modal {
    display: none;
    /* Hidden by default */
    position: fixed;
    /* Stay in place */
    z-index: 1;
    /* Sit on top */
    left: 0;
    top: 0;
    width: 100%;
    /* Full width */
    height: 100%;
    /* Full height */
    overflow: auto;
    /* Enable scroll if needed */
    background-color: rgba(0, 0, 0, 0.6);
    /* Slightly darker overlay for a more professional look */
    animation: fadeIn 0.6s ease-out;
    /* Smooth fade-in effect */
}

/* Modal Content */
.modal-content {
    font-family: 'Helvetica Neue', sans-serif;
    /* Modern and clean font */
    color: #333;
    /* Dark text for good readability */
    font-size: 12px;
    /* Keeping the font size as requested */
    background: linear-gradient(145deg, rgb(196, 216, 236), rgb(201, 212, 218));
    /* Soft gradient background */
    border-radius: 12px;
    /* Rounded corners */
    margin: auto;
    margin-top: 40px;
    padding-left: 40px;
    /* padding-right: 40px; */
    /* padding-top: 30px; Extra padding at the top for balance */
    /* padding-bottom: 30px; Extra padding at the bottom for balance */
    border: 1px solid #ccc;
    /* Light border for subtle effect */
    width: 70%;
    /* Responsive width */
    transform: scale(0.8);
    /* Initial scale for animation */
    animation: scaleUp 0.5s ease-in-out forwards;
    /* Smooth scaling animation */
    box-shadow: 0 15px 25px rgba(0, 0, 0, 0.1);
    /* Soft shadow for depth */
    transition: all 0.3s ease-in-out;
    /* Smooth transition effect */
    overflow: hidden;
    /* To ensure smooth edges */
}

/* Modal fade-in animation */
@keyframes fadeIn {
    from {
        opacity: 0;
    }

    to {
        opacity: 1;
    }
}

/* Scale-up animation */
@keyframes scaleUp {
    from {
        transform: scale(0.8);
        opacity: 0;
    }

    to {
        transform: scale(1);
        opacity: 1;
    }
}

/* The Close Button */
.close {
    float: right;
    color: #e74c3c;
    font-size: 38px;
    /* Larger size for close button */
    font-weight: bold;
    cursor: pointer;
    transition: color 0.3s ease, transform 0.3s ease-in-out;
    padding: 0 10px;
    /* Extra space around close button */
}

.close:hover {
    color: rgb(238, 155, 146);
    /* Red color on hover */
    /* transform: rotate(45deg); Rotate the close button */
}

/* Stylish list items inside the modal */
.modal-content ul {
    list-style-type: decimal;
    /* Use numbers for list items */
    margin-top: 20px;
    padding-left: 25px;
    /* Add padding to list items */
    color: #555;
    /* Lighter text color for better contrast */
}

.modal-content ul li {
    /* margin-bottom: 10px; */
    line-height: 1.6;
    /* Increased line height for better readability */
    padding-left: 10px;
    /* Padding to align list items nicely */
    transition: transform 0.2s ease-in-out;
    /* Smooth transition effect on hover */
}

.modal-content ul li:hover {
    transform: translateX(5px);
    /* Subtle animation on hover for list items */
}

/* Optional: Add a smooth transition effect when content changes */
.modal-content {
    transition: transform 0.5s ease, opacity 0.5s ease;
}

.section {
    /* border-top: 2px solid #2f7cab; */
    padding: 10px 20px;
    margin-top: 3.7%;
}

.section:first-child {
    border-top: none;
}

* {
    margin: 0;
    padding: 0;
    box-sizing: border-box;
    font-family: Arial, sans-serif;
}

body {
    background-color: #f4f8fb;
    min-height: 100%;
      text-transform: uppercase;
    /* padding: 20px; */
    position: relative;
}

.form-container {
    width: 100%;
    max-width: 100%;
    margin: 0 auto;
    display: flex;
    flex-direction: column;
    gap: 10px;
}


/* -------------------------------
   Tab Links (Fixed Nav)
-------------------------------- */
  
.tab-links {
  position: fixed;
  top: 0;
  left: 0; right: 0;
  z-index: 999;
  display: flex;
  justify-content: space-between;
  padding: 7px;
    gap:10px;
  overflow-x: auto;
  backdrop-filter: blur(12px);
  border-bottom: 2px solid rgba(0,0,0,0.05);
  box-shadow: 0 2px 10px rgba(0,0,0,0.08);
  text-align: center;
}

.tab-links .tab {
   border: 1px solid #ddd;
  padding:2px 32px;
  border-radius: 50px;
  font-size: 14px;
  font-weight: bold;
  color: #444;

  transition: all 0.3s ease;
  cursor: pointer;
}

.tab-links .tab.active {
  background: linear-gradient(135deg, #9d7cc1ff, #5d7aacff);
  color: #fff;
    box-shadow: 0 12px 30px rgba(106, 17, 203, 0.35),
              0 6px 15px rgba(37, 117, 252, 0.25);
  transition: all 0.5s cubic-bezier(0.25, 1, 0.5, 1);
  animation: gradientMove 4s ease infinite, float 6s ease-in-out infinite;
  transform: scale(1.05);
  box-shadow: 0 4px 12px rgba(0,0,0,0.2);

}

/* Tab Icon */
.tab img {
  width: 45px;
  height: 45px;
  margin-bottom:5px;
  transition: transform 0.3s ease;
}
.tab:hover img {
  transform: rotate(10deg) scale(1.1);
}



/* Optional: Adjust body or main content margin to accommodate the fixed navbar height */


/* Styling the scrollbar for the entire page */
::-webkit-scrollbar {
    width: 12px;
    /* Width of the vertical scrollbar */
    height: 10px;
    /* Height of horizontal scrollbar */
}

/* Styling the scrollbar track */
::-webkit-scrollbar-track {
    background: linear-gradient(135deg, #f0f0f0, #e0e0e0);
    /* Light gradient track */
    border-radius: 10px;
    /* Rounded corners */
    box-shadow: inset 0 0 10px rgba(0, 0, 0, 0.1);
    /* Subtle shadow */
}

/* Styling the scrollbar thumb (the draggable part) */
::-webkit-scrollbar-thumb {
    background: linear-gradient(135deg, #2f7cab, #0056b3);
    /* Gradient thumb */
    border-radius: 10px;
    /* Rounded corners */
    border: 3px solid transparent;
    /* Add space around thumb */
    background-clip: content-box;
    /* Ensures the thumb’s background doesn’t overlap the border */
    transition: background 0.3s ease, transform 0.3s ease;
    /* Smooth transition for hover */
}

/* Hover effect for the scrollbar thumb */
::-webkit-scrollbar-thumb:hover {
    background: linear-gradient(135deg, #0056b3, #003d80);
    /* Darker gradient on hover */
    transform: scale(1.1);
    /* Slightly enlarge the thumb */
}

/* Styling the horizontal scrollbar */
::-webkit-scrollbar-horizontal {
    height: 8px;
}

/* Styling the horizontal scrollbar track */
::-webkit-scrollbar-track-horizontal {
    background: linear-gradient(135deg, #f0f0f0, #e0e0e0);
    /* Light gradient track */
    border-radius: 10px;
    box-shadow: inset 0 0 10px rgba(0, 0, 0, 0.1);
}

/* Styling the horizontal scrollbar thumb */
::-webkit-scrollbar-thumb-horizontal {
    background: linear-gradient(135deg, #2f7cab, #0056b3);
    border-radius: 10px;
    border: 3px solid transparent;
    background-clip: content-box;
    transition: background 0.3s ease, transform 0.3s ease;
}

/* Hover effect for horizontal scrollbar thumb */
::-webkit-scrollbar-thumb-horizontal:hover {
    background: linear-gradient(135deg, #0056b3, #003d80);
    transform: scale(1.1);
    /* Slightly enlarge the thumb */
}


      .header {
 
 font-size:15px;background: linear-gradient(135deg, #e4dee7ff);
  color:black;
  font-weight:600;
  padding: 16px;
  text-align: center;
  font-size: 20px;
  font-weight: 700;
  letter-spacing: 1px;
  margin-top:10px;
  border-bottom: 4px solid #fff;
  box-shadow: 0 4px 15px rgba(0,0,0,0.2);
  text-transform: uppercase;
}

/* Main Content Styling */
form {
    width: 100%;
}

table {
    width: 100%;
    border-collapse: collapse;
}

td {
    padding: 8px;
    font-size:16px;
    text-align: left;
    vertical-align: middle;
}

td:nth-child(odd) {
    background-color: #e0e0ff;
    font-weight: bold;
}

td:nth-child(even) {
    background-color: #f9f9f9;
}

input[type="text"] {
    width: 100%;
    padding: 8px;
    border: 1px solid #dcdcdc;
    border-radius: 5px;
}


/* Floating Side Buttons */
.side-buttons {
    position: fixed;
    top: 20%;
    right: 20px;
    display: flex;
    flex-direction: column;
    gap: 10px;
    z-index: 1000;
}

.side-buttons button {
    background-color: #2f7cab;
    border: none;
    padding: 10px;
    cursor: pointer;
    border-radius: 50%;
    width: 50px;
    height: 50px;
    display: flex;
    align-items: center;
    justify-content: center;
    transition: background-color 0.3s;
}

.side-buttons button img {
    width: 24px;
    height: 24px;
    filter: invert();
}

.side-buttons button:hover {
    background-color: #0056b3;
}

@media (max-width: 768px) {
    .side-buttons {
        top: 15%;
        right: 10px;
    }

    .tab-links {
        flex-wrap: wrap;
    }
}

@media (max-width: 480px) {
    .tab-links button {
        padding: 8px 10px;
    }

    .header {
        font-size: 16px;
    }

    td {
        font-size: 14px;
    }

    input[type="text"] {
        font-size: 14px;
    }

    .side-buttons {
        top: 10%;
        right: 5px;
    }
}

.image-preview-container {
    display: flex;
    flex-wrap: wrap;
    gap: 10px;
    margin-top: 20px;
    background-color: #f8f9fa;
    border: 2px dashed #dcdcdc;
    padding: 10px;
    border-radius: 8px;
    /* justify-content: center; */
    align-items: center;
    text-align: center;
}

.image-preview-container p {
    color: #888;
    font-size: 14px;
}

.image-preview-container.hidden {
    display: none;
}

/* File input trigger button styling */
.side-buttons button {
    background-color: #2f7cab;
    border: none;
    padding: 10px;
    cursor: pointer;
    border-radius: 50%;
    width: 50px;
    height: 50px;
    display: flex;
    align-items: center;
    justify-content: center;
    transition: background-color 0.3s;
}

.valuation-table {
    width: 100%;
    border-collapse: collapse;
    margin-bottom: 20px;
    font-size: 12px;
    margin-top: -1.1%;
}

.valuation-table th,
.valuation-table td {
    border: 1px solid #333;
    padding: 8px;
    text-align: center;
}

.valuation-table th {
    background-color: #2f7cab;
    color: white;
    font-weight: bold;
}

.valuation-table tr:nth-child(odd) td {
    background-color: #e9f5fb;
}

.valuation-table td {
    background-color: #fff;
    font-weight: normal;
}

.section {
    width: 100%;
    /* border-top: 2px solid #2f7cab; */
    /* padding: 10px 20px; */
    /* margin-top: 3.7%; */
}

.section:first-child {
    border-top: none;
}

h2 {
    font-size: 15px;
    /* border-radius: 5px; */
  
 font-size:15px;background: linear-gradient(135deg, #e4dee7ff);
  color:black;
  font-weight:600;
    padding: 10px;
    /* margin:auto; */
}

ul {
    list-style: none;
    padding: 0;
}

li {
    margin: 5px 0;
    font-size: 13px;
    line-height: 1.6;
}


.rotating-text {
    color: black;
    perspective: 1000px;
    /* Adds a 3D perspective effect */
    font-size: 1.5rem;
    font-weight: bold;
    width: 100%;
    animation: rotate360 3s linear infinite;
    display: inline-block;
    margin-bottom: 10px;
    transform-origin: center center;
    /* Rotates around its center */
    text-align: center;
    /* margin-left:20px; */
    font-style: italic;
    text-shadow:
        1px 1px 2px rgba(235, 244, 243, 0.97),
        2px 2px 4px rgba(246, 242, 242, 0.4),
        3px 3px 6px rgba(249, 252, 252, 0.89),
        4px 4px 8px rgba(248, 242, 247, 0.93),
        5px 5px 10px rgba(232, 236, 237, 0.4);
}

/* Keyframes for rotating the text */
@keyframes rotate360 {
    0% {
        transform: rotateY(0deg);
        /* Starts with no rotation */
    }

    50% {
        transform: rotateY(0deg);
        /* Half rotation */
    }

    100% {
        transform: rotateY(360deg);
        /* Full rotation */
    }
}

.logo {
    /* width: 50px; */
    height: 83px;
    padding: 12px;
    padding-bottom: 33px;

}

#sidebar {
    background: #B0C4DE;
    /* Light Steel Blue */
    color: #2C3E50;
    position: fixed;
    left: -250px;
    top: 0;
    width: 250px;
    height: 100%;
    /* background-color: #111; */
    color: white;
    transition: left 0.3s ease;
    padding: 20px;
}

#sidebar.active {
    left: 35px;
    /* background:grey; */
}

.sidebar {
    width: 250px;
    background: #B0C4DE;
    /* Light Steel Blue */
    /* background:rgba(245, 245, 245, 0.37); Light Steel Blue */
    color: black;
    /* Dark Grayish Blue */
    padding: 20px;
    height: 100vh;
    position: fixed;
    left: 0;
    top: 0;
    z-index: 1000;
    transition: transform 0.3s ease-in-out;
}

.sidebar.hidden {
    transform: translateX(-100%);
}

.sidebar h1 {
    font-size: 20px;
    margin-bottom: 20px;
}

.sidebar a {
    padding: 15px 20px;
    margin: 10px 0;
    text-decoration: none;
    color: #2C3E50;
    /* Dark Grayish Blue */
    font-size: 16px;
    font-style: italic;
    font-weight: 500;
    margin-bottom: 40px;
    border-radius: 5px;
    transition: all 0.3s ease;
    display: flex;
    align-items: center;
}

.sidebar a:hover,
.sidebar a.active {
    background: #4A90E2;
    /* Light Blue */
    transform: translateX(10px);
    color: white;
}

.sidebar a .icon {
    margin-right: 15px;
    font-size: 18px;
}

/* Toggle Button */
#toggleSidebar {
    border-radius: 20%;
    position: fixed;
    top: 0px;
    /* Adjusted for better placement */
    left: 0px;
    /* Adjusted for better placement */
    z-index: 1000;
    background-color: rgb(130, 183, 226);
    color: white;
    border: none;
    padding: 6px 12px;
    /* Added padding for a more clickable area */
    cursor: pointer;
    box-shadow: 0 4px 8px rgba(0, 0, 0, 0.7);
    /* Adds a soft shadow for depth */
    transition: all 0.3s ease;
    /* Smooth transition for hover and active states */
}

/* Button hover effect */
#toggleSidebar:hover {
    background-color: #1c6abf;
    /* Slightly darker shade on hover */
    transform: scale(1);
    /* Slightly enlarges the button for a professional hover effect */
    box-shadow: 0 6px 12px rgba(0, 0, 0, 0.3);
    /* Stronger shadow on hover */
}

/* Active state for the button */
#toggleSidebar.active {
    background-color: #1a4f82;
    /* Darker shade for active state */
    transform: rotate(180deg);
    /* Smooth rotate effect when the sidebar is active */
}

/* Button icon (if you use an icon inside the button) */
#toggleSidebar i {
    font-size: 18px;
    /* Adjust the icon size */
    transition: transform 0.3s ease;
    /* Smooth transition when rotating */
}

.watch-icon {
    margin-right: 16px;
    /* Adds space between the search text and the watch icon */
    color: #555;
    /* Optional: sets the color of the watch icon */
}

#toggleSidebar {
    border-radius: 20%;
    position: fixed;
    top: 0px;
    /* Adjust for better placement */
    /* right: -35px; Position it just outside the sidebar */
    z-index: 1001;
    background-color: rgb(130, 183, 226);
    color: white;
    border: none;
    padding: 6px 12px;
    cursor: pointer;
    box-shadow: 0 4px 8px rgba(0, 0, 0, 0.7);
    transition: all 0.3s ease;
}

/* Button hover effect */
#toggleSidebar:hover {
    background-color: #1c6abf;
    box-shadow: 0 6px 12px rgba(0, 0, 0, 0.3);
}

/* Active state for the button */
#toggleSidebar.active {
    background-color: #1a4f82;
    transform: rotate(180deg);
    /* Smooth 180-degree rotation */
    box-shadow: 0 6px 12px rgba(0, 0, 0, 0.5);
}

/* Sidebar */
#sidebar.active+#toggleSidebar {
    right: 250px;
    /* Adjust so button moves into view */
}

/* Sidebar when active */
#sidebar.active {
    left: 0px;
}

/* Sidebar hidden state */
#sidebar {
    position: fixed;
    left: -250px;
    top: 0;
    width: 250px;
    height: 100%;
    background: #B0C4DE;
    color: white;
    transition: left 0.3s ease;
}

#pdf-container {
    width: 100%;
    height: 100%;
    overflow: auto;
}

canvas {
    display: block;
    margin: 0 auto;
}

/* Modal background */
/* Modal background */
.modal {
    display: none;
    /* Hidden by default */
    position: fixed;
    /* Stay in place */
    z-index: 1;
    /* Sit on top */
    left: 0;
    top: 0;
    width: 100%;
    /* Full width */
    height: 100%;
    /* Full height */
    overflow: auto;
    /* Enable scroll if needed */
    background-color: rgba(0, 0, 0, 0.6);
    /* Slightly darker overlay for a more professional look */
    animation: fadeIn 0.6s ease-out;
    /* Smooth fade-in effect */
}

/* Modal Content */
.modal {
    display: none;
    /* Hidden by default */
    position: fixed;
    /* Stay in place */
    z-index: 1;
    /* Sit on top */
    left: 0;
    top: 0;
    width: 100%;
    /* Full width */
    height: 100%;
    /* Full height */
    overflow: auto;
    /* Enable scroll if needed */
    background-color: rgba(0, 0, 0, 0.6);
    /* Slightly darker overlay for a more professional look */
    animation: fadeIn 0.6s ease-out;
    /* Smooth fade-in effect */
}

/* Modal Content */
.modal-content {
    font-family: 'Helvetica Neue', sans-serif;
    /* Modern and clean font */
    color: #333;
    /* Dark text for good readability */
    font-size: 12px;
    /* Keeping the font size as requested */
    background: linear-gradient(145deg, rgb(196, 216, 236), rgb(201, 212, 218));
    /* Soft gradient background */
    border-radius: 12px;
    /* Rounded corners */
    margin: auto;
    margin-top: 40px;
    padding-left: 40px;
    /* padding-right: 40px; */
    /* padding-top: 30px; Extra padding at the top for balance */
    /* padding-bottom: 30px; Extra padding at the bottom for balance */
    border: 1px solid #ccc;
    /* Light border for subtle effect */
    width: 70%;
    /* Responsive width */
    transform: scale(0.8);
    /* Initial scale for animation */
    animation: scaleUp 0.5s ease-in-out forwards;
    /* Smooth scaling animation */
    box-shadow: 0 15px 25px rgba(0, 0, 0, 0.1);
    /* Soft shadow for depth */
    transition: all 0.3s ease-in-out;
    /* Smooth transition effect */
    overflow: hidden;
    /* To ensure smooth edges */
}

/* Modal fade-in animation */
@keyframes fadeIn {
    from {
        opacity: 0;
    }

    to {
        opacity: 1;
    }
}

/* Scale-up animation */
@keyframes scaleUp {
    from {
        transform: scale(0.8);
        opacity: 0;
    }

    to {
        transform: scale(1);
        opacity: 1;
    }
}

/* The Close Button */
.close {
    float: right;
    color: #e74c3c;
    font-size: 38px;
    /* Larger size for close button */
    font-weight: bold;
    cursor: pointer;
    transition: color 0.3s ease, transform 0.3s ease-in-out;
    padding: 0 10px;
    /* Extra space around close button */
}

.close:hover {
    color: rgb(238, 155, 146);
    /* Red color on hover */
    /* transform: rotate(45deg); Rotate the close button */
}

/* Stylish list items inside the modal */
.modal-content ul {
    list-style-type: decimal;
    /* Use numbers for list items */
    margin-top: 20px;
    padding-left: 25px;
    /* Add padding to list items */
    color: #555;
    /* Lighter text color for better contrast */
}

.modal-content ul li {
    /* margin-bottom: 10px; */
    line-height: 1.6;
    /* Increased line height for better readability */
    padding-left: 10px;
    /* Padding to align list items nicely */
    transition: transform 0.2s ease-in-out;
    /* Smooth transition effect on hover */
}

.modal-content ul li:hover {
    transform: translateX(5px);
    /* Subtle animation on hover for list items */
}

/* Optional: Add a smooth transition effect when content changes */
.modal-content {
    transition: transform 0.5s ease, opacity 0.5s ease;
}

.dropdown-select {
    display: inline-block;
    margin: 20px;
    font-family: Arial, sans-serif;
}

/* Label styling */
.dropdown-select label {
    margin-right: 10px;
    font-weight: bold;
}

label {
    text-align: left;
}

/* Select dropdown styling */
select {
    padding: 10px;
    font-style: italic;
    font-size: 16px;
    border: 2px solid black;
    border-radius: 5px;
    background-color: white;
    color: black;
    appearance: none;
    background-image: url('data:image/svg+xml;charset=US-ASCII,<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 4 5"><path fill="black" d="M2 0L0 2h4zM0 3l2 2 2-2z"/></svg>');
    background-repeat: no-repeat;
    background-position: right 10px center;
    background-size: 12px 12px;
    cursor: pointer;
    transition: all 0.3s ease;
    width: 200px;
    /* Increased width */
}

/* Hover and focus effects */
.select:hover {
    border-color: #007BFF;
    outline: none;
}

textarea {
    width: 100%;
    height: 40%;
}
    </style>
</head>

<body class="loading">
    <!-- Loader -->
    <div id="loaderOverlay">LOADING, PLEASE WAIT...</div><button id="toggleSidebar">&#9776;</button>
<div id="sidebar" class="sidebar">
    <div style="display: flex">
      <img class="logo" src="logo.png" alt="" />
      <h1>Magpie Engineering</h1>
    </div>
    <div class="rotating-text">Report Drafter</div>
    <a href="clear_and_go_home.php"><i class="fas fa-home icon"></i>Home</a>        

    
  <a href="clear_sessions.php" class="active"><i class="fas fa-clock watch-icon"></i>Pending For Drafting</a>
    <a href="technical.php"><i class="fas fa-clipboard-list icon"></i> Preview Report</a>    
          <a href="clear_and_logout.php"><i class="fas fa-sign-out-alt icon"></i>Logout</a>
  </div>
  
<!-- Tab Buttons -->
<div class="tab-links"> 
    <button class="tab tab-button" data-href="REPORT3.php"><img src="info.png" alt="Icon" width="50" height="50"> INFO</button>
    <button class="tab tab-button" data-href="REPORT4.php"><img src="general.png" alt="Icon" width="50" height="50" style="margin-bottom:4px;"> GENERAL</button>
    <button class="tab tab-button" data-href="REPORT2.php"><img src="location.png" alt="Icon" width="50" height="50"> LOCATION</button>
    <button class="tab tab-button" data-href="REPORT5.php"><img src="Zoning.png" alt="Icon" width="50" height="50"> ZONING</button>
    <button class="tab tab-button" data-href="REPORT7.php"><img src="value.png" alt="Icon" width="50" height="50"> VALUE</button>
    <button class="tab tab-button" data-href="REPORT9.php"><img src="Floor.png" alt="Icon" width="50" height="50"> STRUCTURE</button>
    <button class="tab tab-button" data-href="REPORT10.php"><img src="documents.png" alt="Icon" width="50" height="50"> DOCUMENTS</button>
    <button class="tab tab-button" data-href="REPORT115.php"><img src="photo.png" alt="Icon" width="50" height="50"> PHOTOS</button>

    <button class="tab active" onclick="location.href='REPORT12.php'"><img src="remark.png" alt="Icon" width="50" height="50"> REMARK</button>
    <div class="slider"></div>
</div>
        <div class="section valuation-table" style="margin-top:5px;">
    <form id="autosave-form" method="POST" action="">
        <h2>POSITIVE REMARKS ON THE PROPERTY</h2>
        <textarea name="remarks_table" cols="166" rows="10" style="background-color: rgba(207, 233, 252, 0.282); margin:auto;" placeholder="  WRITE REMARKS HERE....."><?= isset($_SESSION['remarks_table']) && is_string($_SESSION['remarks_table']) ? htmlspecialchars($_SESSION['remarks_table']) : "" ?></textarea>

        <h2 style="margin-top:15px;">NEGATIVE REMARKS ON THE PROPERTY</h2>
        <textarea name="negative_remarks" cols="166" rows="10" style="background-color: rgba(252, 207, 207, 0.282); margin:auto;" placeholder="  WRITE NEGATIVE REMARKS HERE....."><?= isset($_SESSION['negative_remarks']) && is_string($_SESSION['negative_remarks']) ? htmlspecialchars($_SESSION['negative_remarks']) : "" ?></textarea>

</div>
            <div class="submit-button">
            <input type="hidden" name="action" value="save">
            <button type="submit" id="saveBtn" name="action" value="save">Save</button>
            <button type="submit" name="action" value="submit">SUBMIT</button>
        </div>
    </form>
          
            </div>
           <!-- Script to hide loader -->
    <script>
        // Run when page is fully loaded
        window.addEventListener('load', function () {
            // Hide loader
            document.getElementById('loaderOverlay').style.display = 'none';
            // Re-enable page interaction
            document.body.classList.remove('loading');
        });
    </script>
<script>
 // On Save button click, set saved flag in sessionStorage
    document.getElementById('saveBtn').addEventListener('click', function () {
        sessionStorage.setItem('isFormSaved', 'true');
    });

    // Intercept tab button clicks
    document.querySelectorAll('.tab-button').forEach(button => {
        button.addEventListener('click', function (e) {
            const isSaved = sessionStorage.getItem('isFormSaved') === 'true';
            if (!isSaved) {
                e.preventDefault();
                alert("Please click 'Save' before switching tabs.");
            } else {
                const url = this.getAttribute('data-href');
                window.location.href = url;
            }
        });
    });

    // Reset save flag if user edits any input
    document.querySelectorAll('input, textarea, select').forEach(field => {
        field.addEventListener('input', function () {
            sessionStorage.setItem('isFormSaved', 'false');
        });
    });


    


    document.addEventListener("DOMContentLoaded", function () {
    let tabs = document.querySelectorAll(".tab-links .tab");
    let slider = document.querySelector(".tab-links .slider");

    function moveSlider(activeTab) {
        slider.style.width = activeTab.offsetWidth + "px";
        slider.style.left = activeTab.offsetLeft + "px";
    }

    tabs.forEach(tab => {
        tab.addEventListener("click", function () {
            tabs.forEach(t => t.classList.remove("active"));
            this.classList.add("active");
            moveSlider(this);
        });

        // Initialize position on load for the active tab
        if (tab.classList.contains("active")) {
            moveSlider(tab);
        }
    });
});
  
document.getElementById("toggleSidebar").addEventListener("click", function () {
    if (confirm("Are you sure to open the side bar? Your data will be lost/erased.")) {
        // Redirect to "Pending For Drafting" page
        window.location.href = "clear_sessions.php";
    } else {
        // If user clicks Cancel, do nothing
        return false;
    }
});


var modal = document.getElementById("myModal");

// Get the <span> element that closes the modal
var span = document.getElementsByClassName("close")[0];

// Function to show the modal with custom text
function showPopup(text) {
    document.getElementById("modalText").innerText = text;
    modal.style.display = "block";
}

// When the user clicks on <span> (x), close the modal
span.onclick = function() {
    modal.style.display = "none";
}

// When the user clicks anywhere outside of the modal, close it
window.onclick = function(event) {
    if (event.target == modal) {
        modal.style.display = "none";
    }
}

function openGoogleMaps(location) {
            const baseUrl = "https://www.google.com/maps/search/?api=1&query=";
            window.open(baseUrl + encodeURIComponent(location), '_blank');
        }
function triggerFileInput2() {
            document.getElementById("imageInput").click();
        }

        document.getElementById("imageInput").addEventListener("change", function (event) {
            const files = event.target.files;
            const previewContainer = document.getElementById("imagePreviewContainer");

            // Clear previous previews
            previewContainer.innerHTML = "";

            // Display previews for each selected image
            Array.from(files).forEach((file) => {
                if (file.type.startsWith("image/")) {
                    const reader = new FileReader();
                    reader.onload = function (e) {
                        const img = document.createElement("img");
                        img.src = e.target.result;
                        previewContainer.appendChild(img);
                    };
                    reader.readAsDataURL(file);
                }
            });
        });
function triggerFileInput1() {
            document.getElementById("pdfInput").click();
        }

        // Handle file selection
        document.getElementById("pdfInput").addEventListener("change", function (event) {
            const file = event.target.files[0];
            if (file && file.type === "application/pdf") {
                // Create a FileReader instance
                const reader = new FileReader();

                // When the file is read successfully, open it in a new tab
                reader.onload = function (e) {
                    const pdfUrl = e.target.result;

                    // Try to open the PDF in a new tab using embed
                    const newTab = window.open();
                    if (newTab) {
                        newTab.document.write('<html><body><embed src="' + pdfUrl + '" type="application/pdf" width="100%" height="100%"></body></html>');
                        newTab.document.close();

                        // Fallback if the PDF does not load correctly
                        setTimeout(function() {
                            if (newTab.document.body.innerHTML === "") {
                                // Use PDF.js as a fallback to display the PDF
                                newTab.document.body.innerHTML = '<div id="pdf-container" style="width: 100%; height: 100%;"></div>';
                                const loadingTask = pdfjsLib.getDocument(pdfUrl);
                                loadingTask.promise.then(function(pdf) {
                                    pdf.getPage(1).then(function(page) {
                                        const scale = 1.5;
                                        const viewport = page.getViewport({ scale: scale });
                                        const canvas = document.createElement('canvas');
                                        const ctx = canvas.getContext('2d');
                                        canvas.height = viewport.height;
                                        canvas.width = viewport.width;
                                        document.getElementById('pdf-container').appendChild(canvas);

                                        // Render PDF page
                                        page.render({
                                            canvasContext: ctx,
                                            viewport: viewport
                                        });
                                    });
                                });
                            }
                        }, 1000); // Check if the embed failed after 1 second
                    }
                };

                // Read the file as a data URL
                reader.readAsDataURL(file);
            } else {
                alert("Please select a valid PDF file.");
            }
        });
</script>
</body>

</html>
