<?php include('auth.php'); ?>
<?php include 'watermark.html'; ?>

<?php
ini_set('display_errors', 1);
error_reporting(E_ALL);

// Increase PHP execution time and memory limit
ini_set('max_execution_time', 600); // Increase execution time to 600 seconds (10 minutes)
ini_set('memory_limit', '4096M'); // Increase memory limit to 4096MB
// Start session

$servername = "localhost";
$username = "root";
$password = "";
$dbname = "project_db";

// Create DB connection
$conn = new mysqli($servername, $username, $password, $dbname);
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

if (!isset($_SESSION['reference_id'])) {
    die("Reference ID not found in session.");
}
$reference_id = $_SESSION['reference_id'];

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['download_images'])) {

    // Get customer name
    $stmt_name = $conn->prepare("SELECT customerName FROM mis WHERE reference_id = ?");
    $stmt_name->bind_param("s", $reference_id);
    $stmt_name->execute();
    $result_name = $stmt_name->get_result();
    $customerName = "customer";
    if ($row = $result_name->fetch_assoc()) {
        $customerName = preg_replace('/[^a-zA-Z0-9]/', '', $row['customerName']);
    }
    $stmt_name->close();

    // Fetch image BLOBs
    $stmt = $conn->prepare("SELECT image1, image2, image3, image4, image5, image6, image7, image8, image9, image10, image11, image12,image13, image14, image15, image16, image17, image18, image19, image20 FROM final_uploaded_images WHERE reference_id = ?");    $stmt->bind_param("s", $reference_id);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows > 0 && ($row = $result->fetch_assoc())) {
        $tempDir = sys_get_temp_dir() . DIRECTORY_SEPARATOR . uniqid('images_', true);
        mkdir($tempDir);

        $imageFiles = [];
        for ($i = 1; $i <= 20; $i++) {
            if (!empty($row["image$i"])) {
                $filename = $tempDir . DIRECTORY_SEPARATOR . "image{$i}.jpg";
                file_put_contents($filename, $row["image$i"]);
                $imageFiles[] = $filename;
            }
        }

        if (empty($imageFiles)) {
            die("No images to download.");
        }

        // Create ZIP
        $zipFileName = "images_" . preg_replace('/[^a-zA-Z0-9]/', '_', $reference_id) . "_{$customerName}.zip";
        $zipPath = $tempDir . DIRECTORY_SEPARATOR . $zipFileName;

        $zip = new ZipArchive();
        if ($zip->open($zipPath, ZipArchive::CREATE) !== TRUE) {
            die("Failed to create ZIP file.");
        }

        foreach ($imageFiles as $file) {
            $zip->addFile($file, basename($file));
        }
        $zip->close();

       header('Content-Type: application/pdf');
header('Content-Disposition: attachment; filename="' . basename($pdfFile) . '"');
header('Content-Length: ' . filesize($pdfFile));
readfile($pdfFile);


        // Cleanup
        foreach ($imageFiles as $file) {
            unlink($file);
        }
        unlink($zipPath);
        rmdir($tempDir);
        exit;
    } else {
        echo "<p style='color:red;'>No image data found for this reference ID.</p>";
    }
}

$page = isset($_GET['page']) ? $_GET['page'] : 1;
$limit = 50;
$offset = ($page - 1) * $limit;
$sql_property = "SELECT * FROM mis WHERE reference_id = ? LIMIT $limit OFFSET $offset";
$stmt_property = $conn->prepare($sql_property);
$stmt_property->bind_param("s", $reference_id);
$stmt_property->execute();
$result_property = $stmt_property->get_result();
$data1 = $result_property->fetch_assoc();

// Fetch data from property_details table
$sql_property = "SELECT * FROM property_details WHERE reference_id = ?";
$stmt_property = $conn->prepare($sql_property);
$stmt_property->bind_param("s", $reference_id);
$stmt_property->execute();
$result_property = $stmt_property->get_result();
$data2= $result_property->fetch_assoc();

// Fetch data from area_valuation table
$sql_area = "SELECT * FROM address_details WHERE reference_id = ?";
$stmt_area = $conn->prepare($sql_area); 
$stmt_area->bind_param("s", $reference_id);
$stmt_area->execute();
$result_area = $stmt_area->get_result();
$data3 = $result_area->fetch_assoc();

// Fetch data from area_valuation table
$sql_area = "SELECT * FROM critical_parameters WHERE reference_id = ?";
$stmt_area = $conn->prepare($sql_area); 
$stmt_area->bind_param("s", $reference_id);
$stmt_area->execute();
$result_area = $stmt_area->get_result();
$data4 = $result_area->fetch_assoc();

// Fetch data from area_valuation table
$sql_area = "SELECT * FROM surroundings_details WHERE reference_id = ?";
$stmt_area = $conn->prepare($sql_area); 
$stmt_area->bind_param("s", $reference_id);
$stmt_area->execute();
$result_area = $stmt_area->get_result();
$data5 = $result_area->fetch_assoc();
$stmt_area->close();
 
// Fetch data from area_valuation table
$sql_area = "SELECT * FROM area_valuation WHERE reference_id = ?";
$stmt_area = $conn->prepare($sql_area); 
$stmt_area->bind_param("s", $reference_id);
$stmt_area->execute();
$result_area = $stmt_area->get_result();
$data6 = $result_area->fetch_assoc();
$stmt_area->close();
 
// Fetch data from area_valuation table
$sql_area = "SELECT * FROM floor_details WHERE reference_id = ?";
$stmt_area = $conn->prepare($sql_area); 
$stmt_area->bind_param("s", $reference_id);
$stmt_area->execute();
$result_area = $stmt_area->get_result();
$data8= $result_area->fetch_assoc();
$stmt_area->close();
 
// Fetch data from area_valuation table
$sql_area = "SELECT * FROM technical_details WHERE reference_id = ?";
$stmt_area = $conn->prepare($sql_area); 
$stmt_area->bind_param("s", $reference_id);
$stmt_area->execute();
$result_area = $stmt_area->get_result();
$data9 = $result_area->fetch_assoc();
$stmt_area->close();
 
// Fetch data from area_valuation table
$sql_area = "SELECT * FROM remarks_table WHERE reference_id = ?";
$stmt_area = $conn->prepare($sql_area); 
$stmt_area->bind_param("s", $reference_id);
$stmt_area->execute();
$result_area = $stmt_area->get_result();
$data10 = $result_area->fetch_assoc();
$stmt_area->close();

// Step 1: Fetch the engineer_id from the mis table
$sql_mis = "SELECT engineer_id FROM mis WHERE reference_id = ?";
$stmt_mis = $conn->prepare($sql_mis);
$stmt_mis->bind_param("s", $reference_id);
$stmt_mis->execute();
$result_mis = $stmt_mis->get_result();
$row_mis = $result_mis->fetch_assoc();
$stmt_mis->close(); 

if ($row_mis) {
    $engineer_id = $row_mis['engineer_id'];

    // Step 2: Fetch the engineer's name from engineer_login table
    $sql_engineer = "SELECT name FROM engineer_login WHERE engineer_id = ?";
    $stmt_engineer = $conn->prepare($sql_engineer);
    $stmt_engineer->bind_param("s", $engineer_id);
    $stmt_engineer->execute();
    $result_engineer = $stmt_engineer->get_result();
    $row_engineer = $result_engineer->fetch_assoc();
    $stmt_engineer->close();

    if ($row_engineer) {
        $engineer_name = $row_engineer['name'];
         //echo "Engineer Name: " . $engineer_name;
    } else {
        echo "Engineer not found.";
    }
} else {
    echo "No engineer assigned for this reference_id.";
}

// Step 1: Fetch the engineer_id from the mis table
$sql_mis = "SELECT report_id FROM mis WHERE reference_id = ?";
$stmt_mis = $conn->prepare($sql_mis);
$stmt_mis->bind_param("s", $reference_id);
$stmt_mis->execute();
$result_mis = $stmt_mis->get_result();
$row_mis = $result_mis->fetch_assoc();
$stmt_mis->close(); 

if ($row_mis) {
    $report_id = $row_mis['report_id'];

    // Step 2: Fetch the engineer's name from engineer_login table
    $sql_engineer = "SELECT name FROM report_login WHERE report_id = ?";
    $stmt_engineer = $conn->prepare($sql_engineer);
    $stmt_engineer->bind_param("s", $report_id);
    $stmt_engineer->execute();
    $result_engineer = $stmt_engineer->get_result();
    $row_engineer = $result_engineer->fetch_assoc();
    $stmt_engineer->close();

    if ($row_engineer) {
        $report_name = $row_engineer['name'];
         //echo "Engineer Name: " . $report_name;
    } else {
        echo "Engineer not found.";
    }
} else {
    echo "No engineer assigned for this reference_id.";
}

// Step 1: Fetch the engineer_id from the mis table
$sql_mis = "SELECT report_drafter_to_technical FROM mis WHERE reference_id = ?";
$stmt_mis = $conn->prepare($sql_mis);
$stmt_mis->bind_param("s", $reference_id);
$stmt_mis->execute();
$result_mis = $stmt_mis->get_result();
$row_mis = $result_mis->fetch_assoc();
$stmt_mis->close(); 

if ($row_mis) {
    $report_drafter_to_technical = $row_mis['report_drafter_to_technical'];

    // Step 2: Fetch the engineer's name from engineer_login table
    $sql_engineer = "SELECT name FROM technical_login WHERE technical_manager_id = ?";
    $stmt_engineer = $conn->prepare($sql_engineer);
    $stmt_engineer->bind_param("s", $report_drafter_to_technical);
    $stmt_engineer->execute();
    $result_engineer = $stmt_engineer->get_result();
    $row_engineer = $result_engineer->fetch_assoc();
    $stmt_engineer->close();

    if ($row_engineer) {
        $technical_name = $row_engineer['name'];
        //echo "Engineer Name: " . $technical_name;
    } else {
        echo "Engineer not found.";
    }
} else {
    echo "No engineer assigned for this reference_id.";
}
?> 

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>HDB Report</title>
    <link rel="shortcut icon" href="favicon.png" type="image/x-icon"> 
    <style>
        body {
    font-family:  sans-serif;
    margin: 20px;
}
header {
display: flex;
align-items: center;
}

.logo img {
width: 100px;
margin-left:30px;
height: auto;
}

.header {
    text-align: center;
    font-size: 48px;
    font-weight: 1000;
    color: #003366;
}
.sub-header {
    text-align: center;
    font-size: 14px;
    color: green;
    margin-bottom: 10px;
}
table {
    width: 100%;
    border-collapse: collapse;
    margin-bottom:8px;
}
h3{
    text-align: center;
    border: 2px solid black;
}
th, td {
    border: 0.5px solid black;
    padding:4px;
    text-align: left;
}
th {
    text-align: center;
    text-decoration: underline;
}
th {
    text-align: center;
}
.highlight {
    font-weight: lighter;
    text-align: center;
}

input {
    color:black;
    border: none;
    width: 90%;
}
.header-container {
display: flex; 
align-items: center; /* Align items vertically */
justify-content: space-around; /* Center content */
gap: 20px; /* Space between logo and text */
width: 100%;
padding: 10px 0;
}


/* Flexbox for proper text alignment */
.header-content {
display: flex;
flex-direction: column;
text-align: center; /* Center text under heading */
}

/* Main heading */
.header {
font-size: 40px;
font-weight: bold;
color: #002f6c; /* Adjust color */
}

/* Sub-header styling */
.sub-header {
font-size: 16px;
color: green; /* Adjust color */
line-height: 1.5; /* Improve readability */
}
textarea
{
    height:200px;
    width:100%
}
 

    .number-col {
      width: 40px;
      text-align: center;
      font-weight: bold;
      background-color: #F3F3F3;
    }
    #highlight{
        background:#ffcc00;
    }
    </style>
     <style>
 
            

.container {
    max-width: 1200px;
    margin: 20px auto;
    padding: 20px;
    background-color: white;
    box-shadow: 0px 0px 10px rgba(0, 0, 0, 0.1);
    border-radius: 8px;
}

.title {
    text-align: center;
    font-size: 24px;
    font-weight: bold;
    margin-bottom: 20px;
}
.grid-container {
    display: grid;
    grid-template-columns: repeat(4, 1fr);
    gap: 15px;
}

.grid-item {
    position: relative;
    border-radius: 8px;
    overflow: hidden;
    box-shadow: 0px 4px 6px rgba(0, 0, 0, 0.1);
}

.grid-item img {
    width: 100%;
    height: 200px;
    object-fit: cover;
    transition: transform 0.3s ease;
}
.grid-item:hover img {
    transform: scale(1.05);
}

.overlay {
    position: absolute;
    bottom: 0;
    left: 0;
    background: rgba(0, 0, 0, 0.6);
    color: white;
    width: 100%;
    padding: 8px;
    font-size: 14px;
    text-align: center;
}
 
   
/* Force a stable 4-column grid that wkhtmltopdf respects */
.image-gallery { width: 100%; }
.image-grid { width: 100%; border-collapse: collapse; table-layout: fixed; }
.image-grid tr { page-break-inside: avoid; }
.image-grid td { width: 25%; padding: 6px; vertical-align: top; }

.image-grid .img-wrap { display: block; }
.image-grid img { display: block; width: 100%; height: auto; }
.image-grid .caption { font-size: 12px; text-align: center; margin-top: 4px; }

/* If you had a flex layout before, neutralize it */
.image-gallery { display: block !important; }



    /* Print-specific rules */
    @media print {
      .no-print {
        display: none !important;
      }

      body {
        margin: 0;
      }
 
    }
  button{
    padding:8px;
    margin-left:45%;
    background-color:#808485;
    color:white;
    font-weight:700;
    font-style:italic;
  }
  button:hover{
    background-color:rgba(216,216,216,255);
    color:white;
  }

/* Optional: Google map styling */
    .google-map-container {
      max-width: 90%;
      margin: 20px auto;
      border: 2px solid #ccc;
      padding: 10px;
      box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
      background-color: #f9f9f9;
      border-radius: 8px;
      text-align: center;
    }

    .google-map-container img {
      max-width: 100%;
      height: auto;
      display: inline-block;
      border: 1px solid #999;
      border-radius: 4px;
    }
    
.logo img {
  width: 120px;
  margin-left:30px;
  height: auto;
}

 .image2-container {
      max-width: 50%;
      margin: 20px auto;
      border: 2px solid #ccc;
      padding: 10px;
      box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
      background-color: #f9f9f9;
      border-radius: 8px;
      text-align: center;
    }

    .image2-container img {
      max-width: 60%;
      height: 20%;
      display: inline-block;
      border: 1px solid #999;
      border-radius: 4px;
    }
    
 .image13-container {
      max-width: 40%;
      margin: 20px auto;
      border: 2px solid #ccc;
      padding: 10px;
      box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
      background-color: #f9f9f9;
      border-radius: 8px;
      text-align: center;
    }

    .image13-container img {
      max-width: 30%;
      height: 10%;
      display: inline-block;
      border: 1px solid #999;
      border-radius: 4px;
    }
 </style>
</head>
<body>
<div class="content">
    <header>
    <div class="logo">
        <img src="SAA.jpg" alt="SAA Logo">
    </div>
      <div class="header-content">
    <div class="header">SAINI AND ASSOCIATES</div>
    <div class="sub1-header">Valuer Designer Architects</div>
    <div class="sub-header">Office no. 201, 2nd floor, Gravity Mall, Mechanic nagar, warehouse road, near vijay nagar, Indore, Madhya Pradesh- 452011</div>
 </div>
</div>
    <h3 id="highlight">VALUATION VERIFICATION REPORT</h3>
    <table style="margin-top:-20px;" >
        <tr>
            <th id="highlight">LOS NO</th>
            <td id="highlight"><span style="display: inline-block; min-width: 50px; padding:2px">
        <?= htmlspecialchars($data1['applicationNo'] ?? '') ?>
    </span></td>
            <th id="highlight">Date:</th>
            <td id="highlight"><span style="display: inline-block; min-width: 50px; padding:2px">
 <?= htmlspecialchars(date('d M Y h:i A', strtotime($data1['report_assigned_at'] ?? ''))) ?>
    </span></td>
            <th id="highlight">Type of Report</th>
            <td id="highlight"><span style="display: inline-block; min-width: 50px; padding:2px">
        <?= htmlspecialchars('Original') ?>
    </span></td>
        </tr>
        <tr>
            <th id="highlight"> Valuer Name, Contact Details, Email ID & Code<br></th>
            <td id="highlight" colspan="5"><span style="display: inline-block; min-width: 50px; padding:2px">
        <?= htmlspecialchars('Sanjay Saini') ?>
    </span></td>
        </tr>
        <tr>
            <th id="highlight">Branch Name or DSA Name</th>
            <td id="highlight" colspan="2"><span style="display: inline-block; min-width: 50px; padding:2px">
        <?= htmlspecialchars($data1['bank_branchname'] ?? '') ?>
    </span></td>  
            <th id="highlight">Product:</th>
            <td id="highlight" colspan="3"><span style="display: inline-block; min-width: 50px; padding:2px">
        <?= htmlspecialchars($data1['caseType'] ?? '') ?>
    </span></td>
        </tr>
          <tr>
            <th id="highlight">Refrence No<br></th>
            <td id="highlight" colspan="5"><span style="display: inline-block; min-width: 50px; padding:2px">
        <?= htmlspecialchars($data1['reference_id'] ?? '') ?>
    </span></tr>
</table>
<table style="margin-top:-20px;">
        <h3 style="margin-top:-10px;" id="highlight">GENERAL DETAILS:</h3>
        <tr>
            <td  >1</td>
            <td><strong>Purpose of Valuation</strong></td>
            <td colspan="4"><span style="display: inline-block; min-width: 50px; padding:2px">
        <?= htmlspecialchars($data1['caseType'] ?? '') ?>
    </span></td>
        </tr>

        <tr>
            <td  >2</td>
            <td><strong>Date on which Valuation is done</strong></td>
            <td colspan="4"><span style="display: inline-block; min-width: 50px; padding:2px">
 <?= htmlspecialchars(date('d M Y h:i A', strtotime($data1['report_assigned_at'] ?? ''))) ?>
    </span></td>
        </tr>
        
        </table>
        <table style="margin-top:-10px;">
        <tr>
            <td rowspan="2" style="width:25px;">3</td>
            <td rowspan="2"><strong>Name of the applicant / Property Owner</strong></td>
            <td colspan="2"><strong>As per Initiation</strong></td>
            <td><strong>As per Documents</strong></td>
            <td><strong>As per Physical Visit</strong></td>
        </tr>
        
        <tr>
            <td colspan="2"><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data1['customerName'] ?? '') ?>
    </span></td>
        <td><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data9['owner_name'] ?? '') ?>
    </span></td>
            <td><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data9['seller_name'] ?? '') ?>
    </span></td>
        </tr>
       
             
        <tr>
            <td  >5</td>
            <td rowspan="2"><strong>Particulars</strong></td>
            <td colspan="2"><strong>As per Ownership Document</strong></td>
            <td><strong>As per Approved Plans & Permission</strong></td>
            <td><strong>As per Physical Visit</strong></td>
        </tr>
        <tr>         
       </tr>
        <tr>
            <td  >5a.</td>
            <td><strong>Property Address Description</strong></td>
              <td colspan="2"><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data3['address_per_document'] ?? '') ?>
    </span></td>
            <td><span style="display: inline-block; min-width: 50px; padding:2px">
        <?= htmlspecialchars($data10['NA'] ?? '') ?>
    </span></td>
              <td><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data3['address_per_site'] ?? '') ?>
    </span></td>
        </tr>
        <tr>
            <td>5b.</td>
            <td><strong>Plot No. & Sub Plot No.</strong></td>
                  <td colspan="2"><span style="display: inline-block; min-width: 50px; padding: 2px;">
    <?= htmlspecialchars($data3['address_line_1_as_per_doc'] ?? '') ?></span></td>
        <td colspan="1"><span style="display: inline-block; min-width: 50px; padding: 2px;">
    <?= htmlspecialchars($data10['NA'] ?? '') ?></span></td>
        <td colspan="1"><span style="display: inline-block; min-width: 50px; padding: 2px;">
    <?= htmlspecialchars($data3['address_line_1_as_per_doc'] ?? '') ?></span></td>
        </tr>
        <tr>
            <td>5c.</td>
            <td><strong>CTS Nos/S.Nos/Gat Nos/Hissa Nos/Khasra Nos.</strong></td>
            <td colspan="2"><span style="display: inline-block; min-width: 50px; padding: 2px;">
    <?= htmlspecialchars($data3['khasra_no'] ?? '') ?></span></td>
    <td colspan="1"><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data10['NA'] ?? '') ?></span></td>
    <td colspan="1"><span style="display: inline-block; min-width: 50px; padding: 2px;">
    <?= htmlspecialchars($data3['khasra_no'] ?? '') ?></span></td>
        </tr>
        <tr>
            <td>5d.</td>
            <td><strong>Village/Town/Location</strong></td>
            <td colspan="2"><span style="display: inline-block; min-width: 50px; padding: 2px;">
    <?= htmlspecialchars($data3['village_name'] ?? '') ?></span></td>
    <td colspan="1"><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data10['NA'] ?? '') ?></span></td>
    <td colspan="1"><span style="display: inline-block; min-width: 50px; padding: 2px;">
    <?= htmlspecialchars($data3['village_name'] ?? '') ?></span></td>
        </tr>
        <tr>
            <td>5e.</td>
            <td><strong>Taluka</strong></td>
           <td colspan="2"><span style="display: inline-block; min-width: 50px; padding: 2px;">    <?= htmlspecialchars($data3['taluka_tehsil'] ?? '') ?></span></td>

    <td colspan="1"><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data10['NA'] ?? '') ?></span></td>
    <td colspan="1"><span style="display: inline-block; min-width: 50px; padding: 2px;">    <?= htmlspecialchars($data3['taluka_tehsil'] ?? '') ?></span></td>

        </tr>
        <tr>
            <td>5f.</td>
            <td><strong>District</strong></td>
            <td colspan="2"><span style="display: inline-block; min-width: 50px; padding:2px">
        <?= htmlspecialchars($data3['address_line_3_as_per_doc'] ?? '') ?>
    </span></td>
            <td><span style="display: inline-block; min-width: 50px; padding:2px">
        <?= htmlspecialchars($data10['NA'] ?? '') ?>
    </span></td>
            <td><span style="display: inline-block; min-width: 50px; padding:2px">
        <?= htmlspecialchars($data3['address_line_3_as_per_doc'] ?? '') ?>
    </span></td>

        </tr>
        <tr>
            <td>5g.</td>
            <td><strong>State</strong></td>
            <td colspan="2"><span style="display: inline-block; min-width: 50px; padding:2px">
        <?= htmlspecialchars($data3['address_line_4_as_per_doc'] ?? '') ?>
    </span></td>
            <td><span style="display: inline-block; min-width: 50px; padding:2px">
        <?= htmlspecialchars($data10['NA'] ?? '') ?>
    </span></td>
            <td><span style="display: inline-block; min-width: 50px; padding:2px">
        <?= htmlspecialchars($data3['address_line_4_as_per_doc'] ?? '') ?>
    </span></td>        </tr>
        <tr>
            <td>5h.</td>
            <td><strong>Pin Code</strong></td>
            <td colspan="2"><span style="display: inline-block; min-width: 50px; padding:2px">
        <?= htmlspecialchars($data3['pin_code'] ?? '') ?>
    </span></td>
            <td><span style="display: inline-block; min-width: 50px; padding:2px">
        <?= htmlspecialchars($data10['NA'] ?? '') ?>
    </span></td>
            <td><span style="display: inline-block; min-width: 50px; padding:2px">
        <?= htmlspecialchars($data3['pin_code'] ?? '') ?>
    </span></td>
        </tr>
        <tr>
            <td>5i.</td>
            <td><strong>Complete Property Address as per System</strong></td>
            <td colspan="4"><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data3['address_per_document'] ?? '') ?>
</span></td>
        </tr>
        <tr>
            <td>5j.</td>
            <td><strong>GPS Coordinates</strong></td>
            <td><strong>Latitude</strong></td>
            <td ><span style="display: inline-block; min-width: 50px; padding:2px">
        <?= htmlspecialchars($data3['latitude_value'] ?? '') ?>
    </span></td>
            <td><strong>Longitude</strong></td>
            <td><span style="display: inline-block; min-width: 50px; padding:2px">
        <?= htmlspecialchars($data3['longitude_value'] ?? '') ?>
    </span></td>
        </tr>
        <tr>
            <td>5k.</td>
            <td><strong>Nearest Landmark</strong></td>
            <td colspan="4"><span style="display: inline-block; min-width: 50px; padding:2px">
        <?= htmlspecialchars($data3['landmark_1'] ?? '') ?>  <?= htmlspecialchars($data3['landmark_2'] ?? '') ?>
    </span></td>
        </tr>
        <tr>
            <td>5l.</td>
            <td><strong>Name on the Society Name Board</strong></td>
            <td colspan="4"><span style="display: inline-block; min-width: 50px; padding:2px">
        <?= htmlspecialchars($data4['board_on_house'] ?? '') ?>
    </span></td>
        </tr>
        <tr>
            <td>5m.</td>
            <td><strong>Name on the Property’s Door/Entrance</strong></td>
            <td colspan="4"><span style="display: inline-block; min-width: 50px; padding:2px">
        <?= htmlspecialchars($data2['name_on_house_board'] ?? '') ?>
    </span></td>
        </tr>
        <tr>
            <td>5n.</td>
      <td><strong>Name, Address and contact No. of the Neighbor/Treasurer / Secretary</strong></td>
       <td colspan="4"><span style="display: inline-block; min-width: 50px; padding:2px">
        <?= htmlspecialchars($data10['NA'] ?? '') ?>
    </span></td>      
        </tr>
        <tr>
            <td>5o.</td>
            <td><strong>Property Address Matches as per Site, Property Documents</strong></td>
            <td colspan="4"><span style="display: inline-block; min-width: 50px; padding:2px">
        <?= htmlspecialchars($data3['address_matching'] ?? '') ?>
    </span></td>
        </tr>
        <tr>
            <td>5p.</td>
            <td><strong>Property Enlisted For Any Negative Authority Action/Negative Area</strong></td>
            <td colspan="4"><span style="display: inline-block; min-width: 50px; padding:2px">
        <?= htmlspecialchars($data10['NA'] ?? '') ?>
    </span></td>
        </tr>
        </table>
        <table style="margin-top:-10px;">
        <tr>
            <td>6</td>
            <td><strong>Particulars</strong></td>
            <td colspan="2"><strong>Name</strong></td>
            <td colspan="2"><strong>Distance</strong></td>
        </tr>
        <tr>
            <td>6a.</td>
            <td><strong>Nearest Government offices from </strong></td>
            <td colspan="2"><span style="display: inline-block; min-width: 50px; padding:2px">
        <?= htmlspecialchars($data3['nearest_post_office_name'] ?? '') ?>
    </span></td>
            <td colspan="2"><span style="display: inline-block; min-width: 50px; padding:2px">
        <?= htmlspecialchars($data3['nearest_post_office_distance'] ?? '') ?>
    </span></td>
        </tr>
         <tr>
            <td>6b.</td>
            <td><strong>Nearest Railway Station from property</strong></td>
            <td colspan="2"><span style="display: inline-block; min-width: 50px; padding:2px">
        <?= htmlspecialchars($data3['nearest_railway_station_name'] ?? '') ?>
    </span></td>
            <td colspan="2"><span style="display: inline-block; min-width: 50px; padding:2px">
        <?= htmlspecialchars($data3['nearest_railway_station_distance'] ?? '') ?>
    </span></td>
        </tr>
         <tr>
            <td>6c.</td>
            <td><strong>Nearest Bus Station from property </strong></td>
            <td colspan="2"><span style="display: inline-block; min-width: 50px; padding:2px">
        <?= htmlspecialchars($data3['nearest_bus_stop_name'] ?? '') ?>
    </span></td>
            <td colspan="2"><span style="display: inline-block; min-width: 50px; padding:2px">
        <?= htmlspecialchars($data3['nearest_bus_stop_distance'] ?? '') ?>
    </span></td>
        </tr>
        <tr>
            <td>6d.</td>
            <td><strong>Nearest Airport Station from property</strong></td>
            <td colspan="2"><span style="display: inline-block; min-width: 50px; padding:2px">
        <?= htmlspecialchars($data3['nearest_airport_name'] ?? '') ?>
    </span></td>
            <td colspan="2"><span style="display: inline-block; min-width: 50px; padding:2px">
        <?= htmlspecialchars($data3['nearest_airport_distance'] ?? '') ?>
    </span></td>
        </tr>
         <tr>
            <td>6e.</td>
            <td><strong>Nearest National Highway from </strong></td>
            <td colspan="2"><span style="display: inline-block; min-width: 50px; padding:2px">
        <?= htmlspecialchars($data3['nearest_national_highway_name'] ?? '') ?>
    </span></td>
            <td colspan="2"><span style="display: inline-block; min-width: 50px; padding:2px">
        <?= htmlspecialchars($data3['nearest_national_highway_distance'] ?? '') ?>
    </span></td>
        </tr>
        <tr>
            <td>6f.</td>
            <td><strong>Community centers like</strong></td>
            <td colspan="2"><span style="display: inline-block; min-width: 50px; padding:2px">
        <?= htmlspecialchars($data3['nearest_bus_stop_name'] ?? '') ?>
    </span></td>
            <td colspan="2"><span style="display: inline-block; min-width: 50px; padding:2px">
        <?= htmlspecialchars($data3['nearest_bus_stop_distance'] ?? '') ?>
    </span></td>
        </tr>
        <tr>
            <td>6g.</td>
            <td><strong>School, College Hospital, Market etc</strong></td>
            <td colspan="2"><span style="display: inline-block; min-width: 50px; padding:2px">
        <?= htmlspecialchars($data3['nearest_school_college_name'] ?? '') ?>
    </span></td>
            <td colspan="2"><input type="text" value=" School:<?= $data3['nearest_school_college_distance'] ?? '' ?> Hospital: <?= $data3['nearest_hospital_distance'] ??'' ?>" readonly></td>
        </tr>
        <tr>
            <td>6h.</td>
            <td><strong> Within Municipal Limits</strong></td>
            <td colspan="3"><span style="display: inline-block; min-width: 50px; padding:2px">
        <?= htmlspecialchars($data2['project_approval_status'] ?? '') ?>
    </span></td>
        </tr>
        <tr>
            <td>6i.</td>
            <td><strong>Details of Local Authority</strong></td>
            <td colspan="3"><span style="display: inline-block; min-width: 50px; padding:2px">
        <?= htmlspecialchars($data3['property_location_in'] ?? '') ?>
    </span></td>
        </tr>
</table>
<table style="margin-top:-20px;">
     <h3 style="margin-top:-10px;" id="highlight">DOCUMENTS DETAILS</h3>
  <tr >
    <th>7</th>
    <th>Particulars</th>
    <th>Whether Provided or not</th>
    <th>Registrar official/Competent Authority/Owner Name</th>
    <th>Document Number</th>
    <th>Dated</th>
</tr>
 
  <tr>
    <td >7a</td>
    <td>Ownership Documents Sale Deed</td>
    <td><span style="display: inline-block; min-width: 50px; padding:2px">
        <?= htmlspecialchars($data9['ownership1_approving_authority'] ?? '') ?>
    </span></td>
    <td><span style="display: inline-block; min-width: 50px; padding:2px">
        <?= htmlspecialchars($data9['ownership1_details'] ?? '') ?>
    </span></td>
    <td><span style="white-space: pre-line; font-size:14px; display: block; text-align: left; padding: 0; margin: 0;font-weight:400;"readonly>
        <?= htmlspecialchars($data9['ownership1_no'] ?? '') ?>
    </span></td>
    <td><span style="white-space: pre-line; font-size:14px; display: block; text-align: left; padding: 0; margin: 0;font-weight:400;"readonly>
     <?= htmlspecialchars(date('d M Y', strtotime($data9['ownership1_date'] ?? ''))) ?>,       
    </span></td>
  </tr>

  <tr>
    <td >7b</td>
    <td class="left-align">Non Agriculture Order/Diversion Order</td>
     <td><span style="display: inline-block; min-width: 50px; padding:2px">
        <?= htmlspecialchars($data9['na_permission_details'] ?? '') ?>
    </span></td>
    <td><span style="display: inline-block; min-width: 50px; padding:2px">
        <?= htmlspecialchars($data9['na_approving_authority'] ?? '') ?>
    </span></td>
    <td><span style="white-space: pre-line; font-size:14px; display: block; text-align: left; padding: 0; margin: 0;font-weight:400;"readonly>
        <?= htmlspecialchars($data9['na_approval_details'] ?? '') ?>
    </span></td>
    <td><span style="white-space: pre-line; font-size:14px; display: block; text-align: left; padding: 0; margin: 0;font-weight:400;"readonly>
        <?= htmlspecialchars($data9['na_approval_date'] ?? '') ?>
    </span></td>
    
  </tr>

  <tr>
    <td >7c</td>
    <td class="left-align">Commencement Certificate</td>
    <td><span style="display: inline-block; min-width: 50px; padding:2px">
        <?= htmlspecialchars($data9['ownership4_approving_authority'] ?? '') ?>
    </span></td>
    <td><span style="display: inline-block; min-width: 50px; padding:2px">
        <?= htmlspecialchars($data9['ownership4_details'] ?? '') ?>
    </span></td>
    <td><span style="display: inline-block; min-width: 50px; padding:2px">
        <?= htmlspecialchars($data9['ownership4_no'] ?? '') ?>
    </span></td>
    <td><span style="display: inline-block; min-width: 50px; padding:2px">
        <?= htmlspecialchars($data9['ownership4_date'] ?? '') ?>
    </span></td>
  </tr>

  <tr>
    <td >7d</td>
    <td class="left-align">Sanctioned Plan Letter</td>
    <td><span style="display: inline-block; min-width: 50px; padding:2px">
        <?= htmlspecialchars($data9['map_available'] ?? '') ?>
    </span></td>
    <td><span style="display: inline-block; min-width: 50px; padding:2px">
        <?= htmlspecialchars($data9['sanction_approving_authority'] ?? '') ?>
    </span></td>
    <td><span style="display: inline-block; min-width: 50px; padding:2px">
        <?= htmlspecialchars($data9['sanction_approval_no'] ?? '') ?>
    </span></td>
    <td><span style="display: inline-block; min-width: 50px; padding:2px">
        <?= htmlspecialchars($data9['sanction_approval_date'] ?? '') ?>
    </span></td>
  </tr>

  <tr>
    <td >7e</td>
    <td class="left-align">Building Plan / Layout Plan</td>
    <td><span style="display: inline-block; min-width: 50px; padding:2px">
        <?= htmlspecialchars($data9['layout_applicable'] ?? '') ?>
    </span></td>
    <td><span style="display: inline-block; min-width: 50px; padding:2px">
        <?= htmlspecialchars($data9['layout_approving_authority'] ?? '') ?>
    </span></td>
    <td><span style="display: inline-block; min-width: 50px; padding:2px">
        <?= htmlspecialchars($data9['layout_approval_details'] ?? '') ?>
    </span></td>
    <td><span style="display: inline-block; min-width: 50px; padding:2px">
        <?= htmlspecialchars($data9['layout_approval_date'] ?? '') ?>
    </span></td>
  </tr>

  <tr>
    <td >7f</td>
    <td class="left-align">Occupancy Certificate/Completion Certificate</td>
   <td><span style="display: inline-block; min-width: 50px; padding:2px">
        <?= htmlspecialchars($data9['ownership2_approving_authority'] ?? '') ?>
    </span></td>
    <td><span style="display: inline-block; min-width: 50px; padding:2px">
        <?= htmlspecialchars($data9['ownership2_details'] ?? '') ?>
    </span></td>
    <td><span style="display: inline-block; min-width: 50px; padding:2px">
        <?= htmlspecialchars($data9['ownership2_no'] ?? '') ?>
    </span></td>
    <td><span style="display: inline-block; min-width: 50px; padding:2px">
        <?= htmlspecialchars($data9['ownership2_date'] ?? '') ?>
    </span></td>
  </tr>

  <tr>
    <td >7g</td>
    <td class="left-align">Regularisation Certificate/Order</td>
    <td><span style="display: inline-block; min-width: 50px; padding:2px">
        <?= htmlspecialchars($data10['NA'] ?? '') ?>
    </span></td>
    <td><span style="display: inline-block; min-width: 50px; padding:2px">
        <?= htmlspecialchars($data10['NA'] ?? '') ?>
    </span></td>
    <td><span style="display: inline-block; min-width: 50px; padding:2px">
        <?= htmlspecialchars($data10['NA'] ?? '') ?>
    </span></td>
    <td><span style="display: inline-block; min-width: 50px; padding:2px">
        <?= htmlspecialchars($data10['NA'] ?? '') ?>
    </span></td>
  </tr>

  <tr>
    <td >7h</td>
    <td class="left-align">Share Certificate</td>
    <td><span style="display: inline-block; min-width: 50px; padding:2px">
        <?= htmlspecialchars($data10['NA'] ?? '') ?>
    </span></td>
    <td><span style="display: inline-block; min-width: 50px; padding:2px">
        <?= htmlspecialchars($data10['NA'] ?? '') ?>
    </span></td>
    <td><span style="display: inline-block; min-width: 50px; padding:2px">
        <?= htmlspecialchars($data10['NA'] ?? '') ?>
    </span></td>
    <td><span style="display: inline-block; min-width: 50px; padding:2px">
        <?= htmlspecialchars($data10['NA'] ?? '') ?>
    </span></td>
  </tr>

  <tr>
    <td >7i</td>
    <td class="left-align">Latest Property Tax Paid Bill</td>
    <td><span style="display: inline-block; min-width: 50px; padding:2px">
        <?= htmlspecialchars($data9['ownership3_approving_authority'] ?? '') ?>
    </span></td>
    <td><span style="display: inline-block; min-width: 50px; padding:2px">
        <?= htmlspecialchars($data9['ownership3_details'] ?? '') ?>
    </span></td>
    <td><span style="display: inline-block; min-width: 50px; padding:2px">
        <?= htmlspecialchars($data9['ownership3_no'] ?? '') ?>
    </span></td>
    <td><span style="display: inline-block; min-width: 50px; padding:2px">
        <?= htmlspecialchars($data9['ownership3_date'] ?? '') ?>
    </span></td>
  </tr>
</table>

    <!-- BOUNDARIES SECTION -->
    <table style="margin-top:-20px;">
        <tr>
            <h3 id="highlight" style="margin-top:-10px;">BOUNDARIES</h3>
        </tr>
        <tr>
            <td rowspan="6">8</td>
            <td><strong>Direction</strong></td>
            <td><strong>As Per Ownership Documents</strong></td>
            <td><strong>As Per Approved Plans</strong></td>
            <td><strong>As Per Site</strong></th>
        </tr>

        <tr>
        <td><strong>East</strong></td>
        <td><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data3['direction_as_per_document_east'] ?? '') ?>
        </span></td>          
        <td><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data3['direction_approved_east'] ?? '') ?>
        </span></td> 
        <td><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data3['direction_as_per_site_east'] ?? '') ?>
       </span></td>        
       </tr>
        <tr>
        <td><strong>West</strong></td>
        <td> <span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data3['direction_as_per_document_west'] ?? '') ?>
        </span></td>
            
        <td> <span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data3['direction_approved_west'] ?? '') ?>
        </span></td>
        <td> <span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data3['direction_as_per_site_west'] ?? '') ?>
        </span></td>        
    </tr>
        <tr>
            <td><strong>North</strong></td>


  <td><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data3['direction_as_per_document_north'] ?? '') ?>
    </span></td>           

  <td><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data3['direction_approved_north'] ?? '') ?>
    </span></td>           
          <td><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data3['direction_as_per_site_north'] ?? '') ?>
    </span></td>
        </tr>
        <tr>
            <td><strong>South</strong></td>
        <td><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data3['direction_as_per_document_south'] ?? '') ?>
    </span></td>
            <td><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data3['direction_approved_south'] ?? '') ?>
    </span></td>
    <td><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data3['direction_as_per_site_south'] ?? '') ?>
    </span></td>
          </tr>
        <tr>
            <td colspan="3"><strong>Number of Boundaries Matching:</strong></td>
            <td><span style="display: inline-block; min-width: 50px; padding:2px">
        <?= htmlspecialchars($data3['boundaries_matching'] ?? '') ?>
    </span></td>
        </tr>
    </table >
    <h3 id="highlight" style="margin-top:-10px;">TECHNICAL DETAILS</h3>
    <table style="margin-top:-20px;">
        <tr>
            <td rowspan="7">9</td>
            <td><strong>Property Type</strong></td>
            <td><span style="display: inline-block; min-width: 50px; padding:2px">
        <?= htmlspecialchars($data2['property_unit_type'] ?? '') ?>
    </span></td>
        </tr>
        <tr> 
            <td><strong>Valuation Methodology</strong></td>
            <td><span style="display: inline-block; min-width: 50px; padding:2px">
        <?= htmlspecialchars($data6['propertyType'] ?? '') ?>
    </span></td></tr>
        <tr>
            <td><strong>Present Occupancy</strong></td>
            <td><span style="display: inline-block; min-width: 50px; padding:2px">
        <?= htmlspecialchars($data2['occupancy_status'] ?? '') ?>
    </span></td>
        </tr>
        <tr>
            <td><strong>If not Occupied by Owner</strong></td>
            <td colspan="2"><span style="display: inline-block; min-width: 50px; padding:2px">
        <?= htmlspecialchars($data4['within_50_mtrs_railway'] ?? '') ?></span></td>
        </tr>
        <tr>
            <td><strong> 1.Name of Occupant</strong></td>
            <td colspan="2"><span style="display: inline-block; min-width: 50px; padding:2px">
        <?= htmlspecialchars($data2['occupant_name'] ?? '') ?></span></td>
        </tr>
        <tr>
            <td><strong>2. Rent Agreement/Lease deed details(Date & No.)</strong></td>
            <td colspan="2"><span style="display: inline-block; min-width: 50px; padding:2px">
        <?= htmlspecialchars($data9['lease_approving_authority'] ?? '') ?>
    </span></td>
        </tr>
        <tr>
            <td><strong> 3.Occupation Age from Day 1</strong></td>
            <td colspan="2"><span style="display: inline-block; min-width: 50px; padding:2px">
        <?= htmlspecialchars($data2['occupied_since'] ?? '') ?>
    </span></td>
        </tr>
    </table>
    <!-- LAND/PLOT DETAILS -->
    <h3 id="highlight" style="margin-top:-10px;">LAND/PLOT - (Applicable in Plot + Construction cases only)</h3>
    <table style="margin-top:-20px;">
        <tr>
            <td>9a.</td>
            <td colspan="1"><strong>Particulars</strong></td>
            <td><strong>As per Ownership Document</strong></td>
            <td><strong>As per Approved Plans & Permission</strong></td>
            <td  colspan="3"><strong>As per Physical Visit</strong></td>
        </tr>
        <tr>
            <td>9a1.</td>
            <td colspan="1"><strong>Area of Land/Plot/Unit (sqft.) SBUA</strong></td>
            <td><span style="display: inline-block; min-width: 50px; padding:2px">
        <?= htmlspecialchars($data6['plot_square_feet'] ?? '') ?>
    </span></td>
            <td><span style="display: inline-block; min-width: 50px; padding:2px">
        <?= htmlspecialchars($data10['NA'] ?? '') ?>
    </span></td>
            <td colspan="3"><span style="display: inline-block; min-width: 50px; padding:2px">
        <?= htmlspecialchars($data6['actual_plot_square_feet'] ?? '') ?>
    </span></td>
        </tr>
        <tr> 
           <td>9a2.</td>
            <td colspan="1"><strong> Plot Usage </strong></td>
            <td><span style="display: inline-block; min-width: 50px; padding:2px">
        <?= htmlspecialchars($data4['approved_property_usage'] ?? '') ?>
    </span></td>
            <td><span style="display: inline-block; min-width: 50px; padding:2px">
        <?= htmlspecialchars($data10['NA'] ?? '') ?>
    </span></td>
            <td colspan="3"><span style="display: inline-block; min-width: 50px; padding:2px">
        <?= htmlspecialchars($data4['current_property_usage'] ?? '') ?>
    </span></td>
        </tr>
        <tr>
            <td>9a3.</td>
            <td colspan="1"><strong>Property Accessibility</strong></td>
            <td colspan="6"><span style="display: inline-block; min-width: 50px; padding:2px">
        <?= htmlspecialchars($data4['zoning_development_plan'] ?? '') ?>
    </span></td>
        <tr>
            <td>9a4.</td>
            <td colspan="1"><strong>Details of Access</strong></td>
            <td><span style="display: inline-block; min-width: 50px; padding:2px">
        <?= htmlspecialchars($data2['type_of_approach_road'] ?? '') ?>
    </span></td>
            <td><strong>Road Width</strong></td>
            <td colspan="3"><span style="display: inline-block; min-width: 50px; padding:2px">
        <?= htmlspecialchars($data2['width_of_approach_road'] ?? '') ?>
    </span></td>
        </tr>
        <tr>
            <td rowspan="5">9a5.</td>
            <td rowspan="5"><strong>Margin Area/ Set Backs (ft)</strong></td>
            <td>Sides</td>
            <td>As per Approved plans & Permission</td>
            <td>As per Physical visit</td>
            <td colspan="2">Deviation</td>
        </tr>
        <tr>
            <td>Front</td>
           <td><span style="display: inline-block; min-width: 50px; padding:2px">
        <?= htmlspecialchars($data10['NA'] ?? '') ?>
    </span></td>
           <td><span style="display: inline-block; min-width: 50px; padding:2px">
        <?= htmlspecialchars($data10['NA'] ?? '') ?>
    </span></td>
            <td colspan="2"><span style="display: inline-block; min-width: 50px; padding:2px">
        <?= htmlspecialchars($data10['NA'] ?? '') ?>
    </span></td>
        </tr>
         <tr>
            <td>Back</td>
           <td><span style="display: inline-block; min-width: 50px; padding:2px">
        <?= htmlspecialchars($data10['NA'] ?? '') ?>
    </span></td>
           <td><span style="display: inline-block; min-width: 50px; padding:2px">
        <?= htmlspecialchars($data10['NA'] ?? '') ?>
    </span></td>
            <td colspan="2"><span style="display: inline-block; min-width: 50px; padding:2px">
        <?= htmlspecialchars($data10['NA'] ?? '') ?>
    </span></td>
        </tr>
        <tr>
            <td>Left</td>
           <td><span style="display: inline-block; min-width: 50px; padding:2px">
        <?= htmlspecialchars($data10['NA'] ?? '') ?>
    </span></td>
           <td><span style="display: inline-block; min-width: 50px; padding:2px">
        <?= htmlspecialchars($data10['NA'] ?? '') ?>
    </span></td>
            <td colspan="2"><span style="display: inline-block; min-width: 50px; padding:2px">
        <?= htmlspecialchars($data10['NA'] ?? '') ?>
    </span></td>
        </tr>
        <tr>
            <td>Right</td>
           <td><span style="display: inline-block; min-width: 50px; padding:2px">
        <?= htmlspecialchars($data10['NA'] ?? '') ?>
    </span></td>
           <td><span style="display: inline-block; min-width: 50px; padding:2px">
        <?= htmlspecialchars($data10['NA'] ?? '') ?>
    </span></td>
            <td colspan="2"><span style="display: inline-block; min-width: 50px; padding:2px">
        <?= htmlspecialchars($data10['NA'] ?? '') ?>
    </span></td>
        </tr>
        <tr>
            <td>9a6.</td>
            <td colspan="2"><strong>Property Demarcated</strong></td>
            <td colspan="4"><span style="display: inline-block; min-width: 50px; padding:2px">
        <?= htmlspecialchars($data2['demarcated_at_site'] ?? '') ?>
    </span></td>
        </tr>
        <tr>
            <td>9a7.</td>
            <td colspan="2"><strong>Ownership</strong></td>
            <td colspan="4"><span style="display: inline-block; min-width: 50px; padding:2px">
        <?= htmlspecialchars($data2['property_leasehold_freehold'] ?? '') ?>
    </span></td></tr>
        <tr>
            <td>9a8.</td>
            <td colspan="2"><strong>Land/Plot Area Considered for Valuation</strong></td>
            
<td colspan="2"><span style="display: inline-block; min-width: 50px; padding:2px">
        <?= htmlspecialchars($data6['final_plot_square_feet'] ?? '') ?>
    </span></td>
        <tr>
            <td>9a9.</td>
            <td colspan="2"><strong>Agreement Value (Rs.)</strong></td>
           
            <td colspan="4"><span style="display: inline-block; min-width: 50px; padding:2px">
        <?= htmlspecialchars($data10['NA'] ?? '') ?>
    </span></td>        </tr>
        <tr> 
            <td>9a10(a).</td>
            <td colspan="2"><strong>Government Guideline Rate (Rs.)</strong></td>
            <td colspan="4"><span style="display: inline-block; min-width: 50px; padding:2px">
        <?= htmlspecialchars($data6['guideline_rate'] ?? '') ?>
    </span></td>        </tr>
        <tr>
            <td>9a11(a).</td>
            <td  colspan="2"><strong>Prevailing Market Rate Range (Rs.)From</strong></td>
            <td>From</td>
            <td><span style="display: inline-block; min-width: 50px; padding:2px">
        <?= htmlspecialchars($data6['estimated_cost_rs'] ?? '') ?>
    </span></td>
            <td>To</td>
            <td colspan="2"><span style="display: inline-block; min-width: 50px; padding:2px">
        <?= htmlspecialchars($data6['estimated_cost_per_sqft'] ?? '') ?>
    </span></td>
        </tr>
        <tr>
            <td rowspan="2">9a10(b).</td>
            <td colspan="2" rowspan="2"> Market Reference for Land rates</td>
            <td>Property details & Broker Reference </td>
            <td>Area of property </td>
            <td>RATE</td>
            <td>Price</td>
        </tr>
        <tr>
            <td><span style="display: inline-block; min-width: 50px; padding:2px">
        <?= htmlspecialchars($data10['NA'] ?? '') ?>
    </span></td>
            <td><span style="display: inline-block; min-width: 50px; padding:2px">
        <?= htmlspecialchars($data10['NA'] ?? '') ?>
    </span></td>
            <td><span style="display: inline-block; min-width: 50px; padding:2px">
        <?= htmlspecialchars($data10['NA'] ?? '') ?>
    </span></td>
            <td><span style="display: inline-block; min-width: 50px; padding:2px">
        <?= htmlspecialchars($data10['NA'] ?? '') ?>
    </span></td>
        </tr>
        <tr>
            <td>9a11(b).</td>
            <td colspan="2">Area of Land /Plot/Unit (sqft.) </td>       
<td colspan="2"><span style="display: inline-block; min-width: 50px; padding:2px">
        <?= htmlspecialchars($data6['final_plot_square_feet'] ?? '') ?>
    </span></td>
        </tr>
        <tr>
            <td>9a12.</td>
            <td colspan="2"><strong>Rate Adopted for Valuation</strong></td>
            <td ><span style="display: inline-block; min-width: 50px; padding:2px">
        <?= htmlspecialchars($data6['final_plot_rate'] ?? '') ?>
    </span></td>
                        <td><input type="text" value="per sq.ft." readonly></td>
            <td><span style="display: inline-block; min-width: 50px; padding:2px">
        <?= htmlspecialchars($data10['NA'] ?? '') ?>
    </span></td>
            <td><span style="display: inline-block; min-width: 50px; padding:2px">
        <?= htmlspecialchars($data10['NA'] ?? '') ?>
    </span></td>
        </tr>
        <tr>
            <td>9a13.</td>
            <td colspan="2"><strong>Fair Market Value</strong></td>
            <td><span style="display: inline-block; min-width: 50px; padding:2px">
        <?= htmlspecialchars($data6['finally_plot_valuation'] ?? '') ?>
    </span></td>
            <td>Realisable Value (80%)</td>
            <td colspan="2"><input type="text" readonly name="valuation_80_percent" value="<?= isset($data6['finally_plot_valuation']) ? round(floatval($data6['finally_plot_valuation']) * 0.8, 2) : '' ?>">
</td>
        </tr>
    </table>
    <h3 id="highlight" style="margin-top:-10px;">CONSTRUCTION / APARTMENTS</h3>
    <table style="margin-top:-20px;">
        <tr>
            <td>9.b.1</td>
            <td><strong>Particulars</strong></td>
            <td><strong>As per Ownership Document</strong></td>
            <td><strong>As per Approved Plans & Permission</strong></td>
            <td colspan="2"><strong>As per Physical Visit</strong></td>
        </tr>
        <tr>
            <td>9.b.2</td>
            <td><strong>Usage</strong></td>
            <td><span style="display: inline-block; min-width: 50px; padding:2px">
        <?= htmlspecialchars($data4['approved_property_usage'] ?? '') ?>
    </span></td>
            <td><span style="display: inline-block; min-width: 50px; padding:2px">
        <?= htmlspecialchars($data10['NA'] ?? '') ?>
    </span></td>
            <td colspan="2"><span style="display: inline-block; min-width: 50px; padding:2px">
        <?= htmlspecialchars($data4['current_property_usage'] ?? '') ?>
    </span></td>
        </tr>
        <tr>
            <td>9.b.3</td>
            <td><strong>Structure</strong></td>
            <td><span style="display: inline-block; min-width: 50px; padding:2px">
        <?= htmlspecialchars($data4['structure_type'] ?? '') ?>
    </span></td>
            <td><span style="display: inline-block; min-width: 50px; padding:2px">
        <?= htmlspecialchars($data10['NA'] ?? '') ?>
    </span></td>
            <td colspan="2"><span style="display: inline-block; min-width: 50px; padding:2px">
        <?= htmlspecialchars($data4['structure_type'] ?? '') ?>
    </span></td>
        </tr>
        <tr>
            <td>9.b.4</td>
            <td><strong>No. of Storey</strong></td>
            <td><span style="display: inline-block; min-width: 50px; padding:2px">
        <?= htmlspecialchars($data8['actual_configuration_building'] ?? '') ?>
    </span></td>
            <td><span style="display: inline-block; min-width: 50px; padding:2px">
        <?= htmlspecialchars($data10['NA'] ?? '') ?>
    </span></td>
            <td colspan="2"><span style="display: inline-block; min-width: 50px; padding:2px">
        <?= htmlspecialchars($data8['actual_configuration_building'] ?? '') ?>
    </span></td>
        </tr>
        <tr>
            <td>9.b.5</td>
            <td><strong>Property Type</strong></td>
            <td><span style="display: inline-block; min-width: 50px; padding:2px">
        <?= htmlspecialchars($data4['approved_property_usage'] ?? '') ?>
    </span></td>
            <td><span style="display: inline-block; min-width: 50px; padding:2px">
        <?= htmlspecialchars($data10['NA'] ?? '') ?>
    </span></td>
            <td colspan="2"><span style="display: inline-block; min-width: 50px; padding:2px">
        <?= htmlspecialchars($data4['current_property_usage'] ?? '') ?>
    </span></td>
        </tr>
        <tr>
            <td>9.b.6</td>
            <td><strong>Completion/Occupancy Age</strong></td>
            <td><span style="display: inline-block; min-width: 50px; padding:2px">
        <?= htmlspecialchars($data2['age_of_property'] ?? '') ?>
    </span></td>
            <td><span style="display: inline-block; min-width: 50px; padding:2px">
        <?= htmlspecialchars($data10['NA'] ?? '') ?>
    </span></td>
            <td colspan="2"><span style="display: inline-block; min-width: 50px; padding:2px">
        <?= htmlspecialchars($data2['age_of_property'] ?? '') ?>
    </span></td>
        </tr>
        <tr>
            <td>9.b.7</td>
            <td><strong>Residual Age</strong></td>
            <td><span style="display: inline-block; min-width: 50px; padding:2px">
        <?= htmlspecialchars($data2['residual_age_of_property'] ?? '') ?>
    </span></td>
            <td><span style="display: inline-block; min-width: 50px; padding:2px">
        <?= htmlspecialchars($data10['NA'] ?? '') ?>
    </span></td>
            <td colspan="2"><span style="display: inline-block; min-width: 50px; padding:2px">
        <?= htmlspecialchars($data2['residual_age_of_property'] ?? '') ?>
    </span></td>
        </tr>
        <tr>
            <td>9.b.8</td>
            <td><strong>Carpet Area (SQFT)</strong></td>
            <td><span style="display: inline-block; min-width: 50px; padding:2px">
        <?= htmlspecialchars($data6['carpet_square_feet'] ?? '') ?>
    </span></td>
            <td><span style="display: inline-block; min-width: 50px; padding:2px">
        <?= htmlspecialchars($data10['NA'] ?? '') ?>
    </span></td>
            <td colspan="2"><span style="display: inline-block; min-width: 50px; padding:2px">
        <?= htmlspecialchars($data6['actual_carpet_square_feet'] ?? '') ?>
    </span></td>
        </tr>
        <tr>
            <td ROWSPAN="2">9.b.9</td>
            <td><strong>Carpet Area (in SQFT Only)</strong></td>
            <td><span style="display: inline-block; min-width: 50px; padding:2px">
        <?= htmlspecialchars($data10['NA'] ?? '') ?>
    </span></td>
            <td><span style="display: inline-block; min-width: 50px; padding:2px">
        <?= htmlspecialchars($data10['NA'] ?? '') ?>
    </span></td>
            <td colspan="2"><span style="display: inline-block; min-width: 50px; padding:2px">
        <?= htmlspecialchars($data10['NA'] ?? '') ?>
    </span></td>
        </tr>
        <tr>
        <td><strong>1.Loading used in %</strong></td>
            <td><span style="display: inline-block; min-width: 50px; padding:2px">
        <?= htmlspecialchars($data10['NA'] ?? '') ?>
    </span></td>
            <td><span style="display: inline-block; min-width: 50px; padding:2px">
        <?= htmlspecialchars($data10['NA'] ?? '') ?>
    </span></td>
            <td colspan="2"><span style="display: inline-block; min-width: 50px; padding:2px">
        <?= htmlspecialchars($data10['NA'] ?? '') ?>
    </span></td>
        </tr>
        <tr>
            <td rowspan="2">9.b.10</td>
            <td><strong>Built-up Area</strong></td>
            <td><span style="display: inline-block; min-width: 50px; padding:2px">
        <?= htmlspecialchars($data6['construction_square_feet'] ?? '') ?>
    </span></td>
            <td><span style="display: inline-block; min-width: 50px; padding:2px">
        <?= htmlspecialchars($data10['NA'] ?? '') ?>
    </span></td>
            <td colspan="2"><span style="display: inline-block; min-width: 50px; padding:2px">
        <?= htmlspecialchars($data6['actual_construction_square_feet'] ?? '') ?>
    </span></td> 
        </tr>
        <tr>
        <td><strong>1. Loading used in %</strong></td>
            <td><span style="display: inline-block; min-width: 50px; padding:2px">
        <?= htmlspecialchars($data10['NA'] ?? '') ?>
    </span></td>
            <td><span style="display: inline-block; min-width: 50px; padding:2px">
        <?= htmlspecialchars($data10['NA'] ?? '') ?>
    </span></td>
            <td colspan="2"><span style="display: inline-block; min-width: 50px; padding:2px">
        <?= htmlspecialchars($data10['NA'] ?? '') ?>
    </span></td>
        </tr>
        <tr>
            <td>9.b.11</td>
            <td><strong>Super Built-up Area/Saleable Area (in SQFT)</strong></td>
            <td><span style="display: inline-block; min-width: 50px; padding:2px">
        <?= htmlspecialchars($data6['saleable_square_feet'] ?? '') ?>
    </span></td>
            <td><span style="display: inline-block; min-width: 50px; padding:2px">
        <?= htmlspecialchars($data10['NA'] ?? '') ?>
    </span></td>
            <td colspan="2"><span style="display: inline-block; min-width: 50px; padding:2px">
        <?= htmlspecialchars($data6['actual_saleable_square_feet'] ?? '') ?>
    </span></td>       
         </tr>
         <tr>
            <td>9.b.12</td>
            <td><strong>Structural Condition</strong></td>
            <td colspan="2"><span style="display: inline-block; min-width: 50px; padding:2px">
        <?= htmlspecialchars($data2['structurally_fit'] ?? '') ?>
    </span></td>          
            <td colspan="2"><span style="display: inline-block; min-width: 50px; padding:2px">
        <?= htmlspecialchars($data10['NA'] ?? '') ?>
    </span></td>
        </tr>
        <tr>
         <td>9.b.13</td>
            <td><strong>Government Guideline Rate (Rs./sqft) </strong></td>
           <td colspan="4"><span style="display: inline-block; min-width: 50px; padding:2px">
        <?= htmlspecialchars($data6['guideline_rate'] ?? '') ?>
    </span></td>  
        </tr>
        <tr>
            <td>9.b.14</td>
            <td><strong>Final Area in SQFT Considered for Valuation</strong></td>
            <td><span style="display: inline-block; min-width: 50px; padding:2px">
        <?= htmlspecialchars($data6['final_construction_square_feet'] ?? '') ?>
    </span></td>
            <td><span style="display: inline-block; min-width: 50px; padding:2px">
        <?= htmlspecialchars($data10['NA'] ?? '') ?>
    </span></td>
            <td colspan="2"><span style="display: inline-block; min-width: 50px; padding:2px">
        <?= htmlspecialchars($data10['NA'] ?? '') ?>
    </span></td>  
      </tr>
         <tr>
            <td>9.b.15</td>
            <td><strong>5 Prevailing Market Rate Range(Rs./sqft)</strong></td>
            <td>From</td>
            <td><span style="display: inline-block; min-width: 50px; padding:2px">
        <?= htmlspecialchars($data6['justified_estimated_cost_per_sqft'] ?? '') ?>
    </span></td>
            <td>TO</td>
            <td><span style="display: inline-block; min-width: 50px; padding:2px">
        <?= htmlspecialchars($data6['adoptable_justified_estimated_cost'] ?? '') ?>
    </span></td>
      </tr>
      <tr>
        <td rowspan="3">9.b.16</td>
        <td rowspan="3"><strong>Market Reference for Property rates</strong></td>
        <td>Property details & Broker Reference</td>  
        <td>Area of property Sq.ft</td>
        <td>Rate(Rs.)</td>
        <td> Value Rs</td>
    </tr>
    <tr>
        <td><span style="display: inline-block; min-width: 50px; padding:2px">
        <?= htmlspecialchars($data10['NA'] ?? '') ?>
    </span></td>
        <td><span style="display: inline-block; min-width: 50px; padding:2px">
        <?= htmlspecialchars($data10['NA'] ?? '') ?>
    </span></td>
        <td><span style="display: inline-block; min-width: 50px; padding:2px">
        <?= htmlspecialchars($data10['NA'] ?? '') ?>
    </span></td>
        <td><span style="display: inline-block; min-width: 50px; padding:2px">
        <?= htmlspecialchars($data10['NA'] ?? '') ?>
    </span></td> 
    </tr>
     <tr>
        <td><span style="display: inline-block; min-width: 50px; padding:2px">
        <?= htmlspecialchars($data10['NA'] ?? '') ?>
    </span></td>
        <td><span style="display: inline-block; min-width: 50px; padding:2px">
        <?= htmlspecialchars($data10['NA'] ?? '') ?>
    </span></td>
        <td><span style="display: inline-block; min-width: 50px; padding:2px">
        <?= htmlspecialchars($data10['NA'] ?? '') ?>
    </span></td>
        <td><span style="display: inline-block; min-width: 50px; padding:2px">
        <?= htmlspecialchars($data10['NA'] ?? '') ?>
    </span></td> 
    </tr>
        <tr>
            <td>9.b.17</td>
            <td><strong>Rate Adopted for Valuation</strong></td>
            <td><span style="display: inline-block; min-width: 50px; padding:2px">
        <?= htmlspecialchars($data6['final_construction_rate'] ?? '') ?>
    </span></td>
            <td><span style="display: inline-block; min-width: 50px; padding:2px">
        <?= htmlspecialchars($data10['NA'] ?? '') ?>
    </span></td>
            <td colspan="2"><span style="display: inline-block; min-width: 50px; padding:2px">
        <?= htmlspecialchars($data10['NA'] ?? '') ?>
    </span></td>  
         </tr>
        <tr>
            <td>9.b.18</td>
            <td><strong>Depreciation (% Only)</strong></td>
            <td><span style="display: inline-block; min-width: 50px; padding:2px">
        <?= htmlspecialchars($data10['NA'] ?? '') ?>
    </span></td>
            <td><strong>Final Rate Post Depreciation </strong></td>
            <td colspan="2"><span style="display: inline-block; min-width: 50px; padding:2px">
        <?= htmlspecialchars($data10['NA'] ?? '') ?>
    </span></td>  
        </tr>
        <tr>
            <td>9.b.19</td>
            <td><strong>Fair Market Value</strong></td>
            <td><span style="display: inline-block; min-width: 50px; padding:2px">
        <?= htmlspecialchars($data6['finally_construction_valuation'] ?? '') ?>
    </span></td>
            <td><strong>Realisable Value </strong></td>
            <td colspan="2"> <input type="text" readonly name="valuation_80_percent" value="<?= isset($data6['finally_construction_valuation']) ? round(floatval($data6['finally_construction_valuation']) * 0.8, 2) : '' ?>"></td>
        </tr>
        <tr>
            <td>9.b.20</td>
            <td><strong>Distress Value (75%)</strong></td>
            <td colspan="4"><input type="text" readonly name="valuation_80_percent" value="<?= isset($data6['total_finally_area_valuation']) ? round(floatval($data6['total_finally_area_valuation']) * 0.75, 2) : '' ?>"></td>
            
        </tr>
        </table>
        <table style="margin-top:-8px;">
        <tr>
            <td rowspan="2">9.b.21</td>
            <td><strong>Unapproved Construction Value (SQFT)</strong></td>
            <td><strong>AREA</strong></td>
            <td><span style="display: inline-block; min-width: 50px; padding:2px">
        <?= htmlspecialchars($data10['NA'] ?? '') ?>
    </span></td>
            <td><strong>Rate (Rs/sqft)</strong></td>
            <td><span style="display: inline-block; min-width: 50px; padding:2px">
        <?= htmlspecialchars($data10['NA'] ?? '') ?>
    </span></td>
                    </tr>
                    <tr>
                        <td><strong>Value:</strong></td>
            <td colspan="4"><span style="display: inline-block; min-width: 50px; padding:2px">
        <?= htmlspecialchars($data10['NA'] ?? '') ?>
    </span></td>

                    </tr>
           <tr>
            <td>9.b.22</td>
            <td><strong>Internal and External Amenities</strong></td>
            <td><span style="display: inline-block; min-width: 50px; padding:2px">
        <?= htmlspecialchars($data6['addition_amenities_description_1'] ?? '') ?>  <?= htmlspecialchars($data6['addition_amenities_addition_amenities_description_2description_1'] ?? '') ?>  <?= htmlspecialchars($data6['addition_amenities_description_3'] ?? '') ?>  <?= htmlspecialchars($data6['addition_amenities_description_4'] ?? '') ?>
    </span></td>
            <td><strong>Details of Amenities to be Avoided</strong></td>
            <td><strong>Total Value of Amenities</strong></td>
            <td><span style="display: inline-block; min-width: 50px; padding:2px">
        <?= htmlspecialchars($data6['amenities_total'] ?? '') ?>
    </span></td>
        </tr>
   <tr>
    <td>9.b.23</td>
    <td><strong>Violation Observed </strong></td>
    <td><span style="display: inline-block; min-width: 50px; padding:2px">
        <?= htmlspecialchars($data10['NA'] ?? '') ?>
    </span></td>
    <td>Details</td>
    <td colspan="2"><span style="display: inline-block; min-width: 50px; padding:2px">
        <?= htmlspecialchars($data10['NA'] ?? '') ?>
    </span></td>
   </tr>
        <tr>
            <td>9.b.24</td>
            <td><strong>Demolition / Sealing Risk</strong></td>
            <td colspan="4"><span style="display: inline-block; min-width: 50px; padding:2px">
        <?= htmlspecialchars($data9['demolition_risk_1'] ?? '') ?>
    </span></td>
        </tr>
        <tr>
            <td>9.b.25</td>
            <td>Remarks on Last 3 years average price</td>
            <td colspan="4"><span style="display: inline-block; min-width: 50px; padding:2px">
        <?= htmlspecialchars($data10['NA'] ?? '') ?>
    </span></td>
        </tr>
        <tr>
            <td>9.b.26</td>
            <td><strong>Insurable Value of Property</strong></td>
            <td colspan="4"><span style="display: inline-block; min-width: 50px; padding:2px">
        <?= htmlspecialchars($data6['finally_construction_valuation'] ?? '') ?>
    </span></td>
        </tr>
    </table>
    <h3 id="highlight" style="margin-top:-10px;">SUMMARY</h3>
    <table style="margin-top:-20px;">
        <tr>
            <td rowspan="2">10</td>
            <td><strong>Land Value</strong></td>
            <td><strong>Buildup Area Value</strong></td>
            <td><strong>Amenities Cost</strong></td>
            <td><strong>Total Value of Property</strong></td>
        </tr>
        <tr>
            <td><span style="display: inline-block; min-width: 50px; padding:2px">
        <?= htmlspecialchars($data6['finally_plot_valuation'] ?? '') ?>
    </span></td>
            <td><span style="display: inline-block; min-width: 50px; padding:2px">
        <?= htmlspecialchars($data6['finally_construction_valuation'] ?? '') ?>
    </span></td>
            <td><span style="display: inline-block; min-width: 50px; padding:2px">
        <?= htmlspecialchars($data6['amenities_total'] ?? '') ?>
    </span></td>	
            <td><span style="display: inline-block; min-width: 50px; padding:2px">
        <?= htmlspecialchars($data6['total_finally_area_valuation'] ?? '') ?>
    </span></td>
        </tr>
        </table>
        <table style="margin-top:-10px;">
        <tr>
            <td>11</td>
            <td colspan="5"></td>
        </tr>
        </table>
        <table style="margin-top:-10px;">
        <tr>
            <td>12</td>
            <td><strong>Final Status</strong></td>
            <td><strong>Positive</strong></td>
            <td><strong>If Negative</strong></td>
            <td><span style="display: inline-block; min-width: 50px; padding:2px">
        <?= htmlspecialchars($data9['positive_report'] ?? '') ?>
    </span></td>	
        </tr>
        </table>
        <table style="margin-top:-20px;">
            <h3 style="margin-top:-10px;">Mandatory Requirements</h3>
            <tr>
                <td>a</td>
            <td><strong>Setback Deviation/Violation - Horizontal</strong></td>
            <td colspan="3"><span style="display: inline-block; min-width: 50px; padding:2px">
        <?= htmlspecialchars($data9['vertical_deviation'] ?? '') ?>
    </span></td>	
        </tr>
        <tr>
            <td>b</td>
            <td><strong>FSI Violation</strong></td>
            <td colspan="3"><span style="display: inline-block; min-width: 50px; padding:2px">
        <?= htmlspecialchars($data9['fsi_deviation'] ?? '') ?>
    </span></td>	
        </tr>
        <tr>
            <td>c</td>
            <td><strong>Locality Details</strong></td>
            <td><span style="display: inline-block; min-width: 50px; padding:2px">
        <?= htmlspecialchars($data2['class_of_locality'] ?? '') ?>
    </span></td>          
            <td><strong>Community Dominated</strong></td>
            <td><span style="display: inline-block; min-width: 50px; padding:2px">
        <?= htmlspecialchars($data2['NA'] ?? '') ?>
    </span></td>
        </tr>
        <tr>
            <td>d</td>
            <td><strong>Demolition Risk</strong></td>
            <td colspan="3"><span style="display: inline-block; min-width: 50px; padding:2px">
        <?= htmlspecialchars($data9['demolition_risk_1'] ?? '') ?>
    </span></td>
        </tr>
        <tr>
            <td>e</td>
            <td><strong>Property Enlisted For Any Negative Authority Action</strong></td>
            <td colspan="3"><span style="display: inline-block; min-width: 50px; padding:2px">
        <?= htmlspecialchars($data10['NA'] ?? '') ?>
    </span></td>
        </tr>
        </table>
        <table>

    
         <tr>
	<th colspan="6">REMARKS</th>
</tr>
<tr> 
    <td >14</td>
  <td><span style="white-space: pre-line; font-size:14px; display: block; text-align: left; padding: 0; margin: 0;font-weight:400;"readonly>
        <?= htmlspecialchars($data10['remarks'] ?? '') ?>
    </span></td>
</tr>
         <tr>
	<th colspan="6">DISCLAIMER-DECLARATION</th>
</tr>
<tr> 
    <td >15</td>
  <td><span style="white-space: pre-line; font-size:14px; display: block; text-align: left; padding: 0; margin: 0;font-weight:400;" readonly>
    <?= nl2br(htmlspecialchars(formatDeclaration($data10['declaration'] ?? ''))) ?>
</span></td>
</tr>
</table>
  <?php
function formatDeclaration($text) {
    // Insert a newline before every occurrence of a number followed by a dot and space (e.g., "1. ", "10. ")
    // Only if it's NOT already at the beginning of the string or a new line
    $text = preg_replace('/(?<!^)(?<!\n)(\d+\.\s)/', "\n$1", $text);
    return $text;
}
?>

<table>
<tr><th style="margin-bottom:-18px;">PHOTOGRAPH OF THE PROPERTY</tr></th></table>
<br>

    
<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

$servername = "localhost";
$username   = "root";
$password   = "";
$dbname     = "project_db";

$conn = new mysqli($servername, $username, $password, $dbname);
if ($conn->connect_error) {
    die("Connection failed: " . htmlspecialchars($conn->connect_error));
}

$reference_id = $_SESSION['reference_id'] ?? null;
$reference_id = $_GET['reference_id'] ?? $reference_id;

if ($reference_id) {

    // Map captions
    $captions = [
        'image1'  => 'EXTERNAL PHOTOS',
        'image2'  => 'Kitchen',
        'image3'  => 'Selfie',
        'image4'  => 'Electric Meter',
        'image6'  => 'Other 1',
        'image7'  => 'Other 2',
        'image8'  => 'Other 3',
        'image9'  => 'Other 4',
        'image10' => 'Other 5',
        'image11' => 'Other 6',
        'image12' => 'Other 7',
        'image13' => 'Other 8',
        'image14' => 'Other 9',
        'image15' => 'Other 10',
        'image16' => 'Other 11',
        'image17' => 'Other 12',
        'image18' => 'Other 13',
        'image19' => 'Other 14',
        'image20' => 'Other 15',
    ];

    // === Helper: EXIF-aware orientation detection ===
    function classify_orientation_after_exif(string $imageData): ?string {
        $size = @getimagesizefromstring($imageData);
        if (!$size || !isset($size[0], $size[1])) {
            return null;
        }
        $width  = (int)$size[0];
        $height = (int)$size[1];

        $mime = $size['mime'] ?? '';
        if ($mime === 'image/jpeg' && function_exists('exif_read_data')) {
            $tmp = @tempnam(sys_get_temp_dir(), 'exif_');
            if ($tmp !== false) {
                @file_put_contents($tmp, $imageData);
                $exif = @exif_read_data($tmp);
                @unlink($tmp);

                if (!empty($exif['Orientation'])) {
                    $orientation = (int)$exif['Orientation'];
                    if ($orientation === 6 || $orientation === 8) {
                        $t = $width; $width = $height; $height = $t;
                    }
                }
            }
        }
        return ($width >= $height) ? 'horizontal' : 'vertical';
    }

    // === Helper: Fix orientation physically with Imagick ===
    function fixImageOrientation($binaryData) {
        $img = new Imagick();
        $img->readImageBlob($binaryData);

        switch ($img->getImageOrientation()) {
            case Imagick::ORIENTATION_BOTTOMRIGHT:
                $img->rotateImage("#000", 180);
                break;
            case Imagick::ORIENTATION_RIGHTTOP:
                $img->rotateImage("#000", 90);
                break;
            case Imagick::ORIENTATION_LEFTBOTTOM:
                $img->rotateImage("#000", -90);
                break;
        }

        $img->setImageOrientation(Imagick::ORIENTATION_TOPLEFT);
        $fixed = $img->getImageBlob();
        $img->destroy();

        return $fixed;
    }

    $sql = "SELECT 
                image1, image2, image3, image4, 
                image6, image7, image8, image9, 
                image10, image11, image12, image13, image14, image15, image16, image17, image18, image19, image20
            FROM final_uploaded_images 
            WHERE reference_id = ?";

    $stmt = $conn->prepare($sql);
    if ($stmt === false) {
        die("Error preparing the SQL statement: " . htmlspecialchars($conn->error));
    }

    $stmt->bind_param("s", $reference_id);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result && $result->num_rows > 0) {
        $horizontal_images = [];
        $vertical_images   = [];

        while ($row = $result->fetch_assoc()) {
            foreach ($row as $key => $imageData) {
                if (!empty($imageData)) {

                    // Actually fix image before displaying
                    $fixedData = fixImageOrientation($imageData);

                    $orientation = classify_orientation_after_exif($fixedData) ?? 'horizontal';
                    $imgString   = base64_encode($fixedData);
                    $caption     = $captions[$key] ?? 'Image';

                    $item = [
                        'data'    => $imgString,
                        'caption' => $caption,
                        'alt'     => $key,
                    ];

                    if ($orientation === 'horizontal') {
                        $horizontal_images[] = $item;
                    } else {
                        $vertical_images[]   = $item;
                    }
                }
            }
        }

 
// Output as a stable 4-column table (works in wkhtmltopdf)
$all_images = array_merge($vertical_images, $horizontal_images);

echo '<table class="image-grid">';
$rows = array_chunk($all_images, 4);
foreach ($rows as $row) {
    echo '<tr>';
    foreach ($row as $img) {
        echo '<td>';
        echo '<div class="img-wrap">';
        echo '<img src="data:image/jpeg;base64,' . $img['data'] . '" alt="' . htmlspecialchars($img['alt']) . '">';
        echo '<div class="caption">' . htmlspecialchars($img['caption']) . '</div>';
        echo '</div>';
        echo '</td>';
    }
    // pad remaining cells to keep 4 columns
    $remaining = 4 - count($row);
    if ($remaining > 0) {
        echo str_repeat('<td></td>', $remaining);
    }
    echo '</tr>';
}
echo '</table>';

    } else {
        echo "<p style='text-align:center;'>No images found.</p>";
    }

    $stmt->close();
} else {
    echo "<p style='text-align:center;'>Reference ID is missing.</p>";
}
?>

    
      <table>
  </tr>
  <tr>

<div class="google-map-container">
<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "project_db";
$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$reference_id = $_SESSION['reference_id'] ?? null;
$reference_id = $_GET['reference_id'] ?? $reference_id;

if ($reference_id) {
    $sql = "SELECT image5 FROM final_uploaded_images WHERE reference_id = ?";
    $stmt = $conn->prepare($sql);
    if ($stmt === false) {
        die("Error preparing the SQL statement: " . $conn->error);
    }

    $stmt->bind_param("s", $reference_id);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows > 0) {
        $row = $result->fetch_assoc();
        if (!empty($row['image5'])) {
                          echo "<p style='text-align:center;'>Location cum Route map showing property boundaries</p>";

            echo '<div><img src="data:image/jpeg;base64,' . base64_encode($row['image5']) . '" alt="Google Map"><p>Google Map</p></div>';
        } else {
            echo "<p style='text-align:center;'>Google Map image not available.</p>";
        }
    } else {
        echo "<p style='text-align:center;'>No record found for Google Map image.</p>";
    }

    $stmt->close();
} else {
    echo "<p style='text-align:center;'>Reference ID is missing.</p>";
}
?>
</tr>
</div>
    </table>
    </table>
     <!-- <button onclick="window.print()">Download PDF</button> -->
    <form method="post">
  <input type="hidden" name="download_images" value="1">
  <button type="submit">Download All Images</button>
</form>
     <!-- <button onclick="window.print()">Download PDF</button> -->
  <button id="downloadPdf" onclick="setPrintMargins()">DOWNLOAD PDF</button>
  <script>
    document.getElementById('downloadPdf').addEventListener('click', () => {
      // Select the content you want to convert to PDF
      const element = document.getElementById('content');
      const options = {
        margin:[0,0],
        filename:'report.pdf',
        image: { type: 'jpeg', quality: 0.98 },
        html2canvas: { scale: 2 },
        jsPDF: { unit: 'in', format: 'letter', orientation: 'portrait' }
      };

      // Generate and download the PDF
      html2pdf().set(options).from(element).save();
    });
    function setPrintMargins() {
      const style = document.createElement('style');
      style.innerHTML = `
      @media print {
          body {
            margin:0.2;
          }
        }
      `;
      document.head.appendChild(style);
      window.print();
    }
    // Disable all input fields in the form
    document.querySelectorAll('input').forEach(function(input) {
        input.disabled = true;  // Disables the field completely
    });
    </script>
     </div>
    
</body>
</html>

