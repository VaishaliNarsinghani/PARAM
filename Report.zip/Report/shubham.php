<?php include('auth.php'); ?>
<?php include 'watermark.html'; ?>

<?php
ini_set('display_errors', 1);
error_reporting(E_ALL);

// Increase PHP execution time and memory limit
ini_set('max_execution_time', 600); // Increase execution time to 600 seconds (10 minutes)
ini_set('memory_limit', '4096M'); // Increase memory limit to 4096MB
// Start session

$servername = "localhost";
$username = "root";
$password = "";
$dbname = "project_db";

// Create DB connection
$conn = new mysqli($servername, $username, $password, $dbname);
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

if (!isset($_SESSION['reference_id'])) {
    die("Reference ID not found in session.");
}
$reference_id = $_SESSION['reference_id'];

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['download_images'])) {

    // Get customer name
    $stmt_name = $conn->prepare("SELECT customerName FROM mis WHERE reference_id = ?");
    $stmt_name->bind_param("s", $reference_id);
    $stmt_name->execute();
    $result_name = $stmt_name->get_result();
    $customerName = "customer";
    if ($row = $result_name->fetch_assoc()) {
        $customerName = preg_replace('/[^a-zA-Z0-9]/', '', $row['customerName']);
    }
    $stmt_name->close();

    // Fetch image BLOBs
    $stmt = $conn->prepare("SELECT image1, image2, image3, image4, image5, image6, image7, image8, image9, image10, image11, image12,image13, image14, image15, image16, image17, image18, image19, image20 FROM final_uploaded_images WHERE reference_id = ?");    $stmt->bind_param("s", $reference_id);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows > 0 && ($row = $result->fetch_assoc())) {
        $tempDir = sys_get_temp_dir() . DIRECTORY_SEPARATOR . uniqid('images_', true);
        mkdir($tempDir);

        $imageFiles = [];
        for ($i = 1; $i <= 12; $i++) {
            if (!empty($row["image$i"])) {
                $filename = $tempDir . DIRECTORY_SEPARATOR . "image{$i}.jpg";
                file_put_contents($filename, $row["image$i"]);
                $imageFiles[] = $filename;
            }
        }

        if (empty($imageFiles)) {
            die("No images to download.");
        }

        // Create ZIP
        $zipFileName = "images_" . preg_replace('/[^a-zA-Z0-9]/', '_', $reference_id) . "_{$customerName}.zip";
        $zipPath = $tempDir . DIRECTORY_SEPARATOR . $zipFileName;

        $zip = new ZipArchive();
        if ($zip->open($zipPath, ZipArchive::CREATE) !== TRUE) {
            die("Failed to create ZIP file.");
        }

        foreach ($imageFiles as $file) {
            $zip->addFile($file, basename($file));
        }
        $zip->close();

        // Send ZIP to browser
        header('Content-Type: application/zip');
        header('Content-Disposition: attachment; filename="' . basename($zipFileName) . '"');
        header('Content-Length: ' . filesize($zipPath));
        flush();
        readfile($zipPath);

        // Cleanup
        foreach ($imageFiles as $file) {
            unlink($file);
        }
        unlink($zipPath);
        rmdir($tempDir);
        exit;
    } else {
        echo "<p style='color:red;'>No image data found for this reference ID.</p>";
    }
}



// Debugging: Output for verification 
//echo "Session reference_id: " . htmlspecialchars($reference_id) . "<br>";


$page = isset($_GET['page']) ? $_GET['page'] : 1;
$limit = 50;
$offset = ($page - 1) * $limit;
$sql_property = "SELECT * FROM mis WHERE reference_id = ? LIMIT $limit OFFSET $offset";
$stmt_property = $conn->prepare($sql_property);
$stmt_property->bind_param("s", $reference_id);
$stmt_property->execute();
$result_property = $stmt_property->get_result();
$data1 = $result_property->fetch_assoc();




// Fetch data from property_details table
$sql_property = "SELECT * FROM property_details WHERE reference_id = ?";
$stmt_property = $conn->prepare($sql_property);
$stmt_property->bind_param("s", $reference_id);
$stmt_property->execute();
$result_property = $stmt_property->get_result();
$data2= $result_property->fetch_assoc();




// Fetch data from area_valuation table
$sql_area = "SELECT * FROM address_details WHERE reference_id = ?";
$stmt_area = $conn->prepare($sql_area); 
$stmt_area->bind_param("s", $reference_id);
$stmt_area->execute();
$result_area = $stmt_area->get_result();
$data3 = $result_area->fetch_assoc();





// Fetch data from area_valuation table
$sql_area = "SELECT * FROM critical_parameters WHERE reference_id = ?";
$stmt_area = $conn->prepare($sql_area); 
$stmt_area->bind_param("s", $reference_id);
$stmt_area->execute();
$result_area = $stmt_area->get_result();
$data4 = $result_area->fetch_assoc();

 
// Fetch data from area_valuation table
$sql_area = "SELECT * FROM surroundings_details WHERE reference_id = ?";
$stmt_area = $conn->prepare($sql_area); 
$stmt_area->bind_param("s", $reference_id);
$stmt_area->execute();
$result_area = $stmt_area->get_result();
$data5 = $result_area->fetch_assoc();
$stmt_area->close();
 
// Fetch data from area_valuation table
$sql_area = "SELECT * FROM area_valuation WHERE reference_id = ?";
$stmt_area = $conn->prepare($sql_area); 
$stmt_area->bind_param("s", $reference_id);
$stmt_area->execute();
$result_area = $stmt_area->get_result();
$data6 = $result_area->fetch_assoc();
$stmt_area->close();
 



// Fetch data from area_valuation table
$sql_area = "SELECT * FROM floor_details WHERE reference_id = ?";
$stmt_area = $conn->prepare($sql_area); 
$stmt_area->bind_param("s", $reference_id);
$stmt_area->execute();
$result_area = $stmt_area->get_result();
$data8= $result_area->fetch_assoc();
$stmt_area->close();
 


// Fetch data from area_valuation table
$sql_area = "SELECT * FROM technical_details WHERE reference_id = ?";
$stmt_area = $conn->prepare($sql_area); 
$stmt_area->bind_param("s", $reference_id);
$stmt_area->execute();
$result_area = $stmt_area->get_result();
$data9 = $result_area->fetch_assoc();
$stmt_area->close();
 
// Fetch data from area_valuation table
$sql_area = "SELECT * FROM remarks_table WHERE reference_id = ?";
$stmt_area = $conn->prepare($sql_area); 
$stmt_area->bind_param("s", $reference_id);
$stmt_area->execute();
$result_area = $stmt_area->get_result();
$data10 = $result_area->fetch_assoc();
$stmt_area->close();


// Step 1: Fetch the engineer_id from the mis table
$sql_mis = "SELECT engineer_id FROM mis WHERE reference_id = ?";
$stmt_mis = $conn->prepare($sql_mis);
$stmt_mis->bind_param("s", $reference_id);
$stmt_mis->execute();
$result_mis = $stmt_mis->get_result();
$row_mis = $result_mis->fetch_assoc();
$stmt_mis->close(); 

if ($row_mis) {
    $engineer_id = $row_mis['engineer_id'];

    // Step 2: Fetch the engineer's name from engineer_login table
    $sql_engineer = "SELECT name FROM engineer_login WHERE engineer_id = ?";
    $stmt_engineer = $conn->prepare($sql_engineer);
    $stmt_engineer->bind_param("s", $engineer_id);
    $stmt_engineer->execute();
    $result_engineer = $stmt_engineer->get_result();
    $row_engineer = $result_engineer->fetch_assoc();
    $stmt_engineer->close();

    if ($row_engineer) {
        $engineer_name = $row_engineer['name'];
         //echo "Engineer Name: " . $engineer_name;
    } else {
        echo "Engineer not found.";
    }
} else {
    echo "No engineer assigned for this reference_id.";
}



// Step 1: Fetch the engineer_id from the mis table
$sql_mis = "SELECT report_id FROM mis WHERE reference_id = ?";
$stmt_mis = $conn->prepare($sql_mis);
$stmt_mis->bind_param("s", $reference_id);
$stmt_mis->execute();
$result_mis = $stmt_mis->get_result();
$row_mis = $result_mis->fetch_assoc();
$stmt_mis->close(); 

if ($row_mis) {
    $report_id = $row_mis['report_id'];

    // Step 2: Fetch the engineer's name from engineer_login table
    $sql_engineer = "SELECT name FROM report_login WHERE report_id = ?";
    $stmt_engineer = $conn->prepare($sql_engineer);
    $stmt_engineer->bind_param("s", $report_id);
    $stmt_engineer->execute();
    $result_engineer = $stmt_engineer->get_result();
    $row_engineer = $result_engineer->fetch_assoc();
    $stmt_engineer->close();

    if ($row_engineer) {
        $report_name = $row_engineer['name'];
         //echo "Engineer Name: " . $report_name;
    } else {
        echo "Engineer not found.";
    }
} else {
    echo "No engineer assigned for this reference_id.";
}


// Step 1: Fetch the engineer_id from the mis table
$sql_mis = "SELECT report_drafter_to_technical FROM mis WHERE reference_id = ?";
$stmt_mis = $conn->prepare($sql_mis);
$stmt_mis->bind_param("s", $reference_id);
$stmt_mis->execute();
$result_mis = $stmt_mis->get_result();
$row_mis = $result_mis->fetch_assoc();
$stmt_mis->close(); 

if ($row_mis) {
    $report_drafter_to_technical = $row_mis['report_drafter_to_technical'];

    // Step 2: Fetch the engineer's name from engineer_login table
    $sql_engineer = "SELECT name FROM technical_login WHERE technical_manager_id = ?";
    $stmt_engineer = $conn->prepare($sql_engineer);
    $stmt_engineer->bind_param("s", $report_drafter_to_technical);
    $stmt_engineer->execute();
    $result_engineer = $stmt_engineer->get_result();
    $row_engineer = $result_engineer->fetch_assoc();
    $stmt_engineer->close();

    if ($row_engineer) {
        $technical_name = $row_engineer['name'];
        //echo "Engineer Name: " . $technical_name;
    } else {
        echo "Engineer not found.";
    }
} else {
    echo "No engineer assigned for this reference_id.";
}
?>

<!DOCTYPE html>
<html>
<head>
        <title>Shubham housing Report</title>
        <link rel="shortcut icon" href="favicon.png" type="image/x-icon"> 
  <style>
    body {
      font-family: 'Segoe UI', sans-serif;
      font-size: 14px;
    }
    
header {
  display: flex;
  align-items: center;
}

.logo img {
  width:170px;
  margin-left:30px;
  margin-bottom:-20px;
    margin-top:-30px;
  height: auto;
}
    .header-content {
  text-align: right;
  flex: 1;
  margin-left:-190x
}

header h1 {
  margin: 0;
  font-weight:700;
  font-size:20px;
 color: #0A4A87; 
 font-family: Georgia, serif;
  margin-right:13px;
}

header p {
  margin: 2px 0;
  font-size:15px;
  font-weight: bolder;
  color:rgb(244, 145, 5);
  font-family: Georgia, serif;
  margin-right:10px;
  
}
    table {
      width: 100%;
      border-collapse: collapse;
      margin-bottom: 20px;
    }
    th {
        background-color:#0A4A87;
      font-family: Georgia, serif;
      color: white;
      text-align:center;
      padding: 8px;
      font-weight: bold;
      font-size: 16px;
    }
    td {
      border: 1px solid #ccc;
      padding: 6px 10px;
      vertical-align: top;
    }
    .input {
      width: 100%;
      border: none;
      font-family: inherit;
      font-size: 14px;
      padding: 4px;
    }
    .section-heading {
      background-color: #0A4A87;
      color: white;
      font-weight: bold;
      text-align: center;
      padding: 8px;
      font-size: 16px;
    }
    .sub-heading {
      background-color: #f2f2f2;
      font-weight: bold;
    }
    
   button{
  padding:8px;
  margin-left:45%;
  background-color:rgb(171, 208, 238);
  font-weight:500;
  font-style:italic;
}
button:hover{
  background-color:#f2f2f2 ;
}
@media print{
  body{
    margin:0;
  }
  button{
    display:none;
    margin-left:30%;
  }

  }             
button{
  padding:8px;
  margin-left:45%;
  background-color:#99c3ee ;
  font-weight:500;
  font-style:italic;
}
button:hover{
  background-color:#DDD9C3 ;
}
@media print{
  body{
    margin:0;
  }
  button{
    display:none;
    margin-left:30%;
  }

}
  </style>
  <style>
.container {
    max-width: 1200px;
    margin: 20px auto;
    margin-top:-51px;
    padding: 20px;
    background-color: white;
    box-shadow: 0px 0px 10px rgba(0, 0, 0, 0.1);
    border-radius: 8px;
}

.title {
    text-align: center;
    font-size: 24px;
    font-weight: bold;
    margin-bottom: 20px;
}
.grid-container {
    display: grid;
    grid-template-columns: repeat(4, 1fr);
    gap: 15px;
}

.grid-item {
    position: relative;
    border-radius: 8px;
    overflow: hidden;
    box-shadow: 0px 4px 6px rgba(0, 0, 0, 0.1);
}

.grid-item img {
    width: 100%;
    height: 200px;
    object-fit: cover;
    transition: transform 0.3s ease;
}
.grid-item:hover img {
    transform: scale(1.05);
}

.overlay {
    position: absolute;
    bottom: 0;
    left: 0;
    background: rgba(0, 0, 0, 0.6);
    color: white;
    width: 100%;
    padding: 8px;
    font-size: 14px;
    text-align: center;
}
 
     
/* Force a stable 4-column grid that wkhtmltopdf respects */
.image-gallery { width: 100%; }
.image-grid { width: 100%; border-collapse: collapse; table-layout: fixed; }
.image-grid tr { page-break-inside: avoid; }
.image-grid td { width: 25%; padding: 6px; vertical-align: top; }

.image-grid .img-wrap { display: block; }
.image-grid img { display: block; width: 100%; height: auto; }
.image-grid .caption { font-size: 12px; text-align: center; margin-top: 4px; }

/* If you had a flex layout before, neutralize it */
.image-gallery { display: block !important; }



    /* Print-specific rules */
    @media print {
      .no-print {
        display: none !important;
      }

      body {
        margin: 0;
      }
 
    }
  button{
    padding:8px;
    margin-left:45%;
    background-color:#808485;
    color:white;
    font-weight:700;
    font-style:italic;
  }
  button:hover{
    background-color:rgba(216,216,216,255);
    color:white;
  }

/* Optional: Google map styling */
    .google-map-container {
      max-width: 90%;
      margin: 20px auto;
      border: 2px solid #ccc;
      padding: 10px;
      box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
      background-color: #f9f9f9;
      border-radius: 8px;
      text-align: center;
    }

    .google-map-container img {
      max-width: 100%;
      height: auto;
      display: inline-block;
      border: 1px solid #999;
      border-radius: 4px;
    }
    
.logo img {
  width: 120px;
  margin-left:30px;
  height: auto;
}
 </style>
</head>
<body>
<div class="content">
    <header>
      <div class="logo">
        <img src="images/Shubham.png" alt="Shubham Logo">
      </div>
      <div class="header-content">
        <h1>Shubham Housing Development Finance Company Ltd.</h1>
        <p>NON APF REPORT</p>
      </div>
    </header>
<table>
  <tr><th colspan="4">APPLICATION DETAILS</th></tr>
  <tr>
    <td>Date of Visit</td>
    <td colspan="3"><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data1['fe_to_coordinator_assign_at'] ?? '') ?></span></td>
    </tr>
    <tr>
    <td>Application Number</td>
    <td colspan="3"><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data1['applicationNo'] ?? '') ?></span></td>
  </tr>
  <tr>
    <td>Branch</td>
    <td colspan="3"><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data1['bank_branchname'] ?? '') ?></span></td>
  </tr>
  <tr>
    <td>Name of Applicant</td>
  <td colspan="3"><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data1['customerName'] ?? '') ?>
    </span></td>  </tr>
  <tr>
    <td>Property Owner Name as Per Legal Document</td>
    <td colspan="3"><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data9['owner_name'] ?? '') ?></span></td>
  </tr>
  <tr>
    <td>Loan Type/Product</td>
    <td colspan="3"><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data1['caseType'] ?? '') ?></span></td>
    </tr>
    <tr>
    <td>Person Met at Site Details</td>
    <td colspan="3"><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data2['person_meet_at_site_contact'] ?? '') ?></span></td>
  </tr>
  <tr>
    <td>Contact No.</td>
    <td colspan="3"><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data1['customerMob'] ?? '') ?></span></td>
  </tr>
  <tr>
    <td>Property Address as Per Site with Pin Code</td>
<td colspan="3"><span style="display: inline-block; min-width: 50px; padding: 2px;" readonly>
        <?= htmlspecialchars($data3['address_per_site'] ?? '') ?>    <?= htmlspecialchars($data3['pin_code'] ?? '') ?>
    </span></td>  </tr>
  <tr>
    <td>Property Address as Per Legal Documents</td>
<td colspan="3"><span style="display: inline-block; min-width: 50px; padding: 2px;" readonly>
        <?= htmlspecialchars($data3['address_per_document'] ?? '') ?> 
    </span></td>   </tr>
  <tr>
    <td>Property Address as per ATS (in HL cases)</td>
    <td colspan="3"><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data10['NA'] ?? '') ?></span></td>
  </tr>
  <tr>
    <td>Detail to be mentioned if address is different as per Site, Doc..</td>
    <td><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data10['NA'] ?? '') ?></span></td>
    <td>Nearby Landmark</td>
       <td><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data3['landmark_1'] ?? '') ?></span></td>
</td>
  </tr>
  <tr>
    <td>Classification of Area (Urban/Rural)</td>
    <td><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data10['NA'] ?? '') ?></span></td>
    <td>Within MC Limit</td>
    <td><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data3['property_location_in'] ?? '') ?></span></td>
  </tr>
  <tr>
    <td>Jurisdiction/Local Municipal Body</td>
    <td><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data10['NA'] ?? '') ?></span></td>
    <td>Property falling in area</td>
    <td><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data3['property_location_in'] ?? '') ?></span></td>


  </tr>
  <tr>
    <td>Marketability</td>
    <td><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data9['markebility'] ?? '') ?></span></td>
    <td>Property Holding Type</td>
    <td><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data2['property_leasehold_freehold'] ?? '') ?></span></td>
  </tr>
  <tr>
    <td>Property Usage</td>
    <td><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data4['current_property_usage'] ?? '') ?></span></td>
    <td>Type of Property</td>
    <td><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data2['property_unit_type'] ?? '') ?></span></td>
  </tr>
  
  <tr>
    <td>Occupancy Status</td>
    <td><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data2['occupancy_status'] ?? '') ?></span></td>
    <td>Development of Surroundings (%)</td>
    <td><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data2['develop_percent'] ?? '') ?></span></td>
  </tr>
  <tr>

    <td>No. of Tenants</td>
    <td><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data10['NA'] ?? '') ?></span></td>
    <td>Occupancy level in Building</td>
    <td><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data2['occupancy_status'] ?? '') ?></span></td>
  </tr>
  <tr>
    <td>Type of Locality</td>
    <td><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data2['class_of_locality'] ?? '') ?></span></td>
    <td>Third Party Check</td>
    <td><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data10['NA'] ?? '') ?></span></td>
  </tr>
  <tr>
    <td>Report prepared by</td>
    <td colspan="3"><input class="input" type="text" readonly  value="<?=  $report_name ?>"></td>
  </tr>
  <tr>
    <td>New/Other APP ID & Product</td>
    <td colspan="3"><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data10['NA'] ?? '') ?></span></td>
  </tr>
  <tr>
    <td>Third Party Check Remarks</td>
    <td colspan="3"><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data10['NA'] ?? '') ?></span></td>
  </tr>
  <tr>
    <td>Document Provided Name</td>
    <td><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data9['list_documents'] ?? '') ?></span></td>
    <td>Description</td>
    <td><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data9['seller_name'] ?? '') ?>,  <?= htmlspecialchars($data9['owner_name'] ?? '') ?></span></td>
  </tr>
</table>

<!-- BOUNDARY DETAILS -->
<table style="margin-top:-20px;">
  <tr><th colspan="4">BOUNDARY DETAILS OF PROPERTY</th></tr>
  <tr class="sub-heading">
    <td>Boundaries</td>
    <td>As per Legal Documents</td>
    <td>Flat Boundaries (As per Site)</td>
    <td>Building/Plot Boundaries (As per Site)</td>
  </tr>
  <tr>
    <td>North</td>
    <td><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data3['direction_as_per_document_north'] ?? '') ?></span></td>
    <td><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data3['direction_as_per_site_north'] ?? '') ?></span></td>
    <td><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data3['direction_as_per_site_north'] ?? '') ?></span></td>
  </tr>
  <tr>
    <td>South</td>
    <td><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data3['direction_as_per_document_south'] ?? '') ?></span></td>
    <td><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data3['direction_as_per_site_south'] ?? '') ?></span></td>
    <td><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data3['direction_as_per_site_south'] ?? '') ?></span></td>
  </tr>
  <tr>
    <td>East</td>
    <td><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data3['direction_as_per_document_east'] ?? '') ?></span></td>
    <td><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data3['direction_as_per_site_east'] ?? '') ?></span></td>
    <td><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data3['direction_as_per_site_east'] ?? '') ?></span></td>
  </tr>
    <tr>
    <td>West</td>
    <td><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data3['direction_as_per_document_west'] ?? '') ?></span></td>
    <td><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data3['direction_as_per_site_west'] ?? '') ?></span></td>
    <td><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data3['direction_as_per_site_west'] ?? '') ?></span></td>
  </tr>
    <tr>
    <td>Boundaries Matching</td>
    <td><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data3['boundaries_matching'] ?? '') ?></span></td>
     <td>Comments</td>
    <td><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data10['NA'] ?? '') ?></span></td>
  </tr>
  <tr>
    <td>Access Road Width</td>
    <td><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data2['width_of_approach_road'] ?? '') ?></span></td>
  <td>Road Type</td>
    <td><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data2['type_of_approach_road'] ?? '') ?></span></td>
  </tr>
</table>

<!-- GENERAL PROPERTY DETAILS -->
<table style="margin-top:-20px;">
  <tr><th colspan="4">GENERAL PROPERTY DETAILS</th></tr>
  <tr>
    <td>Property/Building/Tower Structure</td>
    <td><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data4['structure_type'] ?? '') ?></span></td>
    <td>No. of Wings</td>
    <td><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data10['NA'] ?? '') ?></span></td>
  </tr>
  <tr>
    <td>No. of units/per floor</td>
    <td><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data8['number_of_units_each_floor'] ?? '') ?></span></td>
    <td>Year of completion of property</td>
    <td><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data2['year_of_construction'] ?? '') ?></span></td>
  </tr>
  <tr>
    <td>Residual Age of property</td>
    <td><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data2['residual_age_of_property'] ?? '') ?></span></td>
    <td>Construction Stage of Property (%)</td>
    <td><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data8['stage_construction_actual_present_completion'] ?? '') ?></span></td>
  </tr>
  <tr>
    <td>Construction Stage of Property recommended (%)</td>
    <td><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data8['stage_construction_recommend_present_completion'] ?? '') ?></span></td>
    <td>Total no. of units in building</td>
    <td><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data10['NA'] ?? '') ?></span></td>
  </tr>
  <tr>
    <td>Sanction Plan</td>
    <td><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data9['floor_availability'] ?? '') ?></span></td>
    <td>Property Located at floor no.</td>
    <td><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars('Refer Address') ?></span></td>
  </tr>
  <tr>
    <td>Age of property</td>
    <td><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data2['age_of_property'] ?? '') ?></span></td>
    <td>Flat/Floor Accommodation</td>
    <td><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data8['actual_configuration_building'] ?? '') ?></span></td>
  </tr>
  <tr>
    <td>No. of lifts</td>
    <td><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data8['number_of_lifts'] ?? '') ?></span></td>
    <td>Construction Quality</td>
    <td><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars('Average') ?></span></td>
  </tr>
  <tr>
    <td>Type of Structure</td>
    <td colspan="3"><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data4['structure_type'] ?? '') ?></span></td>
  </tr>
</table>

<!-- PROPERTY AREA DETAILS -->
<table style="margin-top:-20px;">
  <tr><th colspan="4">PROPERTY AREA DETAILS</th></tr>
  <tr>
    <td>Property Area details</td>
    <td>As per Legal Documents</td>
    <td>As Per Plan/ATS</td>
    <td>As Per Site Visit</td>
  </tr>
  <tr>
    <td>East to West</td>
    <td><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data6['dimension_as_per_document_north'] ?? '') ?></span></td>
    <td><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data10['NA'] ?? '') ?></span></td>
    <td><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data6['dimension_as_per_site_north'] ?? '') ?></span></td>
  </tr>
  <tr>
    <td>North to South</td>
    <td><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data6['dimension_as_per_document_east'] ?? '') ?></span></td>
    <td><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data10['NA'] ?? '') ?></span></td>
    <td><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data6['dimension_as_per_site_east'] ?? '') ?></span></td>
  </tr>
  <tr>
    <td>Total Property Area in Sq.Ft.</td>
    <td><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data6['plot_square_feet'] ?? '') ?></span></td>
    <td><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data10['NA'] ?? '') ?></span></td>
    <td><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data6['actual_plot_square_feet'] ?? '') ?></span></td>
  </tr>
  <tr>
    <td>Property Area Matching</td>
    <td colspan="3"><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data10['NA'] ?? '') ?></span></td>
  </tr>
</table>

<!-- FLOORWISE AREA DETAILS -->
<table style="margin-top:-20px;">
  <tr><th colspan="8">FLOORWISE AREA DETAILS</th></tr>
  <tr>
    <td>Floor Details</td>
    <td>Carpet Area Per Legal Docs (Sq.Ft)</td>
    <td>Carpet Area Per Site Visit (Sq.Ft)</td>
    <td>Measured Builtup Area (Sq.Ft)</td>
    <td>Estimate Area Given (Sq.Ft)</td>
    <td>Permissible / Plan Area (Sq.Ft)</td>
    <td>Area Adopted for Calculation (Sq.Ft)</td>
    <td>Floorwise Accommodation Details</td>
  </tr>
  <tr>
    <td>GF</td>
    <td><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data10['NA'] ?? '') ?></span></td>
    <td><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data10['NA'] ?? '') ?></span></td>
    <td><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data10['NA'] ?? '') ?></span></td>
    <td><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data10['NA'] ?? '') ?></span></td>
    <td><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data8['ground_permissible'] ?? '') ?></span></td>
    <td><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data8['ground_actual'] ?? '') ?></span></td>
    <td><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data10['NA'] ?? '') ?></span></td>
  </tr>
  <tr>
    <td>FF</td>
    <td><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data10['NA'] ?? '') ?></span></td>
    <td><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data10['NA'] ?? '') ?></span></td>
    <td><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data10['NA'] ?? '') ?></span></td>
    <td><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data10['NA'] ?? '') ?></span></td>
    <td><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data8['first_permissible'] ?? '') ?></span></td>
    <td><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data8['first_actual'] ?? '') ?></span></td>
    <td><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data10['NA'] ?? '') ?></span></td>
  </tr>
  <tr>
    <td>Total Built-Up Area</td>
    <td colspan="6"><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data6['final_construction_square_feet'] ?? '') ?></span></td>
    <td><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data10['NA'] ?? '') ?></span></td>
  </tr>
  <tr>
    <td>Risk of Demolition</td>
    <td colspan="7"><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data9['demolition_risk_1'] ?? '') ?></span></td>
  </tr>
</table>

<!-- VALUE DETAILS -->
<table style="margin-top:-20px;">
  <tr><th colspan="4">VALUE DETAILS</th></tr>
  <tr>
    <td>Item</td>
    <td>Area Details in Sq.Ft.</td>
    <td>Rate Per Sq.Ft.</td>
    <td>Total Value (INR)</td>
  </tr>
  <tr>
    <td>(A) Adopted Land/Plot Area</td>
    <td><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data6['final_plot_square_feet'] ?? '') ?></span></td>
    <td><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data6['final_plot_rate'] ?? '') ?></span></td>
    <td><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data6['finally_plot_valuation'] ?? '') ?></span></td>
  </tr>
  <tr>
    <td>(B) Total Built Up Area</td>
    <td><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data6['final_construction_square_feet'] ?? '') ?></span></td>
    <td><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data6['final_construction_rate'] ?? '') ?></span></td>
    <td><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data6['finally_construction_valuation'] ?? '') ?></span></td>
  </tr>
   <tr>
    <td>(B) Total Super Built Up Area</td>
    <td><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data6['final_area_square_feet'] ?? '') ?></span></td>
    <td><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data6['final_area_rate'] ?? '') ?></span></td>
    <td><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data6['final_area_valuation'] ?? '') ?></span></td>
  </tr>
  <tr>
    <td>Estimate submitted for renovation / Construction</td>
    <td colspan="3"><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data10['NA'] ?? '') ?></span></td>
  </tr>
   <tr>
<td>(C)Car Parking/Amenities/Other Cost </td>    
    <td colspan="3"><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data6['car_parking_amount'] ?? '') ?></span></td>
  </tr>
     <tr>
<td>Realisable Value of the Property (INR)</td>    
    <td colspan="3"><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data6['total_finally_area_valuation'] ?? '') ?></span></td>
  </tr>
     <tr>
<td>Distress Value (%) </td>    
    <td colspan="3"><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data6['distress_value_percent'] ?? '') ?></span></td>
  </tr>
     <tr>
<td>Distress Value (INR) </td>    
    <td colspan="3"><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data6['total_distress_value'] ?? '') ?></span></td>
  </tr>
</table>
<table style="margin-top:-20px;">
  <tr><th colspan="4">GOVT. VALUE/CIRCLE RATE</th></tr>
  <tr>
    <td>Item</td>
    <td>Area Details in Sq.Ft.</td>
    <td>Rate Per Sq.Ft.</td>
    <td>Total Value (INR)</td>
  </tr>
  <tr>
    <td>Land/Plot Area</td>
    <td><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data6['gov_plot_area_sqft'] ?? '') ?></span></td>
    <td><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data6['gov_plot_area_rate'] ?? '') ?></span></td>
    <td><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data6['gov_plot_area_valuation'] ?? '') ?></span></td>
  </tr>
  <tr>
    <td>Total Built Up Area</td>
    <td><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data6['gov_builtup_area_sqft'] ?? '') ?></span></td>
    <td><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data6['gov_builtup_area_rate'] ?? '') ?></span></td>
    <td><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data6['gov_builtup_area_valuation'] ?? '') ?></span></td>
  </tr>
    <tr>
    <td>Total Super Built Up Area</td>
    <td><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data6['gov_saleable_area_sqft'] ?? '') ?></span></td>
    <td><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data6['gov_saleable_area_rate'] ?? '') ?></span></td>
    <td><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data6['gov_saleable_area_valuation'] ?? '') ?></span></td>
  </tr>
  <tr>
    <td>Total Govt. Value</td>
    <td colspan="3"><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data6['gov_final_area_valuation'] ?? '') ?></span></td>
  </tr>
</table>

<!-- MICRO MARKET DETAILS -->
<table style="margin-top:-20px;">
  <tr><th colspan="4">MICRO MARKET DETAILS</th></tr>
  <tr>
    <td>State</td>
     <td><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data3['address_line_4_as_per_doc'] ?? '') ?></span></td>
    <td>Location Type</td>
    <td><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data10['NA'] ?? '') ?></span></td>
  </tr>
  <tr>
    <td>City/District</td>
     <td><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data3['address_line_3_as_per_doc'] ?? '') ?></span></td>
    <td>Location (Scheme/Colony/Village)</td>
    <td><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars('Refer Address') ?></span></td>
  </tr>
  <tr>
    <td>Pin Code</td>
    <td colspan="3"><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data3['pin_code'] ?? '') ?></span></td>
  </tr>
</table>

<!-- ADDITIONAL CHECKS -->
<table style="margin-top:-20px;">
  <tr><th colspan="4">ADDITIONAL CHECKS</th></tr>
  <tr>
    <td>Location/Zone</td>
    <td><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data10['NA'] ?? '') ?></span></td>
    <td>Distance from Branch</td>
    <td><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data3['distance_from_branch_kms'] ?? '') ?></span></td>
  </tr>

  <tr>
    <td>Distance From Corporation Limits</td>
    <td><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data10['NA'] ?? '') ?></span></td>
    <td>Electricity in Colony</td>
    <td><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data10['NA'] ?? '') ?></span></td>
  </tr>
  <tr>
    <td>Water Supply</td>
    <td><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data10['NA'] ?? '') ?></span></td>
    <td>Sewer Provision</td>
    <td><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data10['NA'] ?? '') ?></span></td>
  </tr>
  <tr>
    <td>Sever Line Connected</td>
    <td><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data10['NA'] ?? '') ?></span></td>
    <td>Distance from City Center</td>
    <td><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data3['nearest_bus_stop_distance'] ?? '') ?></span></td>
  </tr>
  <tr>
    <td>Electricity in Property</td>
    <td><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data10['NA'] ?? '') ?></span></td>
    <td>Metre No.</td>
    <td><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data2['electric_meter_no'] ?? '') ?></span></td>
  </tr>
</table>

<!-- NDMA PARAMETERS -->
<table style="margin-top:-20px;">
  <tr><th colspan="4">NDMA PARAMETERS</th></tr>
  <tr>
    <td>Nature of building/wing</td>
    <td><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data4['structure_type'] ?? '') ?></span></td>
    <td>Concrete grade</td>
    <td><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data10['NA'] ?? '') ?></span></td>
  </tr>
  <tr>
    <td>Soil strata</td>
    <td><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data10['NA'] ?? '') ?></span></td>
    <td>Plan aspect ratio</td>
    <td><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data10['NA'] ?? '') ?></span></td>
  </tr>
  <tr>
    <td>Structural system</td>
    <td><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data10['NA'] ?? '') ?></span></td>
    <td>Soil liquefiable</td>
    <td><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data10['NA'] ?? '') ?></span></td>
  </tr>
  <tr>
    <td>Flood prone area</td>
    <td><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data10['NA'] ?? '') ?></span></td>
    <td>Structure type</td>
    <td><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data4['structure_type'] ?? '') ?></span></td>
  </tr>
  <tr>
    <td>Footing type</td>
    <td><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data10['NA'] ?? '') ?></span></td>
    <td>Soil type</td>
    <td><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars('Black Cotton Soil') ?></span></td>
  </tr>
  <tr>
    <td>Fire exit</td>
    <td><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data10['NA'] ?? '') ?></span></td>
    <td>Ground slope > 20%</td>
    <td><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data10['NA'] ?? '') ?></span></td>
  </tr>
  <tr>
    <td>Shape of building</td>
    <td><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data10['NA'] ?? '') ?></span></td>
    <td>Roof type</td>
    <td><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data4['roof_type'] ?? '') ?></span></td>
  </tr>
  <tr>
    <td>Seismic zone</td>
    <td><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data4['seismic_zone'] ?? '') ?></span></td>
    <td>Slope vulnerable to landslide</td>
    <td><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data10['NA'] ?? '') ?></span></td>
  </tr>
  <tr>
    <td>Type of Masonry</td>
    <td><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars('Brick Masonary') ?></span></td>
    <td>Steel Grade</td>
    <td><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data10['NA'] ?? '') ?></span></td>
  </tr>
  <tr>
    <td>Cyclone/Wind Speed Zone</td>
    <td><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data10['NA'] ?? '') ?></span></td>
    <td>Exposure Condition</td>
    <td><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data10['NA'] ?? '') ?></span></td>
  </tr>
  <tr>
    <td>Expansion joint available</td>
    <td><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data10['NA'] ?? '') ?></span></td>
    <td>Mortar Type</td>
    <td><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars('Cement') ?></span></td>
  </tr>
  <tr>
    <td>Costal regulatory zone </td>
    <td colspan="3"><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data10['NA'] ?? '') ?></span></td>
  </tr>
</table>

<!-- REMARKS/OBSERVATIONS -->
<table style="margin-top:-20px;">
  <tr><th colspan="4">REMARKS/DEVIATION/OBSERVATION</th></tr>
  <tr>
     <td colspan="4"><span style="white-space: pre-line; font-size:14px; display: block; text-align: left; padding: 0; margin: 0;"readonly>
        <?= htmlspecialchars($data10['remarks'] ?? '') ?>
    </span></td>
  </tr>
</table>

<!-- Declaration Table -->
<table style="margin-top:-20px;">
  <tr>
    <td>Commencement Certificate</td>
    <td><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data10['NA'] ?? '') ?></span></td>
    <td>RERA Number</td>
    <td><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data9['location_details'] ?? '') ?></span></td>
  </tr>
  <tr>
    <td>Plan Approved by</td>
    <td><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data9['floor_document'] ?? '') ?></span></td>
    <td>Occupancy Certificate</td>
    <td><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data9['possesion_details'] ?? '') ?></span></td>
  </tr>
  <tr>
      <tr><th colspan="4">DECLARATION</th></tr>
    <td colspan="4">
      <label>
       I hereby declare that
      </label>
      <br>
<span style="white-space: pre-line; font-size:14px; display: block; text-align: left; padding: 0; margin: 0;font-weight:400;" readonly>
    <?= nl2br(htmlspecialchars(formatDeclaration($data10['declaration'] ?? ''))) ?>
</span></td>
 <?php
function formatDeclaration($text) {
    // Insert a newline before every occurrence of a number followed by a dot and space (e.g., "1. ", "10. ")
    // Only if it's NOT already at the beginning of the string or a new line
    $text = preg_replace('/(?<!^)(?<!\n)(\d+\.\s)/', "\n$1", $text);
    return $text;
}
?> 
  </tr>
  <tr>
    <td>Name of TM</td>
    <td><input class="input" type="text" readonly value="<?=$technical_name ?>"></td>
    <td>Date of Report</td>
    <td><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
 <?= htmlspecialchars(date('d M Y h:i A', strtotime($data1['report_assigned_at'] ?? ''))) ?></span></td>
  </tr>
      <td>Employee/Vendor Code</td>
    <td colspan="3"><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data10['NA'] ?? '') ?></span></td>
  </tr>
    
</table>
 <table>
<tr><th style="margin-bottom:-18px;">PHOTOGRAPH OF THE PROPERTY</tr></th></table>
<br>

    
<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

$servername = "localhost";
$username   = "root";
$password   = "";
$dbname     = "project_db";

$conn = new mysqli($servername, $username, $password, $dbname);
if ($conn->connect_error) {
    die("Connection failed: " . htmlspecialchars($conn->connect_error));
}

$reference_id = $_SESSION['reference_id'] ?? null;
$reference_id = $_GET['reference_id'] ?? $reference_id;

if ($reference_id) {

    // Map captions
    $captions = [
        'image1'  => 'EXTERNAL PHOTOS',
        'image2'  => 'Kitchen',
        'image3'  => 'Selfie',
        'image4'  => 'Electric Meter',
        'image6'  => 'Other 1',
        'image7'  => 'Other 2',
        'image8'  => 'Other 3',
        'image9'  => 'Other 4',
        'image10' => 'Other 5',
        'image11' => 'Other 6',
        'image12' => 'Other 7',
        'image13' => 'Other 8',
        'image14' => 'Other 9',
        'image15' => 'Other 10',
        'image16' => 'Other 11',
        'image17' => 'Other 12',
        'image18' => 'Other 13',
        'image19' => 'Other 14',
        'image20' => 'Other 15',
    ];

    // === Helper: EXIF-aware orientation detection ===
    function classify_orientation_after_exif(string $imageData): ?string {
        $size = @getimagesizefromstring($imageData);
        if (!$size || !isset($size[0], $size[1])) {
            return null;
        }
        $width  = (int)$size[0];
        $height = (int)$size[1];

        $mime = $size['mime'] ?? '';
        if ($mime === 'image/jpeg' && function_exists('exif_read_data')) {
            $tmp = @tempnam(sys_get_temp_dir(), 'exif_');
            if ($tmp !== false) {
                @file_put_contents($tmp, $imageData);
                $exif = @exif_read_data($tmp);
                @unlink($tmp);

                if (!empty($exif['Orientation'])) {
                    $orientation = (int)$exif['Orientation'];
                    if ($orientation === 6 || $orientation === 8) {
                        $t = $width; $width = $height; $height = $t;
                    }
                }
            }
        }
        return ($width >= $height) ? 'horizontal' : 'vertical';
    }

    // === Helper: Fix orientation physically with Imagick ===
    function fixImageOrientation($binaryData) {
        $img = new Imagick();
        $img->readImageBlob($binaryData);

        switch ($img->getImageOrientation()) {
            case Imagick::ORIENTATION_BOTTOMRIGHT:
                $img->rotateImage("#000", 180);
                break;
            case Imagick::ORIENTATION_RIGHTTOP:
                $img->rotateImage("#000", 90);
                break;
            case Imagick::ORIENTATION_LEFTBOTTOM:
                $img->rotateImage("#000", -90);
                break;
        }

        $img->setImageOrientation(Imagick::ORIENTATION_TOPLEFT);
        $fixed = $img->getImageBlob();
        $img->destroy();

        return $fixed;
    }

    $sql = "SELECT 
                image1, image2, image3, image4, 
                image6, image7, image8, image9, 
                image10, image11, image12, image13, image14, image15, image16, image17, image18, image19, image20
            FROM final_uploaded_images 
            WHERE reference_id = ?";

    $stmt = $conn->prepare($sql);
    if ($stmt === false) {
        die("Error preparing the SQL statement: " . htmlspecialchars($conn->error));
    }

    $stmt->bind_param("s", $reference_id);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result && $result->num_rows > 0) {
        $horizontal_images = [];
        $vertical_images   = [];

        while ($row = $result->fetch_assoc()) {
            foreach ($row as $key => $imageData) {
                if (!empty($imageData)) {

                    // Actually fix image before displaying
                    $fixedData = fixImageOrientation($imageData);

                    $orientation = classify_orientation_after_exif($fixedData) ?? 'horizontal';
                    $imgString   = base64_encode($fixedData);
                    $caption     = $captions[$key] ?? 'Image';

                    $item = [
                        'data'    => $imgString,
                        'caption' => $caption,
                        'alt'     => $key,
                    ];

                    if ($orientation === 'horizontal') {
                        $horizontal_images[] = $item;
                    } else {
                        $vertical_images[]   = $item;
                    }
                }
            }
        }

 
// Output as a stable 4-column table (works in wkhtmltopdf)
$all_images = array_merge($vertical_images, $horizontal_images);

echo '<table class="image-grid">';
$rows = array_chunk($all_images, 4);
foreach ($rows as $row) {
    echo '<tr>';
    foreach ($row as $img) {
        echo '<td>';
        echo '<div class="img-wrap">';
        echo '<img src="data:image/jpeg;base64,' . $img['data'] . '" alt="' . htmlspecialchars($img['alt']) . '">';
        echo '<div class="caption">' . htmlspecialchars($img['caption']) . '</div>';
        echo '</div>';
        echo '</td>';
    }
    // pad remaining cells to keep 4 columns
    $remaining = 4 - count($row);
    if ($remaining > 0) {
        echo str_repeat('<td></td>', $remaining);
    }
    echo '</tr>';
}
echo '</table>';

    } else {
        echo "<p style='text-align:center;'>No images found.</p>";
    }

    $stmt->close();
} else {
    echo "<p style='text-align:center;'>Reference ID is missing.</p>";
}
?>

    
      <table>
  </tr>
  <tr>

<div class="google-map-container">
<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "project_db";
$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$reference_id = $_SESSION['reference_id'] ?? null;
$reference_id = $_GET['reference_id'] ?? $reference_id;

if ($reference_id) {
    $sql = "SELECT image5 FROM final_uploaded_images WHERE reference_id = ?";
    $stmt = $conn->prepare($sql);
    if ($stmt === false) {
        die("Error preparing the SQL statement: " . $conn->error);
    }

    $stmt->bind_param("s", $reference_id);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows > 0) {
        $row = $result->fetch_assoc();
        if (!empty($row['image5'])) {
 
            echo '<div><img src="data:image/jpeg;base64,' . base64_encode($row['image5']) . '" alt="Google Map"><p>Google Map</p></div>';
        } else {
            echo "<p style='text-align:center;'>Google Map image not available.</p>";
        }
    } else {
        echo "<p style='text-align:center;'>No record found for Google Map image.</p>";
    }

    $stmt->close();
} else {
    echo "<p style='text-align:center;'>Reference ID is missing.</p>";
}
?>
</tr>
</div>
    </table>
    </table>
 
 
   <!-- Buttons: Hidden during print -->
<div class="no-print">
  <form method="post">
    <input type="hidden" name="download_images" value="1">
    <button type="submit">Download All Images</button>
  </form>

  <button onclick="setPrintMargins()">DOWNLOAD PDF</button>
</div>

  <script>
    document.getElementById('downloadPdf').addEventListener('click', () => {
      // Select the content you want to convert to PDF
      const element = document.getElementById('content');
      const options = {
        margin:[0,0],
        filename:'report.pdf',
        image: { type: 'jpeg', quality: 0.98 },
        html2canvas: { scale: 2 },
        jsPDF: { unit: 'in', format: 'letter', orientation: 'portrait' }
      };

      // Generate and download the PDF
      html2pdf().set(options).from(element).save();
    });
    function setPrintMargins() {
      const style = document.createElement('style');
      style.innerHTML = `
      @media print {
          body {
            margin:0.5;
          }
        }
      `;
      document.head.appendChild(style);
      window.print();
    }
    // Disable all input fields in the form
    document.querySelectorAll('input').forEach(function(input) {
        input.disabled = true;  // Disables the field completely
    });
     function resizeFakeInput(input) {
    const fake = document.getElementById('fakeWrap');
    fake.textContent = input.value || ' ';
    input.style.height = fake.scrollHeight + 'px';
  }

  // Initialize height
  resizeFakeInput(document.getElementById('longInput'));
   function autoResize(el) {
    el.style.height = 'auto'; // reset height
    el.style.height = el.scrollHeight + 'px'; // set to content height
  }
  // Auto-resize on load
  document.querySelectorAll('.clean-textarea').forEach(t => autoResize(t));
    </script>
</div>
</body>
</html>

