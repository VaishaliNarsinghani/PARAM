<?php include('auth.php'); ?>
<?php
// ==== CONFIGURATION ====
$servername = "localhost";
$username   = "root";
$password   = "";
$dbname     = "project_db";
$message    = "";

// ==== DB Connection ====
$conn = new mysqli($servername, $username, $password, $dbname);
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// ==== REFERENCE HANDLING ====
$reference_id = $_SESSION['reference_id'] ?? null;
$id = $_GET['reference_id'] ?? $reference_id;
$fieldss = [];

if ($id) {
    // Get old_reference_id from mis
    $sql_check_old = "SELECT old_reference_id FROM mis WHERE reference_id = ?";
    $stmt_check = $conn->prepare($sql_check_old);
    $stmt_check->bind_param("s", $id);
    $stmt_check->execute();
    $result = $stmt_check->get_result();
    $row = $result->fetch_assoc();
    $old_reference_id = $row['old_reference_id'] ?? null;
    $stmt_check->close();

    if (!empty($old_reference_id)) {
        // Fetch old mandatory details
        $sql_prop = "SELECT * FROM mandatory_details WHERE reference_id = ?";
        $stmt_prop = $conn->prepare($sql_prop);
        $stmt_prop->bind_param("s", $old_reference_id);
        $stmt_prop->execute();
        $res_prop = $stmt_prop->get_result();
        $db_data = $res_prop->fetch_assoc() ?: [];
        $stmt_prop->close();

        $fieldss = array_merge($db_data, $_SESSION['mandatory_details'] ?? []);
    } else {
        // Fetch from mandatory_details using current reference_id
        $sql_property = "SELECT * FROM mandatory_details WHERE reference_id = ?";
        $stmt_property = $conn->prepare($sql_property);
        $stmt_property->bind_param("s", $id);
        $stmt_property->execute();
        $result_property = $stmt_property->get_result();
        $db_data = $result_property->fetch_assoc() ?: [];
        $stmt_property->close();

        $fieldss = array_merge($db_data, $_SESSION['mandatory_details'] ?? []);
    }
}

// ==== FORM HANDLING ====
if ($_SERVER["REQUEST_METHOD"] === "POST") {
    $action = $_POST['action'] ?? '';

    if ($action === 'save') {
        $_SESSION['mandatory_details'] = array_map('trim', $_POST);
        $fieldss = $_SESSION['mandatory_details'];
        $message = "Mandatory Details saved successfully!";
    }
    elseif ($action === 'submit') {
        // Create PDO connection for save function
        try {
            $pdo = new PDO("mysql:host=$servername;dbname=$dbname", $username, $password);
            $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
            
            $result = saveMandatoryDetailsToDatabase($pdo, $_SESSION['mandatory_details'] ?? []);
            
            
            if (strpos($result, "Error:") === 0) {
                echo "<script>
                        alert(" . json_encode($result) . ");
                        window.location.href = 'technical13.php';
                      </script>";
                exit;
            } else {
                unset($_SESSION['mandatory_details']);
                header("Location: technical13.php?msg=" . urlencode($result));
                exit();
            }
        } catch (PDOException $e) {
            echo "<script>
                    alert('Database connection error: " . addslashes($e->getMessage()) . "');
                    window.location.href = 'technical13.php';
                  </script>";
            exit;
        }
    }
}
$conn->close();
?>

<?php
if (isset($_GET['msg'])) {
    $message = $_GET['msg'];
}
?>

<?php if (!empty($message)): ?>
<script>alert("<?= htmlspecialchars($message) ?>");</script>
<?php endif; ?>

<script>
document.addEventListener("DOMContentLoaded", function() {
    const form = document.getElementById("autosave-form");
    form.addEventListener("submit", function(e) {
        let isValid = true;
        document.querySelectorAll(".mandatory-field").forEach(input => {
            const errorDiv = document.getElementById("error-" + input.name);
            if (!input.value.trim()) {
                errorDiv.textContent = input.dataset.fieldname + " is required.";
                isValid = false;
            } else {
                errorDiv.textContent = "";
            }
        });

        if (!isValid) {
            e.preventDefault();
            alert("Please fill all mandatory fields.");
        }
    });
});
</script>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Property Details Form</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
    <link rel="shortcut icon" href="favicon.ico" type="image/x-icon">
    <link rel="stylesheet" href="REPORT13.css">
   
</head>

<body>
<button id="toggleSidebar">&#9776;</button>
<div id="sidebar" class="sidebar">
    <div style="display: flex">
      <img class="logo" src="logo.png" alt="" />
      <h1>Magpie Engineering</h1>
    </div>
          <div class="rotating-text">Report Drafter</div>
    <a href="home1.php"><i class="fas fa-home icon"></i>Home</a>        

    
  <a href="Pending_Report.php" ><i class="fas fa-clock watch-icon"></i>Pending For Drafting</a>
 <a href="technical.php" class="active"><i class="fas fa-clipboard-list icon"></i> Preview Report</a>      
    <a href="logout.php"><i class="fas fa-sign-out-alt icon"></i>Logout</a>

  </div>
    <div class="form-container">
        <div style="width: 100%;">
        <div class="tab-links">

    <button class="tab" onclick="location.href='technical3.php'"><img src="info.png" alt="Icon" width="50  " height="50  ">
    INFO</button>
    <button class="tab " onclick="location.href='technical4.php'"><img src="general.png" alt="Icon" width="50  " height="50  ">GENERAL</button>
    <button class="tab" onclick="location.href='technical2.php'"> <img src="location.png" alt="Icon" width="50  " height="50  ">
    LOCATION</button>
    <button class="tab " onclick="location.href='technical5.php'"><img src="Zoning.png" alt="Icon" width="50  " height="50  ">
    ZONING</button>
    <button class="tab" onclick="location.href='technical7.php'"><img src="value.png" alt="Icon" width="50  " height="50  ">
    VALUE</button>
    <button class="tab " onclick="location.href='technical9.php'"><img src="Floor.png" alt="Icon" width="50  " height="50  ">
    STRUCTURE</button>
    <button class="tab" onclick="location.href='technical10.php'"><img src="documents.png" alt="Icon" width="50  " height="50  ">
    DOCUMENTS</button>
    <button class="tab" onclick="location.href='technical115.php'"><img src="photo.png" alt="Icon" width="50  " height="50  ">
    PHOTOS</button>
        <button class="tab tab-button" class="tab active" style="font-weight:800px;" onclick="location.href='technical13.php'">
            <img src="mandatory.png" alt="Icon" width="80" height="80"> MANDATORY FIELDS</button>

    <button class="tab" onclick="location.href='technical12.php'"><img src="remark.png" alt="Icon" width="50  " height="50  ">
    REMARK</button>          
    <button class="tab"  onclick="location.href='view_report.php'"><img src="preview.jpg" alt="Icon" width="50  " height="50  ">
    PREVIEW</button>  
 <div class="slider"></div>
 </div>
 
 

 <!-- Address Form -->
    <form  id="autosave-form" action="" method="POST" style="width: 100%;">
        <div class="header valuation-table">
THE BELOW FIELDS ARE THE MOST IMPORTANT FIELDS IN THE WHOLE DRAFTER'S SECTION       </div>
        <table >
            <?php 
            $fields = [
                'Address As per site' => 'bill_address_per_site',
                'Latitude' => 'bill_latitude',
                'Longitude' => 'bill_longitude',
                'Nearest Branch Location' => 'bill_nearest_branch',
                 'Property Type'=>'bill_property_type',
               
            ];
               // Display the reference_id as a hidden field (assuming it will not be modified by the user)
               $reference_id = $_SESSION['reference_id'] ?? '';
               echo '<input type="hidden" name="reference_id" value="' . htmlspecialchars($reference_id) . '">';
   
    $count = 0;
    echo '<tr>';
    foreach ($fields as $label => $name) {
        $value = htmlspecialchars($fieldss[$name] ?? '');

        // mark mandatory fields
        $mandatoryFields = ['bill_address_per_site','bill_latitude','bill_longitude','bill_nearest_branch','bill_property_type']; // later you can add more
        $isMandatory = in_array($name, $mandatoryFields);

        echo "<td><label for='$name'>$label";
        if ($isMandatory) {
            echo " <span style='color:red'>*</span>";
        }
        echo "</label></td><td>";

        $dropdowns = [
            'demarcated_at_site' => ['NA','Yes', 'No'],
            'structurally_fit' => ['NA','Good', 'Average','Poor'],
            'community_dominated' => ['No', 'Yes'],
            'relation_of_occupant' =>['NA','Self','Tenant','Seller']
        ];

        if (isset($dropdowns[$name])) {
            echo "<select id='$name' name='$name'>";
            foreach ($dropdowns[$name] as $option) {
                $selected = ($value == $option) ? "selected" : "";
                echo "<option value='$option' $selected>$option</option>";
            }
            echo "</select>";
        } else {
            // add data attribute for mandatory
            $extraAttr = $isMandatory ? "class='mandatory-field' data-fieldname='$label'" : "";
            echo "<input type='text' id='$name' name='$name' value='$value' $extraAttr>";
        }

        // placeholder for error message
        if ($isMandatory) {
            echo "<div class='error-message' id='error-$name' style='color:red; font-size:12px;'></div>";
        }

        echo "</td>";
        $count++;
        if ($count % 3 === 0) echo '</tr><tr>';
    }
    echo '</tr>';
    ?>
</table>
         <div class="submit-button">
            <button type="submit" name="action" value="save">Save</button> 
        </div>
       
    </form>
 
 
  <script>

document.addEventListener('DOMContentLoaded', () => {
    const form = document.getElementById('autosave-form');
    if (!form) return;

    function gatherFormData(form) {
        const formData = new FormData(form);
        const data = {};
        formData.forEach((value, key) => { data[key] = value; });
        return data;
    }

    function autoSaveSession() {
        const data = gatherFormData(form);
        fetch('autosave.php', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ page: 'mandatory_details', data })
        });
    }

    // autosave on field input
    form.addEventListener('input', autoSaveSession);

    // autosave on submit too (non-blocking)
    form.addEventListener('submit', () => {
        const data = gatherFormData(form);
        const payload = JSON.stringify({ page: 'mandatory_details', data });
        if (navigator.sendBeacon) {
            navigator.sendBeacon('autosave.php', new Blob([payload], { type: 'application/json' }));
        } else {
            fetch('autosave.php', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: payload,
                keepalive: true
            });
        }
    });
});
 
    document.addEventListener("DOMContentLoaded", function () {
    let tabs = document.querySelectorAll(".tab-links .tab");
    let slider = document.querySelector(".tab-links .slider");

    function moveSlider(activeTab) {
        slider.style.width = activeTab.offsetWidth + "px";
        slider.style.left = activeTab.offsetLeft + "px";
    }

    tabs.forEach(tab => {
        tab.addEventListener("click", function () {
            tabs.forEach(t => t.classList.remove("active"));
            this.classList.add("active");
            moveSlider(this);
        });

        // Initialize position on load for the active tab
        if (tab.classList.contains("active")) {
            moveSlider(tab);
        }
    });
});
     document.getElementById("toggleSidebar").addEventListener("click", function() {
    var sidebar = document.getElementById("sidebar");
    var toggleButton = document.getElementById("toggleSidebar");
    
    sidebar.classList.toggle("active");
    
    // Toggle button state
    toggleButton.classList.toggle("active");
});

var modal = document.getElementById("myModal");

// Get the <span> element that closes the modal
var span = document.getElementsByClassName("close")[0];

// Function to show the modal with custom text
function showPopup(text) {
    document.getElementById("modalText").innerText = text;
    modal.style.display = "block";
}

// When the user clicks on <span> (x), close the modal
span.onclick = function() {
    modal.style.display = "none";
}

// When the user clicks anywhere outside of the modal, close it
window.onclick = function(event) {
    if (event.target == modal) {
        modal.style.display = "none";
    }
}

function openGoogleMaps(location) {
            const baseUrl = "https://www.google.com/maps/search/?api=1&query=";
            window.open(baseUrl + encodeURIComponent(location), '_blank');
        }
function triggerFileInput2() {
            document.getElementById("imageInput").click();
        }

        document.getElementById("imageInput").addEventListener("change", function (event) {
            const files = event.target.files;
            const previewContainer = document.getElementById("imagePreviewContainer");

            // Clear previous previews
            previewContainer.innerHTML = "";

            // Display previews for each selected image
            Array.from(files).forEach((file) => {
                if (file.type.startsWith("image/")) {
                    const reader = new FileReader();
                    reader.onload = function (e) {
                        const img = document.createElement("img");
                        img.src = e.target.result;
                        previewContainer.appendChild(img);
                    };
                    reader.readAsDataURL(file);
                }
            });
        });
function triggerFileInput1() {
            document.getElementById("pdfInput").click();
        }

        // Handle file selection
        document.getElementById("pdfInput").addEventListener("change", function (event) {
            const file = event.target.files[0];
            if (file && file.type === "application/pdf") {
                // Create a FileReader instance
                const reader = new FileReader();

                // When the file is read successfully, open it in a new tab
                reader.onload = function (e) {
                    const pdfUrl = e.target.result;

                    // Try to open the PDF in a new tab using embed
                    const newTab = window.open();
                    if (newTab) {
                        newTab.document.write('<html><body><embed src="' + pdfUrl + '" type="application/pdf" width="100%" height="100%"></body></html>');
                        newTab.document.close();

                        // Fallback if the PDF does not load correctly
                        setTimeout(function() {
                            if (newTab.document.body.innerHTML === "") {
                                // Use PDF.js as a fallback to display the PDF
                                newTab.document.body.innerHTML = '<div id="pdf-container" style="width: 100%; height: 100%;"></div>';
                                const loadingTask = pdfjsLib.getDocument(pdfUrl);
                                loadingTask.promise.then(function(pdf) {
                                    pdf.getPage(1).then(function(page) {
                                        const scale = 1.5;
                                        const viewport = page.getViewport({ scale: scale });
                                        const canvas = document.createElement('canvas');
                                        const ctx = canvas.getContext('2d');
                                        canvas.height = viewport.height;
                                        canvas.width = viewport.width;
                                        document.getElementById('pdf-container').appendChild(canvas);

                                        // Render PDF page
                                        page.render({
                                            canvasContext: ctx,
                                            viewport: viewport
                                        });
                                    });
                                });
                            }
                        }, 1000); // Check if the embed failed after 1 second
                    }
                };

                // Read the file as a data URL
                reader.readAsDataURL(file);
            } else {
                alert("Please select a valid PDF file.");
            }
        });
</script>
</body>
</html>
