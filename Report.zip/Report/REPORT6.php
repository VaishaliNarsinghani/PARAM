<?php include('auth.php'); ?>
<?php



ini_set('display_errors', 1);
error_reporting(E_ALL);

// Increase PHP execution time and memory limit
ini_set('max_execution_time', 600); // Increase execution time to 600 seconds (10 minutes)
ini_set('memory_limit', '4096M'); // Increase memory limit to 4096MB
// Start session

 

$message = "";

  // Step 2: Retrieve reference_id from session (if set)
  $reference_id = $_SESSION['reference_id'] ?? null;  // Use null if not found
  

// Check if the form is submitted
if ($_SERVER["REQUEST_METHOD"] === "POST") {
    if (isset($_POST['action']) && $_POST['action'] === 'save') {
        // Save form data in the session
        $_SESSION['surrounding_amenities'] = array_map(function ($item) {
            return $item ?: '';
            
        }, $_POST);

        $message = "Assignment details saved successfully!";
    } elseif (isset($_POST['action']) && $_POST['action'] === 'submit') {
        // Simulate saving all data to the database or another process
        // Clear session data after submission
        unset($_SESSION['surrounding_amenities']);

        // Redirect to a confirmation page
        header("Location: REPO66.php");
        exit();
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Property Details Form</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
    <link rel="shortcut icon" href="favicon.ico" type="image/x-icon">
    <link rel="stylesheet" href="REPORT6.css">
</head>
<body>
<div class="form-container">
    <?php if (!empty($message)): ?>
        <div class="success-message" style="text-align: center; padding: 10px; background-color: #dff0d8; color: #3c763d; border: 1px solid #d6e9c6; margin-bottom: 20px;">
            <?= htmlspecialchars($message) ?>
        </div>
    <?php endif; ?>

    <div class="tab-links">
        <button class="tab"><a href="REPORT3.php">BANK DETAILS</a></button>
        <button class="tab"><a href="REPORT4.php">GENERAL DETAILS</a></button>
        <button class="tab"><a href="REPORT2.php">ADDRESS</a></button>
        <button class="tab"><a href="REPORT5.php">PARAMETERS</a></button>
        <button class="tab active"><a href="REPO66.php">SURROUNDINGS</a></button>
        <button class="tab"><a href="REPORT7.php">AREA</a></button>
        <button class="tab"><a href="REPORT8.php">COST</a></button>
        <button class="tab"><a href="REPORT9.php">FLOOR DETAILS</a></button>
        <button class="tab"><a href="REPORT10.php">TECHNICAL DETAILS</a></button>
        <button class="tab"><a href="REPORT115.php">PHOTOS</a></button>
        <button class="tab"><a href="REPORT12.php">REMARK</a></button>
    </div>
    <div class="main-content">
        <form id="autosave-form" action="" method="POST" style="width: 88%;">
        <table class="amenities-table">
    <thead>
        <tr>
            <th colspan="3" style="background-color: #2f7cab; color:white;">SURROUNDING EXTERNAL AMENITIES</th>
            <th colspan="2" style="background-color: #2f7cab; color:white;">INTERNAL SPECIFICATIONS</th>
        </tr>
        <tr>
            <th>Premises List</th>
            <th>Approx. Distance</th>
            <th>Name</th>
            <th>Specification List</th>
            <th>Details</th>
        </tr>
    </thead>
 <?php
$fields = [
    // Surrounding External Amenities
    'Nearest Bus Stop Distance' => 'nearest_bus_stop_distance',
    'Nearest Bus Stop Name' => 'nearest_bus_stop_name',
    'Nearest Railway Station Distance' => 'nearest_railway_station_distance',
    'Nearest Railway Station Name' => 'nearest_railway_station_name',
    'Nearest Airport Distance' => 'nearest_airport_distance',
    'Nearest Airport Name' => 'nearest_airport_name',
    'Nearest School/College Distance' => 'nearest_school_college_distance',
    'Nearest School/College Name' => 'nearest_school_college_name',
    'Nearest Bank Distance' => 'nearest_bank_distance',
    'Nearest Bank Name' => 'nearest_bank_name',
    'Nearest Highway/Major Road Distance' => 'nearest_highway_distance',
    'Nearest Highway/Major Road Name' => 'nearest_highway_name',
    'Nearest Hospital Distance' => 'nearest_hospital_distance',
    'Nearest Hospital Name' => 'nearest_hospital_name',
    'Nearest Multiplex/Mall/Market Distance' => 'nearest_multiplex_distance',
    'Nearest Multiplex/Mall/Market Name' => 'nearest_multiplex_name',

    // Internal Specifications
    'Structural Elements' => 'structural_elements',
    'Wall Thickness' => 'wall_thickness',
    'Plaster & Painting' => 'plaster_painting',
    'Electrification' => 'electrification',
    'Plumbing & Bath Fittings' => 'plumbing_bath_fittings',
    'Door, Windows' => 'door_windows',
    'Potable Water Connection' => 'potable_water_connection',
    'Sewerage System' => 'sewerage_system'
];
        // Display the reference_id as a hidden field (assuming it will not be modified by the user)
        $reference_id = $_SESSION['reference_id'] ?? '';
        echo '<input type="hidden" name="reference_id" value="' . htmlspecialchars($reference_id) . '">';

                $count = 0;
                echo '<tr>';
                foreach ($fields as $label => $name) {
                    $value = htmlspecialchars($_SESSION['surrounding_amenities'][$name] ?? '');
                    echo "<td><label for='$name'>$label</label></td>
                          <td><input type='text' id='$name' name='$name' value='$value'></td>";
                    $count++;
                    if ($count % 3 === 0) {
                        echo '</tr><tr>';
                    }
                }
                echo '</tr>';
                ?>
            </table>
            <div class="submit-button">
                <button type="submit" name="action" value="save">Save</button>
            </div>
        </form>
    </div>

    <div class="side-buttons">

<button type="button"><img src="https://www.iconpacks.net/icons/1/free-document-icon-901-thumb.png" alt="" width="35px" height="35px "></button>
<button type="button"><img src="https://cdn-icons-png.flaticon.com/512/25/25666.png" alt="" width="35px" height="35px"></button>       
<button type="button"><img src="https://cdn-icons-png.flaticon.com/512/535/535239.png" alt="" width="35px" height="35px"></button>
<button type="button"><img src="https://cdn-icons-png.flaticon.com/512/1456/1456888.png" alt="" width="35px" height="35px"></button>
</div>
</div>
</body>
</html>
