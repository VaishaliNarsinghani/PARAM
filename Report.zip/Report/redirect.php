<?php
include('auth.php');

// Start session if not already started
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

$host = 'localhost';
$db = 'project_db';
$user = 'root';
$pass = '';

try {
    $conn = new PDO("mysql:host=$host;dbname=$db", $user, $pass);
    $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (PDOException $e) {
    die("Database connection failed: " . $e->getMessage());
}
if (!isset($_GET['reference_id']) || !isset($_GET['bankName'])) {
    die("Error: Missing reference_id or bankName.");
}

$reference_id = $_GET['reference_id'];
$bankName = trim($_GET['bankName']); // <-- This must not be blank!

$_SESSION['reference_id'] = $reference_id;
$_SESSION['bankName'] = $bankName;

// echo "DEBUG: reference_id = $reference_id<br>";
// echo "DEBUG: bankName = $bankName<br>";

// Sanitize and generate target page
$bankNameSanitized = preg_replace('/[^a-zA-Z0-9_]/', '_', $bankName);
$targetPage = strtolower($bankNameSanitized) . ".php";

if (file_exists($targetPage)) {
    header("Location: $targetPage");
    exit();
} else {
    die("Error: Page for '$bankName' not found.");
}
