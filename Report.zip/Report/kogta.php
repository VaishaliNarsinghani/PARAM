<?php include('auth.php'); ?>
<?php include 'watermark.html'; ?>

<?php
ini_set('display_errors', 1);
error_reporting(E_ALL);

// Increase PHP execution time and memory limit
ini_set('max_execution_time', 600); // Increase execution time to 600 seconds (10 minutes)
ini_set('memory_limit', '4096M'); // Increase memory limit to 4096MB
// Start session
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "project_db";

// Create DB connection
$conn = new mysqli($servername, $username, $password, $dbname);
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

if (!isset($_SESSION['reference_id'])) {
    die("Reference ID not found in session.");
}
$reference_id = $_SESSION['reference_id'];

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['download_images'])) {

    // Get customer name
    $stmt_name = $conn->prepare("SELECT customerName FROM mis WHERE reference_id = ?");
    $stmt_name->bind_param("s", $reference_id);
    $stmt_name->execute();
    $result_name = $stmt_name->get_result();
    $customerName = "customer";
    if ($row = $result_name->fetch_assoc()) {
        $customerName = preg_replace('/[^a-zA-Z0-9]/', '', $row['customerName']);
    }
    $stmt_name->close();

    // Fetch image BLOBs
    $stmt = $conn->prepare("SELECT image1, image2, image3, image4, image5, image6, image7, image8, image9, image10, image11, image12,image13, image14, image15, image16, image17, image18, image19, image20 FROM final_uploaded_images WHERE reference_id = ?");    $stmt->bind_param("s", $reference_id);
    $stmt->bind_param("s", $reference_id);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows > 0 && ($row = $result->fetch_assoc())) {
        $tempDir = sys_get_temp_dir() . DIRECTORY_SEPARATOR . uniqid('images_', true);
        mkdir($tempDir);

        $imageFiles = [];
        for ($i = 1; $i <= 12; $i++) {
            if (!empty($row["image$i"])) {
                $filename = $tempDir . DIRECTORY_SEPARATOR . "image{$i}.jpg";
                file_put_contents($filename, $row["image$i"]);
                $imageFiles[] = $filename;
            }
        }

        if (empty($imageFiles)) {
            die("No images to download.");
        }

        // Create ZIP
        $zipFileName = "images_" . preg_replace('/[^a-zA-Z0-9]/', '_', $reference_id) . "_{$customerName}.zip";
        $zipPath = $tempDir . DIRECTORY_SEPARATOR . $zipFileName;

        $zip = new ZipArchive();
        if ($zip->open($zipPath, ZipArchive::CREATE) !== TRUE) {
            die("Failed to create ZIP file.");
        }

        foreach ($imageFiles as $file) {
            $zip->addFile($file, basename($file));
        }
        $zip->close();

        // Send ZIP to browser
        header('Content-Type: application/zip');
        header('Content-Disposition: attachment; filename="' . basename($zipFileName) . '"');
        header('Content-Length: ' . filesize($zipPath));
        flush();
        readfile($zipPath);

        // Cleanup
        foreach ($imageFiles as $file) {
            unlink($file);
        }
        unlink($zipPath);
        rmdir($tempDir);
        exit;
    } else {
        echo "<p style='color:red;'>No image data found for this reference ID.</p>";
    }
}

$page = isset($_GET['page']) ? $_GET['page'] : 1;
$limit = 50;
$offset = ($page - 1) * $limit;
$sql_property = "SELECT * FROM mis WHERE reference_id = ? LIMIT $limit OFFSET $offset";
$stmt_property = $conn->prepare($sql_property);
$stmt_property->bind_param("s", $reference_id);
$stmt_property->execute();
$result_property = $stmt_property->get_result();
$data1 = $result_property->fetch_assoc();




// Fetch data from property_details table
$sql_property = "SELECT * FROM property_details WHERE reference_id = ?";
$stmt_property = $conn->prepare($sql_property);
$stmt_property->bind_param("s", $reference_id);
$stmt_property->execute();
$result_property = $stmt_property->get_result();
$data2= $result_property->fetch_assoc();




// Fetch data from area_valuation table
$sql_area = "SELECT * FROM address_details WHERE reference_id = ?";
$stmt_area = $conn->prepare($sql_area); 
$stmt_area->bind_param("s", $reference_id);
$stmt_area->execute();
$result_area = $stmt_area->get_result();
$data3 = $result_area->fetch_assoc();





// Fetch data from area_valuation table
$sql_area = "SELECT * FROM critical_parameters WHERE reference_id = ?";
$stmt_area = $conn->prepare($sql_area); 
$stmt_area->bind_param("s", $reference_id);
$stmt_area->execute();
$result_area = $stmt_area->get_result();
$data4 = $result_area->fetch_assoc();

 
// Fetch data from area_valuation table
$sql_area = "SELECT * FROM surroundings_details WHERE reference_id = ?";
$stmt_area = $conn->prepare($sql_area); 
$stmt_area->bind_param("s", $reference_id);
$stmt_area->execute();
$result_area = $stmt_area->get_result();
$data5 = $result_area->fetch_assoc();
$stmt_area->close();
 
// Fetch data from area_valuation table
$sql_area = "SELECT * FROM area_valuation WHERE reference_id = ?";
$stmt_area = $conn->prepare($sql_area); 
$stmt_area->bind_param("s", $reference_id);
$stmt_area->execute();
$result_area = $stmt_area->get_result();
$data6 = $result_area->fetch_assoc();
$stmt_area->close();
 



// Fetch data from area_valuation table
$sql_area = "SELECT * FROM floor_details WHERE reference_id = ?";
$stmt_area = $conn->prepare($sql_area); 
$stmt_area->bind_param("s", $reference_id);
$stmt_area->execute();
$result_area = $stmt_area->get_result();
$data8= $result_area->fetch_assoc();
$stmt_area->close();
 


// Fetch data from area_valuation table
$sql_area = "SELECT * FROM technical_details WHERE reference_id = ?";
$stmt_area = $conn->prepare($sql_area); 
$stmt_area->bind_param("s", $reference_id);
$stmt_area->execute();
$result_area = $stmt_area->get_result();
$data9 = $result_area->fetch_assoc();
$stmt_area->close();
 
// Fetch data from area_valuation table
$sql_area = "SELECT * FROM remarks_table WHERE reference_id = ?";
$stmt_area = $conn->prepare($sql_area); 
$stmt_area->bind_param("s", $reference_id);
$stmt_area->execute();
$result_area = $stmt_area->get_result();
$data10 = $result_area->fetch_assoc();
$stmt_area->close();


// Step 1: Fetch the engineer_id from the mis table
$sql_mis = "SELECT engineer_id FROM mis WHERE reference_id = ?";
$stmt_mis = $conn->prepare($sql_mis);
$stmt_mis->bind_param("s", $reference_id);
$stmt_mis->execute();
$result_mis = $stmt_mis->get_result();
$row_mis = $result_mis->fetch_assoc();
$stmt_mis->close(); 

if ($row_mis) {
    $engineer_id = $row_mis['engineer_id'];

    // Step 2: Fetch the engineer's name from engineer_login table
    $sql_engineer = "SELECT name FROM engineer_login WHERE engineer_id = ?";
    $stmt_engineer = $conn->prepare($sql_engineer);
    $stmt_engineer->bind_param("s", $engineer_id);
    $stmt_engineer->execute();
    $result_engineer = $stmt_engineer->get_result();
    $row_engineer = $result_engineer->fetch_assoc();
    $stmt_engineer->close();

    if ($row_engineer) {
        $engineer_name = $row_engineer['name'];
         //echo "Engineer Name: " . $engineer_name;
    } else {
        echo "Engineer not found.";
    }
} else {
    echo "No engineer assigned for this reference_id.";
}



// Step 1: Fetch the engineer_id from the mis table
$sql_mis = "SELECT report_id FROM mis WHERE reference_id = ?";
$stmt_mis = $conn->prepare($sql_mis);
$stmt_mis->bind_param("s", $reference_id);
$stmt_mis->execute();
$result_mis = $stmt_mis->get_result();
$row_mis = $result_mis->fetch_assoc();
$stmt_mis->close(); 

if ($row_mis) {
    $report_id = $row_mis['report_id'];

    // Step 2: Fetch the engineer's name from engineer_login table
    $sql_engineer = "SELECT name FROM report_login WHERE report_id = ?";
    $stmt_engineer = $conn->prepare($sql_engineer);
    $stmt_engineer->bind_param("s", $report_id);
    $stmt_engineer->execute();
    $result_engineer = $stmt_engineer->get_result();
    $row_engineer = $result_engineer->fetch_assoc();
    $stmt_engineer->close();

    if ($row_engineer) {
        $report_name = $row_engineer['name'];
         //echo "Engineer Name: " . $report_name;
    } else {
        echo "Engineer not found.";
    }
} else {
    echo "No engineer assigned for this reference_id.";
}


// Step 1: Fetch the engineer_id from the mis table
$sql_mis = "SELECT report_drafter_to_technical FROM mis WHERE reference_id = ?";
$stmt_mis = $conn->prepare($sql_mis);
$stmt_mis->bind_param("s", $reference_id);
$stmt_mis->execute();
$result_mis = $stmt_mis->get_result();
$row_mis = $result_mis->fetch_assoc();
$stmt_mis->close(); 

if ($row_mis) {
    $report_drafter_to_technical = $row_mis['report_drafter_to_technical'];

    // Step 2: Fetch the engineer's name from engineer_login table
    $sql_engineer = "SELECT name FROM technical_login WHERE technical_manager_id = ?";
    $stmt_engineer = $conn->prepare($sql_engineer);
    $stmt_engineer->bind_param("s", $report_drafter_to_technical);
    $stmt_engineer->execute();
    $result_engineer = $stmt_engineer->get_result();
    $row_engineer = $result_engineer->fetch_assoc();
    $stmt_engineer->close();

    if ($row_engineer) {
        $technical_name = $row_engineer['name'];
        //echo "Engineer Name: " . $technical_name;
    } else {
        echo "Engineer not found.";
    }
} else {
    echo "No engineer assigned for this reference_id.";
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
   <link rel="shortcut icon" href="favicon.png" type="image/x-icon"> 
    <style>
      
    body {
      font-family: Arial, sans-serif;
      margin: 0;
      padding: 0;
      background: #fff;
    }

    .container {
        display:flex;
        flex-direction:column;
        justify-content:space-between;
       text-align:center;
      width: 95%;
      margin: 20px auto;
      border: 1px solid #000;
    }

.header-content {
    text-align: center;
    flex: 1;
}

.header-content h1 {
    margin: 0;
    margin-top:25px;  
     font-size: 30px;
    color: #902d2d;
}

.header-content p {
    margin: 2px 0;
    font-size: 20px;
    color: #333;
}
    table {
      width: 100%;
      border-collapse: collapse;
      font-size: 14px;
    }

    th, td {
      border: 1px solid #000;
      padding: 6px;
      vertical-align: top;
      text-align: left;
    }
#input input{
  width:95%
}



    .title-row {
      background-color: #f4dede;
      font-weight: bold;
      text-align: center;
    }

    .sub-title {
      font-weight: bold;
      background:#e6e3e3ff;
    }

    .no-border {
      border: none;
    }
    input{
      width:95%;
      padding:5px;
      border:none;
    }
    
       .footer{
    display: flex;
}
.logo img {
  width: 120px;
  margin-left:30px;
  height: auto;
}


    </style>
     <style>
 
            

.container {
    max-width: 1200px;
    margin: 20px auto;
    padding: 20px;
    background-color: white;
    box-shadow: 0px 0px 10px rgba(0, 0, 0, 0.1);
    border-radius: 8px;
}

.title {
    text-align: center;
    font-size: 24px;
    font-weight: bold;
    margin-bottom: 20px;
}
.grid-container {
    display: grid;
    grid-template-columns: repeat(4, 1fr);
    gap: 15px;
}

.grid-item {
    position: relative;
    border-radius: 8px;
    overflow: hidden;
    box-shadow: 0px 4px 6px rgba(0, 0, 0, 0.1);
}

.grid-item img {
    width: 100%;
    height: 200px;
    object-fit: cover;
    transition: transform 0.3s ease;
}
.grid-item:hover img {
    transform: scale(1.05);
}

.overlay {
    position: absolute;
    bottom: 0;
    left: 0;
    background: rgba(0, 0, 0, 0.6);
    color: white;
    width: 100%;
    padding: 8px;
    font-size: 14px;
    text-align: center;
}
 
   
/* Force a stable 4-column grid that wkhtmltopdf respects */
.image-gallery { width: 100%; }
.image-grid { width: 100%; border-collapse: collapse; table-layout: fixed; }
.image-grid tr { page-break-inside: avoid; }
.image-grid td { width: 25%; padding: 6px; vertical-align: top; }

.image-grid .img-wrap { display: block; }
.image-grid img { display: block; width: 100%; height: auto; }
.image-grid .caption { font-size: 12px; text-align: center; margin-top: 4px; }

/* If you had a flex layout before, neutralize it */
.image-gallery { display: block !important; }



    /* Print-specific rules */
    @media print {
      .no-print {
        display: none !important;
      }

      body {
        margin: 0;
      }
 
    }
  button{
    padding:8px;
    margin-left:45%;
    background-color:#808485;
    color:white;
    font-weight:700;
    font-style:italic;
  }
  button:hover{
    background-color:rgba(216,216,216,255);
    color:white;
  }

/* Optional: Google map styling */
    .google-map-container {
      max-width: 90%;
      margin: 20px auto;
      border: 2px solid #ccc;
      padding: 10px;
      box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
      background-color: #f9f9f9;
      border-radius: 8px;
      text-align: center;
    }

    .google-map-container img {
      max-width: 100%;
      height: auto;
      display: inline-block;
      border: 1px solid #999;
      border-radius: 4px;
    }
    

 </style>
  <title>Kogta Report</title>
 </head>
<body>
 
<div class="container">
    <header>
            <div class="footer">
            <div class="logo">
                <img <img src="images/Magpie_logo.jpg" alt="Magpie Logo">
            </div>
            <div class="header-content">
                <h1>MAGPIE ENGINEERING PVT. LTD.</h1>
                <p>Valuer Designer Architects</p>
                <p>Address : Office no. 201, 2nd floor, Gravity Mall, Mechanic nagar, warehouse road, near vijay nagar, Indore, Madhya Pradesh- 452011</p>
            </div>
            </div>
        </header>
  <table>
    <tr>
      <td colspan="4" style="font-weight:bold;">KOGTA FINANCIAL INDIA LIMITED</td>
      <th class="sub-title">Date of Initiation</th>
      <td><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data1['initiationDate'] ?? '') ?>
    </span></td>
    </tr>
    <tr>
        <td colspan='6' class="title-row">Technical Report</td>
    </tr>
    <tr>
      <th  class="sub-title"colspan="2">Loan Application No.</th>
      <td><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data1['applicationNo'] ?? '') ?>
    </span></td>
   
      <th class="sub-title">Date of Inspection / Site visit</th>
      <td colspan="3"><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data1['assigned_at'] ?? '') ?>
    </span></td>
    </tr>
    <tr>
    <th  class="sub-title"colspan="2">Product</th>
    <td colspan="1"><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data1['caseType'] ?? '') ?>
    </span></td>
      <th class="sub-title">Landmark</th>
      
        <td colspan="3"><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data3['landmark_1'] ?? '') ?>  <?= htmlspecialchars($data3['landmark_2'] ?? '') ?>
    </span></td>      
    </tr>   
    <tr>
      <th colspan="2" class="sub-title">Name of the Customer/ Applicant /Co applicant</th>
      <td colspan="1"><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data1['customerName'] ?? '') ?>
    </span></td>
      <th class="sub-title">Contact no. of customer</th>
      <td colspan="3"><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data1['customerMob'] ?? '') ?>
    </span></td>
      
    </tr>

    <tr>
      <th colspan="2" class="sub-title">Name of owner</th>
      <td colspan="1">
      <span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data9['owner_name'] ?? '') ?>
    </span>
      </td>
      <th class="sub-title">REF.NO.</th>
      <td colspan="3"><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data1['reference_id'] ?? '') ?>
    </span></td>
    </tr>
    <tr>
      <th rowspan="2" class="sub-title">Address of the property being appraised</th>
      <td class="sub-title">As per Document</td>
        <td colspan="5"><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
  <?= htmlspecialchars($data3['address_per_document'] ?? '') ?>  <?= htmlspecialchars($data3['pin_code'] ?? '') ?>  </span></td>
    </tr>
    <tr>
      <td class="sub-title">As per actual or postal</td>
        <td colspan="5"><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data3['address_per_site'] ?? '') ?>
    </span></td>
    </tr>

    <!-- Documents Section -->
    <tr>
      <td colspan="6" class="title-row">DOCUMENTS PROVIDED BY KFIL</td>
    </tr>
    <tr>
      <th colspan="2" class="sub-title">Document Description</th>
      <th colspan="2" class="sub-title">Collection status</th>
      <th colspan="2" class="sub-title">Document Name, Number and Approval Number</th>
    </tr>
    <tr>
      <td colspan="2" class="sub-title">Copy of Co-Ownership Deed</td>
      <td colspan="2"><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data9['ownership1_approving_authority'] ?? '') ?>
    </span></td>
   <td colspan="2"><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data9['ownership1_details'] ?? '') ?>  <?= htmlspecialchars($data9['ownership2_details'] ?? '') ?>
    </span></td>
      </tr>
    <tr>
      <td colspan="2" class="sub-title">Swamitva Adhikar Abhilekh (Drone Survey)</td>
      <td colspan="2"><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data10['NA'] ?? '') ?>
    </span></td>
      <td colspan="2"><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data10['NA'] ?? '') ?>
    </span></td>
    </tr>
    <tr>
      <td colspan="2" class="sub-title">P-2 form</td>
      <td colspan="2"><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data10['NA'] ?? '') ?>
    </span></td>
      <td colspan="2"><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data10['NA'] ?? '') ?>
    </span></td>
    </tr>
    <tr>
      <td colspan="2" class="sub-title">Conversion Certificate</td>
      <td colspan="2"><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data10['NA'] ?? '') ?>
    </span></td>
      <td colspan="2"><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data10['NA'] ?? '') ?>
    </span></td>
    </tr>
    <tr>
      <td colspan="2" class="sub-title">Property Tax receipts</td>
      <td colspan="2"><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data10['NA'] ?? '') ?>
    </span></td>
      <td colspan="2"><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data10['NA'] ?? '') ?>
    </span></td>
    </tr>
    <tr>
      <td colspan="2" class="sub-title">Other documents</td>
      <td colspan="2"><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data9['list_documents'] ?? '') ?>
    </span></td>
      <td colspan="2"><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data10['NA'] ?? '') ?>
    </span></td>
    </tr>
  </table>
  <table>
  <tr>
    <td colspan="5" class="title-row">DIMENSIONS DETAILS</td>
  </tr>
  <tr class="sub-title">
    <td>Description</td>
    <td>East</td>
    <td>West</td>
    <td>North</td>
    <td>South</td>
  </tr>
  <tr>
    <td class="sub-title">As per Documents</td>
       <td><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data6['dimension_as_per_document_east'] ?? '') ?>
    </span></td>
       <td><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data6['dimension_as_per_document_west'] ?? '') ?>
    </span></td>
    <td><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data6['dimension_as_per_document_north'] ?? '') ?>
    </span></td>
    <td><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data6['dimension_as_per_document_south'] ?? '') ?>
    </span></td>
 
  </tr>
  <tr>
    <td class="sub-title">As per Site / Actual</td>
      <td><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data6['dimension_as_per_site_east'] ?? '') ?>
    </span></td>
    <td> <span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data6['dimension_as_per_site_west'] ?? '') ?>
    </span></td>
     <td><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data6['dimension_as_per_site_north'] ?? '') ?>
    </span></td>
    <td><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data6['dimension_as_per_site_south'] ?? '') ?>
    </span></td>
  
  </tr>

  <!-- BOUNDARIES DETAILS -->
  <tr>
    <td colspan="5" class="title-row">BOUNDARIES DETAILS</td>
  </tr>
  <tr class="sub-title">
    <td>Description</td>
    <td>East</td>
    <td>West</td>
    <td>North</td>
    <td>South</td>
  </tr>
  <tr>
    <td class="sub-title">As per Documents</td>
    <td><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data3['direction_as_per_document_east'] ?? '') ?>
    </span></td>
    <td> <span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data3['direction_as_per_document_west'] ?? '') ?>
    </span></td>
    <td><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data3['direction_as_per_document_north'] ?? '') ?>
    </span></td>
    <td><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data3['direction_as_per_document_south'] ?? '') ?>
    </span></td>
    
    </tr>
  <tr>
    <td class="sub-title">As per Site / Actual</td>
    <td><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data3['direction_as_per_site_east'] ?? '') ?>
    </span></td>
    <td> <span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data3['direction_as_per_site_west'] ?? '') ?>
    </span></td>
     <td><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data3['direction_as_per_site_north'] ?? '') ?>
    </span></td>
    <td><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data3['direction_as_per_site_south'] ?? '') ?>
    </span></td>
    
  </tr>
  
  <tr>
    <td class="sub-title">Boundaries Matching</td>
    <td><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data3['boundaries_matching'] ?? '') ?>
    </span></td>
    <td>Mismatch</td>
    <td colspan="2"><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data3['if_not_matching_then'] ?? '') ?>
    </span></td>
  </tr>
</table>

<br>

<!-- OTHER PROPERTY DETAILS -->
<table id="input">
  <tr>
    <td colspan="6" class="title-row">PROPERTY DETAILS</td>
  </tr>
  <tr>
    <td class="sub-title" colspan="1">Status of Land Holding - LeaseHold or Freehold</td>
    <td colspan="3"><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data2['property_leasehold_freehold'] ?? '') ?>
    </span></td>
    <td class="sub-title" colspan="1">Developed By(Authority)</td>
    <td colspan="3"><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data3['property_location_in'] ?? '') ?>
    </span></td>
  </tr>
  <tr>
    <td class="sub-title" colspan="1">Type of Property As per document</td>
    <td colspan="3"><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data4['approved_property_usage'] ?? '') ?>
    </span></td>
    <td class="sub-title" colspan="1">Type of property at site</td>
    <td colspan="3"><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data4['current_property_usage'] ?? '') ?>
    </span></td>
  </tr>
  <tr>
    <td class="sub-title" colspan="1">Location/Zoning as per Master Plan - (Resi/Comm/Mixed/Industrial)</td>
    <td colspan="3"><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data4['zoning_development_plan'] ?? '') ?>
    </span></td>
    <td class="sub-title" colspan="1">Development of the vicinity in %</td>
    <td colspan="3"><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data2['develop_percent'] ?? '') ?>
    </span></td>
  </tr>
  <tr>
    <td class="sub-title" colspan="1">Distance from nearest KFL Branch</td>
    <td colspan="3"><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data3['distance_from_branch_kms'] ?? '') ?>
    </span></td>
    <td class="sub-title" colspan="1">No. of houses in Village in Rural cases</td>
    <td colspan="3"><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data4['no_of_houses'] ?? '') ?>
    </span></td>
  </tr>
  <tr>
    <td class="sub-title" colspan="1">Approach Road Width</td>
    <td colspan="3"><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data2['width_of_approach_road'] ?? '') ?>
    </span></td>
    <td class="sub-title" colspan="1">Approach road type-CC/Bitumen/Gravel /Kaccha</td>
    <td colspan="3"><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data2['type_of_approach_road'] ?? '') ?>
    </span></td>
  </tr>
  <tr>
    <td class="sub-title" colspan="1">Govt road or Private passage</td>
    <td colspan="3"><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data2['approach_road_to_property'] ?? '') ?>
    </span></td>
    <td class="sub-title" colspan="1">Plot Demarcation available</td>
    <td colspan="3"><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data2['demarcated_at_site'] ?? '') ?>
    </span></td>
  </tr>
  <tr>
    <td class="sub-title" colspan="1">Identified Through (legal docs / Site Map / Customer /local enquiry)</td>
    <td colspan="3"><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data3['property_identified_through'] ?? '') ?>
    </span></td>
    <td class="sub-title" colspan="1">Within  Corporation / Urban Development / GP Limit</td>
    <td colspan="3"><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data3['property_location_in'] ?? '') ?>
    </span></td>
  </tr>
  <tr>
    <td class="sub-title" colspan="1">Type of Structure (RCC/LB/truss roof/Stone roof/ACC or Tin shed/tile roof/ Mud house)</td>
    <td colspan="3"><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data4['structure_type'] ?? '') ?>
    </span></td>
    <td class="sub-title" colspan="1">Person Met at site and his relationship with owner</td>
    <td colspan="3"><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data2['person_meet_at_site_contact'] ?? '') ?>
    </span></td>
  </tr>
  <tr>
    <td class="sub-title" colspan="1">Occupancy status</td>
    <td colspan="3"><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data2['occupancy_status'] ?? '') ?>
    </span></td>
    <td class="sub-title" colspan="1">Occupied since</td>
    <td colspan="3"><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data2['occupied_since'] ?? '') ?>
    </span></td>
  </tr>
  <tr>
    <td class="sub-title" colspan="1">Age of the Property in yrs</td>
    <td colspan="3"><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data2['age_of_property'] ?? '') ?>
    </span></td>
    <td class="sub-title" colspan="1">Residual Life of Property</td>
    <td colspan="3"><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data2['residual_age_of_property'] ?? '') ?>
    </span></td>
  </tr>
  <tr>
    <td class="sub-title" colspan="1">Availability of basic amenities like - electricity, water etc.</td>
    <td colspan="3"><input type="text" value="Available"readonly></td>
    <td class="sub-title" colspan="1">Maintenance level of building in terms of age/coverage/poor</td>
    <td colspan="3"><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data2['structurally_fit'] ?? '') ?>
    </span></td>
  </tr>
  <tr>
    <td class="sub-title" colspan="1">Property situated near nala /open canal</td>
    <td colspan="3"><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data4['presence_of_nala'] ?? '') ?>
    </span></td>
    <td class="sub-title" colspan="1">Distance from Nala/Open Canal</td>
    <td colspan="3"><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data10['NA'] ?? '') ?>
    </span></td>
  </tr>
  <tr>
    <td class="sub-title" colspan="1"><strong>Distance from High Tension Line if HT line is witnessed</strong></td>
    <td colspan="3"><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data4['vertical_distance_from_line'] ?? '') ?>
    </span></td>
    <td class="sub-title" colspan="1"><strong>Seismic Zone Classification</strong></td>
    <td colspan="3"><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data4['seismic_zone'] ?? '') ?>
    </span></td>
  </tr>
  <tr>
    <td class="sub-title" colspan="1"><strong>Locality Type</strong></td>
    <td colspan="3"><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data2['class_of_locality'] ?? '') ?>
    </span></td>
    <td class="sub-title" colspan="1"><strong>Marketability</strong></td>
    <td colspan="3"><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data9['markebility'] ?? '') ?>
    </span></td>
  </tr>
  <tr>
    <td  class="sub-title" colspan="1"><strong>Market Feedback</strong>
    <td colspan="3"><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars('LOCAL ENQUIRY') ?>
    </span></td>
    <td class="sub-title" colspan="1">Any hazard in the event of Earthquakes / land slide / Cyclone / Flood / chemical hazardous / Fire Hazardous / Tsunamis etc as per guideline of NDMA</td>
    <td colspan="3"><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data10['NA'] ?? '') ?>
    </span></td>
  </tr>
</table>
<table>
  <tr>
    <td colspan="6" class="title-row">BUILDING PARAMETERS</td>
  </tr>
  <tr>
    <td class="sub-title">Is the plan in line with the local authority norms</td>
    <td><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data10['NA'] ?? '') ?>
    </span></td>
    <td class="sub-title">Number of floors permitted</td>
    <td><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data10['NA'] ?? '') ?>
    </span></td>
    <td class="sub-title">Number of floors constructed</td>
    <td><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data10['NA'] ?? '') ?>
    </span></td>
  </tr>
  <tr>
    <td class="sub-title">FSI achieved</td>
    <td><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data9['fsi_deviation'] ?? '') ?>
    </span></td>
    <td class="sub-title">Risk of demolition</td>
    <td><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data9['demolition_risk_1'] ?? '') ?>
    </span></td>
    <td class="sub-title">Chances of Compounding</td>
    <td><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data10['NA'] ?? '') ?>
    </span></td>
  </tr>
  <tr>
    
    <td class="sub-title">Setback Deviation (%)</td>
    <td><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data10['NA'] ?? '') ?>
    </span></td>
    <td class="sub-title">Vertical Deviation</td>
    <td><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data9['vertical_deviation'] ?? '') ?>
    </span></td>
    <td class="sub-title">Any extension in future?</td>
    <td><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data4['abutting_agriculture_land'] ?? '') ?>
    </span></td>
  </tr>
</table>
<table>
  <!-- VALUATION OF PROPERTY -->
  <tr>
    <td colspan="8" class="title-row">VALUATION OF PROPERTY (FAIR MARKET VALUATION / DISTRESS VALUATION)</td>
  </tr>
  <tr class="sub-title">
    <td>Area Type</td>
    <td>As per Plan/deed (in sqft)</td>
    <td>As per Site (in sqft)</td>
    <td>Permissible (in sqft)</td>
    <td>Rate/Sqft</td>
    <td>% completed</td>
    <td colspan="2">Valuation INR</td>
  </tr>
  <tr>
    <td class="sub-title">Plot Area </td>
    <td><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data8['document_area_saledeed'] ?? '') ?>
    </span></td>
    <td><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data6['actual_plot_square_feet'] ?? '') ?>
    </span></td>
    <td><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data6['final_plot_square_feet'] ?? '') ?>
    </span></td>
    <td><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data6['final_plot_rate'] ?? '') ?>
    </span></td>
    <td><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars('100%') ?>
    </span></td>
    <td colspan="2"><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data6['finally_plot_valuation'] ?? '') ?>
    </span></td>
  </tr>
  <tr>
    <td class="sub-title"><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data6['construction_name_1'] ?? '') ?>
    </span></td>
    <td><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data10['NA'] ?? '') ?>
    </span></td>
    <td><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data8['ground_actual'] ?? '') ?>
    </span></td>
    <td><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data6['construction_area_sqft_1'] ?? '') ?>
    </span></td>
    <td><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data6['construction_rate_1'] ?? '') ?>
    </span></td>
    <td><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data8['stage_construction_actual_present_completion'] ?? '') ?>
    </span></td>
    <td colspan="2"><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data6['construction_valuation_1'] ?? '') ?>
    </span></td>
  </tr>
  <tr>
    <td class="sub-title"><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data6['construction_name_2'] ?? '') ?>
    </span></td>
    <td><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data10['NA'] ?? '') ?>
    </span></td>
    <td><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data8['first_actual'] ?? '') ?>
    </span></td>
    <td><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data6['construction_area_sqft_2'] ?? '') ?>
    </span></td>
    <td><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data6['construction_rate_2'] ?? '') ?>
    </span></td>
    <td><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data8['stage_construction_recommend_present_completion'] ?? '') ?>
    </span></td>
    <td colspan="2"><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data6['construction_valuation_2'] ?? '') ?>
    </span></td>
  </tr>
  <tr>
    <td class="sub-title"><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data6['construction_name_3'] ?? '') ?>
    </span></td>
    <td><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data10['NA'] ?? '') ?>
    </span></td>
    <td><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data8['second_actual'] ?? '') ?>
    </span></td>
    <td><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data6['construction_area_sqft_3'] ?? '') ?>
    </span></td>
    <td><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data6['construction_rate_3'] ?? '') ?>
    </span></td>
    <td><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data8['description_stage_construction_allotted'] ?? '') ?>
    </span></td>
    <td colspan="2"><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data6['construction_valuation_3'] ?? '') ?>
    </span></td>
  </tr>

  <tr>
    <td class="sub-title">Fair Market Value (INR) @ Present Stage of Construction</td>
    <td colspan="6"><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data6['total_finally_area_valuation'] ?? '') ?>
    </span></td>
  </tr>
  <tr>
    <td class="sub-title">Forced Sale Value (INR) @ 80%</td>
    <td colspan="6"><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data6['total_distress_value'] ?? '') ?>
    </span></td>
  </tr>
  <tr>
    <td class="sub-title" rowspan="3    ">Price confirm from</td>
    <td colspan="4" class="sub-title">Local Property Dealer / Local Person Name</td>
    <td colspan="4"><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data10['NA'] ?? '') ?>
    </span></td>
  </tr>
  <tr>
  
    <td colspan="4" class="sub-title">Local Dealer No. / Local Dealer Shop Name</td>
    <td colspan="4"><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data10['NA'] ?? '') ?>
    </span></td>
  </tr>
  <tr>
  
    <td colspan="4" class="sub-title">Value Rate According to Dealer</td>
    <td colspan="4"><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data10['NA'] ?? '') ?>
    </span></td>
  </tr>
</table>
<table border="1" cellspacing="0" cellpadding="5">
  

  <!-- Government Valuation -->
  <tr>
    <td colspan="6" align="center" style="font-weight:bold; background:#f2e6e6; text-align:center;">AS PER GOVT. VALUE OF PROPERTY</td>
  </tr>
   <tr>
    <td class="sub-title">Government Guideline/Circle Rate for Land (Rs Per Sq.ft)</td>
    <td colspan="2"><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data6['gov_plot_area_rate'] ?? '') ?>
    </span></td>
    <td class="sub-title">Land Value as per Govt Rate (Rs)</td>
    <td colspan="2"><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data6['gov_plot_area_valuation'] ?? '') ?>
    </span></td>
  </tr>
  <tr>
    <td class="sub-title">Government Guideline/Circle Rate for Building(Rs Per Sq.ft)</td>
    <td colspan="2"><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data6['gov_construction_rate1'] ?? '') ?>
    </span></td>
    <td class="sub-title">Flat / Apartment Value as per Govt Rate (Rs)</td>
    <td colspan="2"><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data6['gov_construction_valuation1'] ?? '') ?>
    </span></td>
  </tr>
   
  <tr>
    <td class="sub-title">Total Valuation of Property as Per Government Rate</td>
    <?php
$guideline = floatval($data6['gov_plot_area_valuation'] ?? 0);
$rate = floatval($data6['gov_construction_valuation1'] ?? 0);

$total = $guideline + $rate ;
?>

<td colspan="2">
    <span style="display: inline-block; min-width: 50px; padding: 2px;" readonly>
        <?= htmlspecialchars(number_format($total, 2)) ?>
    </span>
</td>


    <td class="sub-title">Sub Registrar office & Location Name</td>
    <td colspan="2"><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data3['address_line_3_as_per_doc'] ?? '') ?>
    </span></td>
  </tr>

  <!-- Utility Connection -->

  <tr>
    <td colspan="6" align="center" style="font-weight:bold; background:#f2e6e6; text-align:center;"></td>
  </tr>
  <tr>

    <td colspan="2" align="center" class="sub-title">As per Documents</td>
    <td colspan="2" align="center" class="sub-title">As per Actual</td>
    <td colspan="2" align="center" class="sub-title">According to Local Bye laws</td>

  </tr>
  <tr>
    <td colspan="2" align="center"><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data10['NA'] ?? '') ?>
    </span></td>
    <td colspan="2" align="center"><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data10['NA'] ?? '') ?>
    </span></td>
    <td colspan="2" align="center"><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data10['NA'] ?? '') ?>
    </span></td>
 
  </tr>
  <tr>
    <td colspan="6" align="center" class="sub-title" style="font-weight:bold; background:#f2e6e6; text-align:center;">UTILITY CONNECTION</td>
  </tr>
  <tr>
  <td align="center" class="sub-title">Electricity bill in mentioned Meter no.</td>
    <td align="center"><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data2['electric_meter_no'] ?? '') ?>
    </span></td>
    <td align="center" class="sub-title">On site available meter no.</td>
    <td align="center"><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data10['NA'] ?? '') ?>
    </span></td>
    <td align="center" class="sub-title">Both no. are matched</td>
    <td align="center"><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data10['NA'] ?? '') ?>
    </span></td>
  </tr>
  </tr>

  <!-- Remarks -->

  <tr>
    <td colspan="6" align="center" style="font-weight:bold; background:#f2e6e6; text-align:center;">PROPERTY SPECIFIC REMARKS & OBSERVATION</td>
  </tr>
<tr>
    <td  colspan="6"><span style="white-space: pre-line; font-size:14px; display: block; text-align: left; padding: 0; margin: 0;font-weight:400;"readonly>
        <?= htmlspecialchars($data10['remarks'] ?? '') ?>
    </span></td> 
</tr>

</table>
<table border="1" cellspacing="0" cellpadding="5">
  <tr>
    <td colspan="4" align="center" style="font-weight:bold; background:#f2e6e6; text-align:center;">VALUER CERTIFICATION</td>
  </tr>
  <tr>
    <td class="sub-title">Date of Visit</td>
    <td><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data1['fe_to_coordinator_assign_at'] ?? '') ?>
    </span></td>
    <td class="sub-title">Date of Report Submission</td>
    <td><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
 <?= htmlspecialchars(date('d M Y h:i A', strtotime($data1['report_assigned_at'] ?? ''))) ?>
    </span></td>
  </tr>
  <tr>
    <td class="sub-title">Name of Engineer Visited the property</td>
    <td><input type="text"  value="<?= $engineer_name ?>"readonly></td>
    <td class="sub-title">Authorised Signatory Name & Signature</td>
    <td><input type="text" value="MAGPIE ENGINEERING PVT. LTD"readonly></td>
  </tr>
  <tr>
    <td class="sub-title">Place</td>
    <td colspan="3"><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data1['bank_branchname'] ?? '') ?>
    </span></td>
  </tr>
  <tr>
    <td colspan="4">
     <span style="white-space: pre-line; font-size:14px; display: block; text-align: left; padding: 0; margin: 0;font-weight:400;" readonly>
    <?= nl2br(htmlspecialchars(formatDeclaration($data10['declaration'] ?? ''))) ?>
</span>
    </td>
  </tr>
   <?php
function formatDeclaration($text) {
    // Insert a newline before every occurrence of a number followed by a dot and space (e.g., "1. ", "10. ")
    // Only if it's NOT already at the beginning of the string or a new line
    $text = preg_replace('/(?<!^)(?<!\n)(\d+\.\s)/', "\n$1", $text);
    return $text;
}
?>
</table>

<br><br>

<!-- Signature section -->
<div style="text-align:right; font-weight:bold; margin-right:50px;">
  SANJAY <br>
  RAMGOPAL <br>
  SAINI
</div>
<table>
<tr>
<td colspan="5"> LOCATION CUM ROUTE MAP SHOWING PROPERTY BOUNDARIES FROM NEARBY LANDMARKS WITH APPROX DISTANCE </td>
</tr>
  </tr>
    <td class="sub-title">Coordinates</td>
    <td class="sub-title">Latitude</td>
    <td><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data3['latitude_value'] ?? '') ?>
    </span></td>
    <td class="sub-title">Longitude</td>
    <td><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data3['longitude_value'] ?? '') ?>
    </span></td>
  </tr> 
  </table>
<table>
<tr><th style="margin-bottom:-18px;">PHOTOGRAPH OF THE PROPERTY</tr></th></table>
<br>

    
<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

$servername = "localhost";
$username   = "root";
$password   = "";
$dbname     = "project_db";

$conn = new mysqli($servername, $username, $password, $dbname);
if ($conn->connect_error) {
    die("Connection failed: " . htmlspecialchars($conn->connect_error));
}

$reference_id = $_SESSION['reference_id'] ?? null;
$reference_id = $_GET['reference_id'] ?? $reference_id;

if ($reference_id) {

    // Map captions
    $captions = [
        'image1'  => 'EXTERNAL PHOTOS',
        'image2'  => 'Kitchen',
        'image3'  => 'Selfie',
        'image4'  => 'Electric Meter',
        'image6'  => 'Other 1',
        'image7'  => 'Other 2',
        'image8'  => 'Other 3',
        'image9'  => 'Other 4',
        'image10' => 'Other 5',
        'image11' => 'Other 6',
        'image12' => 'Other 7',
        'image13' => 'Other 8',
        'image14' => 'Other 9',
        'image15' => 'Other 10',
        'image16' => 'Other 11',
        'image17' => 'Other 12',
        'image18' => 'Other 13',
        'image19' => 'Other 14',
        'image20' => 'Other 15',
    ];

    // === Helper: EXIF-aware orientation detection ===
    function classify_orientation_after_exif(string $imageData): ?string {
        $size = @getimagesizefromstring($imageData);
        if (!$size || !isset($size[0], $size[1])) {
            return null;
        }
        $width  = (int)$size[0];
        $height = (int)$size[1];

        $mime = $size['mime'] ?? '';
        if ($mime === 'image/jpeg' && function_exists('exif_read_data')) {
            $tmp = @tempnam(sys_get_temp_dir(), 'exif_');
            if ($tmp !== false) {
                @file_put_contents($tmp, $imageData);
                $exif = @exif_read_data($tmp);
                @unlink($tmp);

                if (!empty($exif['Orientation'])) {
                    $orientation = (int)$exif['Orientation'];
                    if ($orientation === 6 || $orientation === 8) {
                        $t = $width; $width = $height; $height = $t;
                    }
                }
            }
        }
        return ($width >= $height) ? 'horizontal' : 'vertical';
    }

    // === Helper: Fix orientation physically with Imagick ===
    function fixImageOrientation($binaryData) {
        $img = new Imagick();
        $img->readImageBlob($binaryData);

        switch ($img->getImageOrientation()) {
            case Imagick::ORIENTATION_BOTTOMRIGHT:
                $img->rotateImage("#000", 180);
                break;
            case Imagick::ORIENTATION_RIGHTTOP:
                $img->rotateImage("#000", 90);
                break;
            case Imagick::ORIENTATION_LEFTBOTTOM:
                $img->rotateImage("#000", -90);
                break;
        }

        $img->setImageOrientation(Imagick::ORIENTATION_TOPLEFT);
        $fixed = $img->getImageBlob();
        $img->destroy();

        return $fixed;
    }

    $sql = "SELECT 
                image1, image2, image3, image4, 
                image6, image7, image8, image9, 
                image10, image11, image12, image13, image14, image15, image16, image17, image18, image19, image20
            FROM final_uploaded_images 
            WHERE reference_id = ?";

    $stmt = $conn->prepare($sql);
    if ($stmt === false) {
        die("Error preparing the SQL statement: " . htmlspecialchars($conn->error));
    }

    $stmt->bind_param("s", $reference_id);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result && $result->num_rows > 0) {
        $horizontal_images = [];
        $vertical_images   = [];

        while ($row = $result->fetch_assoc()) {
            foreach ($row as $key => $imageData) {
                if (!empty($imageData)) {

                    // Actually fix image before displaying
                    $fixedData = fixImageOrientation($imageData);

                    $orientation = classify_orientation_after_exif($fixedData) ?? 'horizontal';
                    $imgString   = base64_encode($fixedData);
                    $caption     = $captions[$key] ?? 'Image';

                    $item = [
                        'data'    => $imgString,
                        'caption' => $caption,
                        'alt'     => $key,
                    ];

                    if ($orientation === 'horizontal') {
                        $horizontal_images[] = $item;
                    } else {
                        $vertical_images[]   = $item;
                    }
                }
            }
        }

 
// Output as a stable 4-column table (works in wkhtmltopdf)
$all_images = array_merge($vertical_images, $horizontal_images);

echo '<table class="image-grid">';
$rows = array_chunk($all_images, 4);
foreach ($rows as $row) {
    echo '<tr>';
    foreach ($row as $img) {
        echo '<td>';
        echo '<div class="img-wrap">';
        echo '<img src="data:image/jpeg;base64,' . $img['data'] . '" alt="' . htmlspecialchars($img['alt']) . '">';
        echo '<div class="caption">' . htmlspecialchars($img['caption']) . '</div>';
        echo '</div>';
        echo '</td>';
    }
    // pad remaining cells to keep 4 columns
    $remaining = 4 - count($row);
    if ($remaining > 0) {
        echo str_repeat('<td></td>', $remaining);
    }
    echo '</tr>';
}
echo '</table>';

    } else {
        echo "<p style='text-align:center;'>No images found.</p>";
    }

    $stmt->close();
} else {
    echo "<p style='text-align:center;'>Reference ID is missing.</p>";
}
?>

    
      <table>
  </tr>
  <tr>

<div class="google-map-container">
<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "project_db";
$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$reference_id = $_SESSION['reference_id'] ?? null;
$reference_id = $_GET['reference_id'] ?? $reference_id;

if ($reference_id) {
    $sql = "SELECT image5 FROM final_uploaded_images WHERE reference_id = ?";
    $stmt = $conn->prepare($sql);
    if ($stmt === false) {
        die("Error preparing the SQL statement: " . $conn->error);
    }

    $stmt->bind_param("s", $reference_id);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows > 0) {
        $row = $result->fetch_assoc();
        if (!empty($row['image5'])) {
                          echo "<p style='text-align:center;'>Location cum Route map showing property boundaries</p>";

            echo '<div><img src="data:image/jpeg;base64,' . base64_encode($row['image5']) . '" alt="Google Map"><p>Google Map</p></div>';
        } else {
            echo "<p style='text-align:center;'>Google Map image not available.</p>";
        }
    } else {
        echo "<p style='text-align:center;'>No record found for Google Map image.</p>";
    }

    $stmt->close();
} else {
    echo "<p style='text-align:center;'>Reference ID is missing.</p>";
}
?>
</tr>
</div>
    </table>
    </table>
    
   <!-- Buttons: Hidden during print -->
<div class="no-print">
  <form method="post">
    <input type="hidden" name="download_images" value="1">
    <button type="submit">Download All Images</button>
  </form>

  <button onclick="setPrintMargins()">DOWNLOAD PDF</button>
</div>

  <script>
    document.getElementById('downloadPdf').addEventListener('click', () => {
      // Select the content you want to convert to PDF
      const element = document.getElementById('content');
      const options = {
        margin:[0,0],
        filename:'report.pdf',
        image: { type: 'jpeg', quality: 0.98 },
        html2canvas: { scale: 2 },
        jsPDF: { unit: 'in', format: 'letter', orientation: 'portrait' }
      };

      // Generate and download the PDF
      html2pdf().set(options).from(element).save();
    });
    function setPrintMargins() {
      const style = document.createElement('style');
      style.innerHTML = `
      @media print {
          body {
            margin:0.5;
          }
        }
      `;
      document.head.appendChild(style);
      window.print();
    }
    // Disable all input fields in the form
    document.querySelectorAll('input').forEach(function(input) {
        input.disabled = true;  // Disables the field completely
    });
     function resizeFakeInput(input) {
    const fake = document.getElementById('fakeWrap');
    fake.textContent = input.value || ' ';
    input.style.height = fake.scrollHeight + 'px';
  }

  // Initialize height
  resizeFakeInput(document.getElementById('longInput'));
   function autoResize(el) {
    el.style.height = 'auto'; // reset height
    el.style.height = el.scrollHeight + 'px'; // set to content height
  }
  // Auto-resize on load
  document.querySelectorAll('.clean-textarea').forEach(t => autoResize(t));
    </script>
</div>
</body>
</html>