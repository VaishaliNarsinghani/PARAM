 
<?php include('auth.php'); ?>
<?php
 // Start the session

  
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

// Increase PHP execution time and memory limit
ini_set('max_execution_time', 600); // Increase execution time to 600 seconds (10 minutes)
ini_set('memory_limit', '4096M'); // Increase memory limit to 4096MB
// Start session




$message = "";  // Feedback message for the user
// Step 2: Retrieve reference_id from session
$reference_id = $_SESSION['reference_id'] ?? null;
$fieldss = [];

// Step 3: Check for old_reference_id in mis table
if ($reference_id) {
    // Database connection
    $servername = "localhost";
    $username = "root";
      $password = "";    $dbname = "project_db";
    $conn = new mysqli($servername, $username, $password, $dbname);
    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }

    // Check if old_reference_id exists for this reference_id
    $sql_check_old = "SELECT old_reference_id FROM mis WHERE reference_id = ?";
    $stmt_check = $conn->prepare($sql_check_old);
    $stmt_check->bind_param("s", $reference_id);
    $stmt_check->execute();
    $result = $stmt_check->get_result();
    $row = $result->fetch_assoc();
    $old_reference_id = $row['old_reference_id'] ?? null;
    $stmt_check->close();

    // If old_reference_id exists, fetch data from technical_details using that
    if (!empty($old_reference_id)) {
        $sql_prop = "SELECT * FROM technical_details WHERE reference_id = ?";
        $stmt_prop = $conn->prepare($sql_prop);
        $stmt_prop->bind_param("s", $old_reference_id);
        $stmt_prop->execute();
        $res_prop = $stmt_prop->get_result();
        $db_data = $res_prop->fetch_assoc() ?: [];
        $stmt_prop->close();

        // Merge session data (priority) with DB data
        $fieldss = array_merge($db_data, $_SESSION['technical_details'] ?? []);
    } else {
        // If no old_reference_id, use only session data
        $fieldss = $_SESSION['technical_details'] ?? [];
    }

    $conn->close();
}


// Handle form submission
if ($_SERVER["REQUEST_METHOD"] === "POST") {
    $action = $_POST['action'] ?? '';
 
    if ($action === 'save') {
      
        $message = "Document Details saved successfully!";
    } elseif ($action === 'submit') {
        // Final submission: Save to database or external storage
        if (saveTechnicalDetailsToDatabase($_SESSION['technical_details'])) {
            // Clear session after successful submission
            unset($_SESSION['technical_details']);
            header("Location: REPORT10.php"); // Redirect to confirmation page
            exit();
        } else {
            $message = "Error occurred while submitting. Please try again.";
        }
    }
}

function saveTechnicalDetailsToDatabase($technical_details) {
    // Placeholder for the database-saving logic
    // Ensure this function is implemented to handle database storage properly
    // For now, return true to simulate a successful save
    return true;
}
?>

<!-- JavaScript for Alert -->
<script>
    <?php if (!empty($message)): ?>
    alert("<?= htmlspecialchars($message) ?>");
    <?php endif; ?>
</script>


<!DOCTYPE html>

<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Property Details Form</title>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
<link rel="shortcut icon" href="favicon.ico" type="image/x-icon">
<!-- <link rel="stylesheet" href="REPORT10.css"> -->
<style>
         * {
  margin: 0;
  padding: 0;
  box-sizing: border-box;
  font-family: "Poppins", "Segoe UI", sans-serif;
}

body {
  background: linear-gradient(135deg, #e0f7fa, #fce4ec, #f3e5f5);
  background-size: 300% 300%;
  animation: gradientBG 12s ease infinite;
  min-height: 100vh;
    text-transform: uppercase;
  padding-top: 110px;
  position: relative;
  color: #2c3e50;
}

/* Animate background */
@keyframes gradientBG {
  0% { background-position: 0% 50%; }
  50% { background-position: 100% 50%; }
  100% { background-position: 0% 50%; }
}

    
        .form-container {
            width: 100%;
            max-width: 100%;
            margin: 0 auto;
            display: flex;
            flex-direction: column;
            gap: 10px;
              text-align: left;
            
        }
       
 
.tab-links {
  position: fixed;
  top: 0;
  left: 0; right: 0;
  z-index: 999;
  display: flex;
  justify-content: space-between;
  padding: 7px;
    gap:10px;
  overflow-x: auto;
  backdrop-filter: blur(12px);
  border-bottom: 2px solid rgba(0,0,0,0.05);
  box-shadow: 0 2px 10px rgba(0,0,0,0.08);
  text-align: center;
}

.tab-links .tab {
   border: 1px solid #ddd;
  padding:2px 35px;
  border-radius: 50px;
  font-size: 14px;
  font-weight: bold;
  color: #444;

  transition: all 0.3s ease;
  cursor: pointer;
}

.tab-links .tab.active {
  background: linear-gradient(135deg, #9d7cc1ff, #5d7aacff);
  color: #fff;
    box-shadow: 0 12px 30px rgba(106, 17, 203, 0.35),
              0 6px 15px rgba(37, 117, 252, 0.25);
  transition: all 0.5s cubic-bezier(0.25, 1, 0.5, 1);
  animation: gradientMove 4s ease infinite, float 6s ease-in-out infinite;
  transform: scale(1.05);
  box-shadow: 0 4px 12px rgba(0,0,0,0.2);

}

/* Tab Icon */
.tab img {
  width: 45px;
  height: 45px;
  margin-bottom:5px;
  transition: transform 0.3s ease;
}
.tab:hover img {
  transform: rotate(10deg) scale(1.1);
}




        /* Styling the scrollbar for the entire page */
::-webkit-scrollbar {
    width: 12px; /* Width of the vertical scrollbar */
    height: 10px; /* Height of horizontal scrollbar */
}
th{
   font-size:15px;background: linear-gradient(135deg, #e4dee7ff);
  color:black;
   font-weight:600;
    box-shadow: 0 12px 30px rgba(106, 17, 203, 0.35),
              0 6px 15px rgba(37, 117, 252, 0.25);
  transition: all 0.5s cubic-bezier(0.25, 1, 0.5, 1);
  animation: gradientMove 4s ease infinite, float 6s ease-in-out infinite;
  transform: scale(1.05);
  box-shadow: 0 4px 12px rgba(0,0,0,0.2);"
}
/* Styling the scrollbar track */
::-webkit-scroltab-linkslbar-track {
    background: linear-gradient(135deg, #f0f0f0, #e0e0e0); /* Light gradient track */
    border-radius: 10px; /* Rounded corners */
    box-shadow: inset 0 0 10px rgba(0, 0, 0, 0.1); /* Subtle shadow */
}

/* Styling the scrollbar thumb (the draggable part) */
::-webkit-scrollbar-thumb {
    background: linear-gradient(135deg, #2f7cab, #0056b3); /* Gradient thumb */
    border-radius: 10px; /* Rounded corners */
    border: 3px solid transparent; /* Add space around thumb */
    background-clip: content-box; /* Ensures the thumb’s background doesn’t overlap the border */
    transition: background 0.3s ease, transform 0.3s ease; /* Smooth transition for hover */
}

/* Hover effect for the scrollbar thumb */
::-webkit-scrollbar-thumb:hover {
    background: linear-gradient(135deg, #0056b3, #003d80); /* Darker gradient on hover */
    transform: scale(1.1); /* Slightly enlarge the thumb */
}

/* Styling the horizontal scrollbar */
::-webkit-scrollbar-horizontal {
    height: 8px;
}

/* Styling the horizontal scrollbar track */
::-webkit-scrollbar-track-horizontal {
    background: linear-gradient(135deg, #f0f0f0, #e0e0e0); /* Light gradient track */
    border-radius: 10px;
    box-shadow: inset 0 0 10px rgba(0, 0, 0, 0.1);
}

/* Styling the horizontal scrollbar thumb */
::-webkit-scrollbar-thumb-horizontal {
    background: linear-gradient(135deg, #2f7cab, #0056b3);
    border-radius: 10px;
    border: 3px solid transparent;
    background-clip: content-box;
    transition: background 0.3s ease, transform 0.3s ease;
}

/* Hover effect for horizontal scrollbar thumb */
::-webkit-scrollbar-thumb-horizontal:hover {
    background: linear-gradient(135deg, #0056b3, #003d80);
    transform: scale(1.1); /* Slightly enlarge the thumb */
}

/* -------------------------------
   Header
-------------------------------- */

      .header {
 
   
 font-size:15px;background: linear-gradient(135deg, #e4dee7ff);
  color:black;
  font-weight:600;
  padding: 16px;
  text-align: center;
  font-size: 20px;
  font-weight: 700;
  letter-spacing: 1px;
  border-bottom: 4px solid #fff;
  box-shadow: 0 4px 15px rgba(0,0,0,0.2);
  text-transform: uppercase;
}


/* Subtle glowing effect under header */
.header::after {
  content: "";
  position: absolute;
  left: 0;
  bottom: -10px;
  width: 100%;
  height: 10px;
  background: radial-gradient(circle, rgba(106,17,203,0.4) 0%, transparent 70%);
  filter: blur(8px);
  z-index: -1;
}

/* Text shine effect */
.header span {
  background: linear-gradient(90deg, #ffffff, #d1c4e9, #ffffff);
  background-clip: text;
  -webkit-background-clip: text;
  color: transparent;
  animation: shine 5s linear infinite;
  display: inline-block;
}

/* Hover effect on header */
.header:hover {
  transform: translateY(-2px);
  box-shadow: 0 15px 35px rgba(0,0,0,0.3);
}

/* Responsive tweaks */
@media (max-width: 768px) {
  .header {
    font-size: 1.6rem;
    padding: 18px 12px;
  }
}

@media (max-width: 480px) {
  .header {
    font-size: 1.4rem;
    letter-spacing: 1px;
  }
}

/* Animations */
@keyframes headerGradient {
  0% { background-position: 0% 50%; }
  50% { background-position: 100% 50%; }
  100% { background-position: 0% 50%; }
}

@keyframes shine {
  0% { background-position: -200%; }
  100% { background-position: 200%; }
}


        /* Main Content Styling */
        form {
            width: 100%;
        }

table {
  width: 100%;
  border-collapse: collapse;
  margin: 10px 0;
}

td {
  padding: 10px;
  font-size:16px;
  vertical-align: middle;
  transition: background 0.3s;
}

td:nth-child(odd) {
  background: #f0f8ff;
  font-weight: 600;
  color: #2c3e50;
}

td:nth-child(even) {
  background: #ffffff;
}

input[type="text"] {
  width: 100%;
  padding: 8px 12px;
  border: 1px solid #ddd;
  border-radius: 8px;
  transition: border-color 0.3s, box-shadow 0.3s;
}

input[type="text"]:focus {
  border-color: #6a11cb;
  box-shadow: 0 0 6px rgba(106, 17, 203, 0.4);
  outline: none;
}
/* Enhanced Submit Button */
.submit-button {
  display: flex;
  justify-content: center;
  margin: 40px 0;
  perspective: 1000px;
}

/* Button styling */
.submit-button button,
.submit-button input[type="submit"] {
  background: linear-gradient(135deg, #6a11cb 0%, #2575fc 100%);
  background-size: 200% 200%;
  border: none;
  padding: 8px 35px;
  border-radius: 999px;
  color: #fff;
  font-size: 20px;
  cursor: pointer;
  font-weight: 800;
  letter-spacing: 0.5px;
  box-shadow: 0 12px 30px rgba(106, 17, 203, 0.35),
              0 6px 15px rgba(37, 117, 252, 0.25);
  transition: all 0.5s cubic-bezier(0.25, 1, 0.5, 1);
  animation: gradientMove 4s ease infinite, float 6s ease-in-out infinite;
  position: relative;
  overflow: hidden;
  outline: none;
  -webkit-tap-highlight-color: transparent;
  transform-style: preserve-3d;
  text-transform: uppercase;
}

/* Shimmer highlight effect */
.submit-button button::before {
  content: "";
  position: absolute;
  top: -50%;
  left: -50%;
  width: 170%;
  height: 170%;
  background: linear-gradient(
    60deg, 
    rgba(255,255,255,0) 0%, 
    rgba(255,255,255,0.15) 50%, 
    rgba(255,255,255,0) 100%
  );
  transform: rotate(25deg) translateX(-100%);
  transition: transform 1.2s cubic-bezier(0.23, 1, 0.32, 1);
  pointer-events: none;
}

/* Hover effects */
.submit-button button:hover {
  transform: translateY(-8px) scale(1.08) rotateX(10deg);
  box-shadow: 0 25px 50px rgba(106, 17, 203, 0.45),
              0 15px 30px rgba(37, 117, 252, 0.35),
              0 0 40px rgba(255, 255, 255, 0.2);
  filter: brightness(1.15) saturate(1.2);
  letter-spacing: 1px;
}

.submit-button button:hover::before {
  transform: rotate(25deg) translateX(100%);
}

/* Active (press) effect */
.submit-button button:active {
  transform: translateY(-2px) scale(0.98);
  box-shadow: 0 8px 20px rgba(106, 17, 203, 0.3);
  transition: all 0.1s ease;
}

/* Pulsing glow effect */
.submit-button button::after {
  content: "";
  position: absolute;
  inset: -4px;
  border-radius: 999px;
  background: linear-gradient(135deg, #6a11cb, #2575fc, #9d7cc1, #5d7aac);
  background-size: 300% 300%;
  z-index: -1;
  filter: blur(12px);
  opacity: 0.7;
  animation: gradientMove 5s ease infinite, pulse 3s ease infinite;
  pointer-events: none;
}

/* Sparkle particles */
.submit-button .sparkle {
  position: absolute;
  width: 4px;
  height: 4px;
  background: white;
  border-radius: 50%;
  pointer-events: none;
  opacity: 0;
  animation: sparkle 1.5s linear infinite;
}

/* Keyframes for animations */
@keyframes gradientMove {
  0% { background-position: 0% 50%; }
  50% { background-position: 100% 50%; }
  100% { background-position: 0% 50%; }
}

@keyframes pulse {
  0% { opacity: 0.5; transform: scale(0.95); }
  50% { opacity: 0.8; transform: scale(1.05); }
  100% { opacity: 0.5; transform: scale(0.95); }
}

@keyframes float {
  0% { transform: translateY(0px); }
  50% { transform: translateY(-5px); }
  100% { transform: translateY(0px); }
}

@keyframes sparkle {
  0% {
    opacity: 0;
    transform: translate(0, 0) scale(0);
  }
  20% {
    opacity: 1;
    transform: translate(var(--sparkle-x), var(--sparkle-y)) scale(1);
  }
  80% {
    opacity: 1;
  }
  100% {
    opacity: 0;
    transform: translate(
      calc(var(--sparkle-x) * 1.5), 
      calc(var(--sparkle-y) * 1.5)
    ) scale(0);
  }
}

.side-buttons {
  position: fixed;
  top: 25%;
  right: 20px;
  display: flex;
  flex-direction: column;
  gap: 12px;
  z-index: 1000;
}

.side-buttons button {
  background: linear-gradient(145deg, #6a11cb, #2575fc);
  border: none;
  border-radius: 50%;
  width: 55px;
  height: 55px;
  display: flex;
  align-items: center;
  justify-content: center;
  box-shadow: 0 5px 12px rgba(0,0,0,0.25);
  transition: all 0.3s ease;
}

.side-buttons button:hover {
  transform: rotate(15deg) scale(1.1);
  background: linear-gradient(145deg, #2575fc, #6a11cb);
}

.side-buttons button img {
  width: 24px;
  height: 24px;
  filter: brightness(0) invert(1);
}



        @media (max-width: 768px) {
            .side-buttons {
                top: 15%;
                right: 10px;
            }

            .tab-links {
                flex-wrap: wrap;
            }
        }

        @media (max-width: 480px) {
            .tab-links button {
                padding: 8px 10px;
            }

            .header {
                font-size: 16px;
            }

            td {
                font-size: 14px;
            }

            input[type="text"] {
                font-size: 14px;
            }

            .side-buttons {
                top: 10%;
                right: 5px;
            }
        }
        .image-preview-container {
    display: flex;
    flex-wrap: wrap;
    gap: 10px;
    margin-top: 20px;
    background-color: #f8f9fa;
    border: 2px dashed #dcdcdc;
    padding: 10px;
    border-radius: 8px;
    /* justify-content: center; */
    align-items: center;
    text-align: center;
}

.image-preview-container p {
    color: #888;
    font-size: 14px;
}

.image-preview-container.hidden {
    display: none;
}

/* File input trigger button styling */
.side-buttons button {
    background-color: #2f7cab;
    border: none;
    padding: 10px;
    cursor: pointer;
    border-radius: 50%;
    width: 50px;
    height: 50px;
    display: flex;
    align-items: center;
    justify-content: center;
    transition: background-color 0.3s;
}  
.rotating-text {
            color:black;
    perspective: 1000px; /* Adds a 3D perspective effect */
    font-size: 1.5rem;
    font-weight:bold;
    width: 100%;
    animation: rotate360 3s linear infinite;
    display: inline-block;
    margin-bottom:10px;
    transform-origin: center center; /* Rotates around its center */
    text-align:center;
    /* margin-left:20px; */
    font-style: italic;
    text-shadow: 
    1px 1px 2px rgba(235, 244, 243, 0.97),
    2px 2px 4px rgba(246, 242, 242, 0.4),
    3px 3px 6px rgba(249, 252, 252, 0.89),
    4px 4px 8px rgba(248, 242, 247, 0.93),
    5px 5px 10px rgba(232, 236, 237, 0.4);
  }
  
  /* Keyframes for rotating the text */
  @keyframes rotate360 {
    0% {
      transform: rotateY(0deg); /* Starts with no rotation */
    }
    50% {
      transform: rotateY(0deg); /* Half rotation */
    }
    100% {
      transform: rotateY(360deg); /* Full rotation */
    }
  }
  .logo {
    /* width: 50px; */
    height: 83px;
    padding: 12px;
    padding-bottom: 33px;
    
  }
#sidebar {
    background: #B0C4DE; /* Light Steel Blue */
    color: #2C3E50; 
    position: fixed;
    left: -250px;
    top: 0;
    width: 250px;
    height: 100%;
    /* background-color: #111; */
    color: white;
    transition: left 0.3s ease;
    padding: 20px;
}

#sidebar.active {
    left: 35px;
    /* background:grey; */
}
.sidebar {
    width: 250px;
    background: #B0C4DE; /* Light Steel Blue */
    /* background:rgba(245, 245, 245, 0.37); Light Steel Blue */
    color: black; /* Dark Grayish Blue */
    padding:20px;
    height: 100vh;
    position: fixed;
    left: 0;
    top: 0;
    z-index: 1000;
    transition: transform 0.3s ease-in-out;
  }
  .sidebar.hidden {
    transform: translateX(-100%);
  }
  .sidebar h1 {
font-size: 20px;
margin-top: 10px;
margin-bottom: 20px;
color: #2C3E50; 
}
  .sidebar a {
    padding: 15px 20px;
      margin: 10px 0;
      text-decoration: none;
      color: #2C3E50; /* Dark Grayish Blue */
      font-size:16px;
      font-style: italic;
      font-weight: 500;
      margin-bottom:70px;
      border-radius: 5px;
      transition: all 0.3s ease;
      display: flex;
      align-items: center;
  }

  .sidebar a:hover,
  .sidebar a.active {
    background: #4A90E2; /* Light Blue */
    transform: translateX(10px);
    color: white;
  }
  .sidebar a .icon {
    margin-right: 15px;
    font-size: 18px;
  }
/* Toggle Button */
#toggleSidebar {
    border-radius: 20%;
    position: fixed;
    top: 0px; /* Adjusted for better placement */
    left: 0px; /* Adjusted for better placement */
    z-index: 1000;
    background-color:rgb(130, 183, 226); 
    color: white;
    border: none;
    padding: 6px 12px; /* Added padding for a more clickable area */
    cursor: pointer;
    box-shadow: 0 4px 8px rgba(0, 0, 0, 0.7); /* Adds a soft shadow for depth */
    transition: all 0.3s ease; 
    /* Smooth transition for hover and active states */
}

/* Button hover effect */
#toggleSidebar:hover {
    background-color: #1c6abf; /* Slightly darker shade on hover */
    transform: scale(1); /* Slightly enlarges the button for a professional hover effect */
    box-shadow: 0 6px 12px rgba(0, 0, 0, 0.3); /* Stronger shadow on hover */
}

/* Active state for the button */
#toggleSidebar.active {
    background-color: #1a4f82; /* Darker shade for active state */
    transform: rotate(180deg); /* Smooth rotate effect when the sidebar is active */
}

/* Button icon (if you use an icon inside the button) */
#toggleSidebar i {
    font-size: 18px; /* Adjust the icon size */
    transition: transform 0.3s ease; /* Smooth transition when rotating */
}
.watch-icon {
    margin-right: 16px; /* Adds space between the search text and the watch icon */
    color: #555; /* Optional: sets the color of the watch icon */
}
#toggleSidebar {
    border-radius: 20%;
    position: fixed;
    top: 0px; /* Adjust for better placement */
    /* right: -35px; Position it just outside the sidebar */
    z-index: 1001;
    background-color: rgb(130, 183, 226);
    color: white;
    border: none;
    padding: 6px 12px;
    cursor: pointer;
    box-shadow: 0 4px 8px rgba(0, 0, 0, 0.7);
    transition: all 0.3s ease;
}

/* Button hover effect */
#toggleSidebar:hover {
    background-color: #1c6abf;
    box-shadow: 0 6px 12px rgba(0, 0, 0, 0.3);
}

/* Active state for the button */
#toggleSidebar.active {
    background-color: #1a4f82;
    transform: rotate(180deg); /* Smooth 180-degree rotation */
    box-shadow: 0 6px 12px rgba(0, 0, 0, 0.5);
}

/* Sidebar */
#sidebar.active + #toggleSidebar {
    right: 250px; /* Adjust so button moves into view */
}

/* Sidebar when active */
#sidebar.active {
    left: 0px;
}

/* Sidebar hidden state */
#sidebar {
    position: fixed;
    left: -250px;
    top: 0;
    width: 250px;
    height: 100%;
    background: #B0C4DE;
    color: white;
    transition: left 0.3s ease;
}
#pdf-container {
            width: 100%;
            height: 100%;
            overflow: auto;
        }
        canvas {
            display: block;
            margin: 0 auto;
        }
 .modal {
  display: none;
  position: fixed;
  z-index: 2000;
  inset: 0;
  background: rgba(0,0,0,0.7);
  animation: fadeIn 0.6s ease-out;
}

.modal-content {
  background: #fff;
  border-radius: 15px;
  margin: 60px auto;
  padding: 30px 40px;
  width: 70%;
  max-width: 900px;
  animation: scaleUp 0.5s ease-in-out forwards;
  box-shadow: 0 20px 40px rgba(0,0,0,0.3);
}

 .close {
  float: right;
  font-size: 34px;
  font-weight: bold;
  color: #e74c3c;
  cursor: pointer;
  transition: transform 0.3s ease;
}

.close:hover {
  transform: rotate(90deg);
  color: #c0392b;
}

/* Animations */
@keyframes scaleUp {
  from { transform: scale(0.8); opacity: 0; }
  to { transform: scale(1); opacity: 1; }
}
@keyframes fadeIn {
  from { opacity: 0; }
  to { opacity: 1; }
}


/* Stylish list items inside the modal */
.modal-content ul {
    list-style-type: decimal; /* Use numbers for list items */
    margin-top: 20px;
    padding-left: 25px; /* Add padding to list items */
    color: #555; /* Lighter text color for better contrast */
}

.modal-content ul li {
    /* margin-bottom: 10px; */
    line-height: 1.6; /* Increased line height for better readability */
    padding-left: 10px; /* Padding to align list items nicely */
    transition: transform 0.2s ease-in-out; /* Smooth transition effect on hover */
}

.modal-content ul li:hover {
    transform: translateX(5px); /* Subtle animation on hover for list items */
}

/* Optional: Add a smooth transition effect when content changes */
.modal-content {
    transition: transform 0.5s ease, opacity 0.5s ease;
}
/* Enhanced Dropdown Styles */
select {
  width: 100%;
  padding: 12px 16px;
  border: 2px solid transparent;
  border-radius: 12px;
  background: linear-gradient(135deg, #e0f7fa, #fce4ec, #f3e5f5);
  color: #2c3e50;
  font-size: 16px;
  font-weight: 500;
  cursor: pointer;
  box-shadow: 0 4px 15px rgba(0,0,0,0.08);
  transition: all 0.4s cubic-bezier(0.25, 1, 0.5, 1);
  appearance: none;
  background-size: 200% 200%;
  animation: gradientBG 12s ease infinite;
  position: relative;
  outline: none;
}

/* Custom dropdown arrow */
.select-wrapper {
  position: relative;
  width: 100%;
}

.select-wrapper::after {
  content: "";
  position: absolute;
  top: 50%;
  right: 16px;
  transform: translateY(-50%) rotate(0deg);
  width: 12px;
  height: 12px;
  background-image: url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 24 24' fill='%236a11cb'%3E%3Cpath d='M7 10l5 5 5-5z'/%3E%3C/svg%3E");
  background-repeat: no-repeat;
  background-position: center;
  pointer-events: none;
  transition: transform 0.4s cubic-bezier(0.68, -0.55, 0.27, 1.55);
}

/* Hover effects */
select:hover {
  transform: translateY(-2px);
  box-shadow: 0 8px 25px rgba(106, 17, 203, 0.2);
  border-color: #6a11cb;
}

/* Focus effects */
select:focus {
  border-color: #6a11cb;
  box-shadow: 0 0 0 4px rgba(106, 17, 203, 0.15), 
              0 8px 25px rgba(106, 17, 203, 0.25);
  background: linear-gradient(135deg, #e0f7fa, #fce4ec, #f3e5f5);
  animation: gradientBG 8s ease infinite, pulseFocus 2s ease infinite;
}

/* Expanded state for dropdown */
select:focus + .select-wrapper::after {
  transform: translateY(-50%) rotate(180deg);
}

/* DROPDOWN LIST STYLING (when open) */
select:focus {
  border-radius: 12px 12px 0 0;
}

/* Firefox dropdown list styling */
select option {
  padding: 12px 16px;
  background: rgba(255, 255, 255, 0.98);
  color: #2c3e50;
  border-bottom: 1px solid #f0f0f0;
  transition: all 0.3s ease;
  font-size: 15px;
  cursor: pointer;
}

/* Hover effect for options */
select option:hover,
select option:checked {
  background: linear-gradient(135deg, #9d7cc1, #5d7aac) !important;
  color: white !important;
  box-shadow: 0 4px 12px rgba(0,0,0,0.1);
  transform: translateX(4px);
}

/* Selected option style */
select option:checked {
  background: linear-gradient(135deg, #6a11cb, #2575fc) !important;
  color: white;
  font-weight: 600;
}

/* For Webkit browsers (Chrome, Safari) */
@media screen and (-webkit-min-device-pixel-ratio:0) {
  select {
    padding-right: 40px; /* Extra space for custom arrow */
  }
  
  /* Style the dropdown list itself */
  select:focus {
    border-radius: 12px;
  }
  
  /* Style the dropdown options */
  select option {
    padding: 12px 16px;
    background: rgba(255, 255, 255, 0.98);
    color: #2c3e50;
    border-bottom: 1px solid #f0f0f0;
    transition: all 0.3s ease;
    font-size: 15px;
    cursor: pointer;
  }
  
  /* Hover effect for options in Webkit */
  select option:hover {
    background: linear-gradient(135deg, #9d7cc1, #5d7aac) !important;
    color: white !important;
    padding-left: 20px;
  }
  
  /* Selected option style in Webkit */
  select option:checked {
    background: linear-gradient(135deg, #6a11cb, #2575fc) !important;
    color: white;
    font-weight: 600;
  }
}

/* Animation for dropdown opening */
@keyframes dropdownOpen {
  0% {
    opacity: 0;
    transform: translateY(-10px);
  }
  100% {
    opacity: 1;
    transform: translateY(0);
  }
}

/* Apply animation to dropdown options in Firefox */
@-moz-document url-prefix() {
  select {
    padding-right: 40px; /* Extra space for custom arrow in Firefox */
  }
  
  select option {
    animation: dropdownOpen 0.4s ease forwards;
  }
}

/* Pulse animation for focus state */
@keyframes pulseFocus {
  0% {
    box-shadow: 0 0 0 4px rgba(106, 17, 203, 0.15), 
                0 8px 25px rgba(106, 17, 203, 0.25);
  }
  50% {
    box-shadow: 0 0 0 8px rgba(106, 17, 203, 0.1), 
                0 8px 25px rgba(106, 17, 203, 0.3);
  }
  100% {
    box-shadow: 0 0 0 4px rgba(106, 17, 203, 0.15), 
                0 8px 25px rgba(106, 17, 203, 0.25);
  }
}

/* Enhanced label styling */
td label {
  display: block;
  font-weight: 600;
  margin-bottom: 8px;
  color: #2c3e50;
  transition: color 0.3s ease;
}

/* Hover effect on label */
td:hover label {
  color: #6a11cb;
}

/* Responsive adjustments */
@media (max-width: 768px) {
  select {
    padding: 10px 14px;
    font-size: 15px;
  }
  
  .select-wrapper::after {
    right: 14px;
  }
}

@media (max-width: 480px) {
  select {
    padding: 8px 12px;
    font-size: 14px;
    border-radius: 10px;
  }
  
  .select-wrapper::after {
    right: 12px;
    width: 10px;
    height: 10px;
  }
}

/* Custom dropdown list for modern browsers */
@supports (-webkit-appearance: none) or (appearance: none) or ((-moz-appearance: none) and (pointer-events: all)) {
  .select-wrapper {
    position: relative;
    display: inline-block;
    width: 100%;
  }
  
  .select-wrapper select {
    padding-right: 40px;
    z-index: 1;
  }
  
  .select-wrapper::after {
    z-index: 2;
  }
  
  /* Focus state for modern browsers */
  .select-wrapper select:focus {
    z-index: 3;
  }
}
/* Date Input Container */
.date-input-container {
    position: relative;
    margin: 25px 0;
}

/* Label Styling */
.date-input-container label {
    display: block;
    text-align: left;
    margin-bottom: 8px;
    font-weight: 600;
    color: #2c3e50;
    transition: all 0.3s ease;
}

/* Date Input Styling */
input[type="date"] {
    width: 100%;
    padding: 10px 10px;
    border: 2px solid transparent;
    border-radius: 12px;
    background: linear-gradient(135deg, #e0f7fa, #fce4ec, #f3e5f5);
    color: #2c3e50;
    font-size: 16px;
    font-weight: 500;
    box-shadow: 0 4px 15px rgba(0, 0, 0, 0.08);
    transition: all 0.4s cubic-bezier(0.25, 1, 0.5, 1);
    outline: none;
    cursor: pointer;
}

/* Hover effect */
input[type="date"]:hover {
    transform: translateY(-2px);
    box-shadow: 0 8px 25px rgba(106, 17, 203, 0.2);
    border-color: #6a11cb;
}


/* Pulse animation for focus state */
@keyframes pulseFocus {
    0% {
        box-shadow: 0 0 0 4px rgba(106, 17, 203, 0.15), 
                    0 8px 25px rgba(106, 17, 203, 0.25);
    }
    50% {
        box-shadow: 0 0 0 8px rgba(106, 17, 203, 0.1), 
                    0 8px 25px rgba(106, 17, 203, 0.3);
    }
    100% {
        box-shadow: 0 0 0 4px rgba(106, 17, 203, 0.15), 
                    0 8px 25px rgba(106, 17, 203, 0.25);
    }
}
</style>
</head>
<body>
<button id="toggleSidebar">&#9776;</button>
<div id="sidebar" class="sidebar">
    <div style="display: flex">
      <img class="logo" src="logo.png" alt="" />
      <h1>Magpie Engineering</h1>
    </div>
    <div class="rotating-text">Report Drafter</div>
    <a href="clear_and_go_home.php"><i class="fas fa-home icon"></i>Home</a>        

    
  <a href="clear_sessions.php" class="active"><i class="fas fa-clock watch-icon"></i>Pending For Drafting</a>
 <a href="technical.php"><i class="fas fa-clipboard-list icon"></i> Preview Report</a>      
    <a href="clear_and_logout.php"><i class="fas fa-sign-out-alt icon"></i>Logout</a>
  </div>
<div class="form-container">
        <?php if ($message): ?>
            <div class="success-message">
                <?= htmlspecialchars($message) ?>
            </div>
        <?php endif; ?>
     
        <div class="tab-links">
    <button class="tab" onclick="location.href='REPORT3.php'"><img src="info.png" alt="Icon" width="50  " height="50  ">
    INFO</button>
    <button class="tab " onclick="location.href='REPORT4.php'"><img src="general.png" alt="Icon" width="50  " height="50  "style="margin-bottom:4px;">GENERAL</button>
    <button class="tab" onclick="location.href='REPORT2.php'"> <img src="location.png" alt="Icon" width="50  " height="50  ">
    LOCATION</button>
    <button class="tab " onclick="location.href='REPORT5.php'"><img src="Zoning.png" alt="Icon" width="50  " height="50  ">
    ZONING</button>
    <button class="tab" onclick="location.href='REPORT7.php'"><img src="value.png" alt="Icon" width="50  " height="50  ">
    VALUE</button>
    <button class="tab" onclick="location.href='REPORT9.php'"><img src="Floor.png" alt="Icon" width="50  " height="50  ">
    STRUCTURE</button>
    <button class="tab active" onclick="location.href='REPORT10.php'"><img src="documents.png" alt="Icon" width="50  " height="50  ">
    DOCUMENTS</button>
    <button class="tab" onclick="location.href='REPORT115.php'"><img src="photo.png" alt="Icon" width="50  " height="50  ">
    PHOTOS</button>

    <button class="tab" onclick="location.href='REPORT12.php'"><img src="remark.png" alt="Icon" width="50  " height="50  ">
    REMARK</button>
    <div class="slider"></div>
</div>
        <div class="form-container valuation-table">
            
            
            <form id="autosave-form" action="" method="POST">
                <!-- Technical Documents Details Section -->
                <h2 class="header valuation-table" style="margin-top:10px;">TECHNICAL DOCUMENTS DETAILS</h2>
                <section>
                    <table >
                        <thead>
                            <tr>
                                <th style="padding:8px;">DOCUMENT NAME</th>
                                <th>APPLICABILITY AND AVAILABILITY</th>
                                <th>DOCUMENT APPROVED BY</th>
                                <th>APPROVAL NUMBER</th>
                                <th>APPROVAL DATE</th>
                             </tr>
                        </thead>
                        <tbody>
    <!-- Sanction FLOOR PLAN -->
    <tr>
        <td>Sanction FLOOR PLAN/APPROVED FLOOR PLAN</td>
        <td><input type="text" id="map_available" name="map_available" value="<?= $fieldss['map_available'] ?? '' ?>"></td>
        <td><input type="text" id="sanction_approving_authority" name="sanction_approving_authority" value="<?= $fieldss['sanction_approving_authority'] ?? '' ?>"></td>
        <td><input type="text" id="sanction_approval_no" name="sanction_approval_no" value="<?= $fieldss['sanction_approval_no'] ?? '' ?>"></td>
        <td><input type="date" class="code-block" id="sanction_approval_date" name="sanction_approval_date" value="<?= $fieldss['sanction_approval_date'] ?? '' ?>"></td>
    </tr>

    <!-- APPROVED T&CP LAYOUT PLAN -->
    <tr>
        <td>APPROVED T&CP LAYOUT PLAN</td>
        <td><input type="text" id="layout_applicable" name="layout_applicable" value="<?= $fieldss['layout_applicable'] ?? '' ?>"></td>
        <td><input type="text" id="layout_approving_authority" name="layout_approving_authority" value="<?= $fieldss['layout_approving_authority'] ?? '' ?>"></td>
        <td><input type="text" id="layout_approval_details" name="layout_approval_details" value="<?= $fieldss['layout_approval_details'] ?? '' ?>"></td>
        <td><input type="date" class="code-block" id="layout_approval_date" name="layout_approval_date" value="<?= $fieldss['layout_approval_date'] ?? '' ?>"></td>
    </tr>

    <!-- BUILDING COMPLETION CERTIFICATE -->
    <tr>
        <td>BUILDING COMPLETION CERTIFICATE</td>
        <td><input type="text" id="completion_certificate" name="completion_certificate" value="<?= $fieldss['completion_certificate'] ?? '' ?>"></td>
        <td><input type="text" id="completion_approving_authority" name="completion_approving_authority" value="<?= $fieldss['completion_approving_authority'] ?? '' ?>"></td>
        <td><input type="text" id="completion_approval_details" name="completion_approval_details" value="<?= $fieldss['completion_approval_details'] ?? '' ?>"></td>
        <td><input type="date" class="code-block" id="completion_approval_date" name="completion_approval_date" value="<?= $fieldss['completion_approval_date'] ?? '' ?>"></td>
    </tr>

    <!-- BUILDING OCCUPANCY CERTIFICATE -->
    <tr>
        <td>BUILDING OCCUPANCY CERTIFICATE</td>
        <td><input type="text" id="occupancy_certificate" name="occupancy_certificate" value="<?= $fieldss['occupancy_certificate'] ?? '' ?>"></td>
        <td><input type="text" id="occupancy_approving_authority" name="occupancy_approving_authority" value="<?= $fieldss['occupancy_approving_authority'] ?? '' ?>"></td>
        <td><input type="text" id="occupancy_approval_details" name="occupancy_approval_details" value="<?= $fieldss['occupancy_approval_details'] ?? '' ?>"></td>
        <td><input type="date" class="code-block" id="occupancy_approval_date" name="occupancy_approval_date" value="<?= $fieldss['occupancy_approval_date'] ?? '' ?>"></td>
    </tr>

    <!-- NON AGRICULTURAL PERMISSION -->
    <tr>
        <td>NON AGRICULTURAL PERMISSION / LAND CONVERSION / DIVERSION ORDER</td>
        <td><input type="text" id="na_permission_details" name="na_permission_details" value="<?= $fieldss['na_permission_details'] ?? '' ?>"></td>
        <td><input type="text" id="na_approving_authority" name="na_approving_authority" value="<?= $fieldss['na_approving_authority'] ?? '' ?>"></td>
        <td><input type="text" id="na_approval_details" name="na_approval_details" value="<?= $fieldss['na_approval_details'] ?? '' ?>"></td>
        <td><input type="date" class="code-block" id="na_approval_date" name="na_approval_date" value="<?= $fieldss['na_approval_date'] ?? '' ?>"></td>
    </tr>

    <!-- RERA DETAILS -->
    <tr>
        <td>RERA DETAILS</td>
        <td><input type="text" id="rera_details" name="rera_details" value="<?= $fieldss['rera_details'] ?? '' ?>"></td>
        <td><input type="text" id="rera_approving_authority" name="rera_approving_authority" value="<?= $fieldss['rera_approving_authority'] ?? '' ?>"></td>
        <td><input type="text" id="rera_approval_details" name="rera_approval_details" value="<?= $fieldss['rera_approval_details'] ?? '' ?>"></td>
        <td><input type="date" class="code-block" id="rera_approval_date" name="rera_approval_date" value="<?= $fieldss['rera_approval_date'] ?? '' ?>"></td>
    </tr>

    <!-- LEASE DEED DETAILS -->
    <tr>
        <td>LEASE DEED DETAILS</td>
        <td><input type="text" id="lease_details" name="lease_details" value="<?= $fieldss['lease_details'] ?? '' ?>"></td>
        <td><input type="text" id="lease_approving_authority" name="lease_approving_authority" value="<?= $fieldss['lease_approving_authority'] ?? '' ?>"></td>
        <td><input type="text" id="lease_approval_details" name="lease_approval_details" value="<?= $fieldss['lease_approval_details'] ?? '' ?>"></td>
        <td><input type="date" class="code-block" id="lease_approval_date" name="lease_approval_date" value="<?= $fieldss['lease_approval_date'] ?? '' ?>"></td>
    </tr>

    <!-- OWNERSHIP DOCUMENT 1 -->
    <tr>
        <td>OWNERSHIP DOCUMENT OBTAINED 1</td>
        <td><input type="text" id="ownership1_approving_authority" name="ownership1_approving_authority" value="<?= $fieldss['ownership1_approving_authority'] ?? '' ?>"></td>
        <td><input type="text" id="ownership1_details" name="ownership1_details" value="<?= $fieldss['ownership1_details'] ?? '' ?>"></td>
        <td><input type="text" id="ownership1_no" name="ownership1_no" value="<?= $fieldss['ownership1_no'] ?? '' ?>"></td>
        <td><input type="date" class="code-block" id="ownership1_date" name="ownership1_date" value="<?= $fieldss['ownership1_date'] ?? '' ?>"></td>
    </tr>

    <!-- OWNERSHIP DOCUMENT 2 -->
    <tr>
        <td>OWNERSHIP DOCUMENT OBTAINED 2</td>
        <td><input type="text" id="ownership2_approving_authority" name="ownership2_approving_authority" value="<?= $fieldss['ownership2_approving_authority'] ?? '' ?>"></td>
        <td><input type="text" id="ownership2_details" name="ownership2_details" value="<?= $fieldss['ownership2_details'] ?? '' ?>"></td>
        <td><input type="text" id="ownership2_no" name="ownership2_no" value="<?= $fieldss['ownership2_no'] ?? '' ?>"></td>
        <td><input type="date" class="code-block" id="ownership2_date" name="ownership2_date" value="<?= $fieldss['ownership2_date'] ?? '' ?>"></td>
    </tr>

    <!-- OWNERSHIP DOCUMENT 3 -->
    <tr>
        <td>OWNERSHIP DOCUMENT OBTAINED 3</td>
        <td><input type="text" id="ownership3_approving_authority" name="ownership3_approving_authority" value="<?= $fieldss['ownership3_approving_authority'] ?? '' ?>"></td>
        <td><input type="text" id="ownership3_details" name="ownership3_details" value="<?= $fieldss['ownership3_details'] ?? '' ?>"></td>
        <td><input type="text" id="ownership3_no" name="ownership3_no" value="<?= $fieldss['ownership3_no'] ?? '' ?>"></td>
        <td><input type="date" class="code-block" id="ownership3_date" name="ownership3_date" value="<?= $fieldss['ownership3_date'] ?? '' ?>"></td>
    </tr>

    <!-- OWNERSHIP DOCUMENT 4 -->
    <tr>
        <td>OWNERSHIP DOCUMENT OBTAINED 4</td>
        <td><input type="text" id="ownership4_approving_authority" name="ownership4_approving_authority" value="<?= $fieldss['ownership4_approving_authority'] ?? '' ?>"></td>
        <td><input type="text" id="ownership4_details" name="ownership4_details" value="<?= $fieldss['ownership4_details'] ?? '' ?>"></td>
        <td><input type="text" id="ownership4_no" name="ownership4_no" value="<?= $fieldss['ownership4_no'] ?? '' ?>"></td>
        <td><input type="date" class="code-block" id="ownership4_date" name="ownership4_date" value="<?= $fieldss['ownership4_date'] ?? '' ?>"></td>
    </tr>
<tr>
     <th  colspan="5">.</th>
</tr>
    <table>
    <tr>
        <td >LIST OF DOCUMENTS OBTAINED</td>
        <td><input type="text"placeholder="Enter List Of Documents Obtained"  id="list_documents" name="list_documents" value="<?= $fieldss['list_documents'] ?? '' ?>"></td>
            <td>REPORT POSITIVE / NEGATIVE</td>
            <td>
                <select name="positive_report" style="width:100%; padding:3px;">
                    <option value="">NA</option>
                    <option value="Positive" <?php if (!empty($fieldss['positive_report']) && $fieldss['positive_report'] === 'Positive') echo 'selected'; ?>>Positive</option>
                    <option value="Negative" <?php if (!empty($fieldss['positive_report']) && $fieldss['positive_report'] === 'Negative') echo 'selected'; ?>>Negative</option>
                 <option value="YES" <?php if (!empty($fieldss['positive_report']) && $fieldss['positive_report'] === 'YES') echo 'selected'; ?>>YES</option>
                    <option value="NO" <?php if (!empty($fieldss['positive_report']) && $fieldss['positive_report'] === 'NO') echo 'selected'; ?>>NO</option>
             
                </select>
            </td>
        </tr>
        <tr>
            <td>MARKETABILITY</td>
            <td>
                <select name="markebility" style="width:100%; padding:3px;">
                    <option value="">NA</option>
                    <option value="Good" <?php if (!empty($fieldss['markebility']) && $fieldss['markebility'] === 'Good') echo 'selected'; ?>>Good</option>
                    <option value="Average" <?php if (!empty($fieldss['markebility']) && $fieldss['markebility'] === 'Average') echo 'selected'; ?>>Average</option>
                    <option value="Poor" <?php if (!empty($fieldss['markebility']) && $fieldss['markebility'] === 'Poor') echo 'selected'; ?>>Poor</option>
                </select>
            </td>
  <td>DEMOLITION RISK</td>
  <td >
  <select name="demolition_risk_1" style="width:100%; padding:3px;">
    <option value="">NA</option>
    <option value="High" <?php if (!empty($fieldss['demolition_risk_1']) && $fieldss['demolition_risk_1'] === 'High') echo 'selected'; ?>>High</option>
    <option value="Medium" <?php if (!empty($fieldss['demolition_risk_1']) && $fieldss['demolition_risk_1'] === 'Medium') echo 'selected'; ?>>Medium</option>
    <option value="Low" <?php if (!empty($fieldss['demolition_risk_1']) && $fieldss['demolition_risk_1'] === 'Low') echo 'selected'; ?>>Low</option>
  </select>
</td>

</tr>

                            <tr>
                           <td>PROPERTY OWNER NAME</td>
                           <td ><input type="text" placeholder="Enter Property Owner Name" name="owner_name" value="<?=$fieldss['owner_name'] ?? '' ?>"></td>
                            <td>SELLER NAME</td>
                            <td ><input type="text" placeholder="Enter Seller Name" name="seller_name" value="<?=$fieldss['seller_name'] ?? '' ?>"></td>
                         </tr>   
                          <tr>
                            <td>SELLER TYPE</td>
                            <td ><input type="text" placeholder="Enter Seller Name" name="seller_type" value="<?=$fieldss['seller_type'] ?? '' ?>"></td>
                            <td>FSI DEVIATION</td>
                            <td ><input type="text" placeholder="Enter FSI Deviation" name="fsi_deviation" value="<?= $fieldss['fsi_deviation'] ?? '' ?>"></td>
                         </tr>    
                         
                          <tr>
                            <td>PERMISSIBLE FSI / FAR</td>
                            <td><input type="text" placeholder="Enter FSI Deviation" name="fsi_far_deviation" value="<?= $fieldss['fsi_far_deviation'] ?? '' ?>"></td>


                         <td>VERTICAL DEVIATION</td>
                            <td><input type="text" placeholder="Enter Verticak Deviation" name="vertical_deviation" value="<?= $fieldss['vertical_deviation'] ?? '' ?>"></td>
                          </tr>    
                        </thead>
                      </table>
                        <?php
        // Display the reference_id as a hidden field (assuming it will not be modified by the user)
           $reference_id = $_SESSION['reference_id'] ?? '';
          echo '<input type="hidden" name="reference_id" value="' . htmlspecialchars($reference_id) . '">';
?>
                    </table>
                </section>
                <div class="submit-button">
                <button type="submit" name="action" value="save">Save</button>
           
            </div>
            </form>
        </div>

    </div>
    
  
<script>
    
    document.addEventListener('DOMContentLoaded', () => {
    const form = document.getElementById('autosave-form');

    if (!form) return;

    function gatherFormData(form) {
        const formData = new FormData(form);
        const data = {};
        formData.forEach((value, key) => {
            data[key] = value;
        });
        return data;
    }

    function autoSaveSession() {
        const data = gatherFormData(form);

        fetch('autosave.php', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
                page: 'technical_details',
                data: data
            })
        });
    }

    form.addEventListener('input', autoSaveSession);
});
 


    document.addEventListener("DOMContentLoaded", function () {
    let tabs = document.querySelectorAll(".tab-links .tab");
    let slider = document.querySelector(".tab-links .slider");

    function moveSlider(activeTab) {
        slider.style.width = activeTab.offsetWidth + "px";
        slider.style.left = activeTab.offsetLeft + "px";
    }

    tabs.forEach(tab => {
        tab.addEventListener("click", function () {
            tabs.forEach(t => t.classList.remove("active"));
            this.classList.add("active");
            moveSlider(this);
        });

        // Initialize position on load for the active tab
        if (tab.classList.contains("active")) {
            moveSlider(tab);
        }
    });
});

   
document.getElementById("toggleSidebar").addEventListener("click", function () {
    if (confirm("Are you sure to open the side bar? Your data will be lost/erased.")) {
        // Redirect to "Pending For Drafting" page
        window.location.href = "clear_sessions.php";
    } else {
        // If user clicks Cancel, do nothing
        return false;
    }
});



var modal = document.getElementById("myModal");

// Get the <span> element that closes the modal
var span = document.getElementsByClassName("close")[0];

// Function to show the modal with custom text
function showPopup(text) {
    document.getElementById("modalText").innerText = text;
    modal.style.display = "block";
}

// When the user clicks on <span> (x), close the modal
span.onclick = function() {
    modal.style.display = "none";
}

// When the user clicks anywhere outside of the modal, close it
window.onclick = function(event) {
    if (event.target == modal) {
        modal.style.display = "none";
    }
}

function openGoogleMaps(location) {
            const baseUrl = "https://www.google.com/maps/search/?api=1&query=";
            window.open(baseUrl + encodeURIComponent(location), '_blank');
        }
function triggerFileInput2() {
            document.getElementById("imageInput").click();
        }

        document.getElementById("imageInput").addEventListener("change", function (event) {
            const files = event.target.files;
            const previewContainer = document.getElementById("imagePreviewContainer");

            // Clear previous previews
            previewContainer.innerHTML = "";

            // Display previews for each selected image
            Array.from(files).forEach((file) => {
                if (file.type.startsWith("image/")) {
                    const reader = new FileReader();
                    reader.onload = function (e) {
                        const img = document.createElement("img");
                        img.src = e.target.result;
                        previewContainer.appendChild(img);
                    };
                    reader.readAsDataURL(file);
                }
            });
        });
function triggerFileInput1() {
            document.getElementById("pdfInput").click();
        }

        // Handle file selection
        document.getElementById("pdfInput").addEventListener("change", function (event) {
            const file = event.target.files[0];
            if (file && file.type === "application/pdf") {
                // Create a FileReader instance
                const reader = new FileReader();

                // When the file is read successfully, open it in a new tab
                reader.onload = function (e) {
                    const pdfUrl = e.target.result;

                    // Try to open the PDF in a new tab using embed
                    const newTab = window.open();
                    if (newTab) {
                        newTab.document.write('<html><body><embed src="' + pdfUrl + '" type="application/pdf" width="100%" height="100%"></body></html>');
                        newTab.document.close();

                        // Fallback if the PDF does not load correctly
                        setTimeout(function() {
                            if (newTab.document.body.innerHTML === "") {
                                // Use PDF.js as a fallback to display the PDF
                                newTab.document.body.innerHTML = '<div id="pdf-container" style="width: 100%; height: 100%;"></div>';
                                const loadingTask = pdfjsLib.getDocument(pdfUrl);
                                loadingTask.promise.then(function(pdf) {
                                    pdf.getPage(1).then(function(page) {
                                        const scale = 1.5;
                                        const viewport = page.getViewport({ scale: scale });
                                        const canvas = document.createElement('canvas');
                                        const ctx = canvas.getContext('2d');
                                        canvas.height = viewport.height;
                                        canvas.width = viewport.width;
                                        document.getElementById('pdf-container').appendChild(canvas);

                                        // Render PDF page
                                        page.render({
                                            canvasContext: ctx,
                                            viewport: viewport
                                        });
                                    });
                                });
                            }
                        }, 1000); // Check if the embed failed after 1 second
                    }
                };

                // Read the file as a data URL
                reader.readAsDataURL(file);
            } else {
                alert("Please select a valid PDF file.");
            }
        });
</script>
</body>
</html>
