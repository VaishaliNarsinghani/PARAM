
<?php include('auth.php'); ?>
<?php


ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

// Increase PHP execution time and memory limit
ini_set('max_execution_time', 600); // Increase execution time to 600 seconds (10 minutes)
ini_set('memory_limit', '4096M'); // Increase memory limit to 4096MB
// Start session


// Database connection
$servername = "localhost";
$username = "root";
  $password = "";$dbname = "project_db";
$message = "";

$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Step 1: Get reference_id from session or GET
$reference_id = $_SESSION['reference_id'] ?? null;
$id = isset($_GET['reference_id']) ? $_GET['reference_id'] : $reference_id;

// Save GET reference_id into session if available
if (isset($_GET['reference_id'])) {
    $_SESSION['reference_id'] = $_GET['reference_id'];
}

// Initialize field data
$fieldsss = [];

// Fetch data from DB if reference_id is present
if ($id) {
    $sql = "SELECT * FROM area_valuation WHERE reference_id = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("s", $id);
    $stmt->execute();
    $result = $stmt->get_result();
    $db_data = $result->fetch_assoc() ?: [];
    $stmt->close();

    // Merge session and DB (session takes priority)
    $fieldsss = array_merge($db_data, $_SESSION['area_valuation'] ?? []);
}

// Ensure insurable_value is set based on propertyType
if (isset($_SESSION['area_valuation']['propertyType'])) {
    $type = $_SESSION['area_valuation']['propertyType'];

    if ($type === "Land and Building") {
        $construction = floatval($_SESSION['area_valuation']['finally_construction_valuation'] ?? 0);
        $_SESSION['area_valuation']['insurable_value'] = round($construction, 2);
    } elseif ($type === "Floor Property") {
        $area = floatval($_SESSION['area_valuation']['final_area_square_feet'] ?? 0);
        $_SESSION['area_valuation']['insurable_value'] = round($area * 1200, 2);
    }
}

// Form submission logic
if ($_SERVER["REQUEST_METHOD"] === "POST") {
    if (isset($_POST['action']) && $_POST['action'] === 'save') {
        // Save to session
        $_SESSION['area_valuation'] = array_map('trim', $_POST);
        $_SESSION['area_valuation'] = array_map('trim', $_POST);

        $fieldsss = $_SESSION['area_valuation']; // Update displayed data

        $message = "Details saved successfully!";
    } elseif (isset($_POST['action']) && $_POST['action'] === 'submit') {
        // Final submission to DB
        $success1 = saveAxisDetailsToDatabase($_SESSION['area_valuation']);
        $success2 = saveAreaValuationToDatabase($_SESSION['area_valuation']);

        if ($success1 && $success2) {
            unset($_SESSION['area_valuation']);
            unset($_SESSION['area_valuation']);
            header("Location: technical7.php");
            exit();
        } else {
            $message = "Error occurred while submitting. Please try again.";
        }
    }
}

// Save function placeholder
function saveAxisDetailsToDatabase($data) {
    return true; // Simulated DB save
}
 
// Database connection
$servername = "localhost";
$username = "root";
  $password = "";$dbname = "project_db";
$message = "";

$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Step 1: Retrieve reference_id from session or GET
$reference_id = $_SESSION['reference_id'] ?? null;
$id = isset($_GET['reference_id']) ? $_GET['reference_id'] : $reference_id;

// Save GET reference_id into session if available
if (isset($_GET['reference_id'])) {
    $_SESSION['reference_id'] = $_GET['reference_id'];
}

// Fetch data from DB
$fieldss = []; // For form display
if ($id) {
    $sql = "SELECT * FROM area_valuation WHERE reference_id = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("s", $id);
    $stmt->execute();
    $result = $stmt->get_result();
    $db_data = $result->fetch_assoc() ?: [];
    $stmt->close();

    // Merge with session data (session has priority)
    $fieldss = array_merge($db_data, $_SESSION['area_valuation'] ?? []);
}

// Handle POST request
if ($_SERVER["REQUEST_METHOD"] === "POST") {
    $action = $_POST['action'] ?? '';

    if ($action === 'save') {
        // Save form data to session
        $_SESSION['area_valuation'] = array_map('trim', $_POST);

        // Update insurable value logic
        if (isset($_SESSION['area_valuation']['propertyType'])) {
            $type = $_SESSION['area_valuation']['propertyType'];

            if ($type === "Land and Building") {
                $val = floatval($_SESSION['area_valuation']['finally_construction_valuation'] ?? 0);
                $_SESSION['area_valuation']['insurable_value'] = round($val, 2);
            } elseif ($type === "Floor Property") {
                $area = floatval($_SESSION['area_valuation']['final_area_square_feet'] ?? 0);
                $_SESSION['area_valuation']['insurable_value'] = round($area * 1200, 2);
            }
        }

        // Update form display data
        $fieldss = $_SESSION['area_valuation'];
        $message = "Details saved successfully!";
    }

    elseif ($action === 'submit') {
        $success = saveAreaValuationToDatabase($_SESSION['area_valuation']);

        if ($success) {
            unset($_SESSION['area_valuation']);
            header("Location: technical7.php");
            exit();
        } else {
            $message = "Error occurred while submitting. Please try again.";
        }
    }
}

// Function to simulate database save (you can replace with actual logic)
function saveAreaValuationToDatabase($data) {
    return true;
}

// Close DB connection
$conn->close();
 
 
?>





<!-- JavaScript for Alert -->
<script>
    <?php if (!empty($message)): ?>
    alert("<?= htmlspecialchars($message) ?>");
    <?php endif; ?>
</script>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Property Details Form</title>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">   
  

<link rel="shortcut icon" href="favicon.ico" type="image/x-icon">
<!-- <link rel="stylesheet" href="REPORT71.css"> -->
<style>
                  * {
  margin: 0;
  padding: 0;
  box-sizing: border-box;
  font-family: "Poppins", "Segoe UI", sans-serif;
}

body {
  background: linear-gradient(135deg, #e0f7fa, #fce4ec, #f3e5f5);
  background-size: 300% 300%;
  animation: gradientBG 12s ease infinite;
  min-height: 100vh;
  text-transform: uppercase;
  padding-top: 110px;
  position: relative;
  color: #2c3e50;
}

/* Animate background */
@keyframes gradientBG {
  0% { background-position: 0% 50%; }
  50% { background-position: 100% 50%; }
  100% { background-position: 0% 50%; }
}

    
        .form-container {
            width: 100%;
            max-width: 100%;
            margin: 0 auto;
            display: flex;
            flex-direction: column;
            gap: 10px;
              text-align: left;
            
        }
       

.tab-links {
  position: fixed;
     gap:9px;
  top: 0;
  left: 0; right: 0;
  z-index: 999;
  display: flex;
  justify-content: space-between;
  padding: 7px;
  overflow-x: auto;
  backdrop-filter: blur(12px);
  border-bottom: 2px solid rgba(0,0,0,0.05);
  box-shadow: 0 2px 10px rgba(0,0,0,0.08);
  text-align: center;
}

.tab-links .tab {
   border: 1px solid #ddd;
  padding:1px 27px;
  border-radius: 50px;
  font-size: 14px;
  font-weight: bold;
  color: #444;

  transition: all 0.3s ease;
  cursor: pointer;
}

.tab-links .tab.active {
  background: linear-gradient(135deg, #9d7cc1ff, #5d7aacff);
  color: #fff;
    box-shadow: 0 12px 30px rgba(106, 17, 203, 0.35),
              0 6px 15px rgba(37, 117, 252, 0.25);
  transition: all 0.5s cubic-bezier(0.25, 1, 0.5, 1);
  animation: gradientMove 4s ease infinite, float 6s ease-in-out infinite;
  transform: scale(1.05);
  box-shadow: 0 4px 12px rgba(0,0,0,0.2);

}

/* Tab Icon */
.tab img {
  width: 45px;
  height: 45px;
  margin-bottom:5px;
  transition: transform 0.3s ease;
}
.tab:hover img {
  transform: rotate(10deg) scale(1.1);
}




        /* Styling the scrollbar for the entire page */
::-webkit-scrollbar {
    width: 12px; /* Width of the vertical scrollbar */
    height: 10px; /* Height of horizontal scrollbar */
}
th{
    font-size:15px;background: linear-gradient(135deg, #e4dee7ff);
  color:black;
  font-weight:600;
    box-shadow: 0 12px 30px rgba(106, 17, 203, 0.35),
              0 6px 15px rgba(37, 117, 252, 0.25);
  transition: all 0.5s cubic-bezier(0.25, 1, 0.5, 1);
  animation: gradientMove 4s ease infinite, float 6s ease-in-out infinite;
  transform: scale(1.05);
  padding:5px;
  box-shadow: 0 4px 12px rgba(0,0,0,0.2);"
}
/* Styling the scrollbar track */
::-webkit-scroltab-linkslbar-track {
    background: linear-gradient(135deg, #f0f0f0, #e0e0e0); /* Light gradient track */
    border-radius: 10px; /* Rounded corners */
    box-shadow: inset 0 0 10px rgba(0, 0, 0, 0.1); /* Subtle shadow */
}

/* Styling the scrollbar thumb (the draggable part) */
::-webkit-scrollbar-thumb {
    background: linear-gradient(135deg, #2f7cab, #0056b3); /* Gradient thumb */
    border-radius: 10px; /* Rounded corners */
    border: 3px solid transparent; /* Add space around thumb */
    background-clip: content-box; /* Ensures the thumb’s background doesn’t overlap the border */
    transition: background 0.3s ease, transform 0.3s ease; /* Smooth transition for hover */
}

/* Hover effect for the scrollbar thumb */
::-webkit-scrollbar-thumb:hover {
    background: linear-gradient(135deg, #0056b3, #003d80); /* Darker gradient on hover */
    transform: scale(1.1); /* Slightly enlarge the thumb */
}

/* Styling the horizontal scrollbar */
::-webkit-scrollbar-horizontal {
    height: 8px;
}

/* Styling the horizontal scrollbar track */
::-webkit-scrollbar-track-horizontal {
    background: linear-gradient(135deg, #f0f0f0, #e0e0e0); /* Light gradient track */
    border-radius: 10px;
    box-shadow: inset 0 0 10px rgba(0, 0, 0, 0.1);
}

/* Styling the horizontal scrollbar thumb */
::-webkit-scrollbar-thumb-horizontal {
    background: linear-gradient(135deg, #2f7cab, #0056b3);
    border-radius: 10px;
    border: 3px solid transparent;
    background-clip: content-box;
    transition: background 0.3s ease, transform 0.3s ease;
}

/* Hover effect for horizontal scrollbar thumb */
::-webkit-scrollbar-thumb-horizontal:hover {
    background: linear-gradient(135deg, #0056b3, #003d80);
    transform: scale(1.1); /* Slightly enlarge the thumb */
}

      .header {
 
   background: #f0f8ff;
  padding: 16px;
  text-align: center;
  font-size: 20px;
  font-weight: 700;

  letter-spacing: 1px;
  border-bottom: 4px solid #fff;
  box-shadow: 0 4px 15px rgba(0,0,0,0.2);
  text-transform: uppercase;
}

        /* Main Content Styling */
        form {
            width: 100%;
        }

table {
  width: 100%;
  border-collapse: collapse;
  margin: 10px 0;
}

td {
  padding: 10px;
  vertical-align: middle;
  transition: background 0.3s;
}

td:nth-child(odd) {
  background: #f0f8ff;
  font-weight: 600;
  color: #2c3e50;
}

td:nth-child(even) {
  background: #ffffff;
}

input[type="text"] {
  width: 100%;
  padding: 8px 12px;
  border: 1px solid #ddd;
  border-radius: 8px;
  transition: border-color 0.3s, box-shadow 0.3s;
}

input[type="text"]:focus {
  border-color: #6a11cb;
  box-shadow: 0 0 6px rgba(106, 17, 203, 0.4);
  outline: none;
}
/* Enhanced Submit Button */
.submit-button {
  display: flex;
  justify-content: center;
  margin: 40px 0;
  perspective: 1000px;
}

/* Button styling */
.submit-button button,
.submit-button input[type="submit"] {
  background: linear-gradient(135deg, #9356d3ff 0%, #568ef0ff 100%);
  background-size: 200% 200%;
  border: none;
  padding: 8px 25px;
  border-radius: 999px;
  color: #fff;
  font-size: 20px;
  cursor: pointer;
  font-weight: 800;
  letter-spacing: 0.5px;
  box-shadow: 0 12px 30px rgba(106, 17, 203, 0.35),
              0 6px 15px rgba(37, 117, 252, 0.25);
  transition: all 0.5s cubic-bezier(0.25, 1, 0.5, 1);
  animation: gradientMove 4s ease infinite, float 6s ease-in-out infinite;
  position: relative;
  overflow: hidden;
  outline: none;
  -webkit-tap-highlight-color: transparent;
  transform-style: preserve-3d;
  text-transform: uppercase;
}

/* Shimmer highlight effect */
.submit-button button::before {
  content: "";
  position: absolute;
  top: -50%;
  left: -50%;
  width: 170%;
  height: 170%;
  background: linear-gradient(
    60deg, 
    rgba(255,255,255,0) 0%, 
    rgba(255,255,255,0.15) 50%, 
    rgba(255,255,255,0) 100%
  );
  transform: rotate(25deg) translateX(-100%);
  transition: transform 1.2s cubic-bezier(0.23, 1, 0.32, 1);
  pointer-events: none;
}

/* Hover effects */
.submit-button button:hover {
  transform: translateY(-8px) scale(1.08) rotateX(10deg);
  box-shadow: 0 25px 50px rgba(106, 17, 203, 0.45),
              0 15px 30px rgba(37, 117, 252, 0.35),
              0 0 40px rgba(255, 255, 255, 0.2);
  filter: brightness(1.15) saturate(1.2);
  letter-spacing: 1px;
}

.submit-button button:hover::before {
  transform: rotate(25deg) translateX(100%);
}

/* Active (press) effect */
.submit-button button:active {
  transform: translateY(-2px) scale(0.98);
  box-shadow: 0 8px 20px rgba(106, 17, 203, 0.3);
  transition: all 0.1s ease;
}

/* Pulsing glow effect */
.submit-button button::after {
  content: "";
  position: absolute;
  inset: -4px;
  border-radius: 999px;
  background: linear-gradient(135deg, #6a11cb, #2575fc, #9d7cc1, #5d7aac);
  background-size: 300% 300%;
  z-index: -1;
  filter: blur(12px);
  opacity: 0.7;
  animation: gradientMove 5s ease infinite, pulse 3s ease infinite;
  pointer-events: none;
}

/* Sparkle particles */
.submit-button .sparkle {
  position: absolute;
  width: 4px;
  height: 4px;
  background: white;
  border-radius: 50%;
  pointer-events: none;
  opacity: 0;
  animation: sparkle 1.5s linear infinite;
}

/* Keyframes for animations */
@keyframes gradientMove {
  0% { background-position: 0% 50%; }
  50% { background-position: 100% 50%; }
  100% { background-position: 0% 50%; }
}

@keyframes pulse {
  0% { opacity: 0.5; transform: scale(0.95); }
  50% { opacity: 0.8; transform: scale(1.05); }
  100% { opacity: 0.5; transform: scale(0.95); }
}

@keyframes float {
  0% { transform: translateY(0px); }
  50% { transform: translateY(-5px); }
  100% { transform: translateY(0px); }
}

@keyframes sparkle {
  0% {
    opacity: 0;
    transform: translate(0, 0) scale(0);
  }
  20% {
    opacity: 1;
    transform: translate(var(--sparkle-x), var(--sparkle-y)) scale(1);
  }
  80% {
    opacity: 1;
  }
  100% {
    opacity: 0;
    transform: translate(
      calc(var(--sparkle-x) * 1.5), 
      calc(var(--sparkle-y) * 1.5)
    ) scale(0);
  }
}

.side-buttons {
  position: fixed;
  top: 25%;
  right: 20px;
  display: flex;
  margin-top: 470px;
  flex-direction: column;
  gap: 12px;
  z-index: 1000;
}

.side-buttons button {
  background: linear-gradient(145deg, #6a11cb, #2575fc);
  border: none;
  border-radius: 50%;
  width: 55px;
  height: 55px;
  display: flex;
  align-items: center;
  justify-content: center;
  box-shadow: 0 5px 12px rgba(0,0,0,0.25);
  transition: all 0.3s ease;
}

.side-buttons button:hover {
  transform: rotate(15deg) scale(1.1);
  background: linear-gradient(145deg, #2575fc, #6a11cb);
}

.side-buttons button img {
  width: 24px;
  height: 24px;
  filter: brightness(0) invert(1);
}



        @media (max-width: 768px) {
            .side-buttons {
                top: 15%;
                right: 10px;
            }

            .tab-links {
                flex-wrap: wrap;
            }
        }

        @media (max-width: 480px) {
            .tab-links button {
                padding: 8px 10px;
            }

            .header {
                font-size: 16px;
            }

            td {
                font-size: 14px;
            }

            input[type="text"] {
                font-size: 14px;
            }

            .side-buttons {
                top: 10%;
                right: 5px;
            }
        }
        .image-preview-container {
    display: flex;
    flex-wrap: wrap;
    gap: 10px;
    margin-top: 20px;
    background-color: #f8f9fa;
    border: 2px dashed #dcdcdc;
    padding: 10px;
    border-radius: 8px;
    /* justify-content: center; */
    align-items: center;
    text-align: center;
}

.image-preview-container p {
    color: #888;
    font-size: 14px;
}

.image-preview-container.hidden {
    display: none;
}

/* File input trigger button styling */
.side-buttons button {
    background-color: #2f7cab;
    border: none;
    padding: 10px;
    cursor: pointer;
    border-radius: 50%;
    width: 50px;
    height: 50px;
    display: flex;
    align-items: center;
    justify-content: center;
    transition: background-color 0.3s;
}  
.rotating-text {
            color:black;
    perspective: 1000px; /* Adds a 3D perspective effect */
    font-size: 1.5rem;
    font-weight:bold;
    width: 100%;
    animation: rotate360 3s linear infinite;
    display: inline-block;
    margin-bottom:10px;
    transform-origin: center center; /* Rotates around its center */
    text-align:center;
    /* margin-left:20px; */
    font-style: italic;
    text-shadow: 
    1px 1px 2px rgba(235, 244, 243, 0.97),
    2px 2px 4px rgba(246, 242, 242, 0.4),
    3px 3px 6px rgba(249, 252, 252, 0.89),
    4px 4px 8px rgba(248, 242, 247, 0.93),
    5px 5px 10px rgba(232, 236, 237, 0.4);
  }
  
  /* Keyframes for rotating the text */
  @keyframes rotate360 {
    0% {
      transform: rotateY(0deg); /* Starts with no rotation */
    }
    50% {
      transform: rotateY(0deg); /* Half rotation */
    }
    100% {
      transform: rotateY(360deg); /* Full rotation */
    }
  }
  .logo {
    /* width: 50px; */
    height: 83px;
    padding: 12px;
    padding-bottom: 33px;
    
  }
#sidebar {
    background: #B0C4DE; /* Light Steel Blue */
    color: #2C3E50; 
    position: fixed;
    left: -250px;
    top: 0;
    width: 250px;
    height: 100%;
    /* background-color: #111; */
    color: white;
    transition: left 0.3s ease;
    padding: 20px;
}

#sidebar.active {
    left: 35px;
    /* background:grey; */
}
.sidebar {
    width: 250px;
    background: #B0C4DE; /* Light Steel Blue */
    /* background:rgba(245, 245, 245, 0.37); Light Steel Blue */
    color: black; /* Dark Grayish Blue */
    padding:20px;
    height: 100vh;
    position: fixed;
    left: 0;
    top: 0;
    z-index: 1000;
    transition: transform 0.3s ease-in-out;
  }
  .sidebar.hidden {
    transform: translateX(-100%);
  }
  .sidebar h1 {
font-size: 20px;
margin-top: 10px;
margin-bottom: 20px;
color: #2C3E50; 
}
  .sidebar a {
    padding: 15px 20px;
      margin: 10px 0;
      text-decoration: none;
      color: #2C3E50; /* Dark Grayish Blue */
      font-size:16px;
      font-style: italic;
      font-weight: 500;
      margin-bottom:70px;
      border-radius: 5px;
      transition: all 0.3s ease;
      display: flex;
      align-items: center;
  }

  .sidebar a:hover,
  .sidebar a.active {
    background: #4A90E2; /* Light Blue */
    transform: translateX(10px);
    color: white;
  }
  .sidebar a .icon {
    margin-right: 15px;
    font-size: 18px;
  }
/* Toggle Button */
#toggleSidebar {
    border-radius: 20%;
    position: fixed;
    top: 0px; /* Adjusted for better placement */
    left: 0px; /* Adjusted for better placement */
    z-index: 1000;
    background-color:rgb(130, 183, 226); 
    color: white;
    border: none;
    padding: 6px 12px; /* Added padding for a more clickable area */
    cursor: pointer;
    box-shadow: 0 4px 8px rgba(0, 0, 0, 0.7); /* Adds a soft shadow for depth */
    transition: all 0.3s ease; 
    /* Smooth transition for hover and active states */
}

/* Button hover effect */
#toggleSidebar:hover {
    background-color: #1c6abf; /* Slightly darker shade on hover */
    transform: scale(1); /* Slightly enlarges the button for a professional hover effect */
    box-shadow: 0 6px 12px rgba(0, 0, 0, 0.3); /* Stronger shadow on hover */
}

/* Active state for the button */
#toggleSidebar.active {
    background-color: #1a4f82; /* Darker shade for active state */
    transform: rotate(180deg); /* Smooth rotate effect when the sidebar is active */
}

/* Button icon (if you use an icon inside the button) */
#toggleSidebar i {
    font-size: 18px; /* Adjust the icon size */
    transition: transform 0.3s ease; /* Smooth transition when rotating */
}
.watch-icon {
    margin-right: 16px; /* Adds space between the search text and the watch icon */
    color: #555; /* Optional: sets the color of the watch icon */
}
#toggleSidebar {
    border-radius: 20%;
    position: fixed;
    top: 0px; /* Adjust for better placement */
    /* right: -35px; Position it just outside the sidebar */
    z-index: 1001;
    background-color: rgb(130, 183, 226);
    color: white;
    border: none;
    padding: 6px 12px;
    cursor: pointer;
    box-shadow: 0 4px 8px rgba(0, 0, 0, 0.7);
    transition: all 0.3s ease;
}

/* Button hover effect */
#toggleSidebar:hover {
    background-color: #1c6abf;
    box-shadow: 0 6px 12px rgba(0, 0, 0, 0.3);
}

/* Active state for the button */
#toggleSidebar.active {
    background-color: #1a4f82;
    transform: rotate(180deg); /* Smooth 180-degree rotation */
    box-shadow: 0 6px 12px rgba(0, 0, 0, 0.5);
}

/* Sidebar */
#sidebar.active + #toggleSidebar {
    right: 250px; /* Adjust so button moves into view */
}

/* Sidebar when active */
#sidebar.active {
    left: 0px;
}

/* Sidebar hidden state */
#sidebar {
    position: fixed;
    left: -250px;
    top: 0;
    width: 250px;
    height: 100%;
    background: #B0C4DE;
    color: white;
    transition: left 0.3s ease;
}
#pdf-container {
            width: 100%;
            height: 100%;
            overflow: auto;
        }
        canvas {
            display: block;
            margin: 0 auto;
        }
 .modal {
  display: none;
  position: fixed;
  z-index: 2000;
  inset: 0;
  background: rgba(0,0,0,0.7);
  animation: fadeIn 0.6s ease-out;
}

.modal-content {
  background: #fff;
  border-radius: 15px;
  margin: 60px auto;
  padding: 30px 40px;
  width: 70%;
  max-width: 900px;
  animation: scaleUp 0.5s ease-in-out forwards;
  box-shadow: 0 20px 40px rgba(0,0,0,0.3);
}

 .close {
  float: right;
  font-size: 34px;
  font-weight: bold;
  color: #e74c3c;
  cursor: pointer;
  transition: transform 0.3s ease;
}

.close:hover {
  transform: rotate(90deg);
  color: #c0392b;
}

/* Animations */
@keyframes scaleUp {
  from { transform: scale(0.8); opacity: 0; }
  to { transform: scale(1); opacity: 1; }
}
@keyframes fadeIn {
  from { opacity: 0; }
  to { opacity: 1; }
}


/* Stylish list items inside the modal */
.modal-content ul {
    list-style-type: decimal; /* Use numbers for list items */
    margin-top: 20px;
    padding-left: 25px; /* Add padding to list items */
    color: #555; /* Lighter text color for better contrast */
}

.modal-content ul li {
    /* margin-bottom: 10px; */
    line-height: 1.6; /* Increased line height for better readability */
    padding-left: 10px; /* Padding to align list items nicely */
    transition: transform 0.2s ease-in-out; /* Smooth transition effect on hover */
}

.modal-content ul li:hover {
    transform: translateX(5px); /* Subtle animation on hover for list items */
}

/* Optional: Add a smooth transition effect when content changes */
.modal-content {
    transition: transform 0.5s ease, opacity 0.5s ease;
}
/* Enhanced Dropdown Styles */
select {
  width: 100%;
  padding: 12px 16px;
  border: 2px solid transparent;
  border-radius: 12px;
  background: linear-gradient(135deg, #e0f7fa, #fce4ec, #f3e5f5);
  color: #2c3e50;
  font-size: 16px;
  font-weight: 500;
  cursor: pointer;
  box-shadow: 0 4px 15px rgba(0,0,0,0.08);
  transition: all 0.4s cubic-bezier(0.25, 1, 0.5, 1);
  appearance: none;
  background-size: 200% 200%;
  animation: gradientBG 12s ease infinite;
  position: relative;
  border:3px solid red;
  outline: none;
}

/* Custom dropdown arrow */
.select-wrapper {
  position: relative;
  width: 100%;
}

.select-wrapper::after {
  content: "";
  position: absolute;
  top: 50%;
  right: 16px;
  transform: translateY(-50%) rotate(0deg);
  width: 12px;
  height: 12px;
  background-image: url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 24 24' fill='%236a11cb'%3E%3Cpath d='M7 10l5 5 5-5z'/%3E%3C/svg%3E");
  background-repeat: no-repeat;
  background-position: center;
  pointer-events: none;
  transition: transform 0.4s cubic-bezier(0.68, -0.55, 0.27, 1.55);
}

/* Hover effects */
select:hover {
  transform: translateY(-2px);
  box-shadow: 0 8px 25px rgba(106, 17, 203, 0.2);
  border-color: #6a11cb;
}

/* Focus effects */
select:focus {
  border-color: #6a11cb;
  box-shadow: 0 0 0 4px rgba(106, 17, 203, 0.15), 
              0 8px 25px rgba(106, 17, 203, 0.25);
  background: linear-gradient(135deg, #e0f7fa, #fce4ec, #f3e5f5);
  animation: gradientBG 8s ease infinite, pulseFocus 2s ease infinite;
}

/* Expanded state for dropdown */
select:focus + .select-wrapper::after {
  transform: translateY(-50%) rotate(180deg);
}

/* DROPDOWN LIST STYLING (when open) */
select:focus {
  border-radius: 12px 12px 0 0;
}

/* Firefox dropdown list styling */
select option {
  padding: 12px 16px;
  background: rgba(255, 255, 255, 0.98);
  color: #2c3e50;
  border-bottom: 1px solid #f0f0f0;
  transition: all 0.3s ease;
  font-size: 15px;
  cursor: pointer;
}

/* Hover effect for options */
select option:hover,
select option:checked {
  background: linear-gradient(135deg, #9d7cc1, #5d7aac) !important;
  color: white !important;
  box-shadow: 0 4px 12px rgba(0,0,0,0.1);
  transform: translateX(4px);
}

/* Selected option style */
select option:checked {
  background: linear-gradient(135deg, #6a11cb, #2575fc) !important;
  color: white;
  font-weight: 600;
}

/* For Webkit browsers (Chrome, Safari) */
@media screen and (-webkit-min-device-pixel-ratio:0) {
  select {
    padding-right: 40px; /* Extra space for custom arrow */
  }
  
  /* Style the dropdown list itself */
  select:focus {
    border-radius: 12px;
  }
  
  /* Style the dropdown options */
  select option {
    padding: 12px 16px;
    background: rgba(255, 255, 255, 0.98);
    color: #2c3e50;
    border-bottom: 1px solid #f0f0f0;
    transition: all 0.3s ease;
    font-size: 15px;
    cursor: pointer;
  }
  
  /* Hover effect for options in Webkit */
  select option:hover {
    background: linear-gradient(135deg, #9d7cc1, #5d7aac) !important;
    color: white !important;
    padding-left: 20px;
  }
  
  /* Selected option style in Webkit */
  select option:checked {
    background: linear-gradient(135deg, #6a11cb, #2575fc) !important;
    color: white;
    font-weight: 600;
  }
}

/* Animation for dropdown opening */
@keyframes dropdownOpen {
  0% {
    opacity: 0;
    transform: translateY(-10px);
  }
  100% {
    opacity: 1;
    transform: translateY(0);
  }
}

/* Apply animation to dropdown options in Firefox */
@-moz-document url-prefix() {
  select {
    padding-right: 40px; /* Extra space for custom arrow in Firefox */
  }
  
  select option {
    animation: dropdownOpen 0.4s ease forwards;
  }
}

/* Pulse animation for focus state */
@keyframes pulseFocus {
  0% {
    box-shadow: 0 0 0 4px rgba(106, 17, 203, 0.15), 
                0 8px 25px rgba(106, 17, 203, 0.25);
  }
  50% {
    box-shadow: 0 0 0 8px rgba(106, 17, 203, 0.1), 
                0 8px 25px rgba(106, 17, 203, 0.3);
  }
  100% {
    box-shadow: 0 0 0 4px rgba(106, 17, 203, 0.15), 
                0 8px 25px rgba(106, 17, 203, 0.25);
  }
}

/* Enhanced label styling */
td label {
  display: block;
  font-weight: 600;
  margin-bottom: 8px;
  color: #2c3e50;
  transition: color 0.3s ease;
}

/* Hover effect on label */
td:hover label {
  color: #6a11cb;
}

/* Responsive adjustments */
@media (max-width: 768px) {
  select {
    padding: 10px 14px;
    font-size: 15px;
  }
  
  .select-wrapper::after {
    right: 14px;
  }
}

@media (max-width: 480px) {
  select {
    padding: 8px 12px;
    font-size: 14px;
    border-radius: 10px;
  }
  
  .select-wrapper::after {
    right: 12px;
    width: 10px;
    height: 10px;
  }
}

/* Custom dropdown list for modern browsers */
@supports (-webkit-appearance: none) or (appearance: none) or ((-moz-appearance: none) and (pointer-events: all)) {
  .select-wrapper {
    position: relative;
    display: inline-block;
    width: 100%;
  }
  
  .select-wrapper select {
    padding-right: 40px;
    z-index: 1;
  }
  
  .select-wrapper::after {
    z-index: 2;
  }
  
  /* Focus state for modern browsers */
  .select-wrapper select:focus {
    z-index: 3;
  }
}
/* Date Input Container */
.date-input-container {
    position: relative;
    margin: 25px 0;
}

/* Label Styling */
.date-input-container label {
    display: block;
    text-align: left;
    margin-bottom: 8px;
    font-weight: 600;
    color: #2c3e50;
    transition: all 0.3s ease;
}

/* Date Input Styling */
input[type="date"] {
    width: 100%;
    padding: 10px 10px;
    border: 2px solid transparent;
    border-radius: 12px;
    background: linear-gradient(135deg, #e0f7fa, #fce4ec, #f3e5f5);
    color: #2c3e50;
    font-size: 16px;
    font-weight: 500;
    box-shadow: 0 4px 15px rgba(0, 0, 0, 0.08);
    transition: all 0.4s cubic-bezier(0.25, 1, 0.5, 1);
    outline: none;
    cursor: pointer;
}

/* Hover effect */
input[type="date"]:hover {
    transform: translateY(-2px);
    box-shadow: 0 8px 25px rgba(106, 17, 203, 0.2);
    border-color: #6a11cb;
}


/* Pulse animation for focus state */
@keyframes pulseFocus {
    0% {
        box-shadow: 0 0 0 4px rgba(106, 17, 203, 0.15), 
                    0 8px 25px rgba(106, 17, 203, 0.25);
    }
    50% {
        box-shadow: 0 0 0 8px rgba(106, 17, 203, 0.1), 
                    0 8px 25px rgba(106, 17, 203, 0.3);
    }
    100% {
        box-shadow: 0 0 0 4px rgba(106, 17, 203, 0.15), 
                    0 8px 25px rgba(106, 17, 203, 0.25);
    }
}
 .valuation-table {
        width: 100%;
        border-collapse: collapse;
    }
    .valuation-table th, .valuation-table td {
        border: 1px solid #fffefeff;
        padding: 6px;
        width: 25%; /* Force each column to take up equal space */
        box-sizing: border-box;
    }
    .valuation-table input {
        width: 98%;
        box-sizing: border-box;
    }
</style>
</head>
<body>
<button id="toggleSidebar">&#9776;</button>
<div id="sidebar" class="sidebar">
    <div style="display: flex">
      <img class="logo" src="logo.png" alt="" />
      <h1>Magpie Engineering</h1>
    </div>
           <div class="rotating-text">Report Drafter</div>
    <a href="home1.php"><i class="fas fa-home icon"></i>Home</a>        

    
  <a href="Pending_Report.php" ><i class="fas fa-clock watch-icon"></i>Pending For Drafting</a>
 <a href="technical.php" class="active"><i class="fas fa-clipboard-list icon"></i> Preview Report</a>      
    <a href="logout.php"><i class="fas fa-sign-out-alt icon"></i>Logout</a>

  </div>
</div>
<div class="form-container">
    <div style="width: 100%;">
    <div class="tab-links">
    <button class="tab" onclick="location.href='technical3.php'"><img src="info.png" alt="Icon" width="50  " height="50  ">
    INFO</button>
    <button class="tab " onclick="location.href='technical4.php'"><img src="general.png" alt="Icon" width="50  " height="50  ">GENERAL</button>
    <button class="tab" onclick="location.href='technical2.php'"> <img src="location.png" alt="Icon" width="50  " height="50  ">
    LOCATION</button>
    <button class="tab " onclick="location.href='technical5.php'"><img src="Zoning.png" alt="Icon" width="50  " height="50  ">
    ZONING</button>
    <button class="tab active" onclick="location.href='technical7.php'"><img src="value.png" alt="Icon" width="50  " height="50  ">
    VALUE</button>
    <button class="tab" onclick="location.href='technical9.php'"><img src="Floor.png" alt="Icon" width="50  " height="50  ">
    STRUCTURE</button>
    <button class="tab" onclick="location.href='technical10.php'"><img src="documents.png" alt="Icon" width="50  " height="50  ">
    DOCUMENTS</button>
    <button class="tab" onclick="location.href='technical115.php'"><img src="photo.png" alt="Icon" width="50  " height="50  ">
    PHOTOS</button>
                

    <button class="tab" onclick="location.href='technical12.php'"><img src="remark.png" alt="Icon" width="50  " height="50  ">
    REMARK</button>          
    <button class="tab" onclick="location.href='view_report.php'"><img src="preview.jpg" alt="Icon" width="50  " height="50  ">
    PREVIEW</button>  
    <div class="slider"></div>
</div> 
<div class="side-buttons">
  <button type="button" onclick="window.open('https://www.magpiecomp.com/QGIS/', '_blank')">
    <img src="https://cdn-icons-png.flaticon.com/512/535/535239.png" alt="Open QGIS" width="35px" height="35px">
  </button>

  <input type="file" id="imageInput" accept="image/*" style="display: none;">
  <input type="file" id="pdfInput" accept="application/pdf" style="display: none;">

  <span class="tooltip-text">RATE ?</span>
</div>    
   
<table  style="margin-top:10px;">
        <thead> 


        <form id="autosave-form" method="POST" action="technical7.php">
    <table style="margin-top:10px;">
        <thead>
  <tr class="fixed-property-type-row" style="align-items:center;">
    <th colspan="3" style="font-size:15px;">Choose Property Type For Valuation:</th>
    <!-- PROPERTY TYPE DROPDOWN -->
<td colspan="3">
  <select id="propertyType" name="propertyType" style="padding:10px 38%;" required>
    <option value="select">Select Property Type</option>
    <option value="Land and Building" <?= ($fieldss['propertyType'] ?? '') === 'Land and Building' ? 'selected' : ''; ?>>Land and Building</option>
    <option value="Floor Property" <?= ($fieldss['propertyType'] ?? '') === 'Floor Property' ? 'selected' : ''; ?>>Floor Property</option>
  </select>
</td>

  </tr>
</thead>





  <tr style="width:100%">
    <td>
      <div class="form-group">
        <label class="checkbox-container">
         <input type="checkbox" id="flag_special_submit" name="flag_special_submit"
  onchange="toggleSpecialText()"
  <?= isset($_POST['flag_special_submit']) || ($data['flag_special_submit'] ?? false) ? 'checked' : '' ?>>

          <span class="checkmark"></span>
          <span class="label-text">ONLY FOR AXIS BANK</span>
        </label>
      </div>
    </td>
  </tr>
 <div class="full-width-table">
  <tr id="specialTextRow" style="display: none;">
    <td>
      <div class="form-group">
<table border="1" cellpadding="8" cellspacing="0" style="width:100%; border-collapse: collapse;">
  <thead>
    <tr>
      <th colspan="3" style="text-align: center;">Plot Area</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <td> 

        <label for="axis_plot_area">Plot Area As Per Site</label><br>
        <input type="text" name="axis_plot_area" id="axis_plot_area" value="<?= $fieldsss['axis_plot_area'] ?? '' ?>" readonly>
      </td>
      <td>
        <label for="axis_plot_sanction">Plot Area As Per Sanction</label><br>
        <input type="text" name="axis_plot_sanction" id="axis_plot_sanction" value="<?= $fieldsss['axis_plot_sanction'] ?? '' ?>" readonly>
      </td>
      <td>
    <label for="axis_plot_document">Plot Area As Per Document</label><br>
     <input type="text" name="axis_plot_document" id="axis_plot_document" value="<?=$fieldsss['axis_plot_document'] ?? '' ?>" readonly>
    </td>
    </tr>
  </tbody>
 <thead>
    <tr>
      <th colspan="3" style="text-align: left;">Plot Area</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <td>
        <label for="axis_plot_area_document">Plot Area As Per Document</label><br>
        <input type="text" name="axis_plot_area_document" id="axis_plot_area_document" value="<?=$fieldsss['axis_plot_area_document'] ?? '' ?>" readonly>
      </td>
</tr>
  <thead>
    <tr><th colspan="3" style="text-align: center;">Actual Built-up Area</th></tr>
  </thead>
  <tbody>
    <tr>
     <td colspan="3">
  <label>Total Area</label><br>
  <input type="text" name="axis_final_plot_square_feet" id="axis_final_plot_square_feet" value="<?=$fieldsss['axis_final_plot_square_feet'] ?? '' ?>" readonly style="width: 100%;">
</td>
</tr>
<tr>
  <td>
    <label>Ground Floor</label><br>
    <input type="text" name="axis_ground_actual" id="axis_ground_actual" value="<?=$fieldsss['axis_ground_actual'] ?? '' ?>" readonly>
  </td>
  <td>
    <label>1st Floor</label><br>
    <input type="text" name="axis_first_actual" id="axis_first_actual" value="<?=$fieldsss['axis_first_actual'] ?? '' ?>" readonly>
  </td>
  <td>
    <label>2nd Floor</label><br>
    <input type="text" name="axis_second_actual" id="axis_second_actual" value="<?=$fieldsss['axis_second_actual'] ?? '' ?>" readonly>
  </td>
</tr>
<tr>
  <td>
    <label>3rd Floor</label><br>
    <input type="text" name="axis_3_actual" id="axis_3_actual" value="<?= $fieldsss['axis_3_actual'] ?? '' ?>" readonly>
  </td>
  <td>
    <label>4th Floor</label><br>
    <input type="text" name="axis_4_actual" id="axis_4_actual" value="<?= $fieldsss['axis_4_actual'] ?? '' ?>" readonly>
  </td>
  <td>
    <label>Other Floor</label><br>
    <input type="text" name="axis_other_actual" id="axis_other_actual" value="<?=$fieldsss['axis_other_actual'] ?? '' ?>" readonly>
  </td>
</tr>
<tr>
  <td>
    <label>Basement Floor</label><br>
    <input type="text" name="axis_basement_floor1" id="axis_basement_floor1" value="<?=$fieldsss['axis_basement_floor1'] ?? '' ?>" readonly>
  </td>
  <td>
    <label>Basement Floor</label><br>
    <input type="text" name="axis_basement_floor2" id="axis_basement_floor2" value="<?=$fieldsss['axis_basement_floor2'] ?? '' ?>" readonly>
  </td>
  <td>
    <label>Basement Floor</label><br>
    <input type="text" name="axis_basement_floor3" id="axis_basement_floor3" value="<?=$fieldsss['axis_basement_floor3'] ?? '' ?>" readonly>
  </td>
</tr>

  </tbody>

  <!-- Built-up Area As Per Document -->
<thead>
  <tr><th colspan="3" style="text-align: center;">Built-up Area As Per Document</th></tr>
</thead>
<tbody>
  <tr>
    <td colspan="3">
      <label>Total Area</label><br>
      <input type="text" name="axis_total_area" id="axis_total_area" value="<?=$fieldsss['axis_total_area'] ?? '' ?>" readonly style="width: 100%;">
    </td>
  </tr>
  <tr>
    <td><label>Ground Floor</label><br><input type="text" name="axis_ground" id="axis_ground" value="<?=$fieldsss['axis_ground'] ?? '' ?>" readonly></td>
    <td><label>1st Floor</label><br><input type="text" name="axis_1_floor" id="axis_1_floor" value="<?=$fieldsss['axis_1_floor'] ?? '' ?>" readonly></td>
    <td><label>2nd Floor</label><br><input type="text" name="axis_2_floor" id="axis_2_floor" value="<?=$fieldsss['axis_2_floor'] ?? '' ?>" readonly></td>
  </tr>
  <tr>
    <td><label>3rd Floor</label><br><input type="text" name="axis_3_floor" id="axis_3_floor" value="<?=$fieldsss['axis_3_floor'] ?? '' ?>" readonly></td>
    <td><label>4th Floor</label><br><input type="text" name="axis_4_floor" id="axis_4_floor" value="<?=$fieldsss['axis_4_floor'] ?? '' ?>" readonly></td>
    <td><label>Other Floor</label><br><input type="text" name="axis_other_floor" id="axis_other_floor" value="<?=$fieldsss['axis_other_floor'] ?? '' ?>" readonly></td>
  </tr>
</tbody>

<!-- Approved Built-up Area -->
<thead>
  <tr><th colspan="3" style="text-align: center;">Approved Built-up Area</th></tr>
</thead>
<tbody>
  <tr>
    <td colspan="3">
      <label>Total Area</label><br>
      <input type="text" name="axis_na_total_area" id="axis_na_total_area" value="<?= $fieldsss['axis_na_total_area'] ?? '' ?>" style="width: 100%;">
    </td>
  </tr>
  <tr>
    <td><label>Ground Floor</label><br><input type="text" name="axis_ground_approved_0" id="axis_ground_approved_0" value="<?=$fieldsss['axis_ground_approved_0'] ?? '' ?>" readonly></td>
    <td><label>1st Floor</label><br><input type="text" name="axis_ground_approved_1" id="axis_ground_approved_1" value="<?=$fieldsss['axis_ground_approved_1'] ?? '' ?>" readonly></td>
    <td><label>2nd Floor</label><br><input type="text" name="axis_ground_approved_2" id="axis_ground_approved_2" value="<?=$fieldsss['axis_ground_approved_2'] ?? '' ?>" readonly></td>
  </tr>
  <tr>
    <td><label>3rd Floor</label><br><input type="text" name="axis_ground_approved_3" id="axis_ground_approved_3" value="<?=$fieldsss['axis_ground_approved_3'] ?? '' ?>" readonly></td>
    <td><label>4th Floor</label><br><input type="text" name="axis_ground_approved_4" id="axis_ground_approved_4" value="<?=$fieldsss['axis_ground_approved_4'] ?? '' ?>" readonly></td>
    <td><label>Other Floor</label><br><input type="text" name="axis_ground_approved_other" id="axis_ground_approved_other" value="<?=$fieldsss['axis_ground_approved_other'] ?? '' ?>" readonly></td>
  </tr>
  <tr>
    <td><label>Basement Floor</label><br><input type="text" name="axis_basement_approved_1" id="axis_basement_approved_1" value="<?=$fieldsss['axis_basement_approved_1'] ?? '' ?>" readonly></td>
    <td><label>Basement Floor</label><br><input type="text" name="axis_basement_approved_2" id="axis_basement_approved_2" value="<?=$fieldsss['axis_basement_approved_2'] ?? '' ?>" readonly></td>
    <td><label>Basement Floor</label><br><input type="text" name="axis_basement_approved_3" id="axis_basement_approved_3" value="<?=$fieldsss['axis_basement_approved_3'] ?? '' ?>" readonly></td>
  </tr>
</tbody>

<!-- Permissible Area -->
<thead>
  <tr><th colspan="3" style="text-align: center;">Permissible Area</th></tr>
</thead>
<tbody>
  <tr>
    <td colspan="3">
      <label>Total Area</label><br>
      <input type="text" name="axis_permissible_area" id="axis_permissible_area" value="<?=$fieldsss['axis_permissible_area'] ?? '' ?>" readonly style="width: 100%;">
    </td>
  </tr>
  <tr>
    <td><label>Ground Floor</label><br><input type="text" name="axis_ground_permissible" id="axis_ground_permissible" value="<?=$fieldsss['axis_ground_permissible'] ?? '' ?>" readonly></td>
    <td><label>1st Floor</label><br><input type="text" name="axis_first_permissible" id="axis_first_permissible" value="<?=$fieldsss['axis_first_permissible'] ?? '' ?>" readonly></td>
    <td><label>2nd Floor</label><br><input type="text" name="axis_second_permissible" id="axis_second_permissible" value="<?=$fieldsss['axis_second_permissible'] ?? '' ?>" readonly></td>
  </tr>
  <tr>
    <td><label>3rd Floor</label><br><input type="text" name="axis_third_permissible" id="axis_third_permissible" value="<?=$fieldsss['axis_third_permissible'] ?? '' ?>" readonly></td>
    <td><label>4th Floor</label><br><input type="text" name="axis_forth_permissible" id="axis_forth_permissible" value="<?=$fieldsss['axis_forth_permissible'] ?? '' ?>" readonly></td>
    <td><label>Other Floor</label><br><input type="text" name="axis_other_permissible_floors" id="axis_other_permissible_floors" value="<?=$fieldsss['axis_other_permissible_floors'] ?? '' ?>" readonly></td>
  </tr>
  <tr>
    <td><label>Basement Floor</label><br><input type="text" name="axis_basement_approved_4" id="axis_basement_approved_4" value="<?=$fieldsss['axis_basement_approved_4'] ?? '' ?>" readonly></td>
    <td><label>Basement Floor</label><br><input type="text" name="axis_basement_approved_5" id="axis_basement_approved_5" value="<?=$fieldsss['axis_basement_approved_5'] ?? '' ?>" readonly></td>
    <td><label>Basement Floor</label><br><input type="text" name="axis_basement_approved_6" id="axis_basement_approved_6" value="<?=$fieldsss['axis_basement_approved_6'] ?? '' ?>" readonly></td>
  </tr>
</tbody>

<!-- Built-up Area Considered for Valuation -->
<thead>
  <tr><th colspan="3" style="text-align: center;">Built-up Area Considered for Valuation</th></tr>
</thead>
<tbody>
  <tr>
    <td colspan="3">
      <label>Total Area</label><br>
      <input type="text" name="axis_total_considered_area" id="axis_total_considered_area" value="<?=$fieldsss['axis_total_considered_area'] ?? '' ?>" readonly style="width: 100%;">
    </td>
  </tr>
  <tr>
    <td><label>Ground Floor</label><br><input type="text" name="axis_ground_considered" id="axis_ground_considered" value="<?=$fieldsss['axis_ground_considered'] ?? '' ?>" readonly></td>
    <td><label>1st Floor</label><br><input type="text" name="axis_first_considered" id="axis_first_considered" value="<?=$fieldsss['axis_first_considered'] ?? '' ?>" readonly></td>
    <td><label>2nd Floor</label><br><input type="text" name="axis_second_considered" id="axis_second_considered" value="<?=$fieldsss['axis_second_considered'] ?? '' ?>" readonly></td>
  </tr>
  <tr>
    <td><label>3rd Floor</label><br><input type="text" name="axis_third_considered" id="axis_third_considered" value="<?=$fieldsss['axis_third_considered'] ?? '' ?>" readonly></td>
    <td><label>4th Floor</label><br><input type="text" name="axis_forth_considered" id="axis_forth_considered" value="<?=$fieldsss['axis_forth_considered'] ?? '' ?>" readonly></td>
    <td><label>Other Floor</label><br><input type="text" name="axis_other_considered_floors" id="axis_other_considered_floors" value="<?=$fieldsss['axis_other_considered_floors'] ?? '' ?>" readonly></td>
  </tr>
  <tr>
    <td><label>Basement Floor</label><br><input type="text" name="axis_basement_approved_7" id="axis_basement_approved_7" value="<?=$fieldsss['axis_basement_approved_7'] ?? '' ?>" readonly></td>
    <td><label>Basement Floor</label><br><input type="text" name="axis_basement_approved_8" id="axis_basement_approved_8" value="<?=$fieldsss['axis_basement_approved_8'] ?? '' ?>" readonly></td>
    <td><label>Basement Floor</label><br><input type="text" name="axis_basement_approved_9" id="axis_basement_approved_9" value="<?=$fieldsss['axis_basement_approved_9'] ?? '' ?>" readonly></td>
  </tr>
</tbody>

</table>

      </div>
    </td>
  </tr>

<script>
  function toggleSpecialText() {
    const checkbox = document.getElementById('flag_special_submit');
    const specialTextRow = document.getElementById('specialTextRow');
    specialTextRow.style.display = checkbox.checked ? 'table-row' : 'none';
  }

  // Call on page load
  window.onload = function () {
    toggleSpecialText();
  };
</script>

</div>








<tr style="align-items:center;">
                
            </tr>
                
            <form id="autosave-form" method="post" action="technical7.php">
                <tr class="header">
                    <th colspan="6">AREA & VALUATION DETAILS</th>
                </tr>
                <tr class="header">
                    <th colspan="6" >APPROVED AREA & VALUATION</th>
                </tr>
                <tr>
                    <th style="background-color: lightskyblue; color: black; " colspan="2">AREA TYPE</th>
                    <th style="background-color: lightskyblue; color: black; ">SQUARE FEET</th>
                    <th style="background-color: lightskyblue; color: black; ">RATE/SQ.FT</th>
                    <th style="background-color: lightskyblue; color: black; " colspan="2">VALUATION (Rs.)</th>
                </tr>
            </thead>
            <tbody>
            <?php
        // Display the reference_id as a hidden field (assuming it will not be modified by the user)
            $reference_id = $_SESSION['reference_id'] ?? '';
            echo '<input type="hidden" name="reference_id" value="' . htmlspecialchars($reference_id) . '">';
?>


<script>
    document.addEventListener("DOMContentLoaded", () => {
        const dropdown = document.getElementById("propertyType");

        const allFields = [
            "plot_square_feet", "plot_rate", "plot_valuation_computed",
            "carpet_square_feet", "carpet_rate", "carpet_valuation_computed",
            "construction_square_feet", "construction_rate", "construction_valuation_computed",
            "saleable_square_feet", "saleable_rate", "saleable_valuation_computed",
            "total_area_valuation",

            "actual_plot_square_feet", "actual_plot_rate", "actual_plot_valuation_computed",
            "actual_carpet_square_feet", "actual_carpet_rate", "actual_carpet_valuation_computed",
            "actual_construction_square_feet", "actual_construction_rate", "actual_construction_valuation_computed",
            "actual_saleable_square_feet", "actual_saleable_rate", "actual_saleable_valuation_computed",
            "total_actual_area_valuation",

            "car_parking", "car_parking_amount",

            "addition_amenities_description_2", "addition_amenities_amount_2",
            "addition_amenities_description_3", "addition_amenities_amount_3",
            "addition_amenities_description_4", "addition_amenities_amount_4",
            "amenities_total",

            "final_plot_square_feet", "final_plot_rate", "finally_plot_valuation", "finally_plot_valuation_hidden",
            "final_construction_square_feet", "final_construction_rate", "finally_construction_valuation", "finally_construction_valuation_hidden",

            "dimension_as_per_site_north", "dimension_as_per_site_south",
            "dimension_as_per_site_east", "dimension_as_per_site_west",
            "dimension_as_per_document_north", "dimension_as_per_document_south",
            "dimension_as_per_document_east", "dimension_as_per_document_west",

            "total_finally_area_valuation", "distress_value_percent",
            "total_distress_value", "total_valuation_words", "distress_value_words",
            "enquiry_remarks", "gross_monthly_rental", "guideline_rate",
            "guideline_values", "replacement_cost", "final_area_square_feet",
            "final_area_rate","insurable_value","loading",

            "construction_name_1", "construction_area_sqft_1", "construction_rate_1",
            "construction_name_2", "construction_area_sqft_2", "construction_rate_2",
            "construction_name_3", "construction_area_sqft_3", "construction_rate_3",

            "axis_plot_area", "axis_plot_sanction", "axis_plot_document", "axis_plot_area_document",
"axis_final_plot_square_feet", "axis_ground_actual", "axis_first_actual", "axis_second_actual", "axis_3_actual", "axis_4_actual", "axis_other_actual",
"axis_basement_floor1", "axis_basement_floor2", "axis_basement_floor3",
"axis_total_area", "axis_ground", "axis_1_floor", "axis_2_floor", "axis_3_floor", "axis_4_floor", "axis_other_floor",
"axis_ground_approved_0", "axis_ground_approved_1", "axis_ground_approved_2", "axis_ground_approved_3", "axis_ground_approved_4", "axis_ground_approved_other",
"axis_basement_approved_1", "axis_basement_approved_2", "axis_basement_approved_3", "axis_na_total_area",
"axis_permissible_area", "axis_ground_permissible", "axis_first_permissible", "axis_second_permissible", "axis_third_permissible", "axis_forth_permissible", "axis_other_permissible_floors",
"axis_basement_approved_4", "axis_basement_approved_5", "axis_basement_approved_6",
"axis_total_considered_area", "axis_ground_considered", "axis_first_considered", "axis_second_considered", "axis_third_considered", "axis_forth_considered", "axis_other_considered_floors",
"axis_basement_approved_7", "axis_basement_approved_8", "axis_basement_approved_9","proposed_plot_rate",
"proposed_plot_valuation",

"proposed_construction_name1",
"proposed_construction_area_sqft1",
"proposed_construction_rate1",
"proposed_construction_valuation1",

"proposed_construction_name2",
"proposed_construction_area_sqft2",
"proposed_construction_rate2",
"proposed_construction_valuation2",

"proposed_construction_name3",
"proposed_construction_area_sqft3",
"proposed_construction_rate3",
"proposed_construction_valuation3",

"proposed_builtup_area_sqft",
"proposed_builtup_rate",
"proposed_builtup_valuation",

"proposed_saleable_area_sqft",
"proposed_saleable_rate",
"proposed_saleable_valuation",

"proposed_final_area_valuation","gov_plot_area_sqft",
"gov_plot_area_rate",
"gov_plot_area_valuation",

"gov_construction_name1",
"gov_construction_area1",
"gov_construction_rate1",
"gov_construction_valuation1",

"gov_construction_name2",
"gov_construction_area2",
"gov_construction_rate2",
"gov_construction_valuation2",

"gov_construction_name3",
"gov_construction_area3",
"gov_construction_rate3",
"gov_construction_valuation3",

"gov_builtup_area_sqft",
"gov_builtup_area_rate",
"gov_builtup_area_valuation",

"gov_saleable_area_sqft",
"gov_saleable_area_rate",
"gov_saleable_area_valuation",

"gov_final_area_valuation"
,"final_carpet_area_square_feet"

        ];

        function toggleFields() {
            const propertyType = dropdown.value;

            // Disable all fields
            allFields.forEach(id => {
                const el = document.getElementById(id);
                if (el) el.setAttribute("readonly", true);
            });

            let enableFields = [];

            if (propertyType === "Land and Building") {
                enableFields = [
                    "plot_square_feet", "plot_rate","carpet_square_feet", "construction_square_feet", "construction_rate",
                    "actual_plot_square_feet", "actual_plot_rate", "actual_carpet_square_feet",
                    "actual_construction_square_feet", "actual_construction_rate",
                    "car_parking", "car_parking_amount",
                    "addition_amenities_description_2", "addition_amenities_amount_2",
                    "addition_amenities_description_3", "addition_amenities_amount_3",
                    "addition_amenities_description_4", "addition_amenities_amount_4",
                    "final_plot_square_feet", "final_plot_rate",
                    
                    "dimension_as_per_site_north", "dimension_as_per_site_south",
                    "dimension_as_per_site_east", "dimension_as_per_site_west",
                    "dimension_as_per_document_north", "dimension_as_per_document_south",
                    "dimension_as_per_document_east", "dimension_as_per_document_west",
                    "enquiry_remarks", "gross_monthly_rental", "guideline_rate",
                    "replacement_cost","distress_value_percent",
                    "construction_name_1", "construction_area_sqft_1", "construction_rate_1",
                    "construction_name_2", "construction_area_sqft_2", "construction_rate_2",
                    "construction_name_3", "construction_area_sqft_3", "construction_rate_3",

                    "axis_plot_area", "axis_plot_sanction", "axis_plot_document", "axis_plot_area_document",
"axis_final_plot_square_feet", "axis_ground_actual", "axis_first_actual", "axis_second_actual", "axis_3_actual", "axis_4_actual", "axis_other_actual",
"axis_basement_floor1", "axis_basement_floor2", "axis_basement_floor3",
"axis_total_area", "axis_ground", "axis_1_floor", "axis_2_floor", "axis_3_floor", "axis_4_floor", "axis_other_floor",
"axis_ground_approved_0", "axis_ground_approved_1", "axis_ground_approved_2", "axis_ground_approved_3", "axis_ground_approved_4", "axis_ground_approved_other",
"axis_basement_approved_1", "axis_basement_approved_2", "axis_basement_approved_3", "axis_na_total_area",
"axis_permissible_area", "axis_ground_permissible", "axis_first_permissible", "axis_second_permissible", "axis_third_permissible", "axis_forth_permissible", "axis_other_permissible_floors",
"axis_basement_approved_4", "axis_basement_approved_5", "axis_basement_approved_6",
"axis_total_considered_area", "axis_ground_considered", "axis_first_considered", "axis_second_considered", "axis_third_considered", "axis_forth_considered", "axis_other_considered_floors",
"axis_basement_approved_7", "axis_basement_approved_8", "axis_basement_approved_9","proposed_plot_rate",
"proposed_plot_valuation",

"proposed_construction_name1",
"proposed_construction_area_sqft1",
"proposed_construction_rate1",
"proposed_construction_valuation1",

"proposed_construction_name2",
"proposed_construction_area_sqft2",
"proposed_construction_rate2",
"proposed_construction_valuation2",

"proposed_construction_name3",
"proposed_construction_area_sqft3",
"proposed_construction_rate3",
"proposed_construction_valuation3",

"proposed_builtup_area_sqft",
"proposed_builtup_rate",
"proposed_builtup_valuation",

"proposed_saleable_area_sqft",
"proposed_saleable_rate",
"proposed_saleable_valuation",

"proposed_final_area_valuation","gov_plot_area_sqft",
"gov_plot_area_rate",
"gov_plot_area_valuation",

"gov_construction_name1",
"gov_construction_area1",
"gov_construction_rate1",
"gov_construction_valuation1",

"gov_construction_name2",
"gov_construction_area2",
"gov_construction_rate2",
"gov_construction_valuation2",

"gov_construction_name3",
"gov_construction_area3",
"gov_construction_rate3",
"gov_construction_valuation3",

"gov_builtup_area_sqft",
"gov_builtup_area_rate",
"gov_builtup_area_valuation",

"gov_saleable_area_sqft",
"gov_saleable_area_rate",
"gov_saleable_area_valuation",

"gov_final_area_valuation","final_carpet_area_square_feet"


                ];
            } else if (propertyType === "Floor Property") {
                enableFields = [
                    "carpet_square_feet", "carpet_rate", "construction_square_feet", "construction_rate",
                    "saleable_square_feet", "saleable_rate","distress_value_percent",
                    "actual_saleable_square_feet", "actual_saleable_rate",

                     "dimension_as_per_site_north", "dimension_as_per_site_south",
                    "dimension_as_per_site_east", "dimension_as_per_site_west",
                    "dimension_as_per_document_north", "dimension_as_per_document_south",
                    "dimension_as_per_document_east", "dimension_as_per_document_west",

                    "car_parking", "car_parking_amount", "replacement_cost",
                    "addition_amenities_description_2", "addition_amenities_amount_2",
                    "addition_amenities_description_3", "addition_amenities_amount_3",
                    "addition_amenities_description_4", "addition_amenities_amount_4",
                    "final_area_square_feet", "final_area_rate",
                    "enquiry_remarks", "gross_monthly_rental", "guideline_rate",
                    "construction_name_1", "construction_area_sqft_1", "construction_rate_1",
                    "construction_name_2", "construction_area_sqft_2", "construction_rate_2",
                    "construction_name_3", "construction_area_sqft_3", "construction_rate_3",

                    "axis_plot_area", "axis_plot_sanction", "axis_plot_document", "axis_plot_area_document",
"axis_final_plot_square_feet", "axis_ground_actual", "axis_first_actual", "axis_second_actual", "axis_3_actual", "axis_4_actual", "axis_other_actual",
"axis_basement_floor1", "axis_basement_floor2", "axis_basement_floor3",
"axis_total_area", "axis_ground", "axis_1_floor", "axis_2_floor", "axis_3_floor", "axis_4_floor", "axis_other_floor",
"axis_ground_approved_0", "axis_ground_approved_1", "axis_ground_approved_2", "axis_ground_approved_3", "axis_ground_approved_4", "axis_ground_approved_other",
"axis_basement_approved_1", "axis_basement_approved_2", "axis_basement_approved_3", "axis_na_total_area",
"axis_permissible_area", "axis_ground_permissible", "axis_first_permissible", "axis_second_permissible", "axis_third_permissible", "axis_forth_permissible", "axis_other_permissible_floors",
"axis_basement_approved_4", "axis_basement_approved_5", "axis_basement_approved_6",
"axis_total_considered_area", "axis_ground_considered", "axis_first_considered", "axis_second_considered", "axis_third_considered", "axis_forth_considered", "axis_other_considered_floors",
"axis_basement_approved_7", "axis_basement_approved_8", "axis_basement_approved_9","proposed_plot_rate",
"proposed_plot_valuation",

"proposed_construction_name1",
"proposed_construction_area_sqft1",
"proposed_construction_rate1",
"proposed_construction_valuation1",

"proposed_construction_name2",
"proposed_construction_area_sqft2",
"proposed_construction_rate2",
"proposed_construction_valuation2",

"proposed_construction_name3",
"proposed_construction_area_sqft3",
"proposed_construction_rate3",
"proposed_construction_valuation3",

"proposed_builtup_area_sqft",
"proposed_builtup_rate",
"proposed_builtup_valuation",

"proposed_saleable_area_sqft",
"proposed_saleable_rate",
"proposed_saleable_valuation",

"proposed_final_area_valuation","gov_plot_area_sqft",
"gov_plot_area_rate",
"gov_plot_area_valuation",

"gov_construction_name1",
"gov_construction_area1",
"gov_construction_rate1",
"gov_construction_valuation1",

"gov_construction_name2",
"gov_construction_area2",
"gov_construction_rate2",
"gov_construction_valuation2",

"gov_construction_name3",
"gov_construction_area3",
"gov_construction_rate3",
"gov_construction_valuation3",

"gov_builtup_area_sqft",
"gov_builtup_area_rate",
"gov_builtup_area_valuation",

"gov_saleable_area_sqft",
"gov_saleable_area_rate",
"gov_saleable_area_valuation",

"gov_final_area_valuation"
,"final_carpet_area_square_feet"

                ];
            }

            // Enable the selected fields
            enableFields.forEach(id => {
                const el = document.getElementById(id);
                if (el) el.removeAttribute("readonly");
            });
        }

        // Initial trigger on page load
        toggleFields();

        // Trigger on dropdown change — dynamic update!
        dropdown.addEventListener("change", toggleFields);
    });
</script>


     <tr>
        <td colspan="2">Plot Area</td>
        <td><input type="text" id="plot_square_feet" name="plot_square_feet" value="<?= $fieldss['plot_square_feet'] ?? '' ?>"></td>
        <td><input type="text" id="plot_rate" name="plot_rate" value="<?= $fieldss['plot_rate'] ?? '0' ?>"></td>
        <td>
            <input type="text" id="plot_valuation_computed" readonly>
            <input type="hidden" name="plot_valuation_computed" id="plot_valuation_hidden">
        </td>
    </tr>
    <tr>
        <td colspan="2">Carpet Area</td>
        <td><input type="text" id="carpet_square_feet" name="carpet_square_feet" value="<?= $fieldss['carpet_square_feet'] ?? '' ?>"></td>
        <td><input type="text" id="carpet_rate" name="carpet_rate" value="<?= $fieldss['carpet_rate'] ?? '0' ?>"></td>
        <td>
            <input type="text" id="carpet_valuation_computed" readonly>
            <input type="hidden" name="carpet_valuation_computed" id="carpet_valuation_hidden">
        </td>
    </tr>
    
    <tr>
        <td colspan="2">Construction Built-Up Area</td>
        <td><input type="text" id="construction_square_feet" name="construction_square_feet" value="<?= $fieldss['construction_square_feet'] ?? '' ?>"></td>
        <td><input type="text" id="construction_rate" name="construction_rate" value="<?= $fieldss['construction_rate'] ?? '0' ?>"></td>
        <td>
            <input type="text" id="construction_valuation_computed" readonly>
            <input type="hidden" name="construction_valuation_computed" id="construction_valuation_hidden">
        </td>
    </tr>
    <tr>
        <td colspan="2">Saleable Area (Super Built-Up Area)</td>
        <td><input type="text" id="saleable_square_feet" name="saleable_square_feet" value="<?= $fieldss['saleable_square_feet'] ?? '' ?>"></td>
        <td><input type="text" id="saleable_rate" name="saleable_rate" value="<?= $fieldss['saleable_rate'] ?? '0' ?>"></td>
        <td>
            <input type="text" id="saleable_valuation_computed" readonly>
            <input type="hidden" name="saleable_valuation_computed" id="saleable_valuation_hidden">
        </td>
    </tr>
    <tr>
        <td colspan="4">APPROVED AREA VALUATION (A) (i + ii + iii + iv)</td>
        <td>
            <input type="text" id="total_area_valuation" readonly>
            <input type="hidden" name="total_area_valuation" id="total_area_valuation_hidden">
        </td>
    </tr>


            </tbody>
        </table>
     
        <table>
    <thead>
        <tr class="header">
            <th colspan="6">ACTUAL AREA & VALUATION</th>
        </tr>
        <tr>
            <th style="background-color: lightskyblue; color: black;" colspan="2">AREA TYPE</th>
            <th style="background-color: lightskyblue; color: black;">SQUARE FEET</th>
            <th style="background-color: lightskyblue; color: black;">RATE/SQ.FT</th>
            <th style="background-color: lightskyblue; color: black;" colspan="2">VALUATION (Rs.)</th>
        </tr>
    </thead>
    <tbody>

            <tr>
                <td colspan="2">Plot Area</td>
                <td><input type="text" id="actual_plot_square_feet" name="actual_plot_square_feet" value="<?= $fieldss['actual_plot_square_feet'] ?? '' ?>"></td>
                <td><input type="text" id="actual_plot_rate" name="actual_plot_rate" value="<?= $fieldss['actual_plot_rate'] ?? '' ?>"></td>
                <td>
                    <input type="text" id="actual_plot_valuation_computed" readonly>
                    <input type="hidden" name="actual_plot_valuation_computed" id="actual_plot_valuation_hidden" >
                </td>
                
            </tr>
            <tr>
                <td colspan="2">Carpet Area</td>
                <td><input type="text" id="actual_carpet_square_feet" name="actual_carpet_square_feet" value="<?= $fieldss['actual_carpet_square_feet'] ?? '' ?>"></td>
                <td><input type="text" id="actual_carpet_rate" name="actual_carpet_rate" value="<?= $fieldss['actual_carpet_rate'] ?? '' ?>"></td>
                <td>
                    <input type="text" id="actual_carpet_valuation_computed" readonly>
                    <input type="hidden" name="actual_carpet_valuation_computed" id="actual_carpet_valuation_hidden">
                </td>
            </tr>
            <tr>
                <td colspan="2">Construction Built-Up Area</td>
                <td><input type="text" id="actual_construction_square_feet" name="actual_construction_square_feet" value="<?= $fieldss['actual_construction_square_feet'] ?? '' ?>"></td>
                <td><input type="text" id="actual_construction_rate" name="actual_construction_rate" value="<?= $fieldss['actual_construction_rate'] ?? '' ?>"></td>
                <td>
                    <input type="text" id="actual_construction_valuation_computed" readonly>
                    <input type="hidden" name="actual_construction_valuation_computed" id="actual_construction_valuation_hidden">
                </td>
            </tr>
            <tr>
                <td colspan="2">Saleable Area (Super Built-Up Area)</td>
                <td><input type="text" id="actual_saleable_square_feet" name="actual_saleable_square_feet" value="<?= $fieldss['actual_saleable_square_feet'] ?? '' ?>"></td>
                <td><input type="text" id="actual_saleable_rate" name="actual_saleable_rate" value="<?= $fieldss['actual_saleable_rate'] ?? '' ?>"></td>
                <td>
                    <input type="text" id="actual_saleable_valuation_computed" readonly>
                    <input type="hidden" name="actual_saleable_valuation_computed" id="actual_saleable_valuation_hidden">
                </td>
            </tr>
            <tr>
                <td colspan="4">ACTUAL AREA VALUATION</td>
                <td>
                    <input type="text" id="total_actual_area_valuation" readonly>
                    <input type="hidden" name="total_actual_area_valuation" id="total_actual_area_valuation_hidden">
                </td>
            </tr>
      
    </tbody>
</table>
 
<script>
document.addEventListener("DOMContentLoaded", function () {
    function calculateValuation(squareFeetId, rateId, valuationId, hiddenId, totalCallback) {
        let squareFeetInput = document.getElementById(squareFeetId);
        let rateInput = document.getElementById(rateId);
        let valuationInput = document.getElementById(valuationId);
        let hiddenInput = document.getElementById(hiddenId);

        function updateValuation() {
            let squareFeet = parseFloat(squareFeetInput.value) || 0;
            let rate = parseFloat(rateInput.value) || 0;
            let valuation = squareFeet * rate;
            valuationInput.value = valuation.toFixed(2);
            hiddenInput.value = valuation.toFixed(2);
            totalCallback();
        }

        squareFeetInput.addEventListener("input", updateValuation);
        rateInput.addEventListener("input", updateValuation);

        updateValuation();
    }

    function updateTotalValuation() {
        let plotValuation = parseFloat(document.getElementById("plot_valuation_computed").value) || 0;
        let carpetValuation = parseFloat(document.getElementById("carpet_valuation_computed").value) || 0;
        let constructionValuation = parseFloat(document.getElementById("construction_valuation_computed").value) || 0;
        let saleableValuation = parseFloat(document.getElementById("saleable_valuation_computed").value) || 0;

        let totalValuation = plotValuation + carpetValuation + constructionValuation + saleableValuation;
        document.getElementById("total_area_valuation").value = totalValuation.toFixed(2);
        document.getElementById("total_area_valuation_hidden").value = totalValuation.toFixed(2);
    }

    function updateTotalActualValuation() {
        let plotValuation = parseFloat(document.getElementById("actual_plot_valuation_computed").value) || 0;
        let carpetValuation = parseFloat(document.getElementById("actual_carpet_valuation_computed").value) || 0;
        let constructionValuation = parseFloat(document.getElementById("actual_construction_valuation_computed").value) || 0;
        let saleableValuation = parseFloat(document.getElementById("actual_saleable_valuation_computed").value) || 0;

        let totalValuation = plotValuation + carpetValuation + constructionValuation + saleableValuation;
        document.getElementById("total_actual_area_valuation").value = totalValuation.toFixed(2);
        document.getElementById("total_actual_area_valuation_hidden").value = totalValuation.toFixed(2);
    }

    calculateValuation("plot_square_feet", "plot_rate", "plot_valuation_computed", "plot_valuation_hidden", updateTotalValuation);
    calculateValuation("carpet_square_feet", "carpet_rate", "carpet_valuation_computed", "carpet_valuation_hidden", updateTotalValuation);
    calculateValuation("construction_square_feet", "construction_rate", "construction_valuation_computed", "construction_valuation_hidden", updateTotalValuation);
    calculateValuation("saleable_square_feet", "saleable_rate", "saleable_valuation_computed", "saleable_valuation_hidden", updateTotalValuation);
    
    calculateValuation("actual_plot_square_feet", "actual_plot_rate", "actual_plot_valuation_computed", "actual_plot_valuation_hidden", updateTotalActualValuation);
    calculateValuation("actual_carpet_square_feet", "actual_carpet_rate", "actual_carpet_valuation_computed", "actual_carpet_valuation_hidden", updateTotalActualValuation);
    calculateValuation("actual_construction_square_feet", "actual_construction_rate", "actual_construction_valuation_computed", "actual_construction_valuation_hidden", updateTotalActualValuation);
    calculateValuation("actual_saleable_square_feet", "actual_saleable_rate", "actual_saleable_valuation_computed", "actual_saleable_valuation_hidden", updateTotalActualValuation);
    
    document.querySelector("form").addEventListener("submit", function (event) {
        updateTotalValuation();
        updateTotalActualValuation();
        
        // Ensure hidden fields have the latest computed values before submission
        document.getElementById("total_area_valuation_hidden").value = document.getElementById("total_area_valuation").value;
        document.getElementById("total_actual_area_valuation_hidden").value = document.getElementById("total_actual_area_valuation").value;
    });

    updateTotalValuation();
    updateTotalActualValuation();
});
</script>

            <!-- Additional Amenities Cost Section -->
            <table>
                <tr>
                    <th colspan="6">ADDITIONAL AMENITIES COST</th>
                </tr>
                <tr>
                    
                    <th style="background-color: lightskyblue; color: black; " >AMENITIES</th>
                    <th style="background-color: lightskyblue; color: black; " >DESCRIPTION</th>
                    <th style="background-color: lightskyblue; color: black; " >AMOUNT (Rs.)</th>
                </tr>
                <tr>
    <td >Car Parking</td>
    <td><input type="text" id="car_parking" name="car_parking" value="<?= htmlspecialchars($fieldss['car_parking'] ?? '') ?>"></td>
    <td><input type="text" id="car_parking_amount" name="car_parking_amount" value="<?= htmlspecialchars($fieldss['car_parking_amount'] ?? '0') ?>"></td>
</tr>
<tr>
    <td  >Additional Amenities 1</td>
    <td><input type="text" id="addition_amenities_description_2" name="addition_amenities_description_2" value="<?= htmlspecialchars($fieldss['addition_amenities_description_2'] ?? '') ?>"></td>
    <td><input type="text" id="addition_amenities_amount_2" name="addition_amenities_amount_2" value="<?= htmlspecialchars($fieldss['addition_amenities_amount_2'] ?? '0') ?>"></td>
</tr>
<tr>
    <td  >Additional Amenities 2</td>
    <td><input type="text" id="addition_amenities_description_3" name="addition_amenities_description_3" value="<?= htmlspecialchars($fieldss['addition_amenities_description_3'] ?? '') ?>"></td>
    <td><input type="text" id="addition_amenities_amount_3" name="addition_amenities_amount_3" value="<?= htmlspecialchars($fieldss['addition_amenities_amount_3'] ?? '0') ?>"></td>
</tr>
<tr>
    <td  >Additional Amenities 3</td>
    <td><input type="text" id="addition_amenities_description_4" name="addition_amenities_description_4" value="<?= htmlspecialchars($fieldss['addition_amenities_description_4'] ?? '') ?>"></td>
    <td><input type="text" id="addition_amenities_amount_4" name="addition_amenities_amount_4" value="<?= htmlspecialchars($fieldss['addition_amenities_amount_4'] ?? '0') ?>"></td>
</tr>
<tr>
    <td colspan="2">AMENITIES TOTAL</td>
    <td>
        <input type="text" id="amenities_total" readonly>
        <input type="hidden" name="amenities_total" id="amenities_total_hidden">
    </td>
</tr>

 
<script>
document.addEventListener("DOMContentLoaded", function () {
    function calculateAmenitiesTotal() {
        let amount1 = parseFloat(document.getElementById("car_parking_amount").value) || 0;
        let amount2 = parseFloat(document.getElementById("addition_amenities_amount_2").value) || 0;
        let amount3 = parseFloat(document.getElementById("addition_amenities_amount_3").value) || 0;
        let amount4 = parseFloat(document.getElementById("addition_amenities_amount_4").value) || 0;

        let total = amount1 + amount2 + amount3 + amount4;
        document.getElementById("amenities_total").value = total.toFixed(2);
        document.getElementById("amenities_total_hidden").value = total.toFixed(2);
    }

    document.getElementById("car_parking_amount").addEventListener("input", calculateAmenitiesTotal);
    document.getElementById("addition_amenities_amount_2").addEventListener("input", calculateAmenitiesTotal);
    document.getElementById("addition_amenities_amount_3").addEventListener("input", calculateAmenitiesTotal);
    document.getElementById("addition_amenities_amount_4").addEventListener("input", calculateAmenitiesTotal);

    calculateAmenitiesTotal();
});
</script>

</table>
    <table>
        <thead>
            <tr class="header">
                <th colspan="6">FINAL CONSIDERED</th>
            </tr>
            <tr>
                <th style="background-color: lightskyblue; color: black;" colspan="2">AREA TYPE</th>
                <th style="background-color: lightskyblue; color: black;">SQUARE FEET</th>
                <th style="background-color: lightskyblue; color: black;">RATE/SQ.FT</th>
                <th style="background-color: lightskyblue; color: black;" colspan="2">VALUATION (Rs.)</th>
            </tr>
        </thead>
        <tbody>   
    
            <tr>
                <td colspan="2">Plot Area</td>
                <td>
                    <input type="text" id="final_plot_square_feet" name="final_plot_square_feet" 
                        value="<?= $fieldss['final_plot_square_feet'] ?? '' ?>">
                </td>
                <td>
                    <input type="text" id="final_plot_rate" name="final_plot_rate" 
                        value="<?= $fieldss['final_plot_rate'] ?? '0' ?>">
                </td>
                <td>
                    <input type="text" id="finally_plot_valuation" readonly>
                    <input type="hidden" name="finally_plot_valuation_hidden" id="finally_plot_valuation_hidden">
                </td>
            </tr>
              <tr>
    <td colspan="2"> <input type="text" id="construction_name_1"  style="text-align:center;" name="construction_name_1"  value="<?= $fieldss['construction_name_1'] ?? '' ?>" placeholder="Construction name 1"></td>
    <td><input type="text" id="construction_area_sqft_1"  name="construction_area_sqft_1"  value="<?= $fieldss['construction_area_sqft_1'] ?? '' ?>" placeholder="Construction area sqft 1" ></td>
    <td><input type="text" id="construction_rate_1"  name="construction_rate_1"  value="<?= $fieldss['construction_rate_1'] ?? '' ?>"  value="<?= $fieldss['final_plot_rate'] ?? '' ?>" placeholder="Construction rate 1" ></td>
<td>
<input type="text" id="construction_valuation_1" name="construction_valuation_1"   value="<?= $fieldss['construction_valuation_1'] ?? '' ?>" placeholder="Construction valuation 1 "readonly>
<input type="hidden" name="final_area_valuation_hiddens" id="final_area_valuation_hiddens"></td>
     
</tr> 
   <tr> <td colspan="2"> <input type="text" id="construction_name_2"  style="text-align:center;"name="construction_name_2"   value="<?= $fieldss['construction_name_2'] ?? '' ?>" placeholder="Construction name 2"></td>
    <td><input type="text" id="construction_area_sqft_2"  name="construction_area_sqft_2"  value="<?= $fieldss['construction_area_sqft_2'] ?? '' ?>" placeholder="Construction area sqft 2" ></td>
    <td> <input type="text" id="construction_rate_2"  name="construction_rate_2"  value="<?= $fieldss['construction_rate_2'] ?? '' ?>" placeholder="Construction rate 2" ></td>
    <td>
    <input type="text" id="construction_valuation_2" name="construction_valuation_2"  value="<?= $fieldss['construction_valuation_2'] ?? '' ?>" placeholder="Construction valuation 2 " readonly>
    <input type="hidden" name="final_area_valuation_hiddens" id="final_area_valuation_hiddens">
    </td>
     
</tr>
   <tr>
    <td colspan="2"> <input type="text" id="construction_name_3"  style="text-align:center;" name="construction_name_3"  value="<?= $fieldss['construction_name_3'] ?? '' ?>" placeholder="Construction name 3 "></td>
    <td><input type="text" id="construction_area_sqft_3"  name="construction_area_sqft_3"  value="<?= $fieldss['construction_area_sqft_3'] ?? '' ?>" placeholder="Construction area sqft 3"> </td>
     <td><input type="text" id="construction_rate_3"  name="construction_rate_3"  value="<?= $fieldss['construction_rate_3'] ?? '' ?>" placeholder="Construction rate 3"></td>
<td>
<input type="text" id="construction_valuation_3" name="construction_valuation_3"  value="<?=$fieldss['construction_valuation_3'] ?? '' ?>" placeholder="Construction valuation 3 " readonly>
<input type="hidden" name="final_area_valuation_hiddens" id="final_area_valuation_hiddens"></td>  
</tr>
            <tr>
                <td colspan="2">Construction Built-Up Area</td>
                <td>
                    <input type="text" id="final_construction_square_feet" name="final_construction_square_feet" 
                        value="<?= $fieldss['final_construction_square_feet'] ?? '' ?>"readonly>
                </td>
                <td>
                    <input type="text" id="final_construction_rate" name="final_construction_rate" 
                        value="<?= $fieldss['final_construction_rate'] ?? '' ?>"readonly>
                </td>
                <td>
                    <input type="text" id="finally_construction_valuation" name="finally_construction_valuation" readonly>
                    <input type="hidden" name="finally_construction_valuation_hidden" id="finally_construction_valuation_hidden">
                </td>
            </tr>
            <tr>
    <td colspan="2">Carpet Area</td>
    <td>
                     <input type="text" id="final_carpet_area_square_feet" name="final_carpet_area_square_feet" 
                        value="<?= $fieldss['final_carpet_area_square_feet'] ?? '' ?>"readonly>
               </td>
                <td>
                  
                </td>
                <td>
                    </td>
     
</tr>

            <tr>
    <td colspan="2">Saleable Area (Super Built-Up Area)</td>
    <td>
                    <input type="text" id="final_area_square_feet" name="final_area_square_feet" 
                        value="<?= $fieldss['final_area_square_feet'] ?? '' ?>">
                </td>
                <td>
                    <input type="text" id="final_area_rate" name="final_area_rate" 
                        value="<?= $fieldss['final_area_rate'] ?? '' ?>">
                </td>
                <td>
                    <input type="text" id="final_area_valuation" readonly>
                    <input type="hidden" name="final_area_valuation_hidden" id="final_area_valuation_hidden">
                </td>
     
</tr>
 
            <tr>
    <td colspan="4">FINAL AREA VALUATION</td>
    <td>
        <input type="text" id="total_finally_area_valuation" name="total_finally_area_valuation" readonly>
        <input type="hidden" name="total_finally_area_valuation_hidden" id="total_finally_area_valuation_hidden">
    </td>
</tr>

        </tbody>
      <table>
        <thead>
            <tr class="header">
                <th colspan="6">GOVERNMENT FINAL CONSIDERED</th>
            </tr>
             <tr>
                <th style="background-color: lightskyblue; color: black;" colspan="1">AREA TYPE</th>
                <th style="background-color: lightskyblue; color: black;">SQUARE FEET</th>
                <th style="background-color: lightskyblue; color: black;">RATE/SQ.FT</th>
                <th style="background-color: lightskyblue; color: black;" colspan="2">VALUATION (Rs.)</th>
            </tr>
        </thead>
        <tbody>  
  
 
    <tr>

        <td>GOVERNMENT Plot Area</td>
        <td><input type="text" id="gov_plot_area_sqft" name="gov_plot_area_sqft" value="<?= $fieldss['gov_plot_area_sqft'] ?? '' ?>" placeholder="Enter plot area (sqft)"></td>
        <td><input type="text" id="gov_plot_area_rate" name="gov_plot_area_rate" value="<?= $fieldss['gov_plot_area_rate'] ?? '' ?>" placeholder="Enter rate/sqft"></td>
        <td><input type="text" id="gov_plot_area_valuation" name="gov_plot_area_valuation" value="<?= $fieldss['gov_plot_area_valuation'] ?? '' ?>" placeholder="Auto valuation"></td>
    </tr>

    <!-- GOVERNMENT Construction 1 -->
    <tr>
        <td><input type="text" id="gov_construction_name1" name="gov_construction_name1" value="<?= $fieldss['gov_construction_name1'] ?? '' ?>" placeholder="Government Construction name 1"></td>
        <td><input type="text" id="gov_construction_area1" name="gov_construction_area1" value="<?= $fieldss['gov_construction_area1'] ?? '' ?>" placeholder="Government Construction area sqft 1"></td>
        <td><input type="text" id="gov_construction_rate1" name="gov_construction_rate1" value="<?= $fieldss['gov_construction_rate1'] ?? '' ?>" placeholder="Government Construction rate 1"></td>
        <td><input type="text" id="gov_construction_valuation1" name="gov_construction_valuation1" value="<?= $fieldss['gov_construction_valuation1'] ?? '' ?>" placeholder="0.00"></td>
    </tr>
    

    <!-- GOVERNMENT Construction 2 -->
    <tr>
        <td><input type="text" id="gov_construction_name2" name="gov_construction_name2" value="<?= $fieldss['gov_construction_name2'] ?? '' ?>" placeholder="Government Construction name 2"></td>
        <td><input type="text" id="gov_construction_area2" name="gov_construction_area2" value="<?= $fieldss['gov_construction_area2'] ?? '' ?>" placeholder="Government Construction area sqft 2"></td>
        <td><input type="text" id="gov_construction_rate2" name="gov_construction_rate2" value="<?= $fieldss['gov_construction_rate2'] ?? '' ?>" placeholder="Government Construction rate 2"></td>
        <td><input type="text" id="gov_construction_valuation2" name="gov_construction_valuation2" value="<?= $fieldss['gov_construction_valuation2'] ?? '' ?>" placeholder="0.00"></td>
    </tr>

    <!-- GOVERNMENT Construction 3 -->
    <tr>
        <td><input type="text" id="gov_construction_name3" name="gov_construction_name3" value="<?= $fieldss['gov_construction_name3'] ?? '' ?>" placeholder="Government Construction name 3"></td>
        <td><input type="text" id="gov_construction_area3" name="gov_construction_area3" value="<?= $fieldss['gov_construction_area3'] ?? '' ?>" placeholder="Government Construction area sqft 3"></td>
        <td><input type="text" id="gov_construction_rate3" name="gov_construction_rate3" value="<?= $fieldss['gov_construction_rate3'] ?? '' ?>" placeholder="Government Construction rate 3"></td>
        <td><input type="text" id="gov_construction_valuation3" name="gov_construction_valuation3" value="<?= $fieldss['gov_construction_valuation3'] ?? '' ?>" placeholder="0.00"></td>
    </tr>

    <!-- GOVERNMENT Built-Up Area -->
    <tr>
        <td>GOVERNMENT Built-Up Area</td>
        <td><input type="text" id="gov_builtup_area_sqft" name="gov_builtup_area_sqft" value="<?= $fieldss['gov_builtup_area_sqft'] ?? '' ?>" placeholder="Built-up area sqft"></td>
        <td><input type="text" id="gov_builtup_area_rate" name="gov_builtup_area_rate" value="<?= $fieldss['gov_builtup_area_rate'] ?? '' ?>" placeholder="Rate/sqft"></td>
        <td><input type="text" id="gov_builtup_area_valuation" name="gov_builtup_area_valuation" value="<?= $fieldss['gov_builtup_area_valuation'] ?? '' ?>" placeholder="Auto valuation"></td>
    </tr>

    <!-- GOVERNMENT Saleable Area -->
    <tr>
        <td>GOVERNMENT Saleable Area (Super Built-Up Area)</td>
        <td><input type="text" id="gov_saleable_area_sqft" name="gov_saleable_area_sqft" value="<?= $fieldss['gov_saleable_area_sqft'] ?? '' ?>" placeholder="Saleable area sqft"></td>
        <td><input type="text" id="gov_saleable_area_rate" name="gov_saleable_area_rate" value="<?= $fieldss['gov_saleable_area_rate'] ?? '' ?>" placeholder="Rate/sqft"></td>
        <td><input type="text" id="gov_saleable_area_valuation" name="gov_saleable_area_valuation" value="<?= $fieldss['gov_saleable_area_valuation'] ?? '' ?>" placeholder="Auto valuation"></td>
    </tr>

    <!-- GOVERNMENT FINAL VALUATION -->
    <tr>
        <td colspan="3" style="text-align:right;">GOVERNMENT FINAL AREA VALUATION</td>
        <td><input type="text" id="gov_final_area_valuation" name="gov_final_area_valuation" value="<?= $fieldss['gov_final_area_valuation'] ?? '' ?>" placeholder="0.00"></td>
    </tr>
</table>

   
</tbody>
   
<script>
function calcGovernmentValuations() {
    const val = id => parseFloat(document.getElementById(id)?.value) || 0;
    const set = (id, v) => document.getElementById(id).value = v.toFixed(2);

    // Plot
    set("gov_plot_area_valuation", val("gov_plot_area_sqft") * val("gov_plot_area_rate"));

    // Constructions
    set("gov_construction_valuation1", val("gov_construction_area1") * val("gov_construction_rate1"));
    set("gov_construction_valuation2", val("gov_construction_area2") * val("gov_construction_rate2"));
    set("gov_construction_valuation3", val("gov_construction_area3") * val("gov_construction_rate3"));

    // Built-up
    const builtup_sqft = val("gov_construction_area1") + val("gov_construction_area2") + val("gov_construction_area3");
    const builtup_val = val("gov_construction_valuation1") + val("gov_construction_valuation2") + val("gov_construction_valuation3");
    set("gov_builtup_area_sqft", builtup_sqft);
    set("gov_builtup_area_valuation", builtup_val);
    set("gov_builtup_area_rate", builtup_sqft > 0 ? builtup_val / builtup_sqft : 0);

    // Saleable
    set("gov_saleable_area_valuation", val("gov_saleable_area_sqft") * val("gov_saleable_area_rate"));

    // Final
    set("gov_final_area_valuation",
        val("gov_plot_area_valuation") +
        val("gov_construction_valuation1") +
        val("gov_construction_valuation2") +
        val("gov_construction_valuation3") +
        val("gov_saleable_area_valuation")
    );
}

// Attach real-time calculation
document.querySelectorAll("input").forEach(inp => {
    inp.addEventListener("input", calcGovernmentValuations);
});
</script>

<table>


              <table>
        <thead>
            <tr class="header">
                <th colspan="6">AS ON DATE / PROPOSED FINAL CONSIDERED</th>
            </tr>
             <tr>
                <th style="background-color: lightskyblue; color: black;" colspan="1">AREA TYPE</th>
                <th style="background-color: lightskyblue; color: black;">SQUARE FEET</th>
                <th style="background-color: lightskyblue; color: black;">RATE/SQ.FT</th>
                <th style="background-color: lightskyblue; color: black;" colspan="2">VALUATION (Rs.)</th>
            </tr>
        </thead>
        <tbody>  
  

  <!-- Proposed Estimate Plot Area -->
  <tr>
    <td>Proposed Plot Area</td>
    <td><input type="text" id="proposed_plot_area_sqft" name="proposed_plot_area_sqft" 
      value="<?= $fieldss['proposed_plot_area_sqft'] ?? '' ?>" placeholder="Enter plot area (sqft)"></td>
    <td><input type="text" id="proposed_plot_rate" name="proposed_plot_rate" 
      value="<?= $fieldss['proposed_plot_rate'] ?? '' ?>" placeholder="Enter rate/sqft"></td>
    <td><input type="text" id="proposed_plot_valuation" name="proposed_plot_valuation" 
      value="<?= $fieldss['proposed_plot_valuation'] ?? '' ?>" placeholder="Auto valuation"></td>
  </tr>

  <!-- Proposed Construction 1 -->
  <tr>
    <td><input type="text" id="proposed_construction_name1" name="proposed_construction_name1" 
      value="<?= $fieldss['proposed_construction_name1'] ?? '' ?>" placeholder="Proposed Construction name 1"></td>
    <td><input type="text" id="proposed_construction_area_sqft1" name="proposed_construction_area_sqft1" 
      value="<?= $fieldss['proposed_construction_area_sqft1'] ?? '' ?>" placeholder="Area sqft"></td>
    <td><input type="text" id="proposed_construction_rate1" name="proposed_construction_rate1" 
      value="<?= $fieldss['proposed_construction_rate1'] ?? '' ?>" placeholder="Rate/sqft"></td>
    <td><input type="text" id="proposed_construction_valuation1" name="proposed_construction_valuation1" 
      value="<?= $fieldss['proposed_construction_valuation1'] ?? '0.00' ?>" placeholder="0.00"></td>
  </tr>

  <!-- Proposed Construction 2 -->
  <tr>
    <td><input type="text" id="proposed_construction_name2" name="proposed_construction_name2" 
      value="<?= $fieldss['proposed_construction_name2'] ?? '' ?>" placeholder="Proposed Construction name 2"></td>
    <td><input type="text" id="proposed_construction_area_sqft2" name="proposed_construction_area_sqft2" 
      value="<?= $fieldss['proposed_construction_area_sqft2'] ?? '' ?>" placeholder="Area sqft"></td>
    <td><input type="text" id="proposed_construction_rate2" name="proposed_construction_rate2" 
      value="<?= $fieldss['proposed_construction_rate2'] ?? '' ?>" placeholder="Rate/sqft"></td>
    <td><input type="text" id="proposed_construction_valuation2" name="proposed_construction_valuation2" 
      value="<?= $fieldss['proposed_construction_valuation2'] ?? '0.00' ?>" placeholder="0.00"></td>
  </tr>

  <!-- Proposed Construction 3 -->
  <tr>
    <td><input type="text" id="proposed_construction_name3" name="proposed_construction_name3" 
      value="<?= $fieldss['proposed_construction_name3'] ?? '' ?>" placeholder="Proposed Construction name 3"></td>
    <td><input type="text" id="proposed_construction_area_sqft3" name="proposed_construction_area_sqft3" 
      value="<?= $fieldss['proposed_construction_area_sqft3'] ?? '' ?>" placeholder="Area sqft"></td>
    <td><input type="text" id="proposed_construction_rate3" name="proposed_construction_rate3" 
      value="<?= $fieldss['proposed_construction_rate3'] ?? '' ?>" placeholder="Rate/sqft"></td>
    <td><input type="text" id="proposed_construction_valuation3" name="proposed_construction_valuation3" 
      value="<?= $fieldss['proposed_construction_valuation3'] ?? '0.00' ?>" placeholder="0.00"></td>
  </tr>

  <!-- Proposed Estimate Construction Built-Up Area -->
  <tr>
    <td>Proposed  Construction Built-Up Area</td>
    <td><input type="text" id="proposed_builtup_area_sqft" name="proposed_builtup_area_sqft" 
      value="<?= $fieldss['proposed_builtup_area_sqft'] ?? '' ?>" placeholder="Proposed Built-up area sqft"></td>
    <td><input type="text" id="proposed_builtup_rate" name="proposed_builtup_rate" 
      value="<?= $fieldss['proposed_builtup_rate'] ?? '' ?>" placeholder="Proposed Rate/sqft"></td>
    <td><input type="text" id="proposed_builtup_valuation" name="proposed_builtup_valuation" 
      value="<?= $fieldss['proposed_builtup_valuation'] ?? '' ?>" placeholder="Proposed Auto valuation"></td>
  </tr>

  <!-- Proposed Estimate Saleable Area -->
  <tr>
    <td>Proposed   Saleable Area (Super Built-Up Area)</td>
    <td><input type="text" id="proposed_saleable_area_sqft" name="proposed_saleable_area_sqft" 
      value="<?= $fieldss['proposed_saleable_area_sqft'] ?? '' ?>" placeholder="Proposed Saleable area sqft"></td>
    <td><input type="text" id="proposed_saleable_rate" name="proposed_saleable_rate" 
      value="<?= $fieldss['proposed_saleable_rate'] ?? '' ?>" placeholder="Proposed Rate/sqft"></td>
    <td><input type="text" id="proposed_saleable_valuation" name="proposed_saleable_valuation" 
      value="<?= $fieldss['proposed_saleable_valuation'] ?? '' ?>" placeholder="Proposed Auto valuation"></td>
  </tr>

  <!-- Proposed Final Area Valuation -->
  <tr>
    <td colspan="3" style="text-align:right;"><strong>PROPOSED FINAL AREA VALUATION</strong></td>
    <td><input type="text" id="proposed_final_area_valuation" name="proposed_final_area_valuation" 
      value="<?= $fieldss['proposed_final_area_valuation'] ?? '0.00' ?>" placeholder="0.00"></td>
  </tr>
</tbody>

<script>
function calculateProposed() {
    const val = id => parseFloat(document.getElementById(id)?.value) || 0;

    // Plot area valuation
    let proposed_plot_area_sqft = val("proposed_plot_area_sqft");
    let proposed_plot_rate = val("proposed_plot_rate");
    let proposed_plot_valuation = proposed_plot_area_sqft * proposed_plot_rate;
    document.getElementById("proposed_plot_valuation").value = proposed_plot_valuation.toFixed(2);

    // Construction 1
    let proposed_construction_area_sqft1 = val("proposed_construction_area_sqft1");
    let proposed_construction_rate1 = val("proposed_construction_rate1");
    let proposed_construction_valuation1 = proposed_construction_area_sqft1 * proposed_construction_rate1;
    document.getElementById("proposed_construction_valuation1").value = proposed_construction_valuation1.toFixed(2);

    // Construction 2
    let proposed_construction_area_sqft2 = val("proposed_construction_area_sqft2");
    let proposed_construction_rate2 = val("proposed_construction_rate2");
    let proposed_construction_valuation2 = proposed_construction_area_sqft2 * proposed_construction_rate2;
    document.getElementById("proposed_construction_valuation2").value = proposed_construction_valuation2.toFixed(2);

    // Construction 3
    let proposed_construction_area_sqft3 = val("proposed_construction_area_sqft3");
    let proposed_construction_rate3 = val("proposed_construction_rate3");
    let proposed_construction_valuation3 = proposed_construction_area_sqft3 * proposed_construction_rate3;
    document.getElementById("proposed_construction_valuation3").value = proposed_construction_valuation3.toFixed(2);

    // Built-up Area
    let proposed_builtup_area_sqft = proposed_construction_area_sqft1 + proposed_construction_area_sqft2 + proposed_construction_area_sqft3;
    let proposed_builtup_area_valuation = proposed_construction_valuation1 + proposed_construction_valuation2 + proposed_construction_valuation3;
    let proposed_builtup_rate = proposed_builtup_area_sqft > 0 ? (proposed_builtup_area_valuation / proposed_builtup_area_sqft) : 0;
    document.getElementById("proposed_builtup_area_sqft").value = proposed_builtup_area_sqft.toFixed(2);
    document.getElementById("proposed_builtup_rate").value = proposed_builtup_rate.toFixed(2);
    document.getElementById("proposed_builtup_valuation").value = proposed_builtup_area_valuation.toFixed(2);

    // Saleable Area
    let proposed_saleable_area_sqft = val("proposed_saleable_area_sqft");
    let proposed_saleable_rate = val("proposed_saleable_rate");
    let proposed_saleable_valuation = proposed_saleable_area_sqft * proposed_saleable_rate;
    document.getElementById("proposed_saleable_valuation").value = proposed_saleable_valuation.toFixed(2);

    // Final Valuation
    let proposed_final_area_valuation = proposed_plot_valuation + proposed_construction_valuation1 + proposed_construction_valuation2 + proposed_construction_valuation3 + proposed_saleable_valuation;
    document.getElementById("proposed_final_area_valuation").value = proposed_final_area_valuation.toFixed(2);
}

// Event listener to update in real time
document.querySelectorAll("input[id^='proposed_']").forEach(input => {
    input.addEventListener("input", calculateProposed);
});
</script>

        <table>
        <tr class="header">
                    <th  colspan="6"> DIMENSIONS</th>
                </tr>
            <tr>
                <th>PROPERTY DIMENSIONS</th>
                <th>North</th>
                <th>SOUTH</th>
                <th >EAST</th>
                <th >WEST</th>
            </tr>
            <tr>
                <td>AS PER SITE</th>
                <td><input type="text" id="dimension_as_per_site_north" name="dimension_as_per_site_north" value="<?= htmlspecialchars($fieldss['dimension_as_per_site_north'] ?? '') ?>"></td>
    <td><input type="text" id="dimension_as_per_site_south"name="dimension_as_per_site_south" value="<?= htmlspecialchars($fieldss['dimension_as_per_site_south'] ?? '') ?>"></td>
    <td><input type="text"  id="dimension_as_per_site_east" name="dimension_as_per_site_east" value="<?= htmlspecialchars($fieldss['dimension_as_per_site_east'] ?? '') ?>"></td>
    <td><input type="text"  id="dimension_as_per_site_west" name="dimension_as_per_site_west" value="<?= htmlspecialchars($fieldss['dimension_as_per_site_west'] ?? '') ?>"></td>
</tr>
            <tr>
                <td id="change">AS PER LEGAL DOCUMENTS</th>
                <td><input type="text"   id="dimension_as_per_document_north" name="dimension_as_per_document_north" value="<?= htmlspecialchars($fieldss['dimension_as_per_document_north'] ?? '') ?>"></td>
    <td><input type="text"  id="dimension_as_per_document_south" name="dimension_as_per_document_south" value="<?= htmlspecialchars($fieldss['dimension_as_per_document_south'] ?? '') ?>"></td>
    <td><input type="text"   id="dimension_as_per_document_east" name="dimension_as_per_document_east" value="<?= htmlspecialchars($fieldss['dimension_as_per_document_east'] ?? '') ?>"></td>
    <td><input type="text"  id="dimension_as_per_document_west" name="dimension_as_per_document_west" value="<?= htmlspecialchars($fieldss['dimension_as_per_document_west'] ?? '') ?>"></td>
</tr>
        </table>
           <!-- Final Valuation Recommended Section -->
              <table>
    <tr>
        <th colspan="4">Estimate Analysis (Applicable only in Self Construction cases)</th>
    </tr>

    <tr>
        <td>Estimated Cost (In Rs)</td>
        <td><input type="text" id="estimated_cost_rs" name="estimated_cost_rs" value="<?= $fieldss['estimated_cost_rs'] ?? '' ?>" placeholder="Enter Estimated Cost (Rs)"></td>
        <td>Estimated Cost (in Rs per Sqft)</td>
        <td><input type="text" id="estimated_cost_per_sqft" name="estimated_cost_per_sqft" value="<?= $fieldss['estimated_cost_per_sqft'] ?? '' ?>" placeholder="Enter Cost per Sqft"></td>
    </tr>

    <tr>
        <td>Justified Estimated Cost (In Rs per Sqft)</td>
        <td><input type="text" id="justified_estimated_cost_per_sqft" name="justified_estimated_cost_per_sqft" value="<?= $fieldss['justified_estimated_cost_per_sqft'] ?? '' ?>" placeholder="Enter Justified Cost per Sqft"></td>
        <td>Adoptable / Justified Estimated Cost (In Rs)</td>
        <td><input type="text" id="adoptable_justified_estimated_cost" name="adoptable_justified_estimated_cost" value="<?= $fieldss['adoptable_justified_estimated_cost'] ?? '' ?>" placeholder="Enter Adoptable Cost (Rs)"></td>
    </tr>
</table>
              <table class="valuation-table">

              <!-- Final Valuation Recommended Section -->
                <tr>
                    <th colspan="4">FINAL VALUATION</th>
                </tr>             
                <tr>
    <td>TOTAL FAIR MARKET VALUATION OF THE PROPERTY (Rs.)</td>
    <td>
        <input type="text" id="total_finally_area_valuation_display"   readonly>
     </td>

    <td>TOTAL VALUATION IN WORDS</td>
    <td>
        <input type="text" id="total_valuation_words" name="total_valuation_words" readonly>
    </td>
</tr>



<script>
document.addEventListener("DOMContentLoaded", function () {

    function numberToWords(num) {
        const words = {
            0: "Zero", 1: "One", 2: "Two", 3: "Three", 4: "Four", 5: "Five", 6: "Six", 7: "Seven", 8: "Eight", 9: "Nine",
            10: "Ten", 11: "Eleven", 12: "Twelve", 13: "Thirteen", 14: "Fourteen", 15: "Fifteen", 16: "Sixteen",
            17: "Seventeen", 18: "Eighteen", 19: "Nineteen", 20: "Twenty", 30: "Thirty", 40: "Forty", 50: "Fifty",
            60: "Sixty", 70: "Seventy", 80: "Eighty", 90: "Ninety"
        };

        if (num === 0) return "Zero";
        if (num < 20) return words[num];
        if (num < 100) return words[num - (num % 10)] + (num % 10 ? " " + words[num % 10] : "");
        if (num < 1000) return words[Math.floor(num / 100)] + " Hundred" + (num % 100 ? " " + numberToWords(num % 100) : "");
        if (num < 100000) return numberToWords(Math.floor(num / 1000)) + " Thousand" + (num % 1000 ? " " + numberToWords(num % 1000) : "");
        if (num < 10000000) return numberToWords(Math.floor(num / 100000)) + " Lakh" + (num % 100000 ? " " + numberToWords(num % 100000) : "");
        return numberToWords(Math.floor(num / 10000000)) + " Crore" + (num % 10000000 ? " " + numberToWords(num % 10000000) : "");
    }

    function calculateValuation(squareFeetId, rateId, valuationId, hiddenId) {
        let squareFeetInput = document.getElementById(squareFeetId);
        let rateInput = document.getElementById(rateId);
        let valuationInput = document.getElementById(valuationId);
        let hiddenInput = document.getElementById(hiddenId);

        function updateValuation() {
            let squareFeet = parseFloat(squareFeetInput?.value) || 0;
            let rate = parseFloat(rateInput?.value) || 0;
            let valuation = squareFeet * rate;

            if (valuationInput) {
                valuationInput.value = valuation.toFixed(2);
                valuationInput.dispatchEvent(new Event("input"));
            }
            if (hiddenInput) hiddenInput.value = valuation.toFixed(2);
        }

        if (squareFeetInput) squareFeetInput.addEventListener("input", updateValuation);
        if (rateInput) rateInput.addEventListener("input", updateValuation);
        updateValuation();
    }

    function calculateConstructionValuations() {
        const area1 = parseFloat(document.getElementById('construction_area_sqft_1')?.value) || 0;
        const rate1 = parseFloat(document.getElementById('construction_rate_1')?.value) || 0;
        const area2 = parseFloat(document.getElementById('construction_area_sqft_2')?.value) || 0;
        const rate2 = parseFloat(document.getElementById('construction_rate_2')?.value) || 0;
        const area3 = parseFloat(document.getElementById('construction_area_sqft_3')?.value) || 0;
        const rate3 = parseFloat(document.getElementById('construction_rate_3')?.value) || 0;

        const valuation1 = area1 * rate1;
        const valuation2 = area2 * rate2;
        const valuation3 = area3 * rate3;

        document.getElementById('construction_valuation_1').value = valuation1.toFixed(2);
        document.getElementById('construction_valuation_2').value = valuation2.toFixed(2);
        document.getElementById('construction_valuation_3').value = valuation3.toFixed(2);

        const totalArea = area1 + area2 + area3;
        const totalValuation = valuation1 + valuation2 + valuation3;

        document.getElementById('final_construction_square_feet').value = totalArea.toFixed(2);
        document.getElementById('finally_construction_valuation').value = totalValuation.toFixed(2);
        document.getElementById('finally_construction_valuation_hidden').value = totalValuation.toFixed(2);

        const finalRate = totalArea !== 0 ? totalValuation / totalArea : 0;
        document.getElementById('final_construction_rate').value = finalRate.toFixed(2);

        updateTotalValuation();
    }

    function updateTotalValuation() {
        let plotVal = parseFloat(document.getElementById("finally_plot_valuation")?.value) || 0;
        let consVal = parseFloat(document.getElementById("finally_construction_valuation")?.value) || 0;
        let areaVal = parseFloat(document.getElementById("final_area_valuation")?.value) || 0;

        let totalVal = plotVal + consVal + areaVal;

        // Final unified total field
        let totalField = document.getElementById("total_finally_area_valuation");
        let hiddenTotalField = document.getElementById("total_finally_area_valuation_hidden");

        let displayField = document.getElementById("total_finally_area_valuation_display");

        let wordsField = document.getElementById("total_valuation_words");

        if (totalField) totalField.value = totalVal.toFixed(2);
        if (hiddenTotalField) hiddenTotalField.value = totalVal.toFixed(2);

        if (displayField) displayField.value = totalVal.toFixed(2);  // Mirror display


        if (wordsField) wordsField.value = numberToWords(Math.round(totalVal));
    }

    // Construction listeners
    const constructionInputs = [
        'construction_area_sqft_1', 'construction_rate_1',
        'construction_area_sqft_2', 'construction_rate_2',
        'construction_area_sqft_3', 'construction_rate_3'
    ];
    constructionInputs.forEach(id => {
        let input = document.getElementById(id);
        if (input) input.addEventListener("input", calculateConstructionValuations);
    });

    // General valuation calculators
    calculateValuation("final_plot_square_feet", "final_plot_rate", "finally_plot_valuation", "finally_plot_valuation_hidden");
    calculateValuation("final_area_square_feet", "final_area_rate", "final_area_valuation", "final_area_valuation_hidden");

    // Trigger update when value fields change
    ["finally_plot_valuation", "finally_construction_valuation", "final_area_valuation"].forEach(id => {
        let el = document.getElementById(id);
        if (el) el.addEventListener("input", updateTotalValuation);
    });

    // Initial calculations
    calculateConstructionValuations();
    updateTotalValuation();

    // Ensure total is updated before form submission
    let form = document.querySelector("form");
    if (form) {
        form.addEventListener("submit", function () {
            calculateConstructionValuations();
            updateTotalValuation();
        });
    }
});
</script>




                <tr>
                    <td>DISTRESS PERCENTAGE (%)</td>
                    <td><input type="text"  id="distress_value_percent" name="distress_value_percent" value="<?= htmlspecialchars($fieldss['distress_value_percent'] ?? '') ?>"></td>
               
    <td>DISTRESS VALUE (Rs.)</td>
    <td><input type="text" id="total_distress_value" name="total_distress_value" readonly></td>
</tr>

<script>
document.addEventListener("DOMContentLoaded", function () {
    function numberToWords(num) {
        const words = {
            0: "Zero", 1: "One", 2: "Two", 3: "Three", 4: "Four", 5: "Five", 6: "Six", 7: "Seven", 8: "Eight", 9: "Nine",
            10: "Ten", 11: "Eleven", 12: "Twelve", 13: "Thirteen", 14: "Fourteen", 15: "Fifteen", 16: "Sixteen",
            17: "Seventeen", 18: "Eighteen", 19: "Nineteen", 20: "Twenty", 30: "Thirty", 40: "Forty", 50: "Fifty",
            60: "Sixty", 70: "Seventy", 80: "Eighty", 90: "Ninety"
        };

        if (num === 0) return "Zero";
        if (num < 20) return words[num];
        if (num < 100) return words[num - (num % 10)] + (num % 10 ? " " + words[num % 10] : "");
        if (num < 1000) return words[Math.floor(num / 100)] + " Hundred " + (num % 100 ? numberToWords(num % 100) : "");
        if (num < 100000) return numberToWords(Math.floor(num / 1000)) + " Thousand " + (num % 1000 ? " " + numberToWords(num % 1000) : "");
        if (num < 10000000) return numberToWords(Math.floor(num / 100000)) + " Lakh " + (num % 100000 ? " " + numberToWords(num % 100000) : "");
        return numberToWords(Math.floor(num / 10000000)) + " Crore " + (num % 10000000 ? " " + numberToWords(num % 10000000) : "");
    }

    function calculateDistressValue() {
        let totalValuation = parseFloat(document.getElementById('total_finally_area_valuation')?.value) || 1;
        let distressPercent = parseFloat(document.getElementById('distress_value_percent')?.value) || 1;
        
        // Calculate distress value
        let distressValue = (totalValuation * distressPercent) / 100;
        
        // Update distress value field
        let distressValueInput = document.getElementById('total_distress_value');
        let distressWordsInput = document.getElementById('distress_value_words');

        if (distressValueInput) distressValueInput.value = distressValue.toFixed(2);
        if (distressWordsInput) distressWordsInput.value = numberToWords(Math.round(distressValue));
    }

    // Add event listeners
    document.getElementById('total_finally_area_valuation').addEventListener('input', calculateDistressValue);
    document.getElementById('distress_value_percent').addEventListener('input', calculateDistressValue);

    // Initial calculation on page load
    calculateDistressValue();
});
</script>
<tr>
    <td>DISTRESS VALUE (Rs.) IN WORDS</td>
    <td>
        <input type="text" id="distress_value_words" name="distress_value_words" readonly>
    </td>


              
        <td>LOCAL ENQUIRY</td>
        <td><input type="text" id="enquiry_remarks" name="enquiry_remarks" value="<?= $fieldss['enquiry_remarks'] ?? '' ?>" ></td>
        </tr>
       
    </tr>
<tr>
       <td>INSURABLE VALUE - AUTO COMPUTED</td>
  <td>
    <!-- INSURABLE VALUE (Read-only) -->
<input type="text" id="insurable_value" name="insurable_value" value="<?= $fieldss['insurable_value'] ?? '' ?>" readonly>

  </td>
      
       <td>INSURABLE VALUE - TO BE MANUALLY FEEDED</td>
  <td>
    <!-- INSURABLE VALUE (Read-only) -->
<input type="text" id="insurable_value_1" name="insurable_value_1" value="<?= $fieldss['insurable_value_1'] ?? '' ?>" readonly>

  </td>
        </tr>
<script>
function updateInsurableValue() {
    const propertyType = document.getElementById("propertyType")?.value;
    const area = parseFloat(document.getElementById("final_area_square_feet")?.value) || 0;
    const constructionArea = parseFloat(document.getElementById("final_construction_square_feet")?.value) || 0;
    const constructionRate = parseFloat(document.getElementById("final_construction_rate")?.value) || 0;

    const insurableField = document.getElementById("insurable_value");
    const loadingField = document.getElementById("loading");

    console.log("Type:", propertyType, "Area:", area, "C.Area:", constructionArea, "Rate:", constructionRate);

    if (propertyType === "Land and Building") {
        // Apply Land and Building formula
        insurableField.value = (constructionArea * constructionRate).toFixed(2);
        loadingField.value = '';
    } else if (propertyType === "Floor Property") {
        // Apply Floor Property formula
        insurableField.value = (area * 1200).toFixed(2);
        if (constructionArea > 0) {
            const loading = (1 - (area / constructionArea)) * 100;
            loadingField.value = loading.toFixed(2);
        } else {
            loadingField.value = '';
        }
    } else {
        insurableField.value = '';
        loadingField.value = '';
    }
}

// Attach listeners to all related fields after DOM is ready
document.addEventListener("DOMContentLoaded", function () {
    const fields = [
        "propertyType",
        "final_area_square_feet",
        "final_construction_square_feet",
        "final_construction_rate"
    ];

    fields.forEach(id => {
        const el = document.getElementById(id);
        if (el) {
            el.addEventListener("input", updateInsurableValue);
            el.addEventListener("change", updateInsurableValue);
        }
    });

    // Re-run the logic every second to ensure live accuracy (optional fallback)
    setInterval(updateInsurableValue, 500);

    // Initial calculation
    updateInsurableValue();
});
</script>


        <tr>
  <td>LOADING - AUTO COMPUTED</td>
  <td>
    <input type="text" id="loading" name="loading" 
           value="<?= $fieldss['loading'] ?? '' ?>"readonly>
  </td>

  <td>LOADING - TO BE MANUALLY FEEDED</td>
  <td>
    <input type="text" id="loading1" name="loading1" 
           value="<?= $fieldss['loading1'] ?? '' ?>">
  </td>
</tr>
</table>
    

            <!-- Rental & Replacement Cost Information Section -->
            <table>
                <tr>
                    <th colspan="3">RENTAL & REPLACEMENT COST INFORMATION</th>
                </tr>
                <tr>
                    <td>GROSS MONTHLY RENTAL FOR SIMILAR PROPERTIES IN LOCALITY (Rs.)</td>
                    <td colspan="2"><input type="text"  id="gross_monthly_rental" name="gross_monthly_rental" value="<?= htmlspecialchars($fieldss['gross_monthly_rental'] ?? '') ?>"></td></tr>
                   <tr><td>GOVERNMENT GUIDELINE</td>
                    <td><input type="text"   id="guideline_rate" name="guideline_rate" value="<?= htmlspecialchars($fieldss['guideline_rate'] ?? '') ?>"Placeholder="GOVERNMENT GUIDELINE RATE"></td>
                    
                    <td><input type="text"  id="guideline_values" name="guideline_values"  Placeholder="GOVERNMENT GUIDELINE VALUE" value="<?= htmlspecialchars($fieldss['guideline_values'] ?? '') ?>"  readonly></td>

 

<script>
    function calculateGuidelineValue() {
        let plotSquareFeet = parseFloat(document.getElementById('final_plot_square_feet').value) || 1;
        let guidelineRate = parseFloat(document.getElementById('guideline_rate').value) || 1;
        let areaSquareFeet = parseFloat(document.getElementById('final_area_square_feet').value) || 1;

        // Perform the multiplication 
        let guidelineValue = plotSquareFeet * guidelineRate * areaSquareFeet;

        // Display the result in the input field
        document.getElementById('guideline_values').value = guidelineValue.toFixed(2);
    }

    // Add event listeners to input fields
    document.getElementById('final_plot_square_feet').addEventListener('input', calculateGuidelineValue);
    document.getElementById('guideline_rate').addEventListener('input', calculateGuidelineValue);
    document.getElementById('final_area_square_feet').addEventListener('input', calculateGuidelineValue);
</script>
                </tr>

                    <tr><td>REPLACEMENT COST (Rs.)</td>
                    <td colspan="2"><input type="text" id="replacement_cost" name="replacement_cost" value="<?= htmlspecialchars($fieldss['replacement_cost'] ?? '') ?>"></td>
                </tr>
            </table>


        <div class="submit-button">
                <button type="submit"  name="action" value="save">Save</button>
           
            </div>
           
    </form>
  </form>
<script>

    
document.addEventListener('DOMContentLoaded', () => {
    const form = document.getElementById('autosave-form');

    if (!form) return;

    function gatherFormData(form) {
        const formData = new FormData(form);
        const data = {};
        formData.forEach((value, key) => {
            data[key] = value;
        });
        return data;
    }

    function autoSaveSession() {
        const data = gatherFormData(form);

        fetch('autosave.php', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
                page: 'area_valuation',
                data: data
            })
        });
    }

    form.addEventListener('input', autoSaveSession);
});



    document.addEventListener("DOMContentLoaded", function () {
    let tabs = document.querySelectorAll(".tab-links .tab");
    let slider = document.querySelector(".tab-links .slider");

    function moveSlider(activeTab) {
        slider.style.width = activeTab.offsetWidth + "px";
        slider.style.left = activeTab.offsetLeft + "px";
    }

    tabs.forEach(tab => {
        tab.addEventListener("click", function () {
            tabs.forEach(t => t.classList.remove("active"));
            this.classList.add("active");
            moveSlider(this);
        });

        // Initialize position on load for the active tab
        if (tab.classList.contains("active")) {
            moveSlider(tab);
        }
    });
});

    document.addEventListener("DOMContentLoaded", function () {
    let tabs = document.querySelectorAll(".tab-links .tab");
    let slider = document.querySelector(".tab-links .slider");

    function moveSlider(activeTab) {
        slider.style.width = activeTab.offsetWidth + "px";
        slider.style.left = activeTab.offsetLeft + "px";
    }

    tabs.forEach(tab => {
        tab.addEventListener("click", function () {
            tabs.forEach(t => t.classList.remove("active"));
            this.classList.add("active");
            moveSlider(this);
        });

        // Initialize position on load for the active tab
        if (tab.classList.contains("active")) {
            moveSlider(tab);
        }
    });
});

   document.getElementById("toggleSidebar").addEventListener("click", function() {
    var sidebar = document.getElementById("sidebar");
    var toggleButton = document.getElementById("toggleSidebar");
    
    sidebar.classList.toggle("active");
    
    // Toggle button state
    toggleButton.classList.toggle("active");
});


var modal = document.getElementById("myModal");

// Get the <span> element that closes the modal
var span = document.getElementsByClassName("close")[0];

// Function to show the modal with custom text
function showPopup(text) {
    document.getElementById("modalText").innerText = text;
    modal.style.display = "block";
}

// When the user clicks on <span> (x), close the modal
span.onclick = function() {
    modal.style.display = "none";
}

// When the user clicks anywhere outside of the modal, close it
window.onclick = function(event) {
    if (event.target == modal) {
        modal.style.display = "none";
    }
}

function openGoogleMaps(location) {
            const baseUrl = "https://www.google.com/maps/search/?api=1&query=";
            window.open(baseUrl + encodeURIComponent(location), '_blank');
        }
function triggerFileInput2() {
            document.getElementById("imageInput").click();
        }

        document.getElementById("imageInput").addEventListener("change", function (event) {
            const files = event.target.files;
            const previewContainer = document.getElementById("imagePreviewContainer");

            // Clear previous previews
            previewContainer.innerHTML = "";

            // Display previews for each selected image
            Array.from(files).forEach((file) => {
                if (file.type.startsWith("image/")) {
                    const reader = new FileReader();
                    reader.onload = function (e) {
                        const img = document.createElement("img");
                        img.src = e.target.result;
                        previewContainer.appendChild(img);
                    };
                    reader.readAsDataURL(file);
                }
            });
        });
function triggerFileInput1() {
            document.getElementById("pdfInput").click();
        }

        // Handle file selection
        document.getElementById("pdfInput").addEventListener("change", function (event) {
            const file = event.target.files[0];
            if (file && file.type === "application/pdf") {
                // Create a FileReader instance
                const reader = new FileReader();

                // When the file is read successfully, open it in a new tab
                reader.onload = function (e) {
                    const pdfUrl = e.target.result;

                    // Try to open the PDF in a new tab using embed
                    const newTab = window.open();
                    if (newTab) {
                        newTab.document.write('<html><body><embed src="' + pdfUrl + '" type="application/pdf" width="100%" height="100%"></body></html>');
                        newTab.document.close();

                        // Fallback if the PDF does not load correctly
                        setTimeout(function() {
                            if (newTab.document.body.innerHTML === "") {
                                // Use PDF.js as a fallback to display the PDF
                                newTab.document.body.innerHTML = '<div id="pdf-container" style="width: 100%; height: 100%;"></div>';
                                const loadingTask = pdfjsLib.getDocument(pdfUrl);
                                loadingTask.promise.then(function(pdf) {
                                    pdf.getPage(1).then(function(page) {
                                        const scale = 1.5;
                                        const viewport = page.getViewport({ scale: scale });
                                        const canvas = document.createElement('canvas');
                                        const ctx = canvas.getContext('2d');
                                        canvas.height = viewport.height;
                                        canvas.width = viewport.width;
                                        document.getElementById('pdf-container').appendChild(canvas);

                                        // Render PDF page
                                        page.render({
                                            canvasContext: ctx,
                                            viewport: viewport
                                        });
                                    });
                                });
                            }
                        }, 1000); // Check if the embed failed after 1 second
                    }
                };

                // Read the file as a data URL
                reader.readAsDataURL(file);
            } else {
                alert("Please select a valid PDF file.");
            }
        });
</script>
</body>
</html> 
