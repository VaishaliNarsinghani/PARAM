<?php include('auth.php'); ?>
<?php include 'watermark.html'; ?><?php
ini_set('display_errors', 1);
error_reporting(E_ALL);
// Increase PHP execution time and memory limit
ini_set('max_execution_time', 3000); // 300 seconds = 5 minutes
ini_set('memory_limit', '1024M'); // Increase memory limit to 512MB

// Start session


$servername = "localhost";
$username = "root";
$password = "";
$dbname = "project_db";

// Create DB connection
$conn = new mysqli($servername, $username, $password, $dbname);
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

if (!isset($_SESSION['reference_id'])) {
    die("Reference ID not found in session.");
}
$reference_id = $_SESSION['reference_id'];

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['download_images'])) {

    // Get customer name
    $stmt_name = $conn->prepare("SELECT customerName FROM mis WHERE reference_id = ?");
    $stmt_name->bind_param("s", $reference_id);
    $stmt_name->execute();
    $result_name = $stmt_name->get_result();
    $customerName = "customer";
    if ($row = $result_name->fetch_assoc()) {
        $customerName = preg_replace('/[^a-zA-Z0-9]/', '', $row['customerName']);
    }
    $stmt_name->close();

    // Fetch image BLOBs
    $stmt = $conn->prepare("SELECT image1, image2, image3, image4, image5, image6, image7, image8, image9, image10, image11, image12,image13, image14, image15, image16, image17, image18, image19, image20 FROM final_uploaded_images WHERE reference_id = ?");
    $stmt->bind_param("s", $reference_id);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows > 0 && ($row = $result->fetch_assoc())) {
        $tempDir = sys_get_temp_dir() . DIRECTORY_SEPARATOR . uniqid('images_', true);
        mkdir($tempDir);

        $imageFiles = [];
        for ($i = 1; $i <= 12; $i++) {
            if (!empty($row["image$i"])) {
                $filename = $tempDir . DIRECTORY_SEPARATOR . "image{$i}.jpg";
                file_put_contents($filename, $row["image$i"]);
                $imageFiles[] = $filename;
            }
        }

        if (empty($imageFiles)) {
            die("No images to download.");
        }

        // Create ZIP
        $zipFileName = "images_" . preg_replace('/[^a-zA-Z0-9]/', '_', $reference_id) . "_{$customerName}.zip";
        $zipPath = $tempDir . DIRECTORY_SEPARATOR . $zipFileName;

        $zip = new ZipArchive();
        if ($zip->open($zipPath, ZipArchive::CREATE) !== TRUE) {
            die("Failed to create ZIP file.");
        }

        foreach ($imageFiles as $file) {
            $zip->addFile($file, basename($file));
        }
        $zip->close();

        // Send ZIP to browser
        header('Content-Type: application/zip');
        header('Content-Disposition: attachment; filename="' . basename($zipFileName) . '"');
        header('Content-Length: ' . filesize($zipPath));
        flush();
        readfile($zipPath);

        // Cleanup
        foreach ($imageFiles as $file) {
            unlink($file);
        }
        unlink($zipPath);
        rmdir($tempDir);
        exit;
    } else {
        echo "<p style='color:red;'>No image data found for this reference ID.</p>";
    }
}

$page = isset($_GET['page']) ? $_GET['page'] : 1;
$limit = 50;
$offset = ($page - 1) * $limit;
$sql_property = "SELECT * FROM mis WHERE reference_id = ? LIMIT $limit OFFSET $offset";
$stmt_property = $conn->prepare($sql_property);
$stmt_property->bind_param("s", $reference_id);
$stmt_property->execute();
$result_property = $stmt_property->get_result();
$data1 = $result_property->fetch_assoc();




// Fetch data from property_details table
$sql_property = "SELECT * FROM property_details WHERE reference_id = ?";
$stmt_property = $conn->prepare($sql_property);
$stmt_property->bind_param("s", $reference_id);
$stmt_property->execute();
$result_property = $stmt_property->get_result();
$data2= $result_property->fetch_assoc();




// Fetch data from area_valuation table
$sql_area = "SELECT * FROM address_details WHERE reference_id = ?";
$stmt_area = $conn->prepare($sql_area); 
$stmt_area->bind_param("s", $reference_id);
$stmt_area->execute();
$result_area = $stmt_area->get_result();
$data3 = $result_area->fetch_assoc();





// Fetch data from area_valuation table
$sql_area = "SELECT * FROM critical_parameters WHERE reference_id = ?";
$stmt_area = $conn->prepare($sql_area); 
$stmt_area->bind_param("s", $reference_id);
$stmt_area->execute();
$result_area = $stmt_area->get_result();
$data4 = $result_area->fetch_assoc();

 
// Fetch data from area_valuation table
$sql_area = "SELECT * FROM surroundings_details WHERE reference_id = ?";
$stmt_area = $conn->prepare($sql_area); 
$stmt_area->bind_param("s", $reference_id);
$stmt_area->execute();
$result_area = $stmt_area->get_result();
$data5 = $result_area->fetch_assoc();
$stmt_area->close();
 
// Fetch data from area_valuation table
$sql_area = "SELECT * FROM area_valuation WHERE reference_id = ?";
$stmt_area = $conn->prepare($sql_area); 
$stmt_area->bind_param("s", $reference_id);
$stmt_area->execute();
$result_area = $stmt_area->get_result();
$data6 = $result_area->fetch_assoc();
$stmt_area->close();
 



// Fetch data from area_valuation table
$sql_area = "SELECT * FROM floor_details WHERE reference_id = ?";
$stmt_area = $conn->prepare($sql_area); 
$stmt_area->bind_param("s", $reference_id);
$stmt_area->execute();
$result_area = $stmt_area->get_result();
$data8= $result_area->fetch_assoc();
$stmt_area->close();
 


// Fetch data from area_valuation table
$sql_area = "SELECT * FROM technical_details WHERE reference_id = ?";
$stmt_area = $conn->prepare($sql_area); 
$stmt_area->bind_param("s", $reference_id);
$stmt_area->execute();
$result_area = $stmt_area->get_result();
$data9 = $result_area->fetch_assoc();
$stmt_area->close();
 
// Fetch data from area_valuation table
$sql_area = "SELECT * FROM remarks_table WHERE reference_id = ?";
$stmt_area = $conn->prepare($sql_area); 
$stmt_area->bind_param("s", $reference_id);
$stmt_area->execute();
$result_area = $stmt_area->get_result();
$data10 = $result_area->fetch_assoc();
$stmt_area->close();


// Step 1: Fetch the engineer_id from the mis table
$sql_mis = "SELECT engineer_id FROM mis WHERE reference_id = ?";
$stmt_mis = $conn->prepare($sql_mis);
$stmt_mis->bind_param("s", $reference_id);
$stmt_mis->execute();
$result_mis = $stmt_mis->get_result();
$row_mis = $result_mis->fetch_assoc();
$stmt_mis->close(); 

if ($row_mis) {
    $engineer_id = $row_mis['engineer_id'];

    // Step 2: Fetch the engineer's name from engineer_login table
    $sql_engineer = "SELECT name FROM engineer_login WHERE engineer_id = ?";
    $stmt_engineer = $conn->prepare($sql_engineer);
    $stmt_engineer->bind_param("s", $engineer_id);
    $stmt_engineer->execute();
    $result_engineer = $stmt_engineer->get_result();
    $row_engineer = $result_engineer->fetch_assoc();
    $stmt_engineer->close();

    if ($row_engineer) {
        $engineer_name = $row_engineer['name'];
         //echo "Engineer Name: " . $engineer_name;
    } else {
        echo "Engineer not found.";
    }
} else {
    echo "No engineer assigned for this reference_id.";
}



// Step 1: Fetch the engineer_id from the mis table
$sql_mis = "SELECT report_id FROM mis WHERE reference_id = ?";
$stmt_mis = $conn->prepare($sql_mis);
$stmt_mis->bind_param("s", $reference_id);
$stmt_mis->execute();
$result_mis = $stmt_mis->get_result();
$row_mis = $result_mis->fetch_assoc();
$stmt_mis->close(); 

if ($row_mis) {
    $report_id = $row_mis['report_id'];

    // Step 2: Fetch the engineer's name from engineer_login table
    $sql_engineer = "SELECT name FROM report_login WHERE report_id = ?";
    $stmt_engineer = $conn->prepare($sql_engineer);
    $stmt_engineer->bind_param("s", $report_id);
    $stmt_engineer->execute();
    $result_engineer = $stmt_engineer->get_result();
    $row_engineer = $result_engineer->fetch_assoc();
    $stmt_engineer->close();

    if ($row_engineer) {
        $report_name = $row_engineer['name'];
         //echo "Engineer Name: " . $report_name;
    } else {
        echo "Engineer not found.";
    }
} else {
    echo "No engineer assigned for this reference_id.";
}


// Step 1: Fetch the engineer_id from the mis table
$sql_mis = "SELECT report_drafter_to_technical FROM mis WHERE reference_id = ?";
$stmt_mis = $conn->prepare($sql_mis);
$stmt_mis->bind_param("s", $reference_id);
$stmt_mis->execute();
$result_mis = $stmt_mis->get_result();
$row_mis = $result_mis->fetch_assoc();
$stmt_mis->close(); 

if ($row_mis) {
    $report_drafter_to_technical = $row_mis['report_drafter_to_technical'];

    // Step 2: Fetch the engineer's name from engineer_login table
    $sql_engineer = "SELECT name FROM technical_login WHERE technical_manager_id = ?";
    $stmt_engineer = $conn->prepare($sql_engineer);
    $stmt_engineer->bind_param("s", $report_drafter_to_technical);
    $stmt_engineer->execute();
    $result_engineer = $stmt_engineer->get_result();
    $row_engineer = $result_engineer->fetch_assoc();
    $stmt_engineer->close();

    if ($row_engineer) {
        $technical_name = $row_engineer['name'];
        //echo "Engineer Name: " . $technical_name;
    } else {
        echo "Engineer not found.";
    }
} else {
    echo "No engineer assigned for this reference_id.";
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Technical Report</title>
     <link rel="shortcut icon" href="favicon.png" type="image/x-icon">
    <style>
        body {
            font-family: Arial, sans-serif;
        }
        .header-container {
            display: flex;
            align-items: center;
        }
        .logo {
            flex: 0 0 auto;
        }
        .logo img {
            width: 150px;
        }
        .header-text {
            flex: 1;
            text-align: center;
        }
        .header {
            font-size: 34px;
            font-weight: bold;
            color: red;
        }
        .sub-header {
            font-size: 18px;
            font-weight: bold;
        }
        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
        }
        th, td {
            border: 1px solid black;
            padding: 8px;
            text-align: left;
        }
        th {
            background-color: #f2f2f2;
        }
        table {
            width: 100%;
            border-collapse: collapse;
        }
        th, td {
            border: 1px solid black;
            padding: 8px;
            text-align: left;
        }
        th {
            background-color: #f2f2f2;
        }
        input {
            width: 100%;
            padding: 5px;
            border: 1px solid #ccc;
        }

        table {
            width: 100%;
            border-collapse: collapse;
        }
        th, td {
            border: 1px solid black;
            padding: 8px;
            text-align: left;
        }
        th {
            background-color: #f2f2f2;
        }
        input  {
            width: 100%;
            padding: 5px;
            border: 1px solid #ccc;
            box-sizing: border-box;
        }

        table {
            width: 100%;
            border-collapse: collapse;
        }
        th, td {
            border: 1px solid black;
            padding: 8px;
            text-align: center;
        }
        th {
            background-color: #d3d3d3;
        }
        input {
            width: 100%;
            border: none;
            padding: 5px;
        }


        table {
            width: 100%;
            border-collapse: collapse;
        }
        th, td {
            border: 1px solid black;
            padding: 8px;         
            text-align: center;
        }
        input {
            width: 100%;
            border: none;
            padding: 5px;
        }
         
        .container {
    max-width: 1200px;
    margin: 20px auto;
    padding: 20px;
    background-color: white;
    box-shadow: 0px 0px 10px rgba(0, 0, 0, 0.1);
    border-radius: 8px;
}

.title {
    text-align: center;
    font-size: 24px;
    font-weight: bold;
    margin-bottom: 20px;
}
.grid-container {
    display: grid;
    grid-template-columns: repeat(4, 1fr);
    gap: 15px;
}

.grid-item {
    position: relative;
    border-radius: 8px;
    overflow: hidden;
    box-shadow: 0px 4px 6px rgba(0, 0, 0, 0.1);
}

.grid-item img {
    width: 100%;
    height: 200px;
    object-fit: cover;
    transition: transform 0.3s ease;
}
.grid-item:hover img {
    transform: scale(1.05);
}

.overlay {
    position: absolute;
    bottom: 0;
    left: 0;
    background: rgba(0, 0, 0, 0.6);
    color: white;
    width: 100%;
    padding: 8px;
    font-size: 14px;
    text-align: center;
}
h3
{
    background-color: #716e6e;
}


  
   
/* Force a stable 4-column grid that wkhtmltopdf respects */
.image-gallery { width: 100%; }
.image-grid { width: 100%; border-collapse: collapse; table-layout: fixed; }
.image-grid tr { page-break-inside: avoid; }
.image-grid td { width: 25%; padding: 6px; vertical-align: top; }

.image-grid .img-wrap { display: block; }
.image-grid img { display: block; width: 100%; height: auto; }
.image-grid .caption { font-size: 12px; text-align: center; margin-top: 4px; }

/* If you had a flex layout before, neutralize it */
.image-gallery { display: block !important; }


.google-map-container {
    max-width: 90%;           /* Keep container within page width */
    margin: 20px auto;        /* Center it with spacing */
    border: 2px solid #ccc;   /* Light gray border */
    padding: 10px;
    box-shadow: 0 0 10px rgba(0, 0, 0, 0.1); /* Optional: subtle shadow */
    background-color: #f9f9f9; /* Optional: light background */
    border-radius: 8px;       /* Rounded corners */
    text-align: center;       /* Center image and caption */
}

.google-map-container img {
    max-width: 100%;          /* Scale image to container */
    height: auto;             /* Keep image aspect ratio */
    display: inline-block;
    border: 1px solid #999;   /* Border around the image itself */
    border-radius: 4px;
} 
    /* Print-specific rules */
    @media print {
      .no-print {
        display: none !important;
      }

      body {
        margin: 0;
      }
 
    }
  button{
    padding:8px;
    margin-left:45%;
    background-color:#808485;
    color:white;
    font-weight:700;
    font-style:italic;
  }
  button:hover{
    background-color:rgba(216,216,216,255);
    color:white;
  }
</style>
</head>
<body>
    <div class="container">
    <div class="header-container">
        <div class="logo">
            <img src="images/logo.png" alt="Company Logo">
        </div>
        <div class="header-text">
            <div class="header">MAGPIE ENGINEERING PVT. LTD.</div>
            <div class="sub-header">Valuer Designer Architects<br>Office no. 201, 2nd floor, Gravity Mall, Mechanic nagar, warehouse road, near vijay nagar, Indore, Madhya Pradesh- 452011</div>
        </div>
    </div>
    <div>
         <table>
        <tr>
            <th colspan="4"> REPORT FORMAT FOR HERO FINCORP</th>

        </tr>
        <tr>
            <td>Name of Customer</td>
            <td> <span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data1['customerName'] ?? '') ?>
    </span></td>
           
            <td>Date of Report</td>
            <td><input  type="text" value="<?=  $data1['report_assigned_at']  ?? '' ?>"readonly style="width:100%;"></td>
        </tr>
        <tr>
            <td>Name of Property Owner</td>
            <td><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data9['owner_name'] ?? '') ?>
    </span></td>
             
            <td>Product Type</td>
            <td><input  type="text" value="<?= $data1['caseType'] ?? '' ?>"readonly style="width:100%;"></td>
        </tr>
        <tr>
            <td>Relationship of Property Owner with Customer</td>
            <td><input  type="text" value="<?= $data10['NA'] ?? '' ?>"readonly style="width:100%;"></td>
            <td>Unit Type (Flat/Land/Duplex/Row House/Bungalow/Industrial/Commercial)</td>
            <td><input  type="text" value="<?= $data2['property_unit_type']  ?? '' ?>"readonly style="width:100%;"></td>
        </tr>
        <tr>
            <td>Complete Property Address</td>
            <td colspan="3"><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data3['address_per_site'] ?? '') ?>
    </span></td>
        </tr>
        <tr>
            <td>Pin Code</td>
            <td colspan="3"><input  type="text" value="<?=  $data3['pin_code']  ?? '' ?>"readonly style="width:100%;"></td>
        </tr>
        <tr>
            <td>Serial No</td>
            <td colspan="3"><input  type="text" value="<?= $data10['NA'] ?? '' ?>"readonly style="width:100%;"></td>
        </tr>
        <tr>
            <td>Nearby Landmark</td>
            <td colspan="3"><input  type="text" value="<?= $data3['landmark_1'] ?? '' ?>  <?= $data3['landmark_2'] ?? '' ?>"readonly style="width:100%;"></td>
        </tr>
        <tr>
            <td>Legal Address</td>
            <td colspan="3"><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data3['address_per_document'] ?? '') ?>
</span></td>
        </tr>
        <tr>
            <td>In demolition list of Municipal Authority?</td>
            <td><input  type="text" value="<?= $data10['NA'] ?? '' ?>"readonly style="width:100%;"></td>
            <td>Level of Risk of Demolition</td>
            <td><input  type="text" value="<?= $data9['demolition_risk_1'] ?? '' ?>"readonly style="width:100%;"></td>
        </tr>
        <tr>
            <td>Distance from City Centre (in Kms)</td>
            <td colspan="3"><input  type="text" value="<?= $data3['nearest_bus_stop_distance'] ?? '' ?>"readonly style="width:100%;"></td>
        </tr>
       </table>
       <table>
        <tr>
            <td>Direction</td>
            <td>As per Documents</td>
            <td>As per Site</td>
        </tr>
        <tr>
            <td>East</td>
            <td><input  type="text" value="<?= $data3['direction_as_per_document_east'] ?? '' ?>"readonly style="width:100%;"></td>
            <td><input  type="text" value="<?= $data3['direction_as_per_site_east'] ?? '' ?>"readonly style="width:100%;"></td>
        </tr>
        <tr>
            <td>West</td>
            <td><input  type="text" value="<?= $data3['direction_as_per_document_west'] ?? '' ?>"readonly style="width:100%;"></td>
            <td><input  type="text" value="<?= $data3['direction_as_per_site_west'] ?? '' ?>"readonly style="width:100%;"></td>
        </tr>
        <tr>
            <td>North</td>
            <td><input  type="text" value="<?= $data3['direction_as_per_document_north'] ?? '' ?>"readonly style="width:100%;"></td>
            <td><input  type="text" value="<?= $data3['direction_as_per_site_north'] ?? '' ?>"readonly style="width:100%;"></td>
        </tr>
        <tr>
            <td>South</td>
            <td><input  type="text" value="<?= $data3['direction_as_per_document_south'] ?? '' ?>"readonly style="width:100%;"></td>
            <td><input  type="text" value="<?= $data3['direction_as_per_site_south'] ?? '' ?>"readonly style="width:100%;"></td>
        </tr>
      </table>

      <table style="margin-top:-2px;">
        <tr>
            <td>Property Area as per Site Measurement (in sqft)</td>
            <td><input  type="text" value="<?= $data6['actual_plot_square_feet'] ?? '' ?>"readonly></td>
            <td>Property Area as per Title Documents (in sqft)</td>
            <td><input  type="text" value="<?= $data6['plot_square_feet'] ?? '' ?>"readonly></td>
        </tr>
        <tr>
            <td>Property Type as per Actual Site</td>
            <td><input  type="text" value="<?= $data2['property_unit_type'] ?? '' ?>"readonly></td>
            <td>Property Type as per Title Documents</td>
            <td><input  type="text" value="<?= $data10['NA'] ?? '' ?>"readonly></td>
        </tr>
        <tr>
            <td>Property Location</td>
            <td colspan="3"><input  type="text" value="<?= $data10['NA'] ?? '' ?>"readonly></td>
        </tr>
        <tr>
            <td>Land Holding Type</td>
     <td colspan="3"><input  type="text" value="<?= $data2['property_leasehold_freehold'] ?? '' ?>"readonly></td>
        </tr>
        <tr>
            <td>Approved Land Usage</td>
            <td colspan="3"><input  type="text" value="<?= $data4['approved_property_usage'] ?? '' ?>"readonly></td>
        </tr>
        <tr>
            <td>Actual Land Usage</td>
            <td colspan="3"><input  type="text" value="<?= $data4['current_property_usage'] ?? '' ?>"readonly></td>
        </tr>
        <tr>
            <td>Property Demarcated at Site</td>
            <td colspan="3"><input  type="text" value="<?= $data2['demarcated_at_site'] ?? '' ?>"readonly></td>
        </tr>
        <tr>
            <td>Class of Locality</td>
             <td colspan="3"><input  type="text" value="<?= $data2['class_of_locality'] ?? '' ?>"readonly></td>
        </tr>
        <tr>
            <td>No of Floors</td>
            <td colspan="3"><input  type="text" value="<?= $data10['NA'] ?? '' ?>"readonly></td>
        </tr>
        <tr>
            <td>No of units on each Floor</td>
            <td colspan="3"><input  type="text" value="<?= $data8['number_of_units_each_floor'] ?? '' ?>"readonly></td>
        </tr>
        <tr>
            <td>Permissible No of Floors</td>
            <td colspan="3"><input  type="text" value="<?= $data10['NA'] ?? '' ?>"readonly></td>
        </tr>
        <tr>
            <td>Construction Type</td>
            <td colspan="3"><input  type="text" value="<?= $data10['NA'] ?? '' ?>"readonly></td>
        </tr>
    <tr>
        <td>Interior (Good/Average/Poor)</td>
         <td colspan="3"><input  type="text" value="Average"readonly></td>
    </tr>
    <tr>
        <td>Exterior (Good/Average/Poor)</td>
       <td colspan="3"><input  type="text" value="Average"readonly></td>
    </tr>
    <tr>
        <td>Property Neighborhood (Developed/Underdeveloped/Undeveloped/Negative)</td>
       <td colspan="3"><input  type="text" value="<?= $data10['NA'] ?? '' ?>"readonly></td>
    </tr>
    <tr>
        <td>Marketability (Good/Average/Poor)</td>
         <td colspan="3"><input  type="text" value="<?= $data9['markebility'] ?? '' ?>"readonly></td>
    </tr>
    <tr>
        <td>Amenities (if any)</td>
   <td colspan="3"><input  type="text" value="<?= $data10['NA'] ?? '' ?>"readonly></td> </tr>
    <tr>
        <td>Basis of Property Identification</td>
   <td colspan="3"><input  type="text" value="<?= $data10['NA'] ?? '' ?>"readonly></td>    </tr>
    <tr>
        <td>Basis of Property Usage Permission Confirmation</td>
   <td colspan="3"><input  type="text" value="<?= $data10['NA'] ?? '' ?>"readonly></td>    </tr>
    <tr>
        <td>Occupancy Status (Occupied/Vacant)</td>
         <td colspan="3"><input  type="text" value="<?= $data2['occupancy_status'] ?? '' ?>"readonly></td>
    </tr>
    <tr>
        <td>Occupied By (Self/Tenant)</td>
    <td colspan="3"><input  type="text" value="<?= $data10['NA'] ?? '' ?>"readonly></td>
    </tr>
    <tr>
        <td>Occupied Since</td>
   <td colspan="3"><input  type="text" value="<?= $data10['NA'] ?? '' ?>"readonly></td>    </tr>
    <tr>
        <td>Age of Property (in years)</td>
   <td colspan="3"><input  type="text" value="<?= $data2['age_of_property'] ?? '' ?>"readonly></td>    </tr>
    <tr>
        <td>Residual Age of Property (in Years)</td>
   <td colspan="3"><input  type="text" value="<?= $data2['residual_age_of_property'] ?? '' ?>"readonly></td>    </tr>
</table>
<table style="margin-top:-1px;">
    <tr>
        <td></td>
        <td>Actual</td>
        <td>Documents</td>
        <td>As Per Approved Plans</td>
    </tr>
    <tr>
        <td>Land Area (in sqft)</td>
        <td><input  type="text" value="<?= $data6['actual_plot_square_feet'] ?? '' ?>"readonly></td>
        <td><input  type="text" value="<?= $data6['plot_square_feet'] ?? '' ?>"readonly></td>
        <td><input  type="text" value="<?= $data10['NA'] ?? '' ?>"readonly></td>
    </tr>
    <tr>
        <td>Carpet Area (in sqft)</td>
        <td><input  type="text" value="<?= $data6['actual_carpet_square_feet'] ?? '' ?>"readonly></td>
        <td><input  type="text" value="<?= $data6['carpet_square_feet'] ?? '' ?>"readonly></td>
        <td><input  type="text" value="<?= $data10['NA'] ?? '' ?>"readonly></td>
    </tr>
    <tr>
        <td>B/up RCC</td>
        <td><input  type="text" value="<?= $data6['actual_construction_square_feet'] ?? '' ?>"readonly></td>
        <td><input  type="text" value="<?= $data6['construction_square_feet'] ?? '' ?>"readonly></td>
        <td><input  type="text" value="<?= $data10['NA'] ?? '' ?>"readonly></td>
    </tr>
    <tr>
        <td>Super Built Up Area (in sqft)</td>
        <td><input  type="text" value="<?= $data6['actual_saleable_square_feet'] ?? '' ?>"readonly></td>
        <td><input  type="text" value="<?= $data6['saleable_square_feet'] ?? '' ?>"readonly></td>
        <td><input  type="text" value="<?= $data10['NA'] ?? '' ?>"readonly></td>
    </tr>
    <tr>
        <td>Permissible FAR</td>
        <td><input  type="text" value="<?= $data10['NA'] ?? '' ?>"readonly></td>
        <td><input  type="text" value="<?= $data10['NA'] ?? '' ?>"readonly></td>
        <td><input  type="text" value="<?= $data10['NA'] ?? '' ?>"readonly></td>
    </tr>
</table>
<table style="margin-top:-1px;">
    <tr>
        <th colspan="4">Valuation</th>
    </tr>
    <tr>
        <td colspan="2">Area Details</td>
        <td>Rate (Rs/sqft)</td>
        <td>Value</td>
    </tr>
    <tr>
        <td>Land Area</td>
        <td><input  type="text" value="<?= $data6['final_plot_square_feet'] ?? '' ?>"readonly></td>
        <td><input  type="text" value="<?= $data6['final_plot_rate'] ?? '' ?>"readonly></td>
        <td><input  type="text" value="<?= $data10['NA'] ?? '' ?>"readonly></td>
    </tr>
    <tr>
        <td>Carpet Area</td>
        <td><input  type="text" value="<?= $data10['NA'] ?? '' ?>"readonly></td>
        <td><input  type="text" value="<?= $data10['NA'] ?? '' ?>"readonly></td>
        <td><input  type="text" value="<?= $data10['NA'] ?? '' ?>"readonly></td>
    </tr>
    <tr>
        <td>Super Built Up Area</td>
        <td><input  type="text" value="<?= $data6['final_area_square_feet'] ?? '' ?>"readonly></td>
        <td><input  type="text" value="<?= $data6['final_area_rate'] ?? '' ?>"readonly></td>
        <td><input  type="text" value="<?= $data10['NA'] ?? '' ?>"readonly></td>
    </tr>
    <tr>
        <td>Built Up Area</td>
        <td><input  type="text" value="<?= $data6['final_construction_square_feet'] ?? '' ?>"readonly></td>
        <td><input  type="text" value="<?= $data6['final_construction_rate'] ?? '' ?>"readonly></td>
        <td><input  type="text" value="<?= $data10['NA'] ?? '' ?>"readonly></td>
    </tr>
    <tr>
        <td>Teen Shed</td>
        <td><input  type="text" value="<?= $data10['NA'] ?? '' ?>"readonly></td>
        <td><input  type="text" value="<?= $data10['NA'] ?? '' ?>"readonly></td>
        <td><input  type="text" value="<?= $data10['NA'] ?? '' ?>"readonly></td>
    </tr>
    <tr>
        <td>RCC</td>
        <td><input  type="text" value="<?= $data10['NA'] ?? '' ?>"readonly></td>
        <td><input  type="text" value="<?= $data10['NA'] ?? '' ?>"readonly></td>
        <td><input  type="text" value="<?= $data10['NA'] ?? '' ?>"readonly></td>
    </tr>
    <tr>
        <td>Extra Amenities</td>
        <td><input  type="text" value="<?= $data10['NA'] ?? '' ?>"readonly></td>
        <td><input  type="text" value="<?= $data10['NA'] ?? '' ?>"readonly></td>
        <td><input  type="text" value="<?= $data6['amenities_total'] ?? '' ?>"readonly></td>
    </tr>
    <tr>
        <td>Total Value</td>
        <td></td>
        <td></td>
        <td><input  type="text" value="<?= $data6['total_finally_area_valuation'] ?? '' ?>"readonly></td>
    </tr>
    <tr>
        <td>Distressed Value @75%</td>
        <td></td>
        <td></td>
        <td><input  type="text" value="<?= $data6['distress_value_percent'] ?? '' ?>"readonly></td>
    </tr>
    <tr>
        <td>Guide Line Value In Sqmt.</td>
        <td colspan="3"><input  type="text" value="<?= $data6['guideline_values'] ?? '' ?>"readonly></td>
    </tr>
    <tr>
        <td>Deviations, if any (Vertical/Horizontal)</td>
        <td colspan="3"><input  type="text" value="<?= $data10['NA'] ?? '' ?>"readonly></td>
    </tr>
    <tr>
        <td>% Deviation with complete details</td>
        <td colspan="3"><input  type="text" value="<?= $data10['NA'] ?? '' ?>"readonly></td>
    </tr>
    <tr>
        <td>Violations (If any)</td>
        <td colspan="3"><input  type="text" value="<?= $data10['NA'] ?? '' ?>"readonly></td>
    </tr>
</table>
<table class="remarks-table" style="margin-top:-1px;">
    <tbody>
        <tr>
            <td>Technical Remarks</td>
          <td colspan="6">
        <span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data10['remarks'] ?? '') ?>
    </span>
    </td>
        </tr>
    </tbody>
</table>
<table style="margin-top:-1px;">
    <tr>
        <td>Technical Progress (in %)</td>
        <td><input  type="text" value="<?= $data10['NA'] ?? '' ?>"readonly></td>
    </tr>
    <tr>
        <td>Floor wise Details of Usage of Property</td>
        <td><input  type="text" value="<?= $data10['NA'] ?? '' ?>"readonly></td>
    </tr>
    <tr>
        <td>Access Road available to the property (Yes/No)</td>
        <td><input  type="text" value="<?= $data10['NA'] ?? '' ?>"readonly></td>
    </tr>
    <tr>
        <td>Width of Access Road & Type (Concrete/Tar/Brick road/Kutcha)</td>
        <td><input  type="text" value="<?= $data10['NA'] ?? '' ?>"readonly></td>
    </tr>
    <tr>
        <td>Is High Tension Wire passing above the property (Yes/No)</td>
        <td><input  type="text" value="<?= $data10['NA'] ?? '' ?>"readonly></td>
    </tr>
    <tr>
        <td>Is it a Landlocked Property (Yes/No)</td>
        <td><input  type="text" value="<?= $data10['NA'] ?? '' ?>"readonly></td>
    </tr>
    <tr>
        <td>Person met at the property along with contact details</td>
        <td><input  type="text" value="<?= $data10['NA'] ?? '' ?>"readonly></td>
    </tr>
    <tr>
        <td>List of Documents shared for valuation</td>
        <td><input  type="text" value="<?= $data10['NA'] ?? '' ?>"readonly></td>
    </tr>
    <tr>
        <td>Date of Visit</td>
        <td><input  type="text" value="<?= $data10['NA'] ?? '' ?>"readonly></td>
    </tr>
    <tr>
        <td>Date Of Report</td>
        <td><input  type="text" value="<?= $data10['NA'] ?? '' ?>"readonly></td>
    </tr>
    <tr>
        <td>Property Visited by</td>
        <td><input  type="text" value="<?= $data10['NA'] ?? '' ?>"readonly></td>
    </tr>
    <tr>
        <td>Tech Report Entered by</td>
        <td><input  type="text" value="<?= $data10['NA'] ?? '' ?>"readonly></td>
    </tr>
</table>
     
<table class="remarks-table" style="margin-top:-1px;">
 
       <tr>  <th>  declaration</th></tr>
<tr>
            <td colspan="7"><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data10['declaration'] ?? '') ?>
    </span></td></td>
        </tr>
    </tbody>
</table>
<table>
<tr><th style="margin-bottom:-18px;">PHOTOGRAPH OF THE PROPERTY</tr></th></table>
<br>

    
<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

$servername = "localhost";
$username   = "root";
$password   = "";
$dbname     = "project_db";

$conn = new mysqli($servername, $username, $password, $dbname);
if ($conn->connect_error) {
    die("Connection failed: " . htmlspecialchars($conn->connect_error));
}

$reference_id = $_SESSION['reference_id'] ?? null;
$reference_id = $_GET['reference_id'] ?? $reference_id;

if ($reference_id) {

    // Map captions
    $captions = [
        'image1'  => 'EXTERNAL PHOTOS',
        'image2'  => 'Kitchen',
        'image3'  => 'Selfie',
        'image4'  => 'Electric Meter',
        'image6'  => 'Other 1',
        'image7'  => 'Other 2',
        'image8'  => 'Other 3',
        'image9'  => 'Other 4',
        'image10' => 'Other 5',
        'image11' => 'Other 6',
        'image12' => 'Other 7',
        'image13' => 'Other 8',
        'image14' => 'Other 9',
        'image15' => 'Other 10',
        'image16' => 'Other 11',
        'image17' => 'Other 12',
        'image18' => 'Other 13',
        'image19' => 'Other 14',
        'image20' => 'Other 15',
    ];

    // === Helper: EXIF-aware orientation detection ===
    function classify_orientation_after_exif(string $imageData): ?string {
        $size = @getimagesizefromstring($imageData);
        if (!$size || !isset($size[0], $size[1])) {
            return null;
        }
        $width  = (int)$size[0];
        $height = (int)$size[1];

        $mime = $size['mime'] ?? '';
        if ($mime === 'image/jpeg' && function_exists('exif_read_data')) {
            $tmp = @tempnam(sys_get_temp_dir(), 'exif_');
            if ($tmp !== false) {
                @file_put_contents($tmp, $imageData);
                $exif = @exif_read_data($tmp);
                @unlink($tmp);

                if (!empty($exif['Orientation'])) {
                    $orientation = (int)$exif['Orientation'];
                    if ($orientation === 6 || $orientation === 8) {
                        $t = $width; $width = $height; $height = $t;
                    }
                }
            }
        }
        return ($width >= $height) ? 'horizontal' : 'vertical';
    }

    // === Helper: Fix orientation physically with Imagick ===
    function fixImageOrientation($binaryData) {
        $img = new Imagick();
        $img->readImageBlob($binaryData);

        switch ($img->getImageOrientation()) {
            case Imagick::ORIENTATION_BOTTOMRIGHT:
                $img->rotateImage("#000", 180);
                break;
            case Imagick::ORIENTATION_RIGHTTOP:
                $img->rotateImage("#000", 90);
                break;
            case Imagick::ORIENTATION_LEFTBOTTOM:
                $img->rotateImage("#000", -90);
                break;
        }

        $img->setImageOrientation(Imagick::ORIENTATION_TOPLEFT);
        $fixed = $img->getImageBlob();
        $img->destroy();

        return $fixed;
    }

    $sql = "SELECT 
                image1, image2, image3, image4, 
                image6, image7, image8, image9, 
                image10, image11, image12, image13, image14, image15, image16, image17, image18, image19, image20
            FROM final_uploaded_images 
            WHERE reference_id = ?";

    $stmt = $conn->prepare($sql);
    if ($stmt === false) {
        die("Error preparing the SQL statement: " . htmlspecialchars($conn->error));
    }

    $stmt->bind_param("s", $reference_id);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result && $result->num_rows > 0) {
        $horizontal_images = [];
        $vertical_images   = [];

        while ($row = $result->fetch_assoc()) {
            foreach ($row as $key => $imageData) {
                if (!empty($imageData)) {

                    // Actually fix image before displaying
                    $fixedData = fixImageOrientation($imageData);

                    $orientation = classify_orientation_after_exif($fixedData) ?? 'horizontal';
                    $imgString   = base64_encode($fixedData);
                    $caption     = $captions[$key] ?? 'Image';

                    $item = [
                        'data'    => $imgString,
                        'caption' => $caption,
                        'alt'     => $key,
                    ];

                    if ($orientation === 'horizontal') {
                        $horizontal_images[] = $item;
                    } else {
                        $vertical_images[]   = $item;
                    }
                }
            }
        }

 
// Output as a stable 4-column table (works in wkhtmltopdf)
$all_images = array_merge($vertical_images, $horizontal_images);

echo '<table class="image-grid">';
$rows = array_chunk($all_images, 4);
foreach ($rows as $row) {
    echo '<tr>';
    foreach ($row as $img) {
        echo '<td>';
        echo '<div class="img-wrap">';
        echo '<img src="data:image/jpeg;base64,' . $img['data'] . '" alt="' . htmlspecialchars($img['alt']) . '">';
        echo '<div class="caption">' . htmlspecialchars($img['caption']) . '</div>';
        echo '</div>';
        echo '</td>';
    }
    // pad remaining cells to keep 4 columns
    $remaining = 4 - count($row);
    if ($remaining > 0) {
        echo str_repeat('<td></td>', $remaining);
    }
    echo '</tr>';
}
echo '</table>';

    } else {
        echo "<p style='text-align:center;'>No images found.</p>";
    }

    $stmt->close();
} else {
    echo "<p style='text-align:center;'>Reference ID is missing.</p>";
}
?>

    
      <table>
  </tr>
  <tr>

<div class="google-map-container">
<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "project_db";
$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$reference_id = $_SESSION['reference_id'] ?? null;
$reference_id = $_GET['reference_id'] ?? $reference_id;

if ($reference_id) {
    $sql = "SELECT image5 FROM final_uploaded_images WHERE reference_id = ?";
    $stmt = $conn->prepare($sql);
    if ($stmt === false) {
        die("Error preparing the SQL statement: " . $conn->error);
    }

    $stmt->bind_param("s", $reference_id);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows > 0) {
        $row = $result->fetch_assoc();
        if (!empty($row['image5'])) {
 
            echo '<div><img src="data:image/jpeg;base64,' . base64_encode($row['image5']) . '" alt="Google Map"><p>Google Map</p></div>';
        } else {
            echo "<p style='text-align:center;'>Google Map image not available.</p>";
        }
    } else {
        echo "<p style='text-align:center;'>No record found for Google Map image.</p>";
    }

    $stmt->close();
} else {
    echo "<p style='text-align:center;'>Reference ID is missing.</p>";
}
?>
</tr>
</div>
    </table>
    </table>
     <!-- <button onclick="window.print()">Download PDF</button> -->
    <form method="post">
  <input type="hidden" name="download_images" value="1">
  <button type="submit">Download All Images</button>
</form>
     <!-- <button onclick="window.print()">Download PDF</button> -->
  <button id="downloadPdf" onclick="setPrintMargins()">DOWNLOAD PDF</button>
  <script>
    document.getElementById('downloadPdf').addEventListener('click', () => {
      // Select the content you want to convert to PDF
      const element = document.getElementById('content');
      const options = {
        margin:[0,0],
        filename:'report.pdf',
        image: { type: 'jpeg', quality: 0.98 },
        html2canvas: { scale: 2 },
        jsPDF: { unit: 'in', format: 'letter', orientation: 'portrait' }
      };

      // Generate and download the PDF
      html2pdf().set(options).from(element).save();
    });
    function setPrintMargins() {
      const style = document.createElement('style');
      style.innerHTML = `
      @media print {
          body {
            margin:0.2;
          }
        }
      `;
      document.head.appendChild(style);
      window.print();
    }
    // Disable all input fields in the form
    document.querySelectorAll('input').forEach(function(input) {
        input.disabled = true;  // Disables the field completely
    });
    </script>
     </div>
    
</body>
</html>
