<?php include('auth.php'); ?>
<?php include 'watermark.html'; ?><?php
ini_set('display_errors', 1);
error_reporting(E_ALL);

// Increase PHP execution time and memory limit
ini_set('max_execution_time', 600); // Increase execution time to 600 seconds (10 minutes)
ini_set('memory_limit', '4096M'); // Increase memory limit to 4096MB
// Start session


$servername = "localhost";
$username = "root";
$password = "";
$dbname = "project_db";

// Create DB connection
$conn = new mysqli($servername, $username, $password, $dbname);
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

if (!isset($_SESSION['reference_id'])) {
    die("Reference ID not found in session.");
}
$reference_id = $_SESSION['reference_id'];

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['download_images'])) {

    // Get customer name
    $stmt_name = $conn->prepare("SELECT customerName FROM mis WHERE reference_id = ?");
    $stmt_name->bind_param("s", $reference_id);
    $stmt_name->execute();
    $result_name = $stmt_name->get_result();
    $customerName = "customer";
    if ($row = $result_name->fetch_assoc()) {
        $customerName = preg_replace('/[^a-zA-Z0-9]/', '', $row['customerName']);
    }
    $stmt_name->close();

    // Fetch image BLOBs
    $stmt = $conn->prepare("SELECT image1, image2, image3, image4, image5, image6, image7, image8, image9, image10, image11, image12 FROM final_uploaded_images WHERE reference_id = ?");
    $stmt->bind_param("s", $reference_id);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows > 0 && ($row = $result->fetch_assoc())) {
        $tempDir = sys_get_temp_dir() . DIRECTORY_SEPARATOR . uniqid('images_', true);
        mkdir($tempDir);

        $imageFiles = [];
        for ($i = 1; $i <= 12; $i++) {
            if (!empty($row["image$i"])) {
                $filename = $tempDir . DIRECTORY_SEPARATOR . "image{$i}.jpg";
                file_put_contents($filename, $row["image$i"]);
                $imageFiles[] = $filename;
            }
        }

        if (empty($imageFiles)) {
            die("No images to download.");
        }

        // Create ZIP
        $zipFileName = "images_" . preg_replace('/[^a-zA-Z0-9]/', '_', $reference_id) . "_{$customerName}.zip";
        $zipPath = $tempDir . DIRECTORY_SEPARATOR . $zipFileName;

        $zip = new ZipArchive();
        if ($zip->open($zipPath, ZipArchive::CREATE) !== TRUE) {
            die("Failed to create ZIP file.");
        }

        foreach ($imageFiles as $file) {
            $zip->addFile($file, basename($file));
        }
        $zip->close();

        // Send ZIP to browser
        header('Content-Type: application/zip');
        header('Content-Disposition: attachment; filename="' . basename($zipFileName) . '"');
        header('Content-Length: ' . filesize($zipPath));
        flush();
        readfile($zipPath);

        // Cleanup
        foreach ($imageFiles as $file) {
            unlink($file);
        }
        unlink($zipPath);
        rmdir($tempDir);
        exit;
    } else {
        echo "<p style='color:red;'>No image data found for this reference ID.</p>";
    }
}

$page = isset($_GET['page']) ? $_GET['page'] : 1;
$limit = 50;
$offset = ($page - 1) * $limit;
$sql_property = "SELECT * FROM mis WHERE reference_id = ? LIMIT $limit OFFSET $offset";
$stmt_property = $conn->prepare($sql_property);
$stmt_property->bind_param("s", $reference_id);
$stmt_property->execute();
$result_property = $stmt_property->get_result();
$data1 = $result_property->fetch_assoc();




// Fetch data from property_details table
$sql_property = "SELECT * FROM property_details WHERE reference_id = ?";
$stmt_property = $conn->prepare($sql_property);
$stmt_property->bind_param("s", $reference_id);
$stmt_property->execute();
$result_property = $stmt_property->get_result();
$data2= $result_property->fetch_assoc();




// Fetch data from area_valuation table
$sql_area = "SELECT * FROM address_details WHERE reference_id = ?";
$stmt_area = $conn->prepare($sql_area); 
$stmt_area->bind_param("s", $reference_id);
$stmt_area->execute();
$result_area = $stmt_area->get_result();
$data3 = $result_area->fetch_assoc();





// Fetch data from area_valuation table
$sql_area = "SELECT * FROM critical_parameters WHERE reference_id = ?";
$stmt_area = $conn->prepare($sql_area); 
$stmt_area->bind_param("s", $reference_id);
$stmt_area->execute();
$result_area = $stmt_area->get_result();
$data4 = $result_area->fetch_assoc();

 
// Fetch data from area_valuation table
$sql_area = "SELECT * FROM surroundings_details WHERE reference_id = ?";
$stmt_area = $conn->prepare($sql_area); 
$stmt_area->bind_param("s", $reference_id);
$stmt_area->execute();
$result_area = $stmt_area->get_result();
$data5 = $result_area->fetch_assoc();
$stmt_area->close();
 
// Fetch data from area_valuation table
$sql_area = "SELECT * FROM area_valuation WHERE reference_id = ?";
$stmt_area = $conn->prepare($sql_area); 
$stmt_area->bind_param("s", $reference_id);
$stmt_area->execute();
$result_area = $stmt_area->get_result();
$data6 = $result_area->fetch_assoc();
$stmt_area->close();
 



// Fetch data from area_valuation table
$sql_area = "SELECT * FROM floor_details WHERE reference_id = ?";
$stmt_area = $conn->prepare($sql_area); 
$stmt_area->bind_param("s", $reference_id);
$stmt_area->execute();
$result_area = $stmt_area->get_result();
$data8= $result_area->fetch_assoc();
$stmt_area->close();
 


// Fetch data from area_valuation table
$sql_area = "SELECT * FROM technical_details WHERE reference_id = ?";
$stmt_area = $conn->prepare($sql_area); 
$stmt_area->bind_param("s", $reference_id);
$stmt_area->execute();
$result_area = $stmt_area->get_result();
$data9 = $result_area->fetch_assoc();
$stmt_area->close();
 
// Fetch data from area_valuation table
$sql_area = "SELECT * FROM remarks_table WHERE reference_id = ?";
$stmt_area = $conn->prepare($sql_area); 
$stmt_area->bind_param("s", $reference_id);
$stmt_area->execute();
$result_area = $stmt_area->get_result();
$data10 = $result_area->fetch_assoc();
$stmt_area->close();


// Step 1: Fetch the engineer_id from the mis table
$sql_mis = "SELECT engineer_id FROM mis WHERE reference_id = ?";
$stmt_mis = $conn->prepare($sql_mis);
$stmt_mis->bind_param("s", $reference_id);
$stmt_mis->execute();
$result_mis = $stmt_mis->get_result();
$row_mis = $result_mis->fetch_assoc();
$stmt_mis->close(); 

if ($row_mis) {
    $engineer_id = $row_mis['engineer_id'];

    // Step 2: Fetch the engineer's name from engineer_login table
    $sql_engineer = "SELECT name FROM engineer_login WHERE engineer_id = ?";
    $stmt_engineer = $conn->prepare($sql_engineer);
    $stmt_engineer->bind_param("s", $engineer_id);
    $stmt_engineer->execute();
    $result_engineer = $stmt_engineer->get_result();
    $row_engineer = $result_engineer->fetch_assoc();
    $stmt_engineer->close();

    if ($row_engineer) {
        $engineer_name = $row_engineer['name'];
         //echo "Engineer Name: " . $engineer_name;
    } else {
        echo "Engineer not found.";
    }
} else {
    echo "No engineer assigned for this reference_id.";
}



// Step 1: Fetch the engineer_id from the mis table
$sql_mis = "SELECT report_id FROM mis WHERE reference_id = ?";
$stmt_mis = $conn->prepare($sql_mis);
$stmt_mis->bind_param("s", $reference_id);
$stmt_mis->execute();
$result_mis = $stmt_mis->get_result();
$row_mis = $result_mis->fetch_assoc();
$stmt_mis->close(); 

if ($row_mis) {
    $report_id = $row_mis['report_id'];

    // Step 2: Fetch the engineer's name from engineer_login table
    $sql_engineer = "SELECT name FROM report_login WHERE report_id = ?";
    $stmt_engineer = $conn->prepare($sql_engineer);
    $stmt_engineer->bind_param("s", $report_id);
    $stmt_engineer->execute();
    $result_engineer = $stmt_engineer->get_result();
    $row_engineer = $result_engineer->fetch_assoc();
    $stmt_engineer->close();

    if ($row_engineer) {
        $report_name = $row_engineer['name'];
         //echo "Engineer Name: " . $report_name;
    } else {
        echo "Engineer not found.";
    }
} else {
    echo "No engineer assigned for this reference_id.";
}


// Step 1: Fetch the engineer_id from the mis table
$sql_mis = "SELECT report_drafter_to_technical FROM mis WHERE reference_id = ?";
$stmt_mis = $conn->prepare($sql_mis);
$stmt_mis->bind_param("s", $reference_id);
$stmt_mis->execute();
$result_mis = $stmt_mis->get_result();
$row_mis = $result_mis->fetch_assoc();
$stmt_mis->close(); 

if ($row_mis) {
    $report_drafter_to_technical = $row_mis['report_drafter_to_technical'];

    // Step 2: Fetch the engineer's name from engineer_login table
    $sql_engineer = "SELECT name FROM technical_login WHERE technical_manager_id = ?";
    $stmt_engineer = $conn->prepare($sql_engineer);
    $stmt_engineer->bind_param("s", $report_drafter_to_technical);
    $stmt_engineer->execute();
    $result_engineer = $stmt_engineer->get_result();
    $row_engineer = $result_engineer->fetch_assoc();
    $stmt_engineer->close();

    if ($row_engineer) {
        $technical_name = $row_engineer['name'];
        //echo "Engineer Name: " . $technical_name;
    } else {
        echo "Engineer not found.";
    }
} else {
    echo "No engineer assigned for this reference_id.";
}
?>
<!DOCTYPE html>
<html>
<head>
    <title>Indusind Report</title>
  <style>
    body {
      font-family: 'Arial', sans-serif;
      font-size: 14px;
    }
    header {
  display: flex;
  align-items: center;
}

.logo img {
  width: 120px;
  margin-left:30px;
  height: auto;
}

.header-content {
  text-align: center;
  flex: 1;
  margin-left:-190x
}

header h1 {
  margin: 0;
  font-weight:700;
  font-size:27px;
  color: #a60000;
  
}

header p {
  margin: 2px 0;
  font-size: 14px;
  font-weight: bolder;
  color: #9e2424;
  
}
    table {
      border-collapse: collapse;
      width: 100%;
      table-layout: fixed;
    }

    th, td {
      border: 1px solid #000;
      padding: 6px;
      vertical-align: top;
    }

    th {
      font-weight: bold;
      text-align: center;
    }

    .section-header {
      font-weight: bold;
      text-align: left;
    }

    input[type="text"] {
      width:98%;
      border: none;
      outline: none;
      padding: 4px;
      font-size: 14px;
    }
    #number{
      width:20px;
      text-align: center;
    }    
  </style>
  <style>
.container {
    max-width: 1200px;
    margin: 20px auto;
    padding: 20px;
    background-color: white;
    box-shadow: 0px 0px 10px rgba(0, 0, 0, 0.1);
    border-radius: 8px;
}

.title {
    text-align: center;
    font-size: 24px;
    font-weight: bold;
    margin-bottom: 20px;
}
.grid-container {
    display: grid;
    grid-template-columns: repeat(4, 1fr);
    gap: 15px;
}

.grid-item {
    position: relative;
    border-radius: 8px;
    overflow: hidden;
    box-shadow: 0px 4px 6px rgba(0, 0, 0, 0.1);
}

.grid-item img {
    width: 100%;
    height: 200px;
    object-fit: cover;
    transition: transform 0.3s ease;
}
.grid-item:hover img {
    transform: scale(1.05);
}

.overlay {
    position: absolute;
    bottom: 0;
    left: 0;
    background: rgba(0, 0, 0, 0.6);
    color: white;
    width: 100%;
    padding: 8px;
    font-size: 14px;
    text-align: center;
}
 
   
/* Force a stable 4-column grid that wkhtmltopdf respects */
.image-gallery { width: 100%; }
.image-grid { width: 100%; border-collapse: collapse; table-layout: fixed; }
.image-grid tr { page-break-inside: avoid; }
.image-grid td { width: 25%; padding: 6px; vertical-align: top; }

.image-grid .img-wrap { display: block; }
.image-grid img { display: block; width: 100%; height: auto; }
.image-grid .caption { font-size: 12px; text-align: center; margin-top: 4px; }

/* If you had a flex layout before, neutralize it */
.image-gallery { display: block !important; }



    /* Print-specific rules */
    @media print {
      .no-print {
        display: none !important;
      }

      body {
        margin: 0;
      }
 
    }
  button{
    padding:8px;
    margin-left:45%;
    background-color:#808485;
    color:white;
    font-weight:700;
    font-style:italic;
  }
  button:hover{
    background-color:rgba(216,216,216,255);
    color:white;
  }

/* Optional: Google map styling */
    .google-map-container {
      max-width: 90%;
      margin: 20px auto;
      border: 2px solid #ccc;
      padding: 10px;
      box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
      background-color: #f9f9f9;
      border-radius: 8px;
      text-align: center;
    }

    .google-map-container img {
      max-width: 100%;
      height: auto;
      display: inline-block;
      border: 1px solid #999;
      border-radius: 4px;
    }
    
.logo img {
  width: 120px;
  margin-left:30px;
  height: auto;
}
 </style>

      <link rel="shortcut icon" href="favicon.ico" type="image/x-icon">
</head>
<body>
<div class="content">
    <header>
      <div class="logo">
        <img src="images/logo.png" alt="Magpie Logo">
      </div>
      <div class="header-content">
        <h1>MAGPIE ENGINEERING PVT. LTD.</h1>
        <p>Valuer Designer Architects</p>
        <p>Reg.Add:5th Floor E-509,Casa Green ,A.B.Road,Talawall Chanda,Indore(M.P)-453771</p>
        <p>Office No. 201, 2nd Floor, Gravity Mall, Warehouse Road, Mechanic Nagar,near Vijay Nagar, Madhya Pradesh - 452011.</p>
      </div>
    </header>
<table>
  <tr>
    <td colspan="10"><strong>Subject:Valuation of property for ABC/BBC/CBG – IndusInd Bank</strong></td>
  
  </tr>

  <tr>
    <th colspan="4">   <span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data1['reference_id'] ?? '') ?>
    </span></th>
    <th></th>
      <td colspan="2" style="text-align:right;"><strong>DATED :</strong></td>
    <td colspan="3">   <span style="display: inline-block; min-width: 50px; padding: 2px;">
 <?= htmlspecialchars(date('d M Y h:i A', strtotime($data1['report_assigned_at'] ?? ''))) ?>
    </span></td>
  </tr>

  <!-- Section A -->
  <tr>
    <td class="section-header" id="number">A</td>
    <td colspan="9" class="section-header"> General details</td>
  </tr>

  <tr>
    <td id="number">1</td>
    <td colspan="3">Name of the customer</td>
    <td colspan="6">   <span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data1['customerName'] ?? '') ?>
    </span></td>
  </tr>

  <tr>
    <td id="number">2</td>
    <td colspan="3">Request received from</td>
    <td colspan="6">Indusind Bank <span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data3['nearest_branch_location'] ?? '') ?>Branch
    </span></td>
  </tr>

  <tr>
    <td id="number">3</td>
    <td colspan="3">Name of document holder (as per Sale Deed)</td>
    <td colspan="6">   <span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data10['NA'] ?? '') ?>
    </span></td>
  </tr>

  <tr>
    <td id="number">4</td>
    <td colspan="3">Property address (as per request)</td>
    <td colspan="6">   <span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data10['NA'] ?? '') ?>
    </span></td>
  </tr>

  <tr>
    <td id="number">5</td>
    <td colspan="3">Property address (on-site inspection)</td>
    <td colspan="6">   <span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data3['address_per_site'] ?? '') ?>
    </span></td>
  </tr>

  <tr>
    <td id="number">6</td>
    <td colspan="3">Property Legal address (as per docs)</td>
    <td colspan="6"> <span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
  <?= htmlspecialchars($data3['address_per_document'] ?? '') ?> </span></td>
  </tr>

  <tr>
    <td id="number">7</td>
    <td colspan="3">Landmark</td>
    <td colspan="6"><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data3['landmark_1'] ?? '') ?><?= htmlspecialchars($data3['landmark_2'] ?? '') ?>
    </span></td>
  </tr>
<tr>
  <td id="number">8</td>
    <td colspan="3">Date of inspection</td>
    <td colspan="6">   <span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data1['fe_to_coordinator_assign_at'] ?? '') ?>
    </span></td>
</tr>
  <!-- Section B -->
  <tr>
     <td class="section-header" id="number">B</td>
    <td colspan="9" class="section-header"> Surrounding locality details</td>
  </tr>

  <tr>
    <td id="number">1</td>
    <td colspan="3">Ward no./Municipal land no.</td>
    <td colspan="6"><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data10['NA'] ?? '') ?>
    </span></td>
  </tr>
<tr>
  <td id="number">2</td>
    <td colspan="3">Vicinity</td>
    <td colspan="6">   <span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data10['NA'] ?? '') ?>
    </span></td>
</tr>
  <tr>
    <td id="number">3</td>
    <td colspan="3">Classification of locality</td>
    <td colspan="6">   <span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data2['class_of_locality'] ?? '') ?>
    </span></td>
  </tr>
  <tr>
    <td rowspan="3" id="number">4</td>
    <td rowspan="3" colspan="3">Proximity to civic amenities</td>
    <td>1</td>
    <td colspan="2"> Nearest railway station</td>
    <td>:</td>
    <td>   <span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data3['nearest_railway_station_distance'] ?? '') ?>
    </span></td>
    <td>Km</td>
  </tr>
  <tr>
      <td>2</td>
    <td colspan="2"> Nearest bus stop</td>
    <td>:</td>
    <td>   <span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data3['nearest_bus_stop_distance'] ?? '') ?>
    </span></td>
    <td>Km</td>
  </tr>
  <tr>
      <td>3</td>
    <td colspan="2">Nearest hospital</td>
    <td>:</td>
    <td>   <span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data3['nearest_hospital_distance'] ?? '') ?>
    </span></td>
    <td>Km</td>
  </tr>
  <tr>
    <td id="number">5</td>
    <td colspan="3">Condition of approach road</td>
    <td colspan="6"><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data2['approach_road_to_property'] ?? '') ?>
    </span></td>
  </tr>
  <!-- Plot demarcation -->
  <tr>
    <td rowspan="3" id="number">6</td>
    <td colspan="2" rowspan="3">Plot demarked at site (are boundaries matching as per legal document)</td>
          <th></th>
          <th colspan="2">East</th>
          <th>West</th>
          <th colspan="2">North</th>
          <th>South</th>
        </tr>
        <tr>
          <td>As per Document</td>
          <td colspan="2"><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data3['direction_as_per_document_east'] ?? '') ?>
    </span></td>
          <td>   <span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data3['direction_as_per_document_west'] ?? '') ?>
    </span></td>
          <td colspan="2">   <span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data3['direction_as_per_document_north'] ?? '') ?>
    </span></td>
          <td>   <span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data3['direction_as_per_document_south'] ?? '') ?>
    </span></td>
        </tr>
        <tr>
          <td>Actual</td>
          <td colspan="2">   <span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data3['direction_as_per_site_east'] ?? '') ?>
    </span></td>
          <td>   <span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data3['direction_as_per_site_west'] ?? '') ?>
    </span></td>
          <td colspan="2">   <span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data3['direction_as_per_site_north'] ?? '') ?>
    </span></td>
          <td>   <span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data3['direction_as_per_site_south'] ?? '') ?>
    </span></td>
        </tr>
  <tr>
    <td id="number">7</td>
    <td colspan="3">Property identified through</td>
    <td colspan="6">   <span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data2['NA'] ?? '') ?>
    </span></td>
  </tr>

  <!-- Property Details -->

  
  <tr>
    <td class="section-header"id="number">C</td>
    <td colspan="9" class="section-header">Property details</td>
  </tr>

  <tr>
    <td id="number">1</td>
    <td colspan="3">Description of property</td>
    <td colspan="6">   <span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data10['NA'] ?? '') ?>
    </span></td>
  </tr>

  <tr>
    <td id="number">2</td>
    <td colspan="3">Type of property</td>
    <td colspan="6">   <span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data2['property_unit_type'] ?? '') ?>
    </span></td>
  </tr>

  <tr>
    <td rowspan="4" id="number">3</td>
    <td colspan="3" rowspan="4">Type of usage of entire property</td>
    <td>GF</td>
    <td></td>
    <td>:</td>
    <td colspan="3">   <span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data10['NA'] ?? '') ?>
    </span></td>
  </tr>
<tr>
   <td>FF</td>
    <td></td>
    <td>:</td>
    <td colspan="3">   <span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data10['NA'] ?? '') ?>
    </span></td>
</tr>
<tr>
   <td>SF</td>
    <td></td>
    <td>:</td>
    <td colspan="3">   <span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data10['NA'] ?? '') ?>
    </span></td>
</tr>
<tr>
   <td>TF</td>
    <td></td>
    <td>:</td>
    <td colspan="3">   <span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data10['NA'] ?? '') ?>
    </span></td>
</tr>
  <tr>
    <td  rowspan="4" id="number">4</td>
    <td colspan="3"  rowspan="4">Accommodation details</td>
      <td>GF</td>
    <td></td>
    <td>:</td>
    <td colspan="3">   <span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data10['NA'] ?? '') ?>
    </span></td>
  </tr>
<tr>
   <td>FF</td>
    <td></td>
    <td>:</td>
    <td colspan="3">   <span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data10['NA'] ?? '') ?>
    </span></td>
</tr>
<tr>
   <td>SF</td>
    <td></td>
    <td>:</td>
    <td colspan="3">   <span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data10['NA'] ?? '') ?>
    </span></td>
</tr>
<tr>
   <td>TF</td>
    <td></td>
    <td>:</td>
    <td colspan="3">   <span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data10['NA'] ?? '') ?>
    </span></td>
</tr>
  <tr>
    <td id="number">5</td>
    <td colspan="3">Additional amenities</td>
    <td colspan="6">   <span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data10['NA'] ?? '') ?>
    </span></td>
  </tr>

  <tr>
    <td id="number">6</td>
    <td colspan="3">Area of property (actual)</td>
    <td colspan="2">   <span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data6['actual_plot_square_feet'] ?? '') ?>
    </span></td>
    <td colspan="4">Sq. ft</td>
  </tr>

  <tr>
    <td id="number">7</td>
    <td colspan="3">Carpet area (approx)</td>
       <td colspan="2">   <span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data10['NA'] ?? '') ?>
    </span></td>
    <td colspan="4">Sq. ft</td>
  </tr>

  <tr>
    <td id="number">8</td>
    <td colspan="3">Built up / saleable area (GF) Tin Shed</td>
    <td colspan="2">   <span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data10['NA'] ?? '') ?>
    </span></td>
    <td colspan="4">Sq. ft</td>
  </tr>
</table>
<table>
  <tr>
    <td rowspan="5" id="number">9</td>
    <td colspan="2" rowspan="5">Area of property (permitted as per approved plan/building byelaws)</td>
    <td>GF</td>
    <td>   <span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data10['NA'] ?? '') ?>
    </span></td>
    <td>Sq.Ft</td>
    <td rowspan="6">Sanction Plan not provided</td>
  </tr>
  <tr>
    <td>FF</td>
    <td>   <span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data10['NA'] ?? '') ?>
    </span></td>
    <td>Sq.Ft</td>
  </tr>
  <tr>
    <td>SF</td>
    <td>   <span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data10['NA'] ?? '') ?>
    </span></td>
    <td>Sq.Ft</td>
  </tr>
    <tr>
    <td>TF</td>
    <td>   <span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data10['NA'] ?? '') ?>
    </span></td>
    <td>Sq.Ft</td>
  </tr>
  <tr>
    <td>Total</td>
    <td>   <span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data10['NA'] ?? '') ?>
    </span></td>
    <td>Sq.Ft</td>
  </tr>
  <tr>
    <td>10</td>
    <td colspan="2">Area as per sale deed / Built up area</td>
    <td colspan="2">   <span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data10['NA'] ?? '') ?>
    </span></td>
    <td>Sq.Ft</td>
  </tr>
  <tr>
    <td>11</td>
    <td colspan="2">Adherence to sanction plan</td>
    <td colspan="4">   <span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data10['NA'] ?? '') ?>
    </span></td>
  </tr>
  <tr>
    <td>12</td>
    <td colspan="2">Deviation from sanction plan/building byelaws (if any)</td>
    <td colspan="4">   <span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data10['NA'] ?? '') ?>
    </span></td>
  </tr>
</table>

<!-- Table 2: Floorwise Area -->
<table>
  <tr>
    <th id="number"></th>
    <th>Floor</th>
    <th>Actual Area %</th>
    <th colspan="2">Permissible Area</th>
    <th>%</th>
    <th>Excess Coverage</th>
    <th>%</th>
  </tr>
  <tr>
    <td id="number"></td>
    <td>GF</td>
    <td>   <span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data10['NA'] ?? '') ?>
    </span></td>
    <td>   <span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data8['ground_permissible'] ?? '') ?>
    </span></td>
    <td>Sq.Ft</td>
    <td>   <span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data10['NA'] ?? '') ?>
    </span></td>
    <td>   <span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data10['NA'] ?? '') ?>
    </span></td>
    <td>   <span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data10['NA'] ?? '') ?>
    </span></td>
  </tr>
  <tr>
    <td id="number"></td>
    <td>FF</td>
    <td>   <span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data10['NA'] ?? '') ?>
    </span></td>
    <td>   <span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data8['first_permissible'] ?? '') ?>
    </span></td>
    <td>Sq.Ft</td>
    <td>   <span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data10['NA'] ?? '') ?>
    </span></td>
    <td>   <span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data10['NA'] ?? '') ?>
    </span></td>
    <td>   <span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data10['NA'] ?? '') ?>
    </span></td>
  </tr>
  <tr>
    <td id="number"></td>
    <td>SF</td>
    <td>   <span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data10['NA'] ?? '') ?>
    </span></td>
    <td>   <span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data8['second_permissible'] ?? '') ?>
    </span></td>
    <td>Sq.Ft</td>
    <td>   <span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data10['NA'] ?? '') ?>
    </span></td>
    <td>   <span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data10['NA'] ?? '') ?>
    </span></td>
    <td>   <span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data10['NA'] ?? '') ?>
    </span></td>
  </tr>
  <tr>
    <td id="number"></td>
    <td>TF</td>
    <td>   <span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data10['NA'] ?? '') ?>
    </span></td>
    <td>   <span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data8['other_permissible_floors'] ?? '') ?>
    </span></td>
    <td>Sq.Ft</td>
    <td>   <span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data10['NA'] ?? '') ?>
    </span></td>
    <td>   <span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data10['NA'] ?? '') ?>
    </span></td>
    <td>   <span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data10['NA'] ?? '') ?>
    </span></td>
  </tr>
</table>

<!-- Table 3: Ownership -->
<table>
  <tr>
    <td id="number">13</td>
    <td colspan="2">Risk of demolition (valuer's view)</td>
    <td colspan="3">   <span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data9['demolition_risk_1'] ?? '') ?>
    </span></td>
  </tr>
  <tr>
    <td id="number">14</td>
    <td colspan="2">Property currently occupied by (owner/self/tenant/vacant)</td>
    <td colspan="3">   <span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data2['occupancy_status'] ?? '') ?>
    </span></td>
  </tr>
  <tr>
    <td>15</td>
    <td colspan="2">If occupied, then since ___ yrs</td>
    <td colspan="3">   <span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data2['occupied_since'] ?? '') ?>
    </span></td>
  </tr>
</table>

<!-- Table 4: Subject Property Details -->
<table>
  <tr>
    <td id="number"><strong>D</strong></td>
    <td colspan="6"><strong> Subject Property Details</strong></td>
  </tr>
  <tr>
    <td>1</td>
    <td colspan="2">Land freehold or leasehold</td>
    <td colspan="4">   <span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data2['property_leasehold_freehold'] ?? '') ?>
    </span></td>
  </tr>
  <tr>
    <td>2</td>
    <td colspan="2">Approval for drawings from Mun.authorities/occupation certificate. ULC clearance/FSI available and balance for future use/FSI from TDR</td>
    <td colspan="4">   <span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data10['NA'] ?? '') ?>
    </span></td>
  </tr>
  <tr>
    <td>3</td>
    <td colspan="2">Name of the co-operative housing society:</td>
    <td colspan="4">   <span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data10['NA'] ?? '') ?>
    </span></td>
  </tr>
  <tr>
    <td>4</td>
    <td colspan="2">Registration no. of society:</td>
    <td colspan="4">   <span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data10['NA'] ?? '') ?>
    </span></td>
  </tr>
  <tr>
    <td>5</td>
     <td colspan="2">No. of shares held and certificate no.:</td>
    <td colspan="4">   <span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data10['NA'] ?? '') ?>
    </span></td>
  </tr>
  <tr>
    <td>6</td>
    <td colspan="2">Outgoings per month :</td>
    <td colspan="4">   <span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data10['NA'] ?? '') ?>
    </span></td>
  </tr>
</table>

<!-- Table 5: Structure -->
<table>
  <tr>
        <td id="number"><strong>E </strong></td>
    <td colspan="5"> <strong>Structural Details</strong></td>
  </tr>
  <tr>
    <td>1</td>
    <td colspan="2">Type of structure</td>
    <td colspan="3">   <span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data4['structure_type'] ?? '') ?>
    </span></td>
   </tr>
    <tr>
      <td>2</td>
    <td colspan="2">No. of floors</td>
    <td colspan="3">   <span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data8['actual_configuration_building'] ?? '') ?>
    </span></td>
  </tr>
  <tr>
    <td>3</td>
    <td colspan="2">No. of wings</td>
    <td colspan="3">   <span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data10['NA'] ?? '') ?>
    </span></td>
</tr>
<tr>
    <td>4</td>
   <td colspan="2">No. of flats on each floor </td>
    <td colspan="3">   <span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data10['NA'] ?? '') ?>
    </span></td>
  </tr>
  <tr>
    <td>5</td>
   <td colspan="2">No. of lifts in each wing </td>
    <td colspan="3">   <span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data10['NA'] ?? '') ?>
    </span></td>
  </tr>
  <tr>
    <td>6</td>
    <td colspan="2">Age of property</td>
    <td colspan="2">   <span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data2['age_of_property'] ?? '') ?>
    </span></td>
    <td>Years</td>
  </tr>
  <tr>
    <td>7</td>
    <td colspan="2">Estimated future life</td>
    <td colspan="2">   <span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data10['NA'] ?? '') ?>
    </span></td>
    <td>Years</td>
  </tr>
</table>

<!-- Table 6: Construction Quality -->
<table>
  <tr>
    <td id="number"></td>
    <td colspan="6"><strong> Quality of Construction </strong></td>
  </tr>
  <tr>
    <td id="number"><strong>A</strong></td>
    <td colspan="6"><strong>Exteriors</strong></td>
  </tr>
  <tr>
    <td id="number">1</td>
    <td colspan="2">Beam & column structure</td>
    <td colspan="4">   <span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data10['NA'] ?? '') ?>
    </span></td>
    </tr>
<tr>
  <td>2</td>
    <td colspan="2">Appearance of the building</td>
    <td colspan="4">   <span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data10['NA'] ?? '') ?>
    </span></td>
  </tr>
  <tr>
      <td>3</td>
    <td colspan="2">Maintenance of the building </td>
    <td colspan="4">   <span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data2['structurally_fit'] ?? '') ?>
    </span></td>
  </tr>
  <tr>
    <td rowspan="4">4</td>
    <td rowspan="4" colspan="2">Common area remarks</td>
    <td>Reception</td>
    <td colspan="3">   <span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data10['NA'] ?? '') ?>
    </span></td>
  </tr>
  <tr>
      <td>Staircase</td>
    <td colspan="3">   <span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data10['NA'] ?? '') ?>
    </span></td> 
  </tr>
  <tr>
   <td>O/h Water tank</td>
    <td colspan="3">   <span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data10['NA'] ?? '') ?>
    </span></td>
  </tr>
    <tr>
   <td>Sanitation</td>
    <td colspan="3">   <span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data10['NA'] ?? '') ?>
    </span></td>
  </tr>
</table>


<table>
  <!-- B Interiors -->
  <tr>
    <td id="number"><strong>B</strong></td>
    <td colspan="3"><strong> Interiors</strong></td>
  </tr>
  <tr>
    <td>1</td>
    <td>Flooring</td>
    <td colspan="2">   <span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data10['NA'] ?? '') ?>
    </span></td>
  </tr>
  <tr>
    <td>2</td>
    <td>Finishing</td>
    <td colspan="2">   <span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data10['NA'] ?? '') ?>
    </span></td>
  </tr>
  <tr>
    <td>3</td>
    <td>Roofing & Terracing</td>
    <td colspan="2">   <span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data4['roof_type'] ?? '') ?>
    </span></td>
  </tr>

  <!-- F Unit Details -->
  <tr>
    <td id="number"><strong>F</strong></td>
    <td colspan="3"><strong>Unit details</strong></td>
  </tr>
  <tr>
    <td>1</td>
    <td>Situated on floor no.</td>
    <td colspan="2">   <span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data10['NA'] ?? '') ?>
    </span></td>
  </tr>
  <tr>
    <td>2</td>
    <td>Internal composition</td>
    <td colspan="2">   <span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data10['NA'] ?? '') ?>
    </span></td>
  </tr>
  <tr>
    <td>3</td>
    <td>Flooring</td>
    <td colspan="2">   <span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data10['NA'] ?? '') ?>
    </span></td>
  </tr>
  <tr>
    <td>4</td>
    <td>Quality of fittings</td>
    <td colspan="2">   <span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data10['NA'] ?? '') ?>
    </span></td>
  </tr>
  <tr>
    <td>5</td>
    <td>Woodwork</td>
    <td colspan="2">   <span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data10['NA'] ?? '') ?>
    </span></td>
  </tr>
  <!-- G Valuation -->
  <tr>
    <td id="number"><strong>G</strong></td>
    <td colspan="3"><strong> Valuation</strong></td>
  </tr>
  <tr>
    <td>1</td>
    <td>Drawings and approvals</td>
    <td colspan="2">   <span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data10['NA'] ?? '') ?>
    </span></td>
  </tr>
  <tr>
    <td>2</td>
    <td>Area considered for valuation</td>
    <td colspan="2">   <span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data10['NA'] ?? '') ?>
    </span></td>
  </tr>
  <tr>
    <td>3</td>
    <td>Age of building & future life</td>
    <td colspan="2">   <span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data10['NA'] ?? '') ?>
    </span></td>
  </tr>
  <tr>
    <td>4</td>
    <td>Present condition of property and structure</td>
    <td colspan="2">   <span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data10['NA'] ?? '') ?>
    </span></td>
  </tr>
  <tr>
    <td>5</td>
    <td>Comments on specification & amenities</td>
    <td colspan="2">   <span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data10['NA'] ?? '') ?>
    </span></td>
  </tr>
  <tr>
    <td>6</td>
    <td>Market rates of properties in the vicinity and surrounding area (Per Sqft)Market rates in vicinity (Per Sqft)</td>
    <td colspan="2">   <span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data10['NA'] ?? '') ?>
    </span></td>
  </tr>
  <tr>
    <td>7</td>
    <td>Inquiries made from</td>
    <td colspan="2">   <span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data10['NA'] ?? '') ?>
    </span></td>
  </tr>
  <tr>
    <td>8</td>
    <td><strong>Remarks (if any)</strong></td>
    <td colspan="2">   <span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data10['NA'] ?? '') ?>
    </span></td>
  </tr>
  
<table>

  <tr>
    <td rowspan="2" id="number">10</td>
    <th colspan="2" rowspan="2">Govt Guideline value (Ready Reckoner/Circle Rate/ Jantri rate as for Stamp Duty)</th>
    <th>Plot Area</th>
    <th>Govt. Sqft. Rate</th>
    <th>Total</th>
  </tr>
  <tr>
    <td>   <span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data10['NA'] ?? '') ?>
    </span></td>
    <td>   <span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data6['guideline_rate'] ?? '') ?>
    </span></td>
    <td>   <span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data6['guideline_values'] ?? '') ?>
    </span></td>
  </tr>
<tr>
  <td colspan="6"> <strong>In view of the data available and basis for valuation, the valuation of the property under reference will as under :-</strong></td>
</tr>
  <tr>
    <td>(I)</td>
    <td colspan="5"><strong>For Land & Building</strong></td>
  </tr>

  <tr >
    <th>A</th>
    <th colspan="2">Land area</th>
    <th>Rate adopted</th>
    <th colspan="2">Land value</th>
  </tr>
  <tr>
    <td></td>
    <td colspan="2">   <span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data6['final_plot_square_feet'] ?? '') ?>
    </span></td>
    <td>   <span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data6['final_plot_rate'] ?? '') ?>
    </span></td>
    <td colspan="2">   <span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data6['finally_plot_valuation'] ?? '') ?>
    </span></td>
  </tr>

  <tr >
    <th>B</th>
    <th colspan="2">Built up area</th>
    <th>Rate adopted (after dep.)</th>
    <th>Less for repairs (if any)</th>
    <th>Building value</th>
  </tr>
  <tr>
    <td></td>
    <td colspan="2">   <span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data6['final_construction_square_feet'] ?? '') ?>
    </span></td>
    <td>   <span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data6['final_construction_rate'] ?? '') ?>
    </span></td>
    <td>   <span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data10['NA'] ?? '') ?>
    </span></td>
    <td>   <span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data10['NA'] ?? '') ?>
    </span></td>
  </tr>

  <tr>
    <th>B</th>
    <th colspan="2">Built up area<br>Teen Shed</th>
    <th>Rate adopted (after dep.)</th>
    <th>Less for repairs (if any)</th>
    <th>Building value</th>
  </tr>
  <tr>
    <td></td>
    <td colspan="2">   <span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data10['NA'] ?? '') ?>
    </span></td>
    <td>   <span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data10['NA'] ?? '') ?>
    </span></td>
    <td>   <span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data10['NA'] ?? '') ?>
    </span></td>
    <td>   <span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data10['NA'] ?? '') ?>
    </span></td>
  </tr>

  <tr>
    <th>C</th>
    <th colspan="2">Total value of property (A + B)</th>
    <td>Rs.</td>
     <td colspan="2">   <span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data6['total_finally_area_valuation'] ?? '') ?>
    </span></td>
  </tr>

  <tr>
    <td></td>
    <th colspan="2">Valuation in words:</th>
   <td colspan="3">   <span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data6['total_valuation_words'] ?? '') ?>
    </span></td>
  </tr>
  </table>
 <table>
  <tr>
    <td id="number">(II)</td>
    <td colspan="7"><strong>For flat/shop/floor</strong></td>
  </tr>
  <tr>
    <td></td>
    <th colspan="2">Built up area</th>
    <th colspan="3">Rate adopted</th>
    <th colspan="2">Present value</th>
  </tr>
  <tr>
    <td></td>
    <td>   <span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data10['NA'] ?? '') ?>
    </span></td>
    <td>Sq.ft</td>
    <td>Rs.</td>
    <td>   <span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data10['NA'] ?? '') ?>
    </span></td>
    <td>   <span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data10['NA'] ?? '') ?>
    </span></td>
   <td>Rs.</td>
    <td>   <span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data10['NA'] ?? '') ?>
    </span></td>
  </tr>
  <tr>
    <td>11</td>
    <td colspan="3">Construction estimate given by the customer</td>
    <td colspan="4">   <span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data10['NA'] ?? '') ?>
    </span></td>
  </tr>
</table>
<table>
  <tr>
    <td id="number">12</td>
    <td>Is the estimate given by the customer valid</td>
    <td colspan="2">   <span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data10['NA'] ?? '') ?>
    </span></td>
  </tr>
  <tr>
    <td>13</td>
    <td>Value of the property (for mortgage value) as on date</td>
    <td id="number">Rs.</td>
    <td>   <span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data10['NA'] ?? '') ?>
    </span></td>
  </tr>
  <tr>
    <td>14</td>
    <td>Forced/distress sale value</td>
    <td id="number">Rs.</td>
    <td>   <span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data6['total_distress_value'] ?? '') ?>
    </span></td>
  </tr>
  <tr>
    <td>15</td>
    <td>Replacement value for insurance purposes</td>
    <td id="number">Rs.</td>
    <td>   <span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data10['NA'] ?? '') ?>
    </span></td>
  </tr>
  <!-- Income/Volatility -->
  <tr>
    <td>1</td>
    <td>For Sale – estimated real income</td>
    <td colspan="2">   <span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data10['NA'] ?? '') ?>
    </span></td>
  </tr>
  <tr>
    <td>2</td>
    <td> For Lease – estimated rental income</td>
    <td colspan="2"> <span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data10['NA'] ?? '') ?>
    </span> </td>
  </tr>
  <tr>
    <td>3</td>
    <td> Volatility of property prices</td>
    <td colspan="2">   <span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data10['NA'] ?? '') ?>
    </span> </td>
  </tr>
  </table>
  <table>
 <tr>
    <td id="number">(VII)</td>
    <td colspan="2"><strong>Disclosure Statement</strong></td>
  </tr>
  <!-- VIII Disclosure Statement -->
  <tr><td>1</td><td colspan="2">Statements of facts are true and correct.</td></tr>
  <tr><td>2</td><td colspan="2">Limiting conditions have been disclosed.</td></tr>
  <tr><td>3</td><td colspan="2">We (valuer) have no interest (present or future) in the transaction or property</td></tr>
  <tr><td>4</td><td colspan="2">Compensation is not contingent upon rendering a specified value.</td></tr>
  <tr><td>5</td><td colspan="2">We have complied with all of the real estate appraisal program requirements.</td></tr>
  <tr><td>6</td><td colspan="2">An inspection of the property was performed by our site engineer.</td></tr>
  <tr><td>7</td><td colspan="2">No support received.</td></tr>

  <!-- REMARK Section -->
  <tr>
    <td></td>
    <td colspan="2">REMARK</td>
    </tr>
    <tr>
      <td></td>
    <td colspan="2"><span style="white-space: pre-line; font-size:14px; display: block; text-align: left; padding: 0; margin: 0; "readonly>
        <?= htmlspecialchars($data10['remarks'] ?? '') ?>
    </span></td>
  </tr>
  <!-- VIII Declaration -->
    <tr>
    <td id="number">(VIII)</td>
    <td colspan="2"><strong>Declaration</strong></td>
  </tr>
  <tr><td></td>
  <td colspan="2"><span style="white-space: pre-line; font-size:14px; display: block; text-align: left; padding: 0; margin: 0;font-weight:400;" readonly>
    <?= nl2br(htmlspecialchars(formatDeclaration($data10['declaration'] ?? ''))) ?>
</span></td> </tr>
 <?php
function formatDeclaration($text) {
    // Insert a newline before every occurrence of a number followed by a dot and space (e.g., "1. ", "10. ")
    // Only if it's NOT already at the beginning of the string or a new line
    $text = preg_replace('/(?<!^)(?<!\n)(\d+\.\s)/', "\n$1", $text);
    return $text;
}
?></tr>
 </table>
 <table>
  <!-- Signature Row -->
  <tr>
    <td colspan="2">Place :</td>
    <td colspan="1">   <span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data1['bank_branchname'] ?? '') ?>
    </span></td>
    <td>For</td>
    <td colspan="1">   <span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data10['NA'] ?? '') ?>
    </span></td>
  </tr>
  <tr>
    <td colspan="3"></td>
    <td colspan="2">MAGPIE ENGINEERING PVT LTD</td>
  </tr>
  <tr>
    <td id="number"></td>
    <td>Date :</td>
    <td colspan="2">    <span style="display: inline-block; min-width: 50px; padding: 2px;">
 <?= htmlspecialchars(date('d M Y h:i A', strtotime($data1['report_assigned_at'] ?? ''))) ?>
    </span></td>
    <td>( Name of Valuer)</td>
  </tr>
</table>

  <table>
<tr><th style="margin-bottom:-18px;">PHOTOGRAPH OF THE PROPERTY</tr></th></table>
<br>

    
<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

$servername = "localhost";
$username   = "root";
$password   = "";
$dbname     = "project_db";

$conn = new mysqli($servername, $username, $password, $dbname);
if ($conn->connect_error) {
    die("Connection failed: " . htmlspecialchars($conn->connect_error));
}

$reference_id = $_SESSION['reference_id'] ?? null;
$reference_id = $_GET['reference_id'] ?? $reference_id;

if ($reference_id) {

    // Map captions
    $captions = [
        'image1'  => 'EXTERNAL PHOTOS',
        'image2'  => 'Kitchen',
        'image3'  => 'Selfie',
        'image4'  => 'Electric Meter',
        'image6'  => 'Other 1',
        'image7'  => 'Other 2',
        'image8'  => 'Other 3',
        'image9'  => 'Other 4',
        'image10' => 'Other 5',
        'image11' => 'Other 6',
        'image12' => 'Other 7',
        'image13' => 'Other 8',
        'image14' => 'Other 9',
        'image15' => 'Other 10',
        'image16' => 'Other 11',
        'image17' => 'Other 12',
        'image18' => 'Other 13',
        'image19' => 'Other 14',
        'image20' => 'Other 15',
    ];

    // === Helper: EXIF-aware orientation detection ===
    function classify_orientation_after_exif(string $imageData): ?string {
        $size = @getimagesizefromstring($imageData);
        if (!$size || !isset($size[0], $size[1])) {
            return null;
        }
        $width  = (int)$size[0];
        $height = (int)$size[1];

        $mime = $size['mime'] ?? '';
        if ($mime === 'image/jpeg' && function_exists('exif_read_data')) {
            $tmp = @tempnam(sys_get_temp_dir(), 'exif_');
            if ($tmp !== false) {
                @file_put_contents($tmp, $imageData);
                $exif = @exif_read_data($tmp);
                @unlink($tmp);

                if (!empty($exif['Orientation'])) {
                    $orientation = (int)$exif['Orientation'];
                    if ($orientation === 6 || $orientation === 8) {
                        $t = $width; $width = $height; $height = $t;
                    }
                }
            }
        }
        return ($width >= $height) ? 'horizontal' : 'vertical';
    }

    // === Helper: Fix orientation physically with Imagick ===
    function fixImageOrientation($binaryData) {
        $img = new Imagick();
        $img->readImageBlob($binaryData);

        switch ($img->getImageOrientation()) {
            case Imagick::ORIENTATION_BOTTOMRIGHT:
                $img->rotateImage("#000", 180);
                break;
            case Imagick::ORIENTATION_RIGHTTOP:
                $img->rotateImage("#000", 90);
                break;
            case Imagick::ORIENTATION_LEFTBOTTOM:
                $img->rotateImage("#000", -90);
                break;
        }

        $img->setImageOrientation(Imagick::ORIENTATION_TOPLEFT);
        $fixed = $img->getImageBlob();
        $img->destroy();

        return $fixed;
    }

    $sql = "SELECT 
                image1, image2, image3, image4, 
                image6, image7, image8, image9, 
                image10, image11, image12, image13, image14, image15, image16, image17, image18, image19, image20
            FROM final_uploaded_images 
            WHERE reference_id = ?";

    $stmt = $conn->prepare($sql);
    if ($stmt === false) {
        die("Error preparing the SQL statement: " . htmlspecialchars($conn->error));
    }

    $stmt->bind_param("s", $reference_id);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result && $result->num_rows > 0) {
        $horizontal_images = [];
        $vertical_images   = [];

        while ($row = $result->fetch_assoc()) {
            foreach ($row as $key => $imageData) {
                if (!empty($imageData)) {

                    // Actually fix image before displaying
                    $fixedData = fixImageOrientation($imageData);

                    $orientation = classify_orientation_after_exif($fixedData) ?? 'horizontal';
                    $imgString   = base64_encode($fixedData);
                    $caption     = $captions[$key] ?? 'Image';

                    $item = [
                        'data'    => $imgString,
                        'caption' => $caption,
                        'alt'     => $key,
                    ];

                    if ($orientation === 'horizontal') {
                        $horizontal_images[] = $item;
                    } else {
                        $vertical_images[]   = $item;
                    }
                }
            }
        }

 
// Output as a stable 4-column table (works in wkhtmltopdf)
$all_images = array_merge($vertical_images, $horizontal_images);

echo '<table class="image-grid">';
$rows = array_chunk($all_images, 4);
foreach ($rows as $row) {
    echo '<tr>';
    foreach ($row as $img) {
        echo '<td>';
        echo '<div class="img-wrap">';
        echo '<img src="data:image/jpeg;base64,' . $img['data'] . '" alt="' . htmlspecialchars($img['alt']) . '">';
        echo '<div class="caption">' . htmlspecialchars($img['caption']) . '</div>';
        echo '</div>';
        echo '</td>';
    }
    // pad remaining cells to keep 4 columns
    $remaining = 4 - count($row);
    if ($remaining > 0) {
        echo str_repeat('<td></td>', $remaining);
    }
    echo '</tr>';
}
echo '</table>';

    } else {
        echo "<p style='text-align:center;'>No images found.</p>";
    }

    $stmt->close();
} else {
    echo "<p style='text-align:center;'>Reference ID is missing.</p>";
}
?>

    
      <table>
  </tr>
  <tr>

<div class="google-map-container">
<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "project_db";
$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$reference_id = $_SESSION['reference_id'] ?? null;
$reference_id = $_GET['reference_id'] ?? $reference_id;

if ($reference_id) {
    $sql = "SELECT image5 FROM final_uploaded_images WHERE reference_id = ?";
    $stmt = $conn->prepare($sql);
    if ($stmt === false) {
        die("Error preparing the SQL statement: " . $conn->error);
    }

    $stmt->bind_param("s", $reference_id);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows > 0) {
        $row = $result->fetch_assoc();
        if (!empty($row['image5'])) {
 
            echo '<div><img src="data:image/jpeg;base64,' . base64_encode($row['image5']) . '" alt="Google Map"><p>Google Map</p></div>';
        } else {
            echo "<p style='text-align:center;'>Google Map image not available.</p>";
        }
    } else {
        echo "<p style='text-align:center;'>No record found for Google Map image.</p>";
    }

    $stmt->close();
} else {
    echo "<p style='text-align:center;'>Reference ID is missing.</p>";
}
?>
</tr>
</div>
    </table>
    </table>
     <!-- <button onclick="window.print()">Download PDF</button> -->
    <form method="post">
  <input type="hidden" name="download_images" value="1">
  <button type="submit">Download All Images</button>
</form>
     <!-- <button onclick="window.print()">Download PDF</button> -->
  <button id="downloadPdf" onclick="setPrintMargins()">DOWNLOAD PDF</button>
  <script>
    document.getElementById('downloadPdf').addEventListener('click', () => {
      // Select the content you want to convert to PDF
      const element = document.getElementById('content');
      const options = {
        margin:[0,0],
        filename:'report.pdf',
        image: { type: 'jpeg', quality: 0.98 },
        html2canvas: { scale: 2 },
        jsPDF: { unit: 'in', format: 'letter', orientation: 'portrait' }
      };

      // Generate and download the PDF
      html2pdf().set(options).from(element).save();
    });
    function setPrintMargins() {
      const style = document.createElement('style');
      style.innerHTML = `
      @media print {
          body {
            margin:0.2;
          }
        }
      `;
      document.head.appendChild(style);
      window.print();
    }
    // Disable all input fields in the form
    document.querySelectorAll('input').forEach(function(input) {
        input.disabled = true;  // Disables the field completely
    });
    </script>
     </div>
    
</body>
</html>
