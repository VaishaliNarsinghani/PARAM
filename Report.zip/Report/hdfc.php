<?php include('auth.php'); ?>
<?php include 'watermark.html'; ?><?php
// Start session

$servername = "localhost";
$username = "root";
$password = "";
$dbname = "project_db";

// Create DB connection
$conn = new mysqli($servername, $username, $password, $dbname);
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

if (!isset($_SESSION['reference_id'])) {
    die("Reference ID not found in session.");
}
$reference_id = $_SESSION['reference_id'];

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['download_images'])) {

    // Get customer name
    $stmt_name = $conn->prepare("SELECT customerName FROM mis WHERE reference_id = ?");
    $stmt_name->bind_param("s", $reference_id);
    $stmt_name->execute();
    $result_name = $stmt_name->get_result();
    $customerName = "customer";
    if ($row = $result_name->fetch_assoc()) 
    {
        $customerName = preg_replace('/[^a-zA-Z0-9]/', '', $row['customerName']);
    }
    $stmt_name->close();

    // Fetch image BLOBs
    $stmt = $conn->prepare("SELECT image1, image2, image3, image4, image5, image6, image7, image8, image9, image10, image11, image12,image13, image14, image15, image16, image17, image18, image19, image20 FROM final_uploaded_images WHERE reference_id = ?");    $stmt->bind_param("s", $reference_id);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows > 0 && ($row = $result->fetch_assoc())) {
        $tempDir = sys_get_temp_dir() . DIRECTORY_SEPARATOR . uniqid('images_', true);
        mkdir($tempDir);

        $imageFiles = [];
        for ($i = 1; $i <= 12; $i++) {
            if (!empty($row["image$i"])) {
                $filename = $tempDir . DIRECTORY_SEPARATOR . "image{$i}.jpg";
                file_put_contents($filename, $row["image$i"]);
                $imageFiles[] = $filename;
            }
        }

        if (empty($imageFiles)) {
            die("No images to download.");
        }

        // Create ZIP
        $zipFileName = "images_" . preg_replace('/[^a-zA-Z0-9]/', '_', $reference_id) . "_{$customerName}.zip";
        $zipPath = $tempDir . DIRECTORY_SEPARATOR . $zipFileName;

        $zip = new ZipArchive();
        if ($zip->open($zipPath, ZipArchive::CREATE) !== TRUE) {
            die("Failed to create ZIP file.");
        }

        foreach ($imageFiles as $file) {
            $zip->addFile($file, basename($file));
        }
        $zip->close();

        // Send ZIP to browser
        header('Content-Type: application/zip');
        header('Content-Disposition: attachment; filename="' . basename($zipFileName) . '"');
        header('Content-Length: ' . filesize($zipPath));
        flush();
        readfile($zipPath);

        // Cleanup
        foreach ($imageFiles as $file) {
            unlink($file);
        }
        unlink($zipPath);
        rmdir($tempDir);
        exit;
    } else {
        echo "<p style='color:red;'>No image data found for this reference ID.</p>";
    }
}

// Fetch data from bank_details table
$sql_property = "SELECT * FROM mis WHERE reference_id = ?";
$stmt_property = $conn->prepare($sql_property);
$stmt_property->bind_param("s", $reference_id);
$stmt_property->execute();
$result_property = $stmt_property->get_result();
$data1 = $result_property->fetch_assoc();

// Fetch data from property_details table
$sql_property = "SELECT * FROM property_details WHERE reference_id = ?";
$stmt_property = $conn->prepare($sql_property);
$stmt_property->bind_param("s", $reference_id);
$stmt_property->execute();
$result_property = $stmt_property->get_result();
$data2= $result_property->fetch_assoc();

// Fetch data from area_valuation table
$sql_area = "SELECT * FROM address_details WHERE reference_id = ?";
$stmt_area = $conn->prepare($sql_area); 
$stmt_area->bind_param("s", $reference_id);
$stmt_area->execute();
$result_area = $stmt_area->get_result();
$data3 = $result_area->fetch_assoc();

// Fetch data from area_valuation table
$sql_area = "SELECT * FROM critical_parameters WHERE reference_id = ?";
$stmt_area = $conn->prepare($sql_area); 
$stmt_area->bind_param("s", $reference_id);
$stmt_area->execute();
$result_area = $stmt_area->get_result();
$data4 = $result_area->fetch_assoc();
 
// Fetch data from area_valuation table
$sql_area = "SELECT * FROM surroundings_details WHERE reference_id = ?";
$stmt_area = $conn->prepare($sql_area); 
$stmt_area->bind_param("s", $reference_id);
$stmt_area->execute();
$result_area = $stmt_area->get_result();
$data5 = $result_area->fetch_assoc();
$stmt_area->close();
 
// Fetch data from area_valuation table
$sql_area = "SELECT * FROM area_valuation WHERE reference_id = ?";
$stmt_area = $conn->prepare($sql_area); 
$stmt_area->bind_param("s", $reference_id);
$stmt_area->execute();
$result_area = $stmt_area->get_result();
$data6 = $result_area->fetch_assoc();
$stmt_area->close();
 
// Fetch data from area_valuation table
$sql_area = "SELECT * FROM floor_details WHERE reference_id = ?";
$stmt_area = $conn->prepare($sql_area); 
$stmt_area->bind_param("s", $reference_id);
$stmt_area->execute();
$result_area = $stmt_area->get_result();
$data8= $result_area->fetch_assoc();
$stmt_area->close();
 
// Fetch data from area_valuation table
$sql_area = "SELECT * FROM technical_details WHERE reference_id = ?";
$stmt_area = $conn->prepare($sql_area); 
$stmt_area->bind_param("s", $reference_id);
$stmt_area->execute();
$result_area = $stmt_area->get_result();
$data9 = $result_area->fetch_assoc();
$stmt_area->close();
 
// Fetch data from area_valuation table
$sql_area = "SELECT * FROM remarks_table WHERE reference_id = ?";
$stmt_area = $conn->prepare($sql_area); 
$stmt_area->bind_param("s", $reference_id);
$stmt_area->execute();
$result_area = $stmt_area->get_result();
$data10 = $result_area->fetch_assoc();
$stmt_area->close();

// Step 1: Fetch the engineer_id from the mis table
$sql_mis = "SELECT engineer_id FROM mis WHERE reference_id = ?";
$stmt_mis = $conn->prepare($sql_mis);
$stmt_mis->bind_param("s", $reference_id);
$stmt_mis->execute();
$result_mis = $stmt_mis->get_result();
$row_mis = $result_mis->fetch_assoc();
$stmt_mis->close(); 

if ($row_mis) {
    $engineer_id = $row_mis['engineer_id'];

    // Step 2: Fetch the engineer's name from engineer_login table
    $sql_engineer = "SELECT name FROM engineer_login WHERE engineer_id = ?";
    $stmt_engineer = $conn->prepare($sql_engineer);
    $stmt_engineer->bind_param("s", $engineer_id);
    $stmt_engineer->execute();
    $result_engineer = $stmt_engineer->get_result();
    $row_engineer = $result_engineer->fetch_assoc();
    $stmt_engineer->close();

    if ($row_engineer) {
        $engineer_name = $row_engineer['name'];
         //echo "Engineer Name: " . $engineer_name;
    } else {
        echo "Engineer not found.";
    }
} else {
    echo "No engineer assigned for this reference_id.";
}

// Step 1: Fetch the engineer_id from the mis table
$sql_mis = "SELECT report_id FROM mis WHERE reference_id = ?";
$stmt_mis = $conn->prepare($sql_mis);
$stmt_mis->bind_param("s", $reference_id);
$stmt_mis->execute();
$result_mis = $stmt_mis->get_result();
$row_mis = $result_mis->fetch_assoc();
$stmt_mis->close(); 

if ($row_mis) {
    $report_id = $row_mis['report_id'];

    // Step 2: Fetch the engineer's name from engineer_login table
    $sql_engineer = "SELECT name FROM report_login WHERE report_id = ?";
    $stmt_engineer = $conn->prepare($sql_engineer);
    $stmt_engineer->bind_param("s", $report_id);
    $stmt_engineer->execute();
    $result_engineer = $stmt_engineer->get_result();
    $row_engineer = $result_engineer->fetch_assoc();
    $stmt_engineer->close();

    if ($row_engineer) {
        $report_name = $row_engineer['name'];
         //echo "Engineer Name: " . $report_name;
    } else {
        echo "Engineer not found.";
    }
} else {
    echo "No engineer assigned for this reference_id.";
}

// Step 1: Fetch the engineer_id from the mis table
$sql_mis = "SELECT report_drafter_to_technical FROM mis WHERE reference_id = ?";
$stmt_mis = $conn->prepare($sql_mis);
$stmt_mis->bind_param("s", $reference_id);
$stmt_mis->execute();
$result_mis = $stmt_mis->get_result();
$row_mis = $result_mis->fetch_assoc();
$stmt_mis->close(); 

if ($row_mis) {
    $report_drafter_to_technical = $row_mis['report_drafter_to_technical'];

    // Step 2: Fetch the engineer's name from engineer_login table
    $sql_engineer = "SELECT name FROM technical_login WHERE technical_manager_id = ?";
    $stmt_engineer = $conn->prepare($sql_engineer);
    $stmt_engineer->bind_param("s", $report_drafter_to_technical);
    $stmt_engineer->execute();
    $result_engineer = $stmt_engineer->get_result();
    $row_engineer = $result_engineer->fetch_assoc();
    $stmt_engineer->close();

    if ($row_engineer) {
        $technical_name = $row_engineer['name'];
        //echo "Engineer Name: " . $technical_name;
    } else {
        echo "Engineer not found.";
    }
} else {
    echo "No engineer assigned for this reference_id.";
}

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="hdfc4.css">
    <link rel="shortcut icon" href="favicon.png" type="image/x-icon"> 
    <title>HDFC Report</title>
    
</head>
<body>
    <div class="container">
        <header>
            <div class="logo">
                <img <img src="images/Magpie_logo.jpg" alt="Magpie Logo">
            </div>
            <div class="header-content">
                <h1>MAGPIE ENGINEERING PVT. LTD.</h1>
                <p>Valuer Designer Architects</p>
                <p>Address : Office no. 201, 2nd floor, Gravity Mall, Mechanic nagar, warehouse road, near vijay nagar, Indore, Madhya Pradesh- 452011</p>
            </div>
        </header>
        <div class="report-header">Valuation Report</div>
        <table>
            <tr>
                <td><b>File No</b></td>
                <td><input type="text "value="<?= $data1['reference_id'] ?? '' ?>"></td>
                <td><b>Project No</b></td>
                <td><input type="text " value="<?= $data1['applicationNo'] ?? '' ?>"></td>
            </tr>
            <tr>
                <td><b>Borrower's Name</b></td>
                 <td><textarea rows="10"  id="remarks" name="engineer_id" oninput="autoResize(this)"><?= $data1['customerName'] ?? '' ?></textarea> 
                <td><b>Type</b></td>
                <td><input type="text " value="<?= $data1['caseType'] ?? '' ?>"></td>
            </tr>
            <tr>
                <td><b>Request Date</b></td>
                <td><input type="date" value="<?= $data1['initiationDate'] ?? '' ?>"></td>
                <td><b>Assigned Agency/Date</b></td>
              <td>Magpie Engineering Pvt. Ltd. <br><input type="text" value="<?= $data1['initiationDate'] ?? '' ?>"></td>
            </tr>
            <tr>
                <td><b>Borrower's Contact Nos</b></td>
                <td><input type="text " value="<?= $data1['customerMob'] ?? '' ?>"></td>
                <td><b>Co-borrower's Contact Nos</b></td>
                <td><input type="text " value="<?= $data1['customerMob'] ?? '' ?>"></td>
            </tr>
            <tr>
                <td><b>Builders Name</b></td>
                <td><input type="text" value="<?= $data10['NA'] ?? '' ?>"></td>
                <td><b>Builder Contact Nos</b></td>
                <td><input type="text" value="<?= $data10['NA'] ?? '' ?>"></td>
            </tr>
            <tr>
                <td><b>Property Name</b></td>
                <td colspan="3"><input type="text " value="<?= $data2['project_name'] ?? '' ?>"></td>
            </tr>
            <tr>
                <td><b>Property Address</b></td>
                <td colspan="3"><textarea rows="10"  id="remarks" name="engineer_id" oninput="autoResize(this)"><?= $data3['address_line_1_as_per_doc'] ?? '' ?></textarea>
            </tr>
            <tr>
                <td><b>Property Address visited by Engineer (If Different)</b></td>
                <td colspan="3"><textarea rows="10"  id="remarks" name="engineer_id" oninput="autoResize(this)"><?= $data3['address_per_site'] ?? '' ?></textarea></td>
            </tr>
            <tr>
                <td><b>Building Name / Society Name (As per Sv)</b></td>
                <td colspan="3"><input type="text" value="<?= $data2['project_name'] ?? '' ?>"></td>
            </tr>
            <tr>
                <td><b>Valuation of</b></td>
                <td><input type="text" value="<?= $data10['NA'] ?? '' ?>"></td>
                <td><b>Property Category</b></td>
                <td><input type="text" value="<?= $data2['property_unit_type'] ?? '' ?>"></td>
            </tr>
            <tr>
                <td><b>Stage of construction/progress</b></td>
                <td colspan="3"><input type="text" value="<?= $data8['description_stage_construction_allotted'] ?? '' ?>"></td>
            </tr>
            <tr>
                <td><b> % Progress </b></td>
                <td colspan="3"><input type="text" value="<?= $data8['total_completion_present'] ?? '' ?>"></td>
            </tr>
        </table>
        <table>
            <tr>
                <th>Progress Remarks</th>
                <td colspan="3"><input type="text" value="<?= $data8['description_stage_construction_allotted']  ?? '' ?>"></td>
            </tr>
            <tr>
                <th>Total No of floors</th>
                <td><input type="text" value="<?= $data10['NA'] ?? '' ?>"></td>
                <th>Property type*</th>
                <td><input type="text" value="<?= $data2['property_unit_type'] ?? '' ?>"></td>
            </tr>
            <tr>
                <th>Status of property</th>  
                <td><input type="text" value="<?= $data2['occupancy_status'] ?? '' ?>"></td>
                <th>Name of the tenant</th>
                <td><input type="text" value="<?= $data10['NA'] ?? '' ?>"></td>
            </tr>
            <tr>
                <th>For how long tenant is occupying the property (Months/Years)</th>
                <td><input type="text" value="<?= $data2['NA'] ?? '' ?>"></td>
                <th>Rent being paid (approx) Rs./Month</th>
                <td><input type="text" value="<?= $data10['NA'] ?? '' ?>"></td>
            </tr>
            <tr>
                <th>Door Locked</th>
                <td><input type="text" value="<?= $data2['NA'] ?? '' ?>"></td>
                <th>For how long is this property locked (Months/Years)</th>
                <td><input type="text" value="<?= $data10['NA'] ?? '' ?>"></td>
            </tr>
            <tr>
                <th>Name of the owner</th>
                <td colspan="3"><input type="text" value="<?= $data9['owner_name'] ?? '' ?>"></td>
            </tr>
            <tr>
                <th>Name mentioned on society board (for Society/builder flats)</th>
                <td colspan="3"><input type="text" value="<?= $data10['NA'] ?? '' ?>"></td>
            </tr>
            <tr>
                <th>Comments</th>
                <td  colspan="3"><input type="text" value="<?= $data2['infra_building']?? '' ?>"></td>
            </tr>
            <tr>
                <th>Infrastructure & surrounding development</th>
                <td  colspan="3"><input type="text" value="<?= $data2['infra_building'] ?? '' ?> <?= $data2['develop_percent'] ?? '' ?>"></td>
            </tr>
            <tr>
                <th>Age of building (approx)</th>
                <td  colspan="3"><input type="text" value="<?= $data2['age_of_property'] ?? '' ?>"></td>
            </tr>
            <tr>
                <th>Nearby Popular Land Mark</th>
                <td  colspan="3"><input type="text" value="<?= $data3['landmark_1'] ?? '' ?>  <?= $data3['landmark_2'] ?? '' ?>"></td>
            </tr>
        </table>
        <div class="header">
            Valuation of the property: Unit Considered: 
            <input type="text" value="<?= $data10['NA'] ?? '' ?>" class="red-input" placeholder="Sqft">
            Area Considered: 
            <input type="text" value="<?= $data10['NA'] ?? '' ?>" class="red-input" placeholder="BUA">
        </div>        
        <table>
            <tr>
                <th>Description</th>
                <th>Area (Sqft)</th>
                <th>Rate (Rs.)</th>
                <th>Total</th>
            </tr>
            <tr>
                <td>Plot Area in sqm (if applicable)</td>
                <td><input type="text" value="<?= $data6['actual_plot_square_feet'] ?? '' ?>"></td>
                <td><input type="text" value="<?= $data6['actual_plot_rate'] ?? '' ?>"></td>
                <td><input type="text" value="<?= $data6['actual_plot_valuation_computed'] ?? '' ?>"></td>
            </tr>
            <tr>
                <td>Carpet area</td>
                <td><input type="text" value="<?= $data6['actual_carpet_square_feet'] ?? '' ?>"></td>
                <td><input type="text" value="<?= $data6['actual_carpet_rate'] ?? '' ?>"></td>
                <td><input type="text" value="<?= $data6['actual_carpet_valuation_computed'] ?? '' ?>"></td>
            </tr>
            <tr>
                <td>BUA area</td>
                <td><input type="text" value="<?= $data6['actual_construction_square_feet'] ?? '' ?>"></td>
                <td><input type="text" value="<?= $data6['actual_construction_rate'] ?? '' ?>"></td>
                <td><input type="text" value="<?= $data6['actual_construction_valuation_computed'] ?? '' ?>"></td>
            </tr>
            <tr>
                <td>Super BUA area</td>
                <td><input type="text" value="<?= $data6['actual_saleable_square_feet'] ?? '' ?>"></td>
                <td><input type="text" value="<?= $data6['actual_saleable_rate'] ?? '' ?>"></td>
                <td><input type="text" value="<?= $data6['actual_saleable_valuation_computed'] ?? '' ?>"></td>
            </tr>
            <tr>
                <th colspan="4">Others</th>
            </tr>
            <tr>
                <td>Terrace area</td>
                <td><input type="text" value="<?= $data10['NA'] ?? '' ?>"></td>
                <td><input type="text" value="<?= $data10['NA'] ?? '' ?>"></td>
                <td><input type="text" value="<?= $data10['NA'] ?? '' ?>"></td>
            </tr>
            <tr>
                <td>Parking Charges</td>
                <td><input type="text" value="<?= $data10['NA'] ?? '' ?>"></td>
                <td><input type="text" value="<?= $data10['NA'] ?? '' ?>"></td>
                <td><input type="text" value="<?= $data10['NA'] ?? '' ?>"></td>
            </tr>
            <tr>
                <td>Others (Free Field to update others)</td>
                <td><input type="text" value="<?= $data10['NA'] ?? '' ?>"></td>
                <td><input type="text" value="<?= $data10['NA'] ?? '' ?>"></td>
                <td><input type="text" value="<?= $data10['NA'] ?? '' ?>"></td>
            </tr>
            <!--BANNA RAJVEER SINGH THAKUR TAPPA-->
            <tr>
    <th colspan="3">Total Value (approx.)</th>
    <td>
        <input type="text" value="<?= ($data7['total_actual_area_valuation'] ?? 0) + ($data6['amenities_total'] ?? 0) ?>">
    </td>
</tr>

            <tr>
                <td colspan="4" class="market-value">Market value (Rs.) <input type="text" value="<?= $data7['total_valuation'] ?? '' ?>"></td>
            </tr>
        </table>
        <div class="geo-tagging">
            <div class="geo-header">GeoTagging: (Update Latitude and Longitude  tails)</div>
            <table>
                <tr>
                    <td>Latitude <input type="text" value="<?= $data3['latitude_value'] ?? '' ?>" placeholder="Enter Latitude"></td>
                    <td>Longitude <input type="text" value="<?= $data3['longitude_value'] ?? '' ?>" placeholder="Enter Longitude"></td>
                </tr>
            </table>
        </div>
        
        
        <div class="header">Boundaries of the property</div>

    <table class="boundary-table">
        <tr>
            <th>Description</th>
            <th>East</th>
            <th>West</th>
            <th>North</th>
            <th>South</th>
        </tr>
        <tr>
            <td>As per approved plan</td>
            <td><input type="text" value="<?= $data3['direction_approved_east'] ?? '' ?>" placeholder="Enter Data"></td>
            <td><input type="text" value="<?= $data3['direction_approved_west'] ?? '' ?>" placeholder="Enter Data"></td>
            <td><input type="text" value="<?= $data3['direction_approved_north'] ?? '' ?>" placeholder="Enter Data"></td>
            <td><input type="text" value="<?= $data3['direction_approved_south'] ?? '' ?>" placeholder="Enter Data"></td>
        </tr>
        <tr>
            <td>As per site</td>
            <td><input type="text" value="<?= $data3['direction_as_per_site_east'] ?? '' ?>" placeholder="Enter Data"></td>
            <td><input type="text" value="<?= $data3['direction_as_per_site_west'] ?? '' ?>" placeholder="Enter Data"></td>
            <td><input type="text" value="<?= $data3['direction_as_per_site_north'] ?? '' ?>" placeholder="Enter Data"></td>
            <td><input type="text" value="<?= $data3['direction_as_per_site_south'] ?? '' ?>" placeholder="Enter Data"></td>
        </tr>
    </table>

    <table class="details-table">
        <tr>
            <td><b>Latitude</b></td>
            <td><input type="text" value="<?= $data3['latitude_value'] ?? '' ?>" placeholder="Enter Latitude"></td>
        </tr>
        <tr>
            <td><b>Longitude</b></td>
            <td><input type="text" value="<?= $data3['longitude_value'] ?? '' ?>" placeholder="Enter Longitude"></td>
        </tr>
        <tr>
            <td><b>Remarks</b></td>
            <td><textarea rows="10"  id="remarks" name="engineer_id" oninput="autoResize(this)"><?= $data10['remarks'] ?? '' ?></textarea></td>
        </tr>
        <tr>
            <td><b>Deviations</b></td>
            <td><input type="text" value="<?= $data9['fsi_deviation'] ?? '' ?>    <?= $data9['vertical_deviation'] ?? '' ?>"></td>
        </tr>
        <tr>
            <td><b>Property Visited by:</b></td>
            <td><input type="text"  value="<?= $engineer_name ?>"></td>
        </tr>
        <tr>
            <td><b>Name of the verifier</b></td>
            <td><input type="text" value="<?= $technical_name ?>"></td>
        </tr>
        <tr>
            <td><b>Date of Site Visit</b></td>
            <td><input type="text" name="engineer_id"  value="<?= $data1['report_assigned_at'] ?? '' ?>"></td>
        </tr>
        <tr>
            <td><b>Report sent to HDFC Date</b></td>
            <td><input type="text" name="engineer_id"  value="<?= $data1['report_assigned_at'] ?? '' ?>"></td>
        </tr>
    </table>

    <!-- Signature Section -->
    <div class="signature-container">
        <div class="signature-box">
            <p class="signature-name">SANJAY SAINI</p>
            <img src="signature.png" alt="Signature" class="signature-img">
        </div>
    </div>
   </div>
  
  
<h3 style="margin-bottom:-18px;">PHOTOGRAPH OF THE PROPERTY</h3>
<br>

<br>
<div class="container">
    <div class="image-gallery">
<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "project_db";
$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$reference_id = $_SESSION['reference_id'] ?? null;
$reference_id = $_GET['reference_id'] ?? $reference_id;

if ($reference_id) {
    $sql = "SELECT 
                image1, image2, image3, image4, 
                image6, image7, image8, image9, 
                image10, image11, image12,image13, image14, image15, image16, image17, image18, image19, image20
            FROM final_uploaded_images 
            WHERE reference_id = ?";

    $stmt = $conn->prepare($sql);
    if ($stmt === false) {
        die("Error preparing the SQL statement: " . $conn->error);
    }

    $stmt->bind_param("s", $reference_id);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows > 0) {
        while ($row = $result->fetch_assoc()) {
            if (!empty($row['image1'])) {
                echo '<div><img src="data:image/jpeg;base64,' . base64_encode($row['image1']) . '" alt="Image 1"><p>EXTERNAL PHOTOS</p></div>';
            }
            if (!empty($row['image2'])) {
                echo '<div><img src="data:image/jpeg;base64,' . base64_encode($row['image2']) . '" alt="Image 2"><p>Kitchen</p></div>';
            }
            if (!empty($row['image3'])) {
                echo '<div><img src="data:image/jpeg;base64,' . base64_encode($row['image3']) . '" alt="Image 3"><p>Selfie</p></div>';
            }
            if (!empty($row['image4'])) {
                echo '<div><img src="data:image/jpeg;base64,' . base64_encode($row['image4']) . '" alt="Image 4"><p>Electric Meter</p></div>';
            }
            if (!empty($row['image6'])) {
                echo '<div><img src="data:image/jpeg;base64,' . base64_encode($row['image6']) . '" alt="Image 6"><p>Other 1</p></div>';
            }
            if (!empty($row['image7'])) {
                echo '<div><img src="data:image/jpeg;base64,' . base64_encode($row['image7']) . '" alt="Image 7"><p>Other 2</p></div>';
            }
            if (!empty($row['image8'])) {
                echo '<div><img src="data:image/jpeg;base64,' . base64_encode($row['image8']) . '" alt="Image 8"><p>Other 3</p></div>';
            }
            if (!empty($row['image9'])) {
                echo '<div><img src="data:image/jpeg;base64,' . base64_encode($row['image9']) . '" alt="Image 9"><p>Other 4</p></div>';
            }
            if (!empty($row['image10'])) {
                echo '<div><img src="data:image/jpeg;base64,' . base64_encode($row['image10']) . '" alt="Image 10"><p>Other 5</p></div>';
            }
            if (!empty($row['image11'])) {
                echo '<div><img src="data:image/jpeg;base64,' . base64_encode($row['image11']) . '" alt="Image 11"><p>Other 6</p></div>';
            }
            if (!empty($row['image12'])) {
                echo '<div><img src="data:image/jpeg;base64,' . base64_encode($row['image12']) . '" alt="Image 12"><p>Other 7</p></div>';
            }
            if (!empty($row['image13'])) {
    echo '<div><img src="data:image/jpeg;base64,' . base64_encode($row['image13']) . '" alt="Image 13"><p>Other 8</p></div>';
}
if (!empty($row['image14'])) {
    echo '<div><img src="data:image/jpeg;base64,' . base64_encode($row['image14']) . '" alt="Image 14"><p>Other 9</p></div>';
}
if (!empty($row['image15'])) {
    echo '<div><img src="data:image/jpeg;base64,' . base64_encode($row['image15']) . '" alt="Image 15"><p>Other 10</p></div>';
}
if (!empty($row['image16'])) {
    echo '<div><img src="data:image/jpeg;base64,' . base64_encode($row['image16']) . '" alt="Image 16"><p>Other 11</p></div>';
}
if (!empty($row['image17'])) {
    echo '<div><img src="data:image/jpeg;base64,' . base64_encode($row['image17']) . '" alt="Image 17"><p>Other 12</p></div>';
}
if (!empty($row['image18'])) {
    echo '<div><img src="data:image/jpeg;base64,' . base64_encode($row['image18']) . '" alt="Image 18"><p>Other 13</p></div>';
}
if (!empty($row['image19'])) {
    echo '<div><img src="data:image/jpeg;base64,' . base64_encode($row['image19']) . '" alt="Image 19"><p>Other 14</p></div>';
}
if (!empty($row['image20'])) {
    echo '<div><img src="data:image/jpeg;base64,' . base64_encode($row['image20']) . '" alt="Image 20"><p>Other 15</p></div>';
}
        }
    } else {
        echo "<p style='text-align:center;'>No images found.</p>";
    }

    $stmt->close();
} else {
    echo "<p style='text-align:center;'>Reference ID is missing.</p>";
}
?>
    </div>
</div>

     <!-- <button onclick="window.print()">Download PDF</button> -->
    <form method="post">
  <input type="hidden" name="download_images" value="1">
  <button type="submit">Download All Images</button>
</form>
     <!-- <button onclick="window.print()">Download PDF</button> -->
  <button id="downloadPdf" onclick="setPrintMargins()">DOWNLOAD PDF</button>
  <script>
    document.getElementById('downloadPdf').addEventListener('click', () => {
      // Select the content you want to convert to PDF
      const element = document.getElementById('content');
      const options = {
        margin:[0,0],
        filename:'report.pdf',
        image: { type: 'jpeg', quality: 0.98 },
        html2canvas: { scale: 2 },
        jsPDF: { unit: 'in', format: 'letter', orientation: 'portrait' }
      };

      // Generate and download the PDF
      html2pdf().set(options).from(element).save();
    });
    function setPrintMargins() {
      const style = document.createElement('style');
      style.innerHTML = `
      @media print {
          body {
            margin:0.5;
          }
        }
      `;
      document.head.appendChild(style);
      window.print();
    }
    // Disable all input fields in the form
    document.querySelectorAll('input').forEach(function(input) {
        input.disabled = true;  // Disables the field completely
    });
    </script>
     </div>

</body>
</html>
