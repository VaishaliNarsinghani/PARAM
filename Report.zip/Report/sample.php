<?php include('auth.php'); ?>
<?php include 'watermark.html'; ?><?php

 // Start the session

$message = "";

// Check if the form is submitted
if ($_SERVER["REQUEST_METHOD"] === "POST") {
    if (isset($_POST['action']) && $_POST['action'] === 'save') {
        // Save form data in the session
        $_SESSION['address_details'] = array_map(function ($item) {
            return $item ?: ''; // Replace empty fields with an empty string
        }, $_POST);

        $message = "Address details saved successfully!";
    } elseif (isset($_POST['action']) && $_POST['action'] === 'submit') {
        // Simulate saving all data to the database or other persistent storage
        // Clear session data after submission
        unset($_SESSION['address_details']);

        // Redirect to the next page
        header("Location: REPORT3.php");
        exit();
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Property Details Form</title>
    <link rel="stylesheet" href="REPORT02.css">
    <style>
        /* Modal styles */
        .modal {
            display: none;
            position: fixed;
            z-index: 1000;
            left: 0;
            top: 0;
            width: 100%;
            height: 100%;
            overflow: auto;
            background-color: rgba(0, 0, 0, 0.5);
        }
        .modal-content {
            background-color: #fefefe;
            margin: 15% auto;
            padding: 20px;
            border: 1px solid #888;
            width: 50%;
            text-align: center;
            border-radius: 8px;
        }
        .modal-content h2 {
            color: #3c763d;
            margin-bottom: 20px;
        }
        .modal-content button {
            padding: 10px 20px;
            background-color: #3c763d;
            color: white;
            border: none;
            border-radius: 5px;
            cursor: pointer;
        }
        .modal-content button:hover {
            background-color: #2e6a4b;
        }
        .modal-show {
            display: block;
        }
    </style>
    <script>
        // JavaScript to display the modal
        function showModal(message) {
            const modal = document.getElementById('myModal');
            const modalMessage = document.getElementById('modalMessage');
            modalMessage.innerText = message;
            modal.classList.add('modal-show');
        }

        function closeModal() {
            const modal = document.getElementById('myModal');
            modal.classList.remove('modal-show');
        }
    </script>
</head>
<body>
<div class="form-container">
    <!-- Modal -->
    <div id="myModal" class="modal">
        <div class="modal-content">
            <h2 id="modalMessage"></h2>
            <button onclick="closeModal()">Close</button>
        </div>
    </div>

    <!-- PHP to trigger modal -->
    <?php if (!empty($message)): ?>
        <script>
            showModal("<?= htmlspecialchars($message) ?>");
        </script>
    <?php endif; ?>

    <!-- Tab Navigation -->
    <div class="tab-links">
        <button class="tab"> <a href="REPORT3.php">BANK DETAILS</a></button>
        <button class="tab"> <a href="REPORT4.php">GENERAL DETAILS</a></button>
        <button class="tab active"> <a href="REPORT2.php">ADDRESS</a></button>
        <button class="tab"> <a href="REPORT5.php">PARAMETERS</a></button>
        
        <button class="tab"> <a href="REPORT7.php">AREA</a></button>
        <button class="tab"> <a href="REPORT8.php">COST</a></button>
        <button class="tab"> <a href="REPORT9.php">FLOOR DETAILS</a></button>
        <button class="tab"> <a href="REPORT10.php">TECHNICAL DETAILS</a></button>
        <button class="tab"> <a href="REPORT115.php">PHOTOS</a></button>
        <button class="tab"> <a href="REPORT12.php">REMARK</a></button>
    </div>

    <!-- Address Form -->
    <form action="" method="POST" style="width: 88%;">
        <div class="header">
            (PLEASE ENTER "NA" IN CASE FIELD DETAILS ARE NOT AVAILABLE/APPLICABLE IN ADDRESS FORM BELOW)
        </div>
        <table>
            <?php
            $fields = [
                'HOUSE/FLAT NO.' => 'house_flat_no',
                'FLOOR NO.' => 'floor_no',
                'WING NAME & NO.' => 'wing_name_no',
                'BUILDING NAME & NO.' => 'building_name_no',
                'PROJECT NAME/SOCIETY NAME' => 'project_society_name',
                'PLOT NO.' => 'plot_no',
                'SURVEY NO.' => 'survey_no',
                'STAGE/SECTOR/WARD NO.' => 'stage_sector_ward_no',
                'STREET NAME & NO.' => 'street_name_no',
                'VILLAGE/LOCATION' => 'village_location',
                'LANDMARK 1' => 'landmark_1',
                'LANDMARK 2' => 'landmark_2',
                'PIN CODE' => 'pin_code',
                'PIN CODE AREA' => 'pin_code_area',
                'CITY / TALUKA/TOWN' => 'city_taluka_town',
                'DISTRICT' => 'district',
                'LATITUDE VALUE' => 'latitude_value',
                'LONGITUDE VALUE' => 'longitude_value',
                'STATE' => 'state',
                'NEAREST JMFHL LOCATION' => 'nearest_jmfhl_location',
                'DISTANCE FROM JMFHL LOCATION (KMS)' => 'distance_from_jmfhl_kms'
            ];
            $count = 0;
            echo '<tr>';
            foreach ($fields as $label => $name) {
                $value = htmlspecialchars($_SESSION['address_details'][$name] ?? '');
                echo "<td>$label</td>
                      <td><input type='text' name='$name' value='$value' placeholder='NA'></td>";
                $count++;
                if ($count % 3 === 0) {
                    echo '</tr><tr>';
                }
            }
            echo '</tr>';
            ?>
        </table>
        <div class="submit-button">
            <button type="submit" name="action" value="save">Save</button>
            <button type="submit" name="action" value="submit">Submit</button>
        </div>
    </form>

    <div class="side-buttons">
        <button type="button"><img src="https://www.iconpacks.net/icons/1/free-document-icon-901-thumb.png" alt="" width="35px" height="35px"></button>
        <button type="button"><img src="https://cdn-icons-png.flaticon.com/512/25/25666.png" alt="" width="35px" height="35px"></button>       
        <button type="button"><img src="https://cdn-icons-png.flaticon.com/512/535/535239.png" alt="" width="35px" height="35px"></button>
        <button type="button"><img src="https://cdn-icons-png.flaticon.com/512/1456/1456888.png" alt="" width="35px" height="35px"></button>
    </div>
</div>
</body>
</html>
