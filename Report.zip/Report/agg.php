
<script>
    function toggleFields() {
        var propertyType = document.getElementById("propertyType").value;
       

        var plotSquareFeet = document.getElementById("plot_square_feet"),
    plotRate = document.getElementById("plot_rate"),
    plotValuationComputed = document.getElementById("plot_valuation_computed"),
    carpetSquareFeet = document.getElementById("carpet_square_feet"),
    carpetRate = document.getElementById("carpet_rate"),
    carpetValuationComputed = document.getElementById("carpet_valuation_computed"),
    constructionSquareFeet = document.getElementById("construction_square_feet"),
    constructionRate = document.getElementById("construction_rate"),
    constructionValuationComputed = document.getElementById("construction_valuation_computed"),
    saleableSquareFeet = document.getElementById("saleable_square_feet"),
    saleableRate = document.getElementById("saleable_rate"),
    saleableValuationComputed = document.getElementById("saleable_valuation_computed"),
    totalAreaValuation = document.getElementById("total_area_valuation"),
    actualPlotSquareFeet = document.getElementById("actual_plot_square_feet"),
    actualPlotRate = document.getElementById("actual_plot_rate"),
    actualPlotValuationComputed = document.getElementById("actual_plot_valuation_computed"),
    actualCarpetSquareFeet = document.getElementById("actual_carpet_square_feet"),
    actualCarpetRate = document.getElementById("actual_carpet_rate"),
    actualCarpetValuationComputed = document.getElementById("actual_carpet_valuation_computed"),
    actualConstructionSquareFeet = document.getElementById("actual_construction_square_feet"),
    actualConstructionRate = document.getElementById("actual_construction_rate"),
    actualConstructionValuationComputed = document.getElementById("actual_construction_valuation_computed"),
    actualSaleableSquareFeet = document.getElementById("actual_saleable_square_feet"),
    actualSaleableRate = document.getElementById("actual_saleable_rate"),
    actualSaleableValuationComputed = document.getElementById("actual_saleable_valuation_computed"),
    totalActualAreaValuation = document.getElementById("total_actual_area_valuation"),
    actualPlotSquareFeet = document.getElementById("actual_plot_square_feet"),
    actualPlotRate = document.getElementById("actual_plot_rate"),
    actualPlotValuationComputed = document.getElementById("actual_plot_valuation_computed"),
    actualCarpetSquareFeet = document.getElementById("actual_carpet_square_feet"),
    actualCarpetRate = document.getElementById("actual_carpet_rate"),
    actualCarpetValuationComputed = document.getElementById("actual_carpet_valuation_computed"),
    actualConstructionSquareFeet = document.getElementById("actual_construction_square_feet"),
    actualConstructionRate = document.getElementById("actual_construction_rate"),
    actualConstructionValuationComputed = document.getElementById("actual_construction_valuation_computed"),
    actualSaleableSquareFeet = document.getElementById("actual_saleable_square_feet"),
    actualSaleableRate = document.getElementById("actual_saleable_rate"),
    actualSaleableValuationComputed = document.getElementById("actual_saleable_valuation_computed"),
    totalActualAreaValuation = document.getElementById("total_actual_area_valuation"),
    additionAmenitiesDescription1 = document.getElementById("car_parking"),
    additionAmenitiesAmount1 = document.getElementById("car_parking_amount"),
    additionAmenitiesDescription2 = document.getElementById("addition_amenities_description_2"),
    additionAmenitiesAmount2 = document.getElementById("addition_amenities_amount_2"),
    additionAmenitiesDescription3 = document.getElementById("addition_amenities_description_3"),
    additionAmenitiesAmount3 = document.getElementById("addition_amenities_amount_3"),
    additionAmenitiesDescription4 = document.getElementById("addition_amenities_description_4"),
    additionAmenitiesAmount4 = document.getElementById("addition_amenities_amount_4"),
    amenitiesTotal = document.getElementById("amenities_total"),
    finalPlotSquareFeet = document.getElementById("final_plot_square_feet"),
    finalPlotRate = document.getElementById("final_plot_rate"),
    finallyPlotValuation = document.getElementById("finally_plot_valuation"),
    finallyPlotValuationHidden = document.getElementById("finally_plot_valuation_hidden"),
    finalConstructionSquareFeet = document.getElementById("final_construction_square_feet"),
    finalConstructionRate = document.getElementById("final_construction_rate"),
    finallyConstructionValuation = document.getElementById("finally_construction_valuation"),
    finallyConstructionValuationHidden = document.getElementById("finally_construction_valuation_hidden"),

    dimensionAsPerSiteNorth = document.getElementById("dimension_as_per_site_north"),  
dimensionAsPerSiteSouth = document.getElementById("dimension_as_per_site_south"),  
dimensionAsPerSiteEast = document.getElementById("dimension_as_per_site_east"),  
dimensionAsPerSiteWest = document.getElementById("dimension_as_per_site_west"),  

dimensionAsPerDocumentNorth = document.getElementById("dimension_as_per_document_north"),  
dimensionAsPerDocumentSouth = document.getElementById("dimension_as_per_document_south"),  
dimensionAsPerDocumentEast = document.getElementById("dimension_as_per_document_east"),  
dimensionAsPerDocumentWest = document.getElementById("dimension_as_per_document_west"),  

totalValuation = document.getElementById("total_finally_area_valuation"),  
distressValuePercent = document.getElementById("distress_value_percent"),  
totalDistressValue = document.getElementById("total_distress_value"),  
totalValuationWords = document.getElementById("total_valuation_words"),  
distressValueWords = document.getElementById("distress_value_words"),  
enquiryRemarks = document.getElementById("enquiry_remarks"),  
insurable = document.getElementById("insurable"),
loading = document.getElementById("loading"),

grossMonthlyRental = document.getElementById("gross_monthly_rental"),  
guidelineRate = document.getElementById("guideline_rate"),  
guidelineValue = document.getElementById("guideline_values"),  
replacementCost = document.getElementById("replacement_cost"),
finalareasquarefeet = document.getElementById("final_area_square_feet"),  
finalarearate = document.getElementById("final_area_rate"),


constructionname1 = document.getElementById("construction_name_1"),
constructionareasqft1 = document.getElementById("construction_area_sqft_1"),
constructionrate1 = document.getElementById("construction_rate_1"),
constructionvaluation1 = document.getElementById("construction_valuation_1"),

constructionname2 = document.getElementById("construction_name_2"),
constructionareasqft2 = document.getElementById("construction_area_sqft_2"),
constructionrate2 = document.getElementById("construction_rate_2"),
constructionvaluation2 = document.getElementById("construction_valuation_2"),

constructionname3 = document.getElementById("construction_name_3"),
constructionareasqft3 = document.getElementById("construction_area_sqft_3"),
constructionrate3 = document.getElementById("construction_rate_3"),
constructionvaluation3 = document.getElementById("construction_valuation_3");


        if (propertyType === "select") {
            plotSquareFeet.setAttribute("readonly", true);
            plotRate.setAttribute("readonly", true);
            carpetSquareFeet.setAttribute("readonly", true);
            carpetRate.setAttribute("readonly", true);
            plotSquareFeet.setAttribute("readonly", true);

plotValuationComputed.setAttribute("readonly", true);
 
carpetValuationComputed.setAttribute("readonly", true);
constructionSquareFeet.setAttribute("readonly", true);
constructionRate.setAttribute("readonly", true);
constructionValuationComputed.setAttribute("readonly", true);
saleableSquareFeet.setAttribute("readonly", true);
saleableRate.setAttribute("readonly", true);
saleableValuationComputed.setAttribute("readonly", true);
totalAreaValuation.setAttribute("readonly", true);
actualPlotSquareFeet.setAttribute("readonly", true);
actualPlotRate.setAttribute("readonly", true);
actualPlotValuationComputed.setAttribute("readonly", true);
actualCarpetSquareFeet.setAttribute("readonly", true);
actualCarpetRate.setAttribute("readonly", true);
actualCarpetValuationComputed.setAttribute("readonly", true);
actualConstructionSquareFeet.setAttribute("readonly", true);
actualConstructionRate.setAttribute("readonly", true);
actualConstructionValuationComputed.setAttribute("readonly", true);
actualSaleableSquareFeet.setAttribute("readonly", true);
actualSaleableRate.setAttribute("readonly", true);
actualSaleableValuationComputed.setAttribute("readonly", true);
totalActualAreaValuation.setAttribute("readonly", true);
car_parking.setAttribute("readonly", true);
car_parking_amount.setAttribute("readonly", true);
addition_amenities_description_2.setAttribute("readonly", true);
addition_amenities_amount_2.setAttribute("readonly", true);
addition_amenities_description_3.setAttribute("readonly", true);
addition_amenities_amount_3.setAttribute("readonly", true);
addition_amenities_description_4.setAttribute("readonly", true);
addition_amenities_amount_4.setAttribute("readonly", true);
amenities_total.setAttribute("readonly", true);
finalPlotSquareFeet.setAttribute("readonly", true);
finalPlotRate.setAttribute("readonly", true);
finalConstructionSquareFeet.setAttribute("readonly", true);
finalConstructionRate.setAttribute("readonly", true);
dimensionAsPerSiteNorth.setAttribute("readonly", true);  
dimensionAsPerSiteSouth.setAttribute("readonly", true);  
dimensionAsPerSiteEast.setAttribute("readonly", true);  
dimensionAsPerSiteWest.setAttribute("readonly", true);  

dimensionAsPerDocumentNorth.setAttribute("readonly", true);  
dimensionAsPerDocumentSouth.setAttribute("readonly", true);  
dimensionAsPerDocumentEast.setAttribute("readonly", true);  
dimensionAsPerDocumentWest.setAttribute("readonly", true);  

totalValuation.setAttribute("readonly", true);  
totalDistressValue.setAttribute("readonly", true);  
totalValuationWords.setAttribute("readonly", true);  
distressValueWords.setAttribute("readonly", true);  
enquiryRemarks.setAttribute("readonly", true);  

grossMonthlyRental.setAttribute("readonly", true);  
guidelineRate.setAttribute("readonly", true);  
guidelineValue.setAttribute("readonly", true);  
replacementCost.setAttribute("readonly", true);  
 
finalareasquarefeet.setAttribute("readonly", true);  
finalarearate.setAttribute("readonly", true);

constructionname1.setAttribute("readonly", true);
constructionareasqft1.setAttribute("readonly", true);
constructionrate1.setAttribute("readonly", true);
constructionvaluation1.setAttribute("readonly", true);

constructionname2.setAttribute("readonly", true);
constructionareasqft2.setAttribute("readonly", true);
constructionrate2.setAttribute("readonly", true);
constructionvaluation2.setAttribute("readonly", true);

constructionname3.setAttribute("readonly", true);
constructionareasqft3.setAttribute("readonly", true);
constructionrate3.setAttribute("readonly", true);
constructionvaluation3.setAttribute("readonly", true);

        }
         else if (propertyType === "Land and Building") {
            plotSquareFeet.removeAttribute("readonly" );
            plotRate.removeAttribute("readonly" );
            carpetSquareFeet.removeAttribute("readonly" );
            carpetRate.setAttribute("readonly", true);
            plotSquareFeet.removeAttribute("readonly" );
 constructionSquareFeet.removeAttribute("readonly" );
constructionRate.removeAttribute("readonly" );
 actualPlotSquareFeet.removeAttribute("readonly");
actualPlotRate.removeAttribute("readonly");
 actualCarpetSquareFeet.removeAttribute("readonly");
 actualConstructionSquareFeet.removeAttribute("readonly");
actualConstructionRate.removeAttribute("readonly");
   car_parking.removeAttribute("readonly" );
car_parking_amount.removeAttribute("readonly" );
addition_amenities_description_2.removeAttribute("readonly" );
addition_amenities_amount_2.removeAttribute("readonly" );
addition_amenities_description_3.removeAttribute("readonly" );
addition_amenities_amount_3.removeAttribute("readonly" );
addition_amenities_description_4.removeAttribute("readonly" );
addition_amenities_amount_4.removeAttribute("readonly" );
 finalPlotSquareFeet.removeAttribute("readonly" );
finalPlotRate.removeAttribute("readonly" );
finalConstructionSquareFeet.removeAttribute("readonly" );
finalConstructionRate.removeAttribute("readonly" );
dimensionAsPerSiteNorth.removeAttribute("readonly" );  
dimensionAsPerSiteSouth.removeAttribute("readonly" );  
dimensionAsPerSiteEast.removeAttribute("readonly" );  
dimensionAsPerSiteWest.removeAttribute("readonly" );  

dimensionAsPerDocumentNorth.removeAttribute("readonly" );  
dimensionAsPerDocumentSouth.removeAttribute("readonly" );  
dimensionAsPerDocumentEast.removeAttribute("readonly" );  
dimensionAsPerDocumentWest.removeAttribute("readonly" );  

   
 enquiryRemarks.removeAttribute("readonly" );  

grossMonthlyRental.removeAttribute("readonly" );  
guidelineRate.removeAttribute("readonly" );  
replacementCost.removeAttribute("readonly" ); 

constructionname1.removeAttribute("readonly");
constructionareasqft1.removeAttribute("readonly");
constructionrate1.removeAttribute("readonly");
constructionvaluation1.removeAttribute("readonly");

constructionname2.removeAttribute("readonly");
constructionareasqft2.removeAttribute("readonly");
constructionrate2.removeAttribute("readonly");
constructionvaluation2.removeAttribute("readonly");

constructionname3.removeAttribute("readonly");
constructionareasqft3.removeAttribute("readonly");
constructionrate3.removeAttribute("readonly");
constructionvaluation3.removeAttribute("readonly");

        } else if (propertyType === "Floor Property") {
           
           
            carpetSquareFeet.removeAttribute("readonly", true);
            carpetRate.removeAttribute("readonly", true);
            
 constructionSquareFeet.removeAttribute("readonly", true);
constructionRate.removeAttribute("readonly", true);
 saleableSquareFeet.removeAttribute("readonly", true);
saleableRate.removeAttribute("readonly", true);
  
actualSaleableSquareFeet.removeAttribute("readonly", true);
actualSaleableRate.removeAttribute("readonly", true);
car_parking.removeAttribute("readonly", true);
car_parking_amount.removeAttribute("readonly", true);
addition_amenities_description_2.removeAttribute("readonly", true);
addition_amenities_amount_2.removeAttribute("readonly", true);
 
  
finalareasquarefeet.removeAttribute("readonly", true);  
finalarearate.removeAttribute("readonly", true);

 
   enquiryRemarks.removeAttribute("readonly", true);  

grossMonthlyRental.removeAttribute("readonly", true);  
guidelineRate.removeAttribute("readonly", true);  
   
finalareasquarefeet.removeAttribute("readonly", true);  
finalarearate.removeAttribute("readonly", true);
      
constructionname1.removeAttribute("readonly"  true);
constructionareasqft1.removeAttribute("readonly"  true);
constructionrate1.removeAttribute("readonly"  true);
constructionvaluation1.removeAttribute("readonly"  true);

constructionname2.removeAttribute("readonly"  true);
constructionareasqft2.removeAttribute("readonly"  true);
constructionrate2.removeAttribute("readonly"  true);
constructionvaluation2.removeAttribute("readonly"  true);

constructionname3.removeAttribute("readonly"  true);
constructionareasqft3.removeAttribute("readonly"  true);
constructionrate3.removeAttribute("readonly"  true);
constructionvaluation3.removeAttribute("readonly"  true);

}
    }

    // Apply default behavior when page loads
    window.onload = toggleFields;
</script>      


















<script>
    function toggleFields() {
        var propertyType = document.getElementById("propertyType").value;
       

        var plotSquareFeet = document.getElementById("plot_square_feet"),
    plotRate = document.getElementById("plot_rate"),
    plotValuationComputed = document.getElementById("plot_valuation_computed"),
    carpetSquareFeet = document.getElementById("carpet_square_feet"),
    carpetRate = document.getElementById("carpet_rate"),
    carpetValuationComputed = document.getElementById("carpet_valuation_computed"),
    constructionSquareFeet = document.getElementById("construction_square_feet"),
    constructionRate = document.getElementById("construction_rate"),
    constructionValuationComputed = document.getElementById("construction_valuation_computed"),
    saleableSquareFeet = document.getElementById("saleable_square_feet"),
    saleableRate = document.getElementById("saleable_rate"),
    saleableValuationComputed = document.getElementById("saleable_valuation_computed"),
    totalAreaValuation = document.getElementById("total_area_valuation"),
    actualPlotSquareFeet = document.getElementById("actual_plot_square_feet"),
    actualPlotRate = document.getElementById("actual_plot_rate"),
    actualPlotValuationComputed = document.getElementById("actual_plot_valuation_computed"),
    actualCarpetSquareFeet = document.getElementById("actual_carpet_square_feet"),
    actualCarpetRate = document.getElementById("actual_carpet_rate"),
    actualCarpetValuationComputed = document.getElementById("actual_carpet_valuation_computed"),
    actualConstructionSquareFeet = document.getElementById("actual_construction_square_feet"),
    actualConstructionRate = document.getElementById("actual_construction_rate"),
    actualConstructionValuationComputed = document.getElementById("actual_construction_valuation_computed"),
    actualSaleableSquareFeet = document.getElementById("actual_saleable_square_feet"),
    actualSaleableRate = document.getElementById("actual_saleable_rate"),
    actualSaleableValuationComputed = document.getElementById("actual_saleable_valuation_computed"),
    totalActualAreaValuation = document.getElementById("total_actual_area_valuation"),
    actualPlotSquareFeet = document.getElementById("actual_plot_square_feet"),
    actualPlotRate = document.getElementById("actual_plot_rate"),
    actualPlotValuationComputed = document.getElementById("actual_plot_valuation_computed"),
    actualCarpetSquareFeet = document.getElementById("actual_carpet_square_feet"),
    actualCarpetRate = document.getElementById("actual_carpet_rate"),
    actualCarpetValuationComputed = document.getElementById("actual_carpet_valuation_computed"),
    actualConstructionSquareFeet = document.getElementById("actual_construction_square_feet"),
    actualConstructionRate = document.getElementById("actual_construction_rate"),
    actualConstructionValuationComputed = document.getElementById("actual_construction_valuation_computed"),
    actualSaleableSquareFeet = document.getElementById("actual_saleable_square_feet"),
    actualSaleableRate = document.getElementById("actual_saleable_rate"),
    actualSaleableValuationComputed = document.getElementById("actual_saleable_valuation_computed"),
    totalActualAreaValuation = document.getElementById("total_actual_area_valuation"),
    car_parking = document.getElementById("car_parking"),
    car_parking_amount = document.getElementById("car_parking_amount"),
    additionAmenitiesDescription2 = document.getElementById("addition_amenities_description_2"),
    additionAmenitiesAmount2 = document.getElementById("addition_amenities_amount_2"),
    additionAmenitiesDescription3 = document.getElementById("addition_amenities_description_3"),
    additionAmenitiesAmount3 = document.getElementById("addition_amenities_amount_3"),
    additionAmenitiesDescription4 = document.getElementById("addition_amenities_description_4"),
    additionAmenitiesAmount4 = document.getElementById("addition_amenities_amount_4"),
    amenitiesTotal = document.getElementById("amenities_total"),
    finalPlotSquareFeet = document.getElementById("final_plot_square_feet"),
    finalPlotRate = document.getElementById("final_plot_rate"),
    finallyPlotValuation = document.getElementById("finally_plot_valuation"),
    finallyPlotValuationHidden = document.getElementById("finally_plot_valuation_hidden"),
    finalConstructionSquareFeet = document.getElementById("final_construction_square_feet"),
    finalConstructionRate = document.getElementById("final_construction_rate"),
    finallyConstructionValuation = document.getElementById("finally_construction_valuation"),
    finallyConstructionValuationHidden = document.getElementById("finally_construction_valuation_hidden"),

    dimensionAsPerSiteNorth = document.getElementById("dimension_as_per_site_north"),  
dimensionAsPerSiteSouth = document.getElementById("dimension_as_per_site_south"),  
dimensionAsPerSiteEast = document.getElementById("dimension_as_per_site_east"),  
dimensionAsPerSiteWest = document.getElementById("dimension_as_per_site_west"),  

dimensionAsPerDocumentNorth = document.getElementById("dimension_as_per_document_north"),  
dimensionAsPerDocumentSouth = document.getElementById("dimension_as_per_document_south"),  
dimensionAsPerDocumentEast = document.getElementById("dimension_as_per_document_east"),  
dimensionAsPerDocumentWest = document.getElementById("dimension_as_per_document_west"),  

totalValuation = document.getElementById("total_finally_area_valuation"),  
distressValuePercent = document.getElementById("distress_value_percent"),  
totalDistressValue = document.getElementById("total_distress_value"),  
totalValuationWords = document.getElementById("total_valuation_words"),  
distressValueWords = document.getElementById("distress_value_words"),  
enquiryRemarks = document.getElementById("enquiry_remarks"),  

grossMonthlyRental = document.getElementById("gross_monthly_rental"),  
guidelineRate = document.getElementById("guideline_rate"),  
guidelineValue = document.getElementById("guideline_values"),  
replacementCost = document.getElementById("replacement_cost"),
finalareasquarefeet = document.getElementById("final_area_square_feet"),  
finalarearate = document.getElementById("final_area_rate"),



constructionname1 = document.getElementById("construction_name_1"),
constructionareasqft1 = document.getElementById("construction_area_sqft_1"),
constructionrate1 = document.getElementById("construction_rate_1"),
 

constructionname2 = document.getElementById("construction_name_2"),
constructionareasqft2 = document.getElementById("construction_area_sqft_2"),
constructionrate2 = document.getElementById("construction_rate_2"),
 

constructionname3 = document.getElementById("construction_name_3"),
constructionareasqft3 = document.getElementById("construction_area_sqft_3"),
constructionrate3 = document.getElementById("construction_rate_3");
 


        if (propertyType === "select") {
            plotSquareFeet.setAttribute("readonly", true);
            plotRate.setAttribute("readonly", true);
            carpetSquareFeet.setAttribute("readonly", true);
            carpetRate.setAttribute("readonly", true);
            plotSquareFeet.setAttribute("readonly", true);

plotValuationComputed.setAttribute("readonly", true);
 
carpetValuationComputed.setAttribute("readonly", true);
constructionSquareFeet.setAttribute("readonly", true);
constructionRate.setAttribute("readonly", true);
constructionValuationComputed.setAttribute("readonly", true);
saleableSquareFeet.setAttribute("readonly", true);
saleableRate.setAttribute("readonly", true);
saleableValuationComputed.setAttribute("readonly", true);
totalAreaValuation.setAttribute("readonly", true);
actualPlotSquareFeet.setAttribute("readonly", true);
actualPlotRate.setAttribute("readonly", true);
actualPlotValuationComputed.setAttribute("readonly", true);
actualCarpetSquareFeet.setAttribute("readonly", true);
actualCarpetRate.setAttribute("readonly", true);
actualCarpetValuationComputed.setAttribute("readonly", true);
actualConstructionSquareFeet.setAttribute("readonly", true);
actualConstructionRate.setAttribute("readonly", true);
actualConstructionValuationComputed.setAttribute("readonly", true);
actualSaleableSquareFeet.setAttribute("readonly", true);
actualSaleableRate.setAttribute("readonly", true);
actualSaleableValuationComputed.setAttribute("readonly", true);
totalActualAreaValuation.setAttribute("readonly", true);
car_parking.setAttribute("readonly", true);
car_parking_amount.setAttribute("readonly", true);
addition_amenities_description_2.setAttribute("readonly", true);
addition_amenities_amount_2.setAttribute("readonly", true);
addition_amenities_description_3.setAttribute("readonly", true);
addition_amenities_amount_3.setAttribute("readonly", true);
addition_amenities_description_4.setAttribute("readonly", true);
addition_amenities_amount_4.setAttribute("readonly", true);
amenities_total.setAttribute("readonly", true);
finalPlotSquareFeet.setAttribute("readonly", true);
finalPlotRate.setAttribute("readonly", true);
finalConstructionSquareFeet.setAttribute("readonly", true);
finalConstructionRate.setAttribute("readonly", true);
dimensionAsPerSiteNorth.setAttribute("readonly", true);  
dimensionAsPerSiteSouth.setAttribute("readonly", true);  
dimensionAsPerSiteEast.setAttribute("readonly", true);  
dimensionAsPerSiteWest.setAttribute("readonly", true);  

dimensionAsPerDocumentNorth.setAttribute("readonly", true);  
dimensionAsPerDocumentSouth.setAttribute("readonly", true);  
dimensionAsPerDocumentEast.setAttribute("readonly", true);  
dimensionAsPerDocumentWest.setAttribute("readonly", true);  

totalValuation.setAttribute("readonly", true);  
totalDistressValue.setAttribute("readonly", true);  
totalValuationWords.setAttribute("readonly", true);  
distressValueWords.setAttribute("readonly", true);  
enquiryRemarks.setAttribute("readonly", true);  

grossMonthlyRental.setAttribute("readonly", true);  
guidelineRate.setAttribute("readonly", true);  
guidelineValue.setAttribute("readonly", true);  
replacementCost.setAttribute("readonly", true);  
 
finalareasquarefeet.setAttribute("readonly", true);  
finalarearate.setAttribute("readonly", true);

constructionname1.setAttribute("readonly", true);
constructionareasqft1.setAttribute("readonly", true);
constructionrate1.setAttribute("readonly", true);
 

constructionname2.setAttribute("readonly", true);
constructionareasqft2.setAttribute("readonly", true);
constructionrate2.setAttribute("readonly", true);
 

constructionname3.setAttribute("readonly", true);
constructionareasqft3.setAttribute("readonly", true);
constructionrate3.setAttribute("readonly", true);
 

        }
         else if (propertyType === "Land and Building") {
            plotSquareFeet.removeAttribute("readonly" );
            plotRate.removeAttribute("readonly" );
            carpetSquareFeet.removeAttribute("readonly" );
            carpetRate.setAttribute("readonly", true);
            plotSquareFeet.removeAttribute("readonly" );
 constructionSquareFeet.removeAttribute("readonly" );
constructionRate.removeAttribute("readonly" );
 actualPlotSquareFeet.removeAttribute("readonly");
actualPlotRate.removeAttribute("readonly");
 actualCarpetSquareFeet.removeAttribute("readonly");
 actualConstructionSquareFeet.removeAttribute("readonly");
actualConstructionRate.removeAttribute("readonly");
   car_parking.removeAttribute("readonly" );
car_parking_amount.removeAttribute("readonly" );
addition_amenities_description_2.removeAttribute("readonly" );
addition_amenities_amount_2.removeAttribute("readonly" );
addition_amenities_description_3.removeAttribute("readonly" );
addition_amenities_amount_3.removeAttribute("readonly" );
addition_amenities_description_4.removeAttribute("readonly" );
addition_amenities_amount_4.removeAttribute("readonly" );
 finalPlotSquareFeet.removeAttribute("readonly" );
finalPlotRate.removeAttribute("readonly" );
finalConstructionSquareFeet.removeAttribute("readonly" );
finalConstructionRate.removeAttribute("readonly" );
dimensionAsPerSiteNorth.removeAttribute("readonly" );  
dimensionAsPerSiteSouth.removeAttribute("readonly" );  
dimensionAsPerSiteEast.removeAttribute("readonly" );  
dimensionAsPerSiteWest.removeAttribute("readonly" );  

dimensionAsPerDocumentNorth.removeAttribute("readonly" );  
dimensionAsPerDocumentSouth.removeAttribute("readonly" );  
dimensionAsPerDocumentEast.removeAttribute("readonly" );  
dimensionAsPerDocumentWest.removeAttribute("readonly" );  

   
 enquiryRemarks.removeAttribute("readonly" );  

grossMonthlyRental.removeAttribute("readonly" );  
guidelineRate.removeAttribute("readonly" );  
replacementCost.removeAttribute("readonly" ); 
  

constructionname1.removeAttribute("readonly");
constructionareasqft1.removeAttribute("readonly");
constructionrate1.removeAttribute("readonly");
 

constructionname2.removeAttribute("readonly");
constructionareasqft2.removeAttribute("readonly");
constructionrate2.removeAttribute("readonly");
 

constructionname3.removeAttribute("readonly");
constructionareasqft3.removeAttribute("readonly");
constructionrate3.removeAttribute("readonly");
 
        } else if (propertyType === "Floor Property") {
           
           
            carpetSquareFeet.removeAttribute("readonly", true);
            carpetRate.removeAttribute("readonly", true);
            
 constructionSquareFeet.removeAttribute("readonly", true);
constructionRate.removeAttribute("readonly", true);
 saleableSquareFeet.removeAttribute("readonly", true);
saleableRate.removeAttribute("readonly", true);
  
actualSaleableSquareFeet.removeAttribute("readonly", true);
actualSaleableRate.removeAttribute("readonly", true);
car_parking.removeAttribute("readonly", true);
car_parking_amount.removeAttribute("readonly", true);
addition_amenities_description_2.removeAttribute("readonly", true);
addition_amenities_amount_2.removeAttribute("readonly", true);
 
  
finalareasquarefeet.removeAttribute("readonly", true);  
finalarearate.removeAttribute("readonly", true);

 
   enquiryRemarks.removeAttribute("readonly", true);  

grossMonthlyRental.removeAttribute("readonly", true);  
guidelineRate.removeAttribute("readonly", true);  
   
finalareasquarefeet.removeAttribute("readonly", true);  
finalarearate.removeAttribute("readonly", true);
 

        }
    }

    // Apply default behavior when page loads
    window.onload = toggleFields;
</script>      

