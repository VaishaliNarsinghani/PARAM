<?php include('auth.php'); ?>
<?php


ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

// Increase PHP execution time and memory limit
ini_set('max_execution_time', 600); // Increase execution time to 600 seconds (10 minutes)
ini_set('memory_limit', '4096M'); // Increase memory limit to 4096MB
// Start session


$message = "";  // Feedback message for the user
$reference_id = $_SESSION['reference_id'] ?? null;
$fieldss = $_SESSION['floor_details'] ?? [];
$_SESSION['floor_details'] = $fieldss; // where $fieldss does not explicitly contain reference_id

// Step 1: Check for old_reference_id in mis table only if we don't have session data
if ($reference_id && empty($_SESSION['floor_details'])) {
    $servername = "localhost";
    $username = "root";
      $password = "";    $dbname = "project_db";

    $conn = new mysqli($servername, $username, $password, $dbname);
    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }

    // Get old_reference_id if exists
    $sql_check_old = "SELECT old_reference_id FROM mis WHERE reference_id = ?";
    $stmt_check = $conn->prepare($sql_check_old);
    $stmt_check->bind_param("s", $reference_id);
    $stmt_check->execute();
    $result = $stmt_check->get_result();
    $row = $result->fetch_assoc();
    $old_reference_id = $row['old_reference_id'] ?? null;
    $stmt_check->close();

    // Fetch previous floor_details data if old_reference_id exists
    if (!empty($old_reference_id)) {
        $sql_area = "SELECT * FROM floor_details WHERE reference_id = ?";
        $stmt_area = $conn->prepare($sql_area);
        $stmt_area->bind_param("s", $old_reference_id);
        $stmt_area->execute();
        $res_area = $stmt_area->get_result();
        $db_data = $res_area->fetch_assoc() ?: [];
        $stmt_area->close();

        $fieldss = array_merge($db_data, $_SESSION['floor_details'] ?? []);
    }

    $conn->close();
}

// Handle form submission
if ($_SERVER["REQUEST_METHOD"] === "POST") {
    // Sanitize input function
    function sanitize_input($data) {
        if (is_array($data)) {
            return array_map('sanitize_input', $data);
        }
        return htmlspecialchars(stripslashes(trim($data)));
    }

    // Sanitize and store form data
    $form_data = sanitize_input($_POST);

    // Merge POST data with existing session data
    foreach ($form_data as $key => $value) {
        if ($key !== 'action' && $key !== 'reference_id') {
            $fieldss[$key] = $value;
        }
    }

    // Ensure propertyType is set
    if (!empty($form_data['propertyType'])) {
        $fieldss['propertyType'] = $form_data['propertyType'];
    }

    // Calculate insurable value based on property type
    if (isset($fieldss['propertyType'])) {
        $type = $fieldss['propertyType'];

        if ($type === "Land and Building") {
            $construction = floatval($fieldss['finally_construction_valuation'] ?? 0);
            $fieldss['insurable'] = round($construction, 2);
        } elseif ($type === "Floor Property") {
            $area = floatval($fieldss['final_area_square_feet'] ?? 0);
            $fieldss['insurable'] = round($area * 1200, 2);
        }
    }

    // Update session with merged data
    $fieldss['reference_id'] = $reference_id; // ✅ Force current reference_id
    $_SESSION['floor_details'] = $fieldss;

    // Handle save or submit action
    $action = $_POST['action'] ?? '';
    if ($action === 'save') {
        if (saveFloorDetailsToDatabase($fieldss)) {
            $message = "Structure Details saved successfully!";
        }
    } elseif ($action === 'submit') {
        if (saveFloorDetailsToDatabase($fieldss)) {
            unset($_SESSION['floor_details']);
            header("Location: REPORT9.php");
            exit();
        }
    }
}

// Save function stub
function saveFloorDetailsToDatabase($fieldss) {
    return true;
}
?>
<!-- JavaScript for Alert -->
<script>
    <?php if (!empty($message)): ?>
    alert("<?= htmlspecialchars($message) ?>");
    <?php endif; ?>
</script>


<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Property Details Form</title>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
<link rel="shortcut icon" href="favicon.ico" type="image/x-icon">
<!-- <link rel="stylesheet" href="REPORT09.css"> -->
<style>
                  * {
  margin: 0;
  padding: 0;
  box-sizing: border-box;
  font-family: "Poppins", "Segoe UI", sans-serif;
}

body {
  background: linear-gradient(135deg, #e0f7fa, #fce4ec, #f3e5f5);
  background-size: 300% 300%;
  animation: gradientBG 12s ease infinite;
  min-height: 100vh;
  text-transform: uppercase;
  padding-top: 110px;
  position: relative;
  color: #2c3e50;
}

/* Animate background */
@keyframes gradientBG {
  0% { background-position: 0% 50%; }
  50% { background-position: 100% 50%; }
  100% { background-position: 0% 50%; }
}

    
        .form-container {
            width: 100%;
            max-width: 100%;
            margin: 0 auto;
            display: flex;
            flex-direction: column;
            gap: 10px;
              text-align: left;
            
        }
       
 
.tab-links {
  position: fixed;
  top: 0;
  left: 0; right: 0;
  z-index: 999;
  display: flex;
  justify-content: space-between;
  padding: 7px;
    gap:10px;
  overflow-x: auto;
  backdrop-filter: blur(12px);
  border-bottom: 2px solid rgba(0,0,0,0.05);
  box-shadow: 0 2px 10px rgba(0,0,0,0.08);
  text-align: center;
}

.tab-links .tab {
   border: 1px solid #ddd;
  padding:2px 35px;
  border-radius: 50px;
  font-size: 14px;
  font-weight: bold;
  color: #444;

  transition: all 0.3s ease;
  cursor: pointer;
}

.tab-links .tab.active {
  background: linear-gradient(135deg, #9d7cc1ff, #5d7aacff);
  color: #fff;
    box-shadow: 0 12px 30px rgba(106, 17, 203, 0.35),
              0 6px 15px rgba(37, 117, 252, 0.25);
  transition: all 0.5s cubic-bezier(0.25, 1, 0.5, 1);
  animation: gradientMove 4s ease infinite, float 6s ease-in-out infinite;
  transform: scale(1.05);
  box-shadow: 0 4px 12px rgba(0,0,0,0.2);

}

/* Tab Icon */
.tab img {
  width: 45px;
  height: 45px;
  margin-bottom:5px;
  transition: transform 0.3s ease;
}
.tab:hover img {
  transform: rotate(10deg) scale(1.1);
}

    /* Styling the scrollbar for the entire page */
::-webkit-scrollbar {
    width: 12px; /* Width of the vertical scrollbar */
    height: 10px; /* Height of horizontal scrollbar */
}
th{
    font-size:15px;background: linear-gradient(135deg, #e4dee7ff);
  color:black;
  font-weight:600;
    box-shadow: 0 12px 30px rgba(106, 17, 203, 0.35),
              0 6px 15px rgba(37, 117, 252, 0.25);
  transition: all 0.5s cubic-bezier(0.25, 1, 0.5, 1);
  animation: gradientMove 4s ease infinite, float 6s ease-in-out infinite;
  transform: scale(1.05);
  padding:5px;
  box-shadow: 0 4px 12px rgba(0,0,0,0.2);"
}
/* Styling the scrollbar track */
::-webkit-scroltab-linkslbar-track {
    background: linear-gradient(135deg, #f0f0f0, #e0e0e0); /* Light gradient track */
    border-radius: 10px; /* Rounded corners */
    box-shadow: inset 0 0 10px rgba(0, 0, 0, 0.1); /* Subtle shadow */
}

/* Styling the scrollbar thumb (the draggable part) */
::-webkit-scrollbar-thumb {
    background: linear-gradient(135deg, #2f7cab, #0056b3); /* Gradient thumb */
    border-radius: 10px; /* Rounded corners */
    border: 3px solid transparent; /* Add space around thumb */
    background-clip: content-box; /* Ensures the thumb’s background doesn’t overlap the border */
    transition: background 0.3s ease, transform 0.3s ease; /* Smooth transition for hover */
}

/* Hover effect for the scrollbar thumb */
::-webkit-scrollbar-thumb:hover {
    background: linear-gradient(135deg, #0056b3, #003d80); /* Darker gradient on hover */
    transform: scale(1.1); /* Slightly enlarge the thumb */
}

/* Styling the horizontal scrollbar */
::-webkit-scrollbar-horizontal {
    height: 8px;
}

/* Styling the horizontal scrollbar track */
::-webkit-scrollbar-track-horizontal {
    background: linear-gradient(135deg, #f0f0f0, #e0e0e0); /* Light gradient track */
    border-radius: 10px;
    box-shadow: inset 0 0 10px rgba(0, 0, 0, 0.1);
}

/* Styling the horizontal scrollbar thumb */
::-webkit-scrollbar-thumb-horizontal {
    background: linear-gradient(135deg, #2f7cab, #0056b3);
    border-radius: 10px;
    border: 3px solid transparent;
    background-clip: content-box;
    transition: background 0.3s ease, transform 0.3s ease;
}

/* Hover effect for horizontal scrollbar thumb */
::-webkit-scrollbar-thumb-horizontal:hover {
    background: linear-gradient(135deg, #0056b3, #003d80);
    transform: scale(1.1); /* Slightly enlarge the thumb */
}

      .header {
 
   background: #f0f8ff;
  padding: 16px;
  text-align: center;
  font-size: 20px;
  font-weight: 700;
  text-decoration:underline;
  letter-spacing: 1px;
  border-bottom: 4px solid #fff;
  box-shadow: 0 4px 15px rgba(0,0,0,0.2);
  text-transform: uppercase;
}

        /* Main Content Styling */
        form {
            width: 100%;
        }

table {
  width: 100%;
  border-collapse: collapse;
  margin: 10px 0;
}

td {
  padding: 10px;
  font-size:16px;
  vertical-align: middle;
  transition: background 0.3s;
}

td:nth-child(odd) {
  background: #f0f8ff;
  font-weight: 600;
  color: #2c3e50;
}

td:nth-child(even) {
  background: #ffffff;
}

input[type="text"] {
  width: 100%;
  padding: 8px 12px;
  border: 1px solid #ddd;
  border-radius: 8px;
  transition: border-color 0.3s, box-shadow 0.3s;
}

input[type="text"]:focus {
  border-color: #6a11cb;
  box-shadow: 0 0 6px rgba(106, 17, 203, 0.4);
  outline: none;
}
/* Enhanced Submit Button */
.submit-button {
  display: flex;
  justify-content: center;
  margin: 40px 0;
  perspective: 1000px;
}

/* Button styling */
.submit-button button,
.submit-button input[type="submit"] {
  background: linear-gradient(135deg, #6a11cb 0%, #2575fc 100%);
  background-size: 200% 200%;
  border: none;
  padding: 8px 35px;
  border-radius: 999px;
  color: #fff;
  font-size: 20px;
  cursor: pointer;
  font-weight: 800;
  letter-spacing: 0.5px;
  box-shadow: 0 12px 30px rgba(106, 17, 203, 0.35),
              0 6px 15px rgba(37, 117, 252, 0.25);
  transition: all 0.5s cubic-bezier(0.25, 1, 0.5, 1);
  animation: gradientMove 4s ease infinite, float 6s ease-in-out infinite;
  position: relative;
  overflow: hidden;
  outline: none;
  -webkit-tap-highlight-color: transparent;
  transform-style: preserve-3d;
  text-transform: uppercase;
}

/* Shimmer highlight effect */
.submit-button button::before {
  content: "";
  position: absolute;
  top: -50%;
  left: -50%;
  width: 170%;
  height: 170%;
  background: linear-gradient(
    60deg, 
    rgba(255,255,255,0) 0%, 
    rgba(255,255,255,0.15) 50%, 
    rgba(255,255,255,0) 100%
  );
  transform: rotate(25deg) translateX(-100%);
  transition: transform 1.2s cubic-bezier(0.23, 1, 0.32, 1);
  pointer-events: none;
}

/* Hover effects */
.submit-button button:hover {
  transform: translateY(-8px) scale(1.08) rotateX(10deg);
  box-shadow: 0 25px 50px rgba(106, 17, 203, 0.45),
              0 15px 30px rgba(37, 117, 252, 0.35),
              0 0 40px rgba(255, 255, 255, 0.2);
  filter: brightness(1.15) saturate(1.2);
  letter-spacing: 1px;
}

.submit-button button:hover::before {
  transform: rotate(25deg) translateX(100%);
}

/* Active (press) effect */
.submit-button button:active {
  transform: translateY(-2px) scale(0.98);
  box-shadow: 0 8px 20px rgba(106, 17, 203, 0.3);
  transition: all 0.1s ease;
}

/* Pulsing glow effect */
.submit-button button::after {
  content: "";
  position: absolute;
  inset: -4px;
  border-radius: 999px;
  background: linear-gradient(135deg, #6a11cb, #2575fc, #9d7cc1, #5d7aac);
  background-size: 300% 300%;
  z-index: -1;
  filter: blur(12px);
  opacity: 0.7;
  animation: gradientMove 5s ease infinite, pulse 3s ease infinite;
  pointer-events: none;
}

/* Sparkle particles */
.submit-button .sparkle {
  position: absolute;
  width: 4px;
  height: 4px;
  background: white;
  border-radius: 50%;
  pointer-events: none;
  opacity: 0;
  animation: sparkle 1.5s linear infinite;
}

/* Keyframes for animations */
@keyframes gradientMove {
  0% { background-position: 0% 50%; }
  50% { background-position: 100% 50%; }
  100% { background-position: 0% 50%; }
}

@keyframes pulse {
  0% { opacity: 0.5; transform: scale(0.95); }
  50% { opacity: 0.8; transform: scale(1.05); }
  100% { opacity: 0.5; transform: scale(0.95); }
}

@keyframes float {
  0% { transform: translateY(0px); }
  50% { transform: translateY(-5px); }
  100% { transform: translateY(0px); }
}

@keyframes sparkle {
  0% {
    opacity: 0;
    transform: translate(0, 0) scale(0);
  }
  20% {
    opacity: 1;
    transform: translate(var(--sparkle-x), var(--sparkle-y)) scale(1);
  }
  80% {
    opacity: 1;
  }
  100% {
    opacity: 0;
    transform: translate(
      calc(var(--sparkle-x) * 1.5), 
      calc(var(--sparkle-y) * 1.5)
    ) scale(0);
  }
}

.side-buttons {
  position: fixed;
  top: 25%;
  right: 20px;
  display: flex;
  flex-direction: column;
  gap: 12px;
  z-index: 1000;
}

.side-buttons button {
  background: linear-gradient(145deg, #6a11cb, #2575fc);
  border: none;
  border-radius: 50%;
  width: 55px;
  height: 55px;
  display: flex;
  align-items: center;
  justify-content: center;
  box-shadow: 0 5px 12px rgba(0,0,0,0.25);
  transition: all 0.3s ease;
}

.side-buttons button:hover {
  transform: rotate(15deg) scale(1.1);
  background: linear-gradient(145deg, #2575fc, #6a11cb);
}

.side-buttons button img {
  width: 24px;
  height: 24px;
  filter: brightness(0) invert(1);
}



        @media (max-width: 768px) {
            .side-buttons {
                top: 15%;
                right: 10px;
            }

            .tab-links {
                flex-wrap: wrap;
            }
        }

        @media (max-width: 480px) {
            .tab-links button {
                padding: 8px 10px;
            }

            .header {
                font-size: 16px;
            }

            td {
                font-size: 14px;
            }

            input[type="text"] {
                font-size: 14px;
            }

            .side-buttons {
                top: 10%;
                right: 5px;
            }
        }
        .image-preview-container {
    display: flex;
    flex-wrap: wrap;
    gap: 10px;
    margin-top: 20px;
    background-color: #f8f9fa;
    border: 2px dashed #dcdcdc;
    padding: 10px;
    border-radius: 8px;
    /* justify-content: center; */
    align-items: center;
    text-align: center;
}

.image-preview-container p {
    color: #888;
    font-size: 14px;
}

.image-preview-container.hidden {
    display: none;
}

/* File input trigger button styling */
.side-buttons button {
    background-color: #2f7cab;
    border: none;
    padding: 10px;
    cursor: pointer;
    border-radius: 50%;
    width: 50px;
    height: 50px;
    display: flex;
    align-items: center;
    justify-content: center;
    transition: background-color 0.3s;
}  
.rotating-text {
            color:black;
    perspective: 1000px; /* Adds a 3D perspective effect */
    font-size: 1.5rem;
    font-weight:bold;
    width: 100%;
    animation: rotate360 3s linear infinite;
    display: inline-block;
    margin-bottom:10px;
    transform-origin: center center; /* Rotates around its center */
    text-align:center;
    /* margin-left:20px; */
    font-style: italic;
    text-shadow: 
    1px 1px 2px rgba(235, 244, 243, 0.97),
    2px 2px 4px rgba(246, 242, 242, 0.4),
    3px 3px 6px rgba(249, 252, 252, 0.89),
    4px 4px 8px rgba(248, 242, 247, 0.93),
    5px 5px 10px rgba(232, 236, 237, 0.4);
  }
  
  /* Keyframes for rotating the text */
  @keyframes rotate360 {
    0% {
      transform: rotateY(0deg); /* Starts with no rotation */
    }
    50% {
      transform: rotateY(0deg); /* Half rotation */
    }
    100% {
      transform: rotateY(360deg); /* Full rotation */
    }
  }
  .logo {
    /* width: 50px; */
    height: 83px;
    padding: 12px;
    padding-bottom: 33px;
    
  }
#sidebar {
    background: #B0C4DE; /* Light Steel Blue */
    color: #2C3E50; 
    position: fixed;
    left: -250px;
    top: 0;
    width: 250px;
    height: 100%;
    /* background-color: #111; */
    color: white;
    transition: left 0.3s ease;
    padding: 20px;
}

#sidebar.active {
    left: 35px;
    /* background:grey; */
}
.sidebar {
    width: 250px;
    background: #B0C4DE; /* Light Steel Blue */
    /* background:rgba(245, 245, 245, 0.37); Light Steel Blue */
    color: black; /* Dark Grayish Blue */
    padding:20px;
    height: 100vh;
    position: fixed;
    left: 0;
    top: 0;
    z-index: 1000;
    transition: transform 0.3s ease-in-out;
  }
  .sidebar.hidden {
    transform: translateX(-100%);
  }
  .sidebar h1 {
font-size: 20px;
margin-top: 10px;
margin-bottom: 20px;
color: #2C3E50; 
}
  .sidebar a {
    padding: 15px 20px;
      margin: 10px 0;
      text-decoration: none;
      color: #2C3E50; /* Dark Grayish Blue */
      font-size:16px;
      font-style: italic;
      font-weight: 500;
      margin-bottom:70px;
      border-radius: 5px;
      transition: all 0.3s ease;
      display: flex;
      align-items: center;
  }

  .sidebar a:hover,
  .sidebar a.active {
    background: #4A90E2; /* Light Blue */
    transform: translateX(10px);
    color: white;
  }
  .sidebar a .icon {
    margin-right: 15px;
    font-size: 18px;
  }
/* Toggle Button */
#toggleSidebar {
    border-radius: 20%;
    position: fixed;
    top: 0px; /* Adjusted for better placement */
    left: 0px; /* Adjusted for better placement */
    z-index: 1000;
    background-color:rgb(130, 183, 226); 
    color: white;
    border: none;
    padding: 6px 12px; /* Added padding for a more clickable area */
    cursor: pointer;
    box-shadow: 0 4px 8px rgba(0, 0, 0, 0.7); /* Adds a soft shadow for depth */
    transition: all 0.3s ease; 
    /* Smooth transition for hover and active states */
}

/* Button hover effect */
#toggleSidebar:hover {
    background-color: #1c6abf; /* Slightly darker shade on hover */
    transform: scale(1); /* Slightly enlarges the button for a professional hover effect */
    box-shadow: 0 6px 12px rgba(0, 0, 0, 0.3); /* Stronger shadow on hover */
}

/* Active state for the button */
#toggleSidebar.active {
    background-color: #1a4f82; /* Darker shade for active state */
    transform: rotate(180deg); /* Smooth rotate effect when the sidebar is active */
}

/* Button icon (if you use an icon inside the button) */
#toggleSidebar i {
    font-size: 18px; /* Adjust the icon size */
    transition: transform 0.3s ease; /* Smooth transition when rotating */
}
.watch-icon {
    margin-right: 16px; /* Adds space between the search text and the watch icon */
    color: #555; /* Optional: sets the color of the watch icon */
}
#toggleSidebar {
    border-radius: 20%;
    position: fixed;
    top: 0px; /* Adjust for better placement */
    /* right: -35px; Position it just outside the sidebar */
    z-index: 1001;
    background-color: rgb(130, 183, 226);
    color: white;
    border: none;
    padding: 6px 12px;
    cursor: pointer;
    box-shadow: 0 4px 8px rgba(0, 0, 0, 0.7);
    transition: all 0.3s ease;
}

/* Button hover effect */
#toggleSidebar:hover {
    background-color: #1c6abf;
    box-shadow: 0 6px 12px rgba(0, 0, 0, 0.3);
}

/* Active state for the button */
#toggleSidebar.active {
    background-color: #1a4f82;
    transform: rotate(180deg); /* Smooth 180-degree rotation */
    box-shadow: 0 6px 12px rgba(0, 0, 0, 0.5);
}

/* Sidebar */
#sidebar.active + #toggleSidebar {
    right: 250px; /* Adjust so button moves into view */
}

/* Sidebar when active */
#sidebar.active {
    left: 0px;
}

/* Sidebar hidden state */
#sidebar {
    position: fixed;
    left: -250px;
    top: 0;
    width: 250px;
    height: 100%;
    background: #B0C4DE;
    color: white;
    transition: left 0.3s ease;
}
#pdf-container {
            width: 100%;
            height: 100%;
            overflow: auto;
        }
        canvas {
            display: block;
            margin: 0 auto;
        }
 .modal {
  display: none;
  position: fixed;
  z-index: 2000;
  inset: 0;
  background: rgba(0,0,0,0.7);
  animation: fadeIn 0.6s ease-out;
}

.modal-content {
  background: #fff;
  border-radius: 15px;
  margin: 60px auto;
  padding: 30px 40px;
  width: 70%;
  max-width: 900px;
  animation: scaleUp 0.5s ease-in-out forwards;
  box-shadow: 0 20px 40px rgba(0,0,0,0.3);
}

 .close {
  float: right;
  font-size: 34px;
  font-weight: bold;
  color: #e74c3c;
  cursor: pointer;
  transition: transform 0.3s ease;
}

.close:hover {
  transform: rotate(90deg);
  color: #c0392b;
}

/* Animations */
@keyframes scaleUp {
  from { transform: scale(0.8); opacity: 0; }
  to { transform: scale(1); opacity: 1; }
}
@keyframes fadeIn {
  from { opacity: 0; }
  to { opacity: 1; }
}


/* Stylish list items inside the modal */
.modal-content ul {
    list-style-type: decimal; /* Use numbers for list items */
    margin-top: 20px;
    padding-left: 25px; /* Add padding to list items */
    color: #555; /* Lighter text color for better contrast */
}

.modal-content ul li {
    /* margin-bottom: 10px; */
    line-height: 1.6; /* Increased line height for better readability */
    padding-left: 10px; /* Padding to align list items nicely */
    transition: transform 0.2s ease-in-out; /* Smooth transition effect on hover */
}

.modal-content ul li:hover {
    transform: translateX(5px); /* Subtle animation on hover for list items */
}

/* Optional: Add a smooth transition effect when content changes */
.modal-content {
    transition: transform 0.5s ease, opacity 0.5s ease;
}
/* Enhanced Dropdown Styles */
select {
  width: 100%;
  padding: 12px 16px;
  border: 2px solid transparent;
  border-radius: 12px;
  background: linear-gradient(135deg, #e0f7fa, #fce4ec, #f3e5f5);
  color: #2c3e50;
  font-size: 16px;
  font-weight: 500;
  cursor: pointer;
  box-shadow: 0 4px 15px rgba(0,0,0,0.08);
  transition: all 0.4s cubic-bezier(0.25, 1, 0.5, 1);
  appearance: none;
  background-size: 200% 200%;
  animation: gradientBG 12s ease infinite;
  position: relative;
  border:3px solid red;
  outline: none;
}

/* Custom dropdown arrow */
.select-wrapper {
  position: relative;
  width: 100%;
}

.select-wrapper::after {
  content: "";
  position: absolute;
  top: 50%;
  right: 16px;
  transform: translateY(-50%) rotate(0deg);
  width: 12px;
  height: 12px;
  background-image: url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 24 24' fill='%236a11cb'%3E%3Cpath d='M7 10l5 5 5-5z'/%3E%3C/svg%3E");
  background-repeat: no-repeat;
  background-position: center;
  pointer-events: none;
  transition: transform 0.4s cubic-bezier(0.68, -0.55, 0.27, 1.55);
}

/* Hover effects */
select:hover {
  transform: translateY(-2px);
  box-shadow: 0 8px 25px rgba(106, 17, 203, 0.2);
  border-color: #6a11cb;
}

/* Focus effects */
select:focus {
  border-color: #6a11cb;
  box-shadow: 0 0 0 4px rgba(106, 17, 203, 0.15), 
              0 8px 25px rgba(106, 17, 203, 0.25);
  background: linear-gradient(135deg, #e0f7fa, #fce4ec, #f3e5f5);
  animation: gradientBG 8s ease infinite, pulseFocus 2s ease infinite;
}

/* Expanded state for dropdown */
select:focus + .select-wrapper::after {
  transform: translateY(-50%) rotate(180deg);
}

/* DROPDOWN LIST STYLING (when open) */
select:focus {
  border-radius: 12px 12px 0 0;
}

/* Firefox dropdown list styling */
select option {
  padding: 12px 16px;
  background: rgba(255, 255, 255, 0.98);
  color: #2c3e50;
  border-bottom: 1px solid #f0f0f0;
  transition: all 0.3s ease;
  font-size: 15px;
  cursor: pointer;
}

/* Hover effect for options */
select option:hover,
select option:checked {
  background: linear-gradient(135deg, #9d7cc1, #5d7aac) !important;
  color: white !important;
  box-shadow: 0 4px 12px rgba(0,0,0,0.1);
  transform: translateX(4px);
}

/* Selected option style */
select option:checked {
  background: linear-gradient(135deg, #6a11cb, #2575fc) !important;
  color: white;
  font-weight: 600;
}

/* For Webkit browsers (Chrome, Safari) */
@media screen and (-webkit-min-device-pixel-ratio:0) {
  select {
    padding-right: 40px; /* Extra space for custom arrow */
  }
  
  /* Style the dropdown list itself */
  select:focus {
    border-radius: 12px;
  }
  
  /* Style the dropdown options */
  select option {
    padding: 12px 16px;
    background: rgba(255, 255, 255, 0.98);
    color: #2c3e50;
    border-bottom: 1px solid #f0f0f0;
    transition: all 0.3s ease;
    font-size: 15px;
    cursor: pointer;
  }
  
  /* Hover effect for options in Webkit */
  select option:hover {
    background: linear-gradient(135deg, #9d7cc1, #5d7aac) !important;
    color: white !important;
    padding-left: 20px;
  }
  
  /* Selected option style in Webkit */
  select option:checked {
    background: linear-gradient(135deg, #6a11cb, #2575fc) !important;
    color: white;
    font-weight: 600;
  }
}

/* Animation for dropdown opening */
@keyframes dropdownOpen {
  0% {
    opacity: 0;
    transform: translateY(-10px);
  }
  100% {
    opacity: 1;
    transform: translateY(0);
  }
}

/* Apply animation to dropdown options in Firefox */
@-moz-document url-prefix() {
  select {
    padding-right: 40px; /* Extra space for custom arrow in Firefox */
  }
  
  select option {
    animation: dropdownOpen 0.4s ease forwards;
  }
}

/* Pulse animation for focus state */
@keyframes pulseFocus {
  0% {
    box-shadow: 0 0 0 4px rgba(106, 17, 203, 0.15), 
                0 8px 25px rgba(106, 17, 203, 0.25);
  }
  50% {
    box-shadow: 0 0 0 8px rgba(106, 17, 203, 0.1), 
                0 8px 25px rgba(106, 17, 203, 0.3);
  }
  100% {
    box-shadow: 0 0 0 4px rgba(106, 17, 203, 0.15), 
                0 8px 25px rgba(106, 17, 203, 0.25);
  }
}

/* Enhanced label styling */
td label {
  display: block;
  font-weight: 600;
  margin-bottom: 8px;
  color: #2c3e50;
  transition: color 0.3s ease;
}

/* Hover effect on label */
td:hover label {
  color: #6a11cb;
}

/* Responsive adjustments */
@media (max-width: 768px) {
  select {
    padding: 10px 14px;
    font-size: 15px;
  }
  
  .select-wrapper::after {
    right: 14px;
  }
}

@media (max-width: 480px) {
  select {
    padding: 8px 12px;
    font-size: 14px;
    border-radius: 10px;
  }
  
  .select-wrapper::after {
    right: 12px;
    width: 10px;
    height: 10px;
  }
}

/* Custom dropdown list for modern browsers */
@supports (-webkit-appearance: none) or (appearance: none) or ((-moz-appearance: none) and (pointer-events: all)) {
  .select-wrapper {
    position: relative;
    display: inline-block;
    width: 100%;
  }
  
  .select-wrapper select {
    padding-right: 40px;
    z-index: 1;
  }
  
  .select-wrapper::after {
    z-index: 2;
  }
  
  /* Focus state for modern browsers */
  .select-wrapper select:focus {
    z-index: 3;
  }
}
/* Date Input Container */
.date-input-container {
    position: relative;
    margin: 25px 0;
}

/* Label Styling */
.date-input-container label {
    display: block;
    text-align: left;
    margin-bottom: 8px;
    font-weight: 600;
    color: #2c3e50;
    transition: all 0.3s ease;
}

/* Date Input Styling */
input[type="date"] {
    width: 100%;
    padding: 10px 10px;
    border: 2px solid transparent;
    border-radius: 12px;
    background: linear-gradient(135deg, #e0f7fa, #fce4ec, #f3e5f5);
    color: #2c3e50;
    font-size: 16px;
    font-weight: 500;
    box-shadow: 0 4px 15px rgba(0, 0, 0, 0.08);
    transition: all 0.4s cubic-bezier(0.25, 1, 0.5, 1);
    outline: none;
    cursor: pointer;
}

/* Hover effect */
input[type="date"]:hover {
    transform: translateY(-2px);
    box-shadow: 0 8px 25px rgba(106, 17, 203, 0.2);
    border-color: #6a11cb;
}


/* Pulse animation for focus state */
@keyframes pulseFocus {
    0% {
        box-shadow: 0 0 0 4px rgba(106, 17, 203, 0.15), 
                    0 8px 25px rgba(106, 17, 203, 0.25);
    }
    50% {
        box-shadow: 0 0 0 8px rgba(106, 17, 203, 0.1), 
                    0 8px 25px rgba(106, 17, 203, 0.3);
    }
    100% {
        box-shadow: 0 0 0 4px rgba(106, 17, 203, 0.15), 
                    0 8px 25px rgba(106, 17, 203, 0.25);
    }
}
</style>
</head>
<body>
<button id="toggleSidebar">&#9776;</button>
<div id="sidebar" class="sidebar">
    <div style="display: flex">
      <img class="logo" src="logo.png" alt="" />
      <h1>Magpie Engineering</h1>
    </div>
    <div class="rotating-text">Report Drafter</div>
    <a href="clear_and_go_home.php"><i class="fas fa-home icon"></i>Home</a>        

    
  <a href="clear_sessions.php" class="active"><i class="fas fa-clock watch-icon"></i>Pending For Drafting</a>
 <a href="technical.php"><i class="fas fa-clipboard-list icon"></i> Preview Report</a>      
    <a href="clear_and_logout.php"><i class="fas fa-sign-out-alt icon"></i>Logout</a>
  </div>
<div class="form-container">
<?php if ($message): ?>
            <div class="success-message">
                <?= htmlspecialchars($message) ?>
            </div>
        <?php endif; ?>
   
<!-- Tab Buttons -->
<div class="tab-links"> 
    <button class="tab tab-button" data-href="REPORT3.php"><img src="info.png" alt="Icon" width="50" height="50"> INFO</button>
    <button class="tab tab-button" data-href="REPORT4.php"><img src="general.png" alt="Icon" width="50" height="50" style="margin-bottom:4px;"> GENERAL</button>
    <button class="tab tab-button" data-href="REPORT2.php"><img src="location.png" alt="Icon" width="50" height="50"> LOCATION</button>
    <button class="tab tab-button" data-href="REPORT5.php"><img src="Zoning.png" alt="Icon" width="50" height="50"> ZONING</button>
    <button class="tab tab-button" data-href="REPORT7.php"><img src="value.png" alt="Icon" width="50" height="50"> VALUE</button>
    <button class="tab active" data-href="REPORT9.php"><img src="Floor.png" alt="Icon" width="50" height="50"> STRUCTURE</button>
    <button class="tab tab-button" data-href="REPORT10.php"><img src="documents.png" alt="Icon" width="50" height="50"> DOCUMENTS</button>
    <button class="tab tab-button" data-href="REPORT115.php"><img src="photo.png" alt="Icon" width="50" height="50"> PHOTOS</button>

    <button class="tab tab-button" data-href="REPORT12.php"><img src="remark.png" alt="Icon" width="50" height="50"> REMARK</button>
    <div class="slider"></div>
</div>
        
<?php
 // $reference_id = $_SESSION['reference_id'] ?? '';
   // echo '<input type="hidden" name="reference_id" value="' . htmlspecialchars($reference_id) . '">';
?>
<table class="valuation-table" style="margin-top:10px;">
        <thead>


<form id="autosave-form" method="POST" action="">
    <table class="valuation-table" style="margin-top:10px;">
    <thead>


<form id="autosave-form" method="POST" action="">
<table class="valuation-table" style="margin-top:-40px;">
<thead>
<tr class="fixed-property-type-row" style="align-items:center;">
<th colspan="4" style="font-size:15px;">Choose Property Type For Valuation:</th>
<td colspan="6">
<select id="propertyType" name="propertyType" style="padding:10px 38%;" onchange="toggleFields()" required>
<option value="select">Select Property Type</option>
<option value="Land and Building" <?= (isset($_SESSION['area_valuation']['propertyType']) && $_SESSION['area_valuation']['propertyType'] == "Land and Building") ? 'selected' : ''; ?>>Land and Building</option>
<option value="Floor Property" <?= (isset($_SESSION['area_valuation']['propertyType']) && $_SESSION['area_valuation']['propertyType'] == "Floor Property") ? 'selected' : ''; ?>>Floor Property</option>
</select>
</td>
</tr>
</thead>

<tr class="fixed-alert-row">
</tr>
     <script>
function toggleFields() {
    var propertyType = document.getElementById("propertyType").value;

    var fields = [
       
 "ground_approved_area","ground_permissible_area", "ground_actual_area", "ground_proposed_area", "first_approved_area", "first_permissible_area", "first_actual_area", "first_proposed_area",
"second_approved_area", "second_permissible_area", "second_actual_area", "second_proposed_area",
"other_approved_area", "other_permissible_area", "other_actual_area", "other_proposed_area",
"total_approved_area", "total_permissible_area", "total_actual_area", "total_proposed_area",
        "stage_construction_recommend_present_completion",
        "description_stage_construction_allotted", "total_completion_present",
        "basements_remarks", "approved_configuration_building", 
        "actual_configuration_building", "document_area_saledeed",
        "ground_accommodation", "ground_completed", "ground_approved", "ground_permissible", "ground_actual", "ground_proposed", "ground_rate", "ground_valuation",
"first_accommodation", "first_completed", "first_approved", "first_permissible", "first_actual", "first_proposed", "first_rate", "first_valuation",
"second_accommodation", "second_completed", "second_approved", "second_permissible", "second_actual", "second_proposed", "second_rate", "second_valuation",
"other_accommodation", "other_completed", "other_approved", "other_permissible", "other_actual", "other_proposed", "other_rate", "other_valuation",
"total_accommodation", "total_completed", "total_approved", "total_permissible", "total_actual", "total_proposed", "total_rate", "total_valuation",
"approved_configuration_building", "actual_configuration_building", "document_area_saledeed", "basements_remarks",
"number_of_units_each_floor", "number_of_lifts", "number_of_units_building", "progress_remarks",
"plinth_completion_present", "plinth_floors_completed",
"rcc_completion_present", "rcc_floors_completed",
"brickwork_completion_present", "brickwork_floors_completed",
"internal_plaster_completion_present", "internal_plaster_floors_completed",
"external_plaster_completion_present", "external_plaster_floors_completed",
"flooring_completion_present", "flooring_floors_completed",
"painting_completion_present", "painting_floors_completed",
"plumbing_completion_present", "plumbing_floors_completed",
"fixtures_completion_present", "fixtures_floors_completed",
"foundation_completion_present", "foundation_floors_completed",
"Present_quality_of_structure", "total_completion_floors_completed",
"stage_construction_actual_present_completion",
"stage_construction_recommend_present_completion",
"description_stage_construction_allotted",
"old_stage_construction_allotted",
"estimate_provided",
"estimate_method",
"total_completion_present", "total_completion_floors_completed",
"front_as_per_plan", "front_as_per_bye_laws", "front_actual_site", "front_extra_plan", "front_extra_bye_laws",
"site1_as_per_plan", "site1_as_per_bye_laws", "site1_actual_site", "site1_extra_plan", "site1_extra_bye_laws",
"site2_as_per_plan", "site2_as_per_bye_laws", "site2_actual_site", "site2_extra_plan", "site2_extra_bye_laws",
"rear_as_per_plan", "rear_as_per_bye_laws", "rear_actual_site", "rear_extra_plan", "rear_extra_bye_laws",
"basement_approved", "basement_actual_planned", "basement_remarks",
"number_ground_approved", "ground_actual_planned", "number_ground_remarks",
"number_first_approved", "first_actual_planned", "number_first_remarks",
"number_second_approved", "second_actual_planned", "number_second_remarks",
"number_third_approved", "third_actual_planned", "number_third_remarks",
"total_floors_approved", "total_floors_actual_planned", "total_number_floors_remarks"


    ];

    // Get all elements and store in an object
    var elements = {};
    fields.forEach(id => {
        elements[id] = document.getElementById(id);
    });

    // Disable all fields and set background to red
    fields.forEach(id => {
        if (elements[id]) {
            elements[id].setAttribute("readonly", true);
            elements[id].style.backgroundColor = "#ffffffff"; // light red
        }
    });

    // Enable and highlight green based on property type
    let enableFields = [];

    if (propertyType === "Land and Building") {
        enableFields = [
           "ground_approved_area","ground_permissible_area", "ground_actual_area", "ground_proposed_area", "first_approved_area", "first_permissible_area", "first_actual_area", "first_proposed_area",
"second_approved_area", "second_permissible_area", "second_actual_area", "second_proposed_area",
"other_approved_area", "other_permissible_area", "other_actual_area", "other_proposed_area",
"total_approved_area", "total_permissible_area", "total_actual_area", "total_proposed_area",
        "stage_construction_recommend_present_completion",
        "description_stage_construction_allotted", "total_completion_present",
        "basements_remarks", "approved_configuration_building", 
        "actual_configuration_building", "document_area_saledeed",
        "ground_accommodation", "ground_completed", "ground_approved", "ground_permissible", "ground_actual", "ground_proposed", "ground_rate", "ground_valuation",
"first_accommodation", "first_completed", "first_approved", "first_permissible", "first_actual", "first_proposed", "first_rate", "first_valuation",
"second_accommodation", "second_completed", "second_approved", "second_permissible", "second_actual", "second_proposed", "second_rate", "second_valuation",
"other_accommodation", "other_completed", "other_approved", "other_permissible", "other_actual", "other_proposed", "other_rate", "other_valuation",
"total_accommodation", "total_completed", "total_approved", "total_permissible", "total_actual", "total_proposed", "total_rate", "total_valuation",
"approved_configuration_building", "actual_configuration_building", "document_area_saledeed", "basements_remarks",
"number_of_units_each_floor", "number_of_lifts", "number_of_units_building", "progress_remarks",
"plinth_completion_present", "plinth_floors_completed",
"rcc_completion_present", "rcc_floors_completed",
"brickwork_completion_present", "brickwork_floors_completed",
"internal_plaster_completion_present", "internal_plaster_floors_completed",
"external_plaster_completion_present", "external_plaster_floors_completed",
"flooring_completion_present", "flooring_floors_completed",
"painting_completion_present", "painting_floors_completed",
"plumbing_completion_present", "plumbing_floors_completed",
"fixtures_completion_present", "fixtures_floors_completed",
"foundation_completion_present", "foundation_floors_completed",
"Present_quality_of_structure", "total_completion_floors_completed",
"stage_construction_actual_present_completion",
"stage_construction_recommend_present_completion",
"description_stage_construction_allotted",
"old_stage_construction_allotted",
"estimate_provided",
"estimate_method",
"total_completion_present", "total_completion_floors_completed",
"front_as_per_plan", "front_as_per_bye_laws", "front_actual_site", "front_extra_plan", "front_extra_bye_laws",
"site1_as_per_plan", "site1_as_per_bye_laws", "site1_actual_site", "site1_extra_plan", "site1_extra_bye_laws",
"site2_as_per_plan", "site2_as_per_bye_laws", "site2_actual_site", "site2_extra_plan", "site2_extra_bye_laws",
"rear_as_per_plan", "rear_as_per_bye_laws", "rear_actual_site", "rear_extra_plan", "rear_extra_bye_laws",
"basement_approved", "basement_actual_planned", "basement_remarks",
"number_ground_approved", "ground_actual_planned", "number_ground_remarks",
"number_first_approved", "first_actual_planned", "number_first_remarks",
"number_second_approved", "second_actual_planned", "number_second_remarks",
"number_third_approved", "third_actual_planned", "number_third_remarks",
"total_floors_approved", "total_floors_actual_planned", "total_number_floors_remarks"
        ];
    } else if (propertyType === "Floor Property") {
        enableFields = [
         
           "ground_approved_area","ground_permissible_area", "ground_actual_area", "ground_proposed_area", "first_approved_area", "first_permissible_area", "first_actual_area", "first_proposed_area",
"second_approved_area", "second_permissible_area", "second_actual_area", "second_proposed_area",
"other_approved_area", "other_permissible_area", "other_actual_area", "other_proposed_area",
"total_approved_area", "total_permissible_area", "total_actual_area", "total_proposed_area",
        "stage_construction_recommend_present_completion",
        "description_stage_construction_allotted", "total_completion_present",
        "basements_remarks", "approved_configuration_building", 
        "actual_configuration_building", "document_area_saledeed",
        "ground_accommodation", "ground_completed", "ground_approved", "ground_permissible", "ground_actual", "ground_proposed", "ground_rate", "ground_valuation",
"first_accommodation", "first_completed", "first_approved", "first_permissible", "first_actual", "first_proposed", "first_rate", "first_valuation",
"second_accommodation", "second_completed", "second_approved", "second_permissible", "second_actual", "second_proposed", "second_rate", "second_valuation",
"other_accommodation", "other_completed", "other_approved", "other_permissible", "other_actual", "other_proposed", "other_rate", "other_valuation",
"total_accommodation", "total_completed", "total_approved", "total_permissible", "total_actual", "total_proposed", "total_rate", "total_valuation",
"approved_configuration_building", "actual_configuration_building", "document_area_saledeed", "basements_remarks",
"number_of_units_each_floor", "number_of_lifts", "number_of_units_building", "progress_remarks",
"plinth_completion_present", "plinth_floors_completed",
"rcc_completion_present", "rcc_floors_completed",
"brickwork_completion_present", "brickwork_floors_completed",
"internal_plaster_completion_present", "internal_plaster_floors_completed",
"external_plaster_completion_present", "external_plaster_floors_completed",
"flooring_completion_present", "flooring_floors_completed",
"painting_completion_present", "painting_floors_completed",
"plumbing_completion_present", "plumbing_floors_completed",
"fixtures_completion_present", "fixtures_floors_completed",
"foundation_completion_present", "foundation_floors_completed",
"Present_quality_of_structure", "total_completion_floors_completed",
"stage_construction_actual_present_completion",
"stage_construction_recommend_present_completion",
"description_stage_construction_allotted",
"old_stage_construction_allotted",
"estimate_provided",
"estimate_method",
"total_completion_present", "total_completion_floors_completed",
"front_as_per_plan", "front_as_per_bye_laws", "front_actual_site", "front_extra_plan", "front_extra_bye_laws",
"site1_as_per_plan", "site1_as_per_bye_laws", "site1_actual_site", "site1_extra_plan", "site1_extra_bye_laws",
"site2_as_per_plan", "site2_as_per_bye_laws", "site2_actual_site", "site2_extra_plan", "site2_extra_bye_laws",
"rear_as_per_plan", "rear_as_per_bye_laws", "rear_actual_site", "rear_extra_plan", "rear_extra_bye_laws",
"basement_approved", "basement_actual_planned", "basement_remarks",
"number_ground_approved", "ground_actual_planned", "number_ground_remarks",
"number_first_approved", "first_actual_planned", "number_first_remarks",
"number_second_approved", "second_actual_planned", "number_second_remarks",
"number_third_approved", "third_actual_planned", "number_third_remarks",
"total_floors_approved", "total_floors_actual_planned", "total_number_floors_remarks"
        ];
    }

    // Enable and highlight green
    enableFields.forEach(id => {
        if (elements[id]) {
            elements[id].removeAttribute("readonly");
            elements[id].style.backgroundColor = "#deffd7ff"; // light green
        }
    });
}

// Run on page load
window.onload = toggleFields;
</script>

            <tr>
                <th colspan="9">FLOOR DETAILS</th>
            </tr>
            <tr>
                <th>Floors</th>
                 <th> Accomodation</th>
                 <th> % completed </th>
                <th>Approved Area</th>
                <th>Permissible Area</th>
                <th>Actual Area</th>
                <th>Proposed Area</th>
                 <th>Rate</th>
                  <th>Valuations</th>

            </tr>
            <tr>
           <!-- Ground Floor -->
  <tr>
    <td>Ground Floor</td>
    <td><input type="text" id="ground_accommodation" name="ground_accommodation" value="<?= $fieldss['ground_accommodation'] ?? '' ?>" placeholder="Enter Accommodation"></td>
    <td><input type="text" id="ground_completed" name="ground_completed" value="<?= $fieldss['ground_completed'] ?? '' ?>" placeholder="% Completed"></td>
    <td><input type="text" id="ground_approved_area" name="ground_approved_area" value="<?= $fieldss['ground_approved_area'] ?? '' ?>" placeholder="Approved Area"></td>
    <td><input type="text" id="ground_permissible_area" name="ground_permissible_area" value="<?= $fieldss['ground_permissible_area'] ?? '' ?>" placeholder="Permissible Area"></td>
    <td><input type="text" id="ground_actual_area" name="ground_actual_area" value="<?= $fieldss['ground_actual_area'] ?? '' ?>" placeholder="Actual Area"></td>
    <td><input type="text" id="ground_proposed_area" name="ground_proposed_area" value="<?= $fieldss['ground_proposed_area'] ?? '' ?>" placeholder="Proposed Area"></td>
    <td><input type="text" id="ground_rate" name="ground_rate" value="<?= $fieldss['ground_rate'] ?? '' ?>" placeholder="Rate"></td>
    <td><input type="text" id="ground_valuation" name="ground_valuation" value="<?= $fieldss['ground_valuation'] ?? '' ?>" placeholder="Valuation"></td>
  </tr>

  <!-- First Floor -->
  <tr>
    <td>First Floor</td>
    <td><input type="text" id="first_accommodation" name="first_accommodation" value="<?= $fieldss['first_accommodation'] ?? '' ?>" placeholder="Enter Accommodation"></td>
    <td><input type="text" id="first_completed" name="first_completed" value="<?= $fieldss['first_completed'] ?? '' ?>" placeholder="% Completed"></td>
    <td><input type="text" id="first_approved_area" name="first_approved_area" value="<?= $fieldss['first_approved_area'] ?? '' ?>" placeholder="Approved Area"></td>
    <td><input type="text" id="first_permissible_area" name="first_permissible_area" value="<?= $fieldss['first_permissible_area'] ?? '' ?>" placeholder="Permissible Area"></td>
    <td><input type="text" id="first_actual_area" name="first_actual_area" value="<?= $fieldss['first_actual_area'] ?? '' ?>" placeholder="Actual Area"></td>
    <td><input type="text" id="first_proposed_area" name="first_proposed_area" value="<?= $fieldss['first_proposed_area'] ?? '' ?>" placeholder="Proposed Area"></td>
    <td><input type="text" id="first_rate" name="first_rate" value="<?= $fieldss['first_rate'] ?? '' ?>" placeholder="Rate"></td>
    <td><input type="text" id="first_valuation" name="first_valuation" value="<?= $fieldss['first_valuation'] ?? '' ?>" placeholder="Valuation"></td>
  </tr>

  <!-- Second Floor -->
  <tr>
    <td>Second Floor</td>
    <td><input type="text" id="second_accommodation" name="second_accommodation" value="<?= $fieldss['second_accommodation'] ?? '' ?>" placeholder="Enter Accommodation"></td>
    <td><input type="text" id="second_completed" name="second_completed" value="<?= $fieldss['second_completed'] ?? '' ?>" placeholder="% Completed"></td>
    <td><input type="text" id="second_approved_area" name="second_approved_area" value="<?= $fieldss['second_approved_area'] ?? '' ?>" placeholder="Approved Area"></td>
    <td><input type="text" id="second_permissible_area" name="second_permissible_area" value="<?= $fieldss['second_permissible_area'] ?? '' ?>" placeholder="Permissible Area"></td>
    <td><input type="text" id="second_actual_area" name="second_actual_area" value="<?= $fieldss['second_actual_area'] ?? '' ?>" placeholder="Actual Area"></td>
    <td><input type="text" id="second_proposed_area" name="second_proposed_area" value="<?= $fieldss['second_proposed_area'] ?? '' ?>" placeholder="Proposed Area"></td>
    <td><input type="text" id="second_rate" name="second_rate" value="<?= $fieldss['second_rate'] ?? '' ?>" placeholder="Rate"></td>
    <td><input type="text" id="second_valuation" name="second_valuation" value="<?= $fieldss['second_valuation'] ?? '' ?>" placeholder="Valuation"></td>
  </tr>

  <!-- Other Floors -->
  <tr>
    <td>Other Floors</td>
    <td><input type="text" id="other_accommodation" name="other_accommodation" value="<?= $fieldss['other_accommodation'] ?? '' ?>" placeholder="Enter Accommodation"></td>
    <td><input type="text" id="other_completed" name="other_completed" value="<?= $fieldss['other_completed'] ?? '' ?>" placeholder="% Completed"></td>
    <td><input type="text" id="other_approved_area" name="other_approved_area" value="<?= $fieldss['other_approved_area'] ?? '' ?>" placeholder="Approved Area"></td>
    <td><input type="text" id="other_permissible_area" name="other_permissible_area" value="<?= $fieldss['other_permissible_area'] ?? '' ?>" placeholder="Permissible Area"></td>
    <td><input type="text" id="other_actual_area" name="other_actual_area" value="<?= $fieldss['other_actual_area'] ?? '' ?>" placeholder="Actual Area"></td>
    <td><input type="text" id="other_proposed_area" name="other_proposed_area" value="<?= $fieldss['other_proposed_area'] ?? '' ?>" placeholder="Proposed Area"></td>
    <td><input type="text" id="other_rate" name="other_rate" value="<?= $fieldss['other_rate'] ?? '' ?>" placeholder="Rate"></td>
    <td><input type="text" id="other_valuation" name="other_valuation" value="<?= $fieldss['other_valuation'] ?? '' ?>" placeholder="Valuation"></td>
  </tr>

  <!-- Total Floors -->
  <tr>
    <td>Total Floors</td>
    <td><input type="text" id="total_accommodation" name="total_accommodation" value="<?= $fieldss['total_accommodation'] ?? '' ?>" placeholder="Enter Accommodation"></td>
    <td><input type="text" id="total_completed" name="total_completed" value="<?= $fieldss['total_completed'] ?? '' ?>" placeholder="% Completed"></td>
    <td><input type="text" id="total_approved_area" name="total_approved_area" value="<?= $fieldss['total_approved_area'] ?? '' ?>" placeholder="Approved Area"></td>
    <td><input type="text" id="total_permissible_area" name="total_permissible_area" value="<?= $fieldss['total_permissible_area'] ?? '' ?>" placeholder="Permissible Area"></td>
    <td><input type="text" id="total_actual_area" name="total_actual_area" value="<?= $fieldss['total_actual_area'] ?? '' ?>" placeholder="Actual Area"></td>
    <td><input type="text" id="total_proposed_area" name="total_proposed_area" value="<?= $fieldss['total_proposed_area'] ?? '' ?>" placeholder="Proposed Area"></td>
    <td><input type="text" id="total_rate" name="total_rate" value="<?= $fieldss['total_rate'] ?? '' ?>" placeholder="Rate"></td>
    <td><input type="text" id="total_valuation" name="total_valuation" value="<?= $fieldss['total_valuation'] ?? '' ?>" placeholder="Valuation"></td>
  </tr>

</table>

<table  class="valuation-table">
<tr>
    <th  colspan="2">Configuration Of Building Approved</th>
    <th  colspan="2">Configuration Of Building Actual</th>
  <th colspan="2">Area as Per Document(Sale Deed)</th>
                  <th  colspan="2">Remarks on No. of Floors, Number of Units on Each Floor</th>

    </tr>
    <tr>
     <td  colspan="2"><input type="text" name="approved_configuration_building" id="approved_configuration_building" value="<?= $fieldss['approved_configuration_building'] ?? '0' ?>"></td>
     <td colspan="2" ><input type="text" name="actual_configuration_building" id="actual_configuration_building" value="<?= $fieldss['actual_configuration_building'] ?? '0' ?>"></td>
     <td colspan="2" ><input type="text" name="document_area_saledeed" id="document_area_saledeed" value="<?= $fieldss['document_area_saledeed'] ?? '0' ?>"></td>
          <td colspan="2" ><input type="text" name="basements_remarks" id="basements_remarks" value="<?= $fieldss['basements_remarks'] ?? '0' ?>"></td>
         
 
    </tr>
 <tr>
    <th colspan="2">Number Of Units On Each Floor </th>
    <th colspan="2">Number Of Lifts</th> 
      <th colspan="2">Number Of Units in Building</th>
       <th>Remarks on Progress</th>
    
    </tr>

    <tr> 
      <td colspan="2"><input type="text" name="number_of_units_each_floor" id="number_of_units_each_floor" value="<?= $fieldss['number_of_units_each_floor'] ?? '0' ?>"></td>
     <td colspan="2"><input type="text" name="number_of_lifts" id="number_of_lifts" value="<?= $fieldss['number_of_lifts'] ?? '0' ?>"></td>
     <td colspan="2"><input type="text" name="number_of_units_building" id="number_of_units_building" value="<?= $fieldss['number_of_units_building'] ?? '0' ?>"></td>
      <td colspan="2"><input type="text" id="progress_remarks" name="progress_remarks" value="<?= $fieldss['progress_remarks'] ?? '' ?>" placeholder="Enter remarks"></td>

</tr>
        </table>
    
   <tr>
     <table class="valuation-table">
  
                <th colspan="10">PROPERTY CONSTRUCTION STAGE</th>
    <tr>
      <th colspan="2">Sr. No.</th>
      <th colspan="2">Activity</th>
      <th colspan="2">Allotted %</th>
      <th colspan="2">Present Completion (%)</th>
      <th colspan="2">No. of Floors Completed</th>
     
    </tr>
  </thead>
  <tbody>
    <!-- 1 Plinth -->
    <tr>
      <td colspan="2"style="width:2px;">1</td>
      <td colspan="2">Plinth</td>
      <td colspan="2">15%</td>
      <td colspan="2"><input type="text" id="plinth_completion_present" name="plinth_completion_present" value="<?= $fieldss['plinth_completion_present'] ?? '' ?>" placeholder="Enter %"></td>
      <td colspan="2"><input type="text" id="plinth_floors_completed" name="plinth_floors_completed" value="<?= $fieldss['plinth_floors_completed'] ?? '' ?>" placeholder="Enter floors"></td>
    </tr>

    <!-- 2 RCC -->
    <tr >
      <td colspan="2"style="width:2px;">2</td>
      <td colspan="2">R.C.C. / Slab Completion</td>
      <td colspan="2">30%</td>
      <td colspan="2"><input type="text" id="rcc_completion_present" name="rcc_completion_present" value="<?= $fieldss['rcc_completion_present'] ?? '' ?>" placeholder="Enter %"></td>
      <td colspan="2"><input type="text" id="rcc_floors_completed" name="rcc_floors_completed" value="<?= $fieldss['rcc_floors_completed'] ?? '' ?>" placeholder="Enter floors"></td>
     </tr>

    <!-- 3 Brickwork -->
    <tr>
      <td colspan="2"style="width:2px;">3</td>
      <td colspan="2">Brickwork</td>
      <td colspan="2">15%</td>
      <td colspan="2"><input type="text" id="brickwork_completion_present" name="brickwork_completion_present" value="<?= $fieldss['brickwork_completion_present'] ?? '' ?>" placeholder="Enter %"></td>
      <td colspan="2"><input type="text" id="brickwork_floors_completed" name="brickwork_floors_completed" value="<?= $fieldss['brickwork_floors_completed'] ?? '' ?>" placeholder="Enter floors"></td>
     </tr>

    <!-- 4 Internal Plaster -->
    <tr>
      <td colspan="2"style="width:2px;">4</td>
      <td colspan="2">Internal Plaster</td>
      <td colspan="2">5%</td>
      <td colspan="2"><input type="text" id="internal_plaster_completion_present" name="internal_plaster_completion_present" value="<?= $fieldss['internal_plaster_completion_present'] ?? '' ?>" placeholder="Enter %"></td>
      <td colspan="2"><input type="text" id="internal_plaster_floors_completed" name="internal_plaster_floors_completed" value="<?= $fieldss['internal_plaster_floors_completed'] ?? '' ?>" placeholder="Enter floors"></td>
     </tr>

    <!-- 5 External Plaster -->
    <tr>
      <td colspan="2"style="width:2px;">5</td>
      <td colspan="2">External Plaster</td>
      <td colspan="2">5%</td>
      <td colspan="2"><input type="text" id="external_plaster_completion_present" name="external_plaster_completion_present" value="<?= $fieldss['external_plaster_completion_present'] ?? '' ?>" placeholder="Enter %"></td>
      <td colspan="2"><input type="text" id="external_plaster_floors_completed" name="external_plaster_floors_completed" value="<?= $fieldss['external_plaster_floors_completed'] ?? '' ?>" placeholder="Enter floors"></td>
     </tr>

    <!-- 6 Flooring -->
    <tr>
      <td colspan="2"style="width:2px;">6</td>
      <td colspan="2">Flooring</td>
      <td colspan="2">5%</td>
      <td colspan="2"><input type="text" id="flooring_completion_present" name="flooring_completion_present" value="<?= $fieldss['flooring_completion_present'] ?? '' ?>" placeholder="Enter %"></td>
      <td colspan="2"><input type="text" id="flooring_floors_completed" name="flooring_floors_completed" value="<?= $fieldss['flooring_floors_completed'] ?? '' ?>" placeholder="Enter floors"></td>
     </tr>

    <!-- 7 Painting -->
    <tr>
      <td colspan="2"style="width:2px;">7</td>
      <td colspan="2">Painting</td>
      <td colspan="2">5%</td>
      <td colspan="2"><input type="text" id="painting_completion_present" name="painting_completion_present" value="<?= $fieldss['painting_completion_present'] ?? '' ?>" placeholder="Enter %"></td>
      <td colspan="2"><input type="text" id="painting_floors_completed" name="painting_floors_completed" value="<?= $fieldss['painting_floors_completed'] ?? '' ?>" placeholder="Enter floors"></td>
     </tr>

    <!-- 8 Plumbing -->
    <tr>
      <td colspan="2"style="width:2px;">8</td>
      <td colspan="2">Plumbing</td>
      <td colspan="2">5%</td>
      <td colspan="2"><input type="text" id="plumbing_completion_present" name="plumbing_completion_present" value="<?= $fieldss['plumbing_completion_present'] ?? '' ?>" placeholder="Enter %"></td>
      <td colspan="2"><input type="text" id="plumbing_floors_completed" name="plumbing_floors_completed" value="<?= $fieldss['plumbing_floors_completed'] ?? '' ?>" placeholder="Enter floors"></td>
     </tr>

    <!-- 9 Fixtures & Finishing -->
    <tr>
      <td colspan="2"style="width:2px;">9</td>
      <td colspan="2">Fixtures & Finishing</td>
      <td colspan="2">5%</td>
      <td colspan="2"><input type="text" id="fixtures_completion_present" name="fixtures_completion_present" value="<?= $fieldss['fixtures_completion_present'] ?? '' ?>" placeholder="Enter %"></td>
      <td colspan="2"><input type="text" id="fixtures_floors_completed" name="fixtures_floors_completed" value="<?= $fieldss['fixtures_floors_completed'] ?? '' ?>" placeholder="Enter floors"></td>
     </tr>

    <!-- 10 Foundation -->
    <tr>
      <td colspan="2"style="width:2px;">10</td>
      <td colspan="2">Foundation</td>
      <td colspan="2">10%</td>
      <td colspan="2"><input type="text" id="foundation_completion_present" name="foundation_completion_present" value="<?= $fieldss['foundation_completion_present'] ?? '' ?>" placeholder="Enter %"></td>
      <td colspan="2"><input type="text" id="foundation_floors_completed" name="foundation_floors_completed" value="<?= $fieldss['foundation_floors_completed'] ?? '' ?>" placeholder="Enter floors"></td>
     </tr>

   
<tr>
    <td colspan="2"style="width:2px;">11</td>
    <td colspan="2">Present Quality Of Structure</td>
     <td colspan="2">10%</td>
    <td  colspan="2"><input type="text" id="Present_quality_of_structure" name="Present_quality_of_structure" value="<?= $fieldss['Present_quality_of_structure'] ?? '' ?>"></td>
 <td colspan="2"><input type="text" id="total_completion_floors_completed" name="total_completion_floors_completed" value="<?= $fieldss['total_completion_floors_completed'] ?? '' ?>" placeholder="Enter floors"></td>
 
</tr>

<tr>
    <td colspan="2"style="width:2px;">12</td>
    <td  colspan="2">Stage Of Construction (Actual %)</td>
    <td colspan="6"><input type="text" id="stage_construction_actual_present_completion" name="stage_construction_actual_present_completion"  value="<?= $fieldss['stage_construction_actual_present_completion'] ?? '0' ?>"></td>

</tr>

<tr>
    <td colspan="2" style="width:2px;">13</td>
    <td  colspan="2">Stage Of Construction (Recommended %)</td>
   <td colspan="6"><input type="text" id="stage_construction_recommend_present_completion" name="stage_construction_recommend_present_completion" value="<?= $fieldss['stage_construction_recommend_present_completion'] ?? '0' ?>"></td>
</tr>

<tr>
    <td colspan="2"style="width:2px;">14</td>
    <td   colspan="2">Description Of Stage Of Construction</td>
    <td colspan="6">
        <input type="text" id="description_stage_construction_allotted" placeholder="Description" name="description_stage_construction_allotted" value="<?= $fieldss['description_stage_construction_allotted'] ?? '' ?>">
    </td>
</tr>

<tr>
    <td colspan="2"style="width:2px;">15</td>
    <td  colspan="2">Old Stage Of Construction</td>
    <td colspan="6">
        <input type="text" id="old_stage_construction_allotted" placeholder="Description" name="old_stage_construction_allotted" value="<?= $fieldss['old_stage_construction_allotted'] ?? '' ?>">
    </td>
</tr>

<tr>
    <td colspan="2"style="width:2px;">16</td>
    <td  colspan="2">Estimate provided</td>
    <td colspan="6">
        <input type="text" id="estimate_provided" placeholder="Description" name="estimate_provided" value="<?= $fieldss['estimate_provided'] ?? '' ?>">
    </td>
</tr>

<tr>
    <td colspan="2" style="width:2px;">17</td>
    <td  colspan="2">Estimate Method</td>
    <td colspan="6">
        <input type="text" id="estimate_method" placeholder="Description" name="estimate_method" value="<?= $fieldss['estimate_method'] ?? '' ?>">
    </td>
</tr>


 <!-- Total Completion -->
    <tr>
        <td colspan="2"></td>
      <td colspan="2"><strong>Total Completion</strong></td>
      <td colspan="2">100%</td>
      <td colspan="3"><input type="text" id="total_completion_present" name="total_completion_present" value="<?= $fieldss['total_completion_present'] ?? '' ?>" placeholder="Enter total completion (%)"></td>
      <td colspan="3"><input type="text" id="total_completion_floors_completed" name="total_completion_floors_completed" value="<?= $fieldss['total_completion_floors_completed'] ?? '' ?>" placeholder="Enter floors"></td>
     </tr>
</tbody>
 
</table>
     <table class="valuation-table">

    <tr>
      <th>Setbacks</th>
      <th>As per Plan</th>
      <th>As per Bye-Laws</th>
      <th>Actual at Site</th>
      <th>Extra Coverage (Plan)</th>
      <th>Extra Coverage (Bye-Laws)</th>
    </tr>
  </thead>
  <tbody>
    <!-- Front -->
    <tr>
      <td>Front</td>
      <td><input type="text" id="front_as_per_plan" name="front_as_per_plan" value="<?= $fieldss['front_as_per_plan'] ?? '' ?>" placeholder="Enter value"></td>
      <td><input type="text" id="front_as_per_bye_laws" name="front_as_per_bye_laws" value="<?= $fieldss['front_as_per_bye_laws'] ?? '' ?>" placeholder="Enter value"></td>
      <td><input type="text" id="front_actual_site" name="front_actual_site" value="<?= $fieldss['front_actual_site'] ?? '' ?>" placeholder="Enter value"></td>
      <td><input type="text" id="front_extra_plan" name="front_extra_plan" value="<?= $fieldss['front_extra_plan'] ?? '' ?>" placeholder="Enter value"></td>
      <td><input type="text" id="front_extra_bye_laws" name="front_extra_bye_laws" value="<?= $fieldss['front_extra_bye_laws'] ?? '' ?>" placeholder="Enter value"></td>
    </tr>

    <!-- Site 1 (Right) -->
    <tr>
      <td>Site 1 (Right)</td>
      <td><input type="text" id="site1_as_per_plan" name="site1_as_per_plan" value="<?= $fieldss['site1_as_per_plan'] ?? '' ?>" placeholder="Enter value"></td>
      <td><input type="text" id="site1_as_per_bye_laws" name="site1_as_per_bye_laws" value="<?= $fieldss['site1_as_per_bye_laws'] ?? '' ?>" placeholder="Enter value"></td>
      <td><input type="text" id="site1_actual_site" name="site1_actual_site" value="<?= $fieldss['site1_actual_site'] ?? '' ?>" placeholder="Enter value"></td>
      <td><input type="text" id="site1_extra_plan" name="site1_extra_plan" value="<?= $fieldss['site1_extra_plan'] ?? '' ?>" placeholder="Enter value"></td>
      <td><input type="text" id="site1_extra_bye_laws" name="site1_extra_bye_laws" value="<?= $fieldss['site1_extra_bye_laws'] ?? '' ?>" placeholder="Enter value"></td>
    </tr>

    <!-- Site 2 (Left) -->
    <tr>
      <td>Site 2 (Left)</td>
      <td><input type="text" id="site2_as_per_plan" name="site2_as_per_plan" value="<?= $fieldss['site2_as_per_plan'] ?? '' ?>" placeholder="Enter value"></td>
      <td><input type="text" id="site2_as_per_bye_laws" name="site2_as_per_bye_laws" value="<?= $fieldss['site2_as_per_bye_laws'] ?? '' ?>" placeholder="Enter value"></td>
      <td><input type="text" id="site2_actual_site" name="site2_actual_site" value="<?= $fieldss['site2_actual_site'] ?? '' ?>" placeholder="Enter value"></td>
      <td><input type="text" id="site2_extra_plan" name="site2_extra_plan" value="<?= $fieldss['site2_extra_plan'] ?? '' ?>" placeholder="Enter value"></td>
      <td><input type="text" id="site2_extra_bye_laws" name="site2_extra_bye_laws" value="<?= $fieldss['site2_extra_bye_laws'] ?? '' ?>" placeholder="Enter value"></td>
    </tr>

    <!-- Rear -->
    <tr>
      <td>Rear</td>
      <td><input type="text" id="rear_as_per_plan" name="rear_as_per_plan" value="<?= $fieldss['rear_as_per_plan'] ?? '' ?>" placeholder="Enter value"></td>
      <td><input type="text" id="rear_as_per_bye_laws" name="rear_as_per_bye_laws" value="<?= $fieldss['rear_as_per_bye_laws'] ?? '' ?>" placeholder="Enter value"></td>
      <td><input type="text" id="rear_actual_site" name="rear_actual_site" value="<?= $fieldss['rear_actual_site'] ?? '' ?>" placeholder="Enter value"></td>
      <td><input type="text" id="rear_extra_plan" name="rear_extra_plan" value="<?= $fieldss['rear_extra_plan'] ?? '' ?>" placeholder="Enter value"></td>
      <td><input type="text" id="rear_extra_bye_laws" name="rear_extra_bye_laws" value="<?= $fieldss['rear_extra_bye_laws'] ?? '' ?>" placeholder="Enter value"></td>
    </tr>
</table>
<table class="valuation-table">
    <tr>
      <th>Floors</th>
      <th>Approved</th>
      <th>Actual / Planned</th>
      <th>Remarks (No. of floors, units per floor)</th>
    </tr>
  </thead>
  <tbody>
    <!-- (A) Basements -->
    <tr>
      <td>(A) No. of Basements</td>
      <td><input type="text" id="basement_approved" name="basement_approved" value="<?= $fieldss['basement_approved'] ?? '' ?>" placeholder="Enter approved"></td>
      <td><input type="text" id="basement_actual_planned" name="basement_actual_planned" value="<?= $fieldss['basement_actual_planned'] ?? '' ?>" placeholder="Enter actual/planned"></td>
      <td><input type="text" id="basement_remarks" name="basement_remarks" value="<?= $fieldss['basement_remarks'] ?? '' ?>" placeholder="Enter remarks"></td>
    </tr>

    <!-- (B) Ground / Parking / Stilt -->
    <tr>
      <td>(B) No. of Ground / Parking / Stilt</td>
      <td><input type="text" id="number_ground_approved" name="number_ground_approved" value="<?= $fieldss['number_ground_approved'] ?? '' ?>" placeholder="Enter approved"></td>
      <td><input type="text" id="ground_actual_planned" name="ground_actual_planned" value="<?= $fieldss['ground_actual_planned'] ?? '' ?>" placeholder="Enter actual/planned"></td>
      <td><input type="text" id="number_ground_remarks" name="number_ground_remarks" value="<?= $fieldss['number_ground_remarks'] ?? '' ?>" placeholder="Enter remarks"></td>
    </tr>

    <!-- (C) Podiums -->
     <tr>
      <td>First Floor</td>
      <td><input type="text" id="number_first_approved" name="number_first_approved" value="<?= $fieldss['number_first_approved'] ?? '' ?>" placeholder="Enter approved"></td>
      <td><input type="text" id="first_actual_planned" name="first_actual_planned" value="<?= $fieldss['first_actual_planned'] ?? '' ?>" placeholder="Enter actual/planned"></td>
      <td><input type="text" id="number_first_remarks" name="number_first_remarks" value="<?= $fieldss['number_first_remarks'] ?? '' ?>" placeholder="Enter remarks"></td>
    </tr>

    <!-- Second Floor -->
    <tr>
      <td>Second Floor</td>
      <td><input type="text" id="number_second_approved" name="number_second_approved" value="<?= $fieldss['number_second_approved'] ?? '' ?>" placeholder="Enter approved"></td>
      <td><input type="text" id="second_actual_planned" name="second_actual_planned" value="<?= $fieldss['second_actual_planned'] ?? '' ?>" placeholder="Enter actual/planned"></td>
      <td><input type="text" id="number_second_remarks" name="number_second_remarks" value="<?= $fieldss['number_second_remarks'] ?? '' ?>" placeholder="Enter remarks"></td>
    </tr>

    <!-- Third Floor -->
    <tr>
      <td>Third Floor</td>
      <td><input type="text" id="number_third_approved" name="number_third_approved" value="<?= $fieldss['number_third_approved'] ?? '' ?>" placeholder="Enter approved"></td>
      <td><input type="text" id="third_actual_planned" name="third_actual_planned" value="<?= $fieldss['third_actual_planned'] ?? '' ?>" placeholder="Enter actual/planned"></td>
      <td><input type="text" id="number_third_remarks" name="number_third_remarks" value="<?= $fieldss['number_third_remarks'] ?? '' ?>" placeholder="Enter remarks"></td>
    </tr>


     
    <!-- (E) Total Floors -->
    <tr>
      <td> Total No. of Floors</td>
      <td><input type="text" id="total_floors_approved" name="total_floors_approved" value="<?= $fieldss['total_floors_approved'] ?? '' ?>" placeholder="Enter approved"></td>
      <td><input type="text" id="total_floors_actual_planned" name="total_floors_actual_planned" value="<?= $fieldss['total_floors_actual_planned'] ?? '' ?>" placeholder="Enter actual/planned"></td>
      <td><input type="text" id="total_number_floors_remarks" name="total_number_floors_remarks" value="<?= $fieldss['total_number_floors_remarks'] ?? '' ?>" placeholder="Enter remarks"></td>
    </tr>
  
</table>
                 



<?php
        // Display the reference_id as a hidden field (assuming it will not be modified by the user)
         //   $reference_id = $_SESSION['reference_id'] ?? '';
           // echo '<input type="hidden" name="reference_id" value="' . htmlspecialchars($reference_id) . '">';
?>
        </table>
    
<!-- Save Button -->
<div class="submit-button">
    <input type="hidden" name="action" value="save">
    <button type="submit" id="saveBtn" name="action" value="save">Save</button>
</div>
   
            
           
    </div>
  
<script>

    
document.addEventListener('DOMContentLoaded', () => {
    const form = document.getElementById('autosave-form');

    if (!form) return;

    function gatherFormData(form) {
        const formData = new FormData(form);
        const data = {};
        formData.forEach((value, key) => {
            data[key] = value;
        });
        return data;
    }

    function autoSaveSession() {
        const data = gatherFormData(form);

        fetch('autosave.php', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
                page: 'floor_details',
                data: data
            })
        });
    }

    form.addEventListener('input', autoSaveSession);
});
 

    // On Save button click, set saved flag in sessionStorage
    document.getElementById('saveBtn').addEventListener('click', function () {
        sessionStorage.setItem('isFormSaved', 'true');
    });

    // Intercept tab button clicks
    document.querySelectorAll('.tab-button').forEach(button => {
        button.addEventListener('click', function (e) {
            const isSaved = sessionStorage.getItem('isFormSaved') === 'true';
            if (!isSaved) {
                e.preventDefault();
                alert("Please click 'Save' before switching tabs.");
            } else {
                const url = this.getAttribute('data-href');
                window.location.href = url;
            }
        });
    });

    // Reset save flag if user edits any input
    document.querySelectorAll('input, textarea, select').forEach(field => {
        field.addEventListener('input', function () {
            sessionStorage.setItem('isFormSaved', 'false');
        });
    });

 


    document.addEventListener("DOMContentLoaded", function () {
    let tabs = document.querySelectorAll(".tab-links .tab");
    let slider = document.querySelector(".tab-links .slider");

    function moveSlider(activeTab) {
        slider.style.width = activeTab.offsetWidth + "px";
        slider.style.left = activeTab.offsetLeft + "px";
    }

    tabs.forEach(tab => {
        tab.addEventListener("click", function () {
            tabs.forEach(t => t.classList.remove("active"));
            this.classList.add("active");
            moveSlider(this);
        });

        // Initialize position on load for the active tab
        if (tab.classList.contains("active")) {
            moveSlider(tab);
        }
    });
});

    
document.getElementById("toggleSidebar").addEventListener("click", function () {
    if (confirm("Are you sure to open the side bar? Your data will be lost/erased.")) {
        // Redirect to "Pending For Drafting" page
        window.location.href = "clear_sessions.php";
    } else {
        // If user clicks Cancel, do nothing
        return false;
    }
});



var modal = document.getElementById("myModal");

// Get the <span> element that closes the modal
var span = document.getElementsByClassName("close")[0];

// Function to show the modal with custom text
function showPopup(text) {
    document.getElementById("modalText").innerText = text;
    modal.style.display = "block";
}

// When the user clicks on <span> (x), close the modal
span.onclick = function() {
    modal.style.display = "none";
}

// When the user clicks anywhere outside of the modal, close it
window.onclick = function(event) {
    if (event.target == modal) {
        modal.style.display = "none";
    }
}

function openGoogleMaps(location) {
            const baseUrl = "https://www.google.com/maps/search/?api=1&query=";
            window.open(baseUrl + encodeURIComponent(location), '_blank');
        }
function triggerFileInput2() {
            document.getElementById("imageInput").click();
        }

        document.getElementById("imageInput").addEventListener("change", function (event) {
            const files = event.target.files;
            const previewContainer = document.getElementById("imagePreviewContainer");

            // Clear previous previews
            previewContainer.innerHTML = "";

            // Display previews for each selected image
            Array.from(files).forEach((file) => {
                if (file.type.startsWith("image/")) {
                    const reader = new FileReader();
                    reader.onload = function (e) {
                        const img = document.createElement("img");
                        img.src = e.target.result;
                        previewContainer.appendChild(img);
                    };
                    reader.readAsDataURL(file);
                }
            });
        });
function triggerFileInput1() {
            document.getElementById("pdfInput").click();
        }

        // Handle file selection
        document.getElementById("pdfInput").addEventListener("change", function (event) {
            const file = event.target.files[0];
            if (file && file.type === "application/pdf") {
                // Create a FileReader instance
                const reader = new FileReader();

                // When the file is read successfully, open it in a new tab
                reader.onload = function (e) {
                    const pdfUrl = e.target.result;

                    // Try to open the PDF in a new tab using embed
                    const newTab = window.open();
                    if (newTab) {
                        newTab.document.write('<html><body><embed src="' + pdfUrl + '" type="application/pdf" width="100%" height="100%"></body></html>');
                        newTab.document.close();

                        // Fallback if the PDF does not load correctly
                        setTimeout(function() {
                            if (newTab.document.body.innerHTML === "") {
                                // Use PDF.js as a fallback to display the PDF
                                newTab.document.body.innerHTML = '<div id="pdf-container" style="width: 100%; height: 100%;"></div>';
                                const loadingTask = pdfjsLib.getDocument(pdfUrl);
                                loadingTask.promise.then(function(pdf) {
                                    pdf.getPage(1).then(function(page) {
                                        const scale = 1.5;
                                        const viewport = page.getViewport({ scale: scale });
                                        const canvas = document.createElement('canvas');
                                        const ctx = canvas.getContext('2d');
                                        canvas.height = viewport.height;
                                        canvas.width = viewport.width;
                                        document.getElementById('pdf-container').appendChild(canvas);

                                        // Render PDF page
                                        page.render({
                                            canvasContext: ctx,
                                            viewport: viewport
                                        });
                                    });
                                });
                            }
                        }, 1000); // Check if the embed failed after 1 second
                    }
                };

                // Read the file as a data URL
                reader.readAsDataURL(file);
            } else {
                alert("Please select a valid PDF file.");
            }
        });
</script>
</body>
</html>
