<?php
$reference_id = $_GET['reference_id'] ?? null;
if (!$reference_id) {
    echo json_encode([]);
    exit;
}

$conn = new mysqli("localhost", "root", "", "project_db");
if ($conn->connect_error) {
    echo json_encode([]);
    exit;
}

// Dynamically build the SQL SELECT for image1 to image50
$columns = [];
for ($i = 1; $i <= 50; $i++) {
    $columns[] = "image" . $i;
}
$columnList = implode(", ", $columns);

$stmt = $conn->prepare("SELECT $columnList FROM uploaded_images WHERE reference_id = ?");
$stmt->bind_param("s", $reference_id);
$stmt->execute();
$result = $stmt->get_result();
$row = $result->fetch_assoc();

$images = [];
if ($row) {
    foreach ($columns as $key) {
        $images[] = $row[$key] ? base64_encode($row[$key]) : null;
    }
}

echo json_encode($images);
?>
