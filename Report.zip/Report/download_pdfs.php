<?php
ini_set('display_errors', 1);
error_reporting(E_ALL);

if (!isset($_GET['reference_id'])) {
    die("Reference ID not provided.");
}

$reference_id = $_GET['reference_id']; // Keep full string (e.g., 25/04/CRI/KOL/0160)

// DB connection
$servername = "localhost";
$username = "root";
  $password = "";$dbname = "project_db";

$conn = new mysqli($servername, $username, $password, $dbname);
if ($conn->connect_error) {
    die("DB connection failed: " . $conn->connect_error);
}
// Fetch customer name too
$sql = "SELECT customerName, pdf1, pdf2, pdf3, pdf4, pdf5, pdf6 FROM mis WHERE reference_id = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("s", $reference_id); // already done
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows === 0) {
    die("No records found for reference_id: $reference_id");
}
$row = $result->fetch_assoc();
$customerName = $row['customerName'] ?? 'Customer';
// Temp folder to store PDFs
$tempDir = sys_get_temp_dir() . "/pdfs_" . uniqid();
mkdir($tempDir);

// Store temporary filenames
$pdfFiles = [];

// Save each non-empty BLOB as a PDF file
$count = 1;
foreach ($row as $index => $blob) {
    if (!empty($blob)) {
        $filename = $tempDir . "/document{$count}.pdf";
        file_put_contents($filename, $blob);
        $pdfFiles[] = $filename;
        $count++;
    }
}

// If no valid PDFs found
if (empty($pdfFiles)) {
    die("No valid PDF files found for download.");
}

// Create ZIP file
// Clean name for file (remove special chars)
$cleanName = preg_replace('/[^a-zA-Z0-9]/', '_', $customerName);
$zipFilename = "documents_" . $cleanName . ".zip";
$zipPath = $tempDir . "/" . $zipFilename;

$zip = new ZipArchive();
if ($zip->open($zipPath, ZipArchive::CREATE | ZipArchive::OVERWRITE) !== TRUE) {
    die("Failed to create ZIP.");
}

foreach ($pdfFiles as $file) {
    $zip->addFile($file, basename($file));
}
$zip->close();

// Serve ZIP
if (file_exists($zipPath)) {
    header('Content-Type: application/zip');
    header('Content-Disposition: attachment; filename="' . basename($zipPath) . '"');
    header('Content-Length: ' . filesize($zipPath));
    readfile($zipPath);
}

// Cleanup
foreach ($pdfFiles as $file) {
    unlink($file);
}
unlink($zipPath);
rmdir($tempDir);
exit;
?>
