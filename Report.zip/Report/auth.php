 
<?php
session_start();
if (!isset($_SESSION['report_id'])) {
    header("Location: login1.php");
    exit();
}
?>
