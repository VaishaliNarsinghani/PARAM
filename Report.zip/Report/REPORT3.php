<?php include('auth.php'); ?>
<?php
 ob_start(); // prevent output until all logic completes

// Enable error reporting for debugging
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

$message = ""; // Feedback message for the user

// Database connection details
$servername = "localhost";
$username = "root";
  $password = "";$dbname = "project_db";

// Establish the database connection
$conn = new mysqli($servername, $username, $password, $dbname);
if ($conn->connect_error) {
    die("Database connection failed: " . $conn->connect_error);
}

// Retrieve reference_id from GET or session
if (isset($_GET['reference_id'])) {
    $_SESSION['reference_id'] = $_GET['reference_id'];
}
$reference_id = $_SESSION['reference_id'] ?? '';

// Automatically populate session with GET data on first load
if (!isset($_SESSION['bank_details']) && !empty($_GET)) {
    $_SESSION['bank_details'] = array_map('htmlspecialchars', $_GET);
}

// Initialize form fields
$fields = [
    'reference_id' => $reference_id,
    'bankName' => $_SESSION['bank_details']['bankName'] ?? $_GET['bankName'] ?? '',
    'customerName' => $_SESSION['bank_details']['customerName'] ?? $_GET['customerName'] ?? '',
    'branchname' => $_SESSION['bank_details']['branchname'] ?? $_GET['branchname'] ?? '',
    'bank_branchname' => $_SESSION['bank_details']['bank_branchname'] ?? $_GET['bank_branchname'] ?? '',

    'applicationNo' => $_SESSION['bank_details']['applicationNo'] ?? $_GET['applicationNo'] ?? '',
    'customerMob' => $_SESSION['bank_details']['customerMob'] ?? $_GET['customerMob'] ?? '',
    'caseType' => $_SESSION['bank_details']['caseType'] ?? $_GET['caseType'] ?? '',
    'visitType' => $_SESSION['bank_details']['visitType'] ?? $_GET['visitType'] ?? '',
    'address' => $_SESSION['bank_details']['address'] ?? $_GET['address'] ?? ''
];

// Handle form submission
if ($_SERVER["REQUEST_METHOD"] === "POST") {
  if (isset($_POST['action'])) {
    if ($_POST['action'] === 'save') {
        $_SESSION['bank_details'] = array_map('htmlspecialchars', $_POST);
        $message = "Bank Details saved successfully!";
    } elseif ($_POST['action'] === 'submit') {
        unset($_SESSION['bank_details']);
        header("Location: REPORT3.php");
        exit();
    }
}

}if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['download_images'])) {
    // Clean output buffer before any output
    while (ob_get_level()) {
        ob_end_clean();
    }

    // Get customer name
    $stmt_name = $conn->prepare("SELECT customerName FROM mis WHERE reference_id = ?");
    $stmt_name->bind_param("s", $reference_id);
    $stmt_name->execute();
    $result_name = $stmt_name->get_result();
    $customerName = "customer";
    if ($row = $result_name->fetch_assoc()) {
        $customerName = preg_replace('/[^a-zA-Z0-9]/', '', $row['customerName']);
    }
    $stmt_name->close();

    // Fetch images
    $stmt = $conn->prepare("SELECT 
        image1, image2, image3, image4, image5, image6, image7, image8, image9, image10,
        image11, image12, image13, image14, image15, image16, image17, image18, image19, image20,
        image21, image22, image23, image24, image25, image26, image27, image28, image29, image30,
        image31, image32, image33, image34, image35, image36, image37, image38, image39, image40,
        image41, image42, image43, image44, image45, image46, image47, image48, image49, image50
        FROM uploaded_images WHERE reference_id = ?");
    $stmt->bind_param("s", $reference_id);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows > 0 && ($row = $result->fetch_assoc())) {
        $tempDir = sys_get_temp_dir() . DIRECTORY_SEPARATOR . uniqid('images_', true);
        mkdir($tempDir);

        $imageFiles = [];
        for ($i = 1; $i <= 50; $i++) {
            if (!empty($row["image$i"])) {
                $filename = $tempDir . DIRECTORY_SEPARATOR . "image{$i}.jpg";
                file_put_contents($filename, $row["image$i"]);
                $imageFiles[] = $filename;
            }
        }

        if (!empty($imageFiles)) {
            $zipFileName = "images_" . preg_replace('/[^a-zA-Z0-9]/', '_', $reference_id) . "_{$customerName}.zip";
            $zipPath = $tempDir . DIRECTORY_SEPARATOR . $zipFileName;

            $zip = new ZipArchive();
            if ($zip->open($zipPath, ZipArchive::CREATE) !== TRUE) {
                die("Failed to create ZIP file.");
            }

            foreach ($imageFiles as $file) {
                $zip->addFile($file, basename($file));
            }
            $zip->close();

            // Clear all output buffers before sending file
            while (ob_get_level()) {
                ob_end_clean();
            }

            header('Content-Type: application/zip');
            header('Content-Disposition: attachment; filename="' . basename($zipFileName) . '"');
            header('Content-Length: ' . filesize($zipPath));
            header('Content-Transfer-Encoding: binary');
            header('Cache-Control: must-revalidate');
            header('Pragma: public');

            flush();
            readfile($zipPath);

            foreach ($imageFiles as $file) unlink($file);
            unlink($zipPath);
            rmdir($tempDir);
            exit();
        } else {
            echo "<p style='color:red;'>No images to download.</p>";
        }
    } else {
        echo "<p style='color:red;'>No image data found for this reference ID.</p>";
    }
}


?>

<!-- JavaScript for Alert -->
<script>
    <?php if (!empty($message)): ?>
    alert("<?= htmlspecialchars($message) ?>");
    <?php endif; ?>
</script>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Property Details Form</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
    <link rel="stylesheet" href="REPORT3.css">
    <link rel="shortcut icon" href="favicon.ico" type="image/x-icon">
</head>
<body>
    <button id="toggleSidebar">&#9776;</button>
    <!-- Sidebar -->
    <div id="sidebar" class="sidebar">
        <div style="display: flex">
          <img class="logo" src="logo.png" alt="" />
          <h1>Magpie Engineering</h1>
        </div>
       <div class="rotating-text">Report Drafter</div>
    <a href="clear_and_go_home.php"><i class="fas fa-home icon"></i>Home</a>        

    
  <a href="clear_sessions.php" class="active"><i class="fas fa-clock watch-icon"></i>Pending For Drafting</a>
 <a href="technical.php"><i class="fas fa-clipboard-list icon"></i> Preview Report</a>      
    <a href="clear_and_logout.php"><i class="fas fa-sign-out-alt icon"></i>Logout</a>

  </div>
    <div class="form-container" id="formContainer" >
        <?php if (!empty($message)): ?>
            <div class="success-message" style="text-align: center; padding: 10px; background-color: #dff0d8; color: #3c763d; border: 1px solid #d6e9c6; margin-bottom: 20px;">
                <?= htmlspecialchars($message) ?>
            </div>
        <?php endif; ?>
    
        <div class="tab-links">
    <button class="tab active" onclick="location.href='REPORT3.php'"><img src="info.png" alt="Icon" width="50  " height="50  ">
    INFO</button>
    <button class="tab " onclick="location.href='REPORT4.php'"><img src="general.png" alt="Icon" width="50  " height="50  "style="margin-bottom:4px;">GENERAL</button>
    <button class="tab" onclick="location.href='REPORT2.php'"> <img src="location.png" alt="Icon" width="50  " height="50  ">
    LOCATION</button>
    <button class="tab " onclick="location.href='REPORT5.php'"><img src="Zoning.png" alt="Icon" width="50  " height="50  ">
    ZONING</button>
    <button class="tab" onclick="location.href='REPORT7.php'"><img src="value.png" alt="Icon" width="50  " height="50  ">
    VALUE</button>
    <button class="tab" onclick="location.href='REPORT9.php'"><img src="Floor.png" alt="Icon" width="50  " height="50  ">
    STRUCTURE</button>
    <button class="tab" onclick="location.href='REPORT10.php'"><img src="documents.png" alt="Icon" width="50  " height="50  ">
    DOCUMENTS</button>
    <button class="tab" onclick="location.href='REPORT115.php'"><img src="photo.png" alt="Icon" width="50  " height="50  ">
    PHOTOS</button>

    <button class="tab" onclick="location.href='REPORT12.php'"><img src="remark.png" alt="Icon" width="50  " height="50  ">
    REMARK</button>
    <div class="slider"></div>
</div>
<!-- Button to trigger PDF download -->
<div class="side-buttons">
  <button type="button" onclick="downloadPDFs('<?= $fields['reference_id'] ?>')">
    <img src="https://www.iconpacks.net/icons/1/free-document-icon-901-thumb.png" alt="Download PDFs" width="35px" height="35px">
  </button>

</div>

<script>
function downloadPDFs(referenceId) {
  if (!referenceId) {
    alert("Reference ID missing.");
    return;
  }

  // Encode special characters in URL
  window.location.href = "download_pdfs.php?reference_id=" + encodeURIComponent(referenceId) ;
}
</script>

  <!-- Customer Details Form -->
  <form id="autosave-form" action="" method="POST" style="width: 100%;" >
            <div class="header">BANK DETAILS / LOAN APPLICATION DETAILS</div>
            <table>
                <tr>
                    <?php
                    $count = 0;
                    foreach ($fields as $label => $value) {
                        echo "<td><label for='$label'>" . ucfirst(str_replace('_', ' ', $label)) . "</label></td>";
                        if ($label === 'address') {
                            echo "<td><textarea id='$label' name='$label' placeholder='Enter $label'>$value</textarea></td>";
                        } else {
                            echo "<td><input type='text' id='$label' name='$label' value='$value' placeholder='Enter $label'></td>";
                        }
                        $count++;
                        if ($count % 3 === 0) {
                            echo '</tr><tr>';
                        }
                    }
                    ?>
                </tr>
            </table>
    <div class="submit-button">
        <button type="submit" name="action" value="save">Save</button>
    </div>
  </form>
         
         <div style="position: relative; display: inline-block; margin: 10px; text-align: center;">
  <form method="post" style="display: inline;">
    <input type="hidden" name="download_images" value="1">
      <div  class="Download-button">
    <button type="submit">
      Download Images
      <span style="visibility: hidden; width: 130px; background-color: #333; color: #fff; text-align: center; border-radius: 6px; padding: 6px; position: absolute; z-index: 1; bottom: 120%; left: 50%; margin-left: -65px; opacity: 0; transition: opacity 0.3s; font-size: 13px;">
        Click to download all uploaded images
      </span>
    </button></div>
  </form>
</div>
                </div>
    <script>
       document.addEventListener("DOMContentLoaded", function () {
    let tabs = document.querySelectorAll(".tab-links .tab");
    let slider = document.querySelector(".tab-links .slider");

    function moveSlider(activeTab) {
        slider.style.width = activeTab.offsetWidth + "px";
        slider.style.left = activeTab.offsetLeft + "px";
    }

    tabs.forEach(tab => {
        tab.addEventListener("click", function () {
            tabs.forEach(t => t.classList.remove("active"));
            this.classList.add("active");
            moveSlider(this);
        });

        // Initialize position on load for the active tab
        if (tab.classList.contains("active")) {
            moveSlider(tab);
        }
    });
});
   
document.getElementById("toggleSidebar").addEventListener("click", function () {
    if (confirm("Are you sure to open the side bar? Your data will be lost/erased.")) {
        // Redirect to "Pending For Drafting" page
        window.location.href = "clear_sessions.php";
    } else {
        // If user clicks Cancel, do nothing
        return false;
    }
});

</script>    
  
</body>
</html>
