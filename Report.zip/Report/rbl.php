<?php include('auth.php'); ?>
<?php include 'watermark.html'; ?><?php
ini_set('display_errors', 1);
error_reporting(E_ALL);

// Increase PHP execution time and memory limit
ini_set('max_execution_time', 600); // Increase execution time to 600 seconds (10 minutes)
ini_set('memory_limit', '4096M'); // Increase memory limit to 4096MB
// Start session


$servername = "localhost";
$username = "root";
$password = "";
$dbname = "project_db";

// Create DB connection
$conn = new mysqli($servername, $username, $password, $dbname);
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

if (!isset($_SESSION['reference_id'])) {
    die("Reference ID not found in session.");
}

$reference_id = $_SESSION['reference_id'];

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['download_images'])) {

    // Get customer name
    $stmt_name = $conn->prepare("SELECT customerName FROM mis WHERE reference_id = ?");
    $stmt_name->bind_param("s", $reference_id);
    $stmt_name->execute();
    $result_name = $stmt_name->get_result();
    $customerName = "customer";
    if ($row = $result_name->fetch_assoc()) {
        $customerName = preg_replace('/[^a-zA-Z0-9]/', '', $row['customerName']);
    }
    $stmt_name->close();

    // Fetch image BLOBs
    $stmt = $conn->prepare("SELECT image1, image2, image3, image4, image5, image6, image7, image8, image9, image10, image11, image12,image13, image14, image15, image16, image17, image18, image19, image20 FROM final_uploaded_images WHERE reference_id = ?");    $stmt->bind_param("s", $reference_id);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows > 0 && ($row = $result->fetch_assoc())) {
        $tempDir = sys_get_temp_dir() . DIRECTORY_SEPARATOR . uniqid('images_', true);
        mkdir($tempDir);

        $imageFiles = [];
        for ($i = 1; $i <= 12; $i++) {
            if (!empty($row["image$i"])) {
                $filename = $tempDir . DIRECTORY_SEPARATOR . "image{$i}.jpg";
                file_put_contents($filename, $row["image$i"]);
                $imageFiles[] = $filename;
            }
        }

        if (empty($imageFiles)) {
            die("No images to download.");
        }

        // Create ZIP
        $zipFileName = "images_" . preg_replace('/[^a-zA-Z0-9]/', '_', $reference_id) . "_{$customerName}.zip";
        $zipPath = $tempDir . DIRECTORY_SEPARATOR . $zipFileName;

        $zip = new ZipArchive();
        if ($zip->open($zipPath, ZipArchive::CREATE) !== TRUE) {
            die("Failed to create ZIP file.");
        }

        foreach ($imageFiles as $file) {
            $zip->addFile($file, basename($file));
        }
        $zip->close();

        // Send ZIP to browser
        header('Content-Type: application/zip');
        header('Content-Disposition: attachment; filename="' . basename($zipFileName) . '"');
        header('Content-Length: ' . filesize($zipPath));
        flush();
        readfile($zipPath);

        // Cleanup
        foreach ($imageFiles as $file) {
            unlink($file);
        }
        unlink($zipPath);
        rmdir($tempDir);
        exit;
    } else {
        echo "<p style='color:red;'>No image data found for this reference ID.</p>";
    }
}

$page = isset($_GET['page']) ? $_GET['page'] : 1;
$limit = 50;
$offset = ($page - 1) * $limit;
$sql_property = "SELECT * FROM mis WHERE reference_id = ? LIMIT $limit OFFSET $offset";
$stmt_property = $conn->prepare($sql_property);
$stmt_property->bind_param("s", $reference_id);
$stmt_property->execute();
$result_property = $stmt_property->get_result();
$data1 = $result_property->fetch_assoc();




// Fetch data from property_details table
$sql_property = "SELECT * FROM property_details WHERE reference_id = ?";
$stmt_property = $conn->prepare($sql_property);
$stmt_property->bind_param("s", $reference_id);
$stmt_property->execute();
$result_property = $stmt_property->get_result();
$data2= $result_property->fetch_assoc();




// Fetch data from area_valuation table
$sql_area = "SELECT * FROM address_details WHERE reference_id = ?";
$stmt_area = $conn->prepare($sql_area); 
$stmt_area->bind_param("s", $reference_id);
$stmt_area->execute();
$result_area = $stmt_area->get_result();
$data3 = $result_area->fetch_assoc();





// Fetch data from area_valuation table
$sql_area = "SELECT * FROM critical_parameters WHERE reference_id = ?";
$stmt_area = $conn->prepare($sql_area); 
$stmt_area->bind_param("s", $reference_id);
$stmt_area->execute();
$result_area = $stmt_area->get_result();
$data4 = $result_area->fetch_assoc();

 
// Fetch data from area_valuation table
$sql_area = "SELECT * FROM surroundings_details WHERE reference_id = ?";
$stmt_area = $conn->prepare($sql_area); 
$stmt_area->bind_param("s", $reference_id);
$stmt_area->execute();
$result_area = $stmt_area->get_result();
$data5 = $result_area->fetch_assoc();
$stmt_area->close();
 
// Fetch data from area_valuation table
$sql_area = "SELECT * FROM area_valuation WHERE reference_id = ?";
$stmt_area = $conn->prepare($sql_area); 
$stmt_area->bind_param("s", $reference_id);
$stmt_area->execute();
$result_area = $stmt_area->get_result();
$data6 = $result_area->fetch_assoc();
$stmt_area->close();
 



// Fetch data from area_valuation table
$sql_area = "SELECT * FROM floor_details WHERE reference_id = ?";
$stmt_area = $conn->prepare($sql_area); 
$stmt_area->bind_param("s", $reference_id);
$stmt_area->execute();
$result_area = $stmt_area->get_result();
$data8= $result_area->fetch_assoc();
$stmt_area->close();
 


// Fetch data from area_valuation table
$sql_area = "SELECT * FROM technical_details WHERE reference_id = ?";
$stmt_area = $conn->prepare($sql_area); 
$stmt_area->bind_param("s", $reference_id);
$stmt_area->execute();
$result_area = $stmt_area->get_result();
$data9 = $result_area->fetch_assoc();
$stmt_area->close();
 
// Fetch data from area_valuation table
$sql_area = "SELECT * FROM remarks_table WHERE reference_id = ?";
$stmt_area = $conn->prepare($sql_area); 
$stmt_area->bind_param("s", $reference_id);
$stmt_area->execute();
$result_area = $stmt_area->get_result();
$data10 = $result_area->fetch_assoc();
$stmt_area->close();


// Step 1: Fetch the engineer_id from the mis table
$sql_mis = "SELECT engineer_id FROM mis WHERE reference_id = ?";
$stmt_mis = $conn->prepare($sql_mis);
$stmt_mis->bind_param("s", $reference_id);
$stmt_mis->execute();
$result_mis = $stmt_mis->get_result();
$row_mis = $result_mis->fetch_assoc();
$stmt_mis->close(); 

if ($row_mis) {
    $engineer_id = $row_mis['engineer_id'];

    // Step 2: Fetch the engineer's name from engineer_login table
    $sql_engineer = "SELECT name FROM engineer_login WHERE engineer_id = ?";
    $stmt_engineer = $conn->prepare($sql_engineer);
    $stmt_engineer->bind_param("s", $engineer_id);
    $stmt_engineer->execute();
    $result_engineer = $stmt_engineer->get_result();
    $row_engineer = $result_engineer->fetch_assoc();
    $stmt_engineer->close();

    if ($row_engineer) {
        $engineer_name = $row_engineer['name'];
         //echo "Engineer Name: " . $engineer_name;
    } else {
        echo "Engineer not found.";
    }
} else {
    echo "No engineer assigned for this reference_id.";
}



// Step 1: Fetch the engineer_id from the mis table
$sql_mis = "SELECT report_id FROM mis WHERE reference_id = ?";
$stmt_mis = $conn->prepare($sql_mis);
$stmt_mis->bind_param("s", $reference_id);
$stmt_mis->execute();
$result_mis = $stmt_mis->get_result();
$row_mis = $result_mis->fetch_assoc();
$stmt_mis->close(); 

if ($row_mis) {
    $report_id = $row_mis['report_id'];

    // Step 2: Fetch the engineer's name from engineer_login table
    $sql_engineer = "SELECT name FROM report_login WHERE report_id = ?";
    $stmt_engineer = $conn->prepare($sql_engineer);
    $stmt_engineer->bind_param("s", $report_id);
    $stmt_engineer->execute();
    $result_engineer = $stmt_engineer->get_result();
    $row_engineer = $result_engineer->fetch_assoc();
    $stmt_engineer->close();

    if ($row_engineer) {
        $report_name = $row_engineer['name'];
         //echo "Engineer Name: " . $report_name;
    } else {
        echo "Engineer not found.";
    }
} else {
    echo "No engineer assigned for this reference_id.";
}


// Step 1: Fetch the engineer_id from the mis table
$sql_mis = "SELECT report_drafter_to_technical FROM mis WHERE reference_id = ?";
$stmt_mis = $conn->prepare($sql_mis);
$stmt_mis->bind_param("s", $reference_id);
$stmt_mis->execute();
$result_mis = $stmt_mis->get_result();
$row_mis = $result_mis->fetch_assoc();
$stmt_mis->close(); 

if ($row_mis) {
    $report_drafter_to_technical = $row_mis['report_drafter_to_technical'];

    // Step 2: Fetch the engineer's name from engineer_login table
    $sql_engineer = "SELECT name FROM technical_login WHERE technical_manager_id = ?";
    $stmt_engineer = $conn->prepare($sql_engineer);
    $stmt_engineer->bind_param("s", $report_drafter_to_technical);
    $stmt_engineer->execute();
    $result_engineer = $stmt_engineer->get_result();
    $row_engineer = $result_engineer->fetch_assoc();
    $stmt_engineer->close();

    if ($row_engineer) {
        $technical_name = $row_engineer['name'];
        //echo "Engineer Name: " . $technical_name;
    } else {
        echo "Engineer not found.";
    }
} else {
    echo "No engineer assigned for this reference_id.";
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<style>


.container {
            width: 90%;
            margin: 20px auto;
            border: 1px solid black;
            padding: 20px;
        }
.header-content {
    text-align: center;
    flex: 1;
}

.header-content h1 {
    margin: 0;
    margin-top:25px;  
     font-size: 38px;
    color: #902d2d;
}

.header-content p {
    margin: 2px 0;
    font-size: 26px;
    color: #333;
}
.footer{
    display: flex;
}
h3{
    background-color:rgb(243, 234, 222) ;
    padding:5px;
    text-align: center;
    border:1px solid black;
}    
table {
  width: 100%;
  border:2px solid black;
  border-collapse: collapse;
  font-size: 14px;
  margin-bottom: 20px;
}

td {
  border: 1px solid black;
  padding: 1 10px;
  vertical-align: top;
}

input[type="text"] {
  min-width: 100px;
  box-sizing: border-box;
  border: none;
  font-size: 13px;
  font-family: inherit;
  background-color: #f9f9f9;
  align-items: center;
}

input:focus {
  outline: none;
  background-color: #eef6ff;
  align-items: center;
}

.section-title {
  background-color: #dcdcdc;
  font-weight: bold;
  text-align: center;
}

h3{
    text-align: center;
}

    
     
.container {
    max-width: 1200px;
    margin: 20px auto;
    padding: 20px;
    background-color: white;
    box-shadow: 0px 0px 10px rgba(0, 0, 0, 0.1);
    border-radius: 8px;
}

.title {
    text-align: center;
    font-size: 24px;
    font-weight: bold;
    margin-bottom: 20px;
}
.grid-container {
    display: grid;
    grid-template-columns: repeat(4, 1fr);
    gap: 15px;
}

.grid-item {
    position: relative;
    border-radius: 8px;
    overflow: hidden;
    box-shadow: 0px 4px 6px rgba(0, 0, 0, 0.1);
}

.grid-item img {
    width: 100%;
    height: 200px;
    object-fit: cover;
    transition: transform 0.3s ease;
}
.grid-item:hover img {
    transform: scale(1.05);
}

.overlay {
    position: absolute;
    bottom: 0;
    left: 0;
    background: rgba(0, 0, 0, 0.6);
    color: white;
    width: 100%;
    padding: 8px;
    font-size: 14px;
    text-align: center;
}
  .saini-header {
      display: flex;
      align-items: center;
      border: 1px solid #000;
      padding: 10px 20px;
      box-shadow: 0 0 3px rgba(0, 0, 0, 0.5);
    }

    .saini-header img {
      height: 80px;
      margin-right: 20px;
    }

    .saini-header-content {
      text-align: center;
      flex: 1;
      font-family: Arial, sans-serif;
    }

    .saini-header-content h1 {
      margin: 0;
      font-size: 26px;
      font-weight: bold;
      color: #00224c;
    }

    .saini-header-content p {
      margin: 4px 0 0;
      font-size: 13px;
      color: #00224c;
    }
    

pre{
  font-weight: 400;
  font-size:15px;
  font-family: Arial, Helvetica, sans-serif;
}
.clean-textarea {
    width: 100%;
    min-height: 30px;
    padding: 5px;
    font-size: 14px;
    font-family: inherit;
    background: transparent;
    border: none;
    outline: none;
    resize: none;
    overflow: hidden;
    color: inherit;
  }
textarea{    
  margin-top:5px;
border:0.2px solid grey;
background-color: transparent;
height:auto;
width:100%;
 font-family: Arial, Helvetica, sans-serif;
}
</style>
<style>
 
/* Force a stable 4-column grid that wkhtmltopdf respects */
.image-gallery { width: 100%; }
.image-grid { width: 100%; border-collapse: collapse; table-layout: fixed; }
.image-grid tr { page-break-inside: avoid; }
.image-grid td { width: 25%; padding: 6px; vertical-align: top; }

.image-grid .img-wrap { display: block; }
.image-grid img { display: block; width: 100%; height: auto; }
.image-grid .caption { font-size: 12px; text-align: center; margin-top: 4px; }

/* If you had a flex layout before, neutralize it */
.image-gallery { display: block !important; }


 
/* Optional: Google map styling */
    .google-map-container {
      max-width: 90%;
      margin: 20px auto;
      border: 2px solid #ccc;
      padding: 10px;
      box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
      background-color: #f9f9f9;
      border-radius: 8px;
      text-align: center;
    }

    .google-map-container img {
      max-width: 100%;
      height: auto;
      display: inline-block;
      border: 1px solid #999;
      border-radius: 4px;
    }
    
.logo img {
  width: 120px;
  margin-left:30px;
  height: auto;
}
@media print{
    body{
      margin:0;
    }
    button{
      display:none;
      margin-left:30%;
    }
}
 </style>

 
<body>
    
<div class="saini-header">
  <img src="images/SAA.jpg" alt="Saini Logo"> <!-- Replace with your actual logo path -->
  <div class="saini-header-content">
    <h1>SAINI AND ASSOCIATES</h1>
    <p>
      Office No. 201, 2nd floor, Gravity Mall, Mechanic Nagar, Warehouse Road, Near Vijay<br>
      Nagar, Indore, Madhya Pradesh - 452011
    </p>
  </div>
</div>
        <table>
            <tr>
              <td colspan="2">RBL BRANCH NAME </td>
              <td><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data1['bank_branchname'] ?? '') ?>
    </span></td>
              <td colspan="2">APPLICATION NO</td>
              <td colspan="2"><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data1['applicationNo'] ?? '') ?>
    </span></td>
              <td colspan="2">LOAN TYPE/PURPOSE</td>
              <td colspan="2"><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data1['caseType'] ?? '') ?>
    </span></td>
            </tr>
            <tr>
              <td colspan="2">NAME OF APPLICANT (S)</td>
              <td colspan="2"><textarea readonly  class="clean-textarea" name="engineer_id"oninput="autoResize(this)"><?= $data1['customerName'] ?? '' ?></textarea> </td>
    
              <td colspan="2">NAME & NUMBER OF CONTACT PERSON FOR PROPERTY VISIT</td>
              <td colspan="4"><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data2['person_meet_at_site_contact'] ?? '') ?>
    </span></td>
            </tr>
          
            <tr>
              <td colspan="12" class="section-title">VALUATION ASSIGNMENT DETAILS</td>
            </tr>
            <tr>
              <td>DATE OF INITIATION</td>
              <td colspan="2"><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data1['initiationDate'] ?? '') ?>
    </span></td>
              <td>VALUATION REFERENCE NO</td>
              <td colspan="2"><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data1['reference_id'] ?? '') ?>
    </span></td>
              <td>PURPOSE OF VALUATION</td>
              <td colspan="3"><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data1['caseType'] ?? '') ?>
    </span></td>
            </tr>
            <tr>
              <td>DATE OF VISIT </td>
              <td colspan="2"><span style="display: inline-block; min-width: 50px; padding: 2px;">
 <?= htmlspecialchars(date('d M Y h:i A', strtotime($data1['report_assigned_at'] ?? ''))) ?>
    </span></td>
              <td>PROPERTY VISITED BY (NAME)</td>
              <td colspan="2"><input type="text" value="<?= $engineer_name ?>"readonly></td>
              <td> VALUATION METHOD ADOPTED</td>
              <td colspan="3"><input type="text" value="Refer Remarks" readonly></td>
            </tr>
            <tr>
              <td >DATE OF VALUATION</td>
              <td colspan="2"><span style="display: inline-block; min-width: 50px; padding: 2px;">
 <?= htmlspecialchars(date('d M Y h:i A', strtotime($data1['report_assigned_at'] ?? ''))) ?>
    </span></td>
              <td>REPORT PREPARED BY (NAME)</td>
              <td colspan="6">MAGPIE ENGINEERING PRIVATE LIMITED</td>
            </tr>
            <tr>
              <td colspan="2">WHETHER SAME PROPERTY VALUED EARLIER?</td>
              <td><input type="text" value="Refer Remarks" readonly></td>
              <td colspan="2">IF YES, DATE AND BRIEF OF EARLIER ASSIGNMENT</td>
              <td colspan="5"><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data10['NA'] ?? '') ?>
    </span></td>
            </tr>
            <tr>
              <td colspan="10">
                ENTER DETAILED ADDRESS DETAILS AS PER PROPERTY VISIT IN BELOW FORM<br>
                (PLEASE ENTER " NA " IN CASE FIELD DETAILS ARE NOT AVAILABLE/APPLICABLE)
              </td>
            </tr>
          
            <!-- Address Details -->
            <tr>
              <td>HOUSE/FLAT NO.</td>
              <td colspan="2"><input type="text" value="Refer Address" readonly></td>
              <td>FLOOR NO.</td>
              <td colspan="2"><input type="text" value="Refer Address" readonly></td>
              <td>WING NAME & NO.</td>
              <td colspan="3"><input type="text" value="Refer Address" readonly></td>
            </tr>
            <tr>
              <td>BUILDING NAME & NO.</td>
              <td colspan="2"><input type="text" value="Refer Address" readonly></td>
              <td>PROJECT NAME/SOCIETY NAME</td>
              <td colspan="2"><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data2['project_name'] ?? '') ?>
    </span></td>
              <td>PLOT NO.</td>
              <td colspan="3"><input type="text" value="Refer Address" readonly></td>
              <!-- <td colspan="3"></td> -->
            </tr>
            <tr>
              <td>SURVEY NO.</td>
              <td colspan="2"><input type="text" value="Refer Address" readonly></td>
              <td>STAGE/SECTOR/WARD NO.</td>
              <td colspan="2"><input type="text" value="Refer Address" readonly></td>
              <td>STREET NAME &/NO.</td>
              <td colspan="3"><input type="text" value="Refer Address" readonly></td>
  
            </tr>
            <tr>
              <td>VILLAGE/LOCATION</td>
              <td colspan="2"><input type="text" value="Refer Address" readonly></td>
              <td>LANDMARK 1</td>
              <td colspan="2"><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data3['landmark_1'] ?? '') ?>
    </span></td>
              <td>LANDMARK 2</td>
              <td colspan="2"><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data3['landmark_2'] ?? '') ?>
    </span></td>
            </tr>
            <tr>
              <td>PIN CODE</td>
              <td colspan="2"><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data3['pin_code'] ?? '') ?>
    </span></td>
              <td>PIN CODE AREA</td>
              <td colspan="2"><input type="text" value="Refer Address" readonly></td>
               <td>CITY / TALUKA / TOWN</td>
               <td colspan="3"><input type="text" value="Refer Address" readonly></td>
            </tr>
            <tr>  
              <td>DISTRICT</td>
              <td colspan="2"><input type="text" value="Refer Address" readonly></td>
              <td>LAT, LONG VALUE (NE)</td>
              <td colspan="6"><input type="text" readonly value="<?= $data3['latitude_value'] ?? '' ?> <?= $data3['longitude_value'] ?? '' ?>" rows="2" placeholder=""></td>
            </tr>  
            <tr>
              <td>STATE</td>
              <td colspan="2"><input type="text" value="Refer Address" readonly></td>
              <td>NEAREST RBL BANK LOCATION</td>
              <td colspan="2"><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data3['nearest_branch_location'] ?? '') ?>
    </span></td>
              <td>DISTANCE FROM RBL BANK LOCATION (KMS.)</td>
              <td colspan="3"><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data3['distance_from_branch_kms'] ?? '') ?>
    </span></td>
            </tr>
            <tr>
              <td>ADDRESS AS PER PROPERTY VISIT</td>
              <td colspan="9"><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data3['address_per_site'] ?? '') ?>
    </span></td>
            </tr>
          </table>
          
          <table>
  <!-- Address Details -->
     <tr>
    <td colspan="5" class="section-title">ADDRESS DETAILS AS PER LEGAL DOCUMENTS</td>
  </tr>
  <tr>
    <td><label>ADDRESS AS PER DOC</label></td>
                <td colspan="4"><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data3['address_line_2_as_per_doc'] ?? '') ?>
    </span></td>
  </tr>
  <tr>
    <td>
      <label>LEGAL DOCUMENT(S) REFERRED FOR ADDRESS</label></td>
      <td colspan="4"><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data1['document_provided_for_valuation'] ?? '') ?>
    </span></td>
  </tr>

  <!-- Boundaries -->
  <tr>
    <td colspan="5" class="section-title">BOUNDARIES & COMMENT ON IDENTIFICATION</td>
  </tr>
  <tr>
    <td>DIRECTIONS</td>
    <td>NORTH</td>
    <td>SOUTH</td>
    <td>EAST</td>
    <td>WEST</td>
  </tr>
  <tr>
    <td>AS PER SITE</td>
     <td><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data3['direction_as_per_site_north'] ?? '') ?>
    </span></td>
                <td><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data3['direction_as_per_site_south'] ?? '') ?>
    </span></td>
                <td><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data3['direction_as_per_site_east'] ?? '') ?>
    </span></td>
                <td><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data3['direction_as_per_site_west'] ?? '') ?>
    </span></td>
            </tr>
  <tr>
    <td>AS PER LEGAL DOCUMENTS</td>
   <td><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data3['direction_as_per_document_north'] ?? '') ?>
    </span></td>
                <td><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data3['direction_as_per_document_south'] ?? '') ?>
    </span></td>
                <td><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data3['direction_as_per_document_east'] ?? '') ?>
    </span></td>
                <td><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data3['direction_as_per_document_west'] ?? '') ?>
    </span></td>
           </tr>
  <tr>
    <td>AS PER PLAN</td>
     <td><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data3['direction_approved_north'] ?? '') ?>
    </span></td>
                <td><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data3['direction_approved_south'] ?? '') ?>
    </span></td>
                <td><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data3['direction_approved_east'] ?? '') ?>
    </span></td>
                <td><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data3['direction_approved_west'] ?? '') ?>
    </span></td>
         </tr>
  <tr>
    <td>BOUNDARIES MATCHING</td>
    <td><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data3['boundaries_matching'] ?? '') ?>
    </span></td>
    <td><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data3['boundaries_matching'] ?? '') ?>
    </span></td>
    <td><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data3['boundaries_matching'] ?? '') ?>
    </span></td>
    <td><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data3['boundaries_matching'] ?? '') ?>
    </span></td>
  </tr>
  <tr>
    <td>COMMENT IF DISCREPANCY IN BOUNDARY MATCHING</td>
    <td colspan="4"><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data10['NA'] ?? '') ?>
    </span></td>
  </tr>

  <!-- Ownership -->
  <tr>
    <td colspan="5" class="section-title">OWNERSHIP DETAILS</td>
  </tr>
  <tr>
    <td><label>PRESENT OWNER</label></td>
     <td><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data9['owner_name'] ?? '') ?>
    </span></td>
    <td><label>PROPOSED OWNERS</label></td>
     <td colspan="2"><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data10['NA'] ?? '') ?>
    </span> </td>
  </tr>
  <tr>
    <td><label>WHETHER SELLER IS BUILDER/DEVELOPER</label></td>
    <td><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data10['NA'] ?? '') ?>
    </span></td>
    <td><label>SELLER NAME(s)</label></td>
    <td colspan="2"><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data9['seller_name'] ?? '') ?>
    </span></td>
  </tr>
  <tr>
    <td><label>WHETHER PROPERTY LEASEHOLD OR FREEHOLD</label></td>
    <td><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data2['property_leasehold_freehold'] ?? '') ?>
    </span></td>
    <td><label>IF LEASEHOLD, NAME OF THE LEASOR, LEASE TENURE</label></td>
     <td colspan="2"><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data10['NA'] ?? '') ?>
    </span></td>
    
  </tr>
  <tr>
    <td><label>OCCUPANCY STATUS</label></td>
    <td><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data2['occupancy_status'] ?? '') ?>
    </span></td>
    <td><label>DETAIL OF OCCUPANT(S) (NAME & TENURE) AS PER VISIT INFO</label></td>
    <td colspan="2"><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data2['occupant_name'] ?? '') ?>
    </span></td> 
  </tr>
</table>
           
   <table>
  <!-- GENERAL DETAILS -->
  <tr><td colspan="9" class="section-title">GENERAL DETAILS</td></tr>
  <tr>
    <td>
      <label>MUNICIPAL LIMIT</label></td>
     <td colspan=""><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data3['property_location_in'] ?? '') ?>
    </span>
    </td>
    <td>
      <label>MUNICIPAL AUTHORITY (NAME)</label></td>
     <td colspan=""> <span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data3['property_location_in'] ?? '') ?>
    </span>
    </td>
    <td>
      <label>YEAR OF CONSTRUCTION</label></td>
     <td colspan="4"> <span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data2['year_of_construction'] ?? '') ?>
    </span>
    </td>
  </tr>
  <tr>
    <td><label>AGE OF PROPERTY (YEARS)</label></td>
    <td><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data2['age_of_property'] ?? '') ?>
    </span></td>
    <td><label>RESIDUAL AGE OF PROPERTY (YEARS)</label></td>
    <td><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data2['residual_age_of_property'] ?? '') ?>
    </span></td>
    <td><label>PERSON MET AT SITE</label></td>
    <td colspan="4"><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data2['person_meet_at_site_contact'] ?? '') ?>
    </span></td>
  </tr>
  <tr>
    <td> <label>APPROACH ROAD TO PROPERTY</label></td>
    <td><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data2['approach_road_to_property'] ?? '') ?>
    </span> </td>
    <td><label>TYPE OF APPROACH ROAD</label></td>
    <td><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data2['type_of_approach_road'] ?? '') ?>
    </span></td>
    <td><label>WIDTH OF APPROACH ROAD (MTRS)</label></td>
    <td colspan="4"><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data2['width_of_approach_road'] ?? '') ?>
    </span></td>
  </tr>
  <tr>
    <td><label>CLASS OF LOCALITY</label></td>
    <td><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data2['class_of_locality'] ?? '') ?>
    </span></td>
    <td><label>PROPERTY FURNISHED/UNFURNISHED</label></td>
    <td><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data2['property_furnished_unfurnished'] ?? '') ?>
    </span></td>
    <td><label>PROPERTY/DWELLING UNIT TYPE</label></td>
    <td colspan="4"><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data2['property_unit_type'] ?? '') ?>
    </span></td>
  </tr>
  <tr>
    <td><label>NATURE OF BUILDING/WING</label></td>
    <td><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data10['NA'] ?? '') ?>
    </span></td>
    <td><label>STRUCTURE TYPE</label></td>
    <td><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data4['structure_type'] ?? '') ?>
    </span></td>
    <td><label>STRUCTURALLY FIT</label></td>
    <td colspan="4"><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data2['structurally_fit'] ?? '') ?>
    </span></td>
  </tr>

  <!-- CRITICAL PARAMETERS CHECK -->
  <tr><td colspan="9" class="section-title">CRITICAL PARAMETERS CHECK</td></tr>
  <tr>
    <td><label>ZONING AS PER DEVELOPMENT PLAN</label></td>
    <td><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data4['zoning_development_plan'] ?? '') ?>
    </span></td>
    <td><label>CURRENT PROPERTY USAGE</label></td>
    <td><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data4['current_property_usage'] ?? '') ?>
    </span></td>
    <td><label>APPROVED PROPERTY USAGE</label></td>
    <td colspan="4"><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data4['approved_property_usage'] ?? '') ?>
    </span></td>
  </tr>
  <tr>
    <td><label>DEVIATIONS TO APPROVED PLAN</label></td>
    <td colspan="2"><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data10['NA'] ?? '') ?>
    </span></td>
    <td colspan="2"> <label>DETAILS IN CASE DEVIATION TO APPROVED PLAN</label></td>
    <td colspan="4"><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data10['NA'] ?? '') ?>
    </span></td>
  </tr>
  <tr>
    <td><label>PROPERTY IN CEILING/UNAUTHORISED LIST OF GOVT / AUTHORITY</label></td>
    <td><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data10['NA'] ?? '') ?>
    </span></td>
    <td><label>DEMOLITION RISK</label></td>
    <td><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data9['demolition_risk_1'] ?? '') ?>
    </span></td>
    <td><label>HABITATION % WITHIN 500 MTRS AROUND PROPERTY</label></td>
     <td colspan="4"><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data4['comment_on_location_risk'] ?? '') ?>
    </span></td>
  </tr>
  <tr>
    <td colspan="8"><label>REMARKS IF PROPERTY AFFECTED BY NALLAS, HT/LT LINES, RAILWAY TRACK, ROAD WIDENING, ETC.</label>
    <td><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data4['presence_of_nala'] ?? '') ?>
        <?= htmlspecialchars($data4['near_high_tension'] ?? '') ?>
    </span></td>
  </tr>
  <!-- SOCIAL INFRA, INTERNAL AND PROJECT SPECS -->
  <tr><td colspan="9" class="section-title">SOCIAL INFRA, INTERNAL AND PROJECT SPECS</td></tr>
  <tr>
    <td colspan="2"><label>PRESENCE OF SOCIAL INFRASTRUCTURE (SCHOOL, BANK, HOSPITAL, MARKET, BUS STOP, ETC)</label></td>
    <td colspan="5"><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data10['NA'] ?? '') ?>
    </span></td>
  </tr>  
  <tr>
    <td colspan="2"><label>INTERNAL PROPERTY SPECS</label></td>
    <td colspan="5"> <input type="text" value="Average" readonly></td>
  </tr>
  <tr>
    <td colspan="2"><label>PROJECT AMENITIES (CLUBHOUSE, GYM, GARDEN, POOL, ETC)</label></td>
    <td colspan="5"><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data10['NA'] ?? '') ?>
    </span></td>
  </tr>
</table>
<table>
  <!-- AREA & VALUATION DETAILS TITLE -->
  <tr>
    <td colspan="7" class="section-title">AREA & VALUATION DETAILS</td>
  </tr>
  <tr>
    <td colspan="7" class="section-subtitle">INDIVIDUAL HOUSE/BUNGALOW/UNIT WHERE VALUATION WHERE LAND & BUILDING SEPARATELY VALUED</td>
  </tr>

  <!-- LAND VALUE SECTION -->
  <tr>
    <td colspan="7" class="section-title">(A) - LAND VALUE</td>
  </tr>
  <tr>
    <td rowspan="">DOC PART DETAILS<br>VERIFIED FROM</td>
    <td colspan="2" class="center-text">Part/Doc 1 - Land Area<br>In sq.ft</td>
    <td colspan="2" class="center-text">Part/Doc 2 - Land Area<br>In sq.ft</td>
    <td colspan="2" class="center-text">Part/Doc 3 - Land Area<br>In sq.ft</td>
  </tr>
  <tr>
    <td><label>Document</label></td>
     <td colspan="2"><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data10['NA'] ?? '') ?>
    </span></td>
    <td colspan="2"><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data10['NA'] ?? '') ?>
    </span></td>
    <td colspan="2"><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data10['NA'] ?? '') ?>
    </span></td>
  </tr>
  <tr>
    <td><label>Approved Plan</label></td>
    <td colspan="2"><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data6['plot_square_feet'] ?? '') ?>
    </span></td>
    <td colspan="2"><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data10['NA'] ?? '') ?>
    </span></td>
    <td colspan="2"><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data10['NA'] ?? '') ?>
    </span></td>
  </tr>
  <tr>
    <td><label>Actual at Site</label></td>
    <td colspan="2"><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data6['actual_plot_square_feet'] ?? '') ?>
    </span></td>
    <td colspan="2"><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data10['NA'] ?? '') ?>
    </span></td>
    <td colspan="2"><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data10['NA'] ?? '') ?>
    </span></td>
  </tr>
  <tr>
    <td colspan="7"><label>Area Type adopted for valuation (Select any one only - Document/Plan/Site)</label></td>
  </tr>
  <tr>
    <td><label>Area adopted for valuation in Sq.ft</label></td>
    <td colspan="2"><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data6['final_area_square_feet'] ?? '') ?>
    </span></td>
    <td colspan="2"><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data10['NA'] ?? '') ?>
    </span></td>
    <td colspan="2"><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data10['NA'] ?? '') ?>
    </span></td>
  </tr>
  <tr>
    <td><label>RATE per sq.ft</label></td>
    <td colspan="6"><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data6['final_area_rate'] ?? '') ?>
    </span></td>
  </tr>
  <tr>
    <td><label>VALUE OF LAND (PART WISE)</label></td>
    <td colspan="2"><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data10['NA'] ?? '') ?>
    </span></td>
    <td colspan="2"><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data10['NA'] ?? '') ?>
    </span></td>
    <td colspan="2"><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data10['NA'] ?? '') ?>
    </span></td>
  </tr>
  <tr>
    <td><label>TOTAL VALUE OF LAND PART/DOC (1 + 2 + 3)</label></td>
    <td colspan="6"><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data6['total_finally_area_valuation'] ?? '') ?>
    </span></td>
  </tr>
  <tr>
    <td><label>(A) : TOTAL LAND VALUE RECOMMENDED</label></td>
    <td colspan="6"><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data6['total_area_valuation'] ?? '') ?>
    </span></td>
  </tr>

  <!-- BUILDING VALUE SECTION -->
  <tr>
    <td  colspan="7" class="section-title">(B) - BUILDING VALUE</td>
  </tr>
  <tr>
    <td rowspan="">DOC PART DETAILS<br>VERIFIED FROM</td>
    <td><label>Ground Floor<br>In sq.ft</label></td>
    <td><label>First Floor<br>In sq.ft</label></td>
    <td><label>Second Floor<br>In sq.ft</label></td>
    <td><label>Third Floor<br>In sq.ft</label></td>
    <td><label>Fourth Floor<br>In sq.ft</label></td>
    
  </tr>
  <tr>
    <td><label>Document</td>
    <td><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data8['ground_permissible'] ?? '') ?>
    </span></td>
    <td><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data8['first_permissible'] ?? '') ?>
    </span></td>
    <td><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data8['second_permissible'] ?? '') ?>
    </span></td>
    <td><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data10['NA'] ?? '') ?>
    </span></td>
    <td><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data8['other_permissible_floors'] ?? '') ?>
    </span></td>
    
  </tr>
  <tr>
    <td><label>Approved Plan</label></td>
    <td><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data8['ground_approved'] ?? '') ?>
    </span></td>
    <td><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data8['first_approved'] ?? '') ?>
    </span></td>
    <td><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data8['second_approved'] ?? '') ?>
    </span></td>
    <td><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data10['NA'] ?? '') ?>
    </span></td>
    <td><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data8['other_approved_floors'] ?? '') ?>
    </span></td>
    
  </tr>
  <tr>
    <td><label>FSI/FAR Norms</label></td>
    <td><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data10['NA'] ?? '') ?>
    </span></td>
    <td><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data10['NA'] ?? '') ?>
    </span></td>
    <td><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data10['NA'] ?? '') ?>
    </span></td>
    <td><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data10['NA'] ?? '') ?>
    </span></td>
    <td><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data10['NA'] ?? '') ?>
    </span></td>
    
  </tr>
  <tr>
    <td><label>Actual at Site</label></td>
    <td><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data8['ground_actual'] ?? '') ?>
    </span></td>
    <td><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data8['first_actual'] ?? '') ?>
    </span></td>
    <td><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data8['second_actual'] ?? '') ?>
    </span></td>
    <td><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data10['NA'] ?? '') ?>
    </span></td>
    <td><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data8['other_actual_floors'] ?? '') ?>
    </span></td>

  </tr>
  <tr>
    <td colspan="6"><label>Area Type adopted for valuation (Select any one only - Document/Plan/Site)</label></td>
  </tr>
  <tr>
    <td><label>Area adopted for valuation in Sq.ft</label></td>
    <td><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data8['ground_actual'] ?? '') ?>
    </span></td>
    <td><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data8['first_actual'] ?? '') ?>
    </span></td>
    <td><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data8['second_actual'] ?? '') ?>
    </span></td>
    <td><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data10['NA'] ?? '') ?>
    </span></td>
    <td><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data8['other_actual_floors'] ?? '') ?>
    </span></td>
    
  </tr>
  <tr>
    <td><label>RATE per sq.ft</label></td>
    <td><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data6['final_area_rate'] ?? '') ?>
    </span></td>
    <td><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data6['final_area_rate'] ?? '') ?>
    </span></td>
    <td><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data6['final_area_rate'] ?? '') ?>
    </span></td>
    <td><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data10['NA'] ?? '') ?>
    </span></td>
    <td><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data6['final_area_rate'] ?? '') ?>
    </span></td>
  </tr>
  <tr>
    <td><label>VALUE OF BLDG (FLOOR WISE)</label></td>
    <td><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data10['NA'] ?? '') ?>
    </span></td>
    <td><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data10['NA'] ?? '') ?>
    </span></td>
    <td><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data10['NA'] ?? '') ?>
    </span></td>
    <td><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data10['NA'] ?? '') ?>
    </span></td>
    <td><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data10['NA'] ?? '') ?>
    </span></td>
    
  </tr>
  <tr>
    <td><label>TOTAL VALUE OF BUILDING ALL FLOORS (1 + 2 + 3 + 4 + 5)</label></td>
    <td colspan="5"><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data6['total_finally_area_valuation'] ?? '') ?>
    </span></td>
  </tr>
  <tr>
    <td><label>(B) : TOTAL BUILDING VALUE RECOMMENDED</label></td>
    <td colspan="5"><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data6['total_area_valuation'] ?? '') ?>
    </span></td>
  </tr>
  <tr>
    <td><label></label></td>
    <td><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data10['NA'] ?? '') ?>
    </span></td>
    <td><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data10['NA'] ?? '') ?>
    </span></td>
    <td><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data10['NA'] ?? '') ?>
    </span></td>
    <td><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data10['NA'] ?? '') ?>
    </span></td>
    <td><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data10['NA'] ?? '') ?>
    </span></td>
  </tr>
</table>

<table>
  <!-- Section Title -->
  <tr>
    <td colspan="10" class="section-title">DETAILS OF ESTIMATE PROVIDED & COST CONSIDERED : IN CASE OF CONSTRUCTION, PLOT + CONSTRUCTION, EXTENSION, IMPROVEMENT LOANS</td>
  </tr>
  <!-- <tr>
    <td colspan="7"></td>
  </tr> -->

  <!-- Remarks -->
  <tr>
    <td colspan="2"><label>REMARKS ON AREA & VALUATION</label></td>
    <td colspan="8"><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data10['NA'] ?? '') ?>
    </span></td>
  </tr>

  <!-- Additional Amenities -->
  <tr>
    <td colspan="10" class="section-title">(C) ADDITIONAL AMENITIES/IMPROVEMENT DONE COST e.g. CAR PARK, FIXED INTERIORS, ADVANCE MEMBERSHIPS, MAINTENANCE CHARGES, ETC</td>
  </tr>
  <tr>
    <td>SR.NO.</td>
    <td colspan="5">AMENITY / IMPROVEMENT DESCRIPTION</td>
    <td colspan="4">AMOUNT (Rs.)</td>
  </tr>
  <tr>
    <td>1</td>
    <td colspan="5"><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data6['car_parking'] ?? '') ?>
    </span></td>
    <td colspan="4"><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data6['car_parking_amount'] ?? '') ?>
    </span></td>
  </tr>
  <tr>
    <td>2</td>
    <td colspan="5"><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data6['addition_amenities_description_2'] ?? '') ?>
    </span></td>
    <td colspan="4"><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data6['addition_amenities_amount_2'] ?? '') ?>
    </span></td>
  </tr>
  <tr>
    <td>3</td>
    <td colspan="5"><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data6['addition_amenities_description_3'] ?? '') ?>
    </span></td>
    <td colspan="4"><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data6['addition_amenities_amount_3'] ?? '') ?>
    </span></td>
  </tr>
  <tr>
    <td>4</td>
    <td colspan="5"><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data6['addition_amenities_description_4'] ?? '') ?>
    </span></td>
    <td colspan="4"><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data6['addition_amenities_amount_4'] ?? '') ?>
    </span></td>
  </tr>
  <tr>
    <td colspan="6" class="right-align"><label>TOTAL AMENITIES COST (C)</label></td>
    <td colspan="4"><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data6['amenities_total'] ?? '') ?>
    </span></td>
  </tr>

  <!-- Final Valuation -->
  <tr>
    <td><label>LAND VALUE</label></td>
    <td colspan="2"><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data6['final_area_valuation'] ?? '') ?>
    </span></td>
    <td colspan="2"><label>(A)</label></td>
    <td colspan="5"></td>
  </tr>
  <tr>  
    <td colspan="2"><label>BUILDING VALUE</label></td>
     <TD> <span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data10['NA'] ?? '') ?>
    </span></td>
    <td colspan="2"><label>(B)</label></td>
    <td colspan="5"></td>
  </tr>
  <tr>
    <td><label>AMENITIES COST CONSIDERED</label></td>
    <TD colspan="2"><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data6['amenities_total'] ?? '') ?>
    </span></td>
    <td colspan="2"><label>(C)</label></td>
    <td colspan="5"></td>
  </tr>
  <tr>
    <td colspan="2"><label>TOTAL FAIR MARKET VALUE (RS.)</label></td>
    <TD><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data6['total_finally_area_valuation'] ?? '') ?>
    </span></td>
    <td colspan="2"><label>TOTAL FAIR MARKET VALUE (RS.) IN WORDS</label></td>
    <td colspan="5"><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data6['total_valuation_words'] ?? '') ?>
    </span></td>
  </tr>
  <tr>
    <td colspan="2"><label>REALISABLE VALUE (RS.)</label></td>
<td>
    <input type="text" readonly name="valuation_90_percent" value="<?= isset($data6['total_finally_area_valuation']) ? round(floatval($data6['total_finally_area_valuation']) * 0.9, 2) : '' ?>">
</td>
    <td colspan="2"><label>REALISABLE VALUE IN WORDS</label></td>
    <td colspan="5"><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data6['distress_value_words'] ?? '') ?>
    </span>
    </td>
  </tr>
  <tr>
    <td colspan="2"><label>DISTRESS VALUE (RS.)</label></td>
    <td><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data6['total_distress_value'] ?? '') ?>
    </span></td>
    <td><label> DISTRESS VALUE (RS.)IN WORDS</label></td>
    <td><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data6['distress_value_words'] ?? '') ?>
    </span></td>
  </tr>

  <!-- Rental & Replacement Info -->
  <tr>
    <td colspan="10" class="section-title">RENTAL & REPLACEMENT COST INFORMATION</td>
  </tr>
  <tr>
    <td colspan="2"><label>GROSS MONTHLY RENTAL FOR SIMILAR PROPERTIES IN LOCALITY IN (RS.)</label></td>
    <td><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data6['gross_monthly_rental'] ?? '') ?>
    </span></td>
    <td colspan="3"><label>GOVT GUIDELINE RATE<br>Per sq.ft.</label></td>
    <td><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data6['guideline_rate'] ?? '') ?>
    </span></td>
    <td colspan="2"><label>REPLACEMENT COST (RS.)</label></td>
    <td><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data6['replacement_cost'] ?? '') ?>
    </span></td>
  </tr>

  <!-- Floor Details -->
  <tr>
    <td colspan="10" class="section-title">FLOOR DETAILS</td>
  </tr>
  <tr>
    <td rowspan="">FLOORS</td>
    <td colspan="2" class="center-text">APPROVED</td>
    <td colspan="2" class="center-text">ACTUAL / PLANNED</td>
    <td colspan="6" rowspan="2" class="center-text">REMARKS ON NO. OF FLOORS, NOS OF UNITS PER FLOOR & LIFT AVAILABILITY</td>
  </tr>
  <tr>
    <td>(A) NO OF BASEMENT(S)</td>
    <td colspan="2"><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data10['NA'] ?? '') ?>
    </span></td>
    <td colspan="2"><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data10['NA'] ?? '') ?>
    </span></td>
  </tr>
  <tr>
    <td>(B) NO OF GROUND / PARKING / STILT</td>
    <td colspan="2"><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data10['NA'] ?? '') ?>
    </span></td>
    <td colspan="2"><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data10['NA'] ?? '') ?>
    </span></td>
    <td colspan="6" rowspan="4"><textarea rows="10"  id="remarks" name="engineer_id" oninput="autoResize(this)"><?= $data8['basements_remarks'] ?? '' ?></textarea></td>
  </tr>
  <tr>
    <td>(D) NO. OF UPPER FLOOR(S)</td>
    <td colspan="2"><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data10['NA'] ?? '') ?>
    </span></td>
    <td colspan="2"><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data10['NA'] ?? '') ?>
    </span></td>
  </tr>
  <tr>
    <td>(E) = (A + B + C + D)<br>TOTAL NO. OF FLOOR(S)</td>
    <td colspan="2"><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data8['approved_configuration_building'] ?? '') ?>
    </span></td>
    <td colspan="2"><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data8['actual_configuration_building'] ?? '') ?>
    </span></td>
  </tr>
</table>

<table>
  <!-- Section Title -->
  <tr>
    <td colspan="6" class="section-title">PROPERTY CONSTRUCTION STAGE</td>
  </tr>
  <tr>
    <td colspan="6" class="subsection-title">PROPERTY COMPLETION STATUS</td>
  </tr>
  <tr>
    <td>SR.NO.</td>
    <td>ACTIVITY</td>
    <td>ALLOTTED % FOR ACTIVITY</td>
    <td>ACTIVITY COMPLETED TILL FLOOR NUMBER</td>
    <td>PRESENT COMPLETION (%)</td>
    <td>IF WORK IS BELOW PLINTH/GROUND LVL, MENTION % UPTO 30%</td>
  </tr>

  <!-- Rows for 11 activities -->
  <tr>
    <td>1</td>
    <td>EXCAVATION</td>
    <td><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data10['NA'] ?? '') ?>
    </span></td>
    <td><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data10[' '] ?? '') ?>
    </span></td>
    <td><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data10['NA'] ?? '') ?>
    </span></td>
    <td><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data10['NA'] ?? '') ?>
    </span></td>
  </tr>
  <tr>
    <td>2</td>
    <td>PLINTH</td>
    <td><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data10['NA'] ?? '') ?>
    </span></td>
    <td><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data10['NA'] ?? '') ?>
    </span></td>
    <td><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data8['plinth_present_completion'] ?? '') ?>
    </span></td>
    <td><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data10['NA'] ?? '') ?>
    </span></td>
  </tr>
  <tr>
    <td>3</td>
    <td>COLUMN UPTO ROOF LEVEL</td>
    <td><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data10['NA'] ?? '') ?>
    </span></td>
    <td><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data10['NA'] ?? '') ?>
    </span></td>
    <td><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data10['NA'] ?? '') ?>
    </span></td>
    <td><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data10['NA'] ?? '') ?>
    </span></td>
  </tr>
  <tr>
    <td>4</td>
    <td>SLAB CASTING</td>
    <td><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data10['NA'] ?? '') ?>
    </span></td>
    <td><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data10['NA'] ?? '') ?>
    </span></td>
    <td><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data10['NA'] ?? '') ?>
    </span></td>
    <td><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data10['NA'] ?? '') ?>
    </span></td>
  </tr>
  <tr>
    <td>5</td>
    <td>BRICKWORK</td>
    <td><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data10['NA'] ?? '') ?>
    </span></td>
    <td><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data10['NA'] ?? '') ?>
    </span></td>
    <td><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data8['brickwork_present_completion'] ?? '') ?>
    </span></td>
    <td><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data10['NA'] ?? '') ?>
    </span></td>
  </tr>
  <tr>
    <td>6</td>
    <td>INTERNAL PLASTER</td>
    <td><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data10['NA'] ?? '') ?>
    </span></td>
    <td><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data10['NA'] ?? '') ?>
    </span></td>
    <td><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data8['internal_plaster_present_completion'] ?? '') ?>
    </span></td>
    <td><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data10['NA'] ?? '') ?>
    </span></td>
  </tr>
  <tr>
    <td>7</td>
    <td>EXTERNAL PLASTER</td>
    <td><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data10['NA'] ?? '') ?>
    </span></td>
    <td><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data10['NA'] ?? '') ?>
    </span></td>
    <td><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data8['external_plaster_present_completion'] ?? '') ?>
    </span></td>
    <td><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data10['NA'] ?? '') ?>
    </span></td>
  </tr>
  <tr>
    <td>8</td>
    <td>FLOORING</td>
    <td><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data10['NA'] ?? '') ?>
    </span></td>
    <td><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data10['NA'] ?? '') ?>
    </span></td>
    <td><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data8['flooring_present_completion'] ?? '') ?>
    </span></td>
    <td><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data10['NA'] ?? '') ?>
    </span></td>
  </tr>
  <tr>
    <td>9</td>
    <td>PLUMBING & ELECTRIC WORK</td>
    <td><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data10['NA'] ?? '') ?>
    </span></td>
    <td><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data10['NA'] ?? '') ?>
    </span></td>
    <td><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data8['plumbing_present_completion'] ?? '') ?>
    </span></td>
    <td><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data10['NA'] ?? '') ?>
    </span></td>
  </tr>
  <tr>
    <td>10</td>
    <td>DOOR, WINDOW & PAINT</td>
    <td><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data10['NA'] ?? '') ?>
    </span></td>
    <td><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data10['NA'] ?? '') ?>
    </span></td>
    <td><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data8['door_window_paint_present_completion'] ?? '') ?>
    </span></td>
    <td><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data10['NA'] ?? '') ?>
    </span></td>
  </tr>
  <tr>
    <td>11</td>
    <td>FINISHING & POSSESSION</td>
    <td><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data10['NA'] ?? '') ?>
    </span></td>
    <td><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data10['NA'] ?? '') ?>
    </span></td>
    <td><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data8['finishing_possession_present_completion'] ?? '') ?>
    </span></td>
    <td><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data10['NA'] ?? '') ?>
    </span></td>
  </tr>

  <tr>
    <td colspan="2" class="right-align"><strong>TOTAL COMPLETION (%)</strong></td>
    <td><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data10['NA'] ?? '') ?>
    </span></td>
    <td><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data10['NA'] ?? '') ?>
    </span></td>
    <td><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data8['total_completion_present'] ?? '') ?>
    </span></td>
  </tr>

  <tr>
    <td colspan="6"><label>: REMARKS ON CONSTRUCTION MATERIALS & LABOUR AVAILABLE AT SITE, CONSTRUCTION PROGRESS PACE & DISBURSEMENT RECOMMENDED:</label></td>
  </tr>
  <tr>
    <td colspan="6"><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data10['NA'] ?? '') ?>
    </span></td>
  </tr>
</table>


 <table class="tech-doc-table">
  <tr>
    <td colspan="4" class="section-title">TECHNICAL DOCUMENTS DETAILS</td>
  </tr>
  <tr>
    <td>DOCUMENT NAME</td>
    <td>APPLICABILITY & AVAILABILITY</td>
    <td>APPROVING AUTHORITY</td>
    <td>DETAILS OF APPROVAL</td>
  </tr>

  <!-- Document rows -->
  <tr>
    <td>APPROVED LAYOUT PLAN</td>
    <td><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data9['layout_authority'] ?? '') ?>
    </span></td>
    <td><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data9['layout_authority'] ?? '') ?>
    </span></td>
    <td><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data9['layout_details'] ?? '') ?>
    </span></td>
  </tr>
  <tr>
    <td>APPROVED FLOOR PLAN</td>
    <td><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data9['floor_availability'] ?? '') ?>
    </span></td>
    <td><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data9['floor_authority'] ?? '') ?>
    </span></td>
    <td><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data9['floor_details'] ?? '') ?>
    </span></td>
  </tr>
  <tr>
    <td>CONSTRUCTION / BUILDING PERMISSION / COMMENCEMENT CERTIFICATE</td>
    <td><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data10['NA'] ?? '') ?>
    </span></td>
    <td><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data10['NA'] ?? '') ?>
    </span></td>
    <td><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data10['NA'] ?? '') ?>
    </span></td>
  </tr>
  <tr>
    <td>NON AGRICULTURAL PERMISSION / LAND CONVERSION / DIVERSION</td>
    <td><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data9['nonagricultural_details'] ?? '') ?>
    </span></td>
    <td><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data9['nonagricultural_details'] ?? '') ?>
    </span></td>
    <td><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data9['nonagricultural_details'] ?? '') ?>
    </span></td>
  </tr>
  <tr>
    <td>BUILDING COMPLETION / OCCUPATION / USE PERMISSION</td>
    <td><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data9['possesion_details'] ?? '') ?>
    </span></td>
    <td><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data9['possesion_details'] ?? '') ?>
    </span></td>
    <td><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data9['possesion_details'] ?? '') ?>
    </span></td>
  </tr>
  <tr>
    <td>LOCATION SKETCH / CERTIFICATE</td>
    <td><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data10['NA'] ?? '') ?>
    </span></td>
    <td><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data10['NA'] ?? '') ?>
    </span></td>
    <td><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data10['NA'] ?? '') ?>
    </span></td>
  </tr>
  <tr>
    <td>AUTHORITY ALLOTMENT LETTER</td>
    <td><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data10['NA'] ?? '') ?>
    </span></td>
    <td><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data10['NA'] ?? '') ?>
    </span></td>
    <td><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data10['NA'] ?? '') ?>
    </span></td>
  </tr>

  <!-- New section -->
  <tr>
    <td>CONSTRUCTION/IMPROVEMENT/EXTENSION ESTIMATE FROM REGISTERED ENGINEER/ARCHITECT</td>
    <td><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data10['NA'] ?? '') ?>
    </span></td>
    <td><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data10['NA'] ?? '') ?>
    </span></td>
    <td><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data10['NA'] ?? '') ?>
    </span></td>
  </tr>
  <tr>
    <td>E.C./CRZ/NOC/AH/NOC/ANY OTHER</td>
    <td><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data10['NA'] ?? '') ?>
    </span></td>
    <td><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data10['NA'] ?? '') ?>
    </span></td>
    <td><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data10['NA'] ?? '') ?>
    </span></td>
  </tr>
  <tr>
    <td>RERA DETAILS, IF APPLICABLE</td>
    <td><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data9['location_details'] ?? '') ?>
    </span></td>
    <td><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data9['location_details'] ?? '') ?>
    </span></td>
    <td><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data9['location_details'] ?? '') ?>
    </span></td>
  </tr>
  <tr>
    <td>ESTIMATE</td>
    <td><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data10['NA'] ?? '') ?>
    </span></td>
    <td><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data10['NA'] ?? '') ?>
    </span></td>
    <td><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data10['NA'] ?? '') ?>
    </span></td>
  </tr>
  <tr>
    <td>SALE DEED</td>
    <td><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data10['NA'] ?? '') ?>
    </span></td>
    <td><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data10['NA'] ?? '') ?>
    </span></td>
    <td><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data10['NA'] ?? '') ?>
    </span></td>
  </tr>
  <tr>
    <td>DRAFT COPY OF SALE AGREEMENT</td>
    <td><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data10['NA'] ?? '') ?>
    </span></td>
    <td><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data10['NA'] ?? '') ?>
    </span></td>
    <td><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data10['NA'] ?? '') ?>
    </span></td>
  </tr>
  <tr>
    <td colspan="4"><label>REMARKS ON DOCUMENTS VERIFIED:</label><textarea   id="remarks" name="engineer_id" oninput="autoResize(this)"><?= $data10['NA'] ?? '' ?></textarea></td>
  </tr>
</table>

<table class="recommendation-table">
  <tr>
    <td colspan="6" class="section-title">FINAL OBSERVATION & RECOMMENDATION ON THE PROPERTY</td>
  </tr>

  <tr>
    <td>UNIT CONFIGURATION</td>
    <td colspan="5"><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data10['NA'] ?? '') ?>
    </span></td>
  </tr>

  <tr>
    <td>BUILDING APPEARANCE</td>
    <td><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data10['NA'] ?? '') ?>
    </span></td>
    <td>MAINTENANCE OF BUILDING</td>
    <td   colspan="3"><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data2['structurally_fit'] ?? '') ?>
    </span></td>
  </tr>

  <tr>
    <td>PROPERTY NUMBERED</td>
    <td><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data10['NA'] ?? '') ?>
    </span></td>
    <td>COMMENT IF NOT NUMBERED</td>
    <td colspan="3"><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data10['NA'] ?? '') ?>
    </span></td>
  </tr>

  <tr>
    <td>PROPERTY DEMARCATED</td>
    <td><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data2['demarcated_at_site'] ?? '') ?>
    </span></td>
    <td>COMMENT IF NOT DEMARCATED</td>
    <td colspan="3"><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data10['NA'] ?? '') ?>
    </span></td>
  </tr>

  <tr>
    <td>PROPERTY IDENTIFIED</td>
    <td><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data10['NA'] ?? '') ?>
    </span></td>
    <td>IDENTIFICATION CONFIRMED WITH</td>
    <td colspan=""><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data10['NA'] ?? '') ?>
    </span></td>
     <td>FOUR SIDE BOUNDARY</td>
    <td><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data10['NA'] ?? '') ?>
    </span></td>
  </tr>

  <tr>
    <td colspan="2">CONSISTENCY WITH SURROUNDING PROPERTIES w.r.t NATURE, USAGE, RATES & DEVIATIONS, IF ANY</td>
    <td colspan="4"><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data10['NA'] ?? '') ?>
    </span></td>
  </tr>

  <tr>
    <td colspan="2">DEMAND, SUPPLY, AVAILABILITY OF SIMILAR PROPERTY</td>
    <td colspan="4"><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data10['NA'] ?? '') ?>
    </span></td>
  </tr>

  <tr>
    <td colspan="2">WHETHER PROPERTY IS FROM APPROVED PROJECT LIST OF RBL BANK?<br>PROVIDE DETAILS</td>
    <td colspan="4"><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data10['NA'] ?? '') ?>
    </span></td>
  </tr>

  <tr>
    <td>PROPERTY TECHNICALLY ACCEPTABLE?</td>
    <td><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data10['NA'] ?? '') ?>
    </span></td>
    <td>MARKETABILITY OF PROPERTY</td>
    <td colspan="3"><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data9['markebility'] ?? '') ?>
    </span></td>
  </tr>

  <tr>
    <td colspan="6" class="section-title">FINAL RECOMMENDATIONS/ REMARKS ON THE PROPERTY</td>
  </tr>
  <tr>
    <td colspan="6"><textarea rows="10"  id="remarks" name="engineer_id" oninput="autoResize(this)"><?= $data10['remarks'] ?? '' ?></textarea></td>
  </tr>

  <!-- PHOTO SECTION -->
  <tr>
    <td colspan="6" class="section-title">PHOTOGRAPHS TO BE ATTACHED WITH REPORT</td>
  </tr>

  <tr>
    <td>GOOGLE MAP WITH LATITUDE AND LONGITUDE / ROUTE SKETCH</td>
    <td>STREET VIEW / APPROACH ROAD TO THE PROPERTY</td>
    <td>PHOTOGRAPH OF ENGINEER WITH PROPERTY</td>
    <td colspan="3">PROPERTY PHOTO WITH PERSON SHOWING PROPERTY<br>- IN RESALE, P+C, SELF CONST</td>
  </tr>

  <tr>
    <td><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data10['NA'] ?? '') ?>
    </span></td>
    <td><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data2['approach_road_to_property'] ?? '') ?>
    </span></td>
    <td><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data10['NA'] ?? '') ?>
    </span></td>
    <td colspan="3"><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data10['NA'] ?? '') ?>
    </span></td>
  </tr>

  <tr>
    <td>PHYSICAL IDENTIFICATION / MAIN DOOR OF PROPERTY</td>
    <td>INTERNAL PHOTOGRAPH 1 (LIVING/HALL)</td>
    <td>INTERNAL PHOTOGRAPH 2 (KITCHEN)</td>
    <td colspan="3">INTERNAL PHOTOGRAPH 3 (OPTIONAL)</td>
  </tr>

  <tr>
    <td><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data10['NA'] ?? '') ?>
    </span></td>
    <td><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data10['NA'] ?? '') ?>
    </span></td>
    <td><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data10['NA'] ?? '') ?>
    </span></td>
    <td colspan="3"><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data10['NA'] ?? '') ?>
    </span></td>
  </tr>

  <tr>
    <td>INTERNAL PHOTOGRAPH 4 (OPTIONAL)</td>
    <td colspan="5">SUPPORTING DOCS (OPTIONAL)<span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data10['NA'] ?? '') ?>
    </span></td>
  </tr>
</table>
  <table>
<tr><th style="margin-bottom:-18px;">PHOTOGRAPH OF THE PROPERTY</tr></th></table>
<br>

    
<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

$servername = "localhost";
$username   = "root";
$password   = "";
$dbname     = "project_db";

$conn = new mysqli($servername, $username, $password, $dbname);
if ($conn->connect_error) {
    die("Connection failed: " . htmlspecialchars($conn->connect_error));
}

$reference_id = $_SESSION['reference_id'] ?? null;
$reference_id = $_GET['reference_id'] ?? $reference_id;

if ($reference_id) {

    // Map captions
    $captions = [
        'image1'  => 'EXTERNAL PHOTOS',
        'image2'  => 'Kitchen',
        'image3'  => 'Selfie',
        'image4'  => 'Electric Meter',
        'image6'  => 'Other 1',
        'image7'  => 'Other 2',
        'image8'  => 'Other 3',
        'image9'  => 'Other 4',
        'image10' => 'Other 5',
        'image11' => 'Other 6',
        'image12' => 'Other 7',
        'image13' => 'Other 8',
        'image14' => 'Other 9',
        'image15' => 'Other 10',
        'image16' => 'Other 11',
        'image17' => 'Other 12',
        'image18' => 'Other 13',
        'image19' => 'Other 14',
        'image20' => 'Other 15',
    ];

    // === Helper: EXIF-aware orientation detection ===
    function classify_orientation_after_exif(string $imageData): ?string {
        $size = @getimagesizefromstring($imageData);
        if (!$size || !isset($size[0], $size[1])) {
            return null;
        }
        $width  = (int)$size[0];
        $height = (int)$size[1];

        $mime = $size['mime'] ?? '';
        if ($mime === 'image/jpeg' && function_exists('exif_read_data')) {
            $tmp = @tempnam(sys_get_temp_dir(), 'exif_');
            if ($tmp !== false) {
                @file_put_contents($tmp, $imageData);
                $exif = @exif_read_data($tmp);
                @unlink($tmp);

                if (!empty($exif['Orientation'])) {
                    $orientation = (int)$exif['Orientation'];
                    if ($orientation === 6 || $orientation === 8) {
                        $t = $width; $width = $height; $height = $t;
                    }
                }
            }
        }
        return ($width >= $height) ? 'horizontal' : 'vertical';
    }

    // === Helper: Fix orientation physically with Imagick ===
    function fixImageOrientation($binaryData) {
        $img = new Imagick();
        $img->readImageBlob($binaryData);

        switch ($img->getImageOrientation()) {
            case Imagick::ORIENTATION_BOTTOMRIGHT:
                $img->rotateImage("#000", 180);
                break;
            case Imagick::ORIENTATION_RIGHTTOP:
                $img->rotateImage("#000", 90);
                break;
            case Imagick::ORIENTATION_LEFTBOTTOM:
                $img->rotateImage("#000", -90);
                break;
        }

        $img->setImageOrientation(Imagick::ORIENTATION_TOPLEFT);
        $fixed = $img->getImageBlob();
        $img->destroy();

        return $fixed;
    }

    $sql = "SELECT 
                image1, image2, image3, image4, 
                image6, image7, image8, image9, 
                image10, image11, image12, image13, image14, image15, image16, image17, image18, image19, image20
            FROM final_uploaded_images 
            WHERE reference_id = ?";

    $stmt = $conn->prepare($sql);
    if ($stmt === false) {
        die("Error preparing the SQL statement: " . htmlspecialchars($conn->error));
    }

    $stmt->bind_param("s", $reference_id);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result && $result->num_rows > 0) {
        $horizontal_images = [];
        $vertical_images   = [];

        while ($row = $result->fetch_assoc()) {
            foreach ($row as $key => $imageData) {
                if (!empty($imageData)) {

                    // Actually fix image before displaying
                    $fixedData = fixImageOrientation($imageData);

                    $orientation = classify_orientation_after_exif($fixedData) ?? 'horizontal';
                    $imgString   = base64_encode($fixedData);
                    $caption     = $captions[$key] ?? 'Image';

                    $item = [
                        'data'    => $imgString,
                        'caption' => $caption,
                        'alt'     => $key,
                    ];

                    if ($orientation === 'horizontal') {
                        $horizontal_images[] = $item;
                    } else {
                        $vertical_images[]   = $item;
                    }
                }
            }
        }

 
// Output as a stable 4-column table (works in wkhtmltopdf)
$all_images = array_merge($vertical_images, $horizontal_images);

echo '<table class="image-grid">';
$rows = array_chunk($all_images, 4);
foreach ($rows as $row) {
    echo '<tr>';
    foreach ($row as $img) {
        echo '<td>';
        echo '<div class="img-wrap">';
        echo '<img src="data:image/jpeg;base64,' . $img['data'] . '" alt="' . htmlspecialchars($img['alt']) . '">';
        echo '<div class="caption">' . htmlspecialchars($img['caption']) . '</div>';
        echo '</div>';
        echo '</td>';
    }
    // pad remaining cells to keep 4 columns
    $remaining = 4 - count($row);
    if ($remaining > 0) {
        echo str_repeat('<td></td>', $remaining);
    }
    echo '</tr>';
}
echo '</table>';

    } else {
        echo "<p style='text-align:center;'>No images found.</p>";
    }

    $stmt->close();
} else {
    echo "<p style='text-align:center;'>Reference ID is missing.</p>";
}
?>

    
      <table>
  </tr>
  <tr>

<div class="google-map-container">
<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "project_db";
$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$reference_id = $_SESSION['reference_id'] ?? null;
$reference_id = $_GET['reference_id'] ?? $reference_id;

if ($reference_id) {
    $sql = "SELECT image5 FROM final_uploaded_images WHERE reference_id = ?";
    $stmt = $conn->prepare($sql);
    if ($stmt === false) {
        die("Error preparing the SQL statement: " . $conn->error);
    }

    $stmt->bind_param("s", $reference_id);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows > 0) {
        $row = $result->fetch_assoc();
        if (!empty($row['image5'])) {
 
            echo '<div><img src="data:image/jpeg;base64,' . base64_encode($row['image5']) . '" alt="Google Map"><p>Google Map</p></div>';
        } else {
            echo "<p style='text-align:center;'>Google Map image not available.</p>";
        }
    } else {
        echo "<p style='text-align:center;'>No record found for Google Map image.</p>";
    }

    $stmt->close();
} else {
    echo "<p style='text-align:center;'>Reference ID is missing.</p>";
}
?>
</tr>
</div>
    </table>
    </table>
     <!-- <button onclick="window.print()">Download PDF</button> -->
    <form method="post">
  <input type="hidden" name="download_images" value="1">
  <button type="submit">Download All Images</button>
</form>
     <!-- <button onclick="window.print()">Download PDF</button> -->
  <button id="downloadPdf" onclick="setPrintMargins()">DOWNLOAD PDF</button>
  <script>
    document.getElementById('downloadPdf').addEventListener('click', () => {
      // Select the content you want to convert to PDF
      const element = document.getElementById('content');
      const options = {
        margin:[0,0],
        filename:'report.pdf',
        image: { type: 'jpeg', quality: 0.98 },
        html2canvas: { scale: 2 },
        jsPDF: { unit: 'in', format: 'letter', orientation: 'portrait' }
      };

      // Generate and download the PDF
      html2pdf().set(options).from(element).save();
    });
    function setPrintMargins() {
      const style = document.createElement('style');
      style.innerHTML = `
      @media print {
          body {
            margin:0.2;
          }
        }
      `;
      document.head.appendChild(style);
      window.print();
    }
    // Disable all input fields in the form
    document.querySelectorAll('input').forEach(function(input) {
        input.disabled = true;  // Disables the field completely
    });
    </script>
     </div>
    
</body>
</html>
