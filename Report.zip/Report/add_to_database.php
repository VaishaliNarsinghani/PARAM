property_details

 'electric_bill_no','relation_person_meet_at_site_contact','name_of_tenant','no_of_tenant','name_on_society_board',
 'transaction_type','property_lies_in_area','ratio_of_each_type','name_on_house_board',

 'infra_building', change to civic_amenities   

 address_details

 property_identified_through,distance_from_vendor_branch_kms,nearest_hospital_distance,nearest_national_highway_distance,
 nearest_national_highway_name,nearest_city_center_distance,nearest_city_center_name,nearest_airport_distance,nearest_airport_name,nearest_police_station_distance,
 ,nearest_police_station_name,nearest_railway_station_distance,nearest_post_office_name,
 ,address_matching,if_not_matching_then, municipal_authority_name, taluka_tehsil, street_name
 ,     

 failing_in_reservation rename caution_area





 critical_parametres




 document_area_saledeed ,Progress_remarks 


 














 structure

 number_of_units_building ,estimate_provided,old_stage_construction_allotted



 total_approved_accomodation_floors,