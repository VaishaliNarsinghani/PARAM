<?php include('auth.php'); ?>
<?php

ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

// Increase PHP execution time and memory limit
ini_set('max_execution_time', 600); // Increase execution time to 600 seconds (10 minutes)
ini_set('memory_limit', '4096M'); // Increase memory limit to 4096MB

// Database connection
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "project_db"; // Replace with your database name
$message = "";
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Step 2: Retrieve reference_id from session (if set)
$reference_id = $_SESSION['reference_id'] ?? null;

// Fetch reference_id from GET or session
$id = isset($_GET['reference_id']) ? $_GET['reference_id'] : $reference_id;
 

$conn->close();
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Image Upload Form with Slider</title>
    <link rel="shortcut icon" href="favicon.ico" type="image/x-icon">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css"> 
      <style>
        /* Loader Overlay */
        #loaderOverlay {
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background-color: rgba(255, 255, 255, 0.95);
            z-index: 9999;
            display: flex;
            justify-content: center;
            align-items: center;
            font-size: 2em;
            color: #333;
        }

        /* Optional: Prevent scrolling while loading */
        body.loading {
            overflow: hidden;
        }

        /* Dim all content when loading */
        #mainContent {
            pointer-events: none; /* Disable interaction */
            opacity: 0.5;
        }

        body:not(.loading) #mainContent {
            pointer-events: auto;
            opacity: 1;
        }
        body {
    font-family: Arial, sans-serif;
    margin: 0;
      text-transform: uppercase;
    padding: 0;
    background-color: #f4f4f4;
}

.header {
    text-align: center;
    margin: 20px 0;
}

.container {
    display: flex;
    flex-direction: column;
    /* Changed to column layout */
    gap: 20px;
    padding: 20px;
    align-items: flex-start;
    margin-left: 20px;
}

.box {
    width: 300px;
    height: 300px;
    border: 2px dashed #aaa;
    display: flex;
    flex-direction: column;
    justify-content: center;
    align-items: center;
    background-color: #fff;
    box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
    position: relative;
    margin-left: 10%;
}

.box img {
    max-width: 100%;
    max-height: 80%;
}

/* Slider modal styling */
.slider-modal {
    position: fixed;
    top: 0;
    right: -50%;
    /* Start off-screen on the right */
    width: 50%;
    height: 100vh;
    display: flex;
    justify-content: center;
    align-items: center;
    transition: right 0.5s ease;
    /* Smooth sliding transition */
    visibility: hidden;
    /* Hidden by default */
}

.slider-modal.show {
    right: 0;
    /* Slide in from the right */
    visibility: visible;
    /* Make it visible when shown */
}

.slider {
    position: relative;
    width: 100%;
    height: 70%;
    background-color: #fff;
    display: flex;
    justify-content: center;
    align-items: center;
    flex-direction: column;
    border-radius: 10px;
    overflow: hidden;
    box-shadow: 0 4px 6px rgba(0, 0, 0, 0.2);
}

.slider img {
    max-width: 90%;
    max-height: 70%;
    border-radius: 10px;
}

.slider .arrow {
    position: absolute;
    top: 50%;
    font-size: 2rem;
    font-weight: bold;
    color: black;
    cursor: pointer;
    transform: translateY(-50%);
}

.slider .arrow.left {
    left: 10px;
}

.slider .arrow.right {
    right: 10px;
}

.slider .buttons {
    margin-top: 10px;
    display: flex;
    gap: 10px;
}

.slider .close {
    position: absolute;
    top: 10px;
    right: 10px;
    font-size: 1.5rem;
    cursor: pointer;
    background: none;
    border: none;
    color: black;
}

/* Title in slider */
.slider h3 {
    font-style: italic;
    color: #333;
    margin-bottom: 10px;
}
   
.rotating-text {
          perspective: 1000px; 
  font-family: "Inter", system-ui, -apple-system, "Segoe UI", Roboto, "Helvetica Neue", Arial;/* Adds a 3D perspective effect */
  font-size:18px;
  color:black;
    text-shadow:
    0 0 6px rgba(137, 139, 139, 0.18),
    0 0 20px rgba(240, 244, 245, 0.95),
    0 6px 20px rgba(0,0,0,0.6);
  -webkit-text-stroke: 0.6px rgba(81, 85, 85, 0.6);
  margin-left:10px;
  font-weight:bold;
  display: inline-block;
  margin-bottom:10px;
  }
  .logo {
    /* width: 50px; */
    height:53px;
    padding:10px;
    padding-bottom: 33px;
    mix-blend-mode: multiply;
  }
  
#sidebar {
    background: #B0C4DE; /* Light Steel Blue */
    color: #2C3E50; 
    position: fixed;
    left: -250px;
    top: 0;
    width: 250px;
    height: 100%;
    /* background-color: #111; */
    color: white;
    transition: left 0.3s ease;
    padding: 20px;
}

#sidebar.active {
    left: 35px;
    /* background:grey; */
}
    /* Sidebar */
    .sidebar {
      width: 250px;
      background: #B0C4DE; /* Light Steel Blue */
      color: #2C3E50; /* Dark Grayish Blue */
      padding:20px;
      height: 100vh;
      position: fixed;
      left: 0;
      top: 0;
      z-index: 1000;
      transition: transform 0.3s ease-in-out;
    }
    .sidebar.hidden {
      transform: translateX(-100%);
    }
   .sidebar h1 {
  font-size: 16px;
  margin: 14px 0 20px -10px;
  color: #a30828;
  font-weight: bold;
  position: relative;
  display: inline-block;
  text-transform: uppercase;
  letter-spacing: 1px;

  /* Minimal white shadow */
  text-shadow: 1px 1px 2px rgba(255, 255, 255, 0.8);

  /* Initial state for slide-in */
  opacity: 0;
  transform: translateX(-30px);
  animation: slideIn 0.8s ease-out forwards;
}

/* Keyframes for entrance animation */
@keyframes slideIn {
  to {
    opacity: 1;
    transform: translateX(0);
  }
}

    .sidebar a {
      padding: 15px 20px;
        margin: 10px 0;
        text-decoration: none;
        color: #2C3E50; /* Dark Grayish Blue */
        font-size:16px;
        font-style: italic;
        font-weight: 500;
        margin-bottom:10px;
        border-radius: 5px;
        transition: all 0.3s ease;
        display: flex;
        align-items: center;
    }
  .sidebar a:hover,
  .sidebar a.active {
    background: #4A90E2; /* Light Blue */
    color: white;
    transform: translateX(10px);
  }
  .sidebar a .icon {
    margin-right: 15px;
    font-size: 18px;
  }
/* Toggle Button */
#toggleSidebar {
    border-radius: 20%;
    position: fixed;
    top: 0px;
    /* Adjusted for better placement */
    left: 0px;
    /* Adjusted for better placement */
    z-index: 1000;
    background-color: rgb(130, 183, 226);
    color: white;
    border: none;
    padding: 6px 12px;
    /* Added padding for a more clickable area */
    cursor: pointer;
    box-shadow: 0 4px 8px rgba(0, 0, 0, 0.7);
    /* Adds a soft shadow for depth */
    transition: all 0.3s ease;
    /* Smooth transition for hover and active states */
}

/* Button hover effect */
#toggleSidebar:hover {
    background-color: #1c6abf;
    /* Slightly darker shade on hover */
    transform: scale(1);
    /* Slightly enlarges the button for a professional hover effect */
    box-shadow: 0 6px 12px rgba(0, 0, 0, 0.3);
    /* Stronger shadow on hover */
}

/* Active state for the button */
#toggleSidebar.active {
    background-color: #1a4f82;
    /* Darker shade for active state */
    transform: rotate(180deg);
    /* Smooth rotate effect when the sidebar is active */
}

/* Button icon (if you use an icon inside the button) */
#toggleSidebar i {
    font-size: 18px;
    /* Adjust the icon size */
    transition: transform 0.3s ease;
    /* Smooth transition when rotating */
}

.watch-icon {
    margin-right: 16px;
    /* Adds space between the search text and the watch icon */
    color: #555;
    /* Optional: sets the color of the watch icon */
}

#toggleSidebar {
    border-radius: 20%;
    position: fixed;
    top: 0px;
    /* Adjust for better placement */
    /* right: -35px; Position it just outside the sidebar */
    z-index: 1001;
    background-color: rgb(130, 183, 226);
    color: white;
    border: none;
    padding: 6px 12px;
    cursor: pointer;
    box-shadow: 0 4px 8px rgba(0, 0, 0, 0.7);
    transition: all 0.3s ease;
}

/* Button hover effect */
#toggleSidebar:hover {
    background-color: #1c6abf;
    box-shadow: 0 6px 12px rgba(0, 0, 0, 0.3);
}

/* Active state for the button */
#toggleSidebar.active {
    background-color: #1a4f82;
    transform: rotate(180deg);
    /* Smooth 180-degree rotation */
    box-shadow: 0 6px 12px rgba(0, 0, 0, 0.5);
}

/* Sidebar */
#sidebar.active+#toggleSidebar {
    right: 250px;
    /* Adjust so button moves into view */
}

/* Sidebar when active */
#sidebar.active {
    left: 0px;
}

/* Sidebar hidden state */
#sidebar {
    position: fixed;
    left: -318px;
    top: 0;
    width: 250px;
    height: 100%;
    background: #B0C4DE;
    color: white;
    transition: left 0.3s ease;
}

#pdf-container {
    width: 100%;
    height: 100%;
    overflow: auto;
}

canvas {
    display: block;
    margin: 0 auto;
}

/* Modal background */
/* Modal background */
.modal {
    display: none;
    /* Hidden by default */
    position: fixed;
    /* Stay in place */
    z-index: 1;
    /* Sit on top */
    left: 0;
    top: 0;
    width: 100%;
    /* Full width */
    height: 100%;
    /* Full height */
    overflow: auto;
    /* Enable scroll if needed */
    background-color: rgba(0, 0, 0, 0.6);
    /* Slightly darker overlay for a more professional look */
    animation: fadeIn 0.6s ease-out;
    /* Smooth fade-in effect */
}

/* Modal Content */
.modal {
    display: none;
    /* Hidden by default */
    position: fixed;
    /* Stay in place */
    z-index: 1;
    /* Sit on top */
    left: 0;
    top: 0;
    width: 100%;
    /* Full width */
    height: 100%;
    /* Full height */
    overflow: auto;
    /* Enable scroll if needed */
    background-color: rgba(0, 0, 0, 0.6);
    /* Slightly darker overlay for a more professional look */
    animation: fadeIn 0.6s ease-out;
    /* Smooth fade-in effect */
}

/* Modal Content */
.modal-content {
    font-family: 'Helvetica Neue', sans-serif;
    /* Modern and clean font */
    color: #333;
    /* Dark text for good readability */
    font-size: 12px;
    /* Keeping the font size as requested */
    background: linear-gradient(145deg, rgb(196, 216, 236), rgb(201, 212, 218));
    /* Soft gradient background */
    border-radius: 12px;
    /* Rounded corners */
    margin: auto;
    margin-top: 40px;
    padding-left: 40px;
    /* padding-right: 40px; */
    /* padding-top: 30px; Extra padding at the top for balance */
    /* padding-bottom: 30px; Extra padding at the bottom for balance */
    border: 1px solid #ccc;
    /* Light border for subtle effect */
    width: 70%;
    /* Responsive width */
    transform: scale(0.8);
    /* Initial scale for animation */
    animation: scaleUp 0.5s ease-in-out forwards;
    /* Smooth scaling animation */
    box-shadow: 0 15px 25px rgba(0, 0, 0, 0.1);
    /* Soft shadow for depth */
    transition: all 0.3s ease-in-out;
    /* Smooth transition effect */
    overflow: hidden;
    /* To ensure smooth edges */
}

/* Modal fade-in animation */
@keyframes fadeIn {
    from {
        opacity: 0;
    }

    to {
        opacity: 1;
    }
}

/* Scale-up animation */
@keyframes scaleUp {
    from {
        transform: scale(0.8);
        opacity: 0;
    }

    to {
        transform: scale(1);
        opacity: 1;
    }
}

/* Adjust the close button styling */
.slider .close {
    position: absolute;
    top: 10px;
    right: 10px;
    font-size: 1.5rem;
    cursor: pointer;
    background: none;
    border: none;
    color: black;
    transition: color 0.3s ease;
}

/* The close button inside modal */
.close {
    float: right;
    color: #e74c3c;
    font-size: 38px;
    /* Larger size for close button */
    font-weight: bold;
    cursor: pointer;
    transition: color 0.3s ease, transform 0.3s ease-in-out;
    padding: 0 10px;
    /* Extra space around close button */
}

.close:hover {
    color: #c0392b;
    /* Change color on hover */
    transform: scale(1.2);
    /* Slightly enlarge the close button on hover */
}


/* Stylish list items inside the modal */
.modal-content ul {
    list-style-type: decimal;
    /* Use numbers for list items */
    margin-top: 20px;
    padding-left: 25px;
    /* Add padding to list items */
    color: #555;
    /* Lighter text color for better contrast */
}

.modal-content ul li {
    /* margin-bottom: 10px; */
    line-height: 1.6;
    /* Increased line height for better readability */
    padding-left: 10px;
    /* Padding to align list items nicely */
    transition: transform 0.2s ease-in-out;
    /* Smooth transition effect on hover */
}

.modal-content ul li:hover {
    transform: translateX(5px);
    /* Subtle animation on hover for list items */
}

/* Optional: Add a smooth transition effect when content changes */
.modal-content {
    transition: transform 0.5s ease, opacity 0.5s ease;
}

.tab-links {
  position: fixed;
     gap:9px;
  top: 0;
  left: 0; right: 0;
  z-index: 999;
  display: flex;
  justify-content: space-between;
  padding: 7px;
  overflow-x: auto;
  backdrop-filter: blur(12px);
  border-bottom: 2px solid rgba(0,0,0,0.05);
  box-shadow: 0 2px 10px rgba(0,0,0,0.08);
  text-align: center;
}

.tab-links .tab {
   border: 1px solid #ddd;
  padding:1px 27px;
  border-radius: 50px;
  font-size: 14px;
  font-weight: bold;
  color: #444;

  transition: all 0.3s ease;
  cursor: pointer;
}

.tab-links .tab.active {
  background: linear-gradient(135deg, #9d7cc1ff, #5d7aacff);
  color: #fff;
    box-shadow: 0 12px 30px rgba(106, 17, 203, 0.35),
              0 6px 15px rgba(37, 117, 252, 0.25);
  transition: all 0.5s cubic-bezier(0.25, 1, 0.5, 1);
  animation: gradientMove 4s ease infinite, float 6s ease-in-out infinite;
  transform: scale(1.05);
  box-shadow: 0 4px 12px rgba(0,0,0,0.2);

}

/* Tab Icon */
.tab img {
  width: 45px;
  height: 45px;
  margin-bottom:5px;
  transition: transform 0.3s ease;
}
.tab:hover img {
  transform: rotate(10deg) scale(1.1);
}


/* Optional: Adjust body or main content margin to accommodate the fixed navbar height */
body {
    margin: 0;
    padding-top: 80px;
    /* Adjust this value based on your navbar's height */
}

/* Styling the scrollbar for the entire page */
::-webkit-scrollbar {
    width: 12px;
    /* Width of the vertical scrollbar */
    height: 10px;
    /* Height of horizontal scrollbar */
}

/* Styling the scrollbar track */
::-webkit-scrollbar-track {
    background: linear-gradient(135deg, #f0f0f0, #e0e0e0);
    /* Light gradient track */
    border-radius: 10px;
    /* Rounded corners */
    box-shadow: inset 0 0 10px rgba(0, 0, 0, 0.1);
    /* Subtle shadow */
}

/* Styling the scrollbar thumb (the draggable part) */
::-webkit-scrollbar-thumb {
    background: linear-gradient(135deg, #2f7cab, #0056b3);
    /* Gradient thumb */
    border-radius: 10px;
    /* Rounded corners */
    border: 3px solid transparent;
    /* Add space around thumb */
    background-clip: content-box;
    /* Ensures the thumb’s background doesn’t overlap the border */
    transition: background 0.3s ease, transform 0.3s ease;
    /* Smooth transition for hover */
}

/* Hover effect for the scrollbar thumb */
::-webkit-scrollbar-thumb:hover {
    background: linear-gradient(135deg, #0056b3, #003d80);
    /* Darker gradient on hover */
    transform: scale(1.1);
    /* Slightly enlarge the thumb */
}

/* Styling the horizontal scrollbar */
::-webkit-scrollbar-horizontal {
    height: 8px;
}

/* Styling the horizontal scrollbar track */
::-webkit-scrollbar-track-horizontal {
    background: linear-gradient(135deg, #f0f0f0, #e0e0e0);
    /* Light gradient track */
    border-radius: 10px;
    box-shadow: inset 0 0 10px rgba(0, 0, 0, 0.1);
}

/* Styling the horizontal scrollbar thumb */
::-webkit-scrollbar-thumb-horizontal {
    background: linear-gradient(135deg, #2f7cab, #0056b3);
    border-radius: 10px;
    border: 3px solid transparent;
    background-clip: content-box;
    transition: background 0.3s ease, transform 0.3s ease;
}

/* Hover effect for horizontal scrollbar thumb */
::-webkit-scrollbar-thumb-horizontal:hover {
    background: linear-gradient(135deg, #0056b3, #003d80);
    transform: scale(1.1);
    /* Slightly enlarge the thumb */
}
         .header {
 font-size:15px;background: linear-gradient(135deg, #e4dee7ff);
  color:black;
  font-weight:600;
  padding:3px;
  text-align: center;
  font-size: 20px;
  font-weight: 700;
  letter-spacing: 1px;
  border-bottom: 4px solid #fff;
  box-shadow: 0 4px 15px rgba(0,0,0,0.2);
  text-transform: uppercase;
}
/* Enhanced Submit Button */
.submit-button {
  display: flex;
  justify-content: center;
  margin: 40px 0;
  perspective: 1000px;
}

/* Button styling */
.submit-button button,
.submit-button input[type="submit"] {
  background: linear-gradient(135deg, #6a11cb 0%, #2575fc 100%);
  background-size: 200% 200%;
  border: none;
  padding: 8px 35px;
  border-radius: 999px;
  color: #fff;
  font-size: 20px;
  cursor: pointer;
  font-weight: 800;
  letter-spacing: 0.5px;
  box-shadow: 0 12px 30px rgba(106, 17, 203, 0.35),
              0 6px 15px rgba(37, 117, 252, 0.25);
  transition: all 0.5s cubic-bezier(0.25, 1, 0.5, 1);
  animation: gradientMove 4s ease infinite, float 6s ease-in-out infinite;
  position: relative;
  overflow: hidden;
  outline: none;
  -webkit-tap-highlight-color: transparent;
  transform-style: preserve-3d;
  text-transform: uppercase;
}

/* Shimmer highlight effect */
.submit-button button::before {
  content: "";
  position: absolute;
  top: -50%;
  left: -50%;
  width: 170%;
  height: 170%;
  background: linear-gradient(
    60deg, 
    rgba(255,255,255,0) 0%, 
    rgba(255,255,255,0.15) 50%, 
    rgba(255,255,255,0) 100%
  );
  transform: rotate(25deg) translateX(-100%);
  transition: transform 1.2s cubic-bezier(0.23, 1, 0.32, 1);
  pointer-events: none;
}

/* Hover effects */
.submit-button button:hover {
  transform: translateY(-8px) scale(1.08) rotateX(10deg);
  box-shadow: 0 25px 50px rgba(106, 17, 203, 0.45),
              0 15px 30px rgba(37, 117, 252, 0.35),
              0 0 40px rgba(255, 255, 255, 0.2);
  filter: brightness(1.15) saturate(1.2);
  letter-spacing: 1px;
}

.submit-button button:hover::before {
  transform: rotate(25deg) translateX(100%);
}

/* Active (press) effect */
.submit-button button:active {
  transform: translateY(-2px) scale(0.98);
  box-shadow: 0 8px 20px rgba(106, 17, 203, 0.3);
  transition: all 0.1s ease;
}

/* Pulsing glow effect */
.submit-button button::after {
  content: "";
  position: absolute;
  inset: -4px;
  border-radius: 999px;
  background: linear-gradient(135deg, #6a11cb, #2575fc, #9d7cc1, #5d7aac);
  background-size: 300% 300%;
  z-index: -1;
  filter: blur(12px);
  opacity: 0.7;
  animation: gradientMove 5s ease infinite, pulse 3s ease infinite;
  pointer-events: none;
}

/* Sparkle particles */
.submit-button .sparkle {
  position: absolute;
  width: 4px;
  height: 4px;
  background: white;
  border-radius: 50%;
  pointer-events: none;
  opacity: 0;
  animation: sparkle 1.5s linear infinite;
}
/* Floating Side Buttons */
.side-buttons {
    position: fixed;
    top: 20%;
    right: 20px;
    display: flex;
    flex-direction: column;
    gap: 10px;
    z-index: 1000;
}

.side-buttons button {
    background-color: #2f7cab;
    border: none;
    padding: 10px;
    cursor: pointer;
    border-radius: 50%;
    width: 50px;
    height: 50px;
    display: flex;
    align-items: center;
    justify-content: center;
    transition: background-color 0.3s;
}

.side-buttons button img {
    width: 24px;
    height: 24px;
    filter: invert();
}

.side-buttons button:hover {
    background-color: #0056b3;
}

@media (max-width: 768px) {
    .side-buttons {
        top: 15%;
        right: 10px;
    }

    .tab-links {
        flex-wrap: wrap;
    }
}

@media (max-width: 480px) {
    .tab-links button {
        padding: 8px 10px;
    }

    .header {
        font-size: 16px;
    }

    td {
        font-size: 14px;
    }

    input[type="text"] {
        font-size: 14px;
    }

    .side-buttons {
        top: 10%;
        right: 5px;
    }
}

.image-preview-container {
    display: flex;
    flex-wrap: wrap;
    gap: 10px;
    margin-top: 20px;
    background-color: #f8f9fa;
    border: 2px dashed #dcdcdc;
    padding: 10px;
    border-radius: 8px;
    /* justify-content: center; */
    align-items: center;
    text-align: center;
}

.image-preview-container p {
    color: #888;
    font-size: 14px;
}

.image-preview-container.hidden {
    display: none;
}

/* File input trigger button styling */
.side-buttons button {
    background-color: #2f7cab;
    border: none;
    padding: 10px;
    cursor: pointer;
    border-radius: 50%;
    width: 50px;
    height: 50px;
    display: flex;
    align-items: center;
    justify-content: center;
    transition: background-color 0.3s;
}

.valuation-table {
    width: 100%;
    border-collapse: collapse;
    /* margin-bottom: 20px; */
    font-size: 15px;
    /* margin-top: -1.1%; */
}

.valuation-table th,
.valuation-table td {
    border: 1px solid black;
    padding: 8px;
    text-align: center;
}

.valuation-table th {
    color: white;
    font-weight: bold;
}

.valuation-table tr:nth-child(odd) td {
    background-color: #e9f5fb;
}

.valuation-table td {
    background-color: #fff;
    font-weight: normal;
}
.switch-label {
  display: flex;
  align-items: center;
  justify-content: flex-end;
  font-family: 'Segoe UI', sans-serif;
  font-size: 25px;
  font-weight: 500;
  margin: 20px 0;
}

.label-text {
  margin-right: 25px;
  color: #333;
}

.switch {
  position: relative;
  display: inline-block;
  width: 65px;
  height: 43px;
}

.switch input {
  opacity: 0;
  width: 0;
  height: 0;
}

.slider.round {
  position: absolute;
  cursor: pointer;
  background-color: #ccc;
  border-radius: 34px;
  top: 0;
  left: 0;
  right: 0;
  bottom: 0;
  transition: 0.4s;
  box-shadow: inset 0 0 5px rgba(0, 0, 0, 0.2);
}

.slider.round:before {
  position: absolute;
  content: "";
  height: 24px;
  width: 24px;
  left: 4px;
  bottom: 4px;
  background-color: white;
  transition: 0.4s;
  border-radius: 50%;
}

/* When ON */
.switch input:checked + .slider.round {
  background-color: #28a745;
  box-shadow: 0 0 8px #28a74580;
}

.switch input:checked + .slider.round:before {
  transform: translateX(28px);
}

.buttons {
    margin-top: 10px;
    display: flex;
    gap: 10px;
}

.button {
    padding: 5px 10px;
    border: none;
    border-radius: 5px;
 background: linear-gradient(135deg, #6a11cb 0%, #2575fc 100%);    color: white;
    cursor: pointer;
}
    </style> 
</head>
<body>
  <!-- Sidebar -->
  <button id="toggleSidebar">&#9776;</button>
    <div id="sidebar" class="sidebar">
        <div style="display: flex">
            <img class="logo" src="logo.png" alt="" />
            <h1>Magpie Engineering</h1>
        </div>
       <div class="rotating-text">Report Drafter</div>
    <a href="clear_and_go_home.php"><i class="fas fa-home icon"></i>Home</a>        

  <a href="clear_sessions.php"><i class="fas fa-clock watch-icon"></i>Pending For Drafting</a>
 <a href="technical.php" class="active"><i class="fas fa-clipboard-list icon"></i> Preview Report</a>      
    <a href="clear_and_logout.php"><i class="fas fa-sign-out-alt icon"></i>Logout</a>
</div>

    <!-- Form Container -->
    <div class="form-container" id="formContainer">
        <!-- Success or error message display -->
        <?php if (!empty($message)): ?>
        <div class="success-message" style="text-align: center; padding: 10px; background-color: #dff0d8; color: #3c763d; border: 1px solid #d6e9c6; margin-bottom: 20px;">
            <?= htmlspecialchars($message) ?>
        </div>
        <?php endif; ?>

        <!-- Tab Links -->
        <div class="tab-links">
    <button class="tab" onclick="location.href='technical3.php'"><img src="info.png" alt="Icon" width="50  " height="50  ">
    INFO</button>
    <button class="tab " onclick="location.href='technical4.php'"><img src="general.png" alt="Icon" width="50  " height="50  ">GENERAL</button>
    <button class="tab" onclick="location.href='technical2.php'"> <img src="location.png" alt="Icon" width="50  " height="50  ">
    LOCATION</button>
    <button class="tab " onclick="location.href='technical5.php'"><img src="Zoning.png" alt="Icon" width="50  " height="50  ">
    ZONING</button>
    <button class="tab" onclick="location.href='technical7.php'"><img src="value.png" alt="Icon" width="50  " height="50  ">
    VALUE</button>
    <button class="tab" onclick="location.href='technical9.php'"><img src="Floor.png" alt="Icon" width="50  " height="50  ">
    STRUCTURE</button>
    <button  class="tab" onclick="location.href='technical10.php'"><img src="documents.png" alt="Icon" width="50  " height="50  ">
    DOCUMENTS</button>
    <button  class="tab active"  onclick="location.href='technical115.php'"><img src="photo.png" alt="Icon" width="50  " height="50  ">
    PHOTOS</button>
                

    <button class="tab" onclick="location.href='technical12.php'"><img src="remark.png" alt="Icon" width="50  " height="50  ">
    REMARK</button>          
    <button class="tab"  onclick="location.href='view_report.php'"><img src="preview.jpg" alt="Icon" width="50  " height="50  ">
    PREVIEW </button>   
 <div class="slider"></div>
 </div>
        <!-- Header Section -->
        <div class="header">
            <h3 style="font-style: italic;">IMAGE UPLOAD FORM</h3>
        </div>
         
         
     
<div class="image-gallery">
    <?php
    // Database connection
    $servername = "localhost";
    $username = "root";
    $password = "";
    $dbname = "project_db";
    $conn = new mysqli($servername, $username, $password, $dbname);

    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }

    $reference_id = $_SESSION['reference_id'] ?? null;
    $id = isset($_GET['reference_id']) ? $_GET['reference_id'] : $reference_id;

    
    if ($id) {
       $sql = "SELECT 
            image1, image2, image3, image4, image5, image6, image7, image8, image9, image10, 
            image11, image12, image13, image14, image15, image16, image17, image18, image19, image20 
        FROM final_uploaded_images 
        WHERE reference_id = ?";

        $stmt = $conn->prepare($sql);
        if ($stmt === false) {
            die("Error preparing the SQL statement: " . $conn->error);
        }

        $stmt->bind_param("s", $id);
        $stmt->execute();
        $result = $stmt->get_result();

        $labels = [
    "EXTERNAL PHOTOS", "Kitchen", "Selfie", "Electric Meter", "Google Map",
    "Other 1", "Other 2", "Other 3", "Other 4", "Other 5", "Other 6", "Other 7",
    "Other 8", "Other 9", "Other 10", "Other 11", "Other 12", "Other 13", "Other 14", "Other 15"
];

        if ($result->num_rows > 0) {
            $row = $result->fetch_assoc();
         for ($i = 1; $i <= 20; $i++) {
    $imgKey = "image" . $i;
    $encodedImage = !empty($row[$imgKey]) ? base64_encode($row[$imgKey]) : '';
    
    echo '<div class="image-container" style="margin-bottom:20px; margin-top:50px;text-align:center;">';

    echo '<img id="mainImage' . $i . '" src="' . ($encodedImage ? 'data:image/jpeg;base64,' . $encodedImage : '') . '" alt="Image ' . $i . '" style="width:900px;height:auto;border:1px solid #ccc;">';

    echo '<p style="font-weight:bold; font-size:18px; margin:10px 0;">' . $labels[$i - 1] . '</p>';

    // Centered button wrapper
    echo '<div style="display:flex; justify-content:center; gap:10px; margin-top:10px;">';
    echo '<button class="button" onclick="viewImageModal(\'mainImage' . $i . '\')">View</button>';
    echo '<button class="button" onclick="triggerUpload(' . $i . ')">Upload</button>';
    echo '<button class="button" onclick="openSelectModal(' . $i . ')">Select</button>';
    echo '</div>';

    echo '<input type="file" accept="image/*" id="uploadInput' . $i . '" style="display:none;" onchange="previewUpload(event, ' . $i . ')">';
    echo '<div id="previewContainer' . $i . '"></div>';

    echo '</div>';
}

            
        } else {
            echo "<p style='text-align:center;'>No images found.</p>";
        }
        $stmt->close();
    } else {
        echo "<p style='text-align:center;'>Reference ID is missing.</p>";
    }
    ?>

</div>
       
      
    </form>
    <!-- Image Modal for "View" -->
<div id="imageModal" style="display:none; position:fixed; top:70px; left:0; width:100%; height:100%; background:rgba(0,0,0,0.8); justify-content:center; align-items:center;">
    <span style="position:absolute;top:50px;right:250px;font-size:30px;color:white;cursor:pointer;" onclick="closeImageModal()">&times;</span>
    <img id="modalImage" src="" style="max-width:80%; max-height:80%;">
    <br>
<button onclick="downloadModalImage()" style="margin-top: 20px; padding: 10px 20px; font-size: 16px; cursor: pointer;">Download</button>
<a id="hiddenDownloadLink" style="display:none;"></a>

</div>

<!-- Select Modal -->
<div id="selectModal" style="display:none; position:fixed; top:100px; left:0; width:100%; height:100%; background:rgba(0,0,0,0.9); overflow:auto; padding:30px;">
<span style="position:fixed; top:120px; right:120px; font-size:36px; color:white; cursor:pointer; z-index:1001;" onclick="closeSelectModal()">&times;</span>
    <div id="selectImageGrid" style="display:flex; flex-wrap:wrap; gap:10px; justify-content:center;"></div>
</div> 
<script>document.addEventListener("DOMContentLoaded", function () {
    // Slider logic
    let tabs = document.querySelectorAll(".tab-links .tab");
    let slider = document.querySelector(".tab-links .slider");

    function moveSlider(activeTab) {
        slider.style.width = activeTab.offsetWidth + "px";
        slider.style.left = activeTab.offsetLeft + "px";
    }
    tabs.forEach(tab => {
        tab.addEventListener("click", function () {
            tabs.forEach(t => t.classList.remove("active"));
            this.classList.add("active");
            moveSlider(this);
        });

        if (tab.classList.contains("active")) {
            moveSlider(tab);
        }
    });
});

document.getElementById("toggleSidebar").addEventListener("click", function () {
    var sidebar = document.getElementById("sidebar");
    var toggleButton = document.getElementById("toggleSidebar");
    sidebar.classList.toggle("active");
    toggleButton.classList.toggle("active");
});
// View image in modal (UPDATED)
function viewImageModal(imageId) {
    const updatedSrc = document.getElementById(imageId).src;
    document.getElementById("modalImage").src = updatedSrc;
    document.getElementById("imageModal").style.display = "flex";
}


function closeImageModal() {
    document.getElementById("imageModal").style.display = "none";
}

// Upload handler
function triggerUpload(index) {
    document.getElementById("uploadInput" + index).click();
}
function previewUpload(event, index) {
    const file = event.target.files[0];
    if (file && file.type.startsWith("image/")) {
        const reader = new FileReader();
        reader.onload = function (e) {
            const mainImg = document.getElementById("mainImage" + index);
            mainImg.src = e.target.result;

            // Optional: clear preview container if you're using it
            const previewContainer = document.getElementById("previewContainer" + index);
            previewContainer.innerHTML = "";
        };
        reader.readAsDataURL(file);
    }
}


// Select Modal Logic
function openSelectModal(imageIndex) {
    const refId = "<?php echo $id; ?>";
    fetch(`get_images_by_ref.php?reference_id=${refId}`)
        .then(response => response.json())
        .then(data => {
            const grid = document.getElementById("selectImageGrid");
            grid.innerHTML = "";
            data.forEach((img, i) => {
                if (img) {
                    const imgElem = document.createElement("img");
                    imgElem.src = `data:image/jpeg;base64,${img}`;
                    imgElem.style.width = "800px";
                    imgElem.style.height = "auto";
                    imgElem.style.cursor = "pointer";

                    imgElem.onclick = function () {
                        document.getElementById("mainImage" + imageIndex).src = this.src;
                        closeSelectModal();
                    };
                    grid.appendChild(imgElem);
                }
            });
            document.getElementById("selectModal").style.display = "block";
        });
}

function closeSelectModal() {
    document.getElementById("selectModal").style.display = "none";
}
function downloadModalImage() {
    const image = document.getElementById("modalImage");
    const link = document.getElementById("hiddenDownloadLink");

    link.href = image.src;
    link.download = "downloaded_image.jpg"; // You can customize the name if needed
    link.click();
}
function submitImages() {
    const referenceId = "<?php echo $id; ?>";
    const imageData = {};

   for (let i = 1; i <= 20; i++) {

        const imgEl = document.getElementById("mainImage" + i);
        if (imgEl && imgEl.src.startsWith("data:image")) {
            imageData["image" + i] = imgEl.src;
        }
    }

    if (Object.keys(imageData).length === 0) {
        alert("No image changes detected.");
        return;
    }

    sendImages(referenceId, imageData);
}


// Function to fetch an image URL and convert it to base64
async function convertImageToBase64(imageUrl) {
    const response = await fetch(imageUrl);
    const blob = await response.blob();
    const reader = new FileReader();
    return new Promise((resolve, reject) => {
        reader.onloadend = () => resolve(reader.result);
        reader.onerror = reject;
        reader.readAsDataURL(blob);
    });
}

function sendImages(referenceId, imageData) {
    fetch("update_images.php", {
        method: "POST",
        headers: {
            "Content-Type": "application/json"
        },
        body: JSON.stringify({
            reference_id: referenceId,
            images: imageData
        })
    })
    .then(response => response.text())
    .then(data => {
        alert(data); // Show success message
    })
    .catch(error => {
        console.error("Error:", error);
        alert("Error updating images.");
    });
}


</script>
<div style="text-align:center; margin-top: 40px;" class="submit-button">
    <button onclick="submitImages()" >Submit</button>
</div>

</body>
</html>
