<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Image Upload Form with Slider</title>
    <link rel="stylesheet" href="REPORT11.css">
</head>
<body>
    
<button id="toggleSidebar">&#9776;</button>

<!-- Sidebar -->
<div id="sidebar" class="sidebar">
    <div style="display: flex">
      <img class="logo" src="logo.png" alt="" />
      <h1>Magpie Engineering</h1>
    </div>
    <div class="rotating-text">Report Drafter</div>
    <a href="clear_and_go_home.php"><i class="fas fa-home icon"></i>Home</a>        

    <a href="search.php"><i class="fas fa-search icon"></i>Search</a>
    <a href="Pending_Report.php"><i class="fas fa-clock watch-icon"></i>Pending For Drafting</a>
    <a href="clear_and_logout.php"><i class="fas fa-sign-out-alt icon"></i>Logout</a>

  </div>

<div class="form-container" id="formContainer" >
    <?php if (!empty($message)): ?>
        <div class="success-message" style="text-align: center; padding: 10px; background-color: #dff0d8; color: #3c763d; border: 1px solid #d6e9c6; margin-bottom: 20px;">
            <?= htmlspecialchars($message) ?>
        </div>
    <?php endif; ?>

    <div class="tab-links">
    <button class="tab" onclick="location.href='REPORT3.php'">BANK DETAILS</button>
    <button class="tab" onclick="location.href='REPORT4.php'">GENERAL DETAILS</button>
    <button class="tab" onclick="location.href='REPORT2.php'">ADDRESS</button>
    <button class="tab" onclick="location.href='REPORT5.php'">PARAMETERS</button>
    <button class="tab active" onclick="location.href='REPORT7.php'">AREA</button>
    <button class="tab" onclick="location.href='REPORT9.php'">FLOOR DETAILS</button>
    <button class="tab" onclick="location.href='REPORT10.php'">TECHNICAL DETAILS</button>
    <button class="tab" onclick="location.href='REPORT115.php'">PHOTOS</button>
    <button class="tab" onclick="location.href='REPORT12.php'">REMARK</button>
</div>
    <div class="header">
        <h2 style="font-style:italic;">IMAGE UPLOAD FORM</h2>
    </div>
    <div class="container" id="container">
        <!-- Boxes will be manually added here -->
    </div>
    <!-- Slider Modal -->
    <div class="slider-modal" id="sliderModal">
        <div class="slider">
            <h3 id="sliderTitle">Title</h3>
            <button class="close" onclick="closeSlider()">✖</button>
            <div class="arrow left" onclick="prevImage()">&#9664;</div>
            <img id="sliderImage" src="" alt="Slider Image">
            <div class="arrow right" onclick="nextImage()">&#9654;</div>
            <div class="buttons">
                <button onclick="selectImage()">Select</button>
                <button onclick="downloadImage()">Download</button>
            </div>
        </div>
    </div>

  
    <!-- Side Buttons Section -->
    <div class="side-buttons">
        <button type="button" onclick="triggerFileInput1()"><img src="https://www.iconpacks.net/icons/1/free-document-icon-901-thumb.png" alt="" width="35px" height="35px"></button>
        <button type="button" onclick="triggerFileInput2()"><img src="https://cdn-icons-png.flaticon.com/512/25/25666.png" alt="" width="35px" height="35px"></button>       
        <button type="button" onclick="openGoogleMaps()"><img src="https://cdn-icons-png.flaticon.com/512/535/535239.png" alt="" width="35px" height="35px"></button>
        <button type="button" onclick="showPopup()"><img src="https://cdn-icons-png.flaticon.com/512/1456/1456888.png" alt="" width="35px" height="35px"></button>
        <input type="file" id="imageInput" accept="image/*" style="display: none;">
        <input type="file" id="pdfInput" accept="application/pdf" style="display: none;">
    </div>

    <script src="https://cdnjs.cloudflare.com/ajax/libs/pdf.js/2.8.335/pdf.min.js"></script>
    <div class="submit-button">
                <button type="submit" name="action" value="save">Save</button>
            </div>
            <div id="imagePreviewContainer" class="image-preview-container">
                <p>Selected images will appear here</p>
            </div>
    <script>
    document.addEventListener("DOMContentLoaded", function () {
    let tabs = document.querySelectorAll(".tab-links .tab");
    let slider = document.querySelector(".tab-links .slider");

    function moveSlider(activeTab) {
        slider.style.width = activeTab.offsetWidth + "px";
        slider.style.left = activeTab.offsetLeft + "px";
    }

    tabs.forEach(tab => {
        tab.addEventListener("click", function () {
            tabs.forEach(t => t.classList.remove("active"));
            this.classList.add("active");
            moveSlider(this);
        });

        // Initialize position on load for the active tab
        if (tab.classList.contains("active")) {
            moveSlider(tab);
        }
    });
});

   document.getElementById("toggleSidebar").addEventListener("click", function() {
    var sidebar = document.getElementById("sidebar");
    var toggleButton = document.getElementById("toggleSidebar");
    
    sidebar.classList.toggle("active");
    
    // Toggle button state
    toggleButton.classList.toggle("active");
});


var modal = document.getElementById("myModal");

// Get the <span> element that closes the modal
var span = document.getElementsByClassName("close")[0];

// Function to show the modal with custom text
function showPopup(text) {
    document.getElementById("modalText").innerText = text;
    modal.style.display = "block";
}

// When the user clicks on <span> (x), close the modal
span.onclick = function() {
    modal.style.display = "none";
}

// When the user clicks anywhere outside of the modal, close it
window.onclick = function(event) {
    if (event.target == modal) {
        modal.style.display = "none";
    }
}

function openGoogleMaps(location) {
            const baseUrl = "https://www.google.com/maps/search/?api=1&query=";
            window.open(baseUrl + encodeURIComponent(location), '_blank');
        }
function triggerFileInput2() {
            document.getElementById("imageInput").click();
        }

        document.getElementById("imageInput").addEventListener("change", function (event) {
            const files = event.target.files;
            const previewContainer = document.getElementById("imagePreviewContainer");

            // Clear previous previews
            previewContainer.innerHTML = "";

            // Display previews for each selected image
            Array.from(files).forEach((file) => {
                if (file.type.startsWith("image/")) {
                    const reader = new FileReader();
                    reader.onload = function (e) {
                        const img = document.createElement("img");
                        img.src = e.target.result;
                        previewContainer.appendChild(img);
                    };
                    reader.readAsDataURL(file);
                }
            });
        });
function triggerFileInput1() {
            document.getElementById("pdfInput").click();
        }

        // Handle file selection
        document.getElementById("pdfInput").addEventListener("change", function (event) {
            const file = event.target.files[0];
            if (file && file.type === "application/pdf") {
                // Create a FileReader instance
                const reader = new FileReader();

                // When the file is read successfully, open it in a new tab
                reader.onload = function (e) {
                    const pdfUrl = e.target.result;

                    // Try to open the PDF in a new tab using embed
                    const newTab = window.open();
                    if (newTab) {
                        newTab.document.write('<html><body><embed src="' + pdfUrl + '" type="application/pdf" width="100%" height="100%"></body></html>');
                        newTab.document.close();

                        // Fallback if the PDF does not load correctly
                        setTimeout(function() {
                            if (newTab.document.body.innerHTML === "") {
                                // Use PDF.js as a fallback to display the PDF
                                newTab.document.body.innerHTML = '<div id="pdf-container" style="width: 100%; height: 100%;"></div>';
                                const loadingTask = pdfjsLib.getDocument(pdfUrl);
                                loadingTask.promise.then(function(pdf) {
                                    pdf.getPage(1).then(function(page) {
                                        const scale = 1.5;
                                        const viewport = page.getViewport({ scale: scale });
                                        const canvas = document.createElement('canvas');
                                        const ctx = canvas.getContext('2d');
                                        canvas.height = viewport.height;
                                        canvas.width = viewport.width;
                                        document.getElementById('pdf-container').appendChild(canvas);

                                        // Render PDF page
                                        page.render({
                                            canvasContext: ctx,
                                            viewport: viewport
                                        });
                                    });
                                });
                            }
                        }, 1000); // Check if the embed failed after 1 second
                    }
                };

                // Read the file as a data URL
                reader.readAsDataURL(file);
            } else {
                alert("Please select a valid PDF file.");
            }
        });
        // Generate 50 images
        const images = Array.from({ length: 50 }, (_, i) => 
            `https://via.placeholder.com/300x300?text=Image+${i + 1}` 
        );

        let currentIndex = 0;
        let currentBoxId = null;
        let currentBoxTitle = '';  // Variable to store box title

        // Manually adding 12 boxes with custom titles
        const container = document.getElementById('container');

        const titles = [
            'External Photo', 'Kitchen', 'Selfie', 'Electric Meter ', 'Google Map', 
            'Other1', 'Other2', 'Other3', 'Other4', 'Other4', 'Other4', 'Other5'
        ];

        for (let i = 0; i < 12; i++) {
            const box = document.createElement('div');
            box.className = 'box';
            box.id = `box${i + 1}`;
            box.innerHTML = `
                <h3 style="font-style:italic;">${titles[i]}</h3>
                <img id="img${i + 1}" src="" alt="No image selected">
                <div class="buttons">
                    <button onclick="openSlider(${i + 1}, '${titles[i]}')">Select</button>
                    <button onclick="uploadImageBox(${i + 1})">Upload</button>
                </div>
            `;
            container.appendChild(box);
        }

        function openSlider(boxId, boxTitle) {
            currentBoxId = boxId;
            currentBoxTitle = boxTitle; // Store the title of the box
            currentIndex = 0; // Reset to the first image
            document.getElementById('sliderTitle').textContent = boxTitle; // Update the title in the slider
            document.getElementById('sliderImage').src = images[currentIndex];
            document.getElementById('sliderModal').classList.add('show'); // Add the "show" class to slide in
        }

        function closeSlider() {
            document.getElementById('sliderModal').classList.remove('show'); // Remove the "show" class to slide out
        }

        function nextImage() {
            currentIndex = (currentIndex + 1) % images.length;
            document.getElementById('sliderImage').src = images[currentIndex];
        }

        function prevImage() {
            currentIndex = (currentIndex - 1 + images.length) % images.length;
            document.getElementById('sliderImage').src = images[currentIndex];
        }

        function selectImage() {
            if (currentBoxId) {
                const imgElement = document.getElementById(`img${currentBoxId}`);
                imgElement.src = images[currentIndex];
            }
            closeSlider();
        }

        function downloadImage() {
            const link = document.createElement('a');
            link.href = images[currentIndex];
            link.download = `Image_${currentIndex + 1}.jpg`;
            link.click();
        }
        function uploadImageBox(boxId) {
            const input = document.createElement('input');
            input.type = 'file';
            input.accept = 'image/*';
            input.onchange = (e) => {
                const reader = new FileReader();
                reader.onload = () => {
                    document.getElementById(`img${boxId}`).src = reader.result;
                };
                reader.readAsDataURL(e.target.files[0]);
            };
            input.click();
        }
    </script>
</body>
</html>
