<?php include('auth.php'); ?>
<?php


if (isset($_SESSION['report_in_progress'])) {
    $allowed_pages = ['technical2.php', 'technical3.php', 'technical4.php', 'technical5.php',
                      'technical6.php', 'technical7.php', 'technical8.php', 'technical9.php',
                      'technical10.php', 'technical11.php', 'technical12.php'];

    $current_page = basename($_SERVER['PHP_SELF']);

    if (!in_array($current_page, $allowed_pages)) {
        header("Location: technical3.php"); // Force user back to report
        exit();
    }
}


// Database credentials
$host = 'localhost';
$db = 'project_db';
$user = 'root';
$pass = '';

try {
    // Create database connection using PDO
    $conn = new PDO("mysql:host=$host;dbname=$db", $user, $pass);
    $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (PDOException $e) {
    die("Database connection failed: " . $e->getMessage());
}

// Check if report_id is set in session (i.e., user is logged in)
if (!isset($_SESSION['report_id'])) {
 
      // Redirect to Pending_Report.php if not logged in, without logging out
      header("Location:login1.php");
      exit();
  }


$report_id = $_SESSION['report_id'];

// Fetch records from the `mis` table where report_id matches the logged-in user
$sql = "SELECT * FROM mis 
WHERE report_id = :report_id 
AND flag_report_drafter = 1 
AND flag_report_preview = 0 ORDER BY report_assigned_at DESC;
";

$stmt = $conn->prepare($sql);
$stmt->bindParam(':report_id', $report_id, PDO::PARAM_STR);
$stmt->execute();
$results = $stmt->fetchAll(PDO::FETCH_ASSOC);

// Handle form submission logic here if necessary...


?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Property Details Form</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
    <link rel="shortcut icon" href="favicon.ico" type="image/x-icon">
    <link rel="stylesheet" href="Pending_Report18.css">
          <style>
        /* Loader Overlay */
        #loaderOverlay {
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background-color: rgba(255, 255, 255, 0.95);
            z-index: 9999;
            display: flex;
            justify-content: center;
            align-items: center;
            font-size: 2em;
            color: #333;
        }

        /* Optional: Prevent scrolling while loading */
        body.loading {
            overflow: hidden;
        }

        /* Dim all content when loading */
        #mainContent {
            pointer-events: none; /* Disable interaction */
            opacity: 0.5;
        }

        body:not(.loading) #mainContent {
            pointer-events: auto;
            opacity: 1;
        }
    </style>
</head>

<body class="loading">
    <!-- Loader -->
    <div id="loaderOverlay">LOADING, PLEASE WAIT...</div>
        <button id="toggleSidebar">&#9776;</button>

    <!-- Sidebar -->
    <div id="sidebar" class="sidebar">
        <div style="display: flex; align-items:center;">
          <img class="logo" src="logo.png" alt="" />
          <h1>Magpie Engineering</h1>
        </div>
        <div class="rotating-text">Report Drafter</div>
        <a href="clear_and_go_home.php"><i class="fas fa-home icon"></i>Home</a>        

        
      <a href="clear_sessions.php" class="active"><i class="fas fa-clock watch-icon"></i>Pending For Drafting</a>
    <a href="technical.php"><i class="fas fa-clipboard-list icon"></i> Preview Report</a>      
        <a href="clear_and_logout.php"><i class="fas fa-sign-out-alt icon"></i>Logout</a>

      </div>
      <?php
    if (!empty($results)): ?>
       <table>       <?php  
       echo "<style>
       /* Main Content */
.content {
 margin: 0; /* Remove conflicting margins */
 padding: 20px;
 animation: fadeIn 1.5s ease-in-out;
 transition: transform 0.3s ease-in-out;
}

table {
 width:98%;
 margin: 0 1% 0 3.5%; /* Use the same margin in both pages */
 border-collapse: collapse;
 background:rgb(207, 222, 240);
 color: #2C3E50;
 border-radius: 10px;
 overflow: hidden;
 table-layout: fixed; /* Enforce fixed column widths */
 
}

th, td {
 padding:10px;
 text-align: left;
 border: 1px solid rgba(255, 255, 255, 0.2);
 font-size: 15px;
 word-wrap: break-word; /* Allow wrapping of text */
 white-space: normal; /* Ensure wrapping is allowed */
 min-width:100px; /* Set a minimum width for columns */
}

th {
 font-size: 13px;
 background-color:rgb(102, 146, 190);
  color:white;
 font-weight: bold;
}

table {
   table-layout: fixed; /* Enforces fixed column widths */
}

th, td {
    /* Adjust as needed for your preferred column width */
   word-wrap: break-word; /* Allows text to wrap onto the next line */
   white-space: normal; /* Ensures wrapping is allowed */
}


tr:nth-child(even) {
  background-color:rgb(234, 236, 250);
}

tr:hover {
  background-color:rgb(138, 177, 215);
  color:white;
  font-weight:bolder;
  font-style:italic;
}
h2{
 margin-left:32% ; 
  font-style: oblique;
color: #2C3E50;
}
button{
   padding:10px 10px;
   background-color: #005f8a;
   color: white;
   text-decoration: none;
   border: none;
   border-radius: 5px;
   cursor: pointer;
   font-size: 16px;
   margin-top:10px;
}

@media (max-width: 768px) {
 

.content {
 margin-left: 0;
}

.search-filters input,
.search-filters button {
 width: 90%;
}
}
.content {
margin-left: 270px; /* Adjust based on sidebar width */
}


@media (min-width: 1200px) {

@media (max-width: 768px) {
.toggle-btn {
display: block;
}

.sidebar {
transform: translateX(-100%);
}

.sidebar.visible {
transform: translateX(0);
}

.content {
margin-left: 0;
margin:0;

}

.search-filters input,
.search-filters button {
width: 90%;
}
}

@keyframes slideIn {
from {
transform: translateX(-100%);
opacity: 0;
}

to {
transform: translateX(0);
opacity: 1;
}
}

@keyframes fadeIn {
from {
opacity: 0;
}

to {
opacity: 1;
}
}

.logo {
 width: 50px;
 height:50px;
 padding: 15px;
}
@media (max-width: 768px) {
 .toggle-btn {
   display: block;
 }

 .sidebar {
   transform: translateX(-100%);
 }

 .sidebar.visible {
   transform: translateX(0);
 }

 .content {
   margin-left: 0;

 }

 .search-filters input,
 .search-filters button {
   width: 90%;
 }
}
 
p{
  color: #2C3E50;
 text-align:center;
 font-size:30px;
 font-style:oblique;
 font-weight: 100;
}
/* Assign Button Styling */
.upload-button {
  background-color:rgb(102, 146, 190);
  color: white; /* White text color */
  border: 1px solid black; /* Black border */
  border-radius: 5px; /* Rounded corners */
  padding: 5px 10px; /* Padding for the button */
  font-size: 14px; /* Font size */
  font-weight: bold; /* Bold text */
  text-align: center; /* Center the text */
  cursor: pointer; /* Pointer cursor on hover */
  display: inline-block; /* Inline-block for proper alignment */
}

.upload-button a {
  text-decoration: none; /* Remove underline */
  color: white; /* Ensure the link text color is white */
  display: inline-block; /* Ensure proper alignment inside the button */
  width: 100%; /* Make it span the button */
  height: 100%; /* Make it span the button */
}

/* Hover effect for the button */
.upload-button:hover {
  background-color: #B0C4DE; /* Gray background on hover */
  color: white; /* Maintain white text on hover */
}

.upload-button a:hover {
  color: white; /* Ensure link remains white on hover */
}

  </style>";
      
         ?>
      <table>
        <p>Customer Information Table</p>
        <tr>
          <th>Reference Number</th>
          <th>Customer Name</th>
          <th>Address</th>
          <th>Customer Mobile Number</th>
          <th>Visit Type</th>
          <th>Bank Name</th>
          <th>MEPL Branch Name</th>
          <th>Bank Branch Name</th>

          <th>Case Type</th>
          <th>Application Number</th>
          <th>Mail ID</th>
          <th>Date</th>
          <th>Draft</th>
        </tr>


     
        <?php foreach ($results as $task): ?>
        <tr>
            <td data-label="Reference Number"><?= htmlspecialchars($task['reference_id']) ?></td>
            <td data-label="Customer Name"><?= htmlspecialchars($task['customerName']) ?></td>
            <td data-label="Address"><?= htmlspecialchars($task['address']) ?></td>
            <td data-label="Customer Mobile Number"><?= htmlspecialchars($task['customerMob']) ?></td>
            <td data-label="Visit Type"><?= htmlspecialchars($task['visitType']) ?></td>
            <td data-label="Bank Name"><?= htmlspecialchars($task['bankName']) ?></td>
            <td data-label="Branch Name"><?= htmlspecialchars($task['branchname']) ?></td>
               <td data-label=" Bank Branch Name"><?= htmlspecialchars($task['bank_branchname']) ?></td>
            <td data-label="Case Type"><?= htmlspecialchars($task['caseType']) ?></td>
            <td data-label="Application Number"><?= htmlspecialchars($task['applicationNo']) ?></td>
            <td data-label="Mail ID"><?= htmlspecialchars($task['initiatorMailId']) ?></td>
            <td data-label="Date"><?= htmlspecialchars($task['initiationDate']) ?></td>
            <td data-label="Assign">
    <a href="REPORT3.php?reference_id=<?= urlencode($task['reference_id']) ?>
        &customerName=<?= urlencode($task['customerName']) ?>
        &bankName=<?= urlencode($task['bankName']) ?>
        &branchname=<?= urlencode($task['branchname']) ?>
        &bank_branchname=<?= urlencode($task['bank_branchname']) ?>

        &applicationNo=<?= urlencode($task['applicationNo']) ?>
        &customerMob=<?= urlencode($task['customerMob']) ?>
        &caseType=<?= urlencode($task['caseType']) ?>
        &visitType=<?= urlencode($task['visitType']) ?>
        &address=<?= urlencode($task['address']) ?>" 
        class="upload-button" style="text-decoration:none;">
        DRAFT REPORT
    </a>
</td>

        </tr>
        <?php endforeach; ?>
        </table>
      <?php else: ?>
        <p style="text-align: center;">No data available</p>
      <?php endif; ?>
    </div>
  </div>
  </div>
             <!-- Script to hide loader -->
    <script>
        // Run when page is fully loaded
        window.addEventListener('load', function () {
            // Hide loader
            document.getElementById('loaderOverlay').style.display = 'none';
            // Re-enable page interaction
            document.body.classList.remove('loading');
        });
    </script>
<script>
  document.addEventListener("DOMContentLoaded", function () {
    let tabs = document.querySelectorAll(".tab-links .tab");
    let slider = document.querySelector(".tab-links .slider");

    function moveSlider(activeTab) {
        slider.style.width = activeTab.offsetWidth + "px";
        slider.style.left = activeTab.offsetLeft + "px";
    }

    tabs.forEach(tab => {
        tab.addEventListener("click", function () {
            tabs.forEach(t => t.classList.remove("active"));
            this.classList.add("active");
            moveSlider(this);
        });

        // Initialize position on load for the active tab
        if (tab.classList.contains("active")) {
            moveSlider(tab);
        }
    });
});

   document.getElementById("toggleSidebar").addEventListener("click", function() {
    var sidebar = document.getElementById("sidebar");
    var toggleButton = document.getElementById("toggleSidebar");
    
    sidebar.classList.toggle("active");
    
    // Toggle button state
    toggleButton.classList.toggle("active");
});

</script>
</body>
</html>
