<?php
session_start();
unset($_SESSION['report_id']);
session_unset();
session_destroy();

// Prevent back-button caching
header("Cache-Control: no-store, no-cache, must-revalidate, max-age=0");
header("Location: login1.php");
exit();
?>
