<?php include('auth.php'); ?>
<?php


// Define error message
$error_message = '';

// Database credentials
$host = 'localhost';
$db = 'project_db';
$user = 'root';
$pass = '';

try {
    // Create database connection using PDO
    $conn = new PDO("mysql:host=$host;dbname=$db;charset=utf8", $user, $pass);
    $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (PDOException $e) {
    die("Database connection failed: " . $e->getMessage());
}

// Check if login form is submitted
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['login'])) {
    $report_id = trim($_POST['report_id']);  // Get the user's reference ID
    $password = trim($_POST['password']);    // Get the password

    try {
        // Fetch the user record from the database using the report_id
        $sql = "SELECT * FROM report_login WHERE report_id = :report_id";
        $stmt = $conn->prepare($sql);
        $stmt->bindParam(':report_id', $report_id, PDO::PARAM_STR);
        $stmt->execute();

        $user = $stmt->fetch(PDO::FETCH_ASSOC);

        if ($user) {
            // Compare the entered password with the stored password
            if ($password === $user['password']) {
                // Set session variables upon successful login
                $_SESSION['logged_in'] = true;
                $_SESSION['report_id'] = $report_id;

                // Redirect to Pending_Report.php
                header("Location: Pending_Report.php");
                exit();
            } else {
                $error_message = "Invalid login credentials.";
            }
        } else {
            $error_message = "No user found with the given Engineer ID.";
        }
    } catch (PDOException $e) {
        $error_message = "An error occurred: " . $e->getMessage();
    }
}
?>


<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
  <title>OTP Popup</title>
<style>
    /* Reset styles */
* {
  margin: 0;
  padding: 0;
  box-sizing: border-box;
  font-family: 'Segoe UI', sans-serif;
}

body {
  background: #f0f2f5;
  display: flex;
  justify-content: center;
  align-items: center;
  height: 100vh;
}

.overlay {
  position: fixed;
  inset: 0;
  background-color: rgba(0, 0, 0, 0.6);
  display: flex;
  justify-content: center;
  align-items: center;
  animation: fadeIn 0.5s ease forwards;
}

.popup {
  background: white;
  padding: 40px 30px;
  border-radius: 15px;
  text-align: center;
  box-shadow: 0 15px 25px rgba(0,0,0,0.2);
  animation: slideUp 0.6s ease forwards;
  max-width: 90%;
  width: 400px;
}

.popup h2 {
  color: #1a1a80;
  margin-bottom: 20px;
  font-size: 24px;
  font-weight: bold;
}

.otp-inputs {
  display: flex;
  justify-content: space-between;
  gap: 10px;
  margin: 20px 0;
}

.otp-inputs input {
  width: 50px;
  height: 60px;
  font-size: 24px;
  text-align: center;
  border: 2px solid #1a1a80;
  border-radius: 8px;
  transition: all 0.2s ease-in-out;
  outline: none;
}

.otp-inputs input:focus {
  border-color: #007BFF;
  box-shadow: 0 0 10px rgba(0,123,255,0.5);
}

button#verifyBtn {
  background-color: #1a1a80;
  color: white;
  padding: 12px 30px;
  border: none;
  border-radius: 8px;
  font-weight: bold;
  cursor: pointer;
  transition: background-color 0.3s;
}

button#verifyBtn:hover {
  background-color: #000066;
}

@keyframes slideUp {
  from {
    opacity: 0;
    transform: translateY(60px);
  }
  to {
    opacity: 1;
    transform: translateY(0);
  }
}

@keyframes fadeIn {
  from { opacity: 0; }
  to { opacity: 1; }
}

</style>
</head>
<body>
  <div class="overlay">
    <div class="popup">
      <h2>Enter OTP</h2>
      <div class="otp-inputs">
        <input type="text" maxlength="1" />
        <input type="text" maxlength="1" />
        <input type="text" maxlength="1" />
        <input type="text" maxlength="1" />
        <input type="text" maxlength="1" />
        <input type="text" maxlength="1" />
      </div>
      <button id="verifyBtn">VERIFY</button>
    </div>
  </div>

  <script>
    const inputs = document.querySelectorAll(".otp-inputs input");

inputs.forEach((input, index) => {
  input.addEventListener("input", () => {
    if (input.value.length === 1 && index < inputs.length - 1) {
      inputs[index + 1].focus();
    }
  });

  input.addEventListener("keydown", (e) => {
    if (e.key === "Backspace" && input.value === "" && index > 0) {
      inputs[index - 1].focus();
    }
  });
});

document.getElementById("verifyBtn").addEventListener("click", () => {
  const otp = Array.from(inputs).map(input => input.value).join("");
  alert("Entered OTP: " + otp);
});

  </script>
</body>
</html>
