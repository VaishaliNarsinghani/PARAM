 <?php include('auth.php'); ?>
<?php

if (isset($_SESSION['report_in_progress'])) {
    $allowed_pages = ['technical2.php', 'technical3.php', 'technical4.php', 'technical5.php',
                      'technical6.php', 'technical7.php', 'technical8.php', 'technical9.php',
                      'technical10.php', 'technical11.php', 'technical12.php'];

    $current_page = basename($_SERVER['PHP_SELF']);

    if (!in_array($current_page, $allowed_pages)) {
        header("Location: technical3.php"); // Force user back to report
        exit();
    }
}

$message = "";

// Check if the form is submitted
if ($_SERVER["REQUEST_METHOD"] === "POST") {
    if (isset($_POST['action']) && $_POST['action'] === 'save') {
        // Save form data in the session
        $_SESSION['bank_details'] = array_map(function ($item) {
            return $item ?: '';
        }, $_POST);
        
        $message = "Bank details saved successfully!";
    } elseif (isset($_POST['action']) && $_POST['action'] === 'submit') {
        // Simulate saving all data to the database or another process
        // Clear session data after submission
        unset($_SESSION['bank_details']);

        // Redirect to a confirmation page
        header("Location: REPORT3.php");
        exit();
    }
}
?>

<!-- JavaScript for Alert -->
<script>
    <?php if (!empty($message)): ?>
    alert("<?= htmlspecialchars($message) ?>");
    <?php endif; ?>
</script>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Property Details Form</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
    <link rel="shortcut icon" href="favicon.ico" type="image/x-icon">
    <link rel="stylesheet" href="home.css">
    <style>
/* Toggle Button */
#toggleSidebar {
    border-radius: 20%;
    position: fixed;
    top: 0px; /* Adjusted for better placement */
    left: 0px; /* Adjusted for better placement */
    z-index: 1000;
    background-color:rgb(130, 183, 226); 
    color: white;
    margin:5px;
    border: none;
    padding: 12px 18px; /* Added padding for a more clickable area */
    cursor: pointer;
    box-shadow: 0 4px 8px rgba(0, 0, 0, 0.7); /* Adds a soft shadow for depth */
    transition: all 0.3s ease; 
    /* Smooth transition for hover and active states */
}

/* Button hover effect */
#toggleSidebar:hover {
    background-color: #1c6abf; /* Slightly darker shade on hover */
    transform: scale(1); /* Slightly enlarges the button for a professional hover effect */
    box-shadow: 0 6px 12px rgba(0, 0, 0, 0.3); /* Stronger shadow on hover */
}

/* Active state for the button */
#toggleSidebar.active {
    background-color: #1a4f82; /* Darker shade for active state */
    transform: rotate(180deg); /* Smooth rotate effect when the sidebar is active */
}

/* Button icon (if you use an icon inside the button) */
#toggleSidebar i {
    font-size: 18px; /* Adjust the icon size */
    transition: transform 0.3s ease; /* Smooth transition when rotating */
}
.watch-icon {
    margin-right: 16px; /* Adds space between the search text and the watch icon */
    color: #555; /* Optional: sets the color of the watch icon */
}
#toggleSidebar {
    border-radius: 20%;
    position: fixed;
    top: 0px; /* Adjust for better placement */
    /* right: -35px; Position it just outside the sidebar */
    z-index: 1001;
    background-color: rgb(130, 183, 226);
    color: white;
    border: none;
    padding: 12px 18px;
    cursor: pointer;
    box-shadow: 0 4px 8px rgba(0, 0, 0, 0.7);
    transition: all 0.3s ease;
}

/* Button hover effect */
#toggleSidebar:hover {
    background-color: #1c6abf;
    box-shadow: 0 6px 12px rgba(0, 0, 0, 0.3);
}

/* Active state for the button */
#toggleSidebar.active {
    background-color: #1a4f82;
    transform: rotate(180deg); /* Smooth 180-degree rotation */
    box-shadow: 0 6px 12px rgba(0, 0, 0, 0.5);
}

/* Sidebar */
#sidebar.active + #toggleSidebar {
    right: 250px; /* Adjust so button moves into view */
}

/* Sidebar when active */
#sidebar.active {
    left: 0px;
}

/* Sidebar hidden state */
#sidebar {
    position: fixed;
    left: -310px;
    top: 0;
    width: 250px;
    height: 100%;
    background: #B0C4DE;
    color: white;
    transition: left 0.3s ease;
}
#pdf-container {
            width: 100%;
            height: 100%;
            overflow: auto;
        }
        canvas {
            display: block;
            margin: 0 auto;
        }
        .container {
    background: #fff;
    border-radius: 15px;
    padding: 30px;
    box-shadow: 0 6px 20px rgba(0, 0, 0, 0.1);
    width: auto;
    text-align: center;
    position: absolute;
    top: 20px;
    right: 20px;
    font-size: 16px;
    transition: transform 0.3s ease;
}

p {
    text-align: center;
    font-size: 18px;
    margin: 10px 0;
    font-weight: 400;
    color: #555;
    /* margin-left: 25%; */
    width: 100%;
}


  /* Time, Date, Day Styles */
  .time, .date, .day {
    padding: 12px;
    width: 70%;
    background-color: #f8f9fa;
    border-radius: 8px;
    margin-left:13%;
    margin-top: 15px;
    box-shadow: 0 3px 6px rgba(0, 0, 0, 0.1);
  }
  
  .time {
    font-size: 24px;
    margin-left:13%;
    font-weight: 700;
    background-color: #cff4f6;
    width: 70%;
  }
  
  .date, .day {
    font-size: 16px;
    font-weight: 500;
    margin-left:13%;
    background-color: #edf3f5;
    box-shadow: none;
    width: 70%;
  }
  
  /* Status Box Styling */
  .status-box {
    background: linear-gradient(135deg, #b3d8e6, #99ffcc);
    border-radius: 12px;
    padding: 20px;
    margin-top: 30px;
    margin-left:13%;
    box-shadow: 0 6px 20px rgba(0, 0, 0, 0.1);
    color: #e9dada;
    align-items: center;
    text-align: center;
    position: relative;
    overflow: hidden;
    width: 70%;
  }
  
  .status-box h2 {
    font-size: 20px;
    font-weight: 600;
    color: #151414;
    margin-bottom: 20px;
    position: relative;
    z-index: 1;
  }
  
  .status-details {
    display: flex;
    justify-content: space-between;
    align-items: center;
    position: relative;
    z-index: 1;
  }
  
  .status-details span {
    font-weight: 500;
    font-size: 14px;
    color: #0f0e0e;
  }
  
  .status-details .value {
    font-weight: 700;
    font-size: 18px;
  }
  
  .status-details .total {
    color: #ff7043;
  }
  
  .status-details .pending {
    color: #ff7043;
  }
  
  .status-box:before {
    content: '';
    position: absolute;
    top: 0;
    left: -150%;
    width: 150%;
    height: 150%;
    background: rgba(255, 255, 255, 0.2);
    animation: moving-background 6s linear infinite;
  }
  
  @keyframes moving-background {
    0% { left: -150%; }
    100% { left: 150%; }
  }
  
  /* Hover effect for the status box */
  .status-box:hover {
    transform: translateY(-5px);
  }
  
  /* Media Queries for Responsiveness */
  @media screen and (max-width: 768px) {
    .container {
        width: 90%;
        right: 5%;
        top: 5%;
        padding: 20px;
    }
  
    p {
        margin-left: 10%;
        width: 80%;
    }
  
    .status-box {
        width: 80%;
        margin-left: 10%;
    }
  
    .status-details {
        flex-direction: column;
        align-items: flex-start;
        text-align: left;
    }
  
    .status-details span {
        font-size: 16px;
    }
  
    .status-details .value {
        font-size: 16px;
    }
  }
  
@media screen and (max-width: 480px) {
    .container {
        width: 100%;
        right: 0;
        top: 10px;
        padding: 15px;
    }

    p {
        margin-left: 0;
        width: 100%;
        font-size: 16px;
    }

    .status-box {
        width: 100%;
        margin-left: 0;
    }

    .status-details {
        flex-direction: column;
        align-items: flex-start;
        text-align: left;
    }

    .status-details span {
        font-size: 14px;
    }

    .status-details .value {
        font-size: 16px;
    }
} 
    </style>
</head>
<body>
    <button id="toggleSidebar">&#9776;</button>

    <!-- Sidebar -->
    <div id="sidebar" class="sidebar">
        <div style="display: flex; align-items:center;">
          <img class="logo" src="logo.png" alt="" />
          <h1>Magpie Engineering</h1>
        </div>
        <div class="rotating-text">Report Drafter</div>
        <a href="home1.php"  class="active"><i class="fas fa-home icon"></i>Home</a>
        
        <a href="Pending_Report.php"><i class="fas fa-clock watch-icon"></i>Pending For Drafting</a>
         <a href="technical.php"><i class="fas fa-clipboard-list icon"></i> Preview Report</a>      
        <a href="clear_and_logout.php"><i class="fas fa-sign-out-alt icon"></i>Logout</a>

      </div>
      <p class="time" id="time">
            <span>Current Time:</span> Loading...
        </p>
        <p class="date">
            <span>Current Date:</span> <?php echo date("l, F j, Y"); ?>
        </p>
        <p class="day">
            <span>Current Day:</span> <?php echo date("l"); ?>
        </p>

        <!-- Creative Status Box for Total and Pending Assignments -->
        <div class="status-box">
            <h2>Assignments Status</h2>
            <div class="status-details">
                <div>
                    <span>Total:</span>
                    <span class="value total">20</span>
                </div>
                <div>
                    <span>Pending:</span>
                    <span class="value pending">5</span>
                </div>
            </div>
        </div>
    </div>

<script>
  document.addEventListener("DOMContentLoaded", function () {
    let tabs = document.querySelectorAll(".tab-links .tab");
    let slider = document.querySelector(".tab-links .slider");

    function moveSlider(activeTab) {
        slider.style.width = activeTab.offsetWidth + "px";
        slider.style.left = activeTab.offsetLeft + "px";
    }

    tabs.forEach(tab => {
        tab.addEventListener("click", function () {
            tabs.forEach(t => t.classList.remove("active"));
            this.classList.add("active");
            moveSlider(this);
        });

        // Initialize position on load for the active tab
        if (tab.classList.contains("active")) {
            moveSlider(tab);
        }
    });
});

   document.getElementById("toggleSidebar").addEventListener("click", function() {
    var sidebar = document.getElementById("sidebar");
    var toggleButton = document.getElementById("toggleSidebar");
    
    sidebar.classList.toggle("active");
    
    // Toggle button state
    toggleButton.classList.toggle("active");
});

function updateTime() {
            const timeElement = document.getElementById('time');
            const currentTime = new Date();
            
            let hours = currentTime.getHours();
            let minutes = currentTime.getMinutes();
            let seconds = currentTime.getSeconds();
            let ampm = hours >= 12 ? 'PM' : 'AM';
            
            // Convert to 12-hour format
            hours = hours % 12;
            hours = hours ? hours : 12; // 0 turns to 12
            minutes = minutes < 10 ? '0' + minutes : minutes;
            seconds = seconds < 10 ? '0' + seconds : seconds;

            const timeString = `${hours}:${minutes}:${seconds} ${ampm}`;
            timeElement.innerHTML = `<span>Current Time:</span> ${timeString}`;
        }

        // Update time every second
        setInterval(updateTime, 1000);

        // Initial time update
        updateTime();
</script>
</body>
</html>
