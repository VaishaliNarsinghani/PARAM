<?php include('auth.php'); ?>
<?php

 // Start the session

$message = "";

  // Step 2: Retrieve reference_id from session (if set)
  $reference_id = $_SESSION['reference_id'] ?? null;  // Use null if not found
  

// Check if the form is submitted
if ($_SERVER["REQUEST_METHOD"] === "POST") {
    if (isset($_POST['action']) && $_POST['action'] === 'save') {
        // Save form data in the session
        $_SESSION['surroundings_details'] = array_map(function ($item) {
            return $item ?: ''; // Replace empty fields with an empty string
        }, $_POST);

        $message = "Surroundings Details saved successfully!";
    } elseif (isset($_POST['action']) && $_POST['action'] === 'submit') {
        // Simulate saving all data to the database or other persistent storage
        // Clear session data after submission
        unset($_SESSION['surroundings_details']);

        // Redirect to the next page
        header("Location: REPORT12.php");
        exit();
    }
}
?>

<!-- JavaScript for Alert -->
<script>
    <?php if (!empty($message)): ?>
    alert("<?= htmlspecialchars($message) ?>");
    <?php endif; ?>
</script>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Property Details Form</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
    <link rel="shortcut icon" href="favicon.ico" type="image/x-icon">
    <link rel="stylesheet" href="REPOPP066.css">
        <style>
                         * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: Arial, sans-serif;
        }

        body {
            background-color: #f4f8fb;
            min-height: 100vh;
            /* padding: 20px; */
            position: relative;
        }

        .form-container {
            width: 100%;
            max-width: 100%;
            margin: 0 auto;
            display: flex;
            flex-direction: column;
            gap: 10px;
        }

        /* Tab Links Styling */
        .tab-links {
            display: flex;
            justify-content: space-between; /* Spread buttons evenly across the container */
            gap: 5px;
            /* background-color: #2f7cab; */
            padding: 10px;
            border-radius: 5px;
            flex-wrap: nowrap; /* Ensures no wrapping */
            overflow-x: auto; /* Handles overflow */
        }

        .tab-links button {
            /* background-color: */
            background-color: #2f7cab;
            color: white;
            border: none;
            padding: 10px 15px;
            border-radius: 5px;
            cursor: pointer;
            text-align: center;
            transition: background-color 0.3s, color 0.3s;
            flex: 1; /* Makes the buttons take equal width */
        }

        .tab-links button:hover {
            /* background-color: #003d80; */
                background-color:rgb(52, 137, 190)
        }

        .tab-links a {
            text-decoration: none;
            color: white;
            font-size: 14px;
        }

        .tab-links button.active {   
    background-color:rgb(28, 84, 119)
        }



        /* Styling the scrollbar for the entire page */
::-webkit-scrollbar {
    width: 12px; /* Width of the vertical scrollbar */
    height: 10px; /* Height of horizontal scrollbar */
}

/* Styling the scrollbar track */
::-webkit-scrollbar-track {
    background: linear-gradient(135deg, #f0f0f0, #e0e0e0); /* Light gradient track */
    border-radius: 10px; /* Rounded corners */
    box-shadow: inset 0 0 10px rgba(0, 0, 0, 0.1); /* Subtle shadow */
}

/* Styling the scrollbar thumb (the draggable part) */
::-webkit-scrollbar-thumb {
    background: linear-gradient(135deg, #2f7cab, #0056b3); /* Gradient thumb */
    border-radius: 10px; /* Rounded corners */
    border: 3px solid transparent; /* Add space around thumb */
    background-clip: content-box; /* Ensures the thumb’s background doesn’t overlap the border */
    transition: background 0.3s ease, transform 0.3s ease; /* Smooth transition for hover */
}

/* Hover effect for the scrollbar thumb */
::-webkit-scrollbar-thumb:hover {
    background: linear-gradient(135deg, #0056b3, #003d80); /* Darker gradient on hover */
    transform: scale(1.1); /* Slightly enlarge the thumb */
}

/* Styling the horizontal scrollbar */
::-webkit-scrollbar-horizontal {
    height: 8px;
}

/* Styling the horizontal scrollbar track */
::-webkit-scrollbar-track-horizontal {
    background: linear-gradient(135deg, #f0f0f0, #e0e0e0); /* Light gradient track */
    border-radius: 10px;
    box-shadow: inset 0 0 10px rgba(0, 0, 0, 0.1);
}

/* Styling the horizontal scrollbar thumb */
::-webkit-scrollbar-thumb-horizontal {
    background: linear-gradient(135deg, #2f7cab, #0056b3);
    border-radius: 10px;
    border: 3px solid transparent;
    background-clip: content-box;
    transition: background 0.3s ease, transform 0.3s ease;
}

/* Hover effect for horizontal scrollbar thumb */
::-webkit-scrollbar-thumb-horizontal:hover {
    background: linear-gradient(135deg, #0056b3, #003d80);
    transform: scale(1.1); /* Slightly enlarge the thumb */
}

        /* Header Styling */
        .header {
            background-color: #2f7cab;
            color: #ffffff;
            padding: 10px;
            text-align: center;
            font-weight: bold;
            /* border-radius: 10px; */
        }

        /* Main Content Styling */
        form {
            width: 100%;
        }

        table {
            width: 100%;
            border-collapse: collapse;
        }

        td {
            padding: 8px;
            text-align: left;
            vertical-align: middle;
        }

        td:nth-child(odd) {
            background-color: #e0e0ff;
            font-weight: bold;
        }

        td:nth-child(even) {
            background-color: #f9f9f9;
        }

        input[type="text"] {
            width: 100%;
            padding: 8px;
            border: 1px solid #dcdcdc;
            border-radius: 5px;
        }

        /* Submit Button Styling */
        .submit-button {
            display: flex;
            justify-content: center;
            margin-top: 20px;
        }

        .submit-button button {
            background-color: #28a745;
            color: #ffffff;
            border: none;
            padding: 10px 30px;
            cursor: pointer;
            border-radius: 5px;
            font-size: 16px;
            transition: background-color 0.3s;
        }

        .submit-button button:hover {
            background-color: #218838;
        }

        /* Floating Side Buttons */
        .side-buttons {
            position: fixed;
            top: 20%;
            right: 20px;
            display: flex;
            flex-direction: column;
            gap: 10px;
            z-index: 1000;
        }

        .side-buttons button {
            background-color: #2f7cab;
            border: none;
            padding: 10px;
            cursor: pointer;
            border-radius: 50%;
            width: 50px;
            height: 50px;
            display: flex;
            align-items: center;
            justify-content: center;
            transition: background-color 0.3s;
        }

        .side-buttons button img {
            width: 24px;
            height: 24px;
            filter: invert();
        }

        .side-buttons button:hover {
            background-color: #0056b3;
        }

        @media (max-width: 768px) {
            .side-buttons {
                top: 15%;
                right: 10px;
            }

            .tab-links {
                flex-wrap: wrap;
            }
        }

        @media (max-width: 480px) {
            .tab-links button {
                padding: 8px 10px;
            }

            .header {
                font-size: 16px;
            }

            td {
                font-size: 14px;
            }

            input[type="text"] {
                font-size: 14px;
            }

            .side-buttons {
                top: 10%;
                right: 5px;
            }
        }
        .image-preview-container {
    display: flex;
    flex-wrap: wrap;
    gap: 10px;
    margin-top: 20px;
    background-color: #f8f9fa;
    border: 2px dashed #dcdcdc;
    padding: 10px;
    border-radius: 8px;
    /* justify-content: center; */
    align-items: center;
    text-align: center;
}

.image-preview-container p {
    color: #888;
    font-size: 14px;
}

.image-preview-container.hidden {
    display: none;
}

/* File input trigger button styling */
.side-buttons button {
    background-color: #2f7cab;
    border: none;
    padding: 10px;
    cursor: pointer;
    border-radius: 50%;
    width: 50px;
    height: 50px;
    display: flex;
    align-items: center;
    justify-content: center;
    transition: background-color 0.3s;
}
.valuation-table {
    width: 100%;
    border-collapse: collapse;
    /* margin-bottom: 20px; */
    font-size: 15px;
    /* margin-top: -1.1%; */
}

.valuation-table th,
.valuation-table td {
    border: 1px solid black;
    padding: 8px;
    text-align: center;
}

.valuation-table th {
    background-color: #2f7cab;
    color: white;
    font-weight: bold;
}

.valuation-table tr:nth-child(odd) td {
    background-color: #e9f5fb;
}

.valuation-table td {
    background-color: #fff;
    font-weight: normal;
}     
.rotating-text {
            color:black;
    perspective: 1000px; /* Adds a 3D perspective effect */
    font-size: 1.5rem;
    font-weight:bold;
    width: 100%;
    animation: rotate360 3s linear infinite;
    display: inline-block;
    margin-bottom:10px;
    transform-origin: center center; /* Rotates around its center */
    text-align:center;
    /* margin-left:20px; */
    font-style: italic;
    text-shadow: 
    1px 1px 2px rgba(235, 244, 243, 0.97),
    2px 2px 4px rgba(246, 242, 242, 0.4),
    3px 3px 6px rgba(249, 252, 252, 0.89),
    4px 4px 8px rgba(248, 242, 247, 0.93),
    5px 5px 10px rgba(232, 236, 237, 0.4);
  }
  
  /* Keyframes for rotating the text */
  @keyframes rotate360 {
    0% {
      transform: rotateY(0deg); /* Starts with no rotation */
    }
    50% {
      transform: rotateY(0deg); /* Half rotation */
    }
    100% {
      transform: rotateY(360deg); /* Full rotation */
    }
  }
  .logo {
    /* width: 50px; */
    height: 83px;
    padding: 12px;
    padding-bottom: 33px;
    
  }
#sidebar {
    background: #B0C4DE; /* Light Steel Blue */
    color: #2C3E50; 
    position: fixed;
    left: -250px;
    top: 0;
    width: 250px;
    height: 100%;
    /* background-color: #111; */
    color: white;
    transition: left 0.3s ease;
    padding: 20px;
}

#sidebar.active {
    left: 35px;
    /* background:grey; */
}
.sidebar {
    width: 250px;
    background: #B0C4DE; /* Light Steel Blue */
    /* background:rgba(245, 245, 245, 0.37); Light Steel Blue */
    color: black; /* Dark Grayish Blue */
    padding:20px;
    height: 100vh;
    position: fixed;
    left: 0;
    top: 0;
    z-index: 1000;
    transition: transform 0.3s ease-in-out;
  }
  .sidebar.hidden {
    transform: translateX(-100%);
  }
  .sidebar h1 {
font-size: 20px;
margin-top: 10px;
margin-bottom: 20px;
color: #2C3E50; 
}
.sidebar a {
    padding: 15px 20px;
      margin: 10px 0;
      text-decoration: none;
      color: #2C3E50; /* Dark Grayish Blue */
      font-size:16px;
      font-style: italic;
      font-weight: 500;
      margin-bottom:70px;
      border-radius: 5px;
      transition: all 0.3s ease;
      display: flex;
      align-items: center;
  }

  .sidebar a:hover,
  .sidebar a.active {
    background: #4A90E2; /* Light Blue */
    transform: translateX(10px);
    color: white;
  }
  .sidebar a .icon {
    margin-right: 15px;
    font-size: 18px;
  }
/* Toggle Button */
#toggleSidebar {
    border-radius: 20%;
    position: fixed;
    top: 0px; /* Adjusted for better placement */
    left: 0px; /* Adjusted for better placement */
    z-index: 1000;
    background-color:rgb(130, 183, 226); 
    color: white;
    border: none;
    padding: 6px 12px; /* Added padding for a more clickable area */
    cursor: pointer;
    box-shadow: 0 4px 8px rgba(0, 0, 0, 0.7); /* Adds a soft shadow for depth */
    transition: all 0.3s ease; 
    /* Smooth transition for hover and active states */
}

/* Button hover effect */
#toggleSidebar:hover {
    background-color: #1c6abf; /* Slightly darker shade on hover */
    transform: scale(1); /* Slightly enlarges the button for a professional hover effect */
    box-shadow: 0 6px 12px rgba(0, 0, 0, 0.3); /* Stronger shadow on hover */
}

/* Active state for the button */
#toggleSidebar.active {
    background-color: #1a4f82; /* Darker shade for active state */
    transform: rotate(180deg); /* Smooth rotate effect when the sidebar is active */
}

/* Button icon (if you use an icon inside the button) */
#toggleSidebar i {
    font-size: 18px; /* Adjust the icon size */
    transition: transform 0.3s ease; /* Smooth transition when rotating */
}
.watch-icon {
    margin-right: 16px; /* Adds space between the search text and the watch icon */
    color: #555; /* Optional: sets the color of the watch icon */
}
#toggleSidebar {
    border-radius: 20%;
    position: fixed;
    top: 0px; /* Adjust for better placement */
    /* right: -35px; Position it just outside the sidebar */
    z-index: 1001;
    background-color: rgb(130, 183, 226);
    color: white;
    border: none;
    padding: 6px 12px;
    cursor: pointer;
    box-shadow: 0 4px 8px rgba(0, 0, 0, 0.7);
    transition: all 0.3s ease;
}

/* Button hover effect */
#toggleSidebar:hover {
    background-color: #1c6abf;
    box-shadow: 0 6px 12px rgba(0, 0, 0, 0.3);
}

/* Active state for the button */
#toggleSidebar.active {
    background-color: #1a4f82;
    transform: rotate(180deg); /* Smooth 180-degree rotation */
    box-shadow: 0 6px 12px rgba(0, 0, 0, 0.5);
}

/* Sidebar */
#sidebar.active + #toggleSidebar {
    right: 250px; /* Adjust so button moves into view */
}

/* Sidebar when active */
#sidebar.active {
    left: 0px;
}

/* Sidebar hidden state */
#sidebar {
    position: fixed;
    left: -250px;
    top: 0;
    width: 250px;
    height: 100%;
    background: #B0C4DE;
    color: white;
    transition: left 0.3s ease;
}
#pdf-container {
            width: 100%;
            height: 100%;
            overflow: auto;
        }
        canvas {
            display: block;
            margin: 0 auto;
        }
   /* Modal background */
/* Modal background */
.modal {
    display: none; /* Hidden by default */
    position: fixed; /* Stay in place */
    z-index: 1; /* Sit on top */
    left: 0;
    top: 0;
    width: 100%; /* Full width */
    height: 100%; /* Full height */
    overflow: auto; /* Enable scroll if needed */
    background-color: rgba(0, 0, 0, 0.6); /* Slightly darker overlay for a more professional look */
    animation: fadeIn 0.6s ease-out; /* Smooth fade-in effect */
}

/* Modal Content */
.modal {
    display: none; /* Hidden by default */
    position: fixed; /* Stay in place */
    z-index: 1; /* Sit on top */
    left: 0;
    top: 0;
    width: 100%; /* Full width */
    height: 100%; /* Full height */
    overflow: auto; /* Enable scroll if needed */
    background-color: rgba(0, 0, 0, 0.6); /* Slightly darker overlay for a more professional look */
    animation: fadeIn 0.6s ease-out; /* Smooth fade-in effect */
}

/* Modal Content */
.modal-content {
    font-family: 'Helvetica Neue', sans-serif; /* Modern and clean font */
    color: #333; /* Dark text for good readability */
    font-size: 12px; /* Keeping the font size as requested */
    background: linear-gradient(145deg,rgb(196, 216, 236),rgb(201, 212, 218)); /* Soft gradient background */
    border-radius: 12px; /* Rounded corners */
    margin: auto;
    margin-top: 40px;
    padding-left: 40px;
    /* padding-right: 40px; */
    /* padding-top: 30px; Extra padding at the top for balance */
    /* padding-bottom: 30px; Extra padding at the bottom for balance */
    border: 1px solid #ccc; /* Light border for subtle effect */
    width: 70%; /* Responsive width */
    transform: scale(0.8); /* Initial scale for animation */
    animation: scaleUp 0.5s ease-in-out forwards; /* Smooth scaling animation */
    box-shadow: 0 15px 25px rgba(0, 0, 0, 0.1); /* Soft shadow for depth */
    transition: all 0.3s ease-in-out; /* Smooth transition effect */
    overflow: hidden; /* To ensure smooth edges */
}

/* Modal fade-in animation */
@keyframes fadeIn {
    from {
        opacity: 0;
    }
    to {
        opacity: 1;
    }
}

/* Scale-up animation */
@keyframes scaleUp {
    from {
        transform: scale(0.8);
        opacity: 0;
    }
    to {
        transform: scale(1);
        opacity: 1;
    }
}

/* The Close Button */
.close {
    float:right;
    color: #e74c3c;
    font-size: 38px; /* Larger size for close button */
    font-weight: bold;
    cursor: pointer;
    transition: color 0.3s ease, transform 0.3s ease-in-out;
    padding: 0 10px; /* Extra space around close button */
}

.close:hover {
    color:rgb(238, 155, 146); /* Red color on hover */
    /* transform: rotate(45deg); Rotate the close button */
}

/* Stylish list items inside the modal */
.modal-content ul {
    list-style-type: decimal; /* Use numbers for list items */
    margin-top: 20px;
    padding-left: 25px; /* Add padding to list items */
    color: #555; /* Lighter text color for better contrast */
}

.modal-content ul li {
    /* margin-bottom: 10px; */
    line-height: 1.6; /* Increased line height for better readability */
    padding-left: 10px; /* Padding to align list items nicely */
    transition: transform 0.2s ease-in-out; /* Smooth transition effect on hover */
}

.modal-content ul li:hover {
    transform: translateX(5px); /* Subtle animation on hover for list items */
}

/* Optional: Add a smooth transition effect when content changes */
.modal-content {
    transition: transform 0.5s ease, opacity 0.5s ease;
}
        </style>
</head>

<body>
<button id="toggleSidebar">&#9776;</button>
<div id="sidebar" class="sidebar">
    <div style="display: flex">
      <img class="logo" src="logo.png" alt="" />
      <h1>Magpie Engineering</h1>
    </div>
    <div class="rotating-text">Report Drafter</div>
    <a href="clear_and_go_home.php"><i class="fas fa-home icon"></i>Home</a>        

    
  <a href="clear_sessions.php" class="active"><i class="fas fa-clock watch-icon"></i>Pending For Drafting</a>
 <a href="technical.php"><i class="fas fa-clipboard-list icon"></i> Preview Report</a>      
    <a href="clear_and_logout.php"><i class="fas fa-sign-out-alt icon"></i>Logout</a>
  </div>
<div class="form-container">
    <!-- Display success message -->
    <?php if (!empty($message)): ?>
        <div class="success-message" style="text-align: center; padding: 10px; background-color: #dff0d8; color: #3c763d; border: 1px solid #d6e9c6; margin-bottom: 20px;">
            <?= htmlspecialchars($message) ?>
        </div>
    <?php endif; ?>

    <div style="width: 100%;">
    <div class="tab-links">
    <button class="tab" onclick="location.href='REPORT3.php'">BANK DETAILS</button>
    <button class="tab" onclick="location.href='REPORT4.php'">GENERAL DETAILS</button>
    <button class="tab" onclick="location.href='REPORT2.php'">ADDRESS</button>
    <button class="tab" onclick="location.href='REPORT5.php'">PARAMETERS</button>
    <button class="tab active" onclick="location.href='REPO66.php'">SURROUNDINGS</button>
    <button class="tab" onclick="location.href='REPORT7.php'">AREA</button>
   
    <button class="tab" onclick="location.href='REPORT9.php'">FLOOR DETAILS</button>
    <button class="tab" onclick="location.href='REPORT10.php'">TECHNICAL DETAILS</button>
    <button class="tab" onclick="location.href='REPORT115.php'">PHOTOS</button>
    <button class="tab" onclick="location.href='REPORT12.php'">REMARK</button>
</div>
        <div class="main-content">
        <form action="" method="POST" style="width: 100%;">
        <table class="amenities-table valuation-table"style="margin-top:10px;">
    <thead>
        <tr>
            <th class="header" colspan="3" style="background-color: #2f7cab; color:white;">SURROUNDING EXTERNAL AMENITIES</th>
            <th  class="header" colspan="3" style="background-color: #2f7cab; color:white;">INTERNAL SPECIFICATIONS</th>
        </tr>
        <tr>
            <th>Premises List</th>
            <th>Approx. Distance</th>
            <th>Name</th>
            <th>Specification List</th>
            <th colspan="2">Details</th>
        </tr>
    </thead>
    <?php
$fields = [
    // Surrounding External Amenities
    'Nearest Bus Stop Distance' => 'nearest_bus_stop_distance',
    'Nearest Bus Stop Name' => 'nearest_bus_stop_name',
    'Nearest Railway Station Distance' => 'nearest_railway_station_distance',
    'Nearest Railway Station Name' => 'nearest_railway_station_name',
    'Nearest Airport Distance' => 'nearest_airport_distance',
    'Nearest Airport Name' => 'nearest_airport_name',
    'Nearest School/College Distance' => 'nearest_school_college_distance',
    'Nearest School/College Name' => 'nearest_school_college_name',
    'Nearest Bank Distance' => 'nearest_bank_distance',
    'Nearest Bank Name' => 'nearest_bank_name',
    'Nearest Highway/Major Road Distance' => 'nearest_highway_distance',
    'Nearest Highway/Major Road Name' => 'nearest_highway_name',
    'Nearest Hospital Distance' => 'nearest_hospital_distance',
    'Nearest Hospital Name' => 'nearest_hospital_name',
    'Nearest Multiplex/Mall/Market Distance' => 'nearest_multiplex_distance',
    'Nearest Multiplex/Mall/Market Name' => 'nearest_multiplex_name',

    // Internal Specifications
    'Structural Elements' => 'structural_elements',
    'Wall Thickness' => 'wall_thickness',
    'Plaster & Painting' => 'plaster_painting',
    'Electrification' => 'electrification',
    'Plumbing & Bath Fittings' => 'plumbing_bath_fittings',
    'Door, Windows' => 'door_windows',
    'Potable Water Connection' => 'potable_water_connection',
    'Sewerage System' => 'sewerage_system',
    'Comment on/ Infrastructure in Building' => 'infra_building',
    'Surrounding Development Percentage' => 'develop_percent'
];
        // Display the reference_id as a hidden field (assuming it will not be modified by the user)
        $reference_id = $_SESSION['reference_id'] ?? '';
        echo '<input type="hidden" name="reference_id" value="' . htmlspecialchars($reference_id) . '">';
$count = 0;
echo '<tr>';
foreach ($fields as $label => $name) {
    $value = htmlspecialchars($_SESSION['surroundings_details'][$name] ?? '');
    echo "<td><label for='$name'>$label</label></td>
          <td><input type='text' id='$name' name='$name' value='$value'></td>";
    $count++;
    if ($count % 3 === 0) {
        echo '</tr><tr>';
    }
}
echo '</tr>';
?>
</table>
<div class="submit-button">
<button type="submit" name="action" value="save">Save</button>
</div>
<div id="imagePreviewContainer" class="image-preview-container">
            <p>Selected images will appear here</p>
</form>
</div>
<div id="myModal" class="modal">
    <div class="modal-content">
        <span class="close">&times;</span>
        <p><h1 style="text-align:center; margin-top:10px;">BANK POLICIES</h1>
            <ul>
           <li style="list-style-type:decimal;">If Boundary Mismatch</li>
           <li style="list-style-type:decimal;">If Area Mismatch Or Dimension </li>
           <li style="list-style-type:decimal;">If Prakostha not available</li>
           <li style="list-style-type:decimal;">Property not Identifiable</li>
           <li style="list-style-type:decimal;">Address different at site</li>
           <li style="list-style-type:decimal;">In case of Multiple tenants</li>
           <li style="list-style-type:decimal;">In Case of Old tenants</li>
           <li style="list-style-type:decimal;">If Property is Very Old</li>
           <li style="list-style-type:decimal;">Property Fully or Partially Locked</li>
           <li style="list-style-type:decimal;">If Property in Basement ir Penthouse()Non FAR Area</li>
           <li style="list-style-type:decimal;">Plot Without Demarcation</li>
           <li style="list-style-type:decimal;">Plot Without Government Approved Layout</li>
           <li style="list-style-type:decimal;">Plot in Undeveloped Area/Colony</li>
           <li style="list-style-type:decimal;">Plot With Unapproved Layout</li>
           <li style="list-style-type:decimal;">Property With No Diversion Order</li>
           <li style="list-style-type:decimal;">Property With Change of Land Use</li>
           <li style="list-style-type:decimal;">Property With MOS Violation</li>
           <li style="list-style-type:decimal;">Property With Extra Floors</li>
           <li style="list-style-type:decimal;">Property With Illegal Colony</li>
           <li style="list-style-type:decimal;">Property With Road Widening</li>
           <li style="list-style-type:decimal;">Property in Green Belt Area</li>
           <li style="list-style-type:decimal;">Property near Naala/River/Lake/Forest land</li>
           <li style="list-style-type:decimal;">Property Known to be Disputed</li>
           <li style="list-style-type:decimal;">Part Property</li>
           <li style="list-style-type:decimal;">Property Having Internal Structural Changes Against approved map</li>
           <li style="list-style-type:decimal;">If Map Is Not Clear</li>
           <li style="list-style-type:decimal;">Very Large Property Measurement Cannot Be Done</li>
           <li style="list-style-type:decimal;">Extra Area Occupied by Customer(Having Construction)</li>
           <li style="list-style-type:decimal;">Customer's Area Occupied By Someone Else</li>
           <li style="list-style-type:decimal;">If Property is amalgamated(shops too)</li>
           <li style="list-style-type:decimal;">Maps Approved By Gram Panchayat Without Endorsement By Any Govt Engineer(CutOff Date)</li>
           <li style="list-style-type:decimal;">Plots/Houses In Colonies Known To Be Disputed</li>
           <li style="list-style-type:decimal;">Property With Private Lease as Ownership</li>
           <li style="list-style-type:decimal;">Property With Expired Lease From Government</li>
           <li style="list-style-type:decimal;">Properties With Khasra Number As Address(Only Identifiable By Customer)</li>
           <li style="list-style-type:decimal;">If Property Which Are Land Locked</li>
           <li style="list-style-type:decimal;">Property Having Salability Issues (Near Wine Shop, Having Narrow Access, Very Less Frontage And Not Usable For Any Purpose)</li>
           <li style="list-style-type:decimal;">If Property Is Patta Property</li>
           <li style="list-style-type:decimal;">Built Up Area Consideration</li>
        </ul></p>
        <p id="modalText">Some text in the Modal..</p>
    </div>
</div>
   
<script>
    document.addEventListener("DOMContentLoaded", function () {
    let tabs = document.querySelectorAll(".tab-links .tab");
    let slider = document.querySelector(".tab-links .slider");

    function moveSlider(activeTab) {
        slider.style.width = activeTab.offsetWidth + "px";
        slider.style.left = activeTab.offsetLeft + "px";
    }

    tabs.forEach(tab => {
        tab.addEventListener("click", function () {
            tabs.forEach(t => t.classList.remove("active"));
            this.classList.add("active");
            moveSlider(this);
        });

        // Initialize position on load for the active tab
        if (tab.classList.contains("active")) {
            moveSlider(tab);
        }
    });
});

   document.getElementById("toggleSidebar").addEventListener("click", function() {
    var sidebar = document.getElementById("sidebar");
    var toggleButton = document.getElementById("toggleSidebar");
    
    sidebar.classList.toggle("active");
    
    // Toggle button state
    toggleButton.classList.toggle("active");
});


var modal = document.getElementById("myModal");

// Get the <span> element that closes the modal
var span = document.getElementsByClassName("close")[0];

// Function to show the modal with custom text
function showPopup(text) {
    document.getElementById("modalText").innerText = text;
    modal.style.display = "block";
}

// When the user clicks on <span> (x), close the modal
span.onclick = function() {
    modal.style.display = "none";
}

// When the user clicks anywhere outside of the modal, close it
window.onclick = function(event) {
    if (event.target == modal) {
        modal.style.display = "none";
    }
}

function openGoogleMaps(location) {
            const baseUrl = "https://www.google.com/maps/search/?api=1&query=";
            window.open(baseUrl + encodeURIComponent(location), '_blank');
        }
function triggerFileInput2() {
            document.getElementById("imageInput").click();
        }

        document.getElementById("imageInput").addEventListener("change", function (event) {
            const files = event.target.files;
            const previewContainer = document.getElementById("imagePreviewContainer");

            // Clear previous previews
            previewContainer.innerHTML = "";

            // Display previews for each selected image
            Array.from(files).forEach((file) => {
                if (file.type.startsWith("image/")) {
                    const reader = new FileReader();
                    reader.onload = function (e) {
                        const img = document.createElement("img");
                        img.src = e.target.result;
                        previewContainer.appendChild(img);
                    };
                    reader.readAsDataURL(file);
                }
            });
        });
function triggerFileInput1() {
            document.getElementById("pdfInput").click();
        }

        // Handle file selection
        document.getElementById("pdfInput").addEventListener("change", function (event) {
            const file = event.target.files[0];
            if (file && file.type === "application/pdf") {
                // Create a FileReader instance
                const reader = new FileReader();

                // When the file is read successfully, open it in a new tab
                reader.onload = function (e) {
                    const pdfUrl = e.target.result;

                    // Try to open the PDF in a new tab using embed
                    const newTab = window.open();
                    if (newTab) {
                        newTab.document.write('<html><body><embed src="' + pdfUrl + '" type="application/pdf" width="100%" height="100%"></body></html>');
                        newTab.document.close();

                        // Fallback if the PDF does not load correctly
                        setTimeout(function() {
                            if (newTab.document.body.innerHTML === "") {
                                // Use PDF.js as a fallback to display the PDF
                                newTab.document.body.innerHTML = '<div id="pdf-container" style="width: 100%; height: 100%;"></div>';
                                const loadingTask = pdfjsLib.getDocument(pdfUrl);
                                loadingTask.promise.then(function(pdf) {
                                    pdf.getPage(1).then(function(page) {
                                        const scale = 1.5;
                                        const viewport = page.getViewport({ scale: scale });
                                        const canvas = document.createElement('canvas');
                                        const ctx = canvas.getContext('2d');
                                        canvas.height = viewport.height;
                                        canvas.width = viewport.width;
                                        document.getElementById('pdf-container').appendChild(canvas);

                                        // Render PDF page
                                        page.render({
                                            canvasContext: ctx,
                                            viewport: viewport
                                        });
                                    });
                                });
                            }
                        }, 1000); // Check if the embed failed after 1 second
                    }
                };

                // Read the file as a data URL
                reader.readAsDataURL(file);
            } else {
                alert("Please select a valid PDF file.");
            }
        });
</script>
</body>
</html>
