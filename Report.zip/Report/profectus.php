<?php include('auth.php'); ?>
<?php include 'watermark.html'; ?><?php
ini_set('display_errors', 1);
error_reporting(E_ALL);

// Increase PHP execution time and memory limit
ini_set('max_execution_time', 600); // Increase execution time to 600 seconds (10 minutes)
ini_set('memory_limit', '4096M'); // Increase memory limit to 4096MB
// Start session


$servername = "localhost";
$username = "root";
$password = "";
$dbname = "project_db";

// Create DB connection
$conn = new mysqli($servername, $username, $password, $dbname);
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

if (!isset($_SESSION['reference_id'])) {
    die("Reference ID not found in session.");
}
$reference_id = $_SESSION['reference_id'];

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['download_images'])) {

    // Get customer name
    $stmt_name = $conn->prepare("SELECT customerName FROM mis WHERE reference_id = ?");
    $stmt_name->bind_param("s", $reference_id);
    $stmt_name->execute();
    $result_name = $stmt_name->get_result();
    $customerName = "customer";
    if ($row = $result_name->fetch_assoc()) {
        $customerName = preg_replace('/[^a-zA-Z0-9]/', '', $row['customerName']);
    }
    $stmt_name->close();

    // Fetch image BLOBs
    $stmt = $conn->prepare("SELECT image1, image2, image3, image4, image5, image6, image7, image8, image9, image10, image11, image12 FROM final_uploaded_images WHERE reference_id = ?");
    $stmt->bind_param("s", $reference_id);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows > 0 && ($row = $result->fetch_assoc())) {
        $tempDir = sys_get_temp_dir() . DIRECTORY_SEPARATOR . uniqid('images_', true);
        mkdir($tempDir);

        $imageFiles = [];
        for ($i = 1; $i <= 12; $i++) {
            if (!empty($row["image$i"])) {
                $filename = $tempDir . DIRECTORY_SEPARATOR . "image{$i}.jpg";
                file_put_contents($filename, $row["image$i"]);
                $imageFiles[] = $filename;
            }
        }

        if (empty($imageFiles)) {
            die("No images to download.");
        }

        // Create ZIP
        $zipFileName = "images_" . preg_replace('/[^a-zA-Z0-9]/', '_', $reference_id) . "_{$customerName}.zip";
        $zipPath = $tempDir . DIRECTORY_SEPARATOR . $zipFileName;

        $zip = new ZipArchive();
        if ($zip->open($zipPath, ZipArchive::CREATE) !== TRUE) {
            die("Failed to create ZIP file.");
        }

        foreach ($imageFiles as $file) {
            $zip->addFile($file, basename($file));
        }
        $zip->close();

        // Send ZIP to browser
        header('Content-Type: application/zip');
        header('Content-Disposition: attachment; filename="' . basename($zipFileName) . '"');
        header('Content-Length: ' . filesize($zipPath));
        flush();
        readfile($zipPath);

        // Cleanup
        foreach ($imageFiles as $file) {
            unlink($file);
        }
        unlink($zipPath);
        rmdir($tempDir);
        exit;
    } else {
        echo "<p style='color:red;'>No image data found for this reference ID.</p>";
    }
}

$page = isset($_GET['page']) ? $_GET['page'] : 1;
$limit = 50;
$offset = ($page - 1) * $limit;
$sql_property = "SELECT * FROM mis WHERE reference_id = ? LIMIT $limit OFFSET $offset";
$stmt_property = $conn->prepare($sql_property);
$stmt_property->bind_param("s", $reference_id);
$stmt_property->execute();
$result_property = $stmt_property->get_result();
$data1 = $result_property->fetch_assoc();




// Fetch data from property_details table
$sql_property = "SELECT * FROM property_details WHERE reference_id = ?";
$stmt_property = $conn->prepare($sql_property);
$stmt_property->bind_param("s", $reference_id);
$stmt_property->execute();
$result_property = $stmt_property->get_result();
$data2= $result_property->fetch_assoc();




// Fetch data from area_valuation table
$sql_area = "SELECT * FROM address_details WHERE reference_id = ?";
$stmt_area = $conn->prepare($sql_area); 
$stmt_area->bind_param("s", $reference_id);
$stmt_area->execute();
$result_area = $stmt_area->get_result();
$data3 = $result_area->fetch_assoc();





// Fetch data from area_valuation table
$sql_area = "SELECT * FROM critical_parameters WHERE reference_id = ?";
$stmt_area = $conn->prepare($sql_area); 
$stmt_area->bind_param("s", $reference_id);
$stmt_area->execute();
$result_area = $stmt_area->get_result();
$data4 = $result_area->fetch_assoc();

 
// Fetch data from area_valuation table
$sql_area = "SELECT * FROM surroundings_details WHERE reference_id = ?";
$stmt_area = $conn->prepare($sql_area); 
$stmt_area->bind_param("s", $reference_id);
$stmt_area->execute();
$result_area = $stmt_area->get_result();
$data5 = $result_area->fetch_assoc();
$stmt_area->close();
 
// Fetch data from area_valuation table
$sql_area = "SELECT * FROM area_valuation WHERE reference_id = ?";
$stmt_area = $conn->prepare($sql_area); 
$stmt_area->bind_param("s", $reference_id);
$stmt_area->execute();
$result_area = $stmt_area->get_result();
$data6 = $result_area->fetch_assoc();
$stmt_area->close();
 



// Fetch data from area_valuation table
$sql_area = "SELECT * FROM floor_details WHERE reference_id = ?";
$stmt_area = $conn->prepare($sql_area); 
$stmt_area->bind_param("s", $reference_id);
$stmt_area->execute();
$result_area = $stmt_area->get_result();
$data8= $result_area->fetch_assoc();
$stmt_area->close();
 


// Fetch data from area_valuation table
$sql_area = "SELECT * FROM technical_details WHERE reference_id = ?";
$stmt_area = $conn->prepare($sql_area); 
$stmt_area->bind_param("s", $reference_id);
$stmt_area->execute();
$result_area = $stmt_area->get_result();
$data9 = $result_area->fetch_assoc();
$stmt_area->close();
 
// Fetch data from area_valuation table
$sql_area = "SELECT * FROM remarks_table WHERE reference_id = ?";
$stmt_area = $conn->prepare($sql_area); 
$stmt_area->bind_param("s", $reference_id);
$stmt_area->execute();
$result_area = $stmt_area->get_result();
$data10 = $result_area->fetch_assoc();
$stmt_area->close();


// Step 1: Fetch the engineer_id from the mis table
$sql_mis = "SELECT engineer_id FROM mis WHERE reference_id = ?";
$stmt_mis = $conn->prepare($sql_mis);
$stmt_mis->bind_param("s", $reference_id);
$stmt_mis->execute();
$result_mis = $stmt_mis->get_result();
$row_mis = $result_mis->fetch_assoc();
$stmt_mis->close(); 

if ($row_mis) {
    $engineer_id = $row_mis['engineer_id'];

    // Step 2: Fetch the engineer's name from engineer_login table
    $sql_engineer = "SELECT name FROM engineer_login WHERE engineer_id = ?";
    $stmt_engineer = $conn->prepare($sql_engineer);
    $stmt_engineer->bind_param("s", $engineer_id);
    $stmt_engineer->execute();
    $result_engineer = $stmt_engineer->get_result();
    $row_engineer = $result_engineer->fetch_assoc();
    $stmt_engineer->close();

    if ($row_engineer) {
        $engineer_name = $row_engineer['name'];
         //echo "Engineer Name: " . $engineer_name;
    } else {
        echo "Engineer not found.";
    }
} else {
    echo "No engineer assigned for this reference_id.";
}



// Step 1: Fetch the engineer_id from the mis table
$sql_mis = "SELECT report_id FROM mis WHERE reference_id = ?";
$stmt_mis = $conn->prepare($sql_mis);
$stmt_mis->bind_param("s", $reference_id);
$stmt_mis->execute();
$result_mis = $stmt_mis->get_result();
$row_mis = $result_mis->fetch_assoc();
$stmt_mis->close(); 

if ($row_mis) {
    $report_id = $row_mis['report_id'];

    // Step 2: Fetch the engineer's name from engineer_login table
    $sql_engineer = "SELECT name FROM report_login WHERE report_id = ?";
    $stmt_engineer = $conn->prepare($sql_engineer);
    $stmt_engineer->bind_param("s", $report_id);
    $stmt_engineer->execute();
    $result_engineer = $stmt_engineer->get_result();
    $row_engineer = $result_engineer->fetch_assoc();
    $stmt_engineer->close();

    if ($row_engineer) {
        $report_name = $row_engineer['name'];
         //echo "Engineer Name: " . $report_name;
    } else {
        echo "Engineer not found.";
    }
} else {
    echo "No engineer assigned for this reference_id.";
}


// Step 1: Fetch the engineer_id from the mis table
$sql_mis = "SELECT report_drafter_to_technical FROM mis WHERE reference_id = ?";
$stmt_mis = $conn->prepare($sql_mis);
$stmt_mis->bind_param("s", $reference_id);
$stmt_mis->execute();
$result_mis = $stmt_mis->get_result();
$row_mis = $result_mis->fetch_assoc();
$stmt_mis->close(); 

if ($row_mis) {
    $report_drafter_to_technical = $row_mis['report_drafter_to_technical'];

    // Step 2: Fetch the engineer's name from engineer_login table
    $sql_engineer = "SELECT name FROM technical_login WHERE technical_manager_id = ?";
    $stmt_engineer = $conn->prepare($sql_engineer);
    $stmt_engineer->bind_param("s", $report_drafter_to_technical);
    $stmt_engineer->execute();
    $result_engineer = $stmt_engineer->get_result();
    $row_engineer = $result_engineer->fetch_assoc();
    $stmt_engineer->close();

    if ($row_engineer) {
        $technical_name = $row_engineer['name'];
        //echo "Engineer Name: " . $technical_name;
    } else {
        echo "Engineer not found.";
    }
} else {
    echo "No engineer assigned for this reference_id.";
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Profectus Report</title>
      <link rel="shortcut icon" href="favicon.ico" type="image/x-icon">
  <style>
    body {
      font-family: Arial, sans-serif;
    }
    header {
  display: flex;
  align-items: center;
}

.logo img {
  width: 120px;
  margin-left:30px;
  height: auto;
}

.header-content {
  text-align: center;
  flex: 1;
  margin-left:-190x
}

header h1 {
  margin: 0;
  font-weight:700;
  font-size:27px;
  color: #a60000;
  
}

header p {
  margin: 2px 0;
  font-size: 14px;
  font-weight: bolder;
  color: #9e2424;
  
}
    table {
      width: 100%;
      border-collapse: collapse;
      margin-bottom: 20px;
    }
    td, th {
      border: 1px solid #000;
      padding: 6px 10px;
      vertical-align: top;
    }
    .header {
      background-color:#d9d9d9;
      text-align: center;
      font-weight: bold;
      font-size: 16px;
    }
    .sub-header {
      background-color: #f2f2f2;
      font-weight: bold;
    }
    input[type="text"] {
      width: 100%;
      border: none;
      outline: none;
      font-size: 14px;
      background: transparent;
    }
    .number {
      width: 30px;
      text-align: center;
    }
     
/* Force a stable 4-column grid that wkhtmltopdf respects */
.image-gallery { width: 100%; }
.image-grid { width: 100%; border-collapse: collapse; table-layout: fixed; }
.image-grid tr { page-break-inside: avoid; }
.image-grid td { width: 25%; padding: 6px; vertical-align: top; }

.image-grid .img-wrap { display: block; }
.image-grid img { display: block; width: 100%; height: auto; }
.image-grid .caption { font-size: 12px; text-align: center; margin-top: 4px; }

/* If you had a flex layout before, neutralize it */
.image-gallery { display: block !important; }



    /* Print-specific rules */
    @media print {
      .no-print {
        display: none !important;
      }

      body {
        margin: 0;
      }
 
    }
  button{
    padding:8px;
    margin-left:45%;
    background-color:#808485;
    color:white;
    font-weight:700;
    font-style:italic;
  }
  button:hover{
    background-color:rgba(216,216,216,255);
    color:white;
  }
    .google-map-container {
    max-width: 90%;           /* Keep container within page width */
    margin: 20px auto;        /* Center it with spacing */
    border: 2px solid #ccc;   /* Light gray border */
    padding: 10px;
    box-shadow: 0 0 10px rgba(0, 0, 0, 0.1); /* Optional: subtle shadow */
    background-color: #f9f9f9; /* Optional: light background */
    border-radius: 8px;       /* Rounded corners */
    text-align: center;       /* Center image and caption */
}

.google-map-container img {
    max-width: 100%;          /* Scale image to container */
    height: auto;             /* Keep image aspect ratio */
    display: inline-block;
    border: 1px solid #999;   /* Border around the image itself */
    border-radius: 4px;
} 
  </style>
</head>
<body>
<div class="content">
    <header>
      <div class="logo">
        <img src="images/logo.png" alt="Magpie Logo">
      </div>
      <div class="header-content">
        <h1>MAGPIE ENGINEERING PVT. LTD.</h1>
        <p>Valuer Designer Architects</p>
        <p>Reg.Add:5th Floor E-509,Casa Green ,A.B.Road,Talawall Chanda,Indore(M.P)-453771</p>
        <p>Office No. 201, 2nd Floor, Gravity Mall, Warehouse Road, Mechanic Nagar,near Vijay Nagar, Madhya Pradesh - 452011.</p>
      </div>
    </header>
<!-- Header Section -->
 <table style="margin-bottom:0px;">
    <tr>
        <td>REF NO </td>
     <td>   <span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data1
        ['reference_id'] ?? '') ?>
    </span></td>
    </tr>
 </table>
<table>
  <tr><td colspan="9" class="header">VALUATION REPORT FOR<br><span>Profectus Capital Private Limited</span></td></tr>
  <tr>
    <td rowspan="3" class="number"></td>
    <td colspan="2">Loan Account No -<br>Collateral ID -</td>
    <td colspan="2">   <span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data10['NA'] ?? '') ?>
    </span><br>   <span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data10['NA'] ?? '') ?>
    </span></td>
    <td>Valuer Name</td>
    <td colspan="3">   <span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars('MAGPIE ENGINEERING PRIVATE LIMITED
') ?>
    </span></td>
  </tr>
  <tr>
    <td colspan="2">Vertical</td>
    <td colspan="2">   <span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data10['NA'] ?? '') ?>
    </span></td>
    <td >Branch Name</td>
    <td colspan="3">   <span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data1['bank_branchname'] ?? '') ?>
    </span></td>
  </tr>
  <tr>
    <td colspan="2">Date of Initiate</td>
    <td colspan="2">   <span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data1['initiationDate'] ?? '') ?>
    </span></td>
    <td >Date of Visit</td>
    <td>   <span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data1['fe_to_coordinator_assign_at'] ?? '') ?>
    </span></td>
    <td >Date of Report</td>
    <td>   <span style="display: inline-block; min-width: 50px; padding: 2px;">
 <?= htmlspecialchars(date('d M Y h:i A', strtotime($data1['report_assigned_at'] ?? ''))) ?>
    </span></td>
  </tr>
</table>

<!-- Table Section -->
<table  style="margin-top:-20px;">
  <tr>
    <td class="number">1</td>
    <td colspan="2">Name/s of the Applicant/s</td>
    <td colspan="3"><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data1['customerName'] ?? '') ?>
    </span></td>
  </tr>
  <tr>
    <td class="number">2</td>
    <td colspan="2">Type of Property</td>
    <td>   <span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data2['property_unit_type'] ?? '') ?>
    </span></td>
    <td>Current Usage</td>
    <td>   <span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data4['current_property_usage'] ?? '') ?>
    </span></td>
  </tr>
  <tr>
    <td class="number" rowspan="3">3</td>
    <td colspan="2">Address as per Firing</td>
    <td colspan="3">   <span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data1['address'] ?? '') ?>
    </span></td>
  </tr>
  <tr>
    <td colspan="2">Address at site</td>
    <td colspan="3">   <span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data3['address_per_site'] ?? '') ?>
    </span></td>
  </tr>
  <tr>
    <td colspan="2">Address as per document</td>
    <td colspan="3"><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
  <?= htmlspecialchars($data3['address_per_document'] ?? '') ?> </span></td>
  </tr>
  <tr>
    <td class="number">4</td>
    <td colspan="2">Has the valuer done valuation before?</td>
    <td colspan="3">   <span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data10['NA'] ?? '') ?>
    </span></td>
  </tr>
</table>
<table style="margin-top:-20px;">
  <tr class="header"><td colspan="6">SANCTION PLAN APPROVAL & OTHER DOCUMENTS DETAILS</td></tr>
  <tr>
    <td class="number">5</td>
    <td colspan="2">Sanctioned plans verified with approval no</td>
    <td colspan="3">   <span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data9['floor_document'] ?? '') ?>
    </span></td>
  </tr>
  <tr>
    <td class="number">6</td>
    <td colspan="2">Property Documents Verified</td>
    <td colspan="3">   <span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data9['list_documents'] ?? '') ?>
    </span></td>
  </tr>
  <tr>
    <td class="number">7</td>
    <td colspan="2">Ownership Type</td>
    <td colspan="3">   <span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data2['property_leasehold_freehold'] ?? '') ?>
    </span></td>
  </tr>
  <tr>
    <td class="number">8</td>
    <td colspan="2">Construction as per approved plan / bye laws</td>
    <td colspan="3">   <span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data10['NA'] ?? '') ?>
    </span></td>
  </tr>
  <tr>
    <td class="number">9</td>
    <td colspan="2">Is the property in demolition list,if yes Details </td>
    <td colspan="3">   <span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data9['demolition_risk_1'] ?? '') ?>
    </span></td>
  </tr>
</table>

<!-- Section: Boundaries -->
<table style="margin-top:-20px;">
  <tr class="header"><td colspan="6">Boundaries as Per Documents & Site</td></tr>
  <tr>
  <td class="number" rowspan="4">10</td>
    <td>Boundaries</td>
    <td>EAST</td>
    <td>WEST</td>
    <td>NORTH</td>
    <td>SOUTH</td>
  </tr>
  <tr>
    <td>As per Deed</td>
    <td>   <span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data3['direction_as_per_document_east'] ?? '') ?>
    </span></td>
    <td>   <span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data3['direction_as_per_document_west'] ?? '') ?>
    </span></td>
    <td>   <span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data3['direction_as_per_document_north'] ?? '') ?>
    </span></td>
    <td>   <span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data3['direction_as_per_document_south'] ?? '') ?>
    </span></td>
  </tr>
  <tr>
    <td>At Site</td>
    <td>   <span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data3['direction_as_per_site_east'] ?? '') ?>
    </span></td>
    <td>   <span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data3['direction_as_per_site_west'] ?? '') ?>
    </span></td>
    <td>   <span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data3['direction_as_per_site_north'] ?? '') ?>
    </span></td>
    <td>   <span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data3['direction_as_per_site_south'] ?? '') ?>
    </span></t3
  </tr>
  <tr>
    <td colspan="2">Boundaries Matching</td>
    <td colspan="3">   <span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data3['boundaries_matching'] ?? '') ?>
    </span></td>
  </tr>
</table>
<!-- Section: Occupancy -->
<table style="margin-top:-20px;">
  <tr >
    <td class="number" rowspan="6">11</td>
    <td colspan="2" rowspan="6">Occupant</td>
  </tr>
    <tr>
    <td colspan="2">Vacant/Occupied</td>
    <td colspan="3">   <span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data2['occupancy_status'] ?? '') ?>
    </span></td>
  </tr>
  <tr>
    <td colspan="2">Name of Occupant</td>
    <td colspan="3">   <span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data2['occupant_name'] ?? '') ?>
    </span></td>
  </tr>
  <tr>
    <td colspan="2">Occupied From</td>
    <td colspan="3"><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data2['occupied_since'] ?? '') ?>
    </span></td>
  </tr>
  <tr>
    <td colspan="2">Relation with Applicant</td>
    <td colspan="3">   <span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data2['relation_of_occupant'] ?? '') ?>
    </span></td>
  </tr>
  <tr>
    <td colspan="2">Property Demarcation</td>
    <td colspan="3">   <span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data2['demarcated_at_site'] ?? '') ?>
    </span></td>
  </tr>
</table>

<!-- Section: Building Details -->
<table style="margin-top:-20px;">
  <tr >
    <td class="number" rowspan="5">12</td>
    <td colspan="2" rowspan="5">Building Details</td>
  </tr>
  <tr>
       <td colspan="2">Property Identified through</td>
    <td colspan="4">   <span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data2['NA'] ?? '') ?>
    </span></td> 
  </tr>
  <tr>
    <td colspan="2">Type of Structure</td>
    <td>   <span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data4['structure_type'] ?? '') ?>
    </span></td>
    <td colspan="2">As Per Site Land/Plot Area(sq mt / Sq Syd/Sqft)</td>
    <td>   <span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data6['actual_plot_square_feet'] ?? '') ?>
    </span></td>
  </tr>
  <tr>
    <td colspan="2">No. of Floors</td>
    <td>   <span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data8['actual_configuration_building'] ?? '') ?>
    </span></td>
    <td colspan="2">Floor Valued  </td>
    <td>   <span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data10['NA'] ?? '') ?>
    </span></td>
  </tr>
  <tr>
    <td colspan="2">No. of Units per Floor</td>
    <td>   <span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data8['number_of_units_each_floor'] ?? '') ?>
    </span></td>
    <td colspan="2">No. of lifts</td>
    <td>   <span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data8['number_of_lifts'] ?? '') ?>
    </span></td>





  </tr>
</table>
<!-- Section 13: Built‑up & Carpeting -->
<table style="margin-top:-20px;">
      <tr >
    <td class="number" rowspan="5">13</td>
    <td  rowspan="5"> Unit details</td>
  </tr>
  <tr>
     <td>No. of rooms</td>
    <td colspan="3">   <span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data10['NA'] ?? '') ?>
    </span></td>
  </tr>
  <tr >
    <td>Built up area (As per site)</td>
    <td colspan="2">   <span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data6['actual_construction_square_feet'] ?? '') ?>
    </span></td>
    <td rowspan="2"  class="number" >Sqft.</td>
  </tr>
  <tr>
    <td>Carpet area</td>
    <td>   <span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data6['actual_carpet_square_feet'] ?? '') ?>
    </span></td>
  </tr>
  <tr>
    <td>Remarks on view from property</td>
    <td colspan="3">   <span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data2['property_facing'] ?? '') ?>
    </span></td>
  </tr>
  <tr >
    <td class="number">14</td>
    <td>Quality of construction</td>
    <td>   <span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars('Average') ?>
    </span></td>
    <td>Interiors</td>
    <td colspan="3">   <span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data10['NA'] ?? '') ?>
    </span></td>

    
    </tr>
    <tr>
    <td class="number">15</td>
    <td>Age of the property (year)</td>
    <td>   <span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data2['age_of_property'] ?? '') ?>
    </span></td>
    <td>Residual life (year)</td>
    <td colspan="3">   <span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data2['residual_age_of_property'] ?? '') ?>
    </span></td>
  </tr>
  <tr >
    <td class="number" rowspan="5">16</td>
    <td rowspan="5">Location </td>
    </tr>
    <tr>
      <td>Type (Comm, Res, Ind, Mix)</td>
      <td colspan="4">   <span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data2['property_unit_type'] ?? '') ?>
    </span></td>
      </tr>
      <tr>
        <td>Class of Locality</td>
        <td colspan="4">   <span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data2['class_of_locality'] ?? '') ?>
    </span></td>
    </tr>
    <tr>
        <td>Site is (Dev, Under Dev)</td>
    <td colspan="4">   <span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data10['NA'] ?? '') ?>
    </span></td>
    </tr>
    <tr>
    <td>Proximity to civic amenities/public transport</td>
    <td colspan="4">   <span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars('Available') ?>
    </span></td>
  </tr>
</table>

<!-- Section 17 to 20: Vicinity & Amenities -->
<table style="margin-top:-20px;">
  <tr>
    <td class="number">17</td>
    <td>Close Vicinity/Landmark</td>
    <td colspan="5">   <span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data3['landmark_1'] ?? '') ?> <?= htmlspecialchars($data3['landmark_2'] ?? '') ?>
    </span></td>
  </tr>
  <tr >
    <td class="number">18</td>
    <td>Property within municipal limits Yes/No</td>
    <td>   <span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data3['property_location_in'] ?? '') ?>
    </span></td>
    <td>Name of Municipal Corporation</td>
    <td colspan="3">   <span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data10['NA'] ?? '') ?>
    </span></td>
  </tr>
  <tr >
    <td class="number">19</td>
    <td>Site Access</td>
    <td>   <span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data2['width_of_approach_road'] ?? '') ?>
    </span></td>
    <td>Availability of basic amenities (Water, Sewer, Electrical, Road)</td>
    <td colspan="3">   <span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars('Average') ?>
    </span></td>
  </tr>
  <tr >
    <td class="number">20</td>
    <td>Marketability</td>
    <td>   <span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data9['markebility'] ?? '') ?>
    </span></td>
    <td>Electricity Meter No:-</td>
    <td colspan="3">   <span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data2['electric_meter_no'] ?? '') ?>
    </span></td>
  </tr>
</table>

<!-- Section 21: Floor‑Wise Area -->
<table style="margin-top:-20px;">
      <tr class="header"><td colspan="10">Floor Wise Area (In Sft.)</td></tr>
  <tr >
    <td class="number" rowspan="5">21</td><td>Area’s</td>
    <td>Basement</td><td>Stilt</td><td>Ground</td><td>First</td>
    <td>Second</td><td>Third/Above</td><td>Fourth</td><td>Total</td>
  </tr>
  <tr>
    <td>Total Constructed</td>
    <td>   <span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data10['NA'] ?? '') ?>
    </span></td><td>   <span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data10['NA'] ?? '') ?>
    </span></td><td>   <span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data8['ground_actual'] ?? '') ?>
    </span></td>
    <td>   <span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data8['first_actual'] ?? '') ?>
    </span></td><td>   <span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data8['second_actual'] ?? '') ?>
    </span></td><td>   <span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data10['NA'] ?? '') ?>
    </span></td>
    <td>   <span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data8['other_actual_floors'] ?? '') ?>
    </span></td><td>   <span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data8['total_actual_floors'] ?? '') ?>
    </span></td>
  </tr>
  <tr>
    <td>Total Permissible</td>
    <td>   <span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data10['NA'] ?? '') ?>
    </span></td><td>   <span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data10['NA'] ?? '') ?>
    </span></td><td>   <span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data8['ground_permissible'] ?? '') ?>
    </span></td>
    <td>   <span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data8['first_permissible'] ?? '') ?>
    </span></td><td>   <span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data8['second_permissible'] ?? '') ?>
    </span></td><td>   <span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data10['NA'] ?? '') ?>
    </span></td>
    <td>   <span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data8['other_permissible_floors'] ?? '') ?>
    </span></td><td>   <span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data8['total_permissible_floors'] ?? '') ?>
    </span></td>
  </tr>
  <tr>
    <td>Extra Coverage</td>
    <td>   <span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data10['NA'] ?? '') ?>
    </span></td><td>   <span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data10['NA'] ?? '') ?>
    </span></td><td>   <span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data10['NA'] ?? '') ?>
    </span></td>
    <td>   <span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data10['NA'] ?? '') ?>
    </span></td><td>   <span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data10['NA'] ?? '') ?>
    </span></td><td>   <span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data10['NA'] ?? '') ?>
    </span></td>
    <td>   <span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data10['NA'] ?? '') ?>
    </span></td><td>   <span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data10['NA'] ?? '') ?>
    </span></td>
  </tr>
  <tr>
    <td class="sub-header" colspan="4">Composite Extra Coverage’s</td><td colspan="9">   <span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data10['NA'] ?? '') ?>
    </span></td>
  </tr>
</table>

<table style="margin-top:-20px;">
  <tr>
    <td class="number" rowspan="22">22</td>
    <td colspan="8" style="text-align:center;" class="sub-header">(A) Description of Constructed Area and Rates</td>
  </tr>
  <tr>
    <td class="sub-header" colspan="2">Description</td>
    <td class="sub-header" colspan="2">Area</td>
    <td class="sub-header" colspan="2">Rate</td>
    <td class="sub-header" colspan="2">Amount</td>
  </tr>
  <tr>
    <td class="sub-header" colspan="2">After Road Winding Land (Sq yd / Sq ft / Sq mtr)</td>
    <td colspan="2">      <span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data10['NA'] ?? '') ?>
    </span></td>
    <td colspan="2">      <span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data10['NA'] ?? '') ?>
    </span></td>
    <td colspan="2">      <span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data10['NA'] ?? '') ?>
    </span></td>
  </tr>
  <tr>
    <td class="sub-header" colspan="2">Construction / Composite Rate (sft) / BUA</td>
    <td colspan="2">      <span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data10['NA'] ?? '') ?>
    </span></td>
    <td colspan="2">      <span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data10['NA'] ?? '') ?>
    </span></td>
    <td colspan="2">      <span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data10['NA'] ?? '') ?>
    </span></td>
  </tr>
  <tr>
    <td class="sub-header" colspan="2">Construction / Composite Rate (sft)</td>
    <td colspan="2">      <span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data10['NA'] ?? '') ?>
    </span></td>
    <td colspan="2">      <span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data10['NA'] ?? '') ?>
    </span></td>
    <td colspan="2">      <span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data10['NA'] ?? '') ?>
    </span></td>
  </tr>
  <tr>
    <td colspan="2">Stage of construction</td>
    <td colspan="6"> <span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data9['description_stage_construction_allotted'] ?? '') ?>
    </span></td>
    </tr>
    <tr>
    <td colspan="2">Stage % </td>
    <td colspan="2">   <span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data8['stage_construction_actual_present_completion'] ?? '') ?>
    </span></td>
    <td colspan="2">Recommended % </td>
    <td colspan="2">   <span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data8['stage_construction_recommend_present_completion'] ?? '') ?>
    </span></td>
  </tr>
  <tr>
    <td colspan="9"  style="text-align:center;"class="sub-header">(B) Value of Extra Amenities</td>
  </tr>
  <tr>
    <td>Car Parking</td>
    <td>PLC</td>
    <td>IDC</td>
    <td>EDC</td>
    <td>Power Backup</td>
    <td>Club Membership</td>
    <td>Club Membership</td>
    <td colspan="2">Other</td>

  </tr>
  <tr>
    <td>      <span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data6['car_parking_amount'] ?? '') ?>
    </span></td>
    <td>      <span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data10['NA'] ?? '') ?>
    </span></td>
    <td>      <span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data10['NA'] ?? '') ?>
    </span></td>
    <td>      <span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data10['NA'] ?? '') ?>
    </span></td>
    <td>      <span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data10['NA'] ?? '') ?>
    </span></td>
    <td>      <span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data10['NA'] ?? '') ?>
    </span></td>
    <td>      <span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data10['NA'] ?? '') ?>
    </span></td>
    <td colspan="2">      <span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data10['NA'] ?? '') ?>
    </span></td>
  </tr>
  <tr>
    <td colspan="6" class="bold">Total Amenities Charges</td>
    <td colspan="2">      <span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data6['amenities_total'] ?? '') ?>
    </span></td>
  </tr>
  <tr>
    <td colspan="6" class="bold">Market Value of Property as on date of Valuation</td>
    <td colspan="2"><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data6['total_finally_area_valuation'] ?? '') ?>
    </span></td>
  </tr>
  <tr>
    <td colspan="6" class="bold">Forced Sale Value</td>
    <td colspan="2">      <span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data6['total_distress_value'] ?? '') ?>
    </span></td>
  </tr>
  <tr>
    <td colspan="6">Approx. Rentals in case of 100% complete property:</td>
    <td colspan="2">      <span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data6['gross_monthly_rental'] ?? '') ?>
    </span></td>
  </tr>

  <tr>
    <td colspan="8" class="sub-header">FLOORWISE DETAILS OF USAGE OF PROPERTY</td>
  </tr>
  <tr>
    <td class="sub-header" colspan="2">FLOOR</td>
    <td class="sub-header" colspan="2">USAGE</td>
    <td class="sub-header" colspan="2">UNITS</td>
    <td class="sub-header" colspan="2">RENTAL ASSESSMENT</td>
  </tr>
  <tr>
    <td class="sub-header"  colspan="2">Basement</td>
    <td  colspan="2">      <span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data10['NA'] ?? '') ?>
    </span></td>
    <td  colspan="2">      <span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data10['NA'] ?? '') ?>
    </span></td>
    <td  colspan="2">      <span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data10['NA'] ?? '') ?>
    </span></td>
  </tr>
  <tr>
    <td class="sub-header"  colspan="2">GF</td>
    <td  colspan="2">      <span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data10['NA'] ?? '') ?>
    </span></td>
    <td  colspan="2">      <span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data10['NA'] ?? '') ?>
    </span></td>
    <td  colspan="2">      <span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data10['NA'] ?? '') ?>
    </span></td>
  </tr>
  <tr>
    <td  colspan="2" class="sub-header">FF</td>
    <td  colspan="2">      <span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data10['NA'] ?? '') ?>
    </span></td>
    <td colspan="2">      <span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data10['NA'] ?? '') ?>
    </span></td>
    <td  colspan="2">      <span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data10['NA'] ?? '') ?>
    </span></td>
  </tr>
  <tr>
    <td   colspan="2"class="sub-header">SF</td>
    <td  colspan="2">      <span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data10['NA'] ?? '') ?>
    </span></td>
    <td  colspan="2">      <span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data10['NA'] ?? '') ?>
    </span></td>
    <td  colspan="2">      <span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data10['NA'] ?? '') ?>
    </span></td>
  </tr>
  <tr>
    <td  colspan="2" class="sub-header">TF</td>
    <td  colspan="2">      <span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data10['NA'] ?? '') ?>
    </span></td>
    <td  colspan="2">      <span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data10['NA'] ?? '') ?>
    </span></td>
    <td  colspan="2">      <span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data10['NA'] ?? '') ?>
    </span></td>
  </tr>
  <tr>
    <td colspan="2" class="sub-header">4th/Above</td>
   <td colspan="2">      <span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data10['NA'] ?? '') ?>
    </span></td>
    <td colspan="2">      <span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data10['NA'] ?? '') ?>
    </span></td>
   <td colspan="2">      <span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data10['NA'] ?? '') ?>
    </span></td>
  </tr>
  <tr>
    <td class="number">23</td>
  <td colspan="8"><b>Remarks:</b><br>
<span style="white-space: pre-line; font-size:14px; display: block; text-align: left; padding: 0; margin: 0;">
        <?= htmlspecialchars($data10['remarks'] ?? '') ?>
    </span></td></tr>
</table>
<table style="margin-top:-20px;margin-bottom:-10px;">
<tr><td colspan="9" class="header"><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data3['address_per_site'] ?? '') ?>
    </span></td></tr></table>
<table>
<tr><th style="margin-bottom:-18px;">PHOTOGRAPH OF THE PROPERTY</tr></th></table>
<br>

    
<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

$servername = "localhost";
$username   = "root";
$password   = "";
$dbname     = "project_db";

$conn = new mysqli($servername, $username, $password, $dbname);
if ($conn->connect_error) {
    die("Connection failed: " . htmlspecialchars($conn->connect_error));
}

$reference_id = $_SESSION['reference_id'] ?? null;
$reference_id = $_GET['reference_id'] ?? $reference_id;

if ($reference_id) {

    // Map captions
    $captions = [
        'image1'  => 'EXTERNAL PHOTOS',
        'image2'  => 'Kitchen',
        'image3'  => 'Selfie',
        'image4'  => 'Electric Meter',
        'image6'  => 'Other 1',
        'image7'  => 'Other 2',
        'image8'  => 'Other 3',
        'image9'  => 'Other 4',
        'image10' => 'Other 5',
        'image11' => 'Other 6',
        'image12' => 'Other 7',
        'image13' => 'Other 8',
        'image14' => 'Other 9',
        'image15' => 'Other 10',
        'image16' => 'Other 11',
        'image17' => 'Other 12',
        'image18' => 'Other 13',
        'image19' => 'Other 14',
        'image20' => 'Other 15',
    ];

    // === Helper: EXIF-aware orientation detection ===
    function classify_orientation_after_exif(string $imageData): ?string {
        $size = @getimagesizefromstring($imageData);
        if (!$size || !isset($size[0], $size[1])) {
            return null;
        }
        $width  = (int)$size[0];
        $height = (int)$size[1];

        $mime = $size['mime'] ?? '';
        if ($mime === 'image/jpeg' && function_exists('exif_read_data')) {
            $tmp = @tempnam(sys_get_temp_dir(), 'exif_');
            if ($tmp !== false) {
                @file_put_contents($tmp, $imageData);
                $exif = @exif_read_data($tmp);
                @unlink($tmp);

                if (!empty($exif['Orientation'])) {
                    $orientation = (int)$exif['Orientation'];
                    if ($orientation === 6 || $orientation === 8) {
                        $t = $width; $width = $height; $height = $t;
                    }
                }
            }
        }
        return ($width >= $height) ? 'horizontal' : 'vertical';
    }

    // === Helper: Fix orientation physically with Imagick ===
    function fixImageOrientation($binaryData) {
        $img = new Imagick();
        $img->readImageBlob($binaryData);

        switch ($img->getImageOrientation()) {
            case Imagick::ORIENTATION_BOTTOMRIGHT:
                $img->rotateImage("#000", 180);
                break;
            case Imagick::ORIENTATION_RIGHTTOP:
                $img->rotateImage("#000", 90);
                break;
            case Imagick::ORIENTATION_LEFTBOTTOM:
                $img->rotateImage("#000", -90);
                break;
        }

        $img->setImageOrientation(Imagick::ORIENTATION_TOPLEFT);
        $fixed = $img->getImageBlob();
        $img->destroy();

        return $fixed;
    }

    $sql = "SELECT 
                image1, image2, image3, image4, 
                image6, image7, image8, image9, 
                image10, image11, image12, image13, image14, image15, image16, image17, image18, image19, image20
            FROM final_uploaded_images 
            WHERE reference_id = ?";

    $stmt = $conn->prepare($sql);
    if ($stmt === false) {
        die("Error preparing the SQL statement: " . htmlspecialchars($conn->error));
    }

    $stmt->bind_param("s", $reference_id);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result && $result->num_rows > 0) {
        $horizontal_images = [];
        $vertical_images   = [];

        while ($row = $result->fetch_assoc()) {
            foreach ($row as $key => $imageData) {
                if (!empty($imageData)) {

                    // Actually fix image before displaying
                    $fixedData = fixImageOrientation($imageData);

                    $orientation = classify_orientation_after_exif($fixedData) ?? 'horizontal';
                    $imgString   = base64_encode($fixedData);
                    $caption     = $captions[$key] ?? 'Image';

                    $item = [
                        'data'    => $imgString,
                        'caption' => $caption,
                        'alt'     => $key,
                    ];

                    if ($orientation === 'horizontal') {
                        $horizontal_images[] = $item;
                    } else {
                        $vertical_images[]   = $item;
                    }
                }
            }
        }

 
// Output as a stable 4-column table (works in wkhtmltopdf)
$all_images = array_merge($vertical_images, $horizontal_images);

echo '<table class="image-grid">';
$rows = array_chunk($all_images, 4);
foreach ($rows as $row) {
    echo '<tr>';
    foreach ($row as $img) {
        echo '<td>';
        echo '<div class="img-wrap">';
        echo '<img src="data:image/jpeg;base64,' . $img['data'] . '" alt="' . htmlspecialchars($img['alt']) . '">';
        echo '<div class="caption">' . htmlspecialchars($img['caption']) . '</div>';
        echo '</div>';
        echo '</td>';
    }
    // pad remaining cells to keep 4 columns
    $remaining = 4 - count($row);
    if ($remaining > 0) {
        echo str_repeat('<td></td>', $remaining);
    }
    echo '</tr>';
}
echo '</table>';

    } else {
        echo "<p style='text-align:center;'>No images found.</p>";
    }

    $stmt->close();
} else {
    echo "<p style='text-align:center;'>Reference ID is missing.</p>";
}
?>

    
      
<table style="margin-top:-20px;margin-bottom:-15px;">
<tr>
    <td>LATITUDE</td>
    <td>LONGITUDE</td>
</tr>
<tr>
    <td>      <span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data3['latitude_value'] ?? '') ?>
    </span></td>
   <td>      <span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data3['longitude_value'] ?? '') ?>
    </span></td> 
</tr>
</table>
 
      <table>
  </tr>
  <tr>

<div class="google-map-container">
<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "project_db";
$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$reference_id = $_SESSION['reference_id'] ?? null;
$reference_id = $_GET['reference_id'] ?? $reference_id;

if ($reference_id) {
    $sql = "SELECT image5 FROM final_uploaded_images WHERE reference_id = ?";
    $stmt = $conn->prepare($sql);
    if ($stmt === false) {
        die("Error preparing the SQL statement: " . $conn->error);
    }

    $stmt->bind_param("s", $reference_id);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows > 0) {
        $row = $result->fetch_assoc();
        if (!empty($row['image5'])) {
 
            echo '<div><img src="data:image/jpeg;base64,' . base64_encode($row['image5']) . '" alt="Google Map"><p>Google Map</p></div>';
        } else {
            echo "<p style='text-align:center;'>Google Map image not available.</p>";
        }
    } else {
        echo "<p style='text-align:center;'>No record found for Google Map image.</p>";
    }

    $stmt->close();
} else {
    echo "<p style='text-align:center;'>Reference ID is missing.</p>";
}
?>
</tr>
</div>
    </table>
    </table>
     <!-- <button onclick="window.print()">Download PDF</button> -->
    <form method="post">
  <input type="hidden" name="download_images" value="1">
  <button type="submit">Download All Images</button>
</form>
     <!-- <button onclick="window.print()">Download PDF</button> -->
  <button id="downloadPdf" onclick="setPrintMargins()">DOWNLOAD PDF</button>
  <script>
    document.getElementById('downloadPdf').addEventListener('click', () => {
      // Select the content you want to convert to PDF
      const element = document.getElementById('content');
      const options = {
        margin:[0,0],
        filename:'report.pdf',
        image: { type: 'jpeg', quality: 0.98 },
        html2canvas: { scale: 2 },
        jsPDF: { unit: 'in', format: 'letter', orientation: 'portrait' }
      };

      // Generate and download the PDF
      html2pdf().set(options).from(element).save();
    });
    function setPrintMargins() {
      const style = document.createElement('style');
      style.innerHTML = `
      @media print {
          body {
            margin:0.2;
          }
        }
      `;
      document.head.appendChild(style);
      window.print();
    }
    // Disable all input fields in the form
    document.querySelectorAll('input').forEach(function(input) {
        input.disabled = true;  // Disables the field completely
    });
    </script>
     </div>
    
</body>
</html>
