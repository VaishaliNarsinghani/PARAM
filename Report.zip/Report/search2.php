<?php include('auth.php'); ?>
<?php

 // Start session

$message = "";

// Check if the form is submitted
if ($_SERVER["REQUEST_METHOD"] === "POST") {
    if (isset($_POST['action']) && $_POST['action'] === 'save') {
        // Save form data in the session
        $_SESSION['bank_details'] = array_map(function ($item) {
            return $item ?: '';
        }, $_POST);
        
        $message = "Bank details saved successfully!";
    } elseif (isset($_POST['action']) && $_POST['action'] === 'submit') {
        // Simulate saving all data to the database or another process
        // Clear session data after submission
        unset($_SESSION['bank_details']);

        // Redirect to a confirmation page
        header("Location: REPORT3.php");
        exit();
    }
}
?>

<!-- JavaScript for Alert -->
<script>
    <?php if (!empty($message)): ?>
    alert("<?= htmlspecialchars($message) ?>");
    <?php endif; ?>
</script>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Property Details Form</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
    <link rel="stylesheet" href="REPORT323.css">
    <style>
        /* Sidebar styles */
        /* Sidebar */
        .rotating-text {
            color:black;
    perspective: 1000px; /* Adds a 3D perspective effect */
    font-size: 1.5rem;
    font-weight:bold;
    width: 100%;
    animation: rotate360 3s linear infinite;
    display: inline-block;
    margin-bottom:10px;
    transform-origin: center center; /* Rotates around its center */
    text-align:center;
    /* margin-left:20px; */
    font-style: italic;
    text-shadow: 
    1px 1px 2px rgba(235, 244, 243, 0.97),
    2px 2px 4px rgba(246, 242, 242, 0.4),
    3px 3px 6px rgba(249, 252, 252, 0.89),
    4px 4px 8px rgba(248, 242, 247, 0.93),
    5px 5px 10px rgba(232, 236, 237, 0.4);
  }
  
  /* Keyframes for rotating the text */
  @keyframes rotate360 {
    0% {
      transform: rotateY(0deg); /* Starts with no rotation */
    }
    50% {
      transform: rotateY(0deg); /* Half rotation */
    }
    100% {
      transform: rotateY(360deg); /* Full rotation */
    }
  }
        .logo {
    /* width: 50px; */
    height: 83px;
    padding: 12px;
    padding-bottom: 33px;
    
  }
#sidebar {
    background: #B0C4DE; /* Light Steel Blue */
    color: #2C3E50; 
    position: fixed;
    left: -250px;
    top: 0;
    width: 250px;
    height: 100%;
    /* background-color: #111; */
    color: white;
    transition: left 0.3s ease;
    padding: 20px;
}

#sidebar.active {
    left: 35px;
    /* background:grey; */
}
.sidebar {
    width: 250px;
    background: #B0C4DE; /* Light Steel Blue */
    /* background:rgba(245, 245, 245, 0.37); Light Steel Blue */
    color: black; /* Dark Grayish Blue */
    padding:20px;
    height: 100vh;
    position: fixed;
    left: 0;
    top: 0;
    z-index: 1000;
    transition: transform 0.3s ease-in-out;
  }
  .sidebar.hidden {
    transform: translateX(-100%);
  }
  .sidebar h1 {
    font-size: 20px;
    margin-bottom: 20px;
  }

  .sidebar a {
    padding: 15px 20px;
      margin: 10px 0;
      text-decoration: none;
      color: #2C3E50; /* Dark Grayish Blue */
      font-size:16px;
      font-style: italic;
      font-weight: 500;
      margin-bottom:40px;
      border-radius: 5px;
      transition: all 0.3s ease;
      display: flex;
      align-items: center;
  }

  .sidebar a:hover,
  .sidebar a.active {
    background: #4A90E2; /* Light Blue */
    transform: translateX(10px);
    color: white;
  }
  .sidebar a .icon {
    margin-right: 15px;
    font-size: 18px;
  }
/* Toggle Button */
#toggleSidebar {
    border-radius: 20%;
    position: fixed;
    top: 0px; /* Adjusted for better placement */
    left: 0px; /* Adjusted for better placement */
    z-index: 1000;
    background-color:rgb(130, 183, 226); 
    color: white;
    border: none;
    padding: 6px 12px; /* Added padding for a more clickable area */
    cursor: pointer;
    box-shadow: 0 4px 8px rgba(0, 0, 0, 0.7); /* Adds a soft shadow for depth */
    transition: all 0.3s ease; 
    /* Smooth transition for hover and active states */
}

/* Button hover effect */
#toggleSidebar:hover {
    background-color: #1c6abf; /* Slightly darker shade on hover */
    transform: scale(1); /* Slightly enlarges the button for a professional hover effect */
    box-shadow: 0 6px 12px rgba(0, 0, 0, 0.3); /* Stronger shadow on hover */
}

/* Active state for the button */
#toggleSidebar.active {
    background-color: #1a4f82; /* Darker shade for active state */
    transform: rotate(180deg); /* Smooth rotate effect when the sidebar is active */
}

/* Button icon (if you use an icon inside the button) */
#toggleSidebar i {
    font-size: 18px; /* Adjust the icon size */
    transition: transform 0.3s ease; /* Smooth transition when rotating */
}
.watch-icon {
    margin-right: 16px; /* Adds space between the search text and the watch icon */
    color: #555; /* Optional: sets the color of the watch icon */
}
#toggleSidebar {
    border-radius: 20%;
    position: fixed;
    top: 0px; /* Adjust for better placement */
    /* right: -35px; Position it just outside the sidebar */
    z-index: 1001;
    background-color: rgb(130, 183, 226);
    color: white;
    border: none;
    padding: 6px 12px;
    cursor: pointer;
    box-shadow: 0 4px 8px rgba(0, 0, 0, 0.7);
    transition: all 0.3s ease;
}

/* Button hover effect */
#toggleSidebar:hover {
    background-color: #1c6abf;
    box-shadow: 0 6px 12px rgba(0, 0, 0, 0.3);
}

/* Active state for the button */
#toggleSidebar.active {
    background-color: #1a4f82;
    transform: rotate(180deg); /* Smooth 180-degree rotation */
    box-shadow: 0 6px 12px rgba(0, 0, 0, 0.5);
}

/* Sidebar */
#sidebar.active + #toggleSidebar {
    right: 250px; /* Adjust so button moves into view */
}

/* Sidebar when active */
#sidebar.active {
    left: 0px;
}

/* Sidebar hidden state */
#sidebar {
    position: fixed;
    left: -250px;
    top: 0;
    width: 250px;
    height: 100%;
    background: #B0C4DE;
    color: white;
    transition: left 0.3s ease;
}
#pdf-container {
            width: 100%;
            height: 100%;
            overflow: auto;
        }
        canvas {
            display: block;
            margin: 0 auto;
        }
        .container {
    background: #fff;
    border-radius: 15px;
    padding: 30px;
    box-shadow: 0 6px 20px rgba(0, 0, 0, 0.1);
    width: auto;
    text-align: center;
    position: absolute;
    top: 20px;
    right: 20px;
    font-size: 16px;
    transition: transform 0.3s ease;
}

p {
    text-align: center;
    font-size: 18px;
    margin: 10px 0;
    font-weight: 400;
    color: #555;
    /* margin-left: 25%; */
    width: 100%;
}

/* Time, Date, Day Styles */
.time, .date, .day {
    padding: 12px;
    background-color: #f8f9fa;
    border-radius: 8px;
    margin-top: 15px;
    box-shadow: 0 3px 6px rgba(0, 0, 0, 0.1);
}

.time {
    font-size: 24px;
    font-weight: 700;
    background-color: #d1e7dd;
}

.date, .day {
    font-size: 16px;
    font-weight: 500;
    background-color: #ffffff;
    box-shadow: none;
}

/* Status Box Styling */
.status-box {
    background: linear-gradient(135deg, #66ccff, #99ffcc);
    border-radius: 12px;
    padding: 20px;
    margin-top: 30px;
    /* margin-left: 25%; */
    box-shadow: 0 6px 20px rgba(0, 0, 0, 0.1);
    color: #e9dada;
    align-items: center;
    text-align: center;
    position: relative;
    overflow: hidden;
    width: 100%;
}

.status-box h2 {
    font-size: 20px;
    font-weight: 600;
    color: #151414;
    margin-bottom: 20px;
    position: relative;
    z-index: 1;
}

.status-details {
    display: flex;
    justify-content: space-between;
    align-items: center;
    position: relative;
    z-index: 1;
}

.status-details span {
    font-weight: 500;
    font-size: 14px;
    color: #0f0e0e;
}

.status-details .value {
    font-weight: 700;
    font-size: 18px;
}

.status-details .total {
    color: #ff7043;
}

.status-details .pending {
    color: #ff7043;
}

.status-box:before {
    content: '';
    position: absolute;
    top: 0;
    left: -150%;
    width: 150%;
    height: 150%;
    background: rgba(255, 255, 255, 0.2);
    animation: moving-background 6s linear infinite;
}

@keyframes moving-background {
    0% { left: -150%; }
    100% { left: 150%; }
}

/* Hover effect for the status box */
.status-box:hover {
    transform: translateY(-5px);
}

/* Media Queries for Responsiveness */
@media screen and (max-width: 768px) {
    .container {
        width: 90%;
        right: 5%;
        top: 5%;
        padding: 20px;
    }

    p {
        margin-left: 10%;
        width: 80%;
    }

    .status-box {
        width: 80%;
        margin-left: 10%;
    }

    .status-details {
        flex-direction: column;
        align-items: flex-start;
        text-align: left;
    }

    .status-details span {
        font-size: 16px;
    }

    .status-details .value {
        font-size: 16px;
    }
}

@media screen and (max-width: 480px) {
    .container {
        width: 100%;
        right: 0;
        top: 10px;
        padding: 15px;
    }

    p {
        margin-left: 0;
        width: 100%;
        font-size: 16px;
    }

    .status-box {
        width: 100%;
        margin-left: 0;
    }

    .status-details {
        flex-direction: column;
        align-items: flex-start;
        text-align: left;
    }

    .status-details span {
        font-size: 14px;
    }

    .status-details .value {
        font-size: 16px;
    }
}
.rotating-text {
    perspective: 1000px; /* Adds a 3D perspective effect */
    font-size: 1.5rem;
    font-weight:bold;
    width: 100%;
    animation: rotate360 3s linear infinite;
    display: inline-block;
    margin-bottom:10px;
    transform-origin: center center; /* Rotates around its center */
    text-align:center;
    /* margin-left:20px; */
    font-style: italic;
    text-shadow: 
    1px 1px 2px rgba(235, 244, 243, 0.97),
    2px 2px 4px rgba(246, 242, 242, 0.4),
    3px 3px 6px rgba(249, 252, 252, 0.89),
    4px 4px 8px rgba(248, 242, 247, 0.93),
    5px 5px 10px rgba(232, 236, 237, 0.4);
  }
  
  /* Keyframes for rotating the text */
  @keyframes rotate360 {
    0% {
      transform: rotateY(0deg); /* Starts with no rotation */
    }
    50% {
      transform: rotateY(180deg); /* Half rotation */
    }
    100% {
      transform: rotateY(360deg); /* Full rotation */
    }
  }
  .search-filters {
    background: hwb(210 92% 7%); /* Light Steel Blue */
    padding: 20px;
    border-radius: 5px;
    box-shadow: 0 5px 15px rgba(247, 247, 247, 0.1);
    animation: slideIn 1s ease-in-out;
  }

  .search-filters h2 {
    margin-bottom: 20px;
      color: #2C3E50; /* Dark Grayish Blue */
    text-align: center;
    margin-left:auto;
  }

  .search-filters input,
  .search-filters button {
    background-color: rgba(255, 255, 255, 0.986);
    padding: 10px;
    margin: 5px;
    border: 1px solid #ccc;
    border-radius: 5px;
    width: 45%;
  }
  table {
    font-size: 15px;
    box-shadow: 2px left linear-gradient(grey,white);
    width: 100%;
    border-collapse: collapse;
    margin: 20px 0;
    background: rgba(255, 254, 254, 0.7);
    color: black;
    border-radius: 10px;
    overflow: hidden;
    font-family:sans-serif;
    overflow: hidden;
  }
  

  th,
  td {
    /* width:20%; */
    padding: 5px;
    text-align: left;
    border: 1px solid rgba(63, 58, 58, 0.363);
  }

  th {
    background-color: #318dd8;
    color: white;
    /* font-weight: bold; */
  }

  tr:nth-child(even) {
    background-color: rgba(154, 217, 241, 0.685);
  }

  tr:hover {
    animation: bounce 0.6s ease-out;
    background: rgba(104, 183, 236, 0.719);
    /* font-size: 15px; */
    font-weight: 300px;
    /* color: white; */
  }


  button {
    padding: 5px 5px;
    background-color: #005f8a;
    color: white;
    border: none;
    border-radius: 5px;
    cursor: pointer;
    font-size: 10px;
  }

  button a {
    text-decoration: none;
    color: white;
  }

  button:hover {
    background-color: #007aa3;
  }

  /* Responsive Table */
  @media screen and (max-width: 768px) {

    table,
    thead,
    tbody,
    th,
    td,
    tr {
      display: block;
    }

    th {
      display: none;
    }

    td {
      position: relative;
      padding-left: 50%;
      text-align: right;
    }

    td::before {
      content: attr(data-label);
      position: absolute;
      left: 10px;
      font-weight: bold;
      text-transform: uppercase;
    }

    tr {
      margin-bottom: 40px;
    }

    /* button {
      width: 100%;
      padding: 10px;
    } */
  }
  .active{
    background-color: grey;
  }
    </style>
</head>
<body>
    <button id="toggleSidebar">&#9776;</button>

    <!-- Sidebar -->
    <div id="sidebar" class="sidebar">
        <div style="display: flex; align-items:center;">
          <img class="logo" src="logo.png" alt="" />
          <h1>Magpie Engineering</h1>
        </div>
        <div class="rotating-text">Report Drafter</div>
        <a href="home1.php"  ><i class="fas fa-home icon"></i>Home</a>
        <a href="Pending_Report.php" class="active"><i class="fas fa-search icon"></i>Search</a>
        <a href="Pending_Report.php"><i class="fas fa-clock watch-icon"></i>Pending For Drafting</a>
        <a href="clear_and_logout.php"><i class="fas fa-sign-out-alt icon"></i>Logout</a>

      </div>
      <div class="content" id="content">
            <div class="search-filters">
                <h2>Search Filters</h2>
                <form id="searchForm" method="POST" action="initiator.php">
                <div class="form-row">
            <input type="text" name="reference_id" placeholder="Reference ID" />
            <input type="text" name="customerName" placeholder="Customer Name" />
          </div>
          <div class="form-row">
            <input type="text" name="city" placeholder="City" />
            <input type="text" name="applicationNo" placeholder="Application No." />
          </div>
          <div class="form-row">
            <input type="text" name="bankName" placeholder="Bank Name" />
            <input type="text" name="branchname" placeholder="Branch Name" />
            <input type="text" name="caseType" placeholder="Case Type" />
          </div>
          <button type="submit"style="background: #4A90E2;"><a href="search2.php" style="text-decoration:none; color:black;">Search</a></button>
                </form>
                </div>
    </div>
    <div class="content" id="content" style="margin-left:0px;">
      <table>
        <p style="color: black; text-align:left;">Customer Information Table</p>
        <tr>
          <th>Reference Number</th>
          <th>Customer Name</th>
          <th>Address</th>
          <th>Customer Mobile Number</th>
          <th>Visit Type</th>
          <th>Bank Name</th>
          <th>Case Type</th>
          <th>Application Number</th>
          <th  style="width: 150px; white-space: normal;">Mail ID</th>
          <th>Date</th>
          <th>Draft</th>
        </tr>
        <tr>
          <td data-label="Reference Number">001</td>
          <td data-label="Customer Name">John Doe</td>
          <td data-label="Address">123 Main St, Cityville</td>
          <td data-label="Customer Mobile Number">+67890</td>
          <td data-label="Visit Type">Initial Visit</td>
          <td data-label="Bank Name">Bank A</td>
          <td data-label="Case Type">Loan</td>
          <td data-label="Application Number"></td>
          <td data-label="Mail ID">johndoe@example.com</td>
          <td data-label="Date">2023-10-01</td>
          <td data-label="View Report"><button><a href ="REPORT3.php">Draft Report</a></button></td>
        </tr>
        <tr>
          <td data-label="Reference Number">001</td>
          <td data-label="Customer Name">John Doe</td>
          <td data-label="Address">123 Main St, Cityville</td>
          <td data-label="Customer Mobile Number">+67890</td>
          <td data-label="Visit Type">Initial Visit</td>
          <td data-label="Bank Name">Bank A</td>
          <td data-label="Case Type">Loan</td>
          <td data-label="Application Number"></td>
          <td data-label="Mail ID">johndoe@example.com</td>
          <td data-label="Date">2023-10-01</td>
          <td data-label="View Report"><button><a href="REPORT3.php">Draft Report</a></button></td>
        </tr>
        <tr>
          <td data-label="Reference Number">001</td>
          <td data-label="Customer Name">John Doe</td>
          <td data-label="Address">123 Main St, Cityville</td>
          <td data-label="Customer Mobile Number">+root67890</td>
          <td data-label="Visit Type">Initial Visit</td>
          <td data-label="Bank Name">Bank A</td>
          <td data-label="Case Type">Loan</td>
          <td data-label="Application Number"></td>
          <td data-label="Mail ID">johndoe@example.com</td>
          <td data-label="Date">2023-10-01</td>
          <td data-label="View Report"><button><a href="REPORT3.php">Draft Report</a></button></td>
        </tr>
        <tr>
          <td data-label="Reference Number">002</td>
          <td data-label="Customer Name">Jane Smith</td>
          <td data-label="Address">456 Park Ave, Townland</td>
          <td data-label="Customer Mobile Number">+0987654321</td>
          <td data-label="Visit Type">Follow-up</td>
          <td data-label="Bank Name">Bank B</td>
          <td data-label="Case Type">Mortgage</td>
          <td data-label="Application Number">67890</td>
          <td data-label="Mail ID">janesmith@example.com</td>
          <td data-label="Date">2023-10-05</td>
          <td data-label="View Report"><button><a href="REPORT3.php">Draft Report</a></button></td>
        </tr>
        <tr>
          <td data-label="Reference Number">003</td>
          <td data-label="Customer Name">Mike Johnson</td>
          <td data-label="Address">789 Oak St, Villageville</td>
          <td data-label="Customer Mobile Number">+1122334455</td>
          <td data-label="Visit Type">Consultation</td>
          <td data-label="Bank Name">Bank C</td>
          <td data-label="Case Type">Credit Card</td>
          <td data-label="Application Number">11223</td>
          <td data-label="Mail ID">mikejohnson@example.com</td>
          <td data-label="Date">2023-10-10</td>
          <td data-label="View Report"><button><a href="REPORT3.php">Draft Report</a></button></td>
        </tr>
      </table>
    </div>
    </main>
  </div>
<script>
  document.addEventListener("DOMContentLoaded", function () {
    let tabs = document.querySelectorAll(".tab-links .tab");
    let slider = document.querySelector(".tab-links .slider");

    function moveSlider(activeTab) {
        slider.style.width = activeTab.offsetWidth + "px";
        slider.style.left = activeTab.offsetLeft + "px";
    }

    tabs.forEach(tab => {
        tab.addEventListener("click", function () {
            tabs.forEach(t => t.classList.remove("active"));
            this.classList.add("active");
            moveSlider(this);
        });

        // Initialize position on load for the active tab
        if (tab.classList.contains("active")) {
            moveSlider(tab);
        }
    });
});

   document.getElementById("toggleSidebar").addEventListener("click", function() {
    var sidebar = document.getElementById("sidebar");
    var toggleButton = document.getElementById("toggleSidebar");
    
    sidebar.classList.toggle("active");
    
    // Toggle button state
    toggleButton.classList.toggle("active");
});

</script>
</body>
</html>
