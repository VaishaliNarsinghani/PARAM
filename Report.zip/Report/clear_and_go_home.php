<?php include('auth.php'); ?>
<?php
 

// Unset specific form session data
$formSessionKeys = [
    'bank_details', 'property_details', 'address_details',
    'critical_parameters', 'area_valuation', 'axis_area_valuation',
    'floor_details', 'technical_details', 'remarks_table', 'negative_remarks','mandatory_details'
];

foreach ($formSessionKeys as $key) {
    unset($_SESSION[$key]);
}

unset($_SESSION['reference_id']); // Optional: if needed

// Redirect to Home page
header("Location: home1.php");
exit;
?>
