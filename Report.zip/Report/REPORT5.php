<?php include('auth.php'); ?>
<?php



ini_set('display_errors', 1);
error_reporting(E_ALL);

// Increase PHP execution time and memory limit
ini_set('max_execution_time', 600); // Increase execution time to 600 seconds (10 minutes)
ini_set('memory_limit', '4096M'); // Increase memory limit to 4096MB
// Start session



$message = "";  // Feedback message for the user
// Step 2: Retrieve reference_id from session
$reference_id = $_SESSION['reference_id'] ?? null;
$fieldss = [];

// Step 3: Check for old_reference_id in mis table
if ($reference_id) {
    // Database connection
    $servername = "localhost";
    $username = "root";
      $password = "";    $dbname = "project_db";
    $conn = new mysqli($servername, $username, $password, $dbname);
    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }

    // Check if old_reference_id exists for this reference_id
    $sql_check_old = "SELECT old_reference_id FROM mis WHERE reference_id = ?";
    $stmt_check = $conn->prepare($sql_check_old);
    $stmt_check->bind_param("s", $reference_id);
    $stmt_check->execute();
    $result = $stmt_check->get_result();
    $row = $result->fetch_assoc();
    $old_reference_id = $row['old_reference_id'] ?? null;
    $stmt_check->close();

    // If old_reference_id exists, fetch data from critical_parameters using that
    if (!empty($old_reference_id)) {
        $sql_prop = "SELECT * FROM critical_parameters WHERE reference_id = ?";
        $stmt_prop = $conn->prepare($sql_prop);
        $stmt_prop->bind_param("s", $old_reference_id);
        $stmt_prop->execute();
        $res_prop = $stmt_prop->get_result();
        $db_data = $res_prop->fetch_assoc() ?: [];
        $stmt_prop->close();

        // Merge session data (priority) with DB data
        $fieldss = array_merge($db_data, $_SESSION['critical_parameters'] ?? []);
    } else {
        // If no old_reference_id, use only session data
        $fieldss = $_SESSION['critical_parameters'] ?? [];
    }

    $conn->close();
}

// Handle form submission
if ($_SERVER["REQUEST_METHOD"] === "POST") {
    $action = $_POST['action'] ?? '';
 
    if ($action === 'save') {
      
        $message = " Zoning Details saved successfully!";
    } elseif ($action === 'submit') {
        // Final submission: Save to database or external storage
        if (saveCriticalParametersToDatabase($_SESSION['critical_parameters'])) {
            // Clear session after successful submission
            unset($_SESSION['critical_parameters']);
            header("Location: REPORT5.php"); // Redirect to confirmation page
            exit();
        } else {
            $message = "Error occurred while submitting. Please try again.";
        }
    }
}

function saveCriticalParametersToDatabase($critical_parameters) {
    // Placeholder for the database-saving logic
    // Ensure this function is implemented to handle database storage properly
    // For now, return true to simulate a successful save
    return true;
}
  
?>


<!-- JavaScript for Alert -->
<script>
    <?php if (!empty($message)): ?>
    alert("<?= htmlspecialchars($message) ?>");
    <?php endif; ?>
</script>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Property Details Form</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
    <link rel="shortcut icon" href="favicon.ico" type="image/x-icon">
    <style>
     * {
  margin: 0;
  padding: 0;
  box-sizing: border-box;
  font-family: "Poppins", "Segoe UI", sans-serif;
}

body {
  background: linear-gradient(135deg, #e0f7fa, #fce4ec, #f3e5f5);
  background-size: 300% 300%;
  animation: gradientBG 12s ease infinite;
  min-height: 100vh;
text-transform: uppercase;
  padding-top: 110px;
  position: relative;
  color: #2c3e50;
}

/* Animate background */
@keyframes gradientBG {
  0% { background-position: 0% 50%; }
  50% { background-position: 100% 50%; }
  100% { background-position: 0% 50%; }
}

    
        .form-container {
            width: 100%;
            max-width: 100%;
            margin: 0 auto;
            display: flex;
            flex-direction: column;
            gap: 10px;
              text-align: left;
            
        }
       
 
.tab-links {
  position: fixed;
  top: 0;
  left: 0; right: 0;
  z-index: 999;
  display: flex;
  justify-content: space-between;
  padding: 7px;
    gap:10px;
  overflow-x: auto;
  backdrop-filter: blur(12px);
  border-bottom: 2px solid rgba(0,0,0,0.05);
  box-shadow: 0 2px 10px rgba(0,0,0,0.08);
  text-align: center;
}

.tab-links .tab {
   border: 1px solid #ddd;
  padding:2px 35px;
  border-radius: 50px;
  font-size: 14px;
  font-weight: bold;
  color: #444;

  transition: all 0.3s ease;
  cursor: pointer;
}

.tab-links .tab.active {
  background: linear-gradient(135deg, #9d7cc1ff, #5d7aacff);
  color: #fff;
    box-shadow: 0 12px 30px rgba(106, 17, 203, 0.35),
              0 6px 15px rgba(37, 117, 252, 0.25);
  transition: all 0.5s cubic-bezier(0.25, 1, 0.5, 1);
  animation: gradientMove 4s ease infinite, float 6s ease-in-out infinite;
  transform: scale(1.05);
  box-shadow: 0 4px 12px rgba(0,0,0,0.2);

}

/* Tab Icon */
.tab img {
  width: 45px;
  height: 45px;
  margin-bottom:5px;
  transition: transform 0.3s ease;
}
.tab:hover img {
  transform: rotate(10deg) scale(1.1);
}



        /* Styling the scrollbar for the entire page */
::-webkit-scrollbar {
    width: 12px; /* Width of the vertical scrollbar */
    height: 10px; /* Height of horizontal scrollbar */
}

/* Styling the scrollbar track */
::-webkit-scroltab-linkslbar-track {
    background: linear-gradient(135deg, #f0f0f0, #e0e0e0); /* Light gradient track */
    border-radius: 10px; /* Rounded corners */
    box-shadow: inset 0 0 10px rgba(0, 0, 0, 0.1); /* Subtle shadow */
}

/* Styling the scrollbar thumb (the draggable part) */
::-webkit-scrollbar-thumb {
    background: linear-gradient(135deg, #2f7cab, #0056b3); /* Gradient thumb */
    border-radius: 10px; /* Rounded corners */
    border: 3px solid transparent; /* Add space around thumb */
    background-clip: content-box; /* Ensures the thumb’s background doesn’t overlap the border */
    transition: background 0.3s ease, transform 0.3s ease; /* Smooth transition for hover */
}

/* Hover effect for the scrollbar thumb */
::-webkit-scrollbar-thumb:hover {
    background: linear-gradient(135deg, #0056b3, #003d80); /* Darker gradient on hover */
    transform: scale(1.1); /* Slightly enlarge the thumb */
}

/* Styling the horizontal scrollbar */
::-webkit-scrollbar-horizontal {
    height: 8px;
}

/* Styling the horizontal scrollbar track */
::-webkit-scrollbar-track-horizontal {
    background: linear-gradient(135deg, #f0f0f0, #e0e0e0); /* Light gradient track */
    border-radius: 10px;
    box-shadow: inset 0 0 10px rgba(0, 0, 0, 0.1);
}

/* Styling the horizontal scrollbar thumb */
::-webkit-scrollbar-thumb-horizontal {
    background: linear-gradient(135deg, #2f7cab, #0056b3);
    border-radius: 10px;
    border: 3px solid transparent;
    background-clip: content-box;
    transition: background 0.3s ease, transform 0.3s ease;
}

/* Hover effect for horizontal scrollbar thumb */
::-webkit-scrollbar-thumb-horizontal:hover {
    background: linear-gradient(135deg, #0056b3, #003d80);
    transform: scale(1.1); /* Slightly enlarge the thumb */
}

      .header {
 
 
 font-size:15px;background: linear-gradient(135deg, #e4dee7ff);
  color:black;
  font-weight:600;
  padding: 16px;
  text-align: center;
  font-size: 20px;
  font-weight: 700;
  letter-spacing: 1px;
  border-bottom: 4px solid #fff;
  box-shadow: 0 4px 15px rgba(0,0,0,0.2);
  text-transform: uppercase;
}

        /* Main Content Styling */
        form {
            width: 100%;
        }

table {
  width: 100%;
  border-collapse: collapse;
  margin: 10px 0;
}

td {
  padding: 10px;
  font-size:16px;
  vertical-align: middle;
  transition: background 0.3s;
}

td:nth-child(odd) {
  background: #f0f8ff;
  font-weight: 600;
  color: #2c3e50;
}

td:nth-child(even) {
  background: #ffffff;
}

input[type="text"] {
  width: 100%;
  padding: 8px 12px;
  border: 1px solid #ddd;
  border-radius: 8px;
  transition: border-color 0.3s, box-shadow 0.3s;
}

input[type="text"]:focus {
  border-color: #6a11cb;
  box-shadow: 0 0 6px rgba(106, 17, 203, 0.4);
  outline: none;
}
/* Enhanced Submit Button */
.submit-button {
  display: flex;
  justify-content: center;
  margin: 40px 0;
  perspective: 1000px;
}

/* Button styling */
.submit-button button,
.submit-button input[type="submit"] {
  background: linear-gradient(135deg, #6a11cb 0%, #2575fc 100%);
  background-size: 200% 200%;
  border: none;
  padding: 8px 35px;
  border-radius: 999px;
  color: #fff;
  font-size: 20px;
  cursor: pointer;
  font-weight: 800;
  letter-spacing: 0.5px;
  box-shadow: 0 12px 30px rgba(106, 17, 203, 0.35),
              0 6px 15px rgba(37, 117, 252, 0.25);
  transition: all 0.5s cubic-bezier(0.25, 1, 0.5, 1);
  animation: gradientMove 4s ease infinite, float 6s ease-in-out infinite;
  position: relative;
  overflow: hidden;
  outline: none;
  -webkit-tap-highlight-color: transparent;
  transform-style: preserve-3d;
  text-transform: uppercase;
}

/* Shimmer highlight effect */
.submit-button button::before {
  content: "";
  position: absolute;
  top: -50%;
  left: -50%;
  width: 170%;
  height: 170%;
  background: linear-gradient(
    60deg, 
    rgba(255,255,255,0) 0%, 
    rgba(255,255,255,0.15) 50%, 
    rgba(255,255,255,0) 100%
  );
  transform: rotate(25deg) translateX(-100%);
  transition: transform 1.2s cubic-bezier(0.23, 1, 0.32, 1);
  pointer-events: none;
}

/* Hover effects */
.submit-button button:hover {
  transform: translateY(-8px) scale(1.08) rotateX(10deg);
  box-shadow: 0 25px 50px rgba(106, 17, 203, 0.45),
              0 15px 30px rgba(37, 117, 252, 0.35),
              0 0 40px rgba(255, 255, 255, 0.2);
  filter: brightness(1.15) saturate(1.2);
  letter-spacing: 1px;
}

.submit-button button:hover::before {
  transform: rotate(25deg) translateX(100%);
}

/* Active (press) effect */
.submit-button button:active {
  transform: translateY(-2px) scale(0.98);
  box-shadow: 0 8px 20px rgba(106, 17, 203, 0.3);
  transition: all 0.1s ease;
}

/* Pulsing glow effect */
.submit-button button::after {
  content: "";
  position: absolute;
  inset: -4px;
  border-radius: 999px;
  background: linear-gradient(135deg, #6a11cb, #2575fc, #9d7cc1, #5d7aac);
  background-size: 300% 300%;
  z-index: -1;
  filter: blur(12px);
  opacity: 0.7;
  animation: gradientMove 5s ease infinite, pulse 3s ease infinite;
  pointer-events: none;
}

/* Sparkle particles */
.submit-button .sparkle {
  position: absolute;
  width: 4px;
  height: 4px;
  background: white;
  border-radius: 50%;
  pointer-events: none;
  opacity: 0;
  animation: sparkle 1.5s linear infinite;
}

/* Keyframes for animations */
@keyframes gradientMove {
  0% { background-position: 0% 50%; }
  50% { background-position: 100% 50%; }
  100% { background-position: 0% 50%; }
}

@keyframes pulse {
  0% { opacity: 0.5; transform: scale(0.95); }
  50% { opacity: 0.8; transform: scale(1.05); }
  100% { opacity: 0.5; transform: scale(0.95); }
}

@keyframes float {
  0% { transform: translateY(0px); }
  50% { transform: translateY(-5px); }
  100% { transform: translateY(0px); }
}

@keyframes sparkle {
  0% {
    opacity: 0;
    transform: translate(0, 0) scale(0);
  }
  20% {
    opacity: 1;
    transform: translate(var(--sparkle-x), var(--sparkle-y)) scale(1);
  }
  80% {
    opacity: 1;
  }
  100% {
    opacity: 0;
    transform: translate(
      calc(var(--sparkle-x) * 1.5), 
      calc(var(--sparkle-y) * 1.5)
    ) scale(0);
  }
}

.side-buttons {
  position: fixed;
  top: 25%;
  right: 20px;
  display: flex;
  flex-direction: column;
  gap: 12px;
  z-index: 1000;
}

.side-buttons button {
  background: linear-gradient(145deg, #6a11cb, #2575fc);
  border: none;
  border-radius: 50%;
  width: 55px;
  height: 55px;
  display: flex;
  align-items: center;
  justify-content: center;
  box-shadow: 0 5px 12px rgba(0,0,0,0.25);
  transition: all 0.3s ease;
}

.side-buttons button:hover {
  transform: rotate(15deg) scale(1.1);
  background: linear-gradient(145deg, #2575fc, #6a11cb);
}

.side-buttons button img {
  width: 24px;
  height: 24px;
  filter: brightness(0) invert(1);
}



        @media (max-width: 768px) {
            .side-buttons {
                top: 15%;
                right: 10px;
            }

            .tab-links {
                flex-wrap: wrap;
            }
        }

        @media (max-width: 480px) {
            .tab-links button {
                padding: 8px 10px;
            }

            .header {
                font-size: 16px;
            }

            td {
                font-size: 14px;
            }

            input[type="text"] {
                font-size: 14px;
            }

            .side-buttons {
                top: 10%;
                right: 5px;
            }
        }
        .image-preview-container {
    display: flex;
    flex-wrap: wrap;
    gap: 10px;
    margin-top: 20px;
    background-color: #f8f9fa;
    border: 2px dashed #dcdcdc;
    padding: 10px;
    border-radius: 8px;
    /* justify-content: center; */
    align-items: center;
    text-align: center;
}

.image-preview-container p {
    color: #888;
    font-size: 14px;
}

.image-preview-container.hidden {
    display: none;
}

/* File input trigger button styling */
.side-buttons button {
    background-color: #2f7cab;
    border: none;
    padding: 10px;
    cursor: pointer;
    border-radius: 50%;
    width: 50px;
    height: 50px;
    display: flex;
    align-items: center;
    justify-content: center;
    transition: background-color 0.3s;
}
.valuation-table {
    width: 100%;
    border-collapse: collapse;
    /* margin-bottom: 20px; */
    font-size: 15px;
    /* margin-top: -1.1%; */
}

.valuation-table th,
.valuation-table td {
    border: 1px solid black;
    padding: 8px;
    text-align: center;
}

.valuation-table th {
    background-color: #2f7cab;
    color: white;
    font-weight: bold;
}

.valuation-table tr:nth-child(odd) td {
    background-color: #e9f5fb;
}

.valuation-table td {
    background-color: #fff;
    font-weight: normal;
}     
.rotating-text {
            color:black;
    perspective: 1000px; /* Adds a 3D perspective effect */
    font-size: 1.5rem;
    font-weight:bold;
    width: 100%;
    animation: rotate360 3s linear infinite;
    display: inline-block;
    margin-bottom:10px;
    transform-origin: center center; /* Rotates around its center */
    text-align:center;
    /* margin-left:20px; */
    font-style: italic;
    text-shadow: 
    1px 1px 2px rgba(235, 244, 243, 0.97),
    2px 2px 4px rgba(246, 242, 242, 0.4),
    3px 3px 6px rgba(249, 252, 252, 0.89),
    4px 4px 8px rgba(248, 242, 247, 0.93),
    5px 5px 10px rgba(232, 236, 237, 0.4);
  }
  
  /* Keyframes for rotating the text */
  @keyframes rotate360 {
    0% {
      transform: rotateY(0deg); /* Starts with no rotation */
    }
    50% {
      transform: rotateY(0deg); /* Half rotation */
    }
    100% {
      transform: rotateY(360deg); /* Full rotation */
    }
  }
  .logo {
    /* width: 50px; */
    height: 83px;
    padding: 12px;
    padding-bottom: 33px;
    
  }
#sidebar {
    background: #B0C4DE; /* Light Steel Blue */
    color: #2C3E50; 
    position: fixed;
    left: -250px;
    top: 0;
    width: 250px;
    height: 100%;
    /* background-color: #111; */
    color: white;
    transition: left 0.3s ease;
    padding: 20px;
}

#sidebar.active {
    left: 35px;
    /* background:grey; */
}
.sidebar {
    width: 250px;
    background: #B0C4DE; /* Light Steel Blue */
    /* background:rgba(245, 245, 245, 0.37); Light Steel Blue */
    color: black; /* Dark Grayish Blue */
    padding:20px;
    height: 100vh;
    position: fixed;
    left: 0;
    top: 0;
    z-index: 1000;
    transition: transform 0.3s ease-in-out;
  }
  .sidebar.hidden {
    transform: translateX(-100%);
  }
  .sidebar h1 {
font-size: 20px;
margin-top: 10px;
margin-bottom: 20px;
color: #2C3E50; 
}
  .sidebar a {
    padding: 15px 20px;
      margin: 10px 0;
      text-decoration: none;
      color: #2C3E50; /* Dark Grayish Blue */
      font-size:16px;
      font-style: italic;
      font-weight: 500;
      margin-bottom:70px;
      border-radius: 5px;
      transition: all 0.3s ease;
      display: flex;
      align-items: center;
  }

  .sidebar a:hover,
  .sidebar a.active {
    background: #4A90E2; /* Light Blue */
    transform: translateX(10px);
    color: white;
  }
  .sidebar a .icon {
    margin-right: 15px;
    font-size: 18px;
  }
/* Toggle Button */
#toggleSidebar {
    border-radius: 20%;
    position: fixed;
    top: 0px; /* Adjusted for better placement */
    left: 0px; /* Adjusted for better placement */
    z-index: 1000;
    background-color:rgb(130, 183, 226); 
    color: white;
    border: none;
    padding: 6px 12px; /* Added padding for a more clickable area */
    cursor: pointer;
    box-shadow: 0 4px 8px rgba(0, 0, 0, 0.7); /* Adds a soft shadow for depth */
    transition: all 0.3s ease; 
    /* Smooth transition for hover and active states */
}

/* Button hover effect */
#toggleSidebar:hover {
    background-color: #1c6abf; /* Slightly darker shade on hover */
    transform: scale(1); /* Slightly enlarges the button for a professional hover effect */
    box-shadow: 0 6px 12px rgba(0, 0, 0, 0.3); /* Stronger shadow on hover */
}

/* Active state for the button */
#toggleSidebar.active {
    background-color: #1a4f82; /* Darker shade for active state */
    transform: rotate(180deg); /* Smooth rotate effect when the sidebar is active */
}

/* Button icon (if you use an icon inside the button) */
#toggleSidebar i {
    font-size: 18px; /* Adjust the icon size */
    transition: transform 0.3s ease; /* Smooth transition when rotating */
}
.watch-icon {
    margin-right: 16px; /* Adds space between the search text and the watch icon */
    color: #555; /* Optional: sets the color of the watch icon */
}
#toggleSidebar {
    border-radius: 20%;
    position: fixed;
    top: 0px; /* Adjust for better placement */
    /* right: -35px; Position it just outside the sidebar */
    z-index: 1001;
    background-color: rgb(130, 183, 226);
    color: white;
    border: none;
    padding: 6px 12px;
    cursor: pointer;
    box-shadow: 0 4px 8px rgba(0, 0, 0, 0.7);
    transition: all 0.3s ease;
}

/* Button hover effect */
#toggleSidebar:hover {
    background-color: #1c6abf;
    box-shadow: 0 6px 12px rgba(0, 0, 0, 0.3);
}

/* Active state for the button */
#toggleSidebar.active {
    background-color: #1a4f82;
    transform: rotate(180deg); /* Smooth 180-degree rotation */
    box-shadow: 0 6px 12px rgba(0, 0, 0, 0.5);
}

/* Sidebar */
#sidebar.active + #toggleSidebar {
    right: 250px; /* Adjust so button moves into view */
}

/* Sidebar when active */
#sidebar.active {
    left: 0px;
}

/* Sidebar hidden state */
#sidebar {
    position: fixed;
    left: -250px;
    top: 0;
    width: 250px;
    height: 100%;
    background: #B0C4DE;
    color: white;
    transition: left 0.3s ease;
}
#pdf-container {
            width: 100%;
            height: 100%;
            overflow: auto;
        }
        canvas {
            display: block;
            margin: 0 auto;
        }
 .modal {
  display: none;
  position: fixed;
  z-index: 2000;
  inset: 0;
  background: rgba(0,0,0,0.7);
  animation: fadeIn 0.6s ease-out;
}

.modal-content {
  background: #fff;
  border-radius: 15px;
  margin: 60px auto;
  padding: 30px 40px;
  width: 70%;
  max-width: 900px;
  animation: scaleUp 0.5s ease-in-out forwards;
  box-shadow: 0 20px 40px rgba(0,0,0,0.3);
}

 .close {
  float: right;
  font-size: 34px;
  font-weight: bold;
  color: #e74c3c;
  cursor: pointer;
  transition: transform 0.3s ease;
}

.close:hover {
  transform: rotate(90deg);
  color: #c0392b;
}

/* Animations */
@keyframes scaleUp {
  from { transform: scale(0.8); opacity: 0; }
  to { transform: scale(1); opacity: 1; }
}
@keyframes fadeIn {
  from { opacity: 0; }
  to { opacity: 1; }
}


/* Stylish list items inside the modal */
.modal-content ul {
    list-style-type: decimal; /* Use numbers for list items */
    margin-top: 20px;
    padding-left: 25px; /* Add padding to list items */
    color: #555; /* Lighter text color for better contrast */
}

.modal-content ul li {
    /* margin-bottom: 10px; */
    line-height: 1.6; /* Increased line height for better readability */
    padding-left: 10px; /* Padding to align list items nicely */
    transition: transform 0.2s ease-in-out; /* Smooth transition effect on hover */
}

.modal-content ul li:hover {
    transform: translateX(5px); /* Subtle animation on hover for list items */
}

/* Optional: Add a smooth transition effect when content changes */
.modal-content {
    transition: transform 0.5s ease, opacity 0.5s ease;
}
/* Enhanced Dropdown Styles */
select {
  width: 100%;
  padding: 12px 16px;
  border: 2px solid transparent;
  border-radius: 12px;
  background: linear-gradient(135deg, #e0f7fa, #fce4ec, #f3e5f5);
  color: #2c3e50;
  font-size: 16px;
  font-weight: 500;
  cursor: pointer;
  box-shadow: 0 4px 15px rgba(0,0,0,0.08);
  transition: all 0.4s cubic-bezier(0.25, 1, 0.5, 1);
  appearance: none;
  background-size: 200% 200%;
  animation: gradientBG 12s ease infinite;
  position: relative;
  outline: none;
}

/* Custom dropdown arrow */
.select-wrapper {
  position: relative;
  width: 100%;
}

.select-wrapper::after {
  content: "";
  position: absolute;
  top: 50%;
  right: 16px;
  transform: translateY(-50%) rotate(0deg);
  width: 12px;
  height: 12px;
  background-image: url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 24 24' fill='%236a11cb'%3E%3Cpath d='M7 10l5 5 5-5z'/%3E%3C/svg%3E");
  background-repeat: no-repeat;
  background-position: center;
  pointer-events: none;
  transition: transform 0.4s cubic-bezier(0.68, -0.55, 0.27, 1.55);
}

/* Hover effects */
select:hover {
  transform: translateY(-2px);
  box-shadow: 0 8px 25px rgba(106, 17, 203, 0.2);
  border-color: #6a11cb;
}

/* Focus effects */
select:focus {
  border-color: #6a11cb;
  box-shadow: 0 0 0 4px rgba(106, 17, 203, 0.15), 
              0 8px 25px rgba(106, 17, 203, 0.25);
  background: linear-gradient(135deg, #e0f7fa, #fce4ec, #f3e5f5);
  animation: gradientBG 8s ease infinite, pulseFocus 2s ease infinite;
}

/* Expanded state for dropdown */
select:focus + .select-wrapper::after {
  transform: translateY(-50%) rotate(180deg);
}

/* DROPDOWN LIST STYLING (when open) */
select:focus {
  border-radius: 12px 12px 0 0;
}

/* Firefox dropdown list styling */
select option {
  padding: 12px 16px;
  background: rgba(255, 255, 255, 0.98);
  color: #2c3e50;
  border-bottom: 1px solid #f0f0f0;
  transition: all 0.3s ease;
  font-size: 15px;
  cursor: pointer;
}

/* Hover effect for options */
select option:hover,
select option:checked {
  background: linear-gradient(135deg, #9d7cc1, #5d7aac) !important;
  color: white !important;
  box-shadow: 0 4px 12px rgba(0,0,0,0.1);
  transform: translateX(4px);
}

/* Selected option style */
select option:checked {
  background: linear-gradient(135deg, #6a11cb, #2575fc) !important;
  color: white;
  font-weight: 600;
}

/* For Webkit browsers (Chrome, Safari) */
@media screen and (-webkit-min-device-pixel-ratio:0) {
  select {
    padding-right: 40px; /* Extra space for custom arrow */
  }
  
  /* Style the dropdown list itself */
  select:focus {
    border-radius: 12px;
  }
  
  /* Style the dropdown options */
  select option {
    padding: 12px 16px;
    background: rgba(255, 255, 255, 0.98);
    color: #2c3e50;
    border-bottom: 1px solid #f0f0f0;
    transition: all 0.3s ease;
    font-size: 15px;
    cursor: pointer;
  }
  
  /* Hover effect for options in Webkit */
  select option:hover {
    background: linear-gradient(135deg, #9d7cc1, #5d7aac) !important;
    color: white !important;
    padding-left: 20px;
  }
  
  /* Selected option style in Webkit */
  select option:checked {
    background: linear-gradient(135deg, #6a11cb, #2575fc) !important;
    color: white;
    font-weight: 600;
  }
}

/* Animation for dropdown opening */
@keyframes dropdownOpen {
  0% {
    opacity: 0;
    transform: translateY(-10px);
  }
  100% {
    opacity: 1;
    transform: translateY(0);
  }
}

/* Apply animation to dropdown options in Firefox */
@-moz-document url-prefix() {
  select {
    padding-right: 40px; /* Extra space for custom arrow in Firefox */
  }
  
  select option {
    animation: dropdownOpen 0.4s ease forwards;
  }
}

/* Pulse animation for focus state */
@keyframes pulseFocus {
  0% {
    box-shadow: 0 0 0 4px rgba(106, 17, 203, 0.15), 
                0 8px 25px rgba(106, 17, 203, 0.25);
  }
  50% {
    box-shadow: 0 0 0 8px rgba(106, 17, 203, 0.1), 
                0 8px 25px rgba(106, 17, 203, 0.3);
  }
  100% {
    box-shadow: 0 0 0 4px rgba(106, 17, 203, 0.15), 
                0 8px 25px rgba(106, 17, 203, 0.25);
  }
}

/* Enhanced label styling */
td label {
  display: block;
  font-weight: 600;
  margin-bottom: 8px;
  color: #2c3e50;
  transition: color 0.3s ease;
}

/* Hover effect on label */
td:hover label {
  color: #6a11cb;
}

/* Responsive adjustments */
@media (max-width: 768px) {
  select {
    padding: 10px 14px;
    font-size: 15px;
  }
  
  .select-wrapper::after {
    right: 14px;
  }
}

@media (max-width: 480px) {
  select {
    padding: 8px 12px;
    font-size: 14px;
    border-radius: 10px;
  }
  
  .select-wrapper::after {
    right: 12px;
    width: 10px;
    height: 10px;
  }
}

/* Custom dropdown list for modern browsers */
@supports (-webkit-appearance: none) or (appearance: none) or ((-moz-appearance: none) and (pointer-events: all)) {
  .select-wrapper {
    position: relative;
    display: inline-block;
    width: 100%;
  }
  
  .select-wrapper select {
    padding-right: 40px;
    z-index: 1;
  }
  
  .select-wrapper::after {
    z-index: 2;
  }
  
  /* Focus state for modern browsers */
  .select-wrapper select:focus {
    z-index: 3;
  }
}
    </style>
</head><body>
<button id="toggleSidebar">&#9776;</button>
<div id="sidebar" class="sidebar">
    <div style="display: flex">
      <img class="logo" src="logo.png" alt="" />
      <h1>Magpie Engineering</h1>
    </div>
    <div class="rotating-text">Report Drafter</div>
    <a href="clear_and_go_home.php"><i class="fas fa-home icon"></i>Home</a>        

    
  <a href="clear_sessions.php" class="active"><i class="fas fa-clock watch-icon"></i>Pending For Drafting</a>
 <a href="technical.php"><i class="fas fa-clipboard-list icon"></i> Preview Report</a>      
    <a href="clear_and_logout.php"><i class="fas fa-sign-out-alt icon"></i>Logout</a>

  </div>
     <?php if (!empty($message)): ?>
        <div class="success-message" style="text-align: center; padding: 10px; background-color: #dff0d8; color: #3c763d; border: 1px solid #d6e9c6; margin-bottom: 20px;">
            <?= htmlspecialchars($message) ?>
        </div>
    <?php endif; ?>
<div>
     
    <div class="tab-links">
    <button class="tab" onclick="location.href='REPORT3.php'"><img src="info.png" alt="Icon" width="50  " height="50  ">
    INFO</button>
    <button class="tab " onclick="location.href='REPORT4.php'"><img src="general.png" alt="Icon" width="50  " height="50  "style="margin-bottom:4px;">GENERAL</button>
    <button class="tab" onclick="location.href='REPORT2.php'"> <img src="location.png" alt="Icon" width="50  " height="50  ">
    LOCATION</button>
    <button class="tab active" onclick="location.href='REPORT5.php'"><img src="Zoning.png" alt="Icon" width="50  " height="50  ">
    ZONING</button>
    <button class="tab" onclick="location.href='REPORT7.php'"><img src="value.png" alt="Icon" width="50  " height="50  ">
    VALUE</button>
    <button class="tab" onclick="location.href='REPORT9.php'"><img src="Floor.png" alt="Icon" width="50  " height="50  ">
    STRUCTURE</button>
    <button class="tab" onclick="location.href='REPORT10.php'"><img src="documents.png" alt="Icon" width="50  " height="50  ">
    DOCUMENTS</button>
    <button class="tab" onclick="location.href='REPORT115.php'"><img src="photo.png" alt="Icon" width="50  " height="50  ">
    PHOTOS</button>
  
    <button class="tab" onclick="location.href='REPORT12.php'"><img src="remark.png" alt="Icon" width="50  " height="50  ">
    REMARK</button>
    <div class="slider"></div>
</div>
    <div class="table">
        <!-- Form Table -->
        <form id="autosave-form" action=""   method="POST" style="width: 100%;">
            
      
            <div   style="  text-align: center;"class="header">CRITICAL PARAMETERS </div>
            <table class="table">
    <?php
    $fields = [
        'Zoning as per development' => 'zoning_development_plan',
        'Caution Area' => 'caution_area',
        'Failing in present or proposed road widening' => 'failing_in_road_widening',
        'Property within 30mtrs from rail way boundary' => 'within_50_mtrs_railway',
        'Property near High / Low tension' => 'near_high_tension',
        'If yes, approx vertical distance from line' => 'vertical_distance_from_line',
        'Presence of Nalaah/ Lake / Water' => 'presence_of_nala',
        'Current property Usage' => 'current_property_usage',
        'Approved Property Usage' => 'approved_property_usage',
        'Comment on location risk if habitation is less than 40% within 1 km' => 'comment_on_location_risk',
        'Property abutting agriculture land' => 'abutting_agriculture_land',
        'Seismic Zone' => 'seismic_zone',
        'Structure Type' => 'structure_type',
        'Costal Regulatory zone' => 'costal_regulatory_zone',
         'Flooring Type' => 'flooring_type',
          'Purpose of Valuation' => 'purpose_of_valuation',
           'Valuation Method used' => 'valuation_method_used',
            'Number of houses in village' => 'no_of_houses',
             'Population of Village' => 'population_of_village',
              'Internal Visit Done ?' => 'internal_visit_done',
               ' Allocated by RO/BM' => 'allocated_by_ro_bm',
                'Number of Properties with 250 meters' => 'properties_250_meters',
                 'Number of Properties with 500 meters' => 'properties_500_meters',
                   'Any board on the house' => 'board_on_house',
                    'Vertical' => 'vertical',
                    'Corner Plot' => 'corner_plot',
                   'Property Registered or not ?' => 'registered_or_not',
                    'Roof Type' => 'roof_type',
                   'Remarks if property affected by any of critical parameters' => 'remarks_on_critical_params',
                    'Habitation % Within 1 km around property' => 'habitation_1km',
                     'Property Configuration' => 'property_configuration',
                     'If yes, rate of the agriculture land ' => 'rate_of_agriculture_land',
                      'Nature of building / wing' => 'nature_of_building',
                    'Shape of Building' => 'shape_of_building',
                    'Fire Exit Available' => 'fire_exit_available',
                    'Steel Grade' => 'steel_grade',
                    'Ground Slope MORE THAN 20%' => 'ground_slope_more_than_20',
                    'Soil Liquefiable ' => 'soil_liquefiable',
                    'Soil Slope Vulnarable to luquefiable' => 'soil_slope_vulnerable',
                    'Flood Prone Area' => 'flood_prone_area',
                     'Mortar Type' => 'mortar_type',
                    'Concrete Grade' => 'concrete_grade',
                    'Expansion joint available' => 'expansion_joint_available',
                    'Structural System' => 'structural_system',
                    'Environment Exposure condition' => 'environment_exposure_condition',
                    'Cyclone Zone - Wind Speed' => 'cyclone_zone_wind_speed',
                     'Footing Type' => 'footing_type',
                     'Projected parts available' => 'projected_parts_available',
                    'Soil Type' => 'soil_type',
                    'Plan Aspect Ratio' => 'plan_aspect_ratio',
                    'Soil Strata' => 'soil_strata',

                    'Type of Masonary  ' => 'type_of_masonary',
                    'Projected Parts Available' => 'projected_parts_available',
                    'Mortar Type  ' => 'mortar_type',
                    'Liquefiable  ' => 'liquefiable',
                    'Soil Slope Vulnerable to Landslide	' => 'landslide',
                     'Expansion Joints Available  ' => 'expansion_joint_available',
                      'Projected Parts Available  ' => 'projected_parts_available',
                     'Environment Exposure Condition  ' => 'exposure_condition'
                    
    ];

    // Hidden field for reference_id
    $reference_id = $_SESSION['reference_id'] ?? '';
    echo '<input type="hidden" name="reference_id" value="' . htmlspecialchars($reference_id) . '">';

   $count = 0;
echo '<tr>';

// Define dropdown options for specific fields
$dropdowns = [
    'property_location_in' => [
       'NA',
        'Gram Panchayat',
        'Municipal Council',
        'Municipal Coorporation'
    ],
    'internal_visit_done' => [
       'NA',
        'Yes',
        'No'
    ],
      'corner_plot' => [
       'NA',
        'Yes',
        'No'
        
      ],
       'registered_or_not' => [
       'NA',
        'Yes',
        'No'
        
    ]
];

foreach ($fields as $label => $name) {
    $value = htmlspecialchars($fieldss[$name] ?? '');

    echo "<td><label for='" . htmlspecialchars($name) . "'>$label</label></td><td>";

    if (array_key_exists($name, $dropdowns)) {
        // Render dropdown with wrapper
        echo "<div class='select-wrapper'>";
        echo "<select id='" . htmlspecialchars($name) . "' name='" . htmlspecialchars($name) . "'>";
        foreach ($dropdowns[$name] as $option) {
            $selected = ($value === $option) ? 'selected' : '';
            echo "<option value='" . htmlspecialchars($option) . "' $selected>$option</option>";
        }
        echo "</select>";
        echo "</div>";
    } else {
        // Render input field
        echo "<input type='text' id='" . htmlspecialchars($name) . "' name='" . htmlspecialchars($name) . "' value='$value'>";
    }

    echo "</td>";
    $count++;

    if ($count % 3 === 0) {
        echo '</tr><tr>';
    }
}

echo '</tr>';

    ?>
</table>

            <div class="submit-button">
                <button type="submit" name="action" value="save">Save</button>
            </div>
           
        </form>
    </div>
   
 
    <script>
document.addEventListener('DOMContentLoaded', () => {
    const form = document.getElementById('autosave-form');

    if (!form) return;

    function gatherFormData(form) {
        const formData = new FormData(form);
        const data = {};
        formData.forEach((value, key) => {
            data[key] = value;
        });
        return data;
    }

    function autoSaveSession() {
        const data = gatherFormData(form);

        fetch('autosave.php', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
                page: 'critical_parameters',
                data: data
            })
        });
    }

    form.addEventListener('input', autoSaveSession);
});
 

document.addEventListener('DOMContentLoaded', () => {
    const form = document.getElementById('autosave-form');

    if (!form) return;

    function gatherFormData(form) {
        const formData = new FormData(form);
        const data = {};
        formData.forEach((value, key) => {
            data[key] = value;
        });
        return data;
    }

    function autoSaveSession() {
        const data = gatherFormData(form);

        fetch('autosave.php', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
                page: 'REPORT5',
                data: data
            })
        });
    }

    form.addEventListener('input', autoSaveSession);
});
 


    document.addEventListener("DOMContentLoaded", function () {
    let tabs = document.querySelectorAll(".tab-links .tab");
    let slider = document.querySelector(".tab-links .slider");

    function moveSlider(activeTab) {
        slider.style.width = activeTab.offsetWidth + "px";
        slider.style.left = activeTab.offsetLeft + "px";
    }

    tabs.forEach(tab => {
        tab.addEventListener("click", function () {
            tabs.forEach(t => t.classList.remove("active"));
            this.classList.add("active");
            moveSlider(this);
        });

        // Initialize position on load for the active tab
        if (tab.classList.contains("active")) {
            moveSlider(tab);
        }
    });
});

  
document.getElementById("toggleSidebar").addEventListener("click", function () {
    if (confirm("Are you sure to open the side bar? Your data will be lost/erased.")) {
        // Redirect to "Pending For Drafting" page
        window.location.href = "clear_sessions.php";
    } else {
        // If user clicks Cancel, do nothing
        return false;
    }
});


var modal = document.getElementById("myModal");

// Get the <span> element that closes the modal
var span = document.getElementsByClassName("close")[0];

// Function to show the modal with custom text
function showPopup(text) {
    document.getElementById("modalText").innerText = text;
    modal.style.display = "block";
}

// When the user clicks on <span> (x), close the modal
span.onclick = function() {
    modal.style.display = "none";
}

// When the user clicks anywhere outside of the modal, close it
window.onclick = function(event) {
    if (event.target == modal) {
        modal.style.display = "none";
    }
}

function openGoogleMaps(location) {
            const baseUrl = "https://www.google.com/maps/search/?api=1&query=";
            window.open(baseUrl + encodeURIComponent(location), '_blank');
        }
function triggerFileInput2() {
            document.getElementById("imageInput").click();
        }

        document.getElementById("imageInput").addEventListener("change", function (event) {
            const files = event.target.files;
            const previewContainer = document.getElementById("imagePreviewContainer");

            // Clear previous previews
            previewContainer.innerHTML = "";

            // Display previews for each selected image
            Array.from(files).forEach((file) => {
                if (file.type.startsWith("image/")) {
                    const reader = new FileReader();
                    reader.onload = function (e) {
                        const img = document.createElement("img");
                        img.src = e.target.result;
                        previewContainer.appendChild(img);
                    };
                    reader.readAsDataURL(file);
                }
            });
        });
function triggerFileInput1() {
            document.getElementById("pdfInput").click();
        }

        // Handle file selection
        document.getElementById("pdfInput").addEventListener("change", function (event) {
            const file = event.target.files[0];
            if (file && file.type === "application/pdf") {
                // Create a FileReader instance
                const reader = new FileReader();

                // When the file is read successfully, open it in a new tab
                reader.onload = function (e) {
                    const pdfUrl = e.target.result;

                    // Try to open the PDF in a new tab using embed
                    const newTab = window.open();
                    if (newTab) {
                        newTab.document.write('<html><body><embed src="' + pdfUrl + '" type="application/pdf" width="100%" height="100%"></body></html>');
                        newTab.document.close();

                        // Fallback if the PDF does not load correctly
                        setTimeout(function() {
                            if (newTab.document.body.innerHTML === "") {
                                // Use PDF.js as a fallback to display the PDF
                                newTab.document.body.innerHTML = '<div id="pdf-container" style="width: 100%; height: 100%;"></div>';
                                const loadingTask = pdfjsLib.getDocument(pdfUrl);
                                loadingTask.promise.then(function(pdf) {
                                    pdf.getPage(1).then(function(page) {
                                        const scale = 1.5;
                                        const viewport = page.getViewport({ scale: scale });
                                        const canvas = document.createElement('canvas');
                                        const ctx = canvas.getContext('2d');
                                        canvas.height = viewport.height;
                                        canvas.width = viewport.width;
                                        document.getElementById('pdf-container').appendChild(canvas);

                                        // Render PDF page
                                        page.render({
                                            canvasContext: ctx,
                                            viewport: viewport
                                        });
                                    });
                                });
                            }
                        }, 1000); // Check if the embed failed after 1 second
                    }
                };

                // Read the file as a data URL
                reader.readAsDataURL(file);
            } else {
                alert("Please select a valid PDF file.");
            }
        });
        
</script>
</body>
</html>
