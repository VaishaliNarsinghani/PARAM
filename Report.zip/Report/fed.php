<?php include('auth.php'); ?>
<?php include 'watermark.html'; ?><?php
ini_set('display_errors', 1);
error_reporting(E_ALL);

// Increase PHP execution time and memory limit
ini_set('max_execution_time', 600); // Increase execution time to 600 seconds (10 minutes)
ini_set('memory_limit', '4096M'); // Increase memory limit to 4096MB
// Start session


// Database credentials
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "project_db";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Retrieve reference_id from session
if (!isset($_SESSION['reference_id'])) {
    die("Error: Reference ID not found.");
}

$reference_id = $_SESSION['reference_id'];


if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['download_images'])) {

    // Get customer name
    $stmt_name = $conn->prepare("SELECT customerName FROM mis WHERE reference_id = ?");
    $stmt_name->bind_param("s", $reference_id);
    $stmt_name->execute();
    $result_name = $stmt_name->get_result();
    $customerName = "customer";
    if ($row = $result_name->fetch_assoc()) {
        $customerName = preg_replace('/[^a-zA-Z0-9]/', '', $row['customerName']);
    }
    $stmt_name->close();

    // Fetch image BLOBs
    $stmt = $conn->prepare("SELECT image1, image2, image3, image4, image5, image6, image7, image8, image9, image10, image11, image12,image13, image14, image15, image16, image17, image18, image19, image20 FROM final_uploaded_images WHERE reference_id = ?");    $stmt->bind_param("s", $reference_id);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows > 0 && ($row = $result->fetch_assoc())) {
        $tempDir = sys_get_temp_dir() . DIRECTORY_SEPARATOR . uniqid('images_', true);
        mkdir($tempDir);

        $imageFiles = [];
        for ($i = 1; $i <= 12; $i++) {
            if (!empty($row["image$i"])) {
                $filename = $tempDir . DIRECTORY_SEPARATOR . "image{$i}.jpg";
                file_put_contents($filename, $row["image$i"]);
                $imageFiles[] = $filename;
            }
        }

        if (empty($imageFiles)) {
            die("No images to download.");
        }

        // Create ZIP
        $zipFileName = "images_" . preg_replace('/[^a-zA-Z0-9]/', '_', $reference_id) . "_{$customerName}.zip";
        $zipPath = $tempDir . DIRECTORY_SEPARATOR . $zipFileName;

        $zip = new ZipArchive();
        if ($zip->open($zipPath, ZipArchive::CREATE) !== TRUE) {
            die("Failed to create ZIP file.");
        }

        foreach ($imageFiles as $file) {
            $zip->addFile($file, basename($file));
        }
        $zip->close();

        // Send ZIP to browser
        header('Content-Type: application/zip');
        header('Content-Disposition: attachment; filename="' . basename($zipFileName) . '"');
        header('Content-Length: ' . filesize($zipPath));
        flush();
        readfile($zipPath);

        // Cleanup
        foreach ($imageFiles as $file) {
            unlink($file);
        }
        unlink($zipPath);
        rmdir($tempDir);
        exit;
    } else {
        echo "<p style='color:red;'>No image data found for this reference ID.</p>";
    }
}

// Debugging: Output for verification
//echo "Session reference_id: " . htmlspecialchars($reference_id) . "<br>";


$page = isset($_GET['page']) ? $_GET['page'] : 1;
$limit = 50;
$offset = ($page - 1) * $limit;
$sql_property = "SELECT * FROM mis WHERE reference_id = ? LIMIT $limit OFFSET $offset";
$stmt_property = $conn->prepare($sql_property);
$stmt_property->bind_param("s", $reference_id);
$stmt_property->execute();
$result_property = $stmt_property->get_result();
$data1 = $result_property->fetch_assoc();




// Fetch data from property_details table
$sql_property = "SELECT * FROM property_details WHERE reference_id = ?";
$stmt_property = $conn->prepare($sql_property);
$stmt_property->bind_param("s", $reference_id);
$stmt_property->execute();
$result_property = $stmt_property->get_result();
$data2= $result_property->fetch_assoc();




// Fetch data from area_valuation table
$sql_area = "SELECT * FROM address_details WHERE reference_id = ?";
$stmt_area = $conn->prepare($sql_area); 
$stmt_area->bind_param("s", $reference_id);
$stmt_area->execute();
$result_area = $stmt_area->get_result();
$data3 = $result_area->fetch_assoc();





// Fetch data from area_valuation table
$sql_area = "SELECT * FROM critical_parameters WHERE reference_id = ?";
$stmt_area = $conn->prepare($sql_area); 
$stmt_area->bind_param("s", $reference_id);
$stmt_area->execute();
$result_area = $stmt_area->get_result();
$data4 = $result_area->fetch_assoc();

 
// Fetch data from area_valuation table
$sql_area = "SELECT * FROM surroundings_details WHERE reference_id = ?";
$stmt_area = $conn->prepare($sql_area); 
$stmt_area->bind_param("s", $reference_id);
$stmt_area->execute();
$result_area = $stmt_area->get_result();
$data5 = $result_area->fetch_assoc();
$stmt_area->close();
 
// Fetch data from area_valuation table
$sql_area = "SELECT * FROM area_valuation WHERE reference_id = ?";
$stmt_area = $conn->prepare($sql_area); 
$stmt_area->bind_param("s", $reference_id);
$stmt_area->execute();
$result_area = $stmt_area->get_result();
$data6 = $result_area->fetch_assoc();
$stmt_area->close();
 



// Fetch data from area_valuation table
$sql_area = "SELECT * FROM floor_details WHERE reference_id = ?";
$stmt_area = $conn->prepare($sql_area); 
$stmt_area->bind_param("s", $reference_id);
$stmt_area->execute();
$result_area = $stmt_area->get_result();
$data8= $result_area->fetch_assoc();
$stmt_area->close();
 


// Fetch data from area_valuation table
$sql_area = "SELECT * FROM technical_details WHERE reference_id = ?";
$stmt_area = $conn->prepare($sql_area); 
$stmt_area->bind_param("s", $reference_id);
$stmt_area->execute();
$result_area = $stmt_area->get_result();
$data9 = $result_area->fetch_assoc();
$stmt_area->close();
 
// Fetch data from area_valuation table
$sql_area = "SELECT * FROM remarks_table WHERE reference_id = ?";
$stmt_area = $conn->prepare($sql_area); 
$stmt_area->bind_param("s", $reference_id);
$stmt_area->execute();
$result_area = $stmt_area->get_result();
$data10 = $result_area->fetch_assoc();
$stmt_area->close();


// Step 1: Fetch the engineer_id from the mis table
$sql_mis = "SELECT engineer_id FROM mis WHERE reference_id = ?";
$stmt_mis = $conn->prepare($sql_mis);
$stmt_mis->bind_param("s", $reference_id);
$stmt_mis->execute();
$result_mis = $stmt_mis->get_result();
$row_mis = $result_mis->fetch_assoc();
$stmt_mis->close(); 

if ($row_mis) {
    $engineer_id = $row_mis['engineer_id'];

    // Step 2: Fetch the engineer's name from engineer_login table
    $sql_engineer = "SELECT name FROM engineer_login WHERE engineer_id = ?";
    $stmt_engineer = $conn->prepare($sql_engineer);
    $stmt_engineer->bind_param("s", $engineer_id);
    $stmt_engineer->execute();
    $result_engineer = $stmt_engineer->get_result();
    $row_engineer = $result_engineer->fetch_assoc();
    $stmt_engineer->close();

    if ($row_engineer) {
        $engineer_name = $row_engineer['name'];
         //echo "Engineer Name: " . $engineer_name;
    } else {
        echo "Engineer not found.";
    }
} else {
    echo "No engineer assigned for this reference_id.";
}



// Step 1: Fetch the engineer_id from the mis table
$sql_mis = "SELECT report_id FROM mis WHERE reference_id = ?";
$stmt_mis = $conn->prepare($sql_mis);
$stmt_mis->bind_param("s", $reference_id);
$stmt_mis->execute();
$result_mis = $stmt_mis->get_result();
$row_mis = $result_mis->fetch_assoc();
$stmt_mis->close(); 

if ($row_mis) {
    $report_id = $row_mis['report_id'];

    // Step 2: Fetch the engineer's name from engineer_login table
    $sql_engineer = "SELECT name FROM report_login WHERE report_id = ?";
    $stmt_engineer = $conn->prepare($sql_engineer);
    $stmt_engineer->bind_param("s", $report_id);
    $stmt_engineer->execute();
    $result_engineer = $stmt_engineer->get_result();
    $row_engineer = $result_engineer->fetch_assoc();
    $stmt_engineer->close();

    if ($row_engineer) {
        $report_name = $row_engineer['name'];
         //echo "Engineer Name: " . $report_name;
    } else {
        echo "Engineer not found.";
    }
} else {
    echo "No engineer assigned for this reference_id.";
}


// Step 1: Fetch the engineer_id from the mis table
$sql_mis = "SELECT report_drafter_to_technical FROM mis WHERE reference_id = ?";
$stmt_mis = $conn->prepare($sql_mis);
$stmt_mis->bind_param("s", $reference_id);
$stmt_mis->execute();
$result_mis = $stmt_mis->get_result();
$row_mis = $result_mis->fetch_assoc();
$stmt_mis->close(); 

if ($row_mis) {
    $report_drafter_to_technical = $row_mis['report_drafter_to_technical'];

    // Step 2: Fetch the engineer's name from engineer_login table
    $sql_engineer = "SELECT name FROM technical_login WHERE technical_manager_id = ?";
    $stmt_engineer = $conn->prepare($sql_engineer);
    $stmt_engineer->bind_param("s", $report_drafter_to_technical);
    $stmt_engineer->execute();
    $result_engineer = $stmt_engineer->get_result();
    $row_engineer = $result_engineer->fetch_assoc();
    $stmt_engineer->close();

    if ($row_engineer) {
        $technical_name = $row_engineer['name'];
        //echo "Engineer Name: " . $technical_name;
    } else {
        echo "Engineer not found.";
    }
} else {
    echo "No engineer assigned for this reference_id.";
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>FED Report</title>
     <link rel="shortcut icon" href="favicon.png" type="image/x-icon"> 
</head>
<style>
    

.header-content {
    text-align: center;
    flex: 1;
}

.header-content h1 {
    margin: 0;
    margin-top:25px;  
     font-size: 38px;
    color: #902d2d;
}

.header-content p {
    margin: 2px 0;
    font-size: 26px;
    color: #333;
}
.footer{
    display: flex;
}
h3{
    background-color:rgb(243, 234, 222) ;
    padding:5px;
    text-align: center;
    border:1px solid black;
}    
      body {
      font-family: Arial, sans-serif;
      font-size: 14px;
      margin: 20px;
    }
    table {
      width: 100%;
      border-collapse: collapse;
      margin-bottom: 20px;
    }
    th, td {
      border: 1px solid #000;
      padding: 6px;
      vertical-align: top;
    }
    th {
      background-color: #d0eaf7;
      font-weight: bold;
      text-align: left;
    }
    .section-header {
      background-color: #c4e3f3;
      font-weight: bold;
      text-align: left;
    }
    input[type="text"]{
      width: 100%;
      border: none;
      padding: 4px;
      box-sizing: border-box;
    }
  
    .center {
      text-align: center;
      font-weight: bold;
      font-size: 16px;
      padding: 10px;
      border: 1px solid #000;
    }
       body {
      font-family: Arial, sans-serif;
    }
    table {
      width: 100%;
      border-collapse: collapse;
      font-size: 14px;
    }
    th, td {
      border: 1px solid black;
      padding: 6px;
      vertical-align: top;
    }
    th {
      background-color: #f2f2f2;
    }
    .section-header {
      background-color: #dbe5f1;
      font-weight: bold;
    }
    .bold {
      font-weight: bold;
    }
    .center {
      text-align: center;
    }
    input {
      width: 100%;
      box-sizing: border-box;
      font-size: 14px;
      padding: 4px;
    }
  
      

.container {
    max-width: 1200px;
    margin: 20px auto;
    padding: 20px;
    background-color: white;
    box-shadow: 0px 0px 10px rgba(0, 0, 0, 0.1);
    border-radius: 8px;
}

.title {
    text-align: center;
    font-size: 24px;
    font-weight: bold;
    margin-bottom: 20px;
}

 

.overlay {
    position: absolute;
    bottom: 0;
    left: 0;
    background: rgba(0, 0, 0, 0.6);
    color: white;
    width: 100%;
    padding: 8px;
    font-size: 14px;
    text-align: center;
}
  .logo img {
    width:160px;
    margin-left:10px;
    height: auto;
  }
 


pre{
  font-weight: 400;
  font-size:15px;
  font-family: Arial, Helvetica, sans-serif;
}
h2{
  text-align: center;
  font-weight: bold;
  padding: 8px;
  font-size:15px;
  font-family: Arial, Helvetica, sans-serif;
}
</style>
<style>
 
            

.container {
    max-width: 1200px;
    margin: 20px auto;
    padding: 20px;
    background-color: white;
    box-shadow: 0px 0px 10px rgba(0, 0, 0, 0.1);
    border-radius: 8px;
}

.title {
    text-align: center;
    font-size: 24px;
    font-weight: bold;
    margin-bottom: 20px;
}
.grid-container {
    display: grid;
    grid-template-columns: repeat(4, 1fr);
    gap: 15px;
}

.grid-item {
    position: relative;
    border-radius: 8px;
    overflow: hidden;
    box-shadow: 0px 4px 6px rgba(0, 0, 0, 0.1);
}

.grid-item img {
    width: 100%;
    height: 200px;
    object-fit: cover;
    transition: transform 0.3s ease;
}
.grid-item:hover img {
    transform: scale(1.05);
}

.overlay {
    position: absolute;
    bottom: 0;
    left: 0;
    background: rgba(0, 0, 0, 0.6);
    color: white;
    width: 100%;
    padding: 8px;
    font-size: 14px;
    text-align: center;
}
 
   
/* Force a stable 4-column grid that wkhtmltopdf respects */
.image-gallery { width: 100%; }
.image-grid { width: 100%; border-collapse: collapse; table-layout: fixed; }
.image-grid tr { page-break-inside: avoid; }
.image-grid td { width: 25%; padding: 6px; vertical-align: top; }

.image-grid .img-wrap { display: block; }
.image-grid img { display: block; width: 100%; height: auto; }
.image-grid .caption { font-size: 12px; text-align: center; margin-top: 4px; }

/* If you had a flex layout before, neutralize it */
.image-gallery { display: block !important; }



    /* Print-specific rules */
    @media print {
      .no-print {
        display: none !important;
      }

      body {
        margin: 0;
      }
 
    }
  button{
    padding:8px;
    margin-left:45%;
    background-color:#808485;
    color:white;
    font-weight:700;
    font-style:italic;
  }
  button:hover{
    background-color:rgba(216,216,216,255);
    color:white;
  }

/* Optional: Google map styling */
    .google-map-container {
      max-width: 90%;
      margin: 20px auto;
      margin-top:-40px;
      border: 2px solid #ccc;
      padding: 10px;
      box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
      background-color: #f9f9f9;
      border-radius: 8px;
      text-align: center;
    }

    .google-map-container img {
      max-width: 100%;
      height: auto;
      display: inline-block;
      border: 1px solid #999;
      border-radius: 4px;
    }
    
.logo img {
  width: 120px;
  margin-left:30px;
  height: auto;
}

 </style>
<body>
    <div class="container">
        <header>
            <div class="footer">
            <div class="logo">
                <img src="images/logo.png" alt="Magpie Logo">
            </div>
            <div class="header-content">
                <h1>MAGPIE ENGINEERING PVT. LTD.</h1>
                <p>Valuer Designer Architects</p>
                <p>Office no. 201, 2nd floor, Gravity Mall, Mechanic nagar, warehouse road, near vijay nagar, Indore, Madhya Pradesh- 452011</p>
            </div>
            </div>
        </header>
<form>
<table>
  <tr>
    <th colspan="7" class="center bold">TECHNICAL REPORT FORMAT</th>
  </tr>
  <tr>
    <td class="bold">Product</td>
    <td colspan=""><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data1['caseType'] ?? '') ?></span></td>
    <td class="bold">Branch</td>
    <td colspan="2"><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data1['bank_branchname'] ?? '') ?></span></td>
    <td class="bold">Date of Report</td>
    <td><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
 <?= htmlspecialchars(date('d M Y h:i A', strtotime($data1['report_assigned_at'] ?? ''))) ?></span></td>
  </tr>

  <tr>
    <td colspan="7" class="section-header">1 CUSTOMER DETAILS</td>
  </tr>

  <tr>
    <td class="bold">1.1</td>
    <td>Application Number</td>
    <td colspan="2"><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data1['applicationNo'] ?? '') ?></span></td>
    <td class="bold">1.7</td>
    <td>Reference Number</td>
    <td><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data1['reference_id'] ?? '') ?></td>
  </tr>

  <tr>
    <td class="bold">1.2</td>
    <td>Customer Name</td>
 <td colspan="2"><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data1['customerName'] ?? '') ?>
    </span></td>    <td class="bold">1.8</td>
    <td>Current Property owner name as per ownership document (also mention document name)</td>
    <td><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data9['owner_name'] ?? '') ?></span></td>
  </tr>

  <tr>
    <td class="bold">1.3</td>
    <td>Co-applicant Details</td>
    <td colspan="2"><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data1['co_applicant_name'] ?? '') ?></span></td>
    <td class="bold">1.9</td>
    <td>Proposed Owner/s</td>
    <td colspan=""><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data10['NA'] ?? '') ?></span></td>
  </tr>

  <tr>
    <td class="bold">1.4</td>
    <td>Date & Time of Inspection</td>
    <td colspan="2"><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data1['assigned_at'] ?? '') ?></span></td>
    <td class="bold">1.10’</td>
    <td>Visit Done By</td>
    <td colspan="2"><input type="text"   value="<?= $engineer_name ?>" readonly  name="visitDoneBy"></td>
  </tr>

  <tr>
    <td class="bold">1.5</td>
    <td>Case Type</td>
    <td colspan="2"><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data1['caseType'] ?? '') ?></span></td>
    <td class="bold">1.11</td>
    <td>Person met at site</td>
    <td colspan=""><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data2['person_meet_at_site_contact'] ?? '') ?></span></td>
  </tr>

  <tr>
    <td class="bold">1.6</td>
    <td>Contact Number of person met at site</td>
    <td colspan="2"><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data2['person_meet_at_site_contact'] ?? '') ?></span></td>
    <td class="bold">1.12</td>
    <td>Relationship with customer</td>
    <td colspan="2"><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data2['NA'] ?? '') ?></span></td>
  </tr>
  <tr>
    <td colspan="7" class="section-header">2 PROPERTY DETAILS</td>
  </tr>
   <tr>
    <td class="bold">2.1</td>
    <td>Address of Property</td>
<td colspan="2"><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data3['address_per_site'] ?? '') ?>
    </span> <td class="bold">2.4</td>
    <td>Legal Address(Survey No./FP No./Khasra No./Plot NO)</td>
<td colspan="2"><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data3['address_line_1_as_per_doc'] ?? '') ?>  <?= htmlspecialchars($data3['address_line_2_as_per_doc'] ?? '') ?>  <?= htmlspecialchars($data3['address_line_3_as_per_doc'] ?? '') ?>  <?= htmlspecialchars($data3['address_line_4_as_per_doc'] ?? '') ?>
    </span></td>  </tr>
   <tr>
    <td class="bold">2.2</td>
    <td>Pin Code </td>
    <td colspan="2"><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data3['pin_code'] ?? '') ?></span></td>
    <td class="bold">2.5</td>
    <td>Nearby Landmark</td>
       <td colspan="2"><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data3['landmark_1'] ?? '') ?> <?= htmlspecialchars($data3['landmark_2'] ?? '') ?></span></td>
  </tr>
   <tr>
    <td class="bold">2.3</td>
    <td>Latitude & Longitude </td>
       <td colspan="2"><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data3['latitude_value'] ?? '') ?> - <?= htmlspecialchars($data3['longitude_value'] ?? '') ?></span></td>
    <td class="bold">2.6</td>
    <td>Seismic Zone</td>
    <td colspan="2"><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data4['seismic_zone'] ?? '') ?></span></td>
  </tr>
   <tr>
    <td colspan="7" class="section-header">3 DOCUMENT DETAILS</td>
  </tr>
   <tr>
    <td class="bold">3.1</td>
    <td>Layout Plan Provided(Y/N) </td>
    <td colspan=""><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars('') ?></span></td>
    <td>Approving Authority </td>
    <td colspan=""><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data9['layout_authority'] ?? '') ?></span></td>
     <td>Approval Number & Date </td>
    <td colspan=""><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data9['layout_details'] ?? '') ?></span></td>
  </tr>
  <tr>
    <td class="bold">3.2</td>
    <td>Building Plan Provided(Y/N) </td>
    <td colspan=""><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data9['floor_availability'] ?? '') ?></span></td>
    <td>Approving Authority </td>
    <td colspan=""><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data9['floor_document'] ?? '') ?></span></td>
     <td>Approval Number & Date </td>
    <td colspan=""><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data9['floor_authority'] ?? '') ?> <?= htmlspecialchars($data9['floor_details'] ?? '') ?></span>
  <tr>
    <td class="bold">3.3</td>
    <td>Consturction Permission(Y/N) </td>
    <td colspan=""><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data10['NA'] ?? '') ?></span></td>
    <td>Approving Authority </td>
    <td colspan=""><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data10['NA'] ?? '') ?></span></td>
     <td>Approval Number & Date </td>
    <td colspan=""><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data10['NA'] ?? '') ?></span></td>
  </tr>
  <tr>
    <td class="bold">3.4</td>
    <td>RERA Applicable(Y/N) </td>
    <td colspan=""><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data10['NA'] ?? '') ?></span></td>
    <td>RERA Number </td>
    <td colspan="3"><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data9['location_details'] ?? '') ?></span></td>
  </tr>
   <tr>
    <td class="bold">3.5</td>
    <td>Stage of Construction as per RERA Website  </td>
    <td colspan=""><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data10['NA'] ?? '') ?></span></td>
    <td>Property Category (A Katha/B Katha/ Panchayat/Laal Dora etc.) </td>
    <td colspan="3"><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data10['NA'] ?? '') ?></span></td>
  </tr>
  <tr>
    <td class="bold">3.6</td>
    <td>List of Construction as per RERA Website   </td>
    <td colspan=""><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data10['NA'] ?? '') ?></span></td>
    <td>Other Document Provided  </td>
    <td colspan="3"><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data1['document_provided_for_valuation'] ?? '') ?></span></td>
  </tr>
</table>
</form>
 <form>
<table style="margin-top:-20px;">
  <tr>
    <td colspan="8" class="section-header">4 PHYSICAL DETAILS</td>
  </tr>

  <tr>
    <td rowspan="">4.1</td>
    <td rowspan="4" class="center"><br><br><br>Four Boundaries of property</td>
    <td>Directions</td>
    <td class="center">East</td>
    <td class="center">West</td>
    <td class="center">North</td>
    <td class="center">South</td>
  </tr>
  <tr>
    <td>4.2</td>
    <td>As per Document</td>
        <td><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data3['direction_as_per_document_east'] ?? '') ?></span></td>
      <td><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data3['direction_as_per_document_west'] ?? '') ?></span></td>
      <td><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data3['direction_as_per_document_north'] ?? '') ?></span></td>
      <td><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data3['direction_as_per_document_south'] ?? '') ?></span></td>
  </tr>

  <tr>
    <td>4.3</td>
    <td> As per Plan</td>
    <td><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data3['direction_approved_north'] ?? '') ?></span></td>
    <td><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data3['direction_approved_south'] ?? '') ?></span></td>
    <td><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data3['direction_approved_east'] ?? '') ?></span></td>
    <td><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data3['direction_approved_west'] ?? '') ?></span></td>
 </tr>
  <tr>
 <td>4.3</td>
    <td> As per site</td>   
    <td><input type="text"   readonly  name="engineer_id"  value="<?= $data3['direction_as_per_site_north'] ?? '' ?>" name="boundary_south"></td>
    <td><input type="text"   readonly  name="engineer_id"  value="<?= $data3['direction_as_per_site_south'] ?? '' ?>" name="boundary_south"></td>
    <td><input type="text"   readonly  name="engineer_id"  value="<?= $data3['direction_as_per_site_east'] ?? '' ?>" name="boundary_south"></td>
    <td><input type="text"   readonly  name="engineer_id"  value="<?= $data3['direction_as_per_site_west'] ?? '' ?>" name="boundary_south"></td>
  </tr>
  <tr>
    <td>4.5</td>
    <td>Boundaries Matching</td>
    <td colspan="2"><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data3['boundaries_matching'] ?? '') ?></span></td>
    <td>If Not, remarks</td>
    <td colspan="2"><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data10['NA'] ?? '') ?></span></td>
  </tr>

  <tr>
    <td>4.6</td>
    <td>Construction as per approved Plan</td>
    <td colspan="5"><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data6['construction_square_feet'] ?? '') ?></span></td>
  </tr>

  <tr>
    <td>4.7</td>
    <td rowspan="10" class="center"><br><br><br><br><br><br><br><br><br><br>PLOT DETAILS</td>
    <td>Plot Area As per Measurement</td>
    <td colspan="4"><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data6['plot_square_feet'] ?? '') ?></span></td>
  </tr>

  <tr>
    <td>4.8</td>
    <td>Plot demarcated at site</td>
    <td colspan="4"><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data2['demarcated_at_site'] ?? '') ?></span></td>
  </tr>

  <tr>
    <td>4.9</td>
    <td>Land Use (As per master plan)</td>
    <td colspan="4"><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data4['zoning_development_plan'] ?? '') ?></span></td>
  </tr>

  <tr>
    <td>4.10</td>
    <td>Whether electricity, water, drainage present in the vicinity (Y/N)</td>
    <td colspan="4"><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars('Yes') ?></span></td>
    
  </tr>

  <tr>
    <td>4.11</td>
    <td>Type of Locality (Residential /Commercial/Mix/Industrial/Others)</td>
    <td colspan="4"><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data2['class_of_locality'] ?? '') ?></span></td>
  </tr>

  <tr>
    <td>4.12</td>
    <td>Class of Locality</td>
    <td colspan="4"><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data2['class_of_locality'] ?? '') ?></span></td>
  </tr>

  <tr>
    <td>4.13</td>
    <td>Is community dominated area (Yes/No)</td>
    <td colspan="4"><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data10['NA'] ?? '') ?></span></td>
  </tr>

  <tr>
    <td>4.14</td>
    <td>Width of public road (ft.)</td>
    <td colspan="4"><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data2['width_of_approach_road'] ?? '') ?></span></td>
  </tr>

  <tr>
    <td>4.15</td>
    <td>Is property easily located and identified (Yes/No)</td>
    <td><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data10['NA'] ?? '') ?></span></td>
    <td>If No, mention reasons</td>
    <td colspan="2"><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data10['NA'] ?? '') ?></span></td>
  </tr>

  <tr>
    <td>4.16</td>
    <td>How Property Identified By Agency Personal</td>
    <td colspan="4"><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data2['NA'] ?? '') ?></span></td>
  </tr>

  <tr>
    <td>4.17</td>
    <td>Property Location (MC/GP/Panchayat under Development Authority)</td>
    <td><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data3['property_location_in'] ?? '') ?></span></td>
    <td>4.18</td>
    <td>Distance from Fedfina Branch (Km)</td>
    <td colspan="2"><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data3['distance_from_branch_kms'] ?? '') ?></span></td>
  </tr>

  <tr>
    <td rowspan="2">4.19</td>
    <td rowspan="2">Type of Property - On Verification (Land/Bungalow/Apartment /Builder Floor/Factory/Commercial Shop/Office/Institute/Farm House/Others)</td>
    <td colspan="2"><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data4['current_property_usage'] ?? '') ?></span></td>
    <td>Type of Property On  Documents</td>
    <td colspan="2"><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data4['approved_property_usage'] ?? '') ?></span></td>
  </tr>
</table>
</form>
 <form>
<table style="margin-top:-20px;">
  <tr>
    <td rowspan="">4.20*</td>
    <td rowspan="5" class="center"><br><br><br><br>Unit Details</td>
    <td>Detail</td>
    <td>No. of Rooms</td>
    <td>No. of Kitchen</td>
    <td>No. of Bathroom</td>
    <td>Others</td>
  </tr>
  <tr>
    <td>4.21</td>
    <td>GF</td>
    <td><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data10['NA'] ?? '') ?></span></td>
    <td><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data10['NA'] ?? '') ?></span></td>
    <td><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data10['NA'] ?? '') ?></span></td>
    <td><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data10['NA'] ?? '') ?></span></td>
  </tr>
  <tr>
    <td>4.22</td>
    <td>FF</td>
    <td><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data10['NA'] ?? '') ?></span></td>
    <td><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data10['NA'] ?? '') ?></span></td>
    <td><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data10['NA'] ?? '') ?></span></td>
    <td><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data10['NA'] ?? '') ?></span></td>
  </tr>
  <tr>
    <td>4.23</td>
    <td>SF</td>
   <td><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data10['NA'] ?? '') ?></span></td>
    <td><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data10['NA'] ?? '') ?></span></td>
    <td><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data10['NA'] ?? '') ?></span></td>
    <td><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data10['NA'] ?? '') ?></span></td>
  </tr>
  <tr>
    <td>4.24</td>
    <td>TF</td>
    <td><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data10['NA'] ?? '') ?></span></td>
    <td><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data10['NA'] ?? '') ?></span></td>
    <td><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data10['NA'] ?? '') ?></span></td>
    <td><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data10['NA'] ?? '') ?></span></td>
  </tr>
   <tr>
    <td>4.25</td>
    <td><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data10['NA'] ?? '') ?></span></td>
    <td><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data10['NA'] ?? '') ?></span></td>
    <td><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data10['NA'] ?? '') ?></span></td>
    <td><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data10['NA'] ?? '') ?></span></td>
    <td><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data10['NA'] ?? '') ?></span></td>
    <td><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data10['NA'] ?? '') ?></span></td>
  </tr>
  <tr>
    <td>4.26</td>
    <td>No. of Wings</td>
    <td colspan="5"><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data10['NA'] ?? '') ?></span></td>
  </tr>
  <tr>
    <td>4.27</td>
    <td>Structure (Load Bearing/RCC/Mixed)</td>
    <td colspan="5"><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data4['structure_type'] ?? '') ?></span></td>
  </tr>
  <tr>
    <td>4.28</td>
    <td>Interior Quality<br>(Premium/Average/Satisfactory/Poor)</td>
    <td colspan="2"><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars( $data2['structurally_fit'] ??'') ?></span></td>
    <td>Exterior Quality<br>(Premium/Average/Satisfactory/Poor)</td>
    <td colspan="2"><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data2['structurally_fit'] ?? '') ?></span></td>
  </tr>
  <tr>
    <td>4.29</td>
    <td>Maintenance level<br>(Good/Average/Poor)</td>
    <td colspan="5"><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data2['structurally_fit'] ?? '') ?></span></td>
  </tr>
  <tr>
    <td>4.30</td>
    <td>Roof (RCC/Wood/Stone/Metal/Asbestos etc.)</td>
    <td colspan="2"><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data4['roof_type'] ?? '') ?></span></td>
     <td>4.33</td>   
    <td> Wall Quality</td>
    <td colspan="2"><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data2['structurally_fit'] ?? '') ?></span></td>
  </tr>
  <tr>
    <td>4.31</td>
    <td>Age of Property (Years)</td>
    <td colspan="2"><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data2['age_of_property'] ?? '') ?></span></td>
    <td>4.34</td>
    <td> Residual Age of property (Years)</td>
    <td colspan="2"><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data2['residual_age_of_property'] ?? '') ?></span></td>
  </tr>

  <!-- OCCUPANCY DETAILS -->
  <tr>
    <td colspan="7" class="section-header">5 OCCUPANCY DETAILS</td>
  </tr>
  <tr>
    <td colspan="7" class="section-header">5.1 OCCUPANCY DETAILS - SUBJECT UNIT</td>
  </tr>
  <tr>
    <td>5.1.1</td>
    <td>Status of Occupancy</td>
    <td colspan="2"><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data2['occupancy_status'] ?? '') ?></span></td>
   <td>5.1.3</td>
    <td> Occupied by</td>
    <td colspan="2"><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data2['occupant_name'] ?? '') ?></span></td>
  </tr>
  <tr>
    <td>5.1.2</td> 
    <td>Relationship of Occupant with customer</td>
    <td colspan="2"><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data2['relation_of_occupant'] ?? '') ?></span></td>
    <td>5.1.4</td>
    <td>Occupied Since</td>
    <td colspan="2"><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data2['occupied_since'] ?? '') ?></span></td>
  </tr>

  <!-- SUBJECT SCHEME -->
  <tr>
    <td colspan="7" class="section-header">5.2 OCCUPANCY DETAILS - SUBJECT SCHEME</td>
  </tr>
  <tr>
    <td>5.2.1</td>
    <td>No of Units Occupied in Particular Scheme</td>
    <td colspan="2"><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data10['NA'] ?? '') ?></span></td>
    <td>5.2.3</td>
    <td> Percentage of Occupancy in Particular Scheme</td>
    <td colspan="2"><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data10['NA'] ?? '') ?></span></td>
  </tr>
  <tr>
    <td>5.2.2</td>
    <td>Percentage of Habitation in Particular Area (1 Kms)</td>
    <td colspan="2"><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data2['develop_percent'] ?? '') ?></span></td>
  </tr>

  <!-- VIOLATIONS -->
  <tr>
    <td colspan="7" class="section-header">6 VIOLATIONS OBSERVED IF ANY</td>
  </tr>
  <tr>
    <td>6.1</td>
    <td>Is there encroachment of land (Y/N)</td>
    <td colspan="2"><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data10['NA'] ?? '') ?></span></td>
    <td>6.4</td>
    <td> Area of encroachment</td>
    <td colspan=""><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data10['NA'] ?? '') ?></span></td>
  </tr>
  <tr>
    <td>6.2</td>
    <td>Any Deviation in Structure (Y/N)</td>
    <td colspan="2"><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data10['NA'] ?? '') ?></span></td>
     <td>6.5</td>
    <td> Risk of Demolition/Sealing (Nil/Low/Medium/High)</td>
    <td colspan=""><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data9['demolition_risk_1'] ?? '') ?></span></td>
  </tr>
  <tr>
    <td>6.3</td>
    <td>If plans not available then is the structure conforming to local bye-laws</td>
    <td colspan="5"><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data10['NA'] ?? '') ?></span></td>
  </tr>
</table>
</form>

<form>
<table style="margin-top:-20px;">
  <tr>
    <td colspan="16" class="section-header">7 VALUATION</td>
  </tr>
  <tr>
    <td rowspan="3">7.1</td>
    <td rowspan="4"><br><br><br><br>Land Value</td>
    <td>Land Area as per Plan</td>
    <td colspan="15"><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data10['NA'] ?? '') ?></span></td>
  </tr>
  <tr>
    <td>Land Area as per Document (in sq. ft.)</td>
    <td colspan="15"><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data6['plot_square_feet'] ?? '') ?></span></td>
  </tr>
  <tr>
    <td>Land Area as per Site (in sq. ft.)</td>
    <td colspan="15"><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data6['actual_plot_square_feet'] ?? '') ?></span></td>
    
  </tr>
  <tr>
    <td>7.2</td>
    <td>Land Rate (Per sq. ft.)</td>
    <td colspan="2"><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data6['final_plot_rate'] ?? '') ?></span></td>
     <td>7.11</td>
    <td>Land  Value</td>
    <td colspan="8"><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data6['finally_plot_valuation'] ?? '') ?></span></td>
  </tr>
  <tr>
    <td>7.3</td>
    <td>Permissible FSI</td>
    <td colspan="2"><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars( '') ?></span></td>
     <td>7.12</td>
    <td>FSI Considered For Valuation</td>
    <td colspan="8"><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars('') ?></span></td>
  </tr>
  <tr>
    <td rowspan="">7.4</td>
    <td rowspan="7"><br><br><br><br><br><br>Existing Construction Value </td>
    <td rowspan="">Type of Area (Carpet Area/Super Built Up Area/Built Up Area)</td>
    <td colspan="">Built Up Area</td>
    <td rowspan=""><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data10['NA'] ?? '') ?></span></td>
    <td rowspan=""><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars('') ?></span></td>
    <td rowspan=""><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars('') ?></span></td>
    <td rowspan=""><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars('') ?></span></td>
    <td rowspan="" colspan="4"><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars('') ?></span></td>
  </tr>
  <tr>
    <td>7.5</td>
    <td> Floor Details</td>
    <td>Area(Sqft)</td>
    <td>Rate(per Sqft)</td>
    <td colspan="4" >Amount(Rs)</td>
  </tr>
  <tr>
    <td>7.6</td>
    <td><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data6['construction_name_1'] ?? '') ?></span></td>
    <td><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data6['construction_area_sqft_1'] ?? '') ?></span></td>
    <td><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data6['construction_rate_1'] ?? '') ?></span></td>
    <td colspan="4"><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data6['construction_valuation_1'] ?? '') ?></span></td>
  </tr>
  <tr>
    <td></td>
    <td><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data6['construction_name_2'] ?? '') ?></span></td>
    <td><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data6['construction_area_sqft_2'] ?? '') ?></span></td>
    <td><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data6['construction_rate_2'] ?? '') ?></span></td>
    <td colspan="4"><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data6['construction_valuation_2'] ?? '') ?></span></td>
  </tr>
   <tr>
    <td></td>
    <td><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data6['construction_name_3'] ?? '') ?></span></td>
    <td><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data6['construction_area_sqft_3'] ?? '') ?></span></td>
    <td><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data6['construction_rate_3'] ?? '') ?></span></td>
    <td colspan="4"><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data6['construction_valuation_3'] ?? '') ?></span></td>
  </tr>
  <tr>
    <td>7.9</td>
    <td>Total</td>
    <td colspan="6"><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data6['finally_construction_valuation'] ?? '') ?></span></td>
  </tr>
  <tr>
    <td>7.10</td>
    <td>Total Existing Value of Property (Rs)</td>
    <td colspan="7"><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data6['total_finally_area_valuation'] ?? '') ?></span></td>
  </tr>
  <tr>
    <td colspan="9" class="note">Note: Lower of 3 to be considered: Construction Area as per plans or As per FSI norms or Actual Physical Measurement Area</td>
  </tr>
  <tr>
    <td colspan="9" class="section-header">To Be Filled ONLY For Construction & Improvement Cases</td>
  </tr>
  <tr>
    <td rowspan="6">7.13</td>
    <td rowspan="6"><br><br><br><br><br><br>Proposed Construction Details (‘C’)</td>
    <td>Floor Details</td>
    <td>Area (Sqft)</td>
    <td>Rate (per Sqft)</td>
    <td colspan="4">Amount (Rs)</td>
  </tr>
  <tr>
    <td>Ground Floor</td>
    <td><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data8['ground_approved'] ?? '') ?></span></td>
    <td><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data10['NA'] ?? '') ?></span></td>
    <td colspan="4"><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data10['NA'] ?? '') ?></span></td>
  </tr>
  <tr>
    <td>First Floor</td>
    <td><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data8['first_approved'] ?? '') ?></span></td>
    <td><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data10['NA'] ?? '') ?></span></td>
    <td colspan="4"><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data10['NA'] ?? '') ?></span></td>
  </tr>
  <tr>
    <td>Second Floor</td>
    <td><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data8['second_approved'] ?? '') ?></span></td>
    <td><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data10['NA'] ?? '') ?></span></td>
    <td colspan="4"><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data10['NA'] ?? '') ?></span></td>
  </tr>
  <tr>
    <td></td>
    <td><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data8['other_approved_floors'] ?? '') ?></span></td>
    <td><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data10['NA'] ?? '') ?></span></td>
    <td colspan="4"><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data10['NA'] ?? '') ?></span></td>
  </tr>
  <tr>
    <td>Total</td>
    <td colspan="6"><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data8['total_approved_floors'] ?? '') ?></span></td>
  </tr>
  <tr>
    <td>7.14</td>
    <td>Cost as per Estimate of Customer (Rs)</td>
    <td colspan="7"><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data10['NA'] ?? '') ?></span></td>
  </tr>
  <tr>
    <td>7.15</td>
    <td>Rate/Sqft as per Estimate of customer (Rs)</td>
    <td colspan="7"><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data10['NA'] ?? '') ?></span></td>
  </tr>
  <tr>
    <td>7.16</td>
    <td>Expected Date of Completion</td>
    <td colspan="7"><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data10['NA'] ?? '') ?></span></td>
  </tr>
  <tr>
    <td>7.17</td>
    <td rowspan="6"><br><br><br><br><br>Description of proposed construction/improvement</td>
    <td colspan="2">Material at site (Yes/No)</td>
    <td colspan="5"><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data10['NA'] ?? '') ?></span></td>
  </tr>
  <tr>
    <td rowspan="5">7.18</td>
    <td>Description</td>
    <td>Rs./sqft</td>
    <td>Qty.</td>
    <td colspan="4">Total Value</td>
  </tr>
  <tr>
    <td><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data10['NA'] ?? '') ?></span></td>
    <td><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data10['NA'] ?? '') ?></span></td>
    <td><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data10['NA'] ?? '') ?></span></td>
    <td colspan="4"><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data10['NA'] ?? '') ?></span></td>
  </tr>
  <tr>
    <td><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data10['NA'] ?? '') ?></span></td>
    <td><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data10['NA'] ?? '') ?></span></td>
    <td><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data10['NA'] ?? '') ?></span></td>
    <td colspan="4"><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data10['NA'] ?? '') ?></span></td>
  </tr>
  <tr>
    <td><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data10['NA'] ?? '') ?></span></td>
    <td><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data10['NA'] ?? '') ?></span></td>
    <td><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data10['NA'] ?? '') ?></span></td>
    <td colspan="4"><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data10['NA'] ?? '') ?></span></td>
  </tr>
  <tr>
    <td><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data10['NA'] ?? '') ?></span></td>
    <td><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data10['NA'] ?? '') ?></span></td>
    <td><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data10['NA'] ?? '') ?></span></td>
    <td colspan="4"><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data10['NA'] ?? '') ?></span></td>
  </tr>
   
  <tr>
    <td>7.19</td>
    <td></td>
    <td>Value of extra Amenities</td>
    <td colspan="6"><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data6['amenities_total'] ?? '') ?></span></td>
  </tr>
  <tr>
    <td>7.20</td>
    <td>Total Property Valuation (A+B+C) (Rs)</td>
    <td colspan="7"><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data6['total_finally_area_valuation'] ?? '') ?></span></td>
  </tr>
  <tr>
    <td>7.21</td>
    <td><br>Valuation as per Govt. Guideline Rate</td>
    <td>Rate (per sqft)</td>
    <td><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data6['guideline_rate'] ?? '') ?></span></td>
    <td><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data10['NA'] ?? '') ?></span></td>
    <td>Land Value as per Government Guideline Rate (RS)</td>
    <td colspan="3"><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data6['guideline_value'] ?? '') ?></span></td>
  </tr>
  <tr>
    <td>7.22</td>
    <td>Realizable Value (95% of Fair Market Value)</td>
    <td colspan="7"><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data10['NA'] ?? '') ?></span></td>
  </tr>
  <tr>
    <td>7.23</td>
    <td>Distressed Value of Property (Rs) (85% of market value)</td>
    <td colspan="7"><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data6['distress_value_percent'] ?? '') ?></span></td>
  </tr>
  <tr>
    <td>7.24</td>
    <td>Marketability</td>
    <td colspan="7"><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data9['markebility'] ?? '') ?></span></td>
  </tr>
</table>
</form>

<form>
<!-- SECTION 8: Stage of Construction -->
<table style="margin-top:-20px;">
  <tr>
    <td colspan="6" class="section-header">8 STAGE OF CONSTRUCTION</td>
  </tr>
  <tr>
    <td>8.1</td>
   <td rowspan="2"><br>Based on standard Cost of construction</td>
    <td>Description of Structure (RCC/Load Bearing/Mix)</td>
    <td>(Description of stage)</td>
    <td>% Completed </td>
    <td> % Recommended </td>
  </tr>
  <tr>
    <td>8.2</td>
    <td><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data4['structure_type'] ?? '') ?></span></td>
    <td><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data8['description_stage_construction_allotted'] ?? '') ?></span></td>
    <td><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data8['stage_construction_actual_present_completion'] ?? '') ?></span></td>
    <td><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data8['stage_construction_recommend_present_completion'] ?? '') ?></span></td>
  </tr>
</table>

<!-- SECTION 9: Reference Details -->
<table style="margin-top:-20px;">
  <tr>
    <td colspan="6" class="section-header">9 REFERENCE DETAILS</td>
  </tr>
  <tr>
    <td>9.1</td>
    <td>Reference Type (Broker/Builder/Colonizer/Neighbour/Shop Owner/Valuer)</td>
    <td><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data10['NA'] ?? '') ?></span></td>
    <td>9.4</td>
    <td>Reference Name</td>
    <td colspan="2"><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data10['NA'] ?? '') ?></span></td>
  </tr>
  <tr>
    <td>9.2</td>
    <td>Reference Contact Number</td>
    <td><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data10['NA'] ?? '') ?></span></td>
    <td>9.5</td>
    <td>Remarks, if any</td>
    <td colspan="2"><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data10['NA'] ?? '') ?></span></td>
  </tr>
  <tr>
    <td>9.3</td>
    <td>Valuation Result</td>
    <td><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data9['positive_report'] ?? '') ?></span></td>
    <td>9.6</td>
    <td> Fair Rental Value</td>
    <td colspan="2"><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data10['NA'] ?? '') ?></span></td>
  </tr>
</table>

<!-- SECTION 10: Remarks -->
<table style="margin-top:-20px;">
  <tr>
    <td colspan="6" class="section-header">10 REMARKS</td>
  </tr>
  <tr>
    <td colspan="6">
<span style="white-space: pre-line; font-size:14px; display: block; text-align: left; padding: 0; margin: 0;">
        <?= htmlspecialchars($data10['remarks'] ?? '') ?>
    </span>
    </td>
  </tr>
</table>
<table style="margin-top:-20px;">
<tr>
    <td colspan="6" class="section-header">11. DECLARATION</td>
</tr>
<tr> 
 <td colspan="6">
<span style="white-space: pre-line; font-size:14px; display: block; text-align: left; padding: 0; margin: 0;font-weight:400;" readonly>
    <?= nl2br(htmlspecialchars(formatDeclaration($data10['declaration'] ?? ''))) ?>
</span></td>
 <?php
function formatDeclaration($text) {
    // Insert a newline before every occurrence of a number followed by a dot and space (e.g., "1. ", "10. ")
    // Only if it's NOT already at the beginning of the string or a new line
    $text = preg_replace('/(?<!^)(?<!\n)(\d+\.\s)/', "\n$1", $text);
    return $text;
}
?>
    <tr>
        <td><br><br>Signature with seal</td>
       <td colspan="5" style="height:80px;"></td>
    </tr>
  <tr>
    <td>Place </td>
    <td colspan="2"><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data1['bank_branchname'] ?? '') ?></span></td>
    <td>Date</td>
     <td colspan="2"><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
 <?= htmlspecialchars(date('d M Y h:i A', strtotime($data1['report_assigned_at'] ?? ''))) ?></span></td>
  </tr>
  <tr>
     <td>Customer Name </td>
 <td colspan="2"><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data1['customerName'] ?? '') ?>
    </span></td>  
      <td>Application Number </td>
    <td colspan="2"><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data1['applicationNo'] ?? '') ?></span></td>
  </tr>

  <tr>
    <td>Address of Property </td>
    <td colspan="5"><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data3['address_per_site'] ?? '') ?>
    </span></td>
  </tr>
   <tr>
    <td>Google View Map  </td>
    <td colspan="5"><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data3['latitude_value'] ?? '') ?>,<?= htmlspecialchars($data3['longitude_value'] ?? '') ?></span>
 </td>
  </tr>
</table>

<!-- SECTION 11: Property Photograph -->
<table style="margin-top:-20px;">
  <tr>
    <td colspan="6" class="section-header">11 Property Photograph</td>
  </tr>
  <tr>
    <td>External photograph of unit (Photo of building/Society Name)</td>
    <td>One Surrounding Photograph</td>
    <td>One Photo of Electricity Meter (Meter number should be visible)</td>
    <td>Selfie of vendor/agent visiting the property</td>
    <td>Internal photograph of unit (Drawing Room, Kitchen, Bedroom, Gallery etc.)</td>
    <td>One Photo of all entrance</td>
  </tr>
    <tr>
    <td colspan="6" class="section-header">12 Geo Location (Satellite View)</td>
  </tr>
  <tr>
   <td colspan="6"class="section-header"><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data3['latitude_value'] ?? '') ?>,<?= htmlspecialchars($data3['longitude_value'] ?? '') ?></span>
 </td>
  </tr>
</table>
</form>
     <table>
<tr><th style="margin-bottom:-18px;">PHOTOGRAPH OF THE PROPERTY</tr></th></table>
<br>

    
<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

$servername = "localhost";
$username   = "root";
$password   = "";
$dbname     = "project_db";

$conn = new mysqli($servername, $username, $password, $dbname);
if ($conn->connect_error) {
    die("Connection failed: " . htmlspecialchars($conn->connect_error));
}

$reference_id = $_SESSION['reference_id'] ?? null;
$reference_id = $_GET['reference_id'] ?? $reference_id;

if ($reference_id) {

    // Map captions
    $captions = [
        'image1'  => 'EXTERNAL PHOTOS',
        'image2'  => 'Kitchen',
        'image3'  => 'Selfie',
        'image4'  => 'Electric Meter',
        'image6'  => 'Other 1',
        'image7'  => 'Other 2',
        'image8'  => 'Other 3',
        'image9'  => 'Other 4',
        'image10' => 'Other 5',
        'image11' => 'Other 6',
        'image12' => 'Other 7',
        'image13' => 'Other 8',
        'image14' => 'Other 9',
        'image15' => 'Other 10',
        'image16' => 'Other 11',
        'image17' => 'Other 12',
        'image18' => 'Other 13',
        'image19' => 'Other 14',
        'image20' => 'Other 15',
    ];

    // === Helper: EXIF-aware orientation detection ===
    function classify_orientation_after_exif(string $imageData): ?string {
        $size = @getimagesizefromstring($imageData);
        if (!$size || !isset($size[0], $size[1])) {
            return null;
        }
        $width  = (int)$size[0];
        $height = (int)$size[1];

        $mime = $size['mime'] ?? '';
        if ($mime === 'image/jpeg' && function_exists('exif_read_data')) {
            $tmp = @tempnam(sys_get_temp_dir(), 'exif_');
            if ($tmp !== false) {
                @file_put_contents($tmp, $imageData);
                $exif = @exif_read_data($tmp);
                @unlink($tmp);

                if (!empty($exif['Orientation'])) {
                    $orientation = (int)$exif['Orientation'];
                    if ($orientation === 6 || $orientation === 8) {
                        $t = $width; $width = $height; $height = $t;
                    }
                }
            }
        }
        return ($width >= $height) ? 'horizontal' : 'vertical';
    }

    // === Helper: Fix orientation physically with Imagick ===
    function fixImageOrientation($binaryData) {
        $img = new Imagick();
        $img->readImageBlob($binaryData);

        switch ($img->getImageOrientation()) {
            case Imagick::ORIENTATION_BOTTOMRIGHT:
                $img->rotateImage("#000", 180);
                break;
            case Imagick::ORIENTATION_RIGHTTOP:
                $img->rotateImage("#000", 90);
                break;
            case Imagick::ORIENTATION_LEFTBOTTOM:
                $img->rotateImage("#000", -90);
                break;
        }

        $img->setImageOrientation(Imagick::ORIENTATION_TOPLEFT);
        $fixed = $img->getImageBlob();
        $img->destroy();

        return $fixed;
    }

    $sql = "SELECT 
                image1, image2, image3, image4, 
                image6, image7, image8, image9, 
                image10, image11, image12, image13, image14, image15, image16, image17, image18, image19, image20
            FROM final_uploaded_images 
            WHERE reference_id = ?";

    $stmt = $conn->prepare($sql);
    if ($stmt === false) {
        die("Error preparing the SQL statement: " . htmlspecialchars($conn->error));
    }

    $stmt->bind_param("s", $reference_id);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result && $result->num_rows > 0) {
        $horizontal_images = [];
        $vertical_images   = [];

        while ($row = $result->fetch_assoc()) {
            foreach ($row as $key => $imageData) {
                if (!empty($imageData)) {

                    // Actually fix image before displaying
                    $fixedData = fixImageOrientation($imageData);

                    $orientation = classify_orientation_after_exif($fixedData) ?? 'horizontal';
                    $imgString   = base64_encode($fixedData);
                    $caption     = $captions[$key] ?? 'Image';

                    $item = [
                        'data'    => $imgString,
                        'caption' => $caption,
                        'alt'     => $key,
                    ];

                    if ($orientation === 'horizontal') {
                        $horizontal_images[] = $item;
                    } else {
                        $vertical_images[]   = $item;
                    }
                }
            }
        }

 
// Output as a stable 4-column table (works in wkhtmltopdf)
$all_images = array_merge($vertical_images, $horizontal_images);

echo '<table class="image-grid">';
$rows = array_chunk($all_images, 4);
foreach ($rows as $row) {
    echo '<tr>';
    foreach ($row as $img) {
        echo '<td>';
        echo '<div class="img-wrap">';
        echo '<img src="data:image/jpeg;base64,' . $img['data'] . '" alt="' . htmlspecialchars($img['alt']) . '">';
        echo '<div class="caption">' . htmlspecialchars($img['caption']) . '</div>';
        echo '</div>';
        echo '</td>';
    }
    // pad remaining cells to keep 4 columns
    $remaining = 4 - count($row);
    if ($remaining > 0) {
        echo str_repeat('<td></td>', $remaining);
    }
    echo '</tr>';
}
echo '</table>';

    } else {
        echo "<p style='text-align:center;'>No images found.</p>";
    }

    $stmt->close();
} else {
    echo "<p style='text-align:center;'>Reference ID is missing.</p>";
}
?>

 
    <table>
<tr>
    <h3 style="margin-top:-16px;">LOCATION MAP</h3>
      </tr>
</table>
<br>
      <table>
<tr> <td colspan="3">Latitude - Longitude</td>
<td colspan="3"><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data3['latitude_value'] ?? '') ?>-<?= htmlspecialchars($data3['longitude_value'] ?? '') ?></span></td>
   </tr>
</table>
 
      <table>
  </tr>
  <tr>

<div class="google-map-container">
<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "project_db";
$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$reference_id = $_SESSION['reference_id'] ?? null;
$reference_id = $_GET['reference_id'] ?? $reference_id;

if ($reference_id) {
    $sql = "SELECT image5 FROM final_uploaded_images WHERE reference_id = ?";
    $stmt = $conn->prepare($sql);
    if ($stmt === false) {
        die("Error preparing the SQL statement: " . $conn->error);
    }

    $stmt->bind_param("s", $reference_id);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows > 0) {
        $row = $result->fetch_assoc();
        if (!empty($row['image5'])) {
 
            echo '<div><img src="data:image/jpeg;base64,' . base64_encode($row['image5']) . '" alt="Google Map"><p>Google Map</p></div>';
        } else {
            echo "<p style='text-align:center;'>Google Map image not available.</p>";
        }
    } else {
        echo "<p style='text-align:center;'>No record found for Google Map image.</p>";
    }

    $stmt->close();
} else {
    echo "<p style='text-align:center;'>Reference ID is missing.</p>";
}
?>
</tr>
</div>
    </table>
    </table>
   <!-- <button onclick="window.print()">Download PDF</button> -->
 <form method="post">
  <input type="hidden" name="download_images" value="1">
  <button type="submit">Download All Images</button>
</form>
     <!-- <button onclick="window.print()">Download PDF</button> -->
  <button id="downloadPdf" onclick="setPrintMargins()">DOWNLOAD PDF</button>
  <script>
    document.getElementById('downloadPdf').addEventListener('click', () => {
      // Select the content you want to convert to PDF
      const element = document.getElementById('content');
      const options = {
        margin:[0,0],
        filename:'report.pdf',
        image: { type: 'jpeg', quality: 0.98 },
        html2canvas: { scale: 2 },
        jsPDF: { unit: 'in', format: 'letter', orientation: 'portrait' }
      };

      // Generate and download the PDF
      html2pdf().set(options).from(element).save();
    });
    function setPrintMargins() {
      const style = document.createElement('style');
      style.innerHTML = `
      @media print {
          body {
            margin:0.5;
          }
        }
      `;
      document.head.appendChild(style);
      window.print();
    }
    // Disable all input fields in the form
    document.querySelectorAll('input').forEach(function(input) {
        input.disabled = true;  // Disables the field completely
    });
    </script>
</body>
</html>