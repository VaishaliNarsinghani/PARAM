<?php include('auth.php'); ?>
<?php include 'watermark.html'; ?>

<?php
ini_set('display_errors', 1);
error_reporting(E_ALL);

// Increase PHP execution time and memory limit
ini_set('max_execution_time', 600); // Increase execution time to 600 seconds (10 minutes)
ini_set('memory_limit', '4096M'); // Increase memory limit to 4096MB
// Start session


$servername = "localhost";
$username = "root";
$password = "";
$dbname = "project_db";

// Create DB connection
$conn = new mysqli($servername, $username, $password, $dbname);
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

if (!isset($_SESSION['reference_id'])) {
    die("Reference ID not found in session.");
}
$reference_id = $_SESSION['reference_id'];

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['download_images'])) {

    // Get customer name
    $stmt_name = $conn->prepare("SELECT customerName FROM mis WHERE reference_id = ?");
    $stmt_name->bind_param("s", $reference_id);
    $stmt_name->execute();
    $result_name = $stmt_name->get_result();
    $customerName = "customer";
    if ($row = $result_name->fetch_assoc()) {
        $customerName = preg_replace('/[^a-zA-Z0-9]/', '', $row['customerName']);
    }
    $stmt_name->close();

    // Fetch image BLOBs
    $stmt = $conn->prepare("SELECT image1, image2, image3, image4, image5, image6, image7, image8, image9, image10, image11, image12, image13, image14, image15, image16, image17, image18, image19, image20 FROM final_uploaded_images WHERE reference_id = ?");
    $stmt->bind_param("s", $reference_id);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows > 0 && ($row = $result->fetch_assoc())) {
        $tempDir = sys_get_temp_dir() . DIRECTORY_SEPARATOR . uniqid('images_', true);
        mkdir($tempDir);

        $imageFiles = [];
        for ($i = 1; $i <= 12; $i++) {
            if (!empty($row["image$i"])) {
                $filename = $tempDir . DIRECTORY_SEPARATOR . "image{$i}.jpg";
                file_put_contents($filename, $row["image$i"]);
                $imageFiles[] = $filename;
            }
        }

        if (empty($imageFiles)) {
            die("No images to download.");
        }

        // Create ZIP
        $zipFileName = "images_" . preg_replace('/[^a-zA-Z0-9]/', '_', $reference_id) . "_{$customerName}.zip";
        $zipPath = $tempDir . DIRECTORY_SEPARATOR . $zipFileName;

        $zip = new ZipArchive();
        if ($zip->open($zipPath, ZipArchive::CREATE) !== TRUE) {
            die("Failed to create ZIP file.");
        }

        foreach ($imageFiles as $file) {
            $zip->addFile($file, basename($file));
        }
        $zip->close();

        // Send ZIP to browser
        header('Content-Type: application/zip');
        header('Content-Disposition: attachment; filename="' . basename($zipFileName) . '"');
        header('Content-Length: ' . filesize($zipPath));
        flush();
        readfile($zipPath);

        // Cleanup
        foreach ($imageFiles as $file) {
            unlink($file);
        }
        unlink($zipPath);
        rmdir($tempDir);
        exit;
    } else {
        echo "<p style='color:red;'>No image data found for this reference ID.</p>";
    }
}

$page = isset($_GET['page']) ? $_GET['page'] : 1;
$limit = 50;
$offset = ($page - 1) * $limit;
$sql_property = "SELECT * FROM mis WHERE reference_id = ? LIMIT $limit OFFSET $offset";
$stmt_property = $conn->prepare($sql_property);
$stmt_property->bind_param("s", $reference_id);
$stmt_property->execute();
$result_property = $stmt_property->get_result();
$data1 = $result_property->fetch_assoc();




// Fetch data from property_details table
$sql_property = "SELECT * FROM property_details WHERE reference_id = ?";
$stmt_property = $conn->prepare($sql_property);
$stmt_property->bind_param("s", $reference_id);
$stmt_property->execute();
$result_property = $stmt_property->get_result();
$data2= $result_property->fetch_assoc();




// Fetch data from area_valuation table
$sql_area = "SELECT * FROM address_details WHERE reference_id = ?";
$stmt_area = $conn->prepare($sql_area); 
$stmt_area->bind_param("s", $reference_id);
$stmt_area->execute();
$result_area = $stmt_area->get_result();
$data3 = $result_area->fetch_assoc();





// Fetch data from area_valuation table
$sql_area = "SELECT * FROM critical_parameters WHERE reference_id = ?";
$stmt_area = $conn->prepare($sql_area); 
$stmt_area->bind_param("s", $reference_id);
$stmt_area->execute();
$result_area = $stmt_area->get_result();
$data4 = $result_area->fetch_assoc();

 
// Fetch data from area_valuation table
$sql_area = "SELECT * FROM surroundings_details WHERE reference_id = ?";
$stmt_area = $conn->prepare($sql_area); 
$stmt_area->bind_param("s", $reference_id);
$stmt_area->execute();
$result_area = $stmt_area->get_result();
$data5 = $result_area->fetch_assoc();
$stmt_area->close();
 
// Fetch data from area_valuation table
$sql_area = "SELECT * FROM area_valuation WHERE reference_id = ?";
$stmt_area = $conn->prepare($sql_area); 
$stmt_area->bind_param("s", $reference_id);
$stmt_area->execute();
$result_area = $stmt_area->get_result();
$data6 = $result_area->fetch_assoc();
$stmt_area->close();
 



// Fetch data from area_valuation table
$sql_area = "SELECT * FROM floor_details WHERE reference_id = ?";
$stmt_area = $conn->prepare($sql_area); 
$stmt_area->bind_param("s", $reference_id);
$stmt_area->execute();
$result_area = $stmt_area->get_result();
$data8= $result_area->fetch_assoc();
$stmt_area->close();
 


// Fetch data from area_valuation table
$sql_area = "SELECT * FROM technical_details WHERE reference_id = ?";
$stmt_area = $conn->prepare($sql_area); 
$stmt_area->bind_param("s", $reference_id);
$stmt_area->execute();
$result_area = $stmt_area->get_result();
$data9 = $result_area->fetch_assoc();
$stmt_area->close();
 
// Fetch data from area_valuation table
$sql_area = "SELECT * FROM remarks_table WHERE reference_id = ?";
$stmt_area = $conn->prepare($sql_area); 
$stmt_area->bind_param("s", $reference_id);
$stmt_area->execute();
$result_area = $stmt_area->get_result();
$data10 = $result_area->fetch_assoc();
$stmt_area->close();


// Step 1: Fetch the engineer_id from the mis table
$sql_mis = "SELECT engineer_id FROM mis WHERE reference_id = ?";
$stmt_mis = $conn->prepare($sql_mis);
$stmt_mis->bind_param("s", $reference_id);
$stmt_mis->execute();
$result_mis = $stmt_mis->get_result();
$row_mis = $result_mis->fetch_assoc();
$stmt_mis->close(); 

if ($row_mis) {
    $engineer_id = $row_mis['engineer_id'];

    // Step 2: Fetch the engineer's name from engineer_login table
    $sql_engineer = "SELECT name FROM engineer_login WHERE engineer_id = ?";
    $stmt_engineer = $conn->prepare($sql_engineer);
    $stmt_engineer->bind_param("s", $engineer_id);
    $stmt_engineer->execute();
    $result_engineer = $stmt_engineer->get_result();
    $row_engineer = $result_engineer->fetch_assoc();
    $stmt_engineer->close();

    if ($row_engineer) {
        $engineer_name = $row_engineer['name'];
         //echo "Engineer Name: " . $engineer_name;
    } else {
        echo "Engineer not found.";
    }
} else {
    echo "No engineer assigned for this reference_id.";
}



// Step 1: Fetch the engineer_id from the mis table
$sql_mis = "SELECT report_id FROM mis WHERE reference_id = ?";
$stmt_mis = $conn->prepare($sql_mis);
$stmt_mis->bind_param("s", $reference_id);
$stmt_mis->execute();
$result_mis = $stmt_mis->get_result();
$row_mis = $result_mis->fetch_assoc();
$stmt_mis->close(); 

if ($row_mis) {
    $report_id = $row_mis['report_id'];

    // Step 2: Fetch the engineer's name from engineer_login table
    $sql_engineer = "SELECT name FROM report_login WHERE report_id = ?";
    $stmt_engineer = $conn->prepare($sql_engineer);
    $stmt_engineer->bind_param("s", $report_id);
    $stmt_engineer->execute();
    $result_engineer = $stmt_engineer->get_result();
    $row_engineer = $result_engineer->fetch_assoc();
    $stmt_engineer->close();

    if ($row_engineer) {
        $report_name = $row_engineer['name'];
         //echo "Engineer Name: " . $report_name;
    } else {
        echo "Engineer not found.";
    }
} else {
    echo "No engineer assigned for this reference_id.";
}


// Step 1: Fetch the engineer_id from the mis table
$sql_mis = "SELECT report_drafter_to_technical FROM mis WHERE reference_id = ?";
$stmt_mis = $conn->prepare($sql_mis);
$stmt_mis->bind_param("s", $reference_id);
$stmt_mis->execute();
$result_mis = $stmt_mis->get_result();
$row_mis = $result_mis->fetch_assoc();
$stmt_mis->close(); 

if ($row_mis) {
    $report_drafter_to_technical = $row_mis['report_drafter_to_technical'];

    // Step 2: Fetch the engineer's name from engineer_login table
    $sql_engineer = "SELECT name FROM technical_login WHERE technical_manager_id = ?";
    $stmt_engineer = $conn->prepare($sql_engineer);
    $stmt_engineer->bind_param("s", $report_drafter_to_technical);
    $stmt_engineer->execute();
    $result_engineer = $stmt_engineer->get_result();
    $row_engineer = $result_engineer->fetch_assoc();
    $stmt_engineer->close();

    if ($row_engineer) {
        $technical_name = $row_engineer['name'];
        //echo "Engineer Name: " . $technical_name;
    } else {
        echo "Engineer not found.";
    }
} else {
    echo "No engineer assigned for this reference_id.";
}
?>
 <!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="UTF-8" />
    <title>Valuation Report Form</title>
    <style>
      body {
        font-family: Arial, sans-serif;
        margin: 0;
        padding: 10px;
      }

      .container {
        max-width: 1200px;
        margin: auto;
        padding: 10px;
        border: 2px solid #000;
      }
      table {
        width: 100%;
        border-collapse: collapse;
      }
      th,
      td {
        border: 1px solid #000;
        padding: 3px 5px;
        font-size: 11px;
        vertical-align: center;
        text-align: center;
      }
      th {
        font-weight: bold;
      }

      input[type="text"] {
        width: 100%;
        border:none;
        outline: none;
        text-align: center;
      }
             button{
  padding:8px;
  margin-left:45%;
  background-color:#5d5e5f8f ;
  font-weight:500;
  font-style:italic;
}
button:hover{
  background-color:#bdbabaf4 ;
}
@media print{
  body{
    margin:0;
  }
  button{
    display:none;
    margin-left:30%;
  }

  }
  pre{
      font-size:15px;
      font-family: Arial, sans-serif;
      font-style: oblique;
  }
  textarea{
      width:100%;
    height:200px;
  }
  .number-column {
    width: 40px;
    text-align: center;
    font-weight: bold;
}

      input[type="text"] {
        width: 100%;
        padding: 6px;
        text-align: left;
        box-sizing: border-box;
        border: 1px solid #ccc;
        border-radius: 4px;
      }
      .photo-gallery {
      display: grid;
      grid-template-columns: repeat(4, 1fr);
      gap: 10px;
    }
    .photo-gallery img {
      width: 100%;
      height: auto;
      border: 1px solid #000;
    }
            
.header-content {
    text-align: center;
    flex: 1;
}

.header-content h1 {
    margin: 0;
    margin-top:25px;  
    font-size: 35px;
    color: #902d2d;
}

.header-content p {
    margin: 2px 0;
    font-size: 16px;
    color: #381515;
}
.footer{
    display: flex;
}
.blue{
    background-color:#dce6f1;
}
.green{
    background-color:#ebf1de;
}
.pink{
    background-color:#f2dcdb;
}

    </style>
     <style>
 
            

.container {
    max-width: 1200px;
    margin: 20px auto;
    padding: 20px;
    background-color: white;
    box-shadow: 0px 0px 10px rgba(0, 0, 0, 0.1);
    border-radius: 8px;
}

.title {
    text-align: center;
    font-size: 24px;
    font-weight: bold;
    margin-bottom: 20px;
}
.grid-container {
    display: grid;
    grid-template-columns: repeat(4, 1fr);
    gap: 15px;
}

.grid-item {
    position: relative;
    border-radius: 8px;
    overflow: hidden;
    box-shadow: 0px 4px 6px rgba(0, 0, 0, 0.1);
}

.grid-item img {
    width: 100%;
    height: 200px;
    object-fit: cover;
    transition: transform 0.3s ease;
}
.grid-item:hover img {
    transform: scale(1.05);
}

.overlay {
    position: absolute;
    bottom: 0;
    left: 0;
    background: rgba(0, 0, 0, 0.6);
    color: white;
    width: 100%;
    padding: 8px;
    font-size: 14px;
    text-align: center;
}
 


    /* Print-specific rules */
    @media print {
      .no-print {
        display: none !important;
      }

      body {
        margin: 0;
      }
 
    }
  button{
    padding:8px;
    margin-left:45%;
    background-color:#808485;
    color:white;
    font-weight:700;
    font-style:italic;
  }
  button:hover{
    background-color:rgba(216,216,216,255);
    color:white;
  }

/* Optional: Google map styling */

.logo img {
  width: 120px;
  margin-left:30px;
  height: auto;
}

 </style>
  <style>
 
            

.container {
    max-width: 1200px;
    margin: 20px auto;
    padding: 20px;
    background-color: white;
    box-shadow: 0px 0px 10px rgba(0, 0, 0, 0.1);
    border-radius: 8px;
}

.title {
    text-align: center;
    font-size: 24px;
    font-weight: bold;
    margin-bottom: 20px;
}
.grid-container {
    display: grid;
    grid-template-columns: repeat(4, 1fr);
    gap: 15px;
}

.grid-item {
    position: relative;
    border-radius: 8px;
    overflow: hidden;
    box-shadow: 0px 4px 6px rgba(0, 0, 0, 0.1);
}

.grid-item img {
    width: 100%;
    height: 200px;
    object-fit: cover;
    transition: transform 0.3s ease;
}
.grid-item:hover img {
    transform: scale(1.05);
}

.overlay {
    position: absolute;
    bottom: 0;
    left: 0;
    background: rgba(0, 0, 0, 0.6);
    color: white;
    width: 100%;
    padding: 8px;
    font-size: 14px;
    text-align: center;
}
 
   
/* Force a stable 4-column grid that wkhtmltopdf respects */
.image-gallery { width: 100%; }
.image-grid { width: 100%; border-collapse: collapse; table-layout: fixed; }
.image-grid tr { page-break-inside: avoid; }
.image-grid td { width: 25%; padding: 6px; vertical-align: top; }

.image-grid .img-wrap { display: block; }
.image-grid img { display: block; width: 100%; height: auto; }
.image-grid .caption { font-size: 12px; text-align: center; margin-top: 4px; }

/* If you had a flex layout before, neutralize it */
.image-gallery { display: block !important; }



    /* Print-specific rules */
    @media print {
      .no-print {
        display: none !important;
      }

      body {
        margin: 0;
      }
 
    }
  button{
    padding:8px;
    margin-left:45%;
    background-color:#808485;
    color:white;
    font-weight:700;
    font-style:italic;
  }
  button:hover{
    background-color:rgba(216,216,216,255);
    color:white;
  }

/* Optional: Google map styling */
    .google-map-container {
      max-width: 90%;
      margin: 20px auto;
      border: 2px solid #ccc;
      padding: 10px;
      box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
      background-color: #f9f9f9;
      border-radius: 8px;
      text-align: center;
    }

    .google-map-container img {
      max-width: 100%;
      height: auto;
      display: inline-block;
      border: 1px solid #999;
      border-radius: 4px;
    }
    
.logo img {
  width: 120px;
  margin-left:30px;
  height: auto;
}
 </style>
  </head>
  <body>
    <div class="container">
         <div class="footer">
            <div class="logo">
                <img src="images/logo.png" alt="Magpie Logo">
            </div>
            <div class="header-content">
                <h1>MAGPIE ENGINEERING PVT. LTD.</h1>
                <p>Valuer Designer Architects</p>
                <p>Office no. 201, 2nd floor, Gravity Mall, Mechanic nagar, warehouse road, near vijay nagar, Indore, Madhya Pradesh- 452011</p>
            </div>
            </div>

      <form style="border:1px solid black;">
        <table>
          <tr>
            <th class="pink"  colspan="2">Name of Valuation Agency</th>
            <th class="blue" colspan="2">Valuation Report For NIDO HOME FINANCE LIMITED</th>
            <th class="pink" >Date of Technical Initiation</th>
           <td><span style="display: inline-block; min-width: 50px; padding: 2px;">
 <?= htmlspecialchars(date('d M Y', strtotime($data1['initiationDate'] ?? ''))) ?>
    </span></td>
          </tr>
          <tr>
            <th class="pink" colspan="2">Name of the Applicant / Contact Details</th>
            <td colspan="2"><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data1['customerName'] ?? '') ?> <?=htmlspecialchars( $data1['customerMob'] ?? '') ?>
    </span></td>
            <th class="pink" >Date of Site Visit</th>
          <td><span style="display: inline-block; min-width: 50px; padding: 2px;">
               <?= htmlspecialchars(date('d M Y', strtotime($data1['fe_to_coordinator_assign_at'] ?? ''))) ?>

    </span></td>
          </tr>
          <tr>
            <th class="pink"  colspan="2">Name of Co Applicant / Contact Details</th>
            <td colspan="2"><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data1['co_applicant_name'] ?? '') ?>
    </span></td>
            <th class="pink" >Date of Report Release</th>
            <td><span style="display: inline-block; min-width: 50px; padding: 2px;">
 <?= htmlspecialchars(date('d M Y h:i A', strtotime($data1['report_assigned_at'] ?? ''))) ?>
    </span> </td>
        </tr>
    </table>
    <table>
        <tr>
            <th class="pink" colspan="4" >Data from Technical Initiation Request Form</th>
        </tr>
        <tr>
            <th class="green" >Proposal ID / Application No</th>
            <td><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data1['applicationNo'] ?? '') ?>
    </span></td>
            <th class="green" >Transaction Type</th>
            <td><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data1['caseType'] ?? '') ?>
    </span></td>
          </tr>
          <tr>
            <th class="green">Branch Name / ID</th>
            <td><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data1['bank_branchname'] ?? '') ?>
    </span></td>
            <th class="green">Request from FIHFC Employee</th>
            <td><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars('Mr.Vinit Billore') ?>
    </span></td>
          </tr>
          <tr>
            <th class="green">Serial No.</th>
            <td colspan="3"><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data1['reference_id'] ?? '') ?>
    </span></td>
          </tr>
          <tr>
            <th class="green">Name of Current Owner / Seller</th>
            <td colspan="3"><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data9['owner_name'] ?? '') ?>
    </span></td>
          </tr>
          <tr>
            <th class="green">Name of the Person met at site & Contact No.</th>
            <td colspan="3"><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data2['person_meet_at_site_contact'] ?? '') ?>
    </span></td>
          </tr>
        </table>
        <table>
            <tr>
                 <th colspan="4" class="pink">Address 1</th>
            </tr>
            <tr>
              <th colspan="1" rowspan="3" class="green">Address Of The Property <br> Being Appraised</th>
            <th class="green">As per TRF</th>
            <td colspan="3"><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
  <?= htmlspecialchars($data3['address_per_document'] ?? '') ?>  <?= htmlspecialchars($data3['pin_code'] ?? '') ?> </span></td>
        
          </tr>
          <tr>
            <th class="green">As per Legal Documents</th>
            <td colspan="2"><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
  <?= htmlspecialchars($data3['address_per_document'] ?? '') ?>   <?= htmlspecialchars($data3['pin_code'] ?? '') ?></span></td>
          </tr>
          <tr>
            <th class="green">As per Actual at site</th>
            <td colspan="2"><span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data3['address_per_site'] ?? '') ?>
    </span></td>
          </tr>
          <tr>
            <th class="green">Documents Provided by EHFL/ERFL/ECLF</th>
            <td colspan="2"><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data9['list_documents'] ?? '') ?>
    </span></td>
          </tr>
        </table>
        <table>
            <tr>
                 <th colspan="6" class="pink">Locational & Property Specific Details</th>
            </tr>
          <tr>
            <th class="green">Status of Holding</th>
            <td><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data2['property_leasehold_freehold'] ?? '') ?>
    </span></td>
            <th class="green">Delivery Agency</th>
            <td colspan="3"><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data3['property_location_in'] ?? '') ?>
    </span></td>
          </tr>
          <tr>
            <th class="green">Type of Property</th>
            <td><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data2['property_unit_type'] ?? '') ?>
    </span></td>
            <th class="green">Name of the State</th>
            <td colspan="3"><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data3['address_line_4_as_per_doc'] ?? '') ?>
    </span></td>
          </tr>
          <tr>
            <th class="green">Main Locality</th>
            <td><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data2['class_of_locality'] ?? '') ?>
    </span></td>
            <th class="green">Sub Locality</th>
            <td colspan="3"><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data2['class_of_locality'] ?? '') ?>
    </span></td>
          </tr>
          <tr>
            <th class="green">Street on which Property is located</th>
            <td><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data2['approach_road_to_property'] ?? '') ?>
    </span></td>
            <th class="green">Nearest Landmark</th>
            <td colspan="3"><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data3['landmark_1'] ?? '') ?>  <?=htmlspecialchars( $data3['landmark_2'] ?? '') ?>
    </span></td>
          </tr>
          <tr>
            <th class="green">Pin Code</th>
            <td><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data3['pin_code'] ?? '') ?>
    </span></td>
            <th class="green">Occupation Status</th>
            <td colspan="3"><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data2['occupancy_status'] ?? '') ?>
    </span></td>
          </tr>
          <tr>
            <th class="green">Locality/Zoning type</th>
            <td><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data4['zoning_development_plan'] ?? '') ?>
    </span></td>
            <th class="green">Property Usage</th>
            <td colspan="3"><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data4['current_property_usage'] ?? '') ?>
    </span></td>
          </tr> 
          <tr>
            <th class="green">Property Identifiable</th>
            <td><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data2['NA'] ?? '') ?>
    </span></td>
            <th class="green">Property Demarcated separately</th>
            <td colspan="3"><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data2['demarcated_at_site'] ?? '') ?>
    </span></td>
          </tr>
          <tr>
            <th class="green">Identified Through</th>
            <td><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data2['NA'] ?? '') ?>
    </span></td>
            <th class="green">Name of City/Town/Village</th>
            <td colspan="3"><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data3['address_line_3_as_per_doc'] ?? '') ?>
    </span></td>
          </tr>
          <tr>
            <th class="green">Roof Construction</th>
            <td><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data4['roof_type'] ?? '') ?>
    </span></td>
            <th class="green">Type of Structure</th>
            <td colspan="3"><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data4['structure_type'] ?? '') ?>
    </span></td>
          </tr>
          <tr>
            <th class="green">No. of Floors in the building</th>
            <td><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data8['actual_configuration_building'] ?? '') ?>
    </span></td>
            <th class="green">Located on Floor No.</th>
            <td colspan="3"><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data2['NA'] ?? '') ?>
    </span></td>
          </tr>
          <tr>
            <th class="green">Total No. of Flats / Units</th>
            <td><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data10['NA'] ?? '') ?>
    </span></td>
            <th class="green">Internal Quality of construction</th>
            <td colspan="3"><input type="text"   readonly  name="engineer_id"  value="Average"></td>
          </tr>
          <tr>
            <th class="green">External Finishing</th>
            <td><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data10['NA'] ?? '') ?>
    </span></td>
            <th class="green">Type of Flooring</th>
            <td colspan="3"><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data10['NA'] ?? '') ?>
    </span></td>
          </tr>
          <tr>
            <th class="green">Present Age of the Property in Yrs</th>
            <td><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data2['age_of_property'] ?? '') ?>
    </span></td>
            <th class="green">Future Physical Life of Property in Yrs</th>
            <td colspan="3"><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data2['residual_age_of_property'] ?? '') ?>
    </span></td>
          </tr>
          <tr>
            <th class="green">Latitude</th>
            <td><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data3['latitude_value'] ?? '') ?>
    </span></td>
            <th class="green">Longitude</th>
            <td colspan="3"><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data3['longitude_value'] ?? '') ?>
    </span></td>
          </tr>
          <tr>
            <th class="green">Extra Amenities available</th>
            <td colspan="5"><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data10['NA'] ?? '') ?>
    </span></td>
          </tr>
        </table>
        <table>
             <tr>
                 <th colspan="6" class="pink">Zone/Locality/Surrounding/Civic Amenities</th>
            </tr>
          <tr>
            <th class="green">Infrastructure in the area</th>
            <td><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data2['infra_building'] ?? '') ?>
    </span></td>
            <th class="green">Class of Locality</th>
            <td colspan="3"><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data2['class_of_locality'] ?? '') ?>
    </span></td>
          </tr>
          <tr>
            <th class="green">Type of Road</th>
            <td><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data2['type_of_approach_road'] ?? '') ?>
    </span></td>
            <th class="green">Width of the Road in ft</th>
            <td><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data2['width_of_approach_road'] ?? '') ?>
    </span></td>
        </tr>
        <tr>
            <th class="green">Electrification</th>
            <td><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data10['NA'] ?? '') ?>
    </span></td>
            <th class="green">Distance from Bus stand (Km)</th>
            <td><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data3['nearest_bus_stop_distance'] ?? '') ?>
    </span></td>
            
          </tr>
          <tr>
            <th class="green">Distance from Main Market</th>
            <td><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data3['nearest_bus_stop_distance'] ?? '') ?>
    </span></td>
            <th class="green">Distance from Railway Station</th>
            <td><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data3['nearest_railway_station_distance'] ?? '') ?>
    </span></td>
          </tr>
          <tr>
            <th class="green">Property falls under Seismic Zone</th>
            <td><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data4['seismic_zone'] ?? '') ?>
    </span></td>
            <th class="green">Property Falls under Flood Zone</th>
            <td><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data10['NA'] ?? '') ?>
    </span></td>
          
          </tr>
          <tr>
              <th class="green">Property falls under Cyclone Zone</th>
            <td><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data10['NA'] ?? '') ?>
    </span></td>
            <th class="green">Property Falls in CR Zone</th>
            <td><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data10['NA'] ?? '') ?>
    </span></td>
          </tr>
          <tr>
            <th class="green">Degree of Risk Associated</th>
            <td><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data10['NA'] ?? '') ?>
    </span></td>
            <th class="green">Na (Any Risk Of Demoilition)</th>
            <td><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data9['demolition_risk_1'] ?? '') ?>
    </span></td>
          </tr>
        </table>
        <table>
                <tr>
                 <th colspan="5" class="pink">Boundaries</th>
            </tr>
          <tr>
            <th class="green">Boundaries</th>
            <th class="green">North</th>
            <th class="green">South</th>
            <th class="green">East</th>
            <th class="green">West</th>
          </tr>
          <tr>
            <th class="green">As per Documents</th>
            <td><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data3['direction_as_per_document_north'] ?? '') ?>
    </span></td>
            <td><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data3['direction_as_per_document_south'] ?? '') ?>
    </span></td>
            <td><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data3['direction_as_per_document_east'] ?? '') ?>
    </span></td>
            <td><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data3['direction_as_per_document_west'] ?? '') ?>
    </span></td>
          </tr>
          <tr>
            <th class="green">As per Site/ Actual</th>
            <td><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data3['direction_as_per_site_north'] ?? '') ?>
    </span></td>
            <td><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data3['direction_as_per_site_south'] ?? '') ?>
    </span></td>
            <td><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data3['direction_as_per_site_east'] ?? '') ?>
    </span></td>
            <td><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data3['direction_as_per_site_west'] ?? '') ?>
    </span></td>
          </tr>
          <tr>
            <th class="green">Boundaries Maching</th>
            <td><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data3['boundaries_matching'] ?? '') ?>
    </span></td>
            <td>If No, then reason thereon</td> 
            <td colspan="2"><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data10['NA'] ?? '') ?>
    </span></td>
          </tr>
        </table>
        <table>
          <tr>
            <th colspan="6" class="section-title pink">Setbacks / Margin (in Ft)</th>
          </tr>
          <tr>
            <th class="green" colspan="2">Setbacks / Margin in buildings</th>
            <th class="green">Front</th>
            <th class="green">Rear</th>
            <th class="green">Left Side</th>
            <th class="green">Right Side</th>
          </tr>
               
          <tr>
            <th class="green" colspan="2">As per sanctioned / permissible byelaws</th>
            <td><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data10['NA'] ?? '') ?>
    </span></td>
            <td><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data10['NA'] ?? '') ?>
    </span></td>
            <td><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data10['NA'] ?? '') ?>
    </span></td>
            <td><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data10['NA'] ?? '') ?>
    </span></td>
          </tr>
          <tr>
            <th class="green" colspan="2">As per Site / Actual</th>
            <td><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data10['NA'] ?? '') ?>
    </span></td>
            <td><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data10['NA'] ?? '') ?>
    </span></td>
            <td><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data10['NA'] ?? '') ?>
    </span></td>
            <td><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data10['NA'] ?? '') ?>
    </span></td>
          </tr>

          <tr>
            <th colspan="6" class="section-title pink">Height / Storeys</th>
          </tr>
          <tr>
            <th colspan="2" class="green">As per sanctioned / permissible byelaws</th>
            <td colspan="4"><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data8['approved_configuration_building'] ?? '') ?>
    </span></td>
          </tr>
          <tr>
            <th colspan="2" class="green">As per Site / Actual</th>
            <td colspan="4"><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data8['actual_configuration_building'] ?? '') ?>
    </span></td>
          </tr>

          <tr>
            <th colspan="6" class="section-title pink">
              Plot dimension details (In Ft) for Independent Built up
            </th>
          </tr>
          <tr>
            <th>Side 1</th>
            <th>Side 2</th>
            <th>Side 3</th>
            <th>Side 4</th>
            <th>Actual Area at site in Sft</th>
            <th>Legal Area as per Docs in Sft</th>
          </tr>
          <tr>
            <td><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data10['NA'] ?? '') ?>
    </span></td>
            <td><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data10['NA'] ?? '') ?>
    </span></td>
            <td><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data10['NA'] ?? '') ?>
    </span></td>
            <td><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data10['NA'] ?? '') ?>
    </span></td>
            <td><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data10['NA'] ?? '') ?>
    </span></td>
            <td><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data10['NA'] ?? '') ?>
    </span></td>
          </tr>

          <tr>
            <th colspan="6" class="section-title pink">
              Area & Accommodation Details
            </th>
          </tr>
          <tr>
            <th class="green">Floor (Pl mention floor wise)</th>
            <th class="green">Accommodation</th>
            <th class="green">Carpet Area (Sft)</th>
            <th class="green">Actual BUA / Saleable Area (Sft)</th>
            <th class="green">Permissible Area (Sft)</th>
            <th class="green">Adopted Area (Sft)</th>
          </tr>
          <tr> 

            <th class="green">Basement / Stilt</th>
            <td><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data10['NA'] ?? '') ?>
    </span></td>
            <td><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data10['NA'] ?? '') ?>
    </span></td>
            <td><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data10['NA'] ?? '') ?>
    </span></td>
            <td><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data10['NA'] ?? '') ?>
    </span></td>
            <td><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data10['NA'] ?? '') ?>
    </span></td>
          </tr>


          <tr>
            <th class="green">Ground Floor Rcc</th>
            <td><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data2['NA'] ?? '') ?>
    </span></td>
            <td><input type="text" readonly value="<?= isset($data6['ground_actual']) ? round($data6['ground_actual'] * 0.8, 2) : '' ?>" 
               name=""></td>
            <td><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data8['ground_actual'] ?? '') ?>
    </span></td>
            <td><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data8['ground_permissible'] ?? '') ?>
    </span></td>
            <td><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data8['ground_approved'] ?? '') ?>
    </span></td>
          </tr>
          <tr>
            <th class="green">FF Floor Tin shed</th>
            <td><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data2['NA'] ?? '') ?>
    </span></td>
  <td><input type="text" 
               readonly 
               value="<?= isset($data6['first_actual']) ? round($data6['first_actual'] * 0.8, 2) : '' ?>" 
               name=""></td>            <td><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data8['first_actual'] ?? '') ?>
    </span></td>
            <td><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data8['first_permissible'] ?? '') ?>
    </span></td>
            <td><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data8['first_approved'] ?? '') ?>
    </span></td>
          </tr>
          <tr>
            <th class="green">Second Floor</th>
            <td><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data2['NA'] ?? '') ?>
    </span></td>
  <td><input type="text" 
               readonly 
               value="<?= isset($data6['second_actual']) ? round($data6['second_actual'] * 0.8, 2) : '' ?>" 
               name=""></td>            <td><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data8['second_actual'] ?? '') ?>
    </span></td>
            <td><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data8['second_permissible'] ?? '') ?>
    </span></td>
            <td><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data8['second_approved'] ?? '') ?>
    </span></td>
          </tr>
          <tr>
            <th class="green">Third Floor</th>
            <td><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data2['NA'] ?? '') ?>
    </span></td>
  <td><input type="text" 
               readonly 
               value="<?= isset($data6['other_actual_floors']) ? round($data6['other_actual_floors'] * 0.8, 2) : '' ?>" 
               name=""></td>            <td><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data8['other_actual_floors'] ?? '') ?>
    </span></td>
            <td><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data8['other_permissible_floors'] ?? '') ?>
    </span></td>
            <td><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data8['other_approved_floors'] ?? '') ?>
    </span></td>
          </tr>
          <tr>
            <th class="green">Total</th>
            <td><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data10['NA'] ?? '') ?>
    </span></td>
  <td><input type="text" 
               readonly 
               value="<?= isset($data6['total_actual_floors']) ? round($data6['total_actual_floors'] * 0.8, 2) : '' ?>" 
               name=""></td>            <td><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data8['total_actual_floors'] ?? '') ?>
    </span></td>
            <td><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data8['total_permissible_floors'] ?? '') ?>
    </span></td>
            <td><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data8['total_approved_floors'] ?? '') ?>
    </span></td>
          </tr>

          <tr>
            <th colspan="6" class="section-title pink">
              Building Approvals & Related Documents
            </th>
          </tr>
          <tr>
            <th colspan="1" class="green">Construction as per approved / sanctioned plans</th>
            <td colspan="2"><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data9['floor_availability'] ?? '') ?>
    </span></td>
            <th colspan="1" class="green">
              Details of approved plan with approval no and date
            </th>
            <td colspan="2"><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data9['floor_authority'] ?? '') ?> <?=htmlspecialchars( $data9['floor_details'] ?? '') ?>
    </span></td>
          </tr>
          <tr>
            <th colspan="1" class="green">CC/OC Number and date</th>
            <td colspan="2"><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data10['NA'] ?? '') ?>
    </span></td>
             <th colspan="1" class="green">Work Progress observed at site</th>
            <td colspan="2"><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data10['NA'] ?? '') ?>
    </span></td>
          </tr>
          <tr>
            <th colspan="1" class="green">
              If plans not available whether the structure confirming to the
              local byelaws.
            </th>
            <td colspan="2"><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data10['NA'] ?? '') ?>
    </span></td>
             <th colspan="1" class="green">Violations Observed if Any</th>
            <td colspan="2"><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data10['NA'] ?? '') ?>
    </span></td>
          </tr>
          <tr>
           
          </tr>
          <tr>
            <th colspan="1" class="green">
              Any other docs like P tax/ E bill/Society NOC etc
            </th>
            <td colspan="2"><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data10['NA'] ?? '') ?>
    </span></td>
              <th colspan="1" class="green">RERA Number for Builder Project</th>
            <td colspan="2"><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data9['location_details'] ?? '') ?>
    </span></td>
          </tr>
          <tr>
          
          </tr>

          <tr>
            <th colspan="6" class="section-title pink">
              Estimate Analysis (Applicable only in Self Construction cases)
            </th>
          </tr>
          <tr>
            <th colspan="1" class="green">Total Estimate submitted (in Rs)</th>
            <td colspan="2"><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data10['NA'] ?? '') ?>
    </span></td>
             <th colspan="1" class="green">Submitted Estimated Cost (in Rs per Sqft)</th>
            <td colspan="2"><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data10['NA'] ?? '') ?>
    </span></td>
          </tr>
          <tr>
           
          </tr>
          <tr>
            <th colspan="1" class="green">Justified Estimated Cost (in Rs per Sqft)</th>
            <td colspan="2"><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data10['NA'] ?? '') ?>
    </span></td>
             <th colspan="1" class="green">Adoptable / Justified Estimated Cost (In Rs)</th>
            <td colspan="2"><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data10['NA'] ?? '') ?>
    </span></td>
          </tr>
          <tr>
           
          </tr>
        </table>
        <table>
          <tr>
            <th colspan="6" class="section-title pink" >Property Valuation</th>
          </tr>

          <tr>
            <th colspan="6" class="section-title blue">
              Valuation of Independent House/Bungalow/Commercial/Industrial
              Building
            </th>
          </tr>
          <tr>
            <th class="green">Land Area (In Sqft)</th>
            <td><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data6['final_plot_square_feet'] ?? '') ?>
    </span></td>
            <th class="green">Adoptable Built-up Area (in Sqft)</th>
            <td><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars('0') ?>
    </span></td>
          </tr>
          <tr>
            <th class="green">Rate Range of land in the locality (Rs Per Sqft)</th>
            <td><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data10['NA'] ?? '') ?>
    </span></td>
            <th class="green">Construction Cost (Rs per sft)</th>
            <td><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars('0') ?>
    </span></td>
          </tr>
          <tr>
            <th class="green">Recommended Rate of Land (Rs per sqft)</th>
            <td><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data6['final_plot_rate'] ?? '') ?>
    </span></td>
            <th class="green">Total Construction Value for 100% complete building (in Rs)</th>
            <td><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data10['NA'] ?? '') ?>
    </span></td>
          </tr>
          <tr>
            <th class="green">Pls specify if any special amenities provided</th>
            <td><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data10['NA'] ?? '') ?>
    </span></td>
            <th class="green">
              Add Cost incurred for amenities (in Rs) - Teen Shade Area in Sqft.
            </th>
            <td><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data10['NA'] ?? '') ?>
    </span></td>
          </tr>
          <tr>
            <th class="green">Total Land Value (in Rs)</th>
            <td><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data6['finally_plot_valuation'] ?? '') ?>
    </span></td>
            <th class="green">
              Total Construction Value at present construction stage (in Rs)
            </th>
            <td><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars('0') ?>
    </span></td>
          </tr>
          <tr>
            <th class="green">
            Market Value of Land & Building for 100% complete property (in Rs)
            </th>
            <td><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data10['NA'] ?? '') ?>
    </span></td>
            <th class="green">
           Market Value of Land & Building at present stage of completion (in Rs)
            </th>
            <td><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data10['NA'] ?? '') ?>
    </span></td>
          </tr>

          <tr>
            <th colspan="6" class="section-title blue">
              Valuation of Flat / Shop / Office / Industrial / Other unit etc
            </th>
          </tr>
          <tr>
            <th class="green">Flat / Apartment / Shop / Office on adopted Area (in Sqft)</th>
            <td><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data6['final_area_square_feet'] ?? '') ?>
    </span></td>
            <th class="green">Rate Range in the locality (Rs per sqft)</th>
            <td><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data10['NA'] ?? '') ?>
    </span></td>
          </tr>
          <tr>
            <th class="green">Amenities and other costs if any (in Rs)</th>
            <td><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data10['NA'] ?? '') ?>
    </span></td>
            <th class="green">Rate considered (Rs per sqft)</th>
            <td><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data6['final_construction_rate'] ?? '') ?>
    </span></td>
          </tr>
          <tr>
            <th class="green">
              Total Realisable Value of Flat / Shop / Flat / Office on 100%
              complete (in Rs)
            </th>
            <td><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data6['total_finally_area_valuation'] ?? '') ?>
    </span></td>
            <th class="green">
              Total Realisable Value of Flat / Shop / Flat / Office on present
              completion stage (in Rs)
            </th>
            <td><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data6['total_finally_area_valuation'] ?? '') ?>
    </span></td>
          </tr>

          <tr>
            <th colspan="6" class="section-title blue">Stage of Construction</th>
          </tr>
          <tr>
            <th class="green">% Completion</th>
            <td><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data8['stage_construction_actual_present_completion'] ?? '') ?>
    </span></td>
            <th class="green">% Recommendation</th>
            <td><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data8['stage_construction_recommend_present_completion'] ?? '') ?>
    </span></td>
          </tr>
        </table>
        <table>
          <tr>
            <td colspan="5" class="section-title blue">
              Guideline & Distress/Forced Sale Value
            </td>
          </tr>
          <tr>
            <td class="green"  colspan="1">Government Guideline/ Circle rate for Land (Rs per sqft)</td>
            <td colspan="2"><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data6['guideline_rate'] ?? '') ?>
    </span></td>
            <td colspan="1" class="green">Land Value as per Government Rate (Rs)</td>
            <td colspan="2"><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data6['guideline_values'] ?? '') ?>
    </span></td>
          </tr>
          <tr>
            <td class="green" colspan="1">
              Government Guideline/ Circle rate for Flat/Unit/ Built up (Rs per
              sqft)
            </td>
            <td colspan="2"><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data6['guideline_rate'] ?? '') ?>
    </span></td>
            <td colspan="1" class="green">Flat / Unit/Built up Value as per Government Rate (Rs)</td>
            <td colspan="2"><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data6['guideline_rate'] ?? '') ?>
    </span></td>
          </tr>
          <tr>
            <td class="green" colspan="1">Relisable Value at 100% Stage</td>
            <td colspan="2"><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data6['total_finally_area_valuation'] ?? '') ?>
    </span></td>
            <td colspan="1" class="green">Distress Value at 100% Stage</td>
            <td colspan="2"><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data6['total_distress_value'] ?? '') ?>
    </span></td>
          </tr>
</table>
<table>
          <tr>
            <td colspan="5" class="section-title pink">
              Property Specific Remarks & Observation
            </td>
          </tr>
        
</table>
<table>
          <tr>
        <span style="white-space: pre-line; font-size:14px; display: block; text-align: left; padding: 0; margin: 0;font-weight:400;"readonly>
        <?= htmlspecialchars($data10['remarks'] ?? '') ?>
    </span>
</tr>
  <tr>
            <th colspan="5">References of Transactions Available</th>
          </tr>
          <tr>
            <td rowspan="2" class="green">Reference of Transition Available</td>
            <td class="green"><strong>Ref 1</strong></td>
            <td class="green"><strong>Ref 2</strong></td>
            <td class="green"><strong>Ref 3</strong></td>
            <td class="green"><strong>Ref 4</strong></td>
          </tr>
          <tr>
            <td><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data10['NA'] ?? '') ?>
    </span></td>
            <td><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data10['NA'] ?? '') ?>
    </span></td>
            <td><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data10['NA'] ?? '') ?>
    </span></td>
            <td><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data10['NA'] ?? '') ?>
    </span></td>
          </tr>

          <tr>
            <td colspan="5" class="section-title pink">Property Photographs</td>
          </tr>
          <tr>
            <th colspan="1" class="green">Name of the Customer/ Applicant</th>
            <td colspan="2"> <span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data1['customerName'] ?? '') ?>
    </span> </td>
            <th>Proposal ID/ Application No</th>
            <td><span style="display: inline-block; min-width: 50px; padding: 2px;">
        <?= htmlspecialchars($data1['applicationNo'] ?? '') ?>
    </span></td>
          </tr>
          <tr>
            <th class="green">Address of the property being appraised</th>
            <td colspan="4"> <span style="display: inline-block; min-width: 50px; padding: 2px;"readonly>
        <?= htmlspecialchars($data3['address_per_site'] ?? '') ?>
    </span>
          </td>
          </tr>
        </table>
 <table>
<tr><th style="margin-bottom:-18px;">PHOTOGRAPH OF THE PROPERTY</tr></th></table>
<br>

    
<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

$servername = "localhost";
$username   = "root";
$password   = "";
$dbname     = "project_db";

$conn = new mysqli($servername, $username, $password, $dbname);
if ($conn->connect_error) {
    die("Connection failed: " . htmlspecialchars($conn->connect_error));
}

$reference_id = $_SESSION['reference_id'] ?? null;
$reference_id = $_GET['reference_id'] ?? $reference_id;

if ($reference_id) {

    // Map captions
    $captions = [
        'image1'  => 'EXTERNAL PHOTOS',
        'image2'  => 'Kitchen',
        'image3'  => 'Selfie',
        'image4'  => 'Electric Meter',
        'image6'  => 'Other 1',
        'image7'  => 'Other 2',
        'image8'  => 'Other 3',
        'image9'  => 'Other 4',
        'image10' => 'Other 5',
        'image11' => 'Other 6',
        'image12' => 'Other 7',
        'image13' => 'Other 8',
        'image14' => 'Other 9',
        'image15' => 'Other 10',
        'image16' => 'Other 11',
        'image17' => 'Other 12',
        'image18' => 'Other 13',
        'image19' => 'Other 14',
        'image20' => 'Other 15',
    ];

    // === Helper: EXIF-aware orientation detection ===
    function classify_orientation_after_exif(string $imageData): ?string {
        $size = @getimagesizefromstring($imageData);
        if (!$size || !isset($size[0], $size[1])) {
            return null;
        }
        $width  = (int)$size[0];
        $height = (int)$size[1];

        $mime = $size['mime'] ?? '';
        if ($mime === 'image/jpeg' && function_exists('exif_read_data')) {
            $tmp = @tempnam(sys_get_temp_dir(), 'exif_');
            if ($tmp !== false) {
                @file_put_contents($tmp, $imageData);
                $exif = @exif_read_data($tmp);
                @unlink($tmp);

                if (!empty($exif['Orientation'])) {
                    $orientation = (int)$exif['Orientation'];
                    if ($orientation === 6 || $orientation === 8) {
                        $t = $width; $width = $height; $height = $t;
                    }
                }
            }
        }
        return ($width >= $height) ? 'horizontal' : 'vertical';
    }

    // === Helper: Fix orientation physically with Imagick ===
    function fixImageOrientation($binaryData) {
        $img = new Imagick();
        $img->readImageBlob($binaryData);

        switch ($img->getImageOrientation()) {
            case Imagick::ORIENTATION_BOTTOMRIGHT:
                $img->rotateImage("#000", 180);
                break;
            case Imagick::ORIENTATION_RIGHTTOP:
                $img->rotateImage("#000", 90);
                break;
            case Imagick::ORIENTATION_LEFTBOTTOM:
                $img->rotateImage("#000", -90);
                break;
        }

        $img->setImageOrientation(Imagick::ORIENTATION_TOPLEFT);
        $fixed = $img->getImageBlob();
        $img->destroy();

        return $fixed;
    }

    $sql = "SELECT 
                image1, image2, image3, image4, 
                image6, image7, image8, image9, 
                image10, image11, image12, image13, image14, image15, image16, image17, image18, image19, image20
            FROM final_uploaded_images 
            WHERE reference_id = ?";

    $stmt = $conn->prepare($sql);
    if ($stmt === false) {
        die("Error preparing the SQL statement: " . htmlspecialchars($conn->error));
    }

    $stmt->bind_param("s", $reference_id);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result && $result->num_rows > 0) {
        $horizontal_images = [];
        $vertical_images   = [];

        while ($row = $result->fetch_assoc()) {
            foreach ($row as $key => $imageData) {
                if (!empty($imageData)) {

                    // Actually fix image before displaying
                    $fixedData = fixImageOrientation($imageData);

                    $orientation = classify_orientation_after_exif($fixedData) ?? 'horizontal';
                    $imgString   = base64_encode($fixedData);
                    $caption     = $captions[$key] ?? 'Image';

                    $item = [
                        'data'    => $imgString,
                        'caption' => $caption,
                        'alt'     => $key,
                    ];

                    if ($orientation === 'horizontal') {
                        $horizontal_images[] = $item;
                    } else {
                        $vertical_images[]   = $item;
                    }
                }
            }
        }

 
// Output as a stable 4-column table (works in wkhtmltopdf)
$all_images = array_merge($vertical_images, $horizontal_images);

echo '<table class="image-grid">';
$rows = array_chunk($all_images, 4);
foreach ($rows as $row) {
    echo '<tr>';
    foreach ($row as $img) {
        echo '<td>';
        echo '<div class="img-wrap">';
        echo '<img src="data:image/jpeg;base64,' . $img['data'] . '" alt="' . htmlspecialchars($img['alt']) . '">';
        echo '<div class="caption">' . htmlspecialchars($img['caption']) . '</div>';
        echo '</div>';
        echo '</td>';
    }
    // pad remaining cells to keep 4 columns
    $remaining = 4 - count($row);
    if ($remaining > 0) {
        echo str_repeat('<td></td>', $remaining);
    }
    echo '</tr>';
}
echo '</table>';

    } else {
        echo "<p style='text-align:center;'>No images found.</p>";
    }

    $stmt->close();
} else {
    echo "<p style='text-align:center;'>Reference ID is missing.</p>";
}
?>

    
      <table>
  </tr>
  <tr>

<div class="google-map-container">
<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "project_db";
$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$reference_id = $_SESSION['reference_id'] ?? null;
$reference_id = $_GET['reference_id'] ?? $reference_id;

if ($reference_id) {
    $sql = "SELECT image5 FROM final_uploaded_images WHERE reference_id = ?";
    $stmt = $conn->prepare($sql);
    if ($stmt === false) {
        die("Error preparing the SQL statement: " . $conn->error);
    }

    $stmt->bind_param("s", $reference_id);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows > 0) {
        $row = $result->fetch_assoc();
        if (!empty($row['image5'])) {
 
            echo '<div><img src="data:image/jpeg;base64,' . base64_encode($row['image5']) . '" alt="Google Map"><p>Google Map</p></div>';
        } else {
            echo "<p style='text-align:center;'>Google Map image not available.</p>";
        }
    } else {
        echo "<p style='text-align:center;'>No record found for Google Map image.</p>";
    }

    $stmt->close();
} else {
    echo "<p style='text-align:center;'>Reference ID is missing.</p>";
}
?>
</tr>
</div>
    </table>
    </table>
      
    <table>
    </table>
  
    <table class="disclaimer">
      <tr><td colspan="4" class="section-title pink">Valuer Certification/Disclaimer</td></tr>
      <tr><td colspan="4">
     <span style="white-space: pre-line; font-size:14px; display: block; text-align: left; padding: 0; margin: 0;font-weight:400;" readonly>
    <?= nl2br(htmlspecialchars(formatDeclaration($data10['declaration'] ?? ''))) ?>
</span>
      </td></tr>
      <?php
function formatDeclaration($text) {
    // Insert a newline before every occurrence of a number followed by a dot and space (e.g., "1. ", "10. ")
    // Only if it's NOT already at the beginning of the string or a new line
    $text = preg_replace('/(?<!^)(?<!\n)(\d+\.\s)/', "\n$1", $text);
    return $text;
}
?>
    </table>

    <table class="footer-table">
      <tr>
        <td class="green"><strong>Name of Engineer Visited the property</strong></td>
        <td><input type="text" value="<?= $engineer_name ?? '' ?>" readonly></td>
        <td class="pink"><strong>Authorized Signatory Name & Signature</strong></td>
<td> <span style="white-space: pre-line; font-size:14px; display: block; text-align: left; padding: 0; margin: 0;font-weight:400;"readonly>
        <?= htmlspecialchars('MAGPIE ENGINEERING PVT. LTD.') ?>
    </span></td> </tr>
    </table>
  </div>
  
      </form>
    
    
   <!-- Buttons: Hidden during print -->
<div class="no-print">
  <form method="post">
    <input type="hidden" name="download_images" value="1">
    <button type="submit">Download All Images</button>
  </form>

  <button id="downloadPdf" onclick="setPrintMargins()">DOWNLOAD PDF</button>
</div>

  <script>
    document.getElementById('downloadPdf').addEventListener('click', () => {
      // Select the content you want to convert to PDF
      const element = document.getElementById('content');
      const options = {
        margin:[0,0],
        filename:'report.pdf',
        image: { type: 'jpeg', quality: 0.98 },
        html2canvas: { scale: 2 },
        jsPDF: { unit: 'in', format: 'letter', orientation: 'portrait' }
      };

      // Generate and download the PDF
      html2pdf().set(options).from(element).save();
    });
    function setPrintMargins() {
      const style = document.createElement('style');
      style.innerHTML = `
      @media print {
          body {
            margin:0.5;
          }
        }
      `;
      document.head.appendChild(style);
      window.print();
    }
    // Disable all input fields in the form
    document.querySelectorAll('input').forEach(function(input) {
        input.disabled = true;  // Disables the field completely
    });
     function resizeFakeInput(input) {
    const fake = document.getElementById('fakeWrap');
    fake.textContent = input.value || ' ';
    input.style.height = fake.scrollHeight + 'px';
  }

  // Initialize height
  resizeFakeInput(document.getElementById('longInput'));
   function autoResize(el) {
    el.style.height = 'auto'; // reset height
    el.style.height = el.scrollHeight + 'px'; // set to content height
  }
  // Auto-resize on load
  document.querySelectorAll('.clean-textarea').forEach(t => autoResize(t));
    </script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/jspdf/2.5.1/jspdf.umd.min.js"></script>

  <script>
    // Disable input fields before generating PDF
    function disableInputs() {
      document.querySelectorAll('input, textarea').forEach(input => input.disabled = true);
    }

    // Re-enable input fields after PDF generation (optional)
    function enableInputs() {
      document.querySelectorAll('input, textarea').forEach(input => input.disabled = false);
    }

    // Auto-resize textareas
    function autoResize(el) {
      el.style.height = 'auto';
      el.style.height = el.scrollHeight + 'px';
    }

    document.querySelectorAll('.clean-textarea').forEach(t => autoResize(t));

    // PDF generation logic using jsPDF with html()
    document.getElementById('downloadPdf').addEventListener('click', async () => {
      disableInputs();

      const { jsPDF } = window.jspdf;
      const doc = new jsPDF({
        orientation: 'portrait',
        unit: 'pt',
        format: 'a4'
      });

      await doc.html(document.getElementById('content'), {
        callback: function (doc) {
          doc.save('report.pdf');
          enableInputs();
        },
        margin: [40, 40, 40, 40],
        autoPaging: 'text',
        x: 10,
        y: 10,
        html2canvas: {
          scale: 1,
          useCORS: true
        }
      });
    });
  </script>
</div>
</body>
</html>


