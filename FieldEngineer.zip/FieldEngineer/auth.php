<?php
session_start();
if (!isset($_SESSION["engineer_id"])) {
    header("Location: login.php");
    exit();
}
?>
