<?php include('auth.php'); ?>
 
<?php
// Database connection details
$host = 'localhost';
$db = 'project_db';
$user = 'root';
$pass = '';
$pdo = null;
$message = "";

// Connect to the database
try {
    $pdo = new PDO("mysql:host=$host;dbname=$db;charset=utf8", $user, $pass);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (PDOException $e) {
    die("Database connection failed: " . $e->getMessage());
}

// File upload and database insertion logic
$maxSize = 8 * 1024 * 1024; // 3MB per image
$messages = [];
$uploadSuccess = true;
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_FILES['images'], $_POST['reference_id'])) {
    $referenceId = $_POST['reference_id'];
    $customername = $_POST['customerName'] ?? null;
    $bankname = $_POST['bankName'] ?? null;

    $images = $_FILES['images'];

    // Debug - Check if files actually arrived
    if (empty($images['name'][0])) {
        die("No files received. Please try again.");
    }

    try {
        $stmt = $pdo->prepare(
            "INSERT INTO uploaded_images (reference_id, customerName, bankName)
             VALUES (?, ?, ?)
             ON DUPLICATE KEY UPDATE 
             customerName = VALUES(customerName), 
             bankName = VALUES(bankName)"
        );
        $stmt->execute([$referenceId, $customername, $bankname]);
    } catch (Exception $e) {
        die("Failed to initialize or update record: " . $e->getMessage());
    }

    // Prepare 50 image columns
    $columnNames = [];
    for ($i = 1; $i <= 50; $i++) {
        $columnNames[] = "image$i";
    }

    try {
        $fetchStmt = $pdo->prepare("SELECT " . implode(", ", $columnNames) . " FROM uploaded_images WHERE reference_id = ?");
        $fetchStmt->execute([$referenceId]);
        $existingData = $fetchStmt->fetch(PDO::FETCH_ASSOC);
        if (!$existingData) {
            die("Record fetch failed for reference ID $referenceId.");
        }
    } catch (Exception $e) {
        die("DB fetch error: " . $e->getMessage());
    }

    // Process each image
    foreach ($images['tmp_name'] as $index => $tmpName) {
        $error = $images['error'][$index];
        $size = $images['size'][$index];
        $name = $images['name'][$index];
        $type = $images['type'][$index];

        if ($error !== UPLOAD_ERR_OK) {
            $messages[] = "File $name failed to upload. Error code: $error";
            $uploadSuccess = false;
            continue;
        }

        if ($size > $maxSize) {
            $messages[] = "File $name exceeds max size of 8MB.";
            $uploadSuccess = false;
            continue;
        }

        if (!str_starts_with($type, "image/")) {
            $messages[] = "File $name is not a valid image.";
            $uploadSuccess = false;
            continue;
        }

        $imageData = file_get_contents($tmpName);
        if (!$imageData) {
            $messages[] = "Failed to read image data for $name.";
            $uploadSuccess = false;
            continue;
        }

        // Find next empty column
        $nextColumn = null;
        for ($i = 1; $i <= 50; $i++) {
            if (empty($existingData["image$i"])) {
                $nextColumn = "image$i";
                $existingData["image$i"] = true;
                break;
            }
        }

        if (!$nextColumn) {
            $uploadSuccess = false;
            $messages[] = "No available columns to store $name.";
            break;
        }

        try {
            $updateStmt = $pdo->prepare("UPDATE uploaded_images SET $nextColumn = ? WHERE reference_id = ?");
            $updateStmt->execute([$imageData, $referenceId]);
            $messages[] = "File $name uploaded to $nextColumn.";
        } catch (Exception $e) {
            $uploadSuccess = false;
            $messages[] = "Error storing $name: " . $e->getMessage();
        }
    }

    // Mark assignment done
    if ($uploadSuccess) {
        try {
            $updateQuery = "UPDATE mis SET flag_fe_submit = TRUE, fe_to_coordinator_assign_at = CURRENT_TIMESTAMP WHERE reference_id = :reference_id";
            $stmt = $pdo->prepare($updateQuery);
            $stmt->bindParam(':reference_id', $referenceId, PDO::PARAM_STR);
            $stmt->execute();
            $messages[] = "Task assigned successfully.";
        } catch (Exception $e) {
            $messages[] = "Task update failed: " . $e->getMessage();
        }

        header("Location: index.php");
        exit();
    }
}

?>
<!-- JavaScript for Alert -->
<script>
    <?php if (!empty($message)): ?>
    alert("<?= htmlspecialchars_decode(addslashes($message)) ?>");
    <?php endif; ?>
</script>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Magpie Engineering</title>

  <link rel="stylesheet" href="uploadFE.css">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
  <style>
    .preview-wrapper {
      position: relative;
      display: inline-block;
      margin: 10px;
      text-align: center;
    }
    .preview-image {
      width: 120px;
      height: auto;
      display: block;
      border: 1px solid #ccc;
      border-radius: 8px;
    }
    .size-warning {
      color: red;
      font-size: 12px;
      margin-top: 5px;
    }
  </style>
</head>
<body>
<button class="toggle-btn" id="toggle-btn">☰</button>
<div class="container">
  <div class="sidebar" id="sidebar">
    <div style="display: flex;">
      <img class="logo" src="logo.png" alt="">
      <h1>Magpie Engineering</h1>
    </div>
    <div class="rotating-text">Field Engineer</div>
    <a href="home.php"><i class="fas fa-home icon"></i> Home</a>
    <a href="index.php" class="active"><i class="fas fa-file-alt icon"></i> Assignment List</a>
    <a href="issuesFE.php"><i class="fas fa-exclamation-triangle icon"></i> Issues</a>
    <a href="login.php"><i class="fas fa-sign-out-alt icon"></i> Logout</a>
  </div>

  <div class="content">
    <h2 class="title">Upload Images</h2>
    <form id="upload-form" enctype="multipart/form-data" method="POST" onsubmit="disableSubmitButton()">
      <div class="input-group">
        <label for="reference-id">Reference ID:</label>
        <input type="text" id="reference-id" name="reference_id" value="<?= htmlspecialchars($_GET['reference_id'] ?? '') ?>" readonly>
      </div>

      <div class="input-group">
        <label for="customer-name">Customer Name:</label>
        <input type="text" id="customer-name" name="customerName" value="<?= htmlspecialchars($_GET['customerName'] ?? '') ?>" readonly>
      </div>

      <div class="input-group">
        <label for="bank-name">Bank Name:</label>
        <input type="text" id="bank-name" name="bankName" value="<?= htmlspecialchars($_GET['bankName'] ?? '') ?>" readonly>
      </div>

      <div class="input-group file-upload">
        <input type="file" id="file-input" name="images[]" multiple accept="image/*" required style="display: none;">
        <label id="select-images-btn" for="file-input" class="upload-btn">Select Images</label>
      </div>

      <div id="image-previews" class="image-previews"></div>

      <button type="submit" id="upload-btn" class="upload-btn">Upload Images</button>
    </form>
    <script>
    function disableSubmitButton() {
        const submitBtn = document.getElementById('upload-btn');
        submitBtn.disabled = true;
        submitBtn.innerText = 'Uploading...'; // Optional: gives user feedback
    }
</script>
    
    <div id="response-message" class="response-message"></div>
  </div>
</div>
<script>
  // Sidebar toggle functionality
  document.getElementById("toggle-btn").addEventListener("click", () => {
    document.getElementById("sidebar").classList.toggle("visible");
  });

  const fileInput = document.getElementById("file-input");
  const uploadBtn = document.getElementById("upload-btn");
  const previewContainer = document.getElementById("image-previews");
  const resizerBox = document.getElementById("resizer-box");

  let allFiles = [];

  function updateFileInput() {
    const dataTransfer = new DataTransfer();
    allFiles.forEach(file => dataTransfer.items.add(file));
    fileInput.files = dataTransfer.files;
  }

  function checkOversize() {
    const oversize = allFiles.some(file => file.size > 1 * 1024 * 1024);
    uploadBtn.disabled = oversize;
  }

  function rebuildPreviews() {
    previewContainer.innerHTML = "";

    allFiles.forEach((file, index) => {
      const reader = new FileReader();
      reader.onload = function (e) {
        const wrapper = document.createElement("div");
        wrapper.classList.add("preview-wrapper");

        const img = document.createElement("img");
        img.className = "preview-image";
        img.src = e.target.result;

        const closeBtn = document.createElement("span");
        closeBtn.innerHTML = "✖";
        closeBtn.className = "close-btn";
        closeBtn.style.position = "absolute";
        closeBtn.style.top = "2px";
        closeBtn.style.right = "5px";
        closeBtn.style.cursor = "pointer";
        closeBtn.style.color = "red";
        closeBtn.style.fontWeight = "bold";
        closeBtn.style.fontSize = "18px";

        closeBtn.onclick = () => {
          allFiles.splice(index, 1);
          rebuildPreviews();
          updateFileInput();
        };

        wrapper.appendChild(closeBtn);
        wrapper.appendChild(img);

        if (file.size > 1 * 1024 * 1024) {
          const warning = document.createElement("div");
          warning.className = "size-warning";
          warning.innerText = "This image is greater than 1MB.";
          wrapper.appendChild(warning);
        }

        previewContainer.appendChild(wrapper);
      };
      reader.readAsDataURL(file);
    });

    checkOversize();
  }
fileInput.addEventListener("change", async function () {
  const newFiles = Array.from(this.files);

  for (const file of newFiles) {
    const isDuplicate = allFiles.some(existingFile =>
      existingFile.name === file.name && existingFile.size === file.size
    );
    if (isDuplicate) continue;

    let finalFile = file;

    // Automatically resize if image is over 1MB
    if (file.size > 1 * 1024 * 1024 && file.type.startsWith("image/")) {
      try {
        const resizedBlob = await resizeImage(file, 0.85);
        if (resizedBlob.size < file.size) {
          finalFile = new File([resizedBlob], file.name, { type: "image/jpeg" });
        }
      } catch (error) {
        console.error("Failed to resize image:", error);
      }
    }

    allFiles.push(finalFile);
  }

  rebuildPreviews();
  updateFileInput();
});

  // Drag and drop to resize
  resizerBox.addEventListener("dragover", function (e) {
    e.preventDefault();
    this.style.backgroundColor = "#f0f0f0";
  });

  resizerBox.addEventListener("dragleave", function (e) {
    this.style.backgroundColor = "";
  });
resizerBox.addEventListener("drop", async function (e) {
  e.preventDefault();
  this.style.backgroundColor = "";

  const droppedFile = e.dataTransfer.files[0];
  if (!droppedFile || !droppedFile.type.startsWith("image/")) {
    alert("Only image files allowed.");
    return;
  }

  if (droppedFile.size <= 1 * 1024 * 1024) {
    alert("This image is already below 1MB.");
    return;
  }

  const resizedBlob = await resizeImage(droppedFile, 0.85);
  if (resizedBlob.size > 1 * 1024 * 1024) {
    alert("Could not resize image below 1MB. Try smaller images.");
    return;
  }

  const resizedFile = new File([resizedBlob], droppedFile.name, { type: "image/jpeg" });

  // 🔄 Remove original from allFiles list
  allFiles = allFiles.filter(f => !(f.name === droppedFile.name && f.size === droppedFile.size));

  // ✅ Add resized version
  allFiles.push(resizedFile);

  // ✅ Remove the old preview manually (DOM cleanup)
  const previewDivs = document.querySelectorAll("#image-previews .preview-wrapper");
  previewDivs.forEach(div => {
    const img = div.querySelector("img");
    if (img && img.src && img.alt === droppedFile.name) {
      div.remove();
    }
  });

  // ✅ Show updated preview
  rebuildPreviews();
  updateFileInput();
});


  async function resizeImage(file, quality = 0.85) {
    return new Promise((resolve, reject) => {
      const reader = new FileReader();
      reader.onload = function (event) {
        const img = new Image();
        img.onload = function () {
          const canvas = document.createElement("canvas");
          let width = img.width;
          let height = img.height;

          // Resize logic: scale down if too big
          const maxDimension = 1200; // optional
          if (width > maxDimension || height > maxDimension) {
            if (width > height) {
              height *= maxDimension / width;
              width = maxDimension;
            } else {
              width *= maxDimension / height;
              height = maxDimension;
            }
          }

          canvas.width = width;
          canvas.height = height;
          const ctx = canvas.getContext("2d");
          ctx.drawImage(img, 0, 0, width, height);
          canvas.toBlob(
            (blob) => {
              resolve(blob);
            },
            "image/jpeg",
            quality
          );
        };
        img.onerror = reject;
        img.src = event.target.result;
      };
      reader.onerror = reject;
      reader.readAsDataURL(file);
    });
  }

  document.getElementById("upload-form").addEventListener("submit", function (e) {
    updateFileInput();
  });
</script>

</body>
</html>
